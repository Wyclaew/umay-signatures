import "dotnet"
import "hash"
import "pe"

rule SIGNATURE_BASE_WEBSHELL_PAS_Webshell : FILE
{
	meta:
		description = "Detects P.A.S. PHP webshell - Based on DHS/FBI JAR-16-2029 (Grizzly  Steppe)"
		author = "FR/ANSSI/SDO (modified by Florian Roth)"
		id = "862aab77-936e-524c-8669-4f48730f4ed5"
		date = "2021-02-15"
		modified = "2026-10-29"
		reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_centreon.yar#L10-L28"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "977ee0fdf0e92ccea6b71fea7b2c7aed2965c6966d8af86230ccb0f95b286694"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$php = "<?php"
		$strreplace = "(str_replace("
		$md5 = ".substr(md5(strrev($"
		$gzinflate = "gzinflate"
		$cookie = "_COOKIE"
		$isset = "isset"

	condition:
		( filesize > 20KB and filesize < 200KB ) and all of them
}
rule SIGNATURE_BASE_WEBSHELL_PAS_Webshell_Ziparchivefile
{
	meta:
		description = "Detects an archive file created by P.A.S. for download operation"
		author = "FR/ANSSI/SDO (modified by Florian Roth)"
		id = "081cc65b-e51c-59fc-a518-cd986e8ee2f7"
		date = "2021-02-15"
		modified = "2026-10-29"
		reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_centreon.yar#L30-L42"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c15e7022f45ec211ba635d6cd31bab16f4fb0d3038fb19d5765e0f751c14a826"
		score = 80
		quality = 85
		tags = ""

	strings:
		$s1 = "Archive created by P.A.S. v."

	condition:
		$s1
}
rule SIGNATURE_BASE_WEBSHELL_PAS_Webshell_Perlnetworkscript : FILE
{
	meta:
		description = "Detects PERL scripts created by P.A.S. webshell"
		author = "FR/ANSSI/SDO"
		id = "1625b63f-ead7-5712-92b4-0ce6ecc49fd4"
		date = "2021-02-15"
		modified = "2026-10-29"
		reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_centreon.yar#L44-L62"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b170c07a005e737c8069f2cc63f869d4d3ff6593b3bfca5bcaf02d7808da6852"
		score = 90
		quality = 85
		tags = "FILE"

	strings:
		$pl_start = "#!/usr/bin/perl\n$SIG{'CHLD'}='IGNORE'; use IO::Socket; use FileHandle;"
		$pl_status = "$o=\" [OK]\";$e=\" Error: \""
		$pl_socket = "socket(SOCKET, PF_INET, SOCK_STREAM,$tcp) or die print \"$l$e$!$l"
		$msg1 = "print \"$l OK! I\\'m successful connected.$l\""
		$msg2 = "print \"$l OK! I\\'m accept connection.$l\""

	condition:
		filesize < 6000 and ( $pl_start at 0 and all of ( $pl* ) ) or any of ( $msg* )
}
rule SIGNATURE_BASE_WEBSHELL_PAS_Webshell_Sqldumpfile
{
	meta:
		description = "Detects SQL dump file created by P.A.S. webshell"
		author = "FR/ANSSI/SDO"
		id = "4c26feeb-3031-5c91-9eeb-4b5fe9702e39"
		date = "2021-02-15"
		modified = "2026-10-29"
		reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_centreon.yar#L64-L76"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c34abcada22fdf462fd66cc2da18ab9e54215defc6f7a7a95b5a80d1155a2ffe"
		score = 90
		quality = 85
		tags = ""

	strings:
		$ = "-- [ SQL Dump created by P.A.S. ] --"

	condition:
		1 of them
}
rule SIGNATURE_BASE_APT_MAL_Sandworm_Exaramel_Configuration_Key
{
	meta:
		description = "Detects the encryption key for the configuration file used by Exaramel malware as seen in sample e1ff72[...]"
		author = "FR/ANSSI/SDO"
		id = "8078de62-3dd2-5ee0-8bda-f508e4013144"
		date = "2021-02-15"
		modified = "2026-10-29"
		reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_centreon.yar#L78-L90"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "056503a2c240a641cd2292a30ab1090e3a358cb4d57dca83b836ecb1bc62ed6b"
		score = 80
		quality = 85
		tags = ""

	strings:
		$ = "odhyrfjcnfkdtslt"

	condition:
		all of them
}
rule SIGNATURE_BASE_APT_MAL_Sandworm_Exaramel_Configuration_Name_Encrypted
{
	meta:
		description = "Detects the specific name of the configuration file in Exaramel malware as seen in sample e1ff72[...]"
		author = "FR/ANSSI/SDO"
		id = "1c06f5fc-3435-51cd-92fb-17a4ab6b63ad"
		date = "2021-02-15"
		modified = "2026-10-29"
		reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_centreon.yar#L92-L104"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f65d59381403534a2c2f39d66c7c62bf1540eafc9aad1ad73de1809e91c42446"
		score = 80
		quality = 85
		tags = ""

	strings:
		$ = "configtx.json"

	condition:
		all of them
}
rule SIGNATURE_BASE_APT_MAL_Sandworm_Exaramel_Configuration_File_Plaintext
{
	meta:
		description = "Detects contents of the configuration file used by Exaramel (plaintext)"
		author = "FR/ANSSI/SDO"
		id = "6f0d834b-e6c8-59e6-bf9a-b4fd9c0b2297"
		date = "2021-02-15"
		modified = "2026-10-29"
		reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_centreon.yar#L106-L118"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "536327d5216372a3fd2f4dad0a21be2778ce2930212daf0a8628ecbdab49b46e"
		score = 80
		quality = 85
		tags = ""

	strings:
		$ = /\{"Hosts":\[".{10,512}"\],"Proxy":".{0,512}","Version":".{1,32}","Guid":"/

	condition:
		all of them
}
rule SIGNATURE_BASE_APT_MAL_Sandworm_Exaramel_Configuration_File_Ciphertext
{
	meta:
		description = "Detects contents of the configuration file used by Exaramel (encrypted with key odhyrfjcnfkdtslt, sample e1ff72[...]"
		author = "FR/ANSSI/SDO"
		id = "763dbb17-2bad-5b40-8a7b-b71bc5849cd9"
		date = "2021-02-15"
		modified = "2026-10-29"
		reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_centreon.yar#L120-L132"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9dc7ee5b0a218a2b5be652e137fa090c944c3ddb0f699f521a72896668210813"
		score = 80
		quality = 85
		tags = ""

	strings:
		$ = { 6F B6 08 E9 A3 0C 8D 5E DD BE D4 }

	condition:
		all of them
}
rule SIGNATURE_BASE_APT_MAL_Sandworm_Exaramel_Socket_Path
{
	meta:
		description = "Detects path of the unix socket created to prevent concurrent executions in Exaramel malware"
		author = "FR/ANSSI/SDO"
		id = "3aab84c9-9748-5d11-9cd7-efa9151036cf"
		date = "2021-02-15"
		modified = "2026-10-29"
		reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_centreon.yar#L134-L146"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8c049b5a7b508ca0f160d166f3c726e4a23a2c5b3105d075d7bf7a301a1c58f6"
		score = 80
		quality = 85
		tags = ""

	strings:
		$ = "/tmp/.applocktx"

	condition:
		all of them
}
rule SIGNATURE_BASE_APT_MAL_Sandworm_Exaramel_Task_Names
{
	meta:
		description = "Detects names of the tasks received from the CC server in Exaramel malware"
		author = "FR/ANSSI/SDO"
		id = "185f2f3b-bf5c-54af-bca2-400d08bf9c91"
		date = "2021-02-15"
		modified = "2026-10-29"
		reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_centreon.yar#L148-L167"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "193482da1e2b9509fa9c65d46edc56057f7b5d44b7408d918d4a9cbb60736dab"
		score = 80
		quality = 85
		tags = ""

	strings:
		$ = "App.Delete"
		$ = "App.SetServer"
		$ = "App.SetProxy"
		$ = "App.SetTimeout"
		$ = "App.Update"
		$ = "IO.ReadFile"
		$ = "IO.WriteFile"
		$ = "OS.ShellExecute"

	condition:
		all of them
}
rule SIGNATURE_BASE_APT_MAL_Sandworm_Exaramel_Struct
{
	meta:
		description = "Detects the beginning of type _type struct for some of the most important structs in Exaramel malware"
		author = "FR/ANSSI/SDO"
		id = "8282e485-966c-554d-8e41-70dc1657f5ea"
		date = "2021-02-15"
		modified = "2026-10-29"
		reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_centreon.yar#L169-L185"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "312d0598fa85837f94023036468fcae50e8b2de532430a944befa8090afe79f6"
		score = 80
		quality = 85
		tags = ""

	strings:
		$struct_le_config = {70 00 00 00 00 00 00 00 58 00 00 00 00 00 00 00 47 2d 28 42 0? [2] 19}
		$struct_le_worker = {30 00 00 00 00 00 00 00 30 00 00 00 00 00 00 00 46 6a 13 e2 0? [2] 19}
		$struct_le_client = {20 00 00 00 00 00 00 00 10 00 00 00 00 00 00 00 7b 6a 49 84 0? [2] 19}
		$struct_le_report = {30 00 00 00 00 00 00 00 28 00 00 00 00 00 00 00 bf 35 0d f9 0? [2] 19}
		$struct_le_task = {50 00 00 00 00 00 00 00 20 00 00 00 00 00 00 00 88 60 a1 c5 0? [2] 19}

	condition:
		any of them
}
rule SIGNATURE_BASE_APT_MAL_Sandworm_Exaramel_Strings_Typo
{
	meta:
		description = "Detects misc strings in Exaramel malware with typos"
		author = "FR/ANSSI/SDO"
		id = "fdc79b87-eb9e-5751-9474-ff653b073165"
		date = "2021-02-15"
		modified = "2026-10-29"
		reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_centreon.yar#L187-L202"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "65e6de743eb9fc742674c7e54eef8a376963a6fd4380bacd03fe6f92d4235920"
		score = 80
		quality = 85
		tags = ""

	strings:
		$typo1 = "/sbin/init | awk "
		$typo2 = "Syslog service for monitoring \n"
		$typo3 = "Error.Can't update app! Not enough update archive."
		$typo4 = ":\"metod\""

	condition:
		3 of ( $typo* )
}
rule SIGNATURE_BASE_APT_MAL_Sandworm_Exaramel_Strings
{
	meta:
		description = "Detects Strings used by Exaramel malware"
		author = "FR/ANSSI/SDO (composed from 4 saparate rules by Florian Roth)"
		id = "30225dd7-420a-43a0-bc8b-2ad36dea6019"
		date = "2021-02-15"
		modified = "2026-10-29"
		reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_centreon.yar#L204-L232"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9d2790e60184ed973b2735263d0a997f32af0beacc9ea8ef65926fe6507011d5"
		score = 80
		quality = 85
		tags = ""

	strings:
		$persistence1 = "systemd"
		$persistence2 = "upstart"
		$persistence3 = "systemV"
		$persistence4 = "freebsd rc"
		$report1 = "systemdupdate.rep"
		$report2 = "upstartupdate.rep"
		$report3 = "remove.rep"
		$url1 = "/tasks.get/"
		$url2 = "/time.get/"
		$url3 = "/time.set"
		$url4 = "/tasks.report"
		$url5 = "/attachment.get/"
		$url6 = "/auth/app"

	condition:
		(5 of ( $url* ) and all of ( $persistence* ) ) or ( all of ( $persistence* ) and all of ( $report* ) ) or ( 5 of ( $url* ) and all of ( $report* ) )
}
rule SIGNATURE_BASE_MAL_UNC2891_Slapstick : FILE
{
	meta:
		description = "Detects UNC2891 Slapstick pam backdoor"
		author = "Frank Boldewin (@r3c0nst), slightly modifier by Florian Roth"
		id = "eb5db507-ac12-5c11-9dd9-ec34b9a80e1c"
		date = "2022-03-30"
		modified = "2023-01-05"
		reference = "https://github.com/fboldewin/YARA-rules/tree/master"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_unc2891_mal_jan23.yar#L19-L39"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "9d0165e0484c31bd4ea467650b2ae2f359f67ae1016af49326bb374cead5f789"
		logic_hash = "4bc51a47a1b620c3bb950c287c38a37e528e79f9720fb4d9fa9ebecbeca82036"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$code1 = {F6 50 04 48 FF C0 48 39 D0 75 F5}
		$code2 = {88 01 48 FF C1 8A 11 89 C8 29 F8 84 D2 0F 85}
		$str1 = "/proc/self/exe" fullword ascii
		$str2 = "%-23s %-23s %-23s %-23s %-23s %s" fullword ascii
		$str3 = "pam_sm_authenticate" ascii
		$str_fr1 = "HISTFILE=/dev/null"

	condition:
		uint32( 0 ) == 0x464c457f and filesize < 100KB and ( all of ( $code* ) or all of ( $str* ) )
}
rule SIGNATURE_BASE_MAL_Information_Collector_May26 : FILE
{
	meta:
		description = "Detects reconaissance payload used in the DAEMON Tools supplychain compromise. The tools collects detailed information about the infected system like hardware, installed software, running processes etc. all data is exfilled to an attacker controlled server."
		author = "MalGamy, Jonathan Peters (cod3nym)"
		id = "97bfe7ef-ba23-550c-a6bf-412c759eec91"
		date = "2026-05-05"
		modified = "2026-05-15"
		reference = "https://securelist.com/tr/daemon-tools-backdoor/119654/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/threat_compromised_daemon_tools_lite_may26.yar#L1-L27"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "a916e56121212613d17932e124b68752c9312e73bde8f2351054bd64394257df"
		logic_hash = "fe05c931037eb62a78f4f696a2697b44672751538eadd37ff20379d9bdd4f013"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$x1 = ": InfoCollector.exe <" wide
		$s1 = "CollectInstalledSoftwareSemicolon" ascii
		$s2 = "GetRc4KeyFromUrl" ascii
		$s3 = "InfoGatherer" ascii
		$op1 = { 09 7E ?? ?? ?? 04 28 ?? ?? ?? 0A 28 ?? ?? ?? 0A 13 ?? 11 ?? 16 36 3A 11 ?? 1E 35 ?? 1E 8D ?? ?? ?? 01 13 ?? 09 7E ?? ?? ?? 04 28 ?? ?? ?? 0A 11 ?? 16 11 ?? 28 ?? ?? ?? 0A }
		$op2 = { 02 73 ?? ?? ?? 0A 6F ?? ?? ?? 0A 0A 06 2D ?? 72 ?? ?? ?? 70 0B DE ?? 06 6F ?? ?? ?? 0A 0A 06 72 ?? ?? ?? 70 7E ?? ?? ?? 0A 6F ?? ?? ?? 0A 0A 06 6F ?? ?? ?? 0A 2D ?? 72 ?? ?? ?? 70 0B DE ?? 06 0B DE }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 50KB and ( $x1 or all of ( $op* ) or all of ( $s* ) )
}
rule SIGNATURE_BASE_MAL_Backdoor_May26
{
	meta:
		description = "Detects a backdoor smuggled into signed DAEMON Tools binaries via supply-chain compromise, receives encrypted commands over HTTPS to execute arbitrary shell commands and drop files on victim hosts."
		author = "MalGamy"
		id = "8f2493db-3ce6-576a-b1e9-80910dfbbaa8"
		date = "2026-05-05"
		modified = "2026-05-15"
		reference = "https://securelist.com/tr/daemon-tools-backdoor/119654/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/threat_compromised_daemon_tools_lite_may26.yar#L52-L66"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "5d581534b48d09855ac045aaf9b196ca26396a6c08616213f9f9afc656849c2f"
		logic_hash = "6173f47f8b50b409bbe63cfa512b0081f5085357df8c9ffd0db198a7d4717625"
		score = 80
		quality = 85
		tags = ""

	strings:
		$op1 = { 48 8D 8D ?? ?? ?? ?? C7 45 ?? ?? ?? ?? ?? C7 45 ?? ?? ?? ?? ?? F3 0F 7F 7D ?? C7 45 ?? ?? ?? ?? ?? F3 0F 7F 75 ?? C7 45 ?? ?? ?? ?? ?? C7 45 ?? ?? ?? ?? ?? 66 C7 45 ?? ?? ?? C6 45 ?? ?? FF 15 ?? ?? ?? ?? 48 8D 15 ?? ?? ?? ?? 48 8D 8D ?? ?? ?? ?? FF 15 ?? ?? ?? ?? 48 8D 95 }
		$op2 = { 4D 8D 40 ?? 99 41 FF C1 41 F7 FB 48 63 C2 0F B6 8C 05 ?? ?? ?? ?? 41 30 48 ?? 49 83 EA }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Minimalistic_Backdoor_May26 : FILE
{
	meta:
		description = "Detects minimalistic backdoor deployment where a shellcode loader downloads an encrypted payload and executes it in memory after RC4 decryption using a command-line provided key"
		author = "MalGamy"
		id = "8292161d-8b20-51e0-987a-dd0f4c1cf3e8"
		date = "2026-05-05"
		modified = "2026-05-15"
		reference = "https://securelist.com/tr/daemon-tools-backdoor/119654/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/threat_compromised_daemon_tools_lite_may26.yar#L68-L92"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "395ec7acd475a8acd358adc75c4615cf41737aed8a96c4f2dd792c8a6af4140c"
		logic_hash = "0f5e1f95d28fe5e45a10d652a11e9940823b4ac113dcf9b547f81d35bcda6cc7"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "Note: if multiple processes load the DLL," wide
		$x2 = "Inject (shellcode file is RC4 ciphertext; key is a UTF-8 string" wide
		$s1 = "Error: VirtualAllocEx failed, Win" wide
		$s2 = "Try running as administrator; " wide
		$s3 = ", shellcode size: " wide
		$s4 = "input file path cannot be empty." wide

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 50KB and ( 1 of ( $x* ) or all of ( $s* ) )
}

rule SIGNATURE_BASE_MAL_Malware_Imphash_Mar23_1 : HIGHVOL FILE
{
	meta:
		description = "Detects malware by known bad imphash or rich_pe_header_hash"
		author = "Arnim Rupp"
		id = "fb398c26-e9ac-55f9-b605-6b763021e96a"
		date = "2023-03-20"
		modified = "2023-03-22"
		reference = "https://yaraify.abuse.ch/statistics/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_imphash_detection.yar#L4-L90"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "167dde6bd578cbfcc587d5853e7fc2904cda10e737ca74b31df52ba24db6e7bc"
		hash = "0a25a78c6b9df52e55455f5d52bcb3816460001cae3307b05e76ac70193b0636"
		hash = "d87a35decd0b81382e0c98f83c7f4bf25a2b25baac90c9dcff5b5a147e33bcc8"
		hash = "5783bf969c36f13f4365f4cae3ec4ee5d95694ff181aba74a33f4959f1f19e8b"
		hash = "4ca925b0feec851d787e7ee42d263f4c08b0f73f496049bdb5d967728ff91073"
		hash = "9c2d2fa9c32fdff1828854e8cc39160dae73a4f90fb89b82ef6d853b63035663"
		hash = "2c53d58f30b2ee1a2a7746e20f136c34d25d0214261783fc67e119329d457c2a"
		hash = "5e83747015b0589b4f04b0db981794adf53274076c1b4acf717e3ff45eca0249"
		hash = "ceaa0af90222ff3a899b9a360f6328cbda9ec0f5fbd18eb44bdc440470bb0247"
		hash = "82fb1ba998dfee806a513f125bb64c316989c36c805575914186a6b45da3b132"
		hash = "cb41d2520995abd9ba8ccd42e53d496a66da392007ea6aebd4cbc43f71ad461a"
		hash = "c7bd758506b72ee6db1cc2557baf745bf9e402127d8e49266cc91c90f3cf3ed5"
		hash = "e6e0d60f65a4ea6895ff97df340f6d90942bbfa402c01bf443ff5b4641ff849f"
		hash = "e8ddef9fa689e98ba2d48260aea3eb8fa41922ed718b7b9135df6426b3ddf126"
		hash = "ad57d77aba6f1bf82e0affe4c0ae95964be45fb3b7c2d6a0e08728e425ecd301"
		hash = "483df98eb489899bc89c6a0662ca8166c9b77af2f6bedebd17e61a69211843d9"
		hash = "a65ed85851d8751e6fe6a27ece7b3879b90866a10f272d8af46fb394b46b90a9"
		hash = "09081e04f3228d6ef2efc1108850958ed86026e4dfda199852046481f4711565"
		hash = "1b2c9054f44f7d08cffe7e2d9127dbd96206ab2c15b63ebf6120184950336ae1"
		hash = "257887d1c84eb15abb2c3c0d7eb9b753ca961d905f4979a10a094d0737d97138"
		hash = "1cbad8b58dbd1176e492e11f16954c3c254b5169dde52b5ad6d0d3c51930abf8"
		hash = "a9897fd2d5401071a8219b05a3e9b74b64ad67ab75044b3e41818e6305a8d7b9"
		hash = "aeac45fbc5d2a59c9669b9664400aeaf6699d76a57126d2f437833a3437a693e"
		hash = "7b4c4d4676fab6c009a40d370e6cb53ea4fd73b09c23426fbaccc66d652f2a00"
		hash = "b07f6873726276842686a6a6845b361068c3f5ce086811db05c1dc2250009cd0"
		hash = "d1b3afebcacf9dd87034f83d209b42b0d79e66e08c0a897942fbe5fbd6704a0e"
		hash = "074d52be060751cf213f6d0ead8e9ab1e63f055ae79b5fcbe4dd18469deea12b"
		hash = "84d1fdef484fa9f637ae3d6820c996f6c5cf455470e8717ad348a3d80d2fb8e0"
		hash = "437da123e80cfd10be5f08123cd63cfc0dc561e17b0bef861634d60c8a134eda"
		hash = "f76c36eb22777473b88c6a5fc150fd9d6b5fac5b2db093f0ccd101614c46c7e7"
		hash = "5498b7995669877a410e1c2b68575ca94e79014075ef5f89f0f1840c70ebf942"
		hash = "af4e633acfba903e7c92342b114c4af4e694c5cfaea3d9ea468a4d322b60aa85"
		hash = "d7d870f5afab8d4afa083ea7d7ce6407f88b0f08ca166df1a1d9bdc1a46a41b3"
		hash = "974209d88747fbba77069bb9afa9e8c09ee37ae233d94c82999d88dfcd297117"
		hash = "f2d99e7d3c59adf52afe0302b298c7d8ea023e9338c2870f74f11eaa0a332fc4"
		hash = "b32c93be9320146fc614fafd5e6f1bb8468be83628118a67eb01c878f941ee5d"
		hash = "bbd99acc750e6457e89acbc5da8b2a63b4ef01d4597d160e9cde5dc8bd04cf74"
		hash = "dbff5ca3d1e18902317ab9c50be4e172640a8141e09ec13dcca986f2ec1dc395"
		hash = "3ee1741a649f0b97bbeb05b6f9df97afda22c82e1e870177d8bdd34141ef163c"
		hash = "222096fc800c8ea2b0e530302306898b691858324dbe5b8357f90407e9665b85"
		hash = "b9995d1987c4e8b6fb30d255948322cfad9cc212c7f8f4c5db3ac80e23071533"
		hash = "a6a92ea0f27da1e678c15beb263647de43f68608afe82d6847450f16a11fe6c0"
		hash = "866e3ea86671a62b677214f07890ddf7e8153bec56455ad083c800e6ab51be37"
		logic_hash = "dcb4d9a1ca83bbd26178895f20f9ab443f48f42aa3ad3df042c763c24ce8c047"
		score = 75
		quality = 85
		tags = "HIGHVOL, FILE"
		license = "Detection Rule License 1.1 https://github.com/SigmaHQ/Detection-Rule-License"

	strings:
		$fp1 = "Win32 Cabinet Self-Extractor" wide
		$fp2 = "EXTRACTOPT" ascii fullword

	condition:
		uint16( 0 ) == 0x5A4D and ( pe.imphash ( ) == "9ee34731129f4801db97fd66adbfeaa0" or pe.imphash ( ) == "f9e8597c55008e10a8cdc8a0764d5341" or pe.imphash ( ) == "0a76016a514d8ed3124268734a31e2d2" or pe.imphash ( ) == "d3cbd6e8f81da85f6bf0529e69de9251" or pe.imphash ( ) == "d8b32e731e5438c6329455786e51ab4b" or pe.imphash ( ) == "cdf5bbb8693f29ef22aef04d2a161dd7" or pe.imphash ( ) == "890e522b31701e079a367b89393329e6" or pe.imphash ( ) == "bf5a4aa99e5b160f8521cadd6bfe73b8" or pe.imphash ( ) == "646167cce332c1c252cdcb1839e0cf48" or pe.imphash ( ) == "9f4693fc0c511135129493f2161d1e86" or pe.imphash ( ) == "b4c6fff030479aa3b12625be67bf4914" ) and not 1 of ( $fp* )
}

rule SIGNATURE_BASE_HKTL_Imphashes_Aug22_1 : FILE
{
	meta:
		description = "Detects different hacktools based on their imphash"
		author = "Florian Roth"
		id = "e1d4dde6-16ad-5495-b3a7-01a86c830761"
		date = "2022-08-17"
		modified = "2023-03-21"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_imphash_detection.yar#L93-L192"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e76701b889138f9635cfe3a2f08710db3a6f0a3c3a15faa705ff0904d0566a1f"
		score = 80
		quality = 85
		tags = "FILE"

	condition:
		uint16( 0 ) == 0x5a4d and ( pe.imphash ( ) == "bcca3c247b619dcd13c8cdff5f123932" or pe.imphash ( ) == "3a19059bd7688cb88e70005f18efc439" or pe.imphash ( ) == "bf6223a49e45d99094406777eb6004ba" or pe.imphash ( ) == "0c106686a31bfe2ba931ae1cf6e9dbc6" or pe.imphash ( ) == "0d1447d4b3259b3c2a1d4cfb7ece13c3" or pe.imphash ( ) == "1b0369a1e06271833f78ffa70ffb4eaf" or pe.imphash ( ) == "4c1b52a19748428e51b14c278d0f58e3" or pe.imphash ( ) == "4d927a711f77d62cebd4f322cb57ec6f" or pe.imphash ( ) == "66ee036df5fc1004d9ed5e9a94a1086a" or pe.imphash ( ) == "672b13f4a0b6f27d29065123fe882dfc" or pe.imphash ( ) == "6bbd59cea665c4afcc2814c1327ec91f" or pe.imphash ( ) == "725bb81dc24214f6ecacc0cfb36ad30d" or pe.imphash ( ) == "9528a0e91e28fbb88ad433feabca2456" or pe.imphash ( ) == "9da6d5d77be11712527dcab86df449a3" or pe.imphash ( ) == "a6e01bc1ab89f8d91d9eab72032aae88" or pe.imphash ( ) == "b24c5eddaea4fe50c6a96a2a133521e4" or pe.imphash ( ) == "d21bbc50dcc169d7b4d0f01962793154" or pe.imphash ( ) == "fcc251cceae90d22c392215cc9a2d5d6" or pe.imphash ( ) == "23867a89c2b8fc733be6cf5ef902f2d1" or pe.imphash ( ) == "a37ff327f8d48e8a4d2f757e1b6e70bc" or pe.imphash ( ) == "f9a28c458284584a93b14216308d31bd" or pe.imphash ( ) == "6118619783fc175bc7ebecff0769b46e" or pe.imphash ( ) == "959a83047e80ab68b368fdb3f4c6e4ea" or pe.imphash ( ) == "563233bfa169acc7892451f71ad5850a" or pe.imphash ( ) == "87575cb7a0e0700eb37f2e3668671a08" or pe.imphash ( ) == "13f08707f759af6003837a150a371ba1" or pe.imphash ( ) == "1781f06048a7e58b323f0b9259be798b" or pe.imphash ( ) == "233f85f2d4bc9d6521a6caae11a1e7f5" or pe.imphash ( ) == "24af2584cbf4d60bbe5c6d1b31b3be6d" or pe.imphash ( ) == "632969ddf6dbf4e0f53424b75e4b91f2" or pe.imphash ( ) == "713c29b396b907ed71a72482759ed757" or pe.imphash ( ) == "749a7bb1f0b4c4455949c0b2bf7f9e9f" or pe.imphash ( ) == "8628b2608957a6b0c6330ac3de28ce2e" or pe.imphash ( ) == "8b114550386e31895dfab371e741123d" or pe.imphash ( ) == "94cb940a1a6b65bed4d5a8f849ce9793" or pe.imphash ( ) == "9d68781980370e00e0bd939ee5e6c141" or pe.imphash ( ) == "b18a1401ff8f444056d29450fbc0a6ce" or pe.imphash ( ) == "cb567f9498452721d77a451374955f5f" or pe.imphash ( ) == "730073214094cd328547bf1f72289752" or pe.imphash ( ) == "17b461a082950fc6332228572138b80c" or pe.imphash ( ) == "dc25ee78e2ef4d36faa0badf1e7461c9" or pe.imphash ( ) == "819b19d53ca6736448f9325a85736792" or pe.imphash ( ) == "829da329ce140d873b4a8bde2cbfaa7e" or pe.imphash ( ) == "c547f2e66061a8dffb6f5a3ff63c0a74" or pe.imphash ( ) == "0588081ab0e63ba785938467e1b10cca" or pe.imphash ( ) == "0d9ec08bac6c07d9987dfd0f1506587c" or pe.imphash ( ) == "bc129092b71c89b4d4c8cdf8ea590b29" or pe.imphash ( ) == "4da924cf622d039d58bce71cdf05d242" or pe.imphash ( ) == "e7a3a5c377e2d29324093377d7db1c66" or pe.imphash ( ) == "9a9dbec5c62f0380b4fa5fd31deffedf" or pe.imphash ( ) == "af8a3976ad71e5d5fdfb67ddb8dadfce" or pe.imphash ( ) == "0c477898bbf137bbd6f2a54e3b805ff4" or pe.imphash ( ) == "0ca9f02b537bcea20d4ea5eb1a9fe338" or pe.imphash ( ) == "3ab3655e5a14d4eefc547f4781bf7f9e" or pe.imphash ( ) == "e6f9d5152da699934b30daab206471f6" or pe.imphash ( ) == "3ad59991ccf1d67339b319b15a41b35d" or pe.imphash ( ) == "ffdd59e0318b85a3e480874d9796d872" or pe.imphash ( ) == "0cf479628d7cc1ea25ec7998a92f5051" or pe.imphash ( ) == "07a2d4dcbd6cb2c6a45e6b101f0b6d51" or pe.imphash ( ) == "d6d0f80386e1380d05cb78e871bc72b1" or pe.imphash ( ) == "38d9e015591bbfd4929e0d0f47fa0055" or pe.imphash ( ) == "0e2216679ca6e1094d63322e3412d650" or pe.imphash ( ) == "ada161bf41b8e5e9132858cb54cab5fb" or pe.imphash ( ) == "2a1bc4913cd5ecb0434df07cb675b798" or pe.imphash ( ) == "11083e75553baae21dc89ce8f9a195e4" or pe.imphash ( ) == "a23d29c9e566f2fa8ffbb79267f5df80" or pe.imphash ( ) == "4a07f944a83e8a7c2525efa35dd30e2f" or pe.imphash ( ) == "767637c23bb42cd5d7397cf58b0be688" or pe.imphash ( ) == "14c4e4c72ba075e9069ee67f39188ad8" or pe.imphash ( ) == "3c782813d4afce07bbfc5a9772acdbdc" or pe.imphash ( ) == "7d010c6bb6a3726f327f7e239166d127" or pe.imphash ( ) == "89159ba4dd04e4ce5559f132a9964eb3" or pe.imphash ( ) == "6f33f4a5fc42b8cec7314947bd13f30f" or pe.imphash ( ) == "5834ed4291bdeb928270428ebbaf7604" or pe.imphash ( ) == "5a8a8a43f25485e7ee1b201edcbc7a38" or pe.imphash ( ) == "dc7d30b90b2d8abf664fbed2b1b59894" or pe.imphash ( ) == "41923ea1f824fe63ea5beb84db7a3e74" or pe.imphash ( ) == "3de09703c8e79ed2ca3f01074719906b" or pe.imphash ( ) == "a53a02b997935fd8eedcb5f7abab9b9f" or pe.imphash ( ) == "e96a73c7bf33a464c510ede582318bf2" or pe.imphash ( ) == "32089b8851bbf8bc2d014e9f37288c83" or pe.imphash ( ) == "09D278F9DE118EF09163C6140255C690" or pe.imphash ( ) == "03866661686829d806989e2fc5a72606" or pe.imphash ( ) == "e57401fbdadcd4571ff385ab82bd5d6d" or pe.imphash ( ) == "84B763C45C0E4A3E7CA5548C710DB4EE" or pe.imphash ( ) == "19584675d94829987952432e018d5056" or pe.imphash ( ) == "330768a4f172e10acb6287b87289d83b" )
}

rule SIGNATURE_BASE_SUSP_Imphash_Mar23_2 : HIGHVOL FILE
{
	meta:
		description = "Detects imphash often found in malware samples (Zero hits with with search for 'imphash:x p:0' on Virustotal)"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "b739d540-5d9f-53b3-9e42-a514dc972e8d"
		date = "2023-03-23"
		modified = "2023-11-25"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_imphash_detection.yar#L194-L295"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "12bf2795f4a140adbaa0af6ad4b2508d398d8ba69e9dadb155f800b10f7458c4"
		hash = "14ec56489fbcc3c7f1ef9a4d4a80ff302a5e233cdc4429a29c635a88fb1278d6"
		hash = "13731912823d6ce01c28a8d7d7f961505f461620bb35adbb409d4954ba1f4b8e"
		hash = "15e59cc5d7b83e63d40dbfd8406701cb4decd31353f68fda47238d073c87e4ea"
		hash = "13e5bb40be20b1a0bc28081ce7798f339c28c9652cb37b538c29872dfd0cd51d"
		hash = "16f963afdb30b38ba4b8b98ce56a37626e9fd87de9eba5f9903d2ba7f8a77788"
		hash = "168f22d02304ce66be88d2370c8fa7c7d9aa2ccf80f8e376edfeabfc9b96c73d"
		hash = "9e7701450dbcbd35083e34df935bd77a95735c4b441e0fc8eacd543a621f2fa5"
		hash = "51205c100702b21cce600692d69f3b108f49228e53f36678dd8b39434406526b"
		hash = "c9b48e8b0e7c6fa75886554659bc0529e454d84b29daa07bd4323aca9a33f607"
		hash = "ba5c06703bd3c093afa89e45d86aaf6c151fbaef44ebf3b65c97f3b376a88c72"
		hash = "7281afc138e8e898aee16d415cd02a29dc5dedda5b11c23934aac0ebd208373b"
		hash = "10a091b2468a8286f7b1a580d8923aef48856b43014e849035f05c4dbdc0a413"
		hash = "56c04e76427bd982be83799d0a435732193d7bf5a70cdeba5eb63eaf0d4ebb77"
		hash = "0aa8b7eddc4792a82f247702442c04e50173bd7712a4b596545916480942853b"
		hash = "627f043ad875c182682149653363b7f856dd618d169821b18df7bc9cdf6269d8"
		hash = "e1df460fd99c4f901859f3a8ec23b041ba9f4b79897dec349a96d6a27fb3e335"
		hash = "f10ecbd8031ce85b782c59682ff32301a65e0975687977688771f1057fb063d1"
		hash = "1bc7b8932b5b077b359c79e7ca664938b7a487a4e7e6b99d6647d6803bc677c5"
		hash = "01f81029a5e93cbfecfbc81cbd4a2ffd1bb1b6159e2a144a21e58caf8dab9661"
		hash = "cd33a71f71e2971667bacb0da71f2d36073777993b9581ec90bbf042162c3530"
		hash = "4aab991149cb2dc8c0c0a323af3acbbd73d6a22177910ef3af92b05ae7c9ae7b"
		hash = "df05fa3983c9e623388231d366dba4e435575ca53421d3f0bcb0fb346dd971d4"
		hash = "14de3584fe7108386f7637c2bd343f30341c0fa2102d52bb35ee772b5b7672f0"
		hash = "c4d9ad5cffd9aa13dfe3acbf0905810e28ff96d231541d7e209327ca5b0b24fe"
		hash = "5e0bed2269dc34c6cc2db30b0a53282e6debb85b3c90a857d1be4cfd06312211"
		hash = "3aa13e72382a2d7da592273b8c18a42106b65db528e16b6066646812e81555c4"
		hash = "244c4a930e3644ffb96bf3ab33e8c8c0f94ed9fe6a8b2fc45fc8e9b6471ef3a8"
		hash = "f00848b8edeeb5a668bf7e89e3f33f438b2f5d5cf130596a8ed2531e21be6d81"
		hash = "5b9348c24ff604e78d70464654e645b90dc695c7e0415959c443fe29cebc3c4e"
		logic_hash = "c6482cbc01a880ffd3056d28a2fde8f87402b1f85d36075c1f0b50788d469ca3"
		score = 65
		quality = 85
		tags = "HIGHVOL, FILE"
		license = "Detection Rule License 1.1 https://github.com/SigmaHQ/Detection-Rule-License"

	condition:
		uint16( 0 ) == 0x5A4D and ( pe.imphash ( ) == "e4290fa6afc89d56616f34ebbd0b1f2c" or pe.imphash ( ) == "8abecba2211e61763c4c9ffcaa13369e" or pe.imphash ( ) == "a64e048b98d051ae6e6b6334f77c95d3" or pe.imphash ( ) == "359d89624a26d1e756c3e9d6782d6eb0" or pe.imphash ( ) == "c2a87fabf96470db507b2e6b43bd92eb" or pe.imphash ( ) == "62ec3dce1eba1b68f6a4511bb09f8c2c" or pe.imphash ( ) == "5662cfcdfd9da29cb429e7528d5af81e" or pe.imphash ( ) == "406c785a6e2c6970c1e8ed62877e197b" or pe.imphash ( ) == "dbf687d6aa2a6cafe4349f7b0821a792" or pe.imphash ( ) == "6dca3e9fb3928bbdb54dbce669943ec8" or pe.imphash ( ) == "f1a539a5b71ad53ac586f053145f08ec" or pe.imphash ( ) == "3a2003ea545fe942681da9e7683ebb58" or pe.imphash ( ) == "a8286b574ff850cd002ea6282d15aa40" or pe.imphash ( ) == "3c8577ca4bab2f95cc6fc73ef1895288" or pe.imphash ( ) == "84706849fa809feaa385711a628be029" or pe.imphash ( ) == "ba23a556ac1d6444f7f76feafd6c8867" or pe.imphash ( ) == "95e6f8741083e0c7d9a63d45e2472360" or pe.imphash ( ) == "774d797db707398fd2ef1979d02634d5" or pe.imphash ( ) == "8c16c795b57934183422be5f6df7d891" or pe.imphash ( ) == "98f67c550a7da65513e63ffd998f6b2e" or pe.imphash ( ) == "e836076a09dba03e4d6faa46dda0fefc" or pe.imphash ( ) == "ff63dc9c65eb25911a9bc535c8f06ad0" or pe.imphash ( ) == "08b67a9663d3a8c9505f3b2561bbdd1c" or pe.imphash ( ) == "135e92fc9902f3140f2e5a51458efdf0" or pe.imphash ( ) == "4753904c40d638a1bc745c65b88291d5" or pe.imphash ( ) == "0f44bf2b3b0b8d5ecae5689ff1d0e90d" or pe.imphash ( ) == "c4c9ecfc26ca516a80b8f6f5b2bdb7e6" or pe.imphash ( ) == "46ad3d954e527f769e37017b3e128039" or pe.imphash ( ) == "802dcac7aab948c19738ba3df9f356d9" or pe.imphash ( ) == "b36a21279375c40e6f4c1ea347f906de" or pe.imphash ( ) == "77a185e903c5527243ef219b003bfd38" or pe.imphash ( ) == "12a30b523ac71a3cbe9145c89400dd7f" or pe.imphash ( ) == "cc40fefa3af5cd00cc28dbd874038a4d" or pe.imphash ( ) == "3d8c26f4cb1782a87c3bb42796fb6b85" or pe.imphash ( ) == "2f4ddcfebbcad3bacadc879747151f6f" or pe.imphash ( ) == "76812f441b0ed9d3cc0748af25d689a3" or pe.imphash ( ) == "9a06f0024c1694774ae97311608bab5b" or pe.imphash ( ) == "481f47bbb2c9c21e108d65f52b04c448" or pe.imphash ( ) == "286870a926664a5129b8b68ed0d4a8eb" or pe.imphash ( ) == "a0db151d55761167d93eba72d3d94b32" or pe.imphash ( ) == "663243fe4d94e1304b265ce4011cd01b" or pe.imphash ( ) == "f24e64014af9015dc25262e5076fe61f" or pe.imphash ( ) == "b7d08302c927428e16a2ad8d18b9d2b7" or pe.imphash ( ) == "352063077f27a851dc2b08e15f08105e" or pe.imphash ( ) == "b0b97d1a91a2730b3daa8bbb2e86b402" or pe.imphash ( ) == "bc96f1c981700752dc2cf9553da99eb6" or pe.imphash ( ) == "f68ddef5f29b66bbd543e947c8743bb0" or pe.imphash ( ) == "6dfbc160505aa2f7205766eaa6fe72a1" or pe.imphash ( ) == "a202429ffe8d8c8b722572cffd5681a7" or pe.imphash ( ) == "342a3708d93b6b819b7b1a768201a747" or pe.imphash ( ) == "cdc00badc7162acde9bb032e793ac137" or pe.imphash ( ) == "be19e18d6a8b41631d40059031a928bb" or pe.imphash ( ) == "0c54f96a844b02689687407de9b6663e" or pe.imphash ( ) == "fa5f28e70130a452b7c0a51db5544ef9" or pe.imphash ( ) == "2e5708ae5fed0403e8117c645fb23e5b" or pe.imphash ( ) == "8d92fa1956a6a631c642190121740197" or pe.imphash ( ) == "dc73a9bd8de0fd640549c85ac4089b87" )
}
rule SIGNATURE_BASE_EXPL_Cleo_Exploitation_Log_Indicators_Dec24 : SCRIPT
{
	meta:
		description = "Detects indicators found in logs during and after Cleo software exploitation (as reported by Huntress in December 2024)"
		author = "Florian Roth"
		id = "385042a9-fc8c-5b50-975f-3436a16e6861"
		date = "2024-12-10"
		modified = "2024-12-12"
		reference = "https://www.huntress.com/blog/threat-advisory-oh-no-cleo-cleo-software-actively-being-exploited-in-the-wild"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cleo_dec24.yar#L2-L16"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a7e6713a08d7cce00cffba8daa12b251ccc12dc8d5a5f38d568bd5054e3783a2"
		score = 75
		quality = 85
		tags = "SCRIPT"

	strings:
		$x1 = "Note: Processing autorun file 'autorun\\health" ascii wide
		$x2 = "60282967-dc91-40ef-a34c-38e992509c2c.xml" ascii wide
		$x3 = "<Detail level=\"1\">Executing 'cmd.exe /c \"powershell -NonInteractive -EncodedCommand " ascii wide

	condition:
		1 of them
}
rule SIGNATURE_BASE_SUSP_EXPL_Cleo_Exploitation_Log_Indicators_Dec24_1 : FILE
{
	meta:
		description = "Detects indicators found in logs during and after Cleo software exploitation (as reported by Huntress in December 2024)"
		author = "X__Junior"
		id = "81daf184-4c38-5d84-899b-9d0de2f39934"
		date = "2024-12-10"
		modified = "2024-12-12"
		reference = "https://www.huntress.com/blog/threat-advisory-oh-no-cleo-cleo-software-actively-being-exploited-in-the-wild"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cleo_dec24.yar#L18-L52"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "786951478a0fc5db24f6e1d8dcc5eaa8880dbd928da97828a61f1f1f0f21e21d"
		logic_hash = "481ddd570d0292036b421223ce0f839ece86cc1a97aa226a8b9fbd1d63905d1b"
		score = 75
		quality = 83
		tags = "FILE"

	strings:
		$sa1 = "<Thread type=\"AutoRun\" action=" ascii
		$sa2 = "<Mark date=" ascii
		$sa3 = "<Event>" ascii
		$sa4 = "<Command text" ascii
		$sb1 = "[System.Net.WebRequest]::create" ascii
		$sb2 = "Invoke-RestMethod" ascii
		$sb3 = "Invoke-WebRequest" ascii
		$sb4 = "iwr " ascii
		$sb5 = "Net.WebClient" ascii
		$sb6 = "Resume-BitsTransfer" ascii
		$sb7 = "Start-BitsTransfer" ascii
		$sb8 = "wget " ascii
		$sb9 = "WinHttp.WinHttpRequest" ascii
		$sb10 = ".DownloadFile(" ascii
		$sb11 = ".DownloadString(" ascii
		$sb12 = "Bypass" nocase ascii
		$sb13 = "-EncodedCommand" ascii
		$sb14 = "-windowstyle hidden" ascii
		$sb15 = " -enc " ascii

	condition:
		filesize < 1MB and all of ( $sa* ) and 1 of ( $sb* )
}
rule SIGNATURE_BASE_SUSP_EXPL_Cleo_Exploitation_Log_Indicators_Dec24_2 : FILE
{
	meta:
		description = "Detects indicators found in logs during and after Cleo software exploitation (as reported by Huntress in December 2024)"
		author = "X__Junior"
		id = "d215d4a0-1726-58d4-90df-8ec6102effe1"
		date = "2024-12-10"
		modified = "2024-12-12"
		reference = "https://www.huntress.com/blog/threat-advisory-oh-no-cleo-cleo-software-actively-being-exploited-in-the-wild"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cleo_dec24.yar#L54-L89"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8debaf2c85ea63501b7a3c2ff8af7a8484f4d6097e073645d808cbd50ef1511a"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$sa1 = "<Thread type=\"AutoRun\" action=" ascii
		$sa2 = "<Mark date=" ascii
		$sa3 = "<Event>" ascii
		$sa4 = "<Command text" ascii
		$sb1 = "wscript" ascii
		$sb2 = "cscript" ascii
		$sb3 = "mshta" ascii
		$sb4 = "certutil" ascii
		$sb5 = "pwsh" ascii
		$sb6 = "curl" ascii
		$sb7 = "msiexec" ascii
		$sb8 = "taskkill" ascii
		$sb9 = "regsvr32" ascii
		$sb10 = "rundll32" ascii
		$sb11 = "bitsadmin" ascii
		$sb12 = "whoami" ascii
		$sb13 = "bcdedit" ascii
		$sb14 = "systeminfo" ascii
		$sb15 = "reg " ascii
		$sb16 = "schtasks" ascii

	condition:
		filesize < 1MB and all of ( $sa* ) and 1 of ( $sb* )
}
rule SIGNATURE_BASE_EXPL_Cleo_Exploitation_XML_Indicators_Dec24 : FILE
{
	meta:
		description = "Detects XML used during and after Cleo software exploitation (as reported by Huntress in December 2024)"
		author = "Florian Roth"
		id = "622633af-aa7a-5bf9-a59c-6590535d86a4"
		date = "2024-12-10"
		modified = "2024-12-12"
		reference = "https://www.huntress.com/blog/threat-advisory-oh-no-cleo-cleo-software-actively-being-exploited-in-the-wild"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cleo_dec24.yar#L91-L109"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "21c11c3e0c0ffea89e24b9c002b6112a46b4dc7c2c4f1f5dc9803758a68efc36"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "<Host alias=\"60282967-dc91-40ef-a34c-38e992509c2c\" application=\"\" " ascii
		$s1 = "<Commands>SYSTEM cmd.exe /c " ascii
		$a1 = "<Action actiontype=\"Commands\" " ascii

	condition:
		filesize < 50KB and ( 1 of ( $x* ) or 2 of them )
}
rule SIGNATURE_BASE_SUSP_EXPL_Cleo_Exploitation_XML_Indicators_Dec24_1 : FILE
{
	meta:
		description = "Detects XML used during and after Cleo software exploitation (as reported by Huntress in December 2024)"
		author = "X__Junior"
		id = "b30ca09f-b84c-5de8-9bf7-9f3269f32c1f"
		date = "2024-12-10"
		modified = "2024-12-12"
		reference = "https://www.huntress.com/blog/threat-advisory-oh-no-cleo-cleo-software-actively-being-exploited-in-the-wild"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cleo_dec24.yar#L112-L146"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "b103f708e85416fc6d7af9605da4b57b3abe42fb9c6c9ec0f539b4c877580bd2"
		logic_hash = "c9be15aec57fdde62815ee04daa5616940ab7949784d382a4825dce9f1e28568"
		score = 70
		quality = 83
		tags = "FILE"

	strings:
		$sa1 = "<Action actiontype=\"Commands\"" ascii
		$sa2 = "<?xml version=" ascii
		$sa3 = "<Runninglocalrequired>" ascii
		$sa4 = "<Autostartup>" ascii
		$sb1 = "[System.Net.WebRequest]::create" ascii
		$sb2 = "Invoke-RestMethod" ascii
		$sb3 = "Invoke-WebRequest" ascii
		$sb4 = "iwr " ascii
		$sb5 = "Net.WebClient" ascii
		$sb6 = "Resume-BitsTransfer" ascii
		$sb7 = "Start-BitsTransfer" ascii
		$sb8 = "wget " ascii
		$sb9 = "WinHttp.WinHttpRequest" ascii
		$sb10 = ".DownloadFile(" ascii
		$sb11 = ".DownloadString(" ascii
		$sb12 = "Bypass" nocase ascii
		$sb13 = "-EncodedCommand" ascii
		$sb14 = "-windowstyle hidden" ascii
		$sb15 = " -enc " ascii

	condition:
		filesize < 10KB and all of ( $sa* ) and 1 of ( $sb* )
}
rule SIGNATURE_BASE_SUSP_EXPL_Cleo_Exploitation_XML_Indicators_Dec24_2 : FILE
{
	meta:
		description = "Detects XML used during and after Cleo software exploitation (as reported by Huntress in December 2024)"
		author = "X__Junior"
		id = "a71c71f3-d36f-5c27-b150-e678bccf2dba"
		date = "2024-12-10"
		modified = "2024-12-12"
		reference = "https://www.huntress.com/blog/threat-advisory-oh-no-cleo-cleo-software-actively-being-exploited-in-the-wild"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cleo_dec24.yar#L148-L183"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "60e53c8d99fde8c48bff67408605aa69c3c1fe3040ba4f9d2080980df970aa93"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$sa1 = "<Action actiontype=\"Commands\"" ascii
		$sa2 = "<?xml version=" ascii
		$sa3 = "<Runninglocalrequired>" ascii
		$sa4 = "<Autostartup>" ascii
		$sb1 = "wscript" ascii
		$sb2 = "cscript" ascii
		$sb3 = "mshta" ascii
		$sb4 = "certutil" ascii
		$sb5 = "pwsh" ascii
		$sb6 = "curl" ascii
		$sb7 = "msiexec" ascii
		$sb8 = "taskkill" ascii
		$sb9 = "regsvr32" ascii
		$sb10 = "rundll32" ascii
		$sb11 = "bitsadmin" ascii
		$sb12 = "whoami" ascii
		$sb13 = "bcdedit" ascii
		$sb14 = "systeminfo" ascii
		$sb15 = "reg " ascii
		$sb16 = "schtasks" ascii

	condition:
		filesize < 10KB and all of ( $sa* ) and 1 of ( $sb* )
}
rule SIGNATURE_BASE_EXPL_Cleo_Exploitation_PS1_Indicators_Dec24 : SCRIPT
{
	meta:
		description = "Detects encoded and decoded PowerShell loader used during Cleo software exploitation (as reported by Huntress in December 2024)"
		author = "Florian Roth"
		id = "491cda57-0ad0-5ddc-90cb-48411eef2f2e"
		date = "2024-12-10"
		modified = "2024-12-12"
		reference = "https://www.huntress.com/blog/threat-advisory-oh-no-cleo-cleo-software-actively-being-exploited-in-the-wild"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cleo_dec24.yar#L185-L202"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "87dcd0aa3c16d8948514b1d8589d38c6cc73bf7e6262f4517659cead16fedd3d"
		score = 75
		quality = 85
		tags = "SCRIPT"

	strings:
		$xe1 = "Start-Process -WindowStyle Hidden -FilePath jre\\bin\\java.exe" base64 ascii wide
		$xe2 = "$f=\"cleo." base64 ascii wide
		$xe3 = "<Detail level=\"1\">Executing 'cmd.exe /c \"powershell -NonInteractive -EncodedCommand " base64 ascii wide
		$x1 = "$f=\"cleo." ascii wide
		$x2 = "<Detail level=\"1\">Executing 'cmd.exe /c \"powershell -NonInteractive -EncodedCommand " ascii wide

	condition:
		1 of them
}
rule SIGNATURE_BASE_SUSP_EXPL_JAR_Indicators_Dec24 : FILE
{
	meta:
		description = "Detects characteristics of JAR files used during Cleo software exploitation (as reported by Huntress in December 2024)"
		author = "Florian Roth"
		id = "4e8f6aa8-9efd-5fcf-b795-5042d4ba1708"
		date = "2024-12-10"
		modified = "2024-12-12"
		reference = "https://www.huntress.com/blog/threat-advisory-oh-no-cleo-cleo-software-actively-being-exploited-in-the-wild"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cleo_dec24.yar#L204-L222"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8b87e7000ab5d9759f55660a085bf0f3dddb46ad1ea411cbbabce1000105ee9e"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "TLS v3 " ascii
		$s2 = "java/util/Base64$Decoder" ascii
		$s3 = "AES/CBC/NoPadding" ascii
		$s4 = "getenv" ascii
		$s5 = "ava/util/zip/ZipInputStream" ascii

	condition:
		uint16( 0 ) == 0xfeca and filesize < 20KB and all of them
}
rule SIGNATURE_BASE_EXPL_Cleo_Exploitation_JAVA_Payloads_Dec24_1_1 : FILE
{
	meta:
		description = "Detects characteristics of JAVA files used during Cleo software exploitation (as reported by Huntress in December 2024) - files Cli, ScSlot, Slot, SrvSlot"
		author = "Florian Roth"
		id = "2940ddad-3dba-594a-9111-e4741d6ff39b"
		date = "2024-12-10"
		modified = "2024-12-12"
		reference = "https://www.huntress.com/blog/threat-advisory-oh-no-cleo-cleo-software-actively-being-exploited-in-the-wild"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cleo_dec24.yar#L224-L245"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0c57b317b572d071afd8ccdb844dd6f117e20f818c6031d7ba8adcbd32be0617"
		logic_hash = "85600e9310e502b3b2135f2f3cf698ae54fe362047cdf9d378dcc107e0c2fa18"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "java/lang/StringBuffer"
		$x1 = "Start-Sleep 3;del " ascii
		$x2 = "sleep 3;rm -f '" ascii
		$x3 = "powershell -Noninteractive -EncodedCommand " ascii
		$x4 = "runDelFileCmd" ascii fullword

	condition:
		uint16( 0 ) == 0xfeca and filesize < 50KB and $a1 and 1 of ( $x* )
}
rule SIGNATURE_BASE_EXPL_Cleo_Exploitation_JAVA_Payloads_Dec24_2 : FILE
{
	meta:
		description = "Detects characteristics of JAVA files used during Cleo software exploitation (as reported by Huntress in December 2024) - file Proc"
		author = "Florian Roth"
		id = "bd575454-7fd0-566d-94e5-ec1368675108"
		date = "2024-12-10"
		modified = "2024-12-12"
		reference = "https://www.huntress.com/blog/threat-advisory-oh-no-cleo-cleo-software-actively-being-exploited-in-the-wild"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cleo_dec24.yar#L247-L265"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "1ba95af21bac45db43ebf02f87ecedde802c7de4d472f33e74ee0a5b5015a726"
		logic_hash = "2bb5eace09b832bf3ce296484f473c9c56f97b881ea17838408be6000cc6fcb1"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Timeout getting pipe-data" ascii fullword
		$s2 = "Ftprootpath" ascii fullword
		$s3 = "Rest cmd=" ascii fullword
		$s4 = "writeToProc" ascii fullword

	condition:
		uint16( 0 ) == 0xfeca and filesize < 30KB and 3 of them
}
rule SIGNATURE_BASE_EXPL_Cleo_Exploitation_JAVA_Payloads_Dec24_3 : FILE
{
	meta:
		description = "Detects characteristics of JAR files used during Cleo software exploitation"
		author = "X__Junior"
		id = "5c227bb9-0731-5955-a758-6fe86ecc2d86"
		date = "2024-12-10"
		modified = "2024-12-12"
		reference = "https://www.huntress.com/blog/threat-advisory-oh-no-cleo-cleo-software-actively-being-exploited-in-the-wild"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cleo_dec24.yar#L267-L286"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "64a6194110d4eb359cc3f15137cf752d598f2f0a52ac181fcaa358bf40072f54"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "java/lang/String" ascii
		$s1 = "#lsz#" ascii
		$s2 = "#dbg#" ascii
		$s3 = "#ll#" ascii
		$s4 = "SvZipDataOverflow=%d OpNotConf=" ascii

	condition:
		uint16( 0 ) == 0xfeca and filesize < 20KB and 3 of ( $s* ) and $a1
}

rule SIGNATURE_BASE_Brc4_Shellcode
{
	meta:
		description = "Hunts for shellcode opcode used in Badger x86/x64 till release v1.2.9"
		author = "@ninjaparanoid"
		id = "7e899d2f-332b-53f7-b9e6-cfde2bce6223"
		date = "2022-11-19"
		modified = "2023-12-05"
		reference = "https://github.com/paranoidninja/Brute-Ratel-C4-Community-Kit/blob/main/deprecated/brc4.yara"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/hktl_bruteratel_c4.yar#L263-L290"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a2816eb0316cebc96569847c17eae3bc50b988b07aa471176a09695fcefc21ec"
		score = 75
		quality = 83
		tags = ""
		version = "last version"
		arch_context = "x64"

	strings:
		$shellcode_x64_Start = { 55 50 53 51 52 56 57 41 50 41 51 41 52 41 53 41 54 41 55 41 56 41 57 }
		$shellcode_x64_End = { 5B 5E 5F 41 5C 41 5D 41 5E 41 5F 5D C3 }
		$shellcode_x64_StageEnd = { 5C 41 5F 41 5E 41 5D 41 5C 41 5B 41 5A 41 59 41 58 5F 5E 5A 59 5B 58 5D C3 }
		$funcHash1 = { 5B BC 4A 6A }
		$funcHash2 = { 5D 68 FA 3C }
		$funcHash3 = { AA FC 0D 7C }
		$funcHash4 = { 8E 4E 0E EC }
		$funcHash5 = { B8 12 DA 00 }
		$funcHash6 = { 07 C4 4C E5 }
		$funcHash7 = { BD CA 3B D3 }
		$funcHash8 = { 89 4D 39 8C }
		$hashFuncx64 = { EB 20 0F 1F 44 00 00 44 0F B6 C8 4C 89 DA 41 83 E9 20 4D 63 C1 4B 8D 04 10 49 39 CB 74 21 49 83 C3 01 41 89 C2 }
		$hashFuncx86 = { EB 07 8D 74 26 00 83 C2 01 0F B6 31 C1 C8 0D 89 F1 8D 5C 30 E0 01 F0 80 F9 61 89 D1 0F 43 C3 39 D7 75 E3 }

	condition:
		(pe.machine == pe.MACHINE_AMD64 and ( 2 of ( $shellcode* ) or all of ( $funcHash* ) and $hashFuncx64 ) ) or ( pe.machine == pe.MACHINE_I386 and ( all of ( $funcHash* ) and $hashFuncx86 ) )
}

rule SIGNATURE_BASE_Gen_Excel_Xll_Addin_Suspicious : FILE
{
	meta:
		description = "Detects suspicious XLL add-ins to Excel"
		author = "@JohnLaTwC"
		id = "013db759-ab9d-5505-933b-bda702a0941e"
		date = "2020-10-16"
		modified = "2023-12-05"
		reference = "https://gist.github.com/ryhanson/227229866af52e2d963cf941af135a52"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_excel_xll_addin_suspicious.yar#L3-L64"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0bad4e4bc5093dcfc2737c4d8be89d6f093509a7b91a1e022050cb890d90e4e0"
		hash = "133e47eedfede46d1a4529ce7f047e09521ed8c7cad2e49d3522064695bd6c43"
		hash = "1994a39d5639b4eea5c3cdf084a8eacf8610a96702e580d88a6ec18887d0ec6b"
		hash = "28f45d01e397841fcba48da1e61e4927f42ff6fe6f32595c23cf9a953cd2658a"
		hash = "54c3598cf22ad64faeb4e0f9f70e026a1ae834a8c06e5187bf289bb3ee43a8ec"
		hash = "5644a04513744edfb247d0ea83e3e2f7d616d6752cfd1af50e866bb0270131ee"
		hash = "836c0d21fc3ea3a8ce1a493097a5034d110e5c50bfd7e6c3dcb674dc7a6a19ec"
		hash = "b926f7db36bc5bae73091c783b0715d2af051de22a579548adf2498cb1a1d075"
		hash = "6ba100a5da5efea14a5ca929628b732a6e6b8ab8f78167db35343e895997ce52"
		hash = "ee603cbd6187850334ae5d8adcf029d5cde710fc966b2b7a2c95249d3b23d693"
		hash = "99195679e998407fd4d606a0d956bda99f79625b638c63f90d9d399c6f2a143e"
		hash = "99534c7086128998ae39967fe5fc6bf526cb2ba5d3b2e99dc7bd03833e4a94ae"
		logic_hash = "d8c3f00ef05b0b84e4c4d655d01eab6f6e67714619695fd1433726e5a940e530"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "CryptStringToBinaryA"
		$s2 = "NtQueueApcThread"
		$cs1 = "dsrole.dll"
		$cs2 = "user32.dll"
		$debug = "SeDebugPrivilege"

	condition:
		filesize < 1MB and uint16( 0 ) == 0x5a4d and pe.characteristics & pe.DLL and pe.exports ( "xlAutoOpen" ) and ( ( ( pe.imports ( "KERNEL32.dll" , "LookupPrivilegeValueW" ) or pe.imports ( "KERNEL32.dll" , "LookupPrivilegeValueA" ) ) and pe.imports ( "KERNEL32.dll" , "AdjustTokenPrivileges" ) and pe.imports ( "KERNEL32.dll" , "OpenProcess" ) and $debug ) or ( pe.imports ( "ADVAPI32.dll" , "CryptDecrypt" ) and pe.imports ( "ADVAPI32.dll" , "CryptImportKey" ) ) or ( pe.imports ( "DNSAPI.dll" , "DnsQuery_A" ) or pe.imports ( "DNSAPI.dll" , "DnsQuery_W" ) ) or ( ( pe.imports ( "KERNEL32.dll" , "FindResourceA" ) or pe.imports ( "KERNEL32.dll" , "FindResourceW" ) ) and pe.imports ( "KERNEL32.dll" , "LoadResource" ) and pe.imports ( "KERNEL32.dll" , "LockResource" ) and ( pe.imports ( "KERNEL32.dll" , "VirtualAlloc" ) or pe.imports ( "KERNEL32.dll" , "VirtualAllocEx" ) ) and pe.imports ( "KERNEL32.dll" , "WriteProcessMemory" ) and pe.imports ( "KERNEL32.dll" , "SetThreadContext" ) ) or ( pe.imports ( "KERNEL32.dll" , "GetThreadContext" ) and pe.imports ( "KERNEL32.dll" , "VirtualAllocEx" ) and pe.imports ( "KERNEL32.dll" , "ResumeThread" ) and pe.imports ( "KERNEL32.dll" , "SetThreadContext" ) ) or ( pe.imports ( "KERNEL32.dll" , "WinExec" ) ) or ( all of ( $s* ) ) or ( all of ( $cs* ) and pe.imports ( "KERNEL32.dll" , "VirtualAllocEx" ) and pe.imports ( "KERNEL32.dll" , "TerminateProcess" ) and pe.imports ( "KERNEL32.dll" , "Sleep" ) ) )
}
rule SIGNATURE_BASE_MAL_G_APT_Backdoor_BRICKSTORM_3 : FILE
{
	meta:
		description = "Detects BRICKSTORM backdoor used by APT group UNC5221 (China Nexus)"
		author = "Google Threat Intelligence Group (GTIG) (modified by Florian Roth)"
		id = "d50d60ec-0238-569e-911a-696b994416f9"
		date = "2025-09-25"
		modified = "2026-05-15"
		reference = "https://cloud.google.com/blog/topics/threat-intelligence/brickstorm-espionage-campaign"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_brickstorm_sep25.yar#L1-L18"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "931eacd7e5250d29903924c31f41b7e5"
		logic_hash = "168bc2bdfff6a135f4ec89f8cf79051e6dcd242b314e3238553d67929995a9ea"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$str1 = { 48 8B 05 ?? ?? ?? ?? 48 89 04 24 E8 ?? ?? ?? ?? 48 B8 ?? ?? ?? ?? ?? ?? ?? ?? 48 89 04 24 [0-5] E8 ?? ?? ?? ?? EB ?? }
		$str4 = "decompress" ascii
		$str5 = "MIMEHeader" ascii
		$str6 = "ResolveReference" ascii
		$str7 = "115792089210356248762697446949407573529996955224135760342422259061068512044369115792089210356248762697446949407573530086143415290314195533631308867097853951" ascii

	condition:
		uint16( 0 ) == 0x457F and all of them
}
rule SIGNATURE_BASE_MAL_G_Backdoor_BRICKSTORM_2 : FILE
{
	meta:
		description = "Detects BRICKSTORM backdoor used by APT group UNC5221 (China Nexus)"
		author = "Google Threat Intelligence Group (GTIG) (modified by Florian Roth)"
		id = "03618840-c3f3-5ba6-983b-181a855d506b"
		date = "2025-09-25"
		modified = "2026-05-15"
		reference = "https://cloud.google.com/blog/topics/threat-intelligence/brickstorm-espionage-campaign"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_brickstorm_sep25.yar#L20-L53"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "afea32d3c817473ec0dbc20177daa4070f847c23295318fa093fc3a96a15e764"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$decr1 = { 0F B6 4C 04 ?? 0F B6 54 04 ?? 31 D1 88 4C 04 ?? 48 FF C0 [0-4] 48 83 F8 ?? 7C }
		$decr2 = { 40 88 7C 34 34 48 FF C3 48 FF C6 48 39 D6 7D 18 0F B6 3B 48 39 CE 73 63 44 0F B6 04 30 44 31 C7 48 83 FE 04 72 DA }
		$decr3 = { 0F B6 54 0C ?? 0F B6 5C 0C ?? 31 DA 88 14 08 48 FF C1 48 83 F9 ?? 7C E8 }
		$str1 = "main.selfWatcher"
		$str2 = "main.copyFile"
		$str3 = "main.startNew"
		$str4 = "WRITE_LOG=true"
		$str5 = "WRITE_LOGWednesday"
		$str6 = "vami-httpdvideo/webm"
		$str7 = "/opt/vmware/sbin/"
		$str8 = "/home/vsphere-ui/"
		$str9 = "/opt/vmware/sbin/vami-http"
		$str10 = "main.getVFromEnv"

	condition:
		uint32( 0 ) == 0x464c457f and filesize < 10MB and ( 1 of ( $decr* ) and 1 of ( $str* ) or 5 of ( $str* ) )
}
rule SIGNATURE_BASE_MAL_G_APT_Backdoor_BRICKSTORM_1 : FILE
{
	meta:
		description = "Detects BRICKSTORM backdoor used by APT group UNC5221 (China Nexus)"
		author = "Google Threat Intelligence Group (GTIG) (modified by Florian Roth)"
		id = "0e56b78c-121d-5ee5-ad3a-103088ecafeb"
		date = "2025-09-25"
		modified = "2026-05-15"
		reference = "https://cloud.google.com/blog/topics/threat-intelligence/brickstorm-espionage-campaign"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_brickstorm_sep25.yar#L55-L81"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "4645f2f6800bc654d5fa812237896b00"
		logic_hash = "ffaeca48c96445044844779f28c46a5c6029ba96191d3faafbc8f3864c29e21b"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$ = "WRITE_LOGWednesday"
		$ = "/home/vsphere-ui/"
		$ = "WRITE_LOG=true"
		$ = "dns rcode: %v"
		$ = "/libs/doh.createDnsMessage"
		$ = "/libs/func1.(*Client).BackgroundRun"
		$ = "/libs/func1.CreateClient"
		$ = "/core/extends/command.CommandNoContext"
		$ = "/core/extends/command.ExecuteCmd"
		$ = "/core/extends/command.RunShell"
		$ = "/libs/fs.(*RemoteDriver).DeleteFile"
		$ = "/libs/fs.(*RemoteDriver).GetFile"
		$ = "/libs/fs.(*RemoteDriver).PutFile"
		$ = "/libs/doh/doh.go"

	condition:
		uint32( 0 ) == 0x464c457f and 5 of them
}
rule SIGNATURE_BASE_MAL_G_APT_Backdoor_BRICKSTORM_2 : FILE
{
	meta:
		description = "Detects BRICKSTORM backdoor used by APT group UNC5221 (China Nexus)"
		author = "Google Threat Intelligence Group (GTIG) (modified by Florian Roth)"
		id = "8418b887-9183-5364-a9d8-d2d4dbdefe83"
		date = "2025-09-25"
		modified = "2026-05-15"
		reference = "https://cloud.google.com/blog/topics/threat-intelligence/brickstorm-espionage-campaign"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_brickstorm_sep25.yar#L83-L96"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "db989caa2a80481e58e6d65068e1814cf7366e3bdfc347e9019fb2bc980c74fa"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$str1 = { 0F 57 C0 0F 11 84 ?? ?? ?? ?? ?? C6 44 ?? ?? 00 4? C7 84 ?? ?? ?? ?? ?? 00 00 00 00 0F 57 C0 0F 11 84 ?? ?? ?? ?? ?? 0F 11 84 ?? ?? ?? ?? ?? 4? 8B 84 ?? ?? ?? ?? ?? 4? 89 04 ?? 4? 8B 8C ?? ?? ?? ?? ?? 4? 89 4C ?? ?? E8 ?? ?? ?? ?? 4? 83 7C ?? ?? 00 0F 84 ?? ?? ?? ?? 4? 8D 05 ?? ?? ?? ?? 4? 89 ?? ?? E8 ?? ?? ?? ?? 4? 8B 7C ?? ?? 4? 8B 84 ?? ?? ?? ?? ?? 4? 89 47 08 83 3D ?? ?? ?? ?? 00 75 ?? 4? 8B 84 ?? ?? ?? ?? ?? 4? 89 07 4? 89 BC ?? ?? ?? ?? ?? 4? C7 84 ?? ?? ?? ?? ?? 01 00 00 00 4? C7 84 ?? ?? ?? ?? ?? 01 00 00 00 0F 57 C0 0F 11 84 ?? ?? ?? ?? ?? 4? 8B ?? ?? ?? ?? ?? ?? 4? 81 C4 ?? ?? ?? ?? C3 }
		$str2 = { 4? C7 84 ?? ?? ?? ?? ?? 00 00 00 00 4? C7 84 ?? ?? ?? ?? ?? 00 00 00 00 4? C7 84 ?? ?? ?? ?? ?? 00 00 00 00 4? C7 84 ?? ?? ?? ?? ?? 00 00 00 00 4? C7 84 ?? ?? ?? ?? ?? 00 00 00 00 4? 8B 84 ?? ?? ?? ?? ?? 4? 89 04 ?? 4? 8B 8C ?? ?? ?? ?? ?? 4? 89 4C ?? ?? E8 ?? ?? ?? ?? 4? 8B 44 ?? ?? 4? 85 C0 0F 84 ?? ?? ?? ?? 4? 8D 05 ?? ?? ?? ?? 4? 89 ?? ?? E8 ?? ?? ?? ?? 4? 8B 44 ?? ?? 4? 8B 8C ?? ?? ?? ?? ?? 4? 89 48 08 8B 0D ?? ?? ?? ?? 85 C9 75 ?? 4? 8B 8C ?? ?? ?? ?? ?? 4? 89 08 84 00 4? 89 84 ?? ?? ?? ?? ?? 4? C7 84 ?? ?? ?? ?? ?? 01 00 00 00 4? C7 84 ?? ?? ?? ?? ?? 01 00 00 00 4? C7 84 ?? ?? ?? ?? ?? 00 00 00 00 4? C7 84 ?? ?? ?? ?? ?? 00 00 00 00 90 E8 ?? ?? ?? ?? 4? 8B ?? ?4 D8 00 00 00 4? 81 C4 E0 00 00 00 C3 }

	condition:
		uint32be( 0 ) == 0x7F454C46 and any of them
}
rule SIGNATURE_BASE_WEBSHELL_G_APT_Backdoorwebshell_SLAYSTYLE_1 : FILE
{
	meta:
		description = "Detects webshell used by APT group UNC5221 (China Nexus)"
		author = "Google Threat Intelligence Group (GTIG) (modified by Florian Roth)"
		id = "6d3dfb91-a14b-5420-b17b-c6d65c94fc53"
		date = "2025-09-25"
		modified = "2026-05-15"
		reference = "https://cloud.google.com/blog/topics/threat-intelligence/brickstorm-espionage-campaign"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_brickstorm_sep25.yar#L98-L117"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7a56238218e60a69049f5d9c756df4fb6f0de772fbc437a14c5db7192f971be6"
		score = 75
		quality = 83
		tags = "FILE"

	strings:
		$str1_alt = "=request.getParameter(\""
		$str2 = "=new String(java.util.Base64.getDecoder().decode(" ascii wide nocase
		$str21_alt = "={\"/bin/sh\",\"-c\"," ascii
		$str3 = "= Runtime.getRuntime().exec(" ascii
		$str4 = "java.io.InputStream" ascii
		$str5 = "java.util.Base64.getEncoder().encodeToString(org.apache.commons.io.IOUtils.toByteArray(" ascii

	condition:
		filesize < 5MB and all of them
}
rule SIGNATURE_BASE_WEBSHELL_G_APT_Backdoorwebshell_SLAYSTYLE_2 : FILE
{
	meta:
		description = "Detects webshell used by APT group UNC5221 (China Nexus)"
		author = "Google Threat Intelligence Group (GTIG) (modified by Florian Roth)"
		id = "5ab6791b-5043-5fa1-b73e-caba9e059eaa"
		date = "2025-09-25"
		modified = "2026-05-15"
		reference = "https://cloud.google.com/blog/topics/threat-intelligence/brickstorm-espionage-campaign"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_brickstorm_sep25.yar#L119-L135"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d2d1003f77a2066b48df1c27feab79c0a1951ebb62c3198de8366bcfee42e30a"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$str1 = "request.getParameter"
		$str2 = "/bin/sh"
		$str3 = "java.io.InputStream"
		$str4 = "Runtime.getRuntime().exec("
		$str5 = "2>&1"

	condition:
		( uint16( 0 ) != 0x5A4D and uint32( 0 ) != 0x464C457F ) and filesize < 7KB and all of them and @str4 > @str2
}
rule SIGNATURE_BASE_MAL_G_Backdoor_BRICKSTEAL_1 : FILE
{
	meta:
		description = "Detects backdoor BRICKSTEAL used by APT group UNC5221 (China Nexus)"
		author = "Google Threat Intelligence Group (GTIG) (modified by Florian Roth)"
		id = "2457d600-d9dd-504f-baa3-699ec5c61eae"
		date = "2025-09-25"
		modified = "2026-05-15"
		reference = "https://cloud.google.com/blog/topics/threat-intelligence/brickstorm-espionage-campaign"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_brickstorm_sep25.yar#L137-L153"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "27413b63eae84d95cf0ca920e9ac1daba200281ecc32cc9922c0e7850c7f0571"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$str1 = "comvmware"
		$str2 = "abcdABCD1234!@#$"
		$str3 = "ads.png"
		$str4 = "User-Agent"
		$str5 = "com/vmware/"

	condition:
		all of them and filesize < 10KB
}
rule SIGNATURE_BASE_MAL_G_Dropper_BRICKSTEAL_1
{
	meta:
		description = "Detects backdoor BRICKSTEAL dropper used by APT group UNC5221 (China Nexus)"
		author = "Google Threat Intelligence Group (GTIG) (modified by Florian Roth)"
		id = "c96eeeb0-ccb4-572c-80b5-638ce3bb51a9"
		date = "2025-09-25"
		modified = "2026-05-15"
		reference = "https://cloud.google.com/blog/topics/threat-intelligence/brickstorm-espionage-campaign"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_brickstorm_sep25.yar#L155-L173"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "5ed68f17ba8ac0c7ba02f9111f083244181332c71ed43b4cd5582baee493c98d"
		score = 75
		quality = 85
		tags = ""

	strings:
		$str1 = "Base64.getDecoder().decode"
		$str2 = "Thread.currentThread().getContextClassLoader()"
		$str3 = ".class.getDeclaredMethod"
		$str4 = "byte[].class"
		$str5 = "method.invoke"
		$str6 = "filterClass.newInstance()"
		$str7 = "/websso/SAML2/SSO/*"

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_G_Dropper_BRICKSTEAL_2
{
	meta:
		description = "Detects backdoor BRICKSTEAL dropper used by APT group UNC5221 (China Nexus)"
		author = "Google Threat Intelligence Group (GTIG) (modified by Florian Roth)"
		id = "8139f8c0-4c18-51bd-bf23-8c4cdc3fd555"
		date = "2025-09-25"
		modified = "2026-05-15"
		reference = "https://cloud.google.com/blog/topics/threat-intelligence/brickstorm-espionage-campaign"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_brickstorm_sep25.yar#L175-L193"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e1bdcc59259b2bf476b873a9f94b9296efc7720d83fba04f6569217019ae3af8"
		score = 75
		quality = 85
		tags = ""

	strings:
		$str1_alt = "(Class<?>) method.invoke(" ascii wide
		$str2 = "(\"yv66vg" ascii wide
		$str3 = "request.getSession().getServletContext" ascii wide
		$str4 = ".getClass().getDeclaredField(" ascii wide
		$str5 = "new FilterDef();" ascii wide
		$str6 = "new FilterMap();" ascii wide

	condition:
		all of them
}

rule SIGNATURE_BASE_MAL_WIPER_Isaacwiper_Mar22_1 : FILE
{
	meta:
		description = "Detects IsaacWiper malware"
		author = "Florian Roth (Nextron Systems)"
		id = "97d8d8dd-db65-5156-8f97-56c620cf2d56"
		date = "2022-03-03"
		modified = "2023-12-05"
		reference = "https://www.welivesecurity.com/2022/03/01/isaacwiper-hermeticwizard-wiper-worm-targeting-ukraine/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ua_isaacwiper.yar#L3-L29"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "13037b749aa4b1eda538fda26d6ac41c8f7b1d02d83f47b0d187dd645154e033"
		hash = "7bcd4ec18fc4a56db30e0aaebd44e2988f98f7b5d8c14f6689f650b4f11e16c0"
		logic_hash = "6fe7d1536db5fc30c9b4a171be66993fc69e6a1d96dae00be4170bdb4a53afb8"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "C:\\ProgramData\\log.txt" wide fullword
		$s2 = "Cleaner.dll" ascii fullword
		$s3 = "-- system logical drive: " wide fullword
		$s4 = "-- FAILED" wide fullword
		$op1 = { 8b f1 80 3d b0 66 03 10 00 0f 85 96 00 00 00 33 c0 40 b9 a8 66 03 10 87 01 33 db }
		$op2 = { 8b 40 04 2b c2 c1 f8 02 3b c8 74 34 68 a2 c8 01 10 2b c1 6a 04 }
		$op3 = { 8d 4d f4 ff 75 08 e8 12 ff ff ff 68 88 39 03 10 8d 45 f4 50 e8 2d 1d 00 00 cc }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 700KB and ( pe.imphash ( ) == "a4b162717c197e11b76a4d9bc58ea25d" or 3 of them )
}
rule SIGNATURE_BASE_MAL_RANSOM_Darkbit_Feb23_1 : FILE
{
	meta:
		description = "Detects indicators found in DarkBit ransomware"
		author = "Florian Roth"
		id = "d209a0c2-f649-5fb1-9ecd-f1c35caa796f"
		date = "2023-02-13"
		modified = "2023-12-05"
		reference = "https://twitter.com/idonaor1/status/1624703255770005506?s=12&t=mxHaauzwR6YOj5Px8cIeIw"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ransom_darkbit_feb23.yar#L2-L23"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ba1baea7cb7362160c4b00b0355000a789b238c1ec82b840479c04028e6ca3ab"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = ".onion" ascii
		$s2 = "GetMOTWHostUrl"
		$x1 = "hus31m7c7ad.onion"
		$x2 = "iw6v2p3cruy"
		$xn1 = "You will receive decrypting key after the payment."

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 10MB and ( 1 of ( $x* ) or 2 of them ) or 4 of them or ( filesize < 10MB and $xn1 )
}
rule SIGNATURE_BASE_MAL_RANSOM_Darkbit_Feb23_2 : FILE
{
	meta:
		description = "Detects Go based DarkBit ransomware (garbled code; could trigger on other obfuscated samples, too)"
		author = "Florian Roth"
		id = "f530815c-68e7-55f1-8e36-bc74a1059584"
		date = "2023-02-13"
		modified = "2023-12-05"
		reference = "https://www.hybrid-analysis.com/sample/9107be160f7b639d68fe3670de58ed254d81de6aec9a41ad58d91aa814a247ff?environmentId=160"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ransom_darkbit_feb23.yar#L25-L45"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "9107be160f7b639d68fe3670de58ed254d81de6aec9a41ad58d91aa814a247ff"
		logic_hash = "577435536300902811612a3415e82420574c98345b91b21fb2bfd2bfde396bec"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "runtime.initLongPathSupport" ascii fullword
		$s2 = "reflect." ascii
		$s3 = "    \"processes\": []," ascii fullword
		$s4 = "^!* %!(!" ascii fullword
		$op1 = { 4d 8b b6 00 00 00 00 48 8b 94 24 40 05 00 00 31 c0 87 82 30 03 00 00 b8 01 00 00 00 f0 0f c1 82 00 03 00 00 48 8b 44 24 48 48 8b 0d ba 1f 32 00 }
		$op2 = { 49 8d 49 01 0f 1f 00 48 39 d9 7c e2 b9 0b 00 00 00 49 89 d8 e9 28 fc ff ff e8 89 6c d7 ff }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 20000KB and all of them
}
rule SIGNATURE_BASE_MAL_WIN_Ralordv1_Apr25 : FILE
{
	meta:
		description = "This ISH Tecnologia Yara rule, detects the main components of the first version of RALord Ransomware"
		author = "0x0d4y-Icaro Cesar"
		id = "67254633-3597-4770-9806-8b2e26c8f66a"
		date = "2025-04-01"
		modified = "2026-05-15"
		reference = "https://ish.com.br/wp-content/uploads/2025/04/RALord-Novo-grupo-de-Ransomware-as-a-Service-1.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_ralordv1_win_ap25.yar#L1-L29"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "be15f62d14d1cbe2aecce8396f4c6289"
		logic_hash = "75d20cca5eb48109bbb3b0ab0ce2efb4f2d89bc1984df8c4fddf1f859d069750"
		score = 80
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"
		rule_matching_tlp = "TLP:WHITE"
		rule_sharing_tlp = "TLP:WHITE"
		malpedia_family = "win.ralord"

	strings:
		$code_pattern_quarterround = { 4? 31 ?? 48 8b ?? ?? ?? 4? 31 ?? 48 8b ?? ?? ?? 31 e8 4? 31 ?? 41 c1 ?? 0c c1 ?? 0c c1 ?? 0c 48 89 c2 c1 ?? 0c }
		$code_pattern_custom_alg = { 0f 57 ?? 0f 10 ?? c5 ?? ?? ?? ?? 0f 57 ?? 0f 10 ?? c5 ?? ?? ?? ?? 0f 57 ?? 0f 10 ?? c5 ?? ?? ?? ?? 0f 57 ?? 0f 11 ?? c5 ?? ?? ?? ?? 0f 11 ?? c5 ?? ?? ?? ?? 0f 11 ?? c5 ?? ?? ?? ?? 0f 11 ?? c5 ?? ?? ?? ?? 48 83 c0 08 48 3d 8? }
		$ralord_str_I = "chacha" ascii
		$ralord_str_II = "scorp" ascii
		$ralord_str_III = "RALord" ascii
		$ralord_str_IV = "onion" ascii
		$ralord_str_V = "/rust" ascii
		$ralord_str_VI = "BCryptGenRandom" ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of ( $code_pattern_* ) and 4 of ( $ralord_str_* )
}
rule SIGNATURE_BASE_EXT_HKTL_MAL_Tinyshell_Backdoor : FILE
{
	meta:
		description = "Detects Tiny Shell - an open-source UNIX backdoor"
		author = "Mandiant"
		id = "4ad5d334-98e4-577f-89c9-86626e8feb58"
		date = "2022-03-17"
		modified = "2026-05-15"
		reference = "https://www.mandiant.com/resources/blog/unc2891-overview"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_unc2891_tinyshell_slapstick.yar#L1-L29"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "1f889871263bd6cdad8f3d4d5fc58b4a32669b944d3ed0860730374bb87d730a"
		logic_hash = "1fe9def11dced638ad38236652877427b61d7138fc8c6ce3fe7f1403c367468f"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$sb1 = { C6 00 48 C6 4? ?? 49 C6 4? ?? 49 C6 4? ?? 4C C6 4? ?? 53 C6 4? ?? 45 C6 4? ?? 54 C6 4? ?? 3D C6 4? ?? 46 C6 4? ?? 00 }
		$sb2 = { C6 00 54 C6 4? ?? 4D C6 4? ?? 45 C6 4? ?? 3D C6 4? ?? 52 }
		$ss1 = "fork" ascii fullword wide
		$ss2 = "socket" ascii fullword wide
		$ss3 = "bind" ascii fullword wide
		$ss4 = "listen" ascii fullword wide
		$ss5 = "accept" ascii fullword wide
		$ss6 = "alarm" ascii fullword wide
		$ss7 = "shutdown" ascii fullword wide
		$ss8 = "creat" ascii fullword wide
		$ss9 = "write" ascii fullword wide
		$ss10 = "open" ascii fullword wide
		$ss11 = "read" ascii fullword wide
		$ss12 = "execl" ascii fullword wide
		$ss13 = "gethostbyname" ascii fullword wide
		$ss14 = "connect" ascii fullword wide

	condition:
		uint32( 0 ) == 0x464c457f and 1 of ( $sb* ) and 10 of ( $ss* )
}
rule SIGNATURE_BASE_EXT_HKTL_MAL_Tinyshell_Backdoor_SPARC : FILE
{
	meta:
		description = "Detects Tiny Shell variant for SPARC - an open-source UNIX backdoor"
		author = "Mandiant"
		id = "0a05a316-65b7-5cdf-849b-820ab60afbbd"
		date = "2022-03-17"
		modified = "2026-05-15"
		reference = "https://www.mandiant.com/resources/blog/unc2891-overview"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_unc2891_tinyshell_slapstick.yar#L31-L44"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "cda78e26c2e274d24d1e4656fcd09af2930f43af7fac01a3f410a5692d79a5ae"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$sb_xor_1 = { DA 0A 80 0C 82 18 40 0D C2 2A 00 0B 96 02 E0 01 98 03 20 01 82 1B 20 04 80 A0 00 01 82 60 20 00 98 0B 00 01 C2 4A 00 0B 80 A0 60 00 32 BF FF F5 C2 0A 00 0B 81 C3 E0 08 }
		$sb_xor_2 = { C6 4A 00 00 80 A0 E0 00 02 40 00 0B C8 0A 00 00 85 38 60 00 C4 09 40 02 84 18 80 04 C4 2A 00 00 82 00 60 01 80 A0 60 04 83 64 60 00 10 6F FF F5 90 02 20 01 81 C3 E0 08 }

	condition:
		uint32( 0 ) == 0x464C457F and ( uint16( 0x10 ) & 0x0200 == 0x0200 ) and ( uint16( 0x12 ) & 0x0200 == 0x0200 ) and 1 of them
}
rule SIGNATURE_BASE_EXT_APT_UNC2891_SLAPSTICK : FILE
{
	meta:
		description = "Detects SLAPSTICK malware used by UNC2891"
		author = "Mandiant"
		id = "2e97b8cb-a86e-5be9-92dc-fd1474aa9547"
		date = "2022-03-17"
		modified = "2026-05-15"
		reference = "https://www.mandiant.com/resources/blog/unc2891-overview"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_unc2891_tinyshell_slapstick.yar#L46-L60"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b046a949dab2f38b8181782cc6ea0782d2e102c0c30bc782de74112a77c23d6e"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$ss1 = { 25 59 20 25 62 20 25 64 20 25 48 3a 25 4d 3a 25 53 20 20 20 20 00 }
		$ss2 = { 25 2d 32 33 73 20 25 2d 32 33 73 20 25 2d 32 33 73 00 }
		$ss3 = { 25 2d 32 33 73 20 25 2d 32 33 73 20 25 2d 32 33 73 20 25 2d 32 33 73 20 25 2d 32 33 73 20 25 73 0a 00 }

	condition:
		( uint32( 0 ) == 0x464c457f ) and all of them
}
rule SIGNATURE_BASE_WEBSHELL_PHP_Unknown_1 : FILE
{
	meta:
		description = "obfuscated php webshell"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "93d01a4c-4c18-55d2-b682-68a1f6460889"
		date = "2021-01-07"
		modified = "2023-04-05"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_webshells.yar#L869-L891"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "12ce6c7167b33cc4e8bdec29fb1cfc44ac9487d1"
		hash = "cf4abbd568ce0c0dfce1f2e4af669ad2"
		logic_hash = "ce2d4c87c001a45febf7eac5474aa0d24ea73067f9154203ef5653bf77e7028f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"
		importance = 70

	strings:
		$sp0 = /^<\?php \$[a-z]{3,30} = '/ wide ascii
		$sp1 = "=explode(chr(" wide ascii
		$sp2 = "; if (!function_exists('" wide ascii
		$sp3 = " = NULL; for(" wide ascii

	condition:
		filesize < 300KB and all of ( $sp* )
}
rule SIGNATURE_BASE_WEBSHELL_PHP_Generic_Eval : FILE
{
	meta:
		description = "Generic PHP webshell which uses any eval/exec function in the same line with user input"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "79cfbd88-f6f7-5cba-a325-0a99962139ca"
		date = "2021-01-07"
		modified = "2023-04-05"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_webshells.yar#L893-L952"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "a61437a427062756e2221bfb6d58cd62439d09d9"
		hash = "90c5cc724ec9cf838e4229e5e08955eec4d7bf95"
		hash = "2b41abc43c5b6c791d4031005bf7c5104a98e98a00ee24620ce3e8e09a78e78f"
		hash = "5c68a0fa132216213b66a114375b07b08dc0cb729ddcf0a29bff9ca7a22eaaf4"
		hash = "de3c01f55d5346577922bbf449faaaaa1c8d1aaa64c01e8a1ee8c9d99a41a1be"
		hash = "124065176d262bde397b1911648cea16a8ff6a4c8ab072168d12bf0662590543"
		hash = "cd7450f3e5103e68741fd086df221982454fbcb067e93b9cbd8572aead8f319b"
		hash = "ab835ce740890473adf5cc804055973b926633e39c59c2bd98da526b63e9c521"
		hash = "31ff9920d401d4fbd5656a4f06c52f1f54258bc42332fc9456265dca7bb4c1ea"
		hash = "64e6c08aa0b542481b86a91cdf1f50c9e88104a8a4572a8c6bd312a9daeba60e"
		hash = "80e98e8a3461d7ba15d869b0641cdd21dd5b957a2006c3caeaf6f70a749ca4bb"
		hash = "93982b8df76080e7ba4520ae4b4db7f3c867f005b3c2f84cb9dff0386e361c35"
		hash = "51c2c8b94c4b8cce806735bcf6e5aa3f168f0f7addce47b699b9a4e31dc71b47"
		hash = "7a16311a371f03b29d5220484e7ecbe841cfaead4e73c17aa6a9c23b5d94544d"
		hash = "7ca5dec0515dd6f401cb5a52c313f41f5437fc43eb62ea4bcc415a14212d09e9"
		hash = "fd5f0f81204ca6ca6e93343500400d5853012e88254874fc9f62efe0fde7ab3c"
		hash = "883f48ed4e9646da078cabf6b8b4946d9f199660262502650f76450ecf60ddd5"
		hash = "6d042b6393669bb4d98213091cabe554ab192a6c916e86c04d06cc2a4ca92c00"
		hash = "dd5d8a9b4bb406e0b8f868165a1714fe54ffb18e621582210f96f6e5ae850b33"
		logic_hash = "4b7759e4761f5897bfb5e576df645a2e99cec4e703fb28d0fc275cf8f8848263"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"
		importance = 70

	strings:
		$geval = /\b(exec|shell_exec|passthru|system|popen|proc_open|pcntl_exec|eval|assert)[\t ]{0,300}(\(base64_decode)?(\(stripslashes)?[\t ]{0,300}(\(trim)?[\t ]{0,300}\(\$(_POST|_GET|_REQUEST|_SERVER\s?\[['"]HTTP_|GLOBALS\[['"]_(POST|GET|REQUEST))/ wide ascii
		$gfp1 = "eval(\"return [$serialised_parameter"
		$gfp2 = "$this->assert(strpos($styles, $"
		$gfp3 = "$module = new $_GET['module']($_GET['scope']);"
		$gfp4 = "$plugin->$_POST['action']($_POST['id']);"
		$gfp5 = "$_POST[partition_by]($_POST["
		$gfp6 = "$object = new $_REQUEST['type']($_REQUEST['id']);"
		$gfp7 = "The above example code can be easily exploited by passing in a string such as"
		$gfp8 = "Smarty_Internal_Debug::start_render($_template);"
		$gfp9 = "?p4yl04d=UNION%20SELECT%20'<?%20system($_GET['command']);%20?>',2,3%20INTO%20OUTFILE%20'/var/www/w3bsh3ll.php"
		$gfp10 = "[][}{;|]\\|\\\\[+=]\\|<?=>?"
		$gfp11 = "(eval (getenv \"EPROLOG\")))"
		$gfp12 = "ZmlsZV9nZXRfY29udGVudHMoJ2h0dHA6Ly9saWNlbnNlLm9wZW5jYXJ0LWFwaS5jb20vbGljZW5zZS5waHA/b3JkZXJ"
		$gfp_3 = " GET /"
		$gfp_4 = " POST /"

	condition:
		filesize < 300KB and not ( any of ( $gfp* ) ) and $geval
}
rule SIGNATURE_BASE_WEBSHELL_PHP_In_Htaccess : FILE
{
	meta:
		description = "Use Apache .htaccess to execute php code inside .htaccess"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "0f5edff9-22b2-50c9-ae81-72698ea8e7db"
		date = "2021-01-07"
		modified = "2023-07-05"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_webshells.yar#L2757-L2779"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "c026d4512a32d93899d486c6f11d1e13b058a713"
		hash = "d79e9b13a32a9e9f3fa36aa1a4baf444bfd2599a"
		hash = "e1d1091fee6026829e037b2c70c228344955c263"
		hash = "c026d4512a32d93899d486c6f11d1e13b058a713"
		hash = "8c9e65cd3ef093cd9c5b418dc5116845aa6602bc92b9b5991b27344d8b3f7ef2"
		logic_hash = "0652a4cb0cb6c61afece5c2e4cbf2f281714509f0d828047f2e3ccd411602115"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"
		importance = 70

	strings:
		$hta = "AddType application/x-httpd-php .htaccess" wide ascii

	condition:
		filesize < 100KB and $hta
}
rule SIGNATURE_BASE_WEBSHELL_JSP_Generic_Processbuilder : FILE
{
	meta:
		description = "Generic JSP webshell which uses processbuilder to execute user input"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "2a7c5f44-24a1-5f43-996e-945c209b79b1"
		date = "2021-01-07"
		modified = "2023-04-05"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_webshells.yar#L5964-L6001"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "82198670ac2072cd5c2853d59dcd0f8dfcc28923"
		hash = "c05a520d96e4ebf9eb5c73fc0fa446ceb5caf343"
		hash = "347a55c174ee39ec912d9107e971d740f3208d53af43ea480f502d177106bbe8"
		hash = "d0ba29b646274e8cda5be1b940a38d248880d9e2bba11d994d4392c80d6b65bd"
		logic_hash = "fffc173cc23e158e319e48097243a64da232151e441c39e4b6ecc2565a82d862"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"
		importance = 70

	strings:
		$exec = "ProcessBuilder" fullword wide ascii
		$start = "start" fullword wide ascii
		$input1 = "getParameter" fullword ascii wide
		$input2 = "getHeaders" fullword ascii wide
		$input3 = "getInputStream" fullword ascii wide
		$input4 = "getReader" fullword ascii wide
		$req1 = "request" fullword ascii wide
		$req2 = "HttpServletRequest" fullword ascii wide
		$req3 = "getRequest" fullword ascii wide

	condition:
		filesize < 2000 and ( any of ( $input* ) and any of ( $req* ) ) and $exec and $start
}
rule SIGNATURE_BASE_WEBSHELL_Cookie_Post_Obfuscation : FILE
{
	meta:
		description = "Detects webshell using cookie POST"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "cc5ded80-5e58-5b25-86d1-1c492042c740"
		date = "2023-01-28"
		modified = "2023-04-05"
		reference = "https://github.com/SigmaHQ/Detection-Rule-License/blob/main/LICENSE.Detection.Rules.md"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_webshells.yar#L6884-L6910"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "d08a00e56feb78b7f6599bad6b9b1d8626ce9a6ea1dfdc038358f4c74e6f65c9"
		hash = "2ce5c4d31682a5a59b665905a6f698c280451117e4aa3aee11523472688edb31"
		hash = "ff732d91a93dfd1612aed24bbb4d13edb0ab224d874f622943aaeeed4356c662"
		hash = "a3b64e9e065602d2863fcab641c75f5d8ec67c8632db0f78ca33ded0f4cea257"
		hash = "d41abce305b0dc9bd3a9feb0b6b35e8e39db9e75efb055d0b1205a9f0c89128e"
		hash = "333560bdc876fb0186fae97a58c27dd68123be875d510f46098fc5a61615f124"
		hash = "2efdb79cdde9396ff3dd567db8876607577718db692adf641f595626ef64d3a4"
		hash = "e1bd3be0cf525a0d61bf8c18e3ffaf3330c1c27c861aede486fd0f1b6930f69a"
		hash = "f8cdedd21b2cc29497896ec5b6e5863cd67cc1a798d929fd32cdbb654a69168a"
		logic_hash = "87229859ca3ee8f8b79360603c421528cda2ecefcc46d4080236d09b2dd510fb"
		score = 75
		quality = 85
		tags = "FILE"
		importance = 70

	strings:
		$s1 = "]($_COOKIE, $_POST) as $"
		$s2 = "function"
		$s3 = "Array"

	condition:
		( uint16( 0 ) == 0x3f3c and filesize < 100KB and ( all of them ) )
}
rule SIGNATURE_BASE_MAL_WIN_Megazord_Apr25 : FILE
{
	meta:
		description = "This Yara rule from ISH Tecnologia's Heimdall Security Research Team, detects the main components of the Megazord Ransomware"
		author = "0x0d4y-Icaro Cesar"
		id = "6225a690-8f54-4a50-a19a-8f7523537228"
		date = "2025-04-11"
		modified = "2026-05-15"
		reference = "https://ish.com.br/wp-content/uploads/2025/04/A-Anatomia-do-Ransomware-Akira-e-sua-expansao-multiplataforma.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_win_megazord_apr25.yar#L1-L30"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "fd380db23531bb7bb610a7b32fc2a6d5"
		logic_hash = "1a73e67b9a43c4f1bbe9f3dbebeb428bbfa705f7c858909a7bbf0673951d677e"
		score = 80
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"
		rule_matching_tlp = "TLP:WHITE"
		rule_sharing_tlp = "TLP:WHITE"
		malpedia_family = "win.akira"

	strings:
		$code_custom_algorithm = { 89 c1 45 31 e6 31 e8 44 31 f0 35 ?? ?? ?? ?? c1 c0 0b 44 31 ff 44 31 ef 31 c7 81 f7 ?? ?? ?? ?? c1 c7 0b 44 31 e3 31 cb 31 fb 81 f3 ?? ?? ?? ?? c1 c3 0b 89 da 31 c2 89 84 24 ?? ?? ?? ?? 44 31 ed 31 d5 89 94 24 ?? ?? ?? ?? 81 f5 ?? ?? ?? ?? c1 c5 0b 41 89 e8 41 31 f8 89 bc 24 ?? ?? ?? ?? 41 31 cf 45 31 c7 44 89 84 24 ?? ?? ?? ?? 41 81 f7 ?? ?? ?? ?? 41 c1 c7 0b 41 31 d4 45 31 fc 41 81 f4 ?? ?? ?? ?? 41 c1 c4 0b 45 31 c5 45 31 e5 41 81 f5 ?? ?? ?? ?? 41 c1 c5 0b 89 9c 24 ?? ?? ?? ?? 31 d9 44 31 f9 44 31 e9 81 f1 ?? ?? ?? ?? c1 c1 0b 41 89 c8 45 31 e0 44 89 a4 24 ?? ?? ?? ?? 89 ac 24 ?? ?? ?? ?? 31 e8 44 31 c0 35 ?? ?? ?? ?? c1 c0 0b 44 89 fa 44 89 bc 24 ?? ?? ?? ?? 31 fa 44 31 ea 31 c2 41 89 c1 81 f2 ?? ?? ?? ?? c1 c2 0b 41 31 d8 41 31 d0 41 81 f0 ?? ?? ?? ?? 41 c1 c0 0b 44 89 e8 44 89 ac 24 ?? ?? ?? ?? 31 e8 44 31 c8 44 31 c0 45 89 c3 35 }
		$megazord_str_I = "powerranges" ascii
		$megazord_str_II = "onion" ascii
		$megazord_str_III = "powershell" ascii
		$megazord_str_IV = "taskkill" ascii
		$megazord_str_V = "mal_public_key_bytes" ascii
		$megazord_str_VI = "runneradmin" ascii
		$megazord_str_VII = "//rustc" ascii

	condition:
		uint16( 0 ) == 0x5a4d and $code_custom_algorithm and 5 of ( $megazord_str_* )
}
rule SIGNATURE_BASE_Brooxml_Hunting : HUNTING FILE
{
	meta:
		description = "Detects Microsoft OOXML files with prepended data/manipulated header"
		author = "Proofpoint"
		id = "1ffea1c7-9f97-5bb1-93d7-ce914765416f"
		date = "2024-11-27"
		modified = "2025-06-02"
		reference = "https://x.com/threatinsight/status/1861817946508763480"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_brooxml_dec24.yar#L2-L39"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8a8d934fe9286c9d1c83a2a0676bb8a5f2501116b96cca32dc27136ecfb9325b"
		score = 70
		quality = 85
		tags = "HUNTING, FILE"
		category = "hunting"

	strings:
		$pk_ooxml_magic = {50 4b 03 04 [22] 13 00 [2] 5b 43 6f 6e 74 65 6e 74 5f 54 79 70 65 73 5d 2e 78 6d 6c}
		$pk_0102 = {50 4b 01 02}
		$pk_0304 = {50 4b 03 04}
		$pk_0506 = {50 4b 05 06}
		$pk_0708 = {50 4b 07 08}
		$word = "word/"
		$ole = {d0 cf 11 e0}
		$tef = {78 9f 3e 22}

	condition:
		$pk_ooxml_magic in ( 4 .. 16384 ) and $pk_0506 in ( 16384 .. filesize ) and #pk_0506 == 1 and #pk_0102 > 2 and #pk_0304 > 2 and $word and not ( $pk_0102 at 0 ) and not ( $pk_0304 at 0 ) and not ( $pk_0506 at 0 ) and not ( $pk_0708 at 0 ) and not ( $ole at 0 ) and not ( uint16( 0 ) == 0x5a4d ) and not ( $tef at 0 )
}
rule SIGNATURE_BASE_Brooxml_Phishing : PHISHING FILE
{
	meta:
		description = "Detects PDF and OOXML files leading to AiTM phishing"
		author = "Proofpoint"
		id = "ccd8ab30-90a4-5d4b-8a77-dbc4669bdb95"
		date = "2024-11-27"
		modified = "2025-06-02"
		reference = "https://x.com/threatinsight/status/1861817946508763480"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_brooxml_dec24.yar#L41-L54"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "884e0b65c6c8b916ca9bc28705134ae02d1705c13cf43bff78f0c9ada894b307"
		score = 65
		quality = 85
		tags = "PHISHING, FILE"
		category = "phishing"

	strings:
		$hex1 = { 21 20 03 20 c3 be c3 bf 09 20 [0-1] 06 20 20 20 20 20 20 20 20 20 20 20 01 20 20 20 06 20 20 20 20 20 20 20 20 10 20 20 05 20 20 20 01 20 20 20 c3 be c3 bf c3 bf c3 bf }

	condition:
		all of ( $hex* ) and ( ( uint16be( 0 ) == 0x504b ) or ( uint32be( 0 ) == 0x25504446 ) )
}
rule SIGNATURE_BASE_APT28_Skinnyboy_Dropper : RUSSIA FILE
{
	meta:
		description = "Detects APT28 SkinnyBoy droppers"
		author = "Cluster25"
		id = "ed0b2d2b-f820-57b5-9654-c24734d81996"
		date = "2021-05-24"
		modified = "2023-12-05"
		reference = "https://cluster25.io/wp-content/uploads/2021/05/2021-05_FancyBear.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt28.yar#L103-L118"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "12331809c3e03d84498f428a37a28cf6cbb1dafe98c36463593ad12898c588c9"
		logic_hash = "9e29ed985fac8701f72f0860fe101272c3c3342ef6857e30d32f5fea14822945"
		score = 75
		quality = 85
		tags = "RUSSIA, FILE"

	strings:
		$ = "cmd /c DEL " ascii
		$ = {8a 08 40 84 c9 75 f9}
		$ = {0f b7 84 0d fc fe ff ff 66 31 84 0d fc fd ff ff}

	condition:
		( uint16( 0 ) == 0x5A4D and all of them )
}
rule SIGNATURE_BASE_SUSP_PS1_Frombase64String_Content_Indicator : FILE
{
	meta:
		description = "Detects suspicious base64 encoded PowerShell expressions"
		author = "Florian Roth (Nextron Systems)"
		id = "326c83ff-5d21-508f-b935-03ccdab6efa7"
		date = "2020-01-25"
		modified = "2024-04-03"
		reference = "https://gist.github.com/Neo23x0/6af876ee72b51676c82a2db8d2cd3639"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_powershell_susp.yar#L233-L284"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a9ec7a00e9faee5cc081a2bc86abf8027fcd3cfe590cdd4f2f99425b6723f23f"
		score = 65
		quality = 83
		tags = "FILE"

	strings:
		$ = "::FromBase64String(\"H4s" ascii wide
		$ = "::FromBase64String(\"TVq" ascii wide
		$ = "::FromBase64String(\"UEs" ascii wide
		$ = "::FromBase64String(\"JAB" ascii wide
		$ = "::FromBase64String(\"SUVY" ascii wide
		$ = "::FromBase64String(\"SQBFAF" ascii wide
		$ = "::FromBase64String(\"SQBuAH" ascii wide
		$ = "::FromBase64String(\"PAA" ascii wide
		$ = "::FromBase64String(\"cwBhA" ascii wide
		$ = "::FromBase64String(\"aWV4" ascii wide
		$ = "::FromBase64String(\"aQBlA" ascii wide
		$ = "::FromBase64String(\"R2V0" ascii wide
		$ = "::FromBase64String(\"dmFy" ascii wide
		$ = "::FromBase64String(\"dgBhA" ascii wide
		$ = "::FromBase64String(\"dXNpbm" ascii wide
		$ = "::FromBase64String(\"H4sIA" ascii wide
		$ = "::FromBase64String(\"Y21k" ascii wide
		$ = "::FromBase64String(\"Qzpc" ascii wide
		$ = "::FromBase64String(\"Yzpc" ascii wide
		$ = "::FromBase64String(\"IAB" ascii wide
		$ = "::FromBase64String('H4s" ascii wide
		$ = "::FromBase64String('TVq" ascii wide
		$ = "::FromBase64String('UEs" ascii wide
		$ = "::FromBase64String('JAB" ascii wide
		$ = "::FromBase64String('SUVY" ascii wide
		$ = "::FromBase64String('SQBFAF" ascii wide
		$ = "::FromBase64String('SQBuAH" ascii wide
		$ = "::FromBase64String('PAA" ascii wide
		$ = "::FromBase64String('cwBhA" ascii wide
		$ = "::FromBase64String('aWV4" ascii wide
		$ = "::FromBase64String('aQBlA" ascii wide
		$ = "::FromBase64String('R2V0" ascii wide
		$ = "::FromBase64String('dmFy" ascii wide
		$ = "::FromBase64String('dgBhA" ascii wide
		$ = "::FromBase64String('dXNpbm" ascii wide
		$ = "::FromBase64String('H4sIA" ascii wide
		$ = "::FromBase64String('Y21k" ascii wide
		$ = "::FromBase64String('Qzpc" ascii wide
		$ = "::FromBase64String('Yzpc" ascii wide
		$ = "::FromBase64String('IAB" ascii wide

	condition:
		filesize < 5000KB and 1 of them
}
rule SIGNATURE_BASE_MAL_JS_NPM_Supplychain_Attack_Sep25 : FILE
{
	meta:
		description = "Detects obfuscated JavaScript in NPM packages used in supply chain crypto stealer attacks in September 2025"
		author = "Florian Roth"
		id = "f083233e-348a-5b7d-a128-181c543a279c"
		date = "2025-09-09"
		modified = "2025-11-29"
		reference = "https://www.linkedin.com/feed/update/urn:li:activity:7370889385992437760/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_npm_supply_chain_sep25.yar#L1-L21"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "16f6c756bc8ce5ef5d9aa1ded0f811ec0c9cee3d8f85cc151b8ca1df7b8a4337"
		logic_hash = "1b83d1bd79cdff02ed2fff7bf1feb57801ff9a933de1bd4f7ceecf738213ab4c"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "const _0x112fa8=_0x180f;(function(_0x13c8b9" ascii
		$fp1 = "<html"
		$fp2 = "<xml "
		$fp3 = "<?xml"

	condition:
		filesize < 200KB and 1 of ( $x* ) and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_MAL_JS_NPM_Supplychain_Compromise_Sep25 : FILE
{
	meta:
		description = "Detects a supply chain compromise in NPM packages (TinyColor, CrowdStrike etc.)"
		author = "Florian Roth"
		id = "f64fa37b-8445-554a-8442-bd2d42a6643b"
		date = "2025-09-16"
		modified = "2025-09-17"
		reference = "https://socket.dev/blog/tinycolor-supply-chain-attack-affects-40-packages"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_npm_supply_chain_sep25.yar#L23-L50"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6ddcf152ee8b90496d9d3f7f51dc239d927a3a2095082d13c6cc7e21819097f4"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "if (plat === \"linux\") return \"https://github.com/trufflesecurity/trufflehog/releases"
		$sa1 = "curl -d \"$CONTENTS\" https://webhook.site/" ascii
		$sa2 = "curl -s -X POST -d \"$CONTENTS\" \"https://webhook.site/"
		$sb1 = " | base64 -w 0 | " ascii
		$sb2 = " | base64 -w0)"

	condition:
		filesize < 20MB and ( 1 of ( $x* ) or ( 1 of ( $sa* ) and 1 of ( $sb* ) ) ) and not uint8( 0 ) == 0x7b
}
rule SIGNATURE_BASE_EXPL_Signdrop_CLFS_LPE_Nov26 : FILE
{
	meta:
		description = "Detects SignDrop (SigDrop.exe), a Windows local privilege escalation exploit by Nightmare-Eclipse (MSNightmare) that abuses the CLFS authentication mitigation. It coerces Microsoft Defender via the signature update RPC into creating a CLFS authentication file (.cnpf) as SYSTEM, redirected to C:\\Program Files\\Common Files\\microsoft shared\\ink\\hid.dll, and then gets that DLL loaded on the UAC secure desktop."
		author = "Florian Roth"
		id = "2d03e489-db2c-5688-8f41-87b03f9ae4ca"
		date = "2026-11-13"
		modified = "2026-11-14"
		reference = "https://github.com/MSNightmare/SignDrop"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_signdrop_clfs_lpe_nov26.yar#L2-L32"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4365c73a49c30c7659abf578ba2bb2538f9dad34e3daaa038b941a610a9d7b78"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "\\??\\%TEMP%\\SigDrop_" wide
		$x2 = "\\BaseNamedObjects\\Restricted\\mpasbase.vdm" wide
		$x3 = "\\CLFS%ws\\%ws" wide
		$x4 = "Failed to create CLFS containers, error : %d" ascii
		$x5 = "Failed to create clfs log file, error : 0x%0.8X" ascii
		$s1 = "%ws.cnpf" wide
		$s2 = "\\\\.\\GlobalRoot\\BaseNamedObjects\\Restricted\\" wide
		$s3 = "\\Common Files\\microsoft shared\\ink\\hid.dll" wide
		$s4 = "IMpService77BDAF73-B396-481F-9042-AD358843EC24" wide
		$s5 = "MpEngine.dll" wide fullword
		$s6 = "Failed to create bait file, error : 0x%0.8X" ascii
		$s7 = "This machine is not vulnerable." ascii
		$s8 = "\\Program Files\\Common Files\\microsoft shared\\ink" wide

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 10MB and ( 1 of ( $x* ) or 4 of ( $s* ) )
}
rule SIGNATURE_BASE_EXPL_Signdrop_Payload_DLL_Nov26 : FILE
{
	meta:
		description = "Detects the hid.dll payload of the SignDrop CLFS privilege escalation exploit, which gets loaded as SYSTEM on the UAC secure desktop, switches to the user's default desktop, starts conhost.exe as SYSTEM and terminates consent.exe. Also matches SignDrop executables that embed the payload as a resource."
		author = "Florian Roth"
		id = "83685599-e0f1-5e92-b595-fd586682e4ac"
		date = "2026-11-13"
		modified = "2026-11-14"
		reference = "https://github.com/MSNightmare/SignDrop"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_signdrop_clfs_lpe_nov26.yar#L34-L81"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "c799634115525db95295f18e339a143a0fd1c6ba3a249269b5d00db97b35418d"
		logic_hash = "ece1f4185793566886c185b650d548a902ec182e8b7fe69ba88658e8ff4bb459"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "\\source\\repos\\hid\\x64\\Release\\hid.pdb" ascii
		$s1 = "WinSta0\\Default" wide fullword
		$s2 = "C:\\Windows\\System32\\conhost.exe" wide fullword
		$s3 = "consent.exe" wide fullword
		$op1 = {
         41 B9 00 00 00 10     // mov     r9d, 10000000h; dwDesiredAccess = GENERIC_ALL
         48 8D 0D ?? ?? ?? ??  // lea     rcx, aDefault; lpszDesktop
         45 33 C0              // xor     r8d, r8d; fInherit
         33 D2                 // xor     edx, edx; dwFlags
         FF 15                 // call    cs:__imp_OpenDesktopW
      }
		$op2 = {
         C7 44 24 28 10 02 00 01  // mov     dword ptr [rsp+28h], 1000210h; dwCreationFlags
         89 44 24 20              // mov     [rsp+20h], eax; bInheritHandles = FALSE
      }
		$op3 = {
         44 8B 84 24 ?? ?? 00 00  // mov     r8d, [rsp+...]; dwProcessId = th32ProcessID
         33 D2                    // xor     edx, edx; bInheritHandle
         B9 01 00 00 00           // mov     ecx, 1; dwDesiredAccess = PROCESS_TERMINATE
         FF 15 ?? ?? ?? ??        // call    cs:__imp_OpenProcess
         48 8B C8                 // mov     rcx, rax; hProcess
         33 D2                    // xor     edx, edx; uExitCode
         48 8B D8                 // mov     rbx, rax
         FF 15                    // call    cs:__imp_TerminateProcess
      }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 10MB and ( $x1 and 1 of ( $s* ) or all of ( $s* ) and 1 of ( $op* ) )
}
rule SIGNATURE_BASE_SUSP_CLFS_Auth_File_Redirect_Exploit_Nov26 : FILE
{
	meta:
		description = "Detects executables that combine direct access to the CLFS device namespace, CLFS authentication file (.cnpf) references and object manager symbolic link creation, a combination used by exploits like SignDrop to redirect CLFS authentication file creation to an attacker-chosen path."
		author = "Florian Roth"
		id = "c6e236f7-a823-530e-a96c-847c2bbd8aa8"
		date = "2026-11-13"
		modified = "2026-11-14"
		reference = "https://github.com/MSNightmare/SignDrop"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_signdrop_clfs_lpe_nov26.yar#L83-L109"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7eb3ac8282e4627c242eb147ac9c9a78b41906a8810bcd2162451d40f6622b77"
		score = 65
		quality = 83
		tags = "FILE"

	strings:
		$clfs1 = "\\CLFS\\" ascii wide
		$clfs2 = "\\CLFS%" ascii wide
		$cnpf = ".cnpf" ascii wide
		$sym1 = "NtCreateSymbolicLinkObject" ascii
		$ns1 = "\\BaseNamedObjects\\Restricted" ascii wide
		$ns2 = "\\RPC Control\\" ascii wide
		$ns3 = "\\GlobalRoot\\" ascii wide nocase

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 20MB and 1 of ( $clfs* ) and $cnpf and $sym1 and 1 of ( $ns* )
}
rule SIGNATURE_BASE_APT_UNC2447_MAL_SOMBRAT_May21_1 : FILE
{
	meta:
		description = "Detects SombRAT samples from UNC2447 campaign"
		author = "Florian Roth (Nextron Systems)"
		id = "78b46bed-4fd4-596f-bba7-12243f467af3"
		date = "2021-05-01"
		modified = "2023-01-07"
		reference = "https://www.fireeye.com/blog/threat-research/2021/04/unc2447-sombrat-and-fivehands-ransomware-sophisticated-financial-threat.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_unc2447_sombrat.yar#L2-L36"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "61e286c62e556ac79b01c17357176e58efb67d86c5d17407e128094c3151f7f9"
		hash = "99baffcd7a6b939b72c99af7c1e88523a50053ab966a079d9bf268aff884426e"
		logic_hash = "6f2572745cbd68c5f2be5c64b160d2513938daba6da57523012491acc63cfee4"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "~arungvc" ascii fullword
		$s1 = "plugin64_" ascii
		$s2 = "0xUnknown" ascii fullword
		$s3 = "b%x.%s" ascii fullword
		$s4 = "/news" ascii
		$sc1 = { 00 73 00 65 00 72 00 76 00 69 00 63 00 65 00 73
               00 2E 00 65 00 78 00 65 00 00 00 00 00 00 00 00
               00 49 73 57 6F 77 36 34 50 72 6F 63 65 73 73 00
               00 6B 00 65 00 72 00 6E 00 65 00 6C 00 33 00 32
               00 00 00 00 00 00 00 00 00 47 00 6C 00 6F 00 62
               00 61 00 6C 00 5C 00 25 00 73 }
		$op1 = { 66 90 0f b6 45 80 32 44 0d 81 34 de 88 44 0d 81 48 ff c1 48 83 f9 19 72 e9 }
		$op2 = { 48 8b d0 66 0f 6f 05 ?1 ?? 0? 00 f3 0f 7f 44 24 68 66 89 7c 24 58 41 b8 10 00 00 00 4c 39 40 10 4c 0f 42 40 10 48 83 78 18 08 }
		$op3 = { 49 f7 b0 a0 00 00 00 42 0f b6 04 0a 41 30 44 33 fe 48 83 79 18 10 72 03 48 8b 09 33 d2 b8 05 00 00 00 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 3000KB and ( ( 1 of ( $x* ) and 1 of ( $s* ) ) or 3 of them ) or 5 of them
}
rule SIGNATURE_BASE_APT_UNC2447_MAL_RANSOM_Hellokitty_May21_1 : FILE
{
	meta:
		description = "Detects HelloKitty Ransomware samples from UNC2447 campaign"
		author = "Florian Roth (Nextron Systems)"
		id = "c84b2430-dcf1-5a80-96a0-02d292ea386b"
		date = "2021-05-01"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2021/04/unc2447-sombrat-and-fivehands-ransomware-sophisticated-financial-threat.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_unc2447_sombrat.yar#L38-L72"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "02a08b994265901a649f1bcf6772bc06df2eb51eb09906af9fd0f4a8103e9851"
		hash = "0e5f7737704c8f25b2b8157561be54a463057cd4d79c7e016c30a1cf6590a85c"
		hash = "52dace403e8f9b4f7ea20c0c3565fa11b6953b404a7d49d63af237a57b36fd2a"
		hash = "7be901c5f7ffeb8f99e4f5813c259d0227335680380ed06df03fb836a041cb06"
		hash = "947e357bfdfe411be6c97af6559fd1cdc5c9d6f5cea122bf174d124ee03d2de8"
		hash = "9a7daafc56300bd94ceef23eac56a0735b63ec6b9a7a409fb5a9b63efe1aa0b0"
		hash = "a147945635d5bd0fa832c9b55bc3ebcea7a7787e8f89b98a44279f8eddda2a77"
		hash = "bade05a30aba181ffbe4325c1ba6c76ef9e02cbe41a4190bd3671152c51c4a7b"
		hash = "c2498845ed4b287fd0f95528926c8ee620ef0cbb5b27865b2007d6379ffe4323"
		hash = "dc007e71085297883ca68a919e37687427b7e6db0c24ca014c148f226d8dd98f"
		hash = "ef614b456ca4eaa8156a895f450577600ad41bd553b4512ae6abf3fb8b5eb04e"
		logic_hash = "acc0ab5502d53c6e22c8650c29c5459a6106f33c398e4efcd963f54971a0c870"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$xop1 = { 8b 45 08 8b 75 f4 fe 85 f7 fd ff ff 0f 11 44 05 b4 83 c0 10 89 45 08 83 f8 30 7c 82 }
		$xop2 = { 81 c3 dc a9 b0 5c c1 c9 0b 33 c8 89 55 a0 8b c7 8b 7d e0 c1 c8 06 33 f7 }
		$s1 = "select * from Win32_ShadowCopy" wide fullword
		$s2 = "bootfont.bin" wide fullword
		$s3 = "DECRYPT_NOTE.txt" wide fullword
		$s4 = ".onion" wide
		$sop1 = { 8b f9 0f 57 c0 68 18 01 00 00 6a 00 0f 11 45 dc 8d 5f 20 53 0f 11 45 ec }
		$sop2 = { 56 57 8b f9 0f 57 c0 68 18 01 00 00 6a 00 0f 11 45 dc 8d 5f 20 }
		$sop3 = { 57 8b f9 0f 57 c0 68 18 01 00 00 6a 00 0f 11 45 dc 8d 5f 20 53 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 800KB and 1 of ( $x* ) or 3 of them
}
rule SIGNATURE_BASE_APT_UNC2447_MAL_RANSOM_Hellokitty_May21_2 : FILE
{
	meta:
		description = "Detects HelloKitty Ransomware samples from UNC2447 campaign"
		author = "Florian Roth (Nextron Systems)"
		id = "82aaabc6-102a-512e-8c2a-4d6fda864c68"
		date = "2021-05-01"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2021/04/unc2447-sombrat-and-fivehands-ransomware-sophisticated-financial-threat.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_unc2447_sombrat.yar#L74-L99"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "10887d13dba1f83ef34e047455a04416d25a83079a7f3798ce3483e0526e3768"
		hash = "3ae7bedf236d4e53a33f3a3e1e80eae2d93e91b1988da2f7fcb8fde5dcc3a0e9"
		hash = "501487b025f25ddf1ca32deb57a2b4db43ccf6635c1edc74b9cff54ce0e5bcfe"
		hash = "9a7daafc56300bd94ceef23eac56a0735b63ec6b9a7a409fb5a9b63efe1aa0b0"
		logic_hash = "1eee3a00ab3f70425d2b6bf5dc507155bf504b851ddb6515602d83d8b6a254b8"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$xop1 = { 50 8d 45 f8 50 ff 75 fc ff 15 ?? ?? 42 00 3d ea 00 00 00 75 18 83 7d f8 00 }
		$s1 = "HelloKittyMutex" wide
		$s2 = "%s\\read_me_lkd.txt" wide fullword
		$s3 = "/C ping 127.0.0.1 & del %s" wide fullword
		$s4 = "(%d) [%d] %s: STOP DOUBLE PROCESS RUN" ascii fullword
		$sop1 = { 6a 00 6a 01 ff 75 fc ff 15 ?? ?? 42 00 85 c0 0f 94 c3 ff 75 fc ff 15 ?? ?? 42 00 }
		$sop2 = { 74 12 6a 00 6a 01 ff 75 fc ff 15 ?? ?? 42 00 85 c0 0f 94 c3 ff 75 fc }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 600KB and 1 of ( $x* ) or 2 of them
}
rule SIGNATURE_BASE_APT_UNC2447_PS1_WARPRISM_May21_1 : FILE
{
	meta:
		description = "Detects WARPRISM PowerShell samples from UNC2447 campaign"
		author = "Florian Roth (Nextron Systems)"
		id = "fa389a45-3b31-5a84-9882-49fd6ee8cac5"
		date = "2021-05-01"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2021/04/unc2447-sombrat-and-fivehands-ransomware-sophisticated-financial-threat.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_unc2447_sombrat.yar#L101-L119"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "3090bff3d16b0b150444c3bfb196229ba0ab0b6b826fa306803de0192beddb80"
		hash = "63ba6db8c81c60dd9f1a0c7c4a4c51e2e56883f063509ed7b543ad7651fd8806"
		hash = "b41a303a4caa71fa260dd601a796033d8bfebcaa6bd9dfd7ad956fac5229a735"
		logic_hash = "09abac2be0f12d31dabfdae9e8a148a28887a2a5df003c7bcb56ba45f1c6a62c"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "if ($MyInvocation.MyCommand.Path -match '\\S') {" ascii fullword
		$s1 = "[DllImport(\"kernel32.dll\")]public static extern IntPtr VirtualAlloc(IntPtr " ascii wide
		$s2 = "[Runtime.InteropServices.Marshal]::Copy($" ascii wide
		$s3 = "[System.Diagnostics.Process]::Start((-join(" ascii wide

	condition:
		filesize < 5000KB and 1 of ( $x* ) or 2 of them
}
rule SIGNATURE_BASE_APT_UNC2447_BAT_Runner_May21_1 : FILE
{
	meta:
		description = "Detects Batch script runners from UNC2447 campaign"
		author = "Florian Roth (Nextron Systems)"
		id = "0bacd4f7-421a-570f-9f74-5a19ab806dd0"
		date = "2021-05-01"
		modified = "2023-01-07"
		reference = "https://www.fireeye.com/blog/threat-research/2021/04/unc2447-sombrat-and-fivehands-ransomware-sophisticated-financial-threat.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_unc2447_sombrat.yar#L121-L135"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "ccacf4658ae778d02e4e55cd161b5a0772eb8b8eee62fed34e2d8f11db2cc4bc"
		logic_hash = "f9872327f648e4421aa40ca3ce55df5d3eb5e8c5bc718ff62a3d4adac79217eb"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "powershell.exe -c \"[System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String([IO.File]::" ascii
		$x2 = "wwansvc.txt')))\" | powershell.exe -" ascii

	condition:
		filesize < 5000KB and 1 of them
}
rule SIGNATURE_BASE_APT_MAL_LNX_Kobalos : FILE
{
	meta:
		description = "Kobalos malware"
		author = "Marc-Etienne M.Leveille"
		id = "dfa47e30-c093-57f6-af01-72a2534cc6f4"
		date = "2020-11-02"
		modified = "2023-12-05"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_lnx_kobalos.yar#L32-L57"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "48aec47b70633d4c8cb55d90a2e168f3c2027ef27cfe1cd5d30dcdc08a2ff717"
		score = 75
		quality = 85
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$encrypted_strings_sizes = {
            05 00 00 00 09 00 00 00  04 00 00 00 06 00 00 00
            08 00 00 00 08 00 00 00  02 00 00 00 02 00 00 00
            01 00 00 00 01 00 00 00  05 00 00 00 07 00 00 00
            05 00 00 00 05 00 00 00  05 00 00 00 0A 00 00 00
        }
		$password_md5_digest = { 3ADD48192654BD558A4A4CED9C255C4C }
		$rsa_512_mod_header = { 10 11 02 00 09 02 00 }
		$strings_rc4_key = { AE0E05090F3AC2B50B1BC6E91D2FE3CE }

	condition:
		uint16( 0 ) == 0x457f and any of them
}
rule SIGNATURE_BASE_APT_MAL_LNX_Kobalos_SSH_Credential_Stealer : FILE
{
	meta:
		description = "Kobalos SSH credential stealer seen in OpenSSH client"
		author = "Marc-Etienne M.Leveille"
		id = "0f923f92-c5d8-500d-9a2e-634ca7945c5c"
		date = "2020-11-02"
		modified = "2023-12-05"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_lnx_kobalos.yar#L59-L76"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "fdabaea0c838e43b8716bcd102bdeebf2f08fc041b0b909333e3d9d6f94391fc"
		score = 75
		quality = 85
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$ = "user: %.128s host: %.128s port %05d user: %.128s password: %.128s"

	condition:
		uint16( 0 ) == 0x457f and any of them
}
rule SIGNATURE_BASE_MAL_LNX_Linadoor_Rootkit_May22 : FILE
{
	meta:
		description = "Detects LinaDoor Linux Rootkit"
		author = "Florian Roth"
		id = "e2f250b4-9a8a-5d70-83d7-5d12ad3763fb"
		date = "2022-05-19"
		modified = "2023-05-16"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_lnx_linadoor_rootkit.yar#L2-L37"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "25ff1efe36eb15f8e19411886217d4c9ec30b42dca072b1bf22f041a04049cd9"
		hash = "4792e22d4c9996af1cb58ed54fee921a7a9fdd19f7a5e7f268b6793cdd1ab4e7"
		hash = "9067230a0be61347c0cf5c676580fc4f7c8580fc87c932078ad0c3f425300fb7"
		hash = "940b79dc25d1988dabd643e879d18e5e47e25d0bb61c1f382f9c7a6c545bfcff"
		hash = "a1df5b7e4181c8c1c39de976bbf6601a91cde23134deda25703bc6d9cb499044"
		hash = "c4eea99658cd82d48aaddaec4781ce0c893de42b33376b6c60a949008a3efb27"
		hash = "c5651add0c7db3bbfe0bbffe4eafe9cd5aa254d99be7e3404a2054d6e07d20e7"
		logic_hash = "546c34d4c204c7266884bb3b5b6ada418e83029ab88f72e5ffb094f50d9ed28e"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "/dev/net/.../rootkit_/" ascii
		$s2 = "did_exec" ascii fullword
		$s3 = "rh_reserved_tp_target" ascii fullword
		$s4 = "HIDDEN_SERVICES" ascii fullword
		$s5 = "bypass_udp_ports" ascii fullword
		$s6 = "DoBypassIP" ascii fullword
		$op1 = { 74 2a 4c 89 ef e8 00 00 00 00 48 89 da 4c 29 e2 48 01 c2 31 c0 4c 39 f2 }
		$op2 = { e8 00 00 00 00 48 89 da 4c 29 e2 48 01 c2 31 c0 4c 39 f2 48 0f 46 c3 5b }
		$op3 = { 48 89 c3 74 2a 4c 89 ef e8 00 00 00 00 48 89 da 4c 29 e2 48 01 c2 31 c0 }
		$op4 = { 4c 29 e2 48 01 c2 31 c0 4c 39 f2 48 0f 46 c3 5b 41 5c 41 5d }
		$fp1 = "/wgsyncdaemon.pid"

	condition:
		uint16( 0 ) == 0x457f and filesize < 2000KB and 2 of them and not 1 of ( $fp* ) or 4 of them
}
rule SIGNATURE_BASE_MAL_RANSOM_Crime_Dearcry_Mar2021_1 : FILE
{
	meta:
		description = "Triggers on strings of known DearCry samples"
		author = "Nils Kuhnert"
		id = "d9714502-f1ea-5fe8-b0ac-1f7a9a30d8f5"
		date = "2021-03-12"
		modified = "2023-12-05"
		reference = "https://twitter.com/phillip_misner/status/1370197696280027136"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_dearcry_ransom.yar#L1-L27"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "2b9838da7edb0decd32b086e47a31e8f5733b5981ad8247a2f9508e232589bff"
		hash = "e044d9f2d0f1260c3f4a543a1e67f33fcac265be114a1b135fd575b860d2b8c6"
		hash = "feb3e6d30ba573ba23f3bd1291ca173b7879706d1fe039c34d53a4fdcdf33ede"
		logic_hash = "e55507475888087c84f9624f82516e8a40aaf59bf2fbea72129a1dd134b28110"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = ".TIF .TIFF .PDF .XLS .XLSX .XLTM .PS .PPS .PPT .PPTX .DOC .DOCX .LOG .MSG .RTF .TEX .TXT .CAD .WPS .EML .INI .CSS .HTM .HTML  .XHTML .JS .JSP .PHP .KEYCHAIN .PEM .SQL .APK .APP .BAT .CGI .ASPX .CER .CFM .C .CPP .GO .CONFIG .PL .PY .DWG .XML .JPG .BMP .PNG .EXE .DLL .CAD .AVI .H.CSV .DAT .ISO .PST .PGD  .7Z .RAR .ZIP .ZIPX .TAR .PDB .BIN .DB .MDB .MDF .BAK .LOG .EDB .STM .DBF .ORA .GPG .EDB .MFS" ascii
		$s1 = "create rsa error" ascii fullword
		$s2 = "DEARCRY!" ascii fullword
		$s4 = "/readme.txt" ascii fullword
		$s5 = "msupdate" ascii fullword
		$s6 = "Your file has been encrypted!" ascii fullword
		$s7 = "%c:\\%s" ascii fullword
		$s8 = "C:\\Users\\john\\" ascii
		$s9 = "EncryptFile.exe.pdb" ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize > 1MB and filesize < 2MB and ( 1 of ( $x* ) or 3 of them ) or 5 of them
}
rule SIGNATURE_BASE_MAL_CRIME_RANSOM_Dearcry_Mar21_1 : FILE
{
	meta:
		description = "Detects DearCry Ransomware affecting Exchange servers"
		author = "Florian Roth (Nextron Systems)"
		id = "96cd2fe8-8bb9-5a3b-9bf1-c63a1148a817"
		date = "2021-03-12"
		modified = "2023-12-05"
		reference = "https://twitter.com/phillip_misner/status/1370197696280027136"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_dearcry_ransom.yar#L29-L53"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "2b9838da7edb0decd32b086e47a31e8f5733b5981ad8247a2f9508e232589bff"
		hash = "e044d9f2d0f1260c3f4a543a1e67f33fcac265be114a1b135fd575b860d2b8c6"
		hash = "feb3e6d30ba573ba23f3bd1291ca173b7879706d1fe039c34d53a4fdcdf33ede"
		logic_hash = "c4af7c29e917078f8658aca68ec95f8a03934f42c81fdd421639437e24f304bc"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "dear!!!" ascii fullword
		$s2 = "EncryptFile.exe.pdb" ascii fullword
		$s3 = "/readme.txt" ascii fullword
		$s4 = "C:\\Users\\john\\" ascii
		$s5 = "And please send me the following hash!" ascii fullword
		$op1 = { 68 e0 30 52 00 6a 41 68 a5 00 00 00 6a 22 e8 81 d0 f8 ff 83 c4 14 33 c0 5e }
		$op2 = { 68 78 6a 50 00 6a 65 6a 74 6a 10 e8 d9 20 fd ff 83 c4 14 33 c0 5e }
		$op3 = { 31 40 00 13 31 40 00 a4 31 40 00 41 32 40 00 5f 33 40 00 e5 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 4000KB and 3 of them or 5 of them
}
rule SIGNATURE_BASE_MAL_RANSOM_Conticrypter
{
	meta:
		description = "Signature for a crypter associated with Conti"
		author = "James Quinn, Binary Defense"
		id = "f2a00655-41a2-5614-9c29-3629c93c0e95"
		date = "2021-03-17"
		modified = "2023-12-05"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_ransom_conti.yar#L2-L16"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "256fbd028a91da45049e2e861e16e97201f09cb92ab049eda373c80e6a796726"
		score = 75
		quality = 85
		tags = ""
		tlp = "White"

	strings:
		$handoff1 = {4C 8D 05 ?? ?? ?? ?? 48 C7 44 24 28 00 00 00 00 C7 44 24 20 00 00 00 00 e8}
		$handoff2 = {C7 ?? 24 ?? 00 00 00 00 89 44 24 ?? C7 ?? 24 ?? ?? ?? ?? ?? C7 ?? 24 ?? 00 00 00 00 }
		$garbageLoad1 = {53 48 83 EC 20 89 CB 48 8D 0D ?? ?? ?? ?? FF 15 ?? ?? ?? ?? 01 D8 48 83 C4 20 5B C3}
		$garbageLoad2 = {55 89 E5 83 EC 18 C7 ?? 24 ?? ?? ?? ?? FF 15 ?? ?? ?? ?? 03 45 08 52 C9 C3}

	condition:
		1 of ( $handoff* ) and 1 of ( $garbageLoad* )
}
rule SIGNATURE_BASE_MAL_LNX_PLAGUE_BACKDOOR_Jul25 : FILE
{
	meta:
		description = "Detects Plague backdoor ELF binaries, related to PAM authentication alteration."
		author = "Pezier Pierre-Henri"
		id = "2c2e9030-fcef-58c9-9ed2-798560b8b384"
		date = "2025-07-25"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_lnx_plague.yar#L1-L29"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "14b0c90a2eff6b94b9c5160875fcf29aff15dcfdfd3402d953441d9b0dca8b39"
		hash = "7c3ada3f63a32f4727c62067d13e40bcb9aa9cbec8fb7e99a319931fc5a9332e"
		logic_hash = "9ef7d8153c8567f85b8713467bf5b175e0c2af050e1f275fb2441bbca8d20a79"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "decrypt_phrase"
		$s2 = "init_phrases"
		$x1 = "captured_password"
		$x2 = "updateklog"
		$x3 = "init_cred_structs"
		$xop1 = {
         48 8b [4] 00    // mov     rax, cs:_ent_ptr
         8b 00           // mov     eax, [rax]
         3d ca b2 e9 f1  // cmp     eax, 0F1E9B2CAh
         74              // jz      short loc_4586
      }

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 1MB and 2 of them
}
rule SIGNATURE_BASE_LOG_EXPL_SUSP_Teamcity_CVE_2023_42793_Oct23_1 : CVE_2023_42793
{
	meta:
		description = "Detects log entries that could indicate a successful exploitation of CVE-2023-42793 on TeamCity servers"
		author = "Florian Roth"
		id = "81c04863-72aa-5515-889e-3ef718360cac"
		date = "2023-10-02"
		modified = "2023-12-05"
		reference = "https://attackerkb.com/topics/1XEEEkGHzt/cve-2023-42793/rapid7-analysis"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_teamcity_2023_42793.yar#L2-L18"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3b6c8e3e3ff91563899ca94904a56460cd702a3e58e0aacf1c3acb506ec3f959"
		score = 70
		quality = 85
		tags = "CVE-2023-42793"

	strings:
		$sa1 = "File edited: "
		$sa2 = "\\TeamCity\\config\\internal.properties by user with id="
		$sb1 = "s.buildServer.ACTIVITIES.AUDIT - server_file_change: File "
		$sb2 = "\\TeamCity\\config\\internal.properties was modified by \"user with id"

	condition:
		all of ( $sa* ) or all of ( $sb* )
}
rule SIGNATURE_BASE_LOG_EXPL_SUSP_Teamcity_Oct23_1
{
	meta:
		description = "Detects log entries that could indicate a successful exploitation of TeamCity servers"
		author = "Florian Roth"
		id = "4845b40a-cf77-53ae-b2fa-d1ed861153f2"
		date = "2023-10-02"
		modified = "2023-12-05"
		reference = "https://attackerkb.com/topics/1XEEEkGHzt/cve-2023-42793/rapid7-analysis"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_teamcity_2023_42793.yar#L20-L34"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a2f0abffb9c72e6b32875310e5af7365b6cab4e6c4f6188daa3085b57c38ed0e"
		score = 70
		quality = 85
		tags = ""

	strings:
		$a1 = "tbrains.buildServer.ACTIVITIES"
		$s1 = "External process is launched by user user with id"
		$s2 = ". Command line: cmd.exe \"/c whoami"

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Crime_Win32_Rat_Parallax_Shell_Bin : FILE
{
	meta:
		description = "Detects Parallax injected code"
		author = "@VK_Intel"
		id = "6bb337ef-3156-589a-9b2f-fa1b21699433"
		date = "2020-05-05"
		modified = "2023-12-05"
		reference = "https://twitter.com/VK_Intel/status/1257714191902937088"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_rat_parallax.yar#L2-L16"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6b8c71cc19ca6f066d27a4e58d9ec347ac51d245308f2c41adf2386242581610"
		score = 75
		quality = 85
		tags = "FILE"
		tlp = "white"

	strings:
		$ntdll_load = {55 8b ec 81 ec d0 08 00 00 53 56 57 e8 ?? ?? ?? ?? 89 ?? ?? ?? ?? ?? 8d ?? ?? ?? ?? ?? 33 c0 b9 18 01 00 00 f3 ?? 68 02 9f e6 6a e8 ?? ?? ?? ?? 8b d8 68 40 5e c0 84 89 ?? ?? e8 ?? ?? ?? ?? 6a 00 8b f0 68 0b 1c 64 72 53 89 ?? ?? e8 ?? ?? ?? ?? 83 c4 14 89 ?? ?? ?? ?? ?? 8d ?? ?? ?? ?? ?? 68 30 02 00 00 51 ff d0 6a 6e 58 6a 74 66 ?? ?? ?? ?? ?? ?? 58 6a 64 59 6a 6c 66 ?? ?? ?? ?? ?? ?? 58 66 ?? ?? ?? ?? ?? ?? 66 ?? ?? ?? ?? ?? ?? 66 ?? ?? ?? ?? ?? ?? 66 ?? ?? ?? ?? ?? ?? 33 c0 6a 2e}
		$call_func = {81 ec bc 00 00 00 8d ?? ?? 56 50 6a 00 6a 01 ff ?? ?? e8 ?? ?? ?? ?? 8b f0 83 c4 10 85 f6 0f ?? ?? ?? ?? ?? 33 c9 89 ?? ?? 39 ?? ?? 0f ?? ?? ?? ?? ?? 8b ?? ?? 53 57 8b ?? ?? 8d ?? ?? 0f ?? ?? ?? 8b ?? ?? 8d ?? ?? 8b ?? ?? 03 fa 8b df 2b da 03 ?? ?? 80 ?? ?? 0f ?? ?? ?? ?? ?? 83 ?? ?? ?? 8b c7 83 ?? ?? ?? 83 ?? ?? ?? 83 ?? ?? ?? 83 ?? ?? ?? 83 ?? ?? ?? 99 89 ?? ?? 8b ca 89 ?? ?? 8d ?? ?? 99 89 ?? ?? 89 ?? ?? 8d ?? ?? 89 ?? ?? 89 ?? ?? 8b ca 99 89 ?? ?? 89 ?? ?? 8b ca 89 ?? ?? 89 ?? ?? 8d ?? ?? 6a 40 89 ?? ??}
		$cryp_hex = {8b ec 8b ?? ?? 25 55 55 55 55 d1 e0 8b ?? ?? d1 e9 81 e1 55 55 55 55 0b c1 89 ?? ?? 8b ?? ?? 81 e2 33 33 33 33 c1 e2 02 8b ?? ?? c1 e8 02 25 33 33 33 33 0b d0 89 ?? ?? 8b ?? ?? 81 e1 0f 0f 0f 0f c1 e1 04 8b ?? ?? c1 ea 04 81 e2 0f 0f 0f 0f 0b ca 89 ?? ?? 8b ?? ?? c1 e0 18 8b ?? ?? 81 e1 00 ff 00 00 c1 e1 08 0b c1 8b ?? ?? c1 ea 08 81 e2 00 ff 00 00 0b c2 8b ?? ?? c1 e9 18 0b c1 89 ?? ?? 8b ?? ?? 5d c3}

	condition:
		uint16( 0 ) == 0x5a4d and 2 of them or all of them
}
rule SIGNATURE_BASE_MAL_RANSOM_COVID19_Apr20_1 : FILE
{
	meta:
		description = "Detects ransomware distributed in COVID-19 theme"
		author = "Florian Roth (Nextron Systems)"
		id = "fc723d1f-e969-5af6-af57-70d00bf797f4"
		date = "2020-04-15"
		modified = "2023-12-05"
		reference = "https://unit42.paloaltonetworks.com/covid-19-themed-cyber-attacks-target-government-and-medical-organizations/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_covid_ransom.yar#L2-L20"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "2779863a173ff975148cb3156ee593cb5719a0ab238ea7c9e0b0ca3b5a4a9326"
		logic_hash = "9b32ce1dff9d27c5f7541de97cd1198b0d837a69ee260b327c66a22ca6f30091"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "/savekey.php" wide
		$op1 = { 3f ff ff ff ff ff 0b b4 }
		$op2 = { 60 2e 2e 2e af 34 34 34 b8 34 34 34 b8 34 34 34 }
		$op3 = { 1f 07 1a 37 85 05 05 36 83 05 05 36 83 05 05 34 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 700KB and 2 of them
}
rule SIGNATURE_BASE_APT_APT29_NOBELIUM_JS_Envyscout_May21_1 : FILE
{
	meta:
		description = "Detects EnvyScout deobfuscator code as used by NOBELIUM group"
		author = "Florian Roth (Nextron Systems)"
		id = "42739aad-a88a-545b-8256-1f727c79c4f8"
		date = "2021-05-29"
		modified = "2025-03-21"
		reference = "https://www.microsoft.com/security/blog/2021/05/28/breaking-down-nobeliums-latest-early-stage-toolset/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt29_nobelium_may21.yar#L56-L67"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ad8a7bb5a1d2065e3a573842fb37ee3c63b7695c18840f0c26d32e6ae3d99c6c"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "[i].charCodeAt(0) ^ 2);}"

	condition:
		filesize < 5000KB and 1 of them
}
rule SIGNATURE_BASE_APT_APT29_NOBELIUM_JS_Envyscout_May21_2 : FILE
{
	meta:
		description = "Detects EnvyScout deobfuscator code as used by NOBELIUM group"
		author = "Florian Roth (Nextron Systems)"
		id = "d5cf3365-fe24-533a-a678-b5b6d4d99997"
		date = "2021-05-29"
		modified = "2025-03-21"
		reference = "https://www.microsoft.com/security/blog/2021/05/28/breaking-down-nobeliums-latest-early-stage-toolset/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt29_nobelium_may21.yar#L69-L83"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6f5c50b340d628559799897a2ba79add7d126e3ecb2daeb365bc15d64796ccd2"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "saveAs(blob, " ascii
		$s2 = ".iso\");" ascii
		$s3 = "application/x-cd-image" ascii
		$s4 = ".indexOf(\"Win\")!=-1" ascii

	condition:
		filesize < 5000KB and all of them
}
rule SIGNATURE_BASE_APT_APT29_NOBELIUM_LNK_NV_Link_May21_2 : FILE
{
	meta:
		description = "Detects NV Link as used by NOBELIUM group"
		author = "Florian Roth (Nextron Systems)"
		id = "52c2caf9-13df-5614-9c9e-afcd76ec77f9"
		date = "2021-05-29"
		modified = "2025-03-21"
		reference = "https://www.microsoft.com/security/blog/2021/05/28/breaking-down-nobeliums-latest-early-stage-toolset/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt29_nobelium_may21.yar#L85-L97"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "5eee9df368da3fc98c00a0f8c65a7f3bd5b812342082be58054b272b5bb03455"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "RegisterOCX BOOM" ascii wide
		$s2 = "cmd.exe /c start BOOM.exe" ascii wide

	condition:
		filesize < 5000KB and 1 of them
}
rule SIGNATURE_BASE_APT_APT29_NOBELIUM_LNK_Samples_May21_1 : FILE
{
	meta:
		description = "Detects link file characteristics as described in APT29 NOBELIUM report"
		author = "Florian Roth (Nextron Systems)"
		id = "c807ab5a-f66a-5622-81b1-6e69b6df8446"
		date = "2021-05-27"
		modified = "2025-03-21"
		reference = "https://www.microsoft.com/security/blog/2021/05/27/new-sophisticated-email-based-attack-from-nobelium/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt29_nobelium_may21.yar#L99-L128"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "24caf54e7c3fe308444093f7ac64d6d520c8f44ea4251e09e24931bdb72f5548"
		logic_hash = "32d76bb1af76f0fc2afb76d9726bc8ec99c4be34c9d46cebab7356d8c68af11c"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "rundll32.exe" wide
		$sa1 = "IMGMountingService.dll" wide
		$sa2 = "MountImgHelper" wide
		$sb1 = "diassvcs.dll" wide
		$sb2 = "InitializeComponent" wide
		$sc1 = "MsDiskMountService.dll" wide
		$sc2 = "DiskDriveIni" wide
		$sd1 = "GraphicalComponent.dll" wide
		$sd2 = "VisualServiceComponent" wide
		$se1 = "data/mstu.dll,MicrosoftUpdateService" wide

	condition:
		uint16( 0 ) == 0x004c and filesize < 4KB and $a1 and ( all of ( $sa* ) or all of ( $sb* ) or all of ( $sc* ) or all of ( $sd* ) or all of ( $se* ) )
}
rule SIGNATURE_BASE_APT_APT29_NOBELIUM_Boombox_May21_1 : FILE
{
	meta:
		description = "Detects BoomBox malware as described in APT29 NOBELIUM report"
		author = "Florian Roth"
		id = "1a14dcf7-81be-5a74-a530-caf6268d1976"
		date = "2021-05-27"
		modified = "2025-03-20"
		reference = "https://www.microsoft.com/security/blog/2021/05/27/new-sophisticated-email-based-attack-from-nobelium/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt29_nobelium_may21.yar#L130-L161"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "8199f309478e8ed3f03f75e7574a3e9bce09b4423bd7eb08bb5bff03af2b7c27"
		logic_hash = "034ea34eb34ea6de0c65b9a7fc9d16f108ef34cd75294b022371ac17789c3830"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "]::FromBase64String($" ascii wide
		$xa1 = "123do3y4r378o5t34onf7t3o573tfo73" ascii wide fullword
		$xa2 = "1233t04p7jn3n4rg" ascii wide fullword
		$s1 = "\\Release\\BOOM.pdb" ascii
		$s2 = "/files/upload" ascii
		$s3 = "/tmp/readme.pdf" ascii fullword
		$s4 = "/new/{0}" ascii fullword
		$s5 = "(&(objectClass=user)(objectCategory=person))"

	condition:
		( uint16( 0 ) == 0x5a4d or 1 of ( $a* ) ) and ( 1 of ( $x* ) or 3 of ( $s* ) )
}
rule SIGNATURE_BASE_APT_APT29_NOBELIUM_Nativezone_Loader_May21_1 : FILE
{
	meta:
		description = "Detects NativeZone loader as described in APT29 NOBELIUM report"
		author = "Florian Roth (Nextron Systems)"
		id = "02d9257d-f439-5071-96b0-a973b088e329"
		date = "2021-05-27"
		modified = "2025-03-21"
		reference = "https://www.microsoft.com/security/blog/2021/05/27/new-sophisticated-email-based-attack-from-nobelium/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt29_nobelium_may21.yar#L184-L204"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "136f4083b67bc8dc999eb15bb83042aeb01791fc0b20b5683af6b4ddcf0bbc7d"
		logic_hash = "a02fd6fcd7423781bbd2e4458bd61d28e16a5b1a73b1682e63db5c86d53c7da4"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "\\SystemCertificates\\Lib\\CertPKIProvider.dll" ascii
		$s2 = "rundll32.exe %s %s" ascii fullword
		$s3 = "eglGetConfigs" ascii fullword
		$op1 = { 80 3d 74 8c 01 10 00 0f 85 96 00 00 00 33 c0 40 b9 6c 8c 01 10 87 01 33 db 89 5d fc }
		$op2 = { 8b 46 18 e9 30 ff ff ff 90 87 2f 00 10 90 2f 00 10 }
		$op3 = { e8 14 dd ff ff 8b f1 80 3d 74 8c 01 10 00 0f 85 96 00 00 00 33 c0 40 b9 6c 8c 01 10 87 01 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 3000KB and 3 of them or 4 of them
}
rule SIGNATURE_BASE_APT_APT29_NOBELIUM_Boombox_May21_2 : FILE
{
	meta:
		description = "Detects BoomBox malware used by APT29 / NOBELIUM"
		author = "Florian Roth (Nextron Systems)"
		id = "a4144c00-48b2-5520-b773-5d0a5de95fb1"
		date = "2021-05-29"
		modified = "2025-03-21"
		reference = "https://www.microsoft.com/security/blog/2021/05/28/breaking-down-nobeliums-latest-early-stage-toolset/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt29_nobelium_may21.yar#L206-L234"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0acb884f2f4cfa75b726cb8290b20328c8ddbcd49f95a1d761b7d131b95bafec"
		hash = "8199f309478e8ed3f03f75e7574a3e9bce09b4423bd7eb08bb5bff03af2b7c27"
		hash = "cf1d992f776421f72eabc31d5afc2f2067ae856f1c9c1d6dc643a67cb9349d8c"
		logic_hash = "2a3829e704af2464639d07e8e7952669281e20cf2a7ac487d5d1eee021d08b35"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "\\Microsoft\\NativeCache\\NativeCacheSvc.dll" wide
		$x2 = "\\NativeCacheSvc.dll _configNativeCache" wide
		$a1 = "/content.dropboxapi.com" wide fullword
		$s1 = "rundll32.exe {0} {1}" wide fullword
		$s2 = "\\\\CertPKIProvider.dll" wide
		$s3 = "/tmp/readme.pdf" wide
		$s4 = "temp/[^\"]*)\"" wide fullword
		$op1 = { 00 78 00 2d 00 41 00 50 00 49 00 2d 00 41 00 72 00 67 00 01 2f 4f 00 72 00 }
		$op2 = { 25 72 98 01 00 70 6f 34 00 00 0a 25 6f 35 00 00 0a 72 71 02 00 70 72 }
		$op3 = { 4d 05 20 00 12 80 91 04 20 01 08 0e 04 20 00 12 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 40KB and 3 of them or 4 of them
}
rule SIGNATURE_BASE_APT_APT29_NOBELIUM_Malware_May21_2 : FILE
{
	meta:
		description = "Detects malware used by APT29 / NOBELIUM"
		author = "Florian Roth (Nextron Systems)"
		id = "b1462b4b-227f-5aeb-92ea-bda6a86831c7"
		date = "2021-05-29"
		modified = "2025-03-21"
		reference = "https://www.microsoft.com/security/blog/2021/05/28/breaking-down-nobeliums-latest-early-stage-toolset/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt29_nobelium_may21.yar#L236-L252"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "292e5b0a12fea4ff3fc02e1f98b7a370f88152ce71fe62670dd2f5edfaab2ff8"
		hash = "776014a63bf3cc7034bd5b6a9c36c75a930b59182fe232535bb7a305e539967b"
		logic_hash = "18a52f5fd71455b8564d4b485c233dd358a304bfddc5e6fb604b8e5a2a1949a3"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$op1 = { 48 03 c8 42 0f b6 04 21 88 03 0f b6 43 01 8b c8 83 e0 0f 48 83 e1 f0 48 03 c8 }
		$op2 = { 48 03 c8 42 0f b6 04 21 88 43 01 41 0f b6 c7 8b c8 83 e0 0f 48 83 e1 f0 48 03 c8 }
		$op3 = { 45 0f b6 43 ff 41 8b c2 99 44 88 03 41 0f b6 2b 83 e2 03 03 c2 40 88 6b 01 }

	condition:
		filesize < 2200KB and all of them
}
rule SIGNATURE_BASE_APT_APT29_NOBELIUM_Stageless_Loader_May21_2 : FILE
{
	meta:
		description = "Detects stageless loader as used by APT29 / NOBELIUM"
		author = "Florian Roth (Nextron Systems)"
		id = "7b83d327-52fc-5401-ae35-00f6b825678a"
		date = "2021-05-29"
		modified = "2025-03-21"
		reference = "https://www.microsoft.com/security/blog/2021/05/28/breaking-down-nobeliums-latest-early-stage-toolset/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt29_nobelium_may21.yar#L254-L276"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "a4f1f09a2b9bc87de90891da6c0fca28e2f88fd67034648060cef9862af9a3bf"
		hash = "c4ff632696ec6e406388e1d42421b3cd3b5f79dcb2df67e2022d961d5f5a9e78"
		logic_hash = "850f6a1ad342fd5e4bb29c7bf90a032ddd8ac9d2eac5ffcbedf43e4d04b178f5"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "DLL_stageless.dll" ascii fullword
		$s1 = "c:\\users\\devuser\\documents" ascii fullword nocase
		$s2 = "VisualServiceComponent" ascii fullword
		$s3 = "CheckUpdteFrameJavaCurrentVersion" ascii fullword
		$op1 = { a3 d? 6? 04 10 ff d6 33 05 00 ?0 0? 10 68 d8 d4 00 10 57 a3 d? 6? 04 10 ff d6 33 05 00 ?0 0? 10 }
		$op2 = { ff d6 33 05 00 ?0 0? 10 68 d8 d4 00 10 57 a3 d? 6? 04 10 ff d6 33 05 00 ?0 0? 10 68 e8 d4 00 10 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 900KB and 2 of them or 3 of them
}
rule SIGNATURE_BASE_APT_APT29_NOBELIUM_Malware_May21_3 : FILE
{
	meta:
		description = "Detects malware used by APT29 / NOBELIUM"
		author = "Florian Roth (Nextron Systems)"
		id = "89cb6884-4242-5b5a-b0ac-b31041dd261c"
		date = "2021-05-29"
		modified = "2025-03-21"
		reference = "https://www.microsoft.com/security/blog/2021/05/28/breaking-down-nobeliums-latest-early-stage-toolset/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt29_nobelium_may21.yar#L278-L300"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "2a352380d61e89c89f03f4008044241a38751284995d000c73acf9cad38b989e"
		logic_hash = "472acd1d6daf3480de59ecd3fa038d644e339dcc979cf7e56617eadc6cb32dc5"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Win32Project1.dll" ascii fullword
		$op1 = { 59 c3 6a 08 68 70 5e 01 10 e8 d2 8c ff ff 8b 7d 08 8b c7 c1 f8 05 }
		$op2 = { 8d 4d f0 e8 c4 12 00 00 68 64 5b 01 10 8d 45 f0 c7 45 f0 6c 01 01 10 50 e8 ea 13 00 00 cc }
		$op4 = { 40 c3 8b 65 e8 e8 a6 86 ff ff cc 6a 0c 68 88 60 01 10 e8 b0 4d ff ff }
		$xc1 = { 25 73 25 73 00 00 00 00 2F 65 2C 20 00 00 00 00
               43 00 3A 00 5C 00 77 00 69 00 6E 00 64 00 6F 00
               77 00 73 00 5C 00 65 00 78 00 70 00 6C 00 6F 00
               72 00 65 00 72 00 2E 00 65 00 78 00 65 }

	condition:
		filesize < 3000KB and ( $xc1 or 3 of them )
}
rule SIGNATURE_BASE_APT_APT29_NOBELIUM_Malware_May21_4 : FILE
{
	meta:
		description = "Detects malware used by APT29 / NOBELIUM"
		author = "Florian Roth (Nextron Systems)"
		id = "56193475-52b4-5720-abc5-72249e2a0c37"
		date = "2021-05-29"
		modified = "2025-03-21"
		reference = "https://www.microsoft.com/security/blog/2021/05/28/breaking-down-nobeliums-latest-early-stage-toolset/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt29_nobelium_may21.yar#L302-L323"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "3b94cc71c325f9068105b9e7d5c9667b1de2bde85b7abc5b29ff649fd54715c4"
		logic_hash = "7d5858cc6dab094d5dceab75a2002d9145537008241a08ac7bd399c9d6e6c270"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "KM.FileSystem.dll" ascii fullword
		$op1 = { 80 3d 50 6b 04 10 00 0f 85 96 00 00 00 33 c0 40 b9 48 6b 04 10 87 01 33 db 89 5d fc }
		$op2 = { c3 33 c0 b9 7c 6f 04 10 40 87 01 c3 8b ff 55 }
		$op3 = { 8d 4d f4 e8 53 ff ff ff 68 d0 22 01 10 8d 45 f4 50 e8 d8 05 00 00 cc 8b 41 04 }
		$xc1 = { 2E 64 6C 6C 00 00 00 00 41 53 4B 4F 44 00 00 00
               53 75 63 63 65 73 73 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 3000KB and ( $xc1 or 3 of them )
}
rule SIGNATURE_BASE_HKTL_Natbypass_Dec22_1 : T1090 FILE
{
	meta:
		description = "Detects NatBypass tool (also used by APT41)"
		author = "Florian Roth (Nextron Systems)"
		id = "54af4d84-72f7-5ec4-b0bf-7ba228fdf508"
		date = "2022-12-27"
		modified = "2023-12-05"
		reference = "https://github.com/cw1997/NATBypass"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/hktl_natbypass.yar#L2-L24"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "4550635143c9997d5499d1d4a4c860126ee9299311fed0f85df9bb304dca81ff"
		logic_hash = "8af76d7d9d4500dc219090fbd8ca8cd9fd17bfc224f14a411febfd6f75b92206"
		score = 80
		quality = 85
		tags = "T1090, FILE"

	strings:
		$x1 = "nb -slave 127.0.0.1:3389 8.8.8.8:1997" ascii
		$x2 = "| Welcome to use NATBypass Ver" ascii
		$s1 = "main.port2host.func1" ascii fullword
		$s2 = "start to transmit address:" ascii
		$s3 = "^(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])"

	condition:
		filesize < 8000KB and ( 1 of ( $x* ) or 2 of them ) or 3 of them
}
rule SIGNATURE_BASE_SUSP_PS1_Msdt_Execution_May22 : CVE_2022_30190 FILE
{
	meta:
		description = "Detects suspicious calls of msdt.exe as seen in CVE-2022-30190 / Follina exploitation"
		author = "Nasreddine Bencherchali, Christian Burkard"
		id = "a1863582-87a2-5d07-a549-ef4a31bf0ed2"
		date = "2022-05-31"
		modified = "2025-03-21"
		reference = "https://doublepulsar.com/follina-a-microsoft-office-code-execution-vulnerability-1a47fce5629e"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_doc_follina.yar#L2-L37"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9b8a061de4210d23e58b5190a300ee331273fc98f357156a0bb1d79f9f2b49b1"
		score = 65
		quality = 85
		tags = "CVE-2022-30190, FILE"

	strings:
		$a = "PCWDiagnostic" ascii wide fullword
		$sa1 = "msdt.exe" ascii wide
		$sa2 = "msdt " ascii wide
		$sa3 = "ms-msdt" ascii wide
		$sb1 = "/af " ascii wide
		$sb2 = "-af " ascii wide
		$sb3 = "IT_BrowseForFile=" ascii wide
		$fp1 = { 4F 00 72 00 69 00 67 00 69 00 6E 00 61 00 6C 00
               46 00 69 00 6C 00 65 00 6E 00 61 00 6D 00 65 00
               00 00 70 00 63 00 77 00 72 00 75 00 6E 00 2E 00
               65 00 78 00 65 00 }
		$fp2 = "FilesFullTrust" wide
		$fp3 = "Cisco Spark" ascii wide
		$fp4 = "author: " ascii

	condition:
		filesize < 10MB and $a and 1 of ( $sa* ) and 1 of ( $sb* ) and not 1 of ( $fp* ) and not uint8( 0 ) == 0x7B
}
rule SIGNATURE_BASE_SUSP_Doc_Wordxmlrels_May22 : CVE_2022_30190 FILE
{
	meta:
		description = "Detects a suspicious pattern in docx document.xml.rels file as seen in CVE-2022-30190 / Follina exploitation"
		author = "Tobias Michalski, Christian Burkard, Wojciech Cieslak"
		id = "304c4816-b2f6-5319-9fe9-8f74bdb82ad0"
		date = "2022-05-30"
		modified = "2022-06-20"
		reference = "https://doublepulsar.com/follina-a-microsoft-office-code-execution-vulnerability-1a47fce5629e"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_doc_follina.yar#L39-L61"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "62f262d180a5a48f89be19369a8425bec596bc6a02ed23100424930791ae3df0"
		logic_hash = "c9846f8c2c1724792de14ab4de0064f951a8faaf01cc27d873e600f29d59c842"
		score = 70
		quality = 85
		tags = "CVE-2022-30190, FILE"

	strings:
		$a1 = "<Relationships" ascii
		$a2 = "TargetMode=\"External\"" ascii
		$x1 = ".html!" ascii
		$x2 = ".htm!" ascii
		$x3 = "%2E%68%74%6D%6C%21" ascii
		$x4 = "%2E%68%74%6D%21" ascii

	condition:
		filesize < 50KB and all of ( $a* ) and 1 of ( $x* )
}
rule SIGNATURE_BASE_SUSP_Doc_RTF_Externalresource_May22 : CVE_2022_30190 FILE
{
	meta:
		description = "Detects a suspicious pattern in RTF files which downloads external resources as seen in CVE-2022-30190 / Follina exploitation"
		author = "Tobias Michalski, Christian Burkard"
		id = "71bb97e0-ec12-504c-a1f6-25039ac91c86"
		date = "2022-05-30"
		modified = "2022-05-31"
		reference = "https://doublepulsar.com/follina-a-microsoft-office-code-execution-vulnerability-1a47fce5629e"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_doc_follina.yar#L63-L79"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c841e0c1ff78bf8dade5f573a7452b16a7f447cfc19417704b727684a8f3d3ff"
		score = 70
		quality = 85
		tags = "CVE-2022-30190, FILE"

	strings:
		$s1 = " LINK htmlfile \"http" ascii
		$s2 = ".html!\" " ascii

	condition:
		uint32be( 0 ) == 0x7B5C7274 and filesize < 300KB and all of them
}
rule SIGNATURE_BASE_EXPL_Follina_CVE_2022_30190_Msdt_Msprotocoluri_May22 : CVE_2022_30190 FILE
{
	meta:
		description = "Detects the malicious usage of the ms-msdt URI as seen in CVE-2022-30190 / Follina exploitation"
		author = "Tobias Michalski, Christian Burkard"
		id = "62e67c25-a420-5dac-9d1c-b0648ea6b574"
		date = "2022-05-30"
		modified = "2022-07-18"
		reference = "https://doublepulsar.com/follina-a-microsoft-office-code-execution-vulnerability-1a47fce5629e"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_doc_follina.yar#L81-L99"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "4a24048f81afbe9fb62e7a6a49adbd1faf41f266b5f9feecdceb567aec096784"
		hash = "778cbb0ee4afffca6a0b788a97bc2f4855ceb69ddc5eaa230acfa2834e1aeb07"
		logic_hash = "d56820737951f97606749c74025589e6a8ecbe70cfff069492368b2ba8528a7d"
		score = 80
		quality = 85
		tags = "CVE-2022-30190, FILE"

	strings:
		$re1 = /location\.href\s{0,20}=\s{0,20}"ms-msdt:/
		$a1 = "%6D%73%2D%6D%73%64%74%3A%2F" ascii

	condition:
		filesize > 3KB and filesize < 100KB and 1 of them
}
rule SIGNATURE_BASE_SUSP_Doc_RTF_Ole2Link_Jun22 : FILE
{
	meta:
		description = "Detects a suspicious pattern in RTF files which downloads external resources"
		author = "Christian Burkard"
		id = "e9c83d58-6214-51d5-882a-4bd2ed6acc9a"
		date = "2022-06-01"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_doc_follina.yar#L101-L132"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "4abc20e5130b59639e20bd6b8ad759af18eb284f46e99a5cc6b4f16f09456a68"
		logic_hash = "36cb711399197c694ac4fa4fd49cd5d587a830e152a138c81851b8e16301803d"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$sa = "\\objdata" ascii nocase
		$sb1 = "4f4c45324c696e6b" ascii
		$sb2 = "4F4C45324C696E6B" ascii
		$sc1 = "d0cf11e0a1b11ae1" ascii
		$sc2 = "D0CF11E0A1B11AE1" ascii
		$x1 = "68007400740070003a002f002f00" ascii
		$x2 = "68007400740070003A002F002F00" ascii
		$x3 = "680074007400700073003a002f002f00" ascii
		$x4 = "680074007400700073003A002F002F00" ascii
		$x5 = "6600740070003a002f002f00" ascii
		$x6 = "6600740070003A002F002F00" ascii

	condition:
		( uint32be( 0 ) == 0x7B5C7274 or uint32be( 0 ) == 0x7B5C2A5C ) and $sa and 1 of ( $sb* ) and 1 of ( $sc* ) and 1 of ( $x* )
}
rule SIGNATURE_BASE_SUSP_Doc_RTF_Ole2Link_EMAIL_Jun22 : FILE
{
	meta:
		description = "Detects a suspicious pattern in RTF files which downloads external resources inside e-mail attachments"
		author = "Christian Burkard"
		id = "48cde505-3ce4-52ef-b338-0c08ac4f63de"
		date = "2022-06-01"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_doc_follina.yar#L134-L193"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "4abc20e5130b59639e20bd6b8ad759af18eb284f46e99a5cc6b4f16f09456a68"
		logic_hash = "fcbb3e32762f8c67b5b226e8095b767d630f8c118521a82fc22f9a3cc272b794"
		score = 75
		quality = 83
		tags = "FILE"

	strings:
		$sa1 = "XG9iamRhdG" ascii
		$sa2 = "xvYmpkYXRh" ascii
		$sa3 = "cb2JqZGF0Y" ascii
		$sb1 = "NGY0YzQ1MzI0YzY5NmU2Y" ascii
		$sb2 = "RmNGM0NTMyNGM2OTZlNm" ascii
		$sb3 = "0ZjRjNDUzMjRjNjk2ZTZi" ascii
		$sb4 = "NEY0QzQ1MzI0QzY5NkU2Q" ascii
		$sb5 = "RGNEM0NTMyNEM2OTZFNk" ascii
		$sb6 = "0RjRDNDUzMjRDNjk2RTZC" ascii
		$sc1 = "ZDBjZjExZTBhMWIxMWFlM" ascii
		$sc2 = "QwY2YxMWUwYTFiMTFhZT" ascii
		$sc3 = "kMGNmMTFlMGExYjExYWUx" ascii
		$sc4 = "RDBDRjExRTBBMUIxMUFFM" ascii
		$sc5 = "QwQ0YxMUUwQTFCMTFBRT" ascii
		$sc6 = "EMENGMTFFMEExQjExQUUx" ascii
		$x1 = "NjgwMDc0MDA3NDAwNzAwMDNhMDAyZjAwMmYwM" ascii
		$x2 = "Y4MDA3NDAwNzQwMDcwMDAzYTAwMmYwMDJmMD" ascii
		$x3 = "2ODAwNzQwMDc0MDA3MDAwM2EwMDJmMDAyZjAw" ascii
		$x4 = "NjgwMDc0MDA3NDAwNzAwMDNBMDAyRjAwMkYwM" ascii
		$x5 = "Y4MDA3NDAwNzQwMDcwMDAzQTAwMkYwMDJGMD" ascii
		$x6 = "2ODAwNzQwMDc0MDA3MDAwM0EwMDJGMDAyRjAw" ascii
		$x7 = "NjgwMDc0MDA3NDAwNzAwMDczMDAzYTAwMmYwMDJmMD" ascii
		$x8 = "Y4MDA3NDAwNzQwMDcwMDA3MzAwM2EwMDJmMDAyZjAw" ascii
		$x9 = "2ODAwNzQwMDc0MDA3MDAwNzMwMDNhMDAyZjAwMmYwM" ascii
		$x10 = "NjgwMDc0MDA3NDAwNzAwMDczMDAzQTAwMkYwMDJGMD" ascii
		$x11 = "Y4MDA3NDAwNzQwMDcwMDA3MzAwM0EwMDJGMDAyRjAw" ascii
		$x12 = "2ODAwNzQwMDc0MDA3MDAwNzMwMDNBMDAyRjAwMkYwM" ascii
		$x13 = "NjYwMDc0MDA3MDAwM2EwMDJmMDAyZjAw" ascii
		$x14 = "Y2MDA3NDAwNzAwMDNhMDAyZjAwMmYwM" ascii
		$x15 = "2NjAwNzQwMDcwMDAzYTAwMmYwMDJmMD" ascii
		$x16 = "NjYwMDc0MDA3MDAwM0EwMDJGMDAyRjAw" ascii
		$x17 = "Y2MDA3NDAwNzAwMDNBMDAyRjAwMkYwM" ascii
		$x18 = "2NjAwNzQwMDcwMDAzQTAwMkYwMDJGMD" ascii

	condition:
		filesize < 10MB and 1 of ( $sa* ) and 1 of ( $sb* ) and 1 of ( $sc* ) and 1 of ( $x* )
}
rule SIGNATURE_BASE_SUSP_DOC_RTF_Externalresource_EMAIL_Jun22 : CVE_2022_30190 FILE
{
	meta:
		description = "Detects a suspicious pattern in RTF files which downloads external resources as seen in CVE-2022-30190 / Follina exploitation inside e-mail attachment"
		author = "Christian Burkard"
		id = "3ddc838c-8520-5572-9652-8cb823f83e27"
		date = "2022-06-01"
		modified = "2026-05-15"
		reference = "https://doublepulsar.com/follina-a-microsoft-office-code-execution-vulnerability-1a47fce5629e"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_doc_follina.yar#L195-L221"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "73e76bd80f77640c0d8d47ebb7903eb9cc23336fbe653e7d008cae6a0de7c45b"
		score = 70
		quality = 85
		tags = "CVE-2022-30190, FILE"

	strings:
		$sa1 = "PFJlbGF0aW9uc2hpcH" ascii
		$sa2 = "xSZWxhdGlvbnNoaXBz" ascii
		$sa3 = "8UmVsYXRpb25zaGlwc" ascii
		$sb1 = "VGFyZ2V0TW9kZT0iRXh0ZXJuYWwi" ascii
		$sb2 = "RhcmdldE1vZGU9IkV4dGVybmFsI" ascii
		$sb3 = "UYXJnZXRNb2RlPSJFeHRlcm5hbC" ascii
		$sc1 = "Lmh0bWwhI" ascii
		$sc2 = "5odG1sIS" ascii
		$sc3 = "uaHRtbCEi" ascii

	condition:
		filesize < 400KB and 1 of ( $sa* ) and 1 of ( $sb* ) and 1 of ( $sc* )
}
rule SIGNATURE_BASE_SUSP_Msdt_Artefact_Jun22_2 : CVE_2022_30190 FILE
{
	meta:
		description = "Detects suspicious pattern in msdt diagnostics log (e.g. CVE-2022-30190 / Follina exploitation)"
		author = "Christian Burkard"
		id = "aa2a4bd7-2094-5652-a088-f58d0c7d3f62"
		date = "2022-06-01"
		modified = "2022-07-29"
		reference = "https://twitter.com/nas_bench/status/1531718490494844928"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_doc_follina.yar#L223-L242"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e18f6405f0411128335336e65dda4ed2b6be6e9ad47b94646ececf0479fbe967"
		score = 75
		quality = 85
		tags = "CVE-2022-30190, FILE"

	strings:
		$a1 = "<ScriptError><Data id=\"ScriptName\" name=\"Script\">TS_ProgramCompatibilityWizard.ps1" ascii
		$x1 = "/../../" ascii
		$x2 = "$(Invoke-Expression" ascii
		$x3 = "$(IEX(" ascii nocase

	condition:
		uint32( 0 ) == 0x6D783F3C and $a1 and 1 of ( $x* )
}
rule SIGNATURE_BASE_SUSP_LNK_Follina_Jun22 : CVE_2022_30190 FILE
{
	meta:
		description = "Detects LNK files with suspicious Follina/CVE-2022-30190 strings"
		author = "Paul Hager"
		id = "d331d584-2ab3-5275-b435-6129c7291417"
		date = "2022-06-02"
		modified = "2026-05-15"
		reference = "https://twitter.com/gossithedog/status/1531650897905950727"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_doc_follina.yar#L244-L262"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "0b63bb266b968987b2b5a83c9429e96acbd57e12178e4f5fd5894b23d1aaa237"
		score = 75
		quality = 85
		tags = "CVE-2022-30190, FILE"

	strings:
		$sa1 = "msdt.exe" ascii wide
		$sa2 = "msdt " ascii wide
		$sa3 = "ms-msdt:" ascii wide
		$sb = "IT_BrowseForFile=" ascii wide

	condition:
		filesize < 5KB and uint16( 0 ) == 0x004c and uint32( 4 ) == 0x00021401 and 1 of ( $sa* ) and $sb
}
rule SIGNATURE_BASE_SUSP_RDP_File_Indicators_Oct24_1 : FILE
{
	meta:
		description = "Detects characteristics found in malicious RDP files used as email attachments in spear phishing campaigns"
		author = "Florian Roth"
		id = "16128c1e-64ed-5a3e-ad1e-e0330d91f5a9"
		date = "2024-10-25"
		modified = "2024-12-12"
		reference = "https://thecyberexpress.com/rogue-rdp-files-used-in-ukraine-cyberattacks/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nobellium_rdp_phish.yar#L2-L24"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "280fbf353fdffefc5a0af40c706377142fff718c7b87bc8b0daab10849f388d0"
		hash = "8b45f5a173e8e18b0d5c544f9221d7a1759847c28e62a25210ad8265f07e96d5"
		hash = "9b8cb8b01ce4eafb9204250a3c28bfaf70cc76a99ce411ad52bbf1aa2b6cce34"
		hash = "ba4d58f2c5903776fe47c92a0ec3297cc7b9c8fa16b3bf5f40b46242e7092b46"
		hash = "f357d26265a59e9c356be5a8ddb8d6533d1de222aae969c2ad4dc9c40863bfe8"
		logic_hash = "55bd63738c38719ce7aeb874956488b0d3f7167a31d880ee61994b5921bd1458"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "redirectclipboard:i:1" wide fullword
		$s2 = "redirectprinters:i:1" wide fullword
		$s3 = "remoteapplicationmode:i:1" wide fullword
		$s4 = "username:s:" wide
		$s5 = "emoteapplicationicon:s:C:\\Windows\\SystemApps" wide

	condition:
		filesize < 50KB and all of them
}
rule SIGNATURE_BASE_MAL_Cisco_Rayinitiator_Stage_1
{
	meta:
		description = "Detects RayInitiator GRUB bootkit stage 1 code that searches for the 'Booting the kernel' string."
		author = "NCSC"
		id = "5631f2c5-5141-5039-9cd0-a35314aa0bd5"
		date = "2025-09-25"
		modified = "2026-05-15"
		reference = "https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cisco_asa_lineviper_rayinitiator_sep25.yar#L1-L20"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e657de97954545f06fc6997a3221eb77037fb89c6c56f08eeb78be615512a3e4"
		score = 85
		quality = 85
		tags = ""

	strings:
		$xc1 = {
         BB 00 00 40 00 43 81 FB 00 00 60 00 0F 87 AB 00 00 00
         8B 3B 81 FF 64 6F 6E 65 75 E9 83 C3 04 8B 3B 81 FF 2E 0A 42 6F 75
         DC 83 C3 04 8B 3B 81 FF 6F 74 69 6E 75 CF 83 C3 04 8B 3B 81 FF 67
         20 74 68 75 C2 83 C3 04 8B 3B 81 FF 65 20 6B 65 75 B5 83 C3 04 8B
         3B 81 FF 72 6E 65 6C 75 A8 83 EB 14
      }

	condition:
		$xc1
}
rule SIGNATURE_BASE_MAL_Cisco_Rayinitiator_Stage_2
{
	meta:
		description = "Detects RayInitiator GRUB bootkit stage 2 code that identifies the Linux kernel syscall table."
		author = "NCSC"
		id = "c49bdbe7-eba6-562c-8388-5e638887b405"
		date = "2025-09-25"
		modified = "2026-05-15"
		reference = "https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cisco_asa_lineviper_rayinitiator_sep25.yar#L22-L39"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "27f040bc14caec745f04fa32de08955a09857a801e5f2f04936fffca991c9d19"
		score = 85
		quality = 85
		tags = ""

	strings:
		$xc1 = {
         49 89 E0 48 83 F8 30 0F 84 70 00 00 00 49 01 C0 49 8B
         10 48 83 C0 08 66 85 D2 75 E4 BF ?? ?? 60 00 48 8B 3C 17 48 BE 6E
         6D 69 5F 6D 61 78 5F
      }

	condition:
		$xc1
}
rule SIGNATURE_BASE_MAL_Cisco_Rayinitiator_Stage_3
{
	meta:
		description = "Detects RayInitiator GRUB bootkit stage 3 install phase code that searches for the 'client-cert-fail' string."
		author = "NCSC"
		id = "ea42c20b-7362-5d2d-9ce2-ad010f3f880d"
		date = "2025-09-25"
		modified = "2026-05-15"
		reference = "https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cisco_asa_lineviper_rayinitiator_sep25.yar#L41-L58"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "332756bc77cc17c3330ce1ffb0af9d1a7c0f5f9a457f7e9ad7f4081d7aba50c6"
		score = 85
		quality = 85
		tags = ""

	strings:
		$xc1 = {
         48 81 EE 00 00 00 08 48 B8 63 6C 69 65 6E 74 2D 63 49
         B8 65 72 74 2D 66 61 69 6C 48 FF C6 48 39 D6 0F 87 D2
         00 00 00 48 8B 3E 48 39 C7
      }

	condition:
		$xc1
}
rule SIGNATURE_BASE_MAL_Cisco_Rayinitiator_Stage_3_LINE_VIPER_Shellcode
{
	meta:
		description = "Detects RayInitiator GRUB bootkit stage 3 deploy phase code that copies LINE VIPER shellcode stub and marks executable."
		author = "NCSC"
		id = "91545ed8-b798-5c0c-a229-e7d37ed7d271"
		date = "2025-09-25"
		modified = "2026-05-15"
		reference = "https://www.ncsc.gov.uk/static-assets/documents/malware-analysis-reports/RayInitiator-LINE-VIPER/ncsc-mar-rayinitiator-line-viper.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cisco_asa_lineviper_rayinitiator_sep25.yar#L60-L76"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e509bde73d8843b188d632fa44bb4d90ff9d1766138c830c2932e503c5a07197"
		score = 85
		quality = 85
		tags = ""

	strings:
		$xc1 = {
         48 89 FA 48 83 C7 40 4C 89 CE B9 D0 01 00 00 F3 A4 48
         89 D7 48 83 C7 40 48 89 3A 48 C1 EF 0C 48 C1 E7 0C BA
         07 00 00 00 48 C7 C6 00 20 00 00
      }

	condition:
		$xc1
}
rule SIGNATURE_BASE_MAL_Cisco_LINE_VIPER_Shellcode_Deobfuscation_Routine
{
	meta:
		description = "Detects LINE VIPER Cisco ASA malware code as part of a shellcode deobfuscation routine."
		author = "NCSC"
		id = "608282b5-f296-5d21-b88b-92cd53128d89"
		date = "2025-09-25"
		modified = "2026-05-15"
		reference = "https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cisco_asa_lineviper_rayinitiator_sep25.yar#L78-L98"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9feb3703a99c529b28c12646a0834e77d3377f1fd75ec69c46201cb0d4d22775"
		score = 85
		quality = 85
		tags = ""

	strings:
		$xc1 = {
         48 8B 7F 08 48 8D 5F 70 49 C7 C1 00 18 00 00 49 C7 C0
         20 00 00 00 48 89 DF 8A 01 32 07 48 FF C7 41 FF C8 4D 85 C0 75 F3
         88 01 48 FF C1 41 FF C9 4D 85 C9 75 DA
      }
		$x1 = "SIt/CEiNX3BJx8EAGAAAScfAIAAAAEiJ34oBMgdI/8dB/8hNhcB184gBSP/BQf/JTYXJdd"
		$x2 = "iLfwhIjV9wScfBABgAAEnHwCAAAABIid+KATIHSP/HQf/ITYXAdfOIAUj/wUH/yU2FyXXa"
		$x3 = "Ii38ISI1fcEnHwQAYAABJx8AgAAAASInfigEyB0j/x0H/yE2FwHXziAFI/8FB/8lNhcl12"

	condition:
		1 of them
}
rule SIGNATURE_BASE_MAL_Cisco_LINE_VIPER_Shellcode_Initial_Execution
{
	meta:
		description = "Detects LINE VIPER Cisco ASA malware code as part of shellcode initial execution."
		author = "NCSC (modifier by Florian Roth)"
		id = "ca88eff7-bf0d-5959-b614-1afb6d68879e"
		date = "2025-09-25"
		modified = "2025-09-27"
		reference = "https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cisco_asa_lineviper_rayinitiator_sep25.yar#L100-L123"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "813aa79525bb43f62d98142eced501f793764e90a86c7176a686f9017f32eb4b"
		score = 85
		quality = 85
		tags = ""

	strings:
		$xc1 = {
         48 8D B7 80 00 00 00 BA 00 20 00 00 [19] 48 C7 C6 00
         90 00 00 BA 07 00 00 00
      }
		$xe1 = { 53 49 32 33 67 41 41 41 41 4c 6f 41 49 41 41 41 [26] 6a 48 78 67 43 51 41 41 43 36 42 77 41 41 41 }
		$xe2 = { 69 4e 74 34 41 41 41 41 43 36 41 43 41 41 41 [26] 49 78 38 59 41 6b 41 41 41 75 67 63 41 41 41 }
		$xe3 = { 49 6a 62 65 41 41 41 41 41 75 67 41 67 41 41 [26] 53 4d 66 47 41 4a 41 41 41 4c 6f 48 41 41 41 41 }

	condition:
		1 of them
}
rule SIGNATURE_BASE_MAL_Cisco_LINE_VIPER_RSA_Enc_Random_AES_Key_Gen
{
	meta:
		description = "Detects LINE VIPER Cisco ASA malware code as part of RSA encrypted random AES key generation."
		author = "NCSC"
		id = "ef37a3cf-aab8-513b-b859-7f7704fce622"
		date = "2025-09-25"
		modified = "2026-05-15"
		reference = "https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cisco_asa_lineviper_rayinitiator_sep25.yar#L125-L154"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c382158e21300f49ed3da58e3e02c4578c10fd854c87a18227a01b7d6f7723bc"
		score = 85
		quality = 85
		tags = ""

	strings:
		$xc1 = {
         48 31 C0 49 89 06 49 89 46 08 49 83 C6 10 49 83 ED 10
         4D 85 ED 75 D8 BF 30 00 00 00
      }
		$xc2 = {
         0F 85 57 01 00 00 49 8B 44 24 08 48 83 F8 2F 7C 33 41
         BD F0 02 00 00 4D 8D 74 24 10 49 8B 3E
      }
		$xc3 = {
         85 C0 0F 8E EE 00 00 00 41 BD F0 02 00 00 4D 8D 7C 24
         10 49 8B 3F 48 85 FF 74 0D 49 83 C7 10 49 83 ED 10 4D 85 ED 75 EB
         4D 89 37 BF 70 00 00 00
      }
		$xc4 = {
         48 85 C0 0F 84 3F 00 00 00 48 89 45 B0 BF 80 00 00 00
         4C 89 EE 48 89 C2 48 8B 4D A8 41 B8 01 00 00 00
      }

	condition:
		1 of them
}
rule SIGNATURE_BASE_MAL_Cisco_LINE_VIPER_AES_Enc_Tasking_Exfil
{
	meta:
		description = "Detects LINE VIPER Cisco ASA malware code as part of AES encrypted tasking and exfiltration."
		author = "NCSC"
		id = "9f3d77a6-3e31-588c-a65d-f1f9d9bc84df"
		date = "2025-09-25"
		modified = "2026-05-15"
		reference = "https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cisco_asa_lineviper_rayinitiator_sep25.yar#L156-L185"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b6181701b512709c812f303a33e13115bb52f28be7095c086ef2a3b17f6ef4fd"
		score = 85
		quality = 85
		tags = ""

	strings:
		$ = {
         48 31 C0 48 89 45 D8 49 89 FC 49 89 F5 49 89 D6 48 8B
         47 08 48 89 45 B8 48 8D 40 40 48 89 45 E0 48 8D 70 E0 48 89 75 B0
         48 8D 78 F0 48 89 7D E8 BA 10 00 00 00
      }
		$ = {
         48 85 C0 0F 84 EA 00 00 00 48 89 45 A8 4C 89 EF 48 89
         C6 4C 89 F2 48 8B 4D A0 4C 8B 45 B0 4D 31 C9
      }
		$ = {
         48 85 C0 0F 84 82 00 00 00 49 89 C7 48 8B 7D E0 BE 00
         01 00 00 48 8B 55 A0
      }
		$ = {
         48 8B 7D D0 49 83 C7 10 49 C1 EF 04 49 C1 E7 04 4C 89
         FE 48 8D 55 D8
      }

	condition:
		3 of them
}
rule SIGNATURE_BASE_MAL_Cisco_LINE_VIPER_ICMP_Tasking_Shellcode_Payloads
{
	meta:
		description = "Detects LINE VIPER Cisco ASA malware code as part of ICMP tasking shellcode payloads."
		author = "NCSC"
		id = "7f8df075-8ed6-5d24-9743-cf3da9a48ec4"
		date = "2025-09-25"
		modified = "2026-05-15"
		reference = "https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cisco_asa_lineviper_rayinitiator_sep25.yar#L187-L217"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a11d8cebae498340065244ddaf6863925ef8368cea20af1d1f21c46fc51280ee"
		score = 85
		quality = 85
		tags = ""

	strings:
		$ = {
         55 53 41 54 41 55 41 56 41 57 48 89 E5 48 83 EC 60 48
         31 C0 B9 07 00 00 00 48 8D 7D A8 F3 48 AB BF 01 00 00
         00 BE 30 00 00 00
      }
		$ = {
         49 89 C7 48 C7 C2 38 DF FF FF 64 48 8B 0A 48 8B 99 00
         01 00 00 48 89 81 00 01 00 00
      }
		$ = {
         49 8B 47 10 48 8D 55 B0 BE 01 20 01 00 4C 89 FF FF 90
         90 00 00 00 48 8B 7D B0 48 85 FF 0F 84 3C 00 00 00
      }
		$ = {
         49 8B 47 10 BE 08 20 01 00 4C 89 FF 48 8D 55 A8 FF 90
         90 00 00 00 48 8B 7D B0 49 89 7E 20 48 8B 7D A8 49 89
         7E 28
      }

	condition:
		3 of them
}
rule SIGNATURE_BASE_Octowave_Loader_03_2025 : FILE
{
	meta:
		description = "Detects opcodes found in Octowave loader DLLs and WAV steganography files"
		author = "Jai Minton (@CyberRaiju) - HuntressLabs"
		id = "d583c416-be20-5fcf-848e-edd037e3b0d4"
		date = "2025-03-19"
		modified = "2025-03-21"
		reference = "https://yaratoolkit.securitybreak.io/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_octowave_loader_mar25.yar#L1-L285"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0504bfbacb6e10b81196f625f2fe37b33500e7bf65fd82d3510a2b178c6cd5bd"
		hash = "3a2db0cb9ee01549a6b660d58115d112d36a744d65705394b54d7d95287c7a74"
		hash = "eb50d06057fe123d6e9f7a76d3d1a4bc5307e8f15d017be8f6031e92136cf36a"
		hash = "24715920e749b014ba05f74c96627a27355c5860a14461c106aa48a7aba371ea"
		logic_hash = "266568d5f0f95cc805a833745a9e63689234ae927c2903230438c080f7ec2e56"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$opcode_1 = {
			55
			8B EC
			56
			57
			8B D1
			33 C0
			8B FA
			6A 06
			59
			AB
			AB
			AB
			AB
			8B 45 08
			8B FA
			83 62 10 00
			8B F0
			83 62 14 00
			F3 A5
			83 60 10 00
		}
		$opcode_2 = {
			55
			8B EC
			8B 55 ??
			56
			8B F1
			8B 46 ??
			8B 4E ??
			2B C1
			3B D0
			77 ??
			83 7E ?? 07
			53
			8D 1C 11
			57
			89 5E ??
			8B FE
			76 ??
			8B 3E
			8D 04 12
			50
			FF 75 ??
			8D 0C 4F
			51
			E8 ?? ?? ?? ??
			83 C4 0C
			33 C0
			66 89 04 5F
			8B C6
			5F
			5B
			EB ??
			52
			FF 75 ??
			8B CE
			FF 75 ??
			52
			E8 ?? ?? ?? ??
			5E
			5D
			C2 08 00
		}
		$opcode_3 = {
			55
			8B EC
			8B 4D 08
			83 C9 ??
			56
			3B 4D 10
			77 1C
			8B 75 0C
			8B D6
			8B 45 10
			D1 EA
			2B C2
			3B F0
			77 0C
			8D 04 32
			3B C8
			0F 42 C8
			8B C1
			EB 03
		}
		$opcode_4 = {
			56
			8B F1
			8B 46 14
			83 F8 ??
			76 ??
		}
		$opcode_5 = {
			50
			FF 36
			E8 ?? ?? ?? ??
			59
			59
			83 66 ?? 00
		}
		$opcode_6 = {
			C7 46 14 ?? 00 00 00
			66 89 06
			5E
			C3
		}
		$opcode_7 = {
			55
			8B EC
			51
			51
			A1 ?? ?? ?? ??
			33 C5
			89 45 FC
			8B 4D 0C
			8B 45 08
			89 45 F8
			81 F9 00 10 00 00
			72 ??
			8D 45 0C
			50
			8D 45 F8
			50
			E8 ?? ?? ?? ??
			8B 45 F8
			59
			59
		}

	condition:
		( uint16( 0 ) == ( 0x5a4d ) or uint32( 0 ) == 0x46464952 ) and filesize < 50000KB and all of them
}
rule SIGNATURE_BASE_Octowave_Loader_Supporting_File_03_2025 : FILE
{
	meta:
		description = "Detects supporting file used by Octowave loader containing hardcoded values"
		author = "Jai Minton (@CyberRaiju) - HuntressLabs"
		id = "2c81c8b8-4b4d-55c9-9285-556e8b5303bd"
		date = "2025-03-19"
		modified = "2025-03-21"
		reference = "https://x.com/CyberRaiju/status/1893450184224362946?t=u0X6ST2Qgnrf-ujjphGOSg&s=19"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_octowave_loader_mar25.yar#L287-L312"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "c4cbaa7e4521fa0ed9cc634c5e2bacbf41f46842ca4526b7904d98843a7e9db9"
		hash = "f5cfb2e634539d5dc7ffe202ffdc422ef7457100401ba1fbc21dd05558719865"
		hash = "56f1967f7177c166386d864807cdf03d5bbd3f118a285ce67ea226d02e5cf58c"
		hash = "11ee5ad8a81ae85e5b7ddf93adf6edd20de8460c755bf0426dfcbc7f658d7e85"
		hash = "d218b65493e4d9d85cbc2f7b608f4f7e501708014bc04af27d33d995aa54a703"
		hash = "0c112f9dfe27211b357c74f358d9c144ea10cc0d92d6420b8742b72a65562c5a"
		logic_hash = "42abd38e704a17ef81b423829c2dd356749873a5d036e43cc2746debfb3f5434"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$unique_key = {1D 1C 1F 1E 01 01 03 02 05 04 07 06 09 D4 0E 0A 0D 0C 0F 0E 31 30 31 32 35 34 36 36 39 38 DC 3F 3D 3C 3E}
		$unique_string = "MLONqpsrutwvyx"
		$unique_string2 = "A@CBEDGFIHKJMLONqpsrutwvyx"

	condition:
		uint16( 0 ) != 0x5a4d and filesize < 10000KB and all of them
}

rule SIGNATURE_BASE_SUSP_Fake_AMSI_DLL_Jun23_1 : FILE
{
	meta:
		description = "Detects an amsi.dll that has the same exports as the legitimate one but very different contents or file sizes"
		author = "Florian Roth"
		id = "b12df9de-ecfb-562b-b599-87fa786a33bc"
		date = "2023-06-07"
		modified = "2023-06-12"
		reference = "https://twitter.com/eversinc33/status/1666121784192581633?s=20"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_fake_amsi_dll.yar#L3-L35"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ec3db233ab22144bc65614b45bb894a7ea5a4fd40ccb603e6e52cc1b9ff8805b"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "Microsoft.Antimalware.Scan.Interface" ascii
		$a2 = "Amsi.pdb" ascii fullword
		$a3 = "api-ms-win-core-sysinfo-" ascii
		$a4 = "Software\\Microsoft\\AMSI\\Providers" wide
		$a5 = "AmsiAntimalware@" ascii
		$a6 = "AMSI UAC Scan" ascii
		$fp1 = "Wine builtin DLL"

	condition:
		uint16( 0 ) == 0x5a4d and ( pe.exports ( "AmsiInitialize" ) and pe.exports ( "AmsiScanString" ) ) and ( filesize > 200KB or filesize < 35KB or not 4 of ( $a* ) ) and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_APT_MAL_SLOTHFULMEDIA_Oct20_1 : FILE
{
	meta:
		description = "Detects SLOTHFULMEDIA malware"
		author = "Florian Roth (Nextron Systems)"
		id = "cc413225-f084-5859-bc27-04eb018d8894"
		date = "2020-10-01"
		modified = "2023-12-05"
		reference = "https://us-cert.cisa.gov/ncas/analysis-reports/ar20-275a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_iamtheking.yar#L2-L48"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "64d78eec46c9ddd4b9a366de62ba0f2813267dc4393bc79e4c9a51a9bb7e6273"
		hash = "927d945476191a3523884f4c0784fb71c16b7738bd7f2abd1e3a198af403f0ae"
		hash = "f0503f0131040b805e106eafe64a65d9404a0e279f052237b868e456c34d36e6"
		hash = "ed5258306c06d6fac9b13c99c7c8accc7f7fa0de4cf4de4f7d9eccad916555f5"
		hash = "04ca010f4c8997a023fabacae230698290e3ff918a86703c5e0a2a6983b039eb"
		hash = "cb2adcaaa25bb6b8a9f1c685c219f8d6d78aa5cfd65c633f4d255ff81da2c517"
		logic_hash = "e50bda40eb05767e0903c3d8dd62b4e0290d89740c82c8b7f391d5763dc35156"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$xc1 = { 25 73 26 69 3D 25 64 00 48 54 54 50 2F 31 2E 31
               00 00 00 00 50 4F 53 54 00 00 00 00 43 6F 6E 74
               65 6E 74 2D 4C 65 6E 67 74 68 3A 20 25 64 00 00
               5C 00 53 00 65 00 74 00 75 00 70 00 55 00 69 00
               00 00 00 00 25 00 73 00 25 00 73 00 5F 00 25 00
               64 00 2E 00 64 00 61 00 74 }
		$xc2 = { 2F 76 3F 6D 3D 00 00 00 35 30 31 00 32 30 30 00
               2A 00 2E 00 2A 00 00 00 25 00 73 00 00 00 00 00
               53 00 65 00 44 00 65 00 62 00 75 00 67 00 50 00
               72 00 69 00 76 00 69 00 6C 00 65 00 67 00 65 }
		$xc3 = { 00 25 00 73 00 7C 00 25 00 73 00 7C 00 25 00 73
               00 7C 00 25 00 73 00 00 00 5C 00 46 00 69 00 6C
               00 74 00 65 00 72 00 33 00 2E 00 6A 00 70 00 67 }
		$sc1 = { 25 74 65 6D 70 25 00 00 25 73 5C 25 73 2E 65 78
               65 00 00 00 25 74 65 6D 70 25 00 00 25 73 5C 25
               73 2E 65 78 65 }
		$sc2 = { 61 70 70 6C 69 63 61 74 69 6F 6E 2F 6F 63 74 65
               74 2D 73 74 72 65 61 6D 2C 61 70 70 6C 69 63 61
               74 69 6F 6E 2F 78 68 74 6D 6C 00 00 25 73 26 69
               3D 25 64 00 48 54 54 50 2F 31 2E 31 00 00 00 00
               50 4F 53 54 }
		$s1 = "%s%s_%d.dat" wide fullword
		$s2 = "Local Security Process" wide fullword
		$s3 = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.75" ascii fullword
		$s4 = "Global%s%d" wide fullword
		$s5 = "ExtKeyloggerStart" ascii fullword
		$s6 = "GetExtendedTcpTable" ascii fullword

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 400KB and ( 1 of ( $x* ) or 3 of them ) or 4 of them
}
rule SIGNATURE_BASE_LOG_Proxynotshell_POC_CVE_2022_41040_Nov22 : CVE_2022_41040 CVE_2022_41082
{
	meta:
		description = "Detects logs generated after a successful exploitation using the PoC code against CVE-2022-41040 and CVE-2022-41082 (aka ProxyNotShell) in Microsoft Exchange servers"
		author = "Florian Roth (Nextron Systems)"
		id = "1e47d124-3103-5bf5-946f-b1bb69ff2c8e"
		date = "2022-11-17"
		modified = "2023-12-05"
		reference = "https://github.com/testanull/ProxyNotShell-PoC"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/vuln_proxynotshell_cve_2022_41040.yar#L2-L20"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7f91502fd9c59180970fc4253134582b44ba318db03ef4eb575257b2f3818d94"
		score = 70
		quality = 85
		tags = "CVE-2022-41040, CVE-2022-41082"

	strings:
		$aa1 = " POST " ascii wide
		$aa2 = " GET " ascii wide
		$ab1 = " 200 " ascii wide
		$s01 = "/autodiscover.json x=a" ascii wide
		$s02 = "/autodiscover/admin@localhost/" ascii wide

	condition:
		1 of ( $aa* ) and $ab1 and 1 of ( $s* )
}
rule SIGNATURE_BASE_EXT_NK_GOLDBACKDOOR_Inital_Shellcode
{
	meta:
		description = "Detection for initial shellcode loader used to deploy GOLDBACDOOR"
		author = "Silas Cutler (silas@Stairwell.com)"
		id = "daab8e54-11b3-51cc-8bee-55b078f3e791"
		date = "2022-04-21"
		modified = "2023-12-05"
		reference = "https://stairwell.com/wp-content/uploads/2022/04/Stairwell-threat-report-The-ink-stained-trail-of-GOLDBACKDOOR.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_goldbackdoor.yar#L2-L20"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4df97181037a580098dbe34d3b6ceab5c7b83932f1831c36ee99876a8f1524f9"
		score = 80
		quality = 85
		tags = ""
		version = "0.1"

	strings:
		$ = { C7 45 C4 25 6C 6F 63 50 8D 45 C4 C7 45 C8 61 6C 61 70 8B F9 C7 45
              CC 70 64 61 74 50 B9 BD 88 17 75 C7 45 D0 61 25 5C 6C 8B DA C7 45 D4 6F
              67 5F 67 C7 45 D8 6F 6C 64 2E C7 45 DC 74 78 74 00 }
		$ = { 51 50 57 56 B9 E6 8E 85 35 E8 ?? ?? ?? ?? FF D0 }
		$ = { 6A 40 68 00 10 00 00 52 6A 00 FF 75 E0 B9 E3 18 90 72 E8 ?? ?? ?? ?? FF D0}

	condition:
		all of them
}
rule SIGNATURE_BASE_EXT_NK_GOLDBACKDOOR_Injected_Shellcode
{
	meta:
		description = "Detection for injected shellcode that decodes GOLDBACKDOOR"
		author = "Silas Cutler (silas@Stairwell.com)"
		id = "aa921f01-98cc-51ab-877a-e7beede77e36"
		date = "2022-04-21"
		modified = "2023-12-05"
		reference = "https://stairwell.com/wp-content/uploads/2022/04/Stairwell-threat-report-The-ink-stained-trail-of-GOLDBACKDOOR.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_goldbackdoor.yar#L22-L42"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b45f408c0f342591e66ef0dfcfc1c09f8558c5e8f4bd7f824b30f00d531c7511"
		score = 80
		quality = 85
		tags = ""
		version = "0.1"

	strings:
		$dec_routine = { 8A 19 57 8B FA 8B 51 01 83 C1 05 85 D2 74 0E 56 8B C1 8B F2 30 18 40 83 EE 01 75 F8 5E 57 }
		$rtlfillmemory_load = { B9 4B 17 CD 5B 55 56 33 ED 55 6A 10 50 E8 86 00 00 00 FF D0 }
		$ = "StartModule"
		$log_file_name = { C7 44 24 3C 25 6C 6F 63 50 8D 44 24 40 C7 44 24 44 61 6C 
                           61 70 50 B9 BD 88 17 75 C7 44 24 4C 70 64 61 74 C7 44 24 
                           50 61 25 5C 6C C7 44 24 54 6F 67 5F 67 C7 44 24 58 6F 6C
                           64 32 C7 44 24 5C 2E 74 78 74 }
		$ = { B9 8E 8A DD 8D 8B F0 E8 E9 FB FF FF FF D0 }

	condition:
		3 of them
}
rule SIGNATURE_BASE_EXT_NK_GOLDBACKDOOR_Generic_Shellcode
{
	meta:
		description = "Generic detection for shellcode used to drop GOLDBACKDOOR"
		author = "Silas Cutler (silas@Stairwell.com)"
		id = "70081d63-0b26-5358-8444-5adc3a44aaa0"
		date = "2022-04-21"
		modified = "2023-12-05"
		reference = "https://stairwell.com/wp-content/uploads/2022/04/Stairwell-threat-report-The-ink-stained-trail-of-GOLDBACKDOOR.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_goldbackdoor.yar#L44-L58"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e046a70b1dee020ba73d960a9d91daaccd0b5c262965c8647f608c5c83a28257"
		score = 75
		quality = 85
		tags = ""
		version = "0.1"

	strings:
		$ = { B9 8E 8A DD 8D 8B F0 E8 ?? ?? ?? ?? FF D0 }
		$ = { B9 8E AB 6F 40 [1-10] 50 [1-10] E8 ?? ?? ?? ?? FF D0 }

	condition:
		all of them
}
rule SIGNATURE_BASE_EXPL_CVE_2021_1647_Apr21_1 : CVE_2021_1647 FILE
{
	meta:
		description = "Detects samples that exploit CVE-2021-1647"
		author = "Arkbird_SOLG"
		id = "ecce018e-1bee-5374-b6c8-984c2a8c2530"
		date = "2021-05-04"
		modified = "2023-12-05"
		reference = "https://attackerkb.com/topics/DzXZpEuBeP/cve-2021-1647-microsoft-windows-defender-zero-day-vulnerability"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cve_2021_1647.yar#L2-L18"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "6e1e9fa0334d8f1f5d0e3a160ba65441f0656d1f1c99f8a9f1ae4b1b1bf7d788"
		hash = "9eaea8a56c47524f6d6b2e2bb72d035c1aa782a4f069ef9df92a0af5c6ee612b"
		hash = "db0e53c9db41d4de21f4bbf1f60d977f5d935239d3fce8b902e8ef0082796cc7"
		hash = "24d9ff44affea06435829507e8e6cb4b659468aa2af510031ed963caf5a6d77a"
		logic_hash = "b0e1809ba10e5ea624e1c4d2e948c928c590b40e6315def8cb1216930ead8579"
		score = 75
		quality = 85
		tags = "CVE-2021-1647, FILE"

	strings:
		$seq1 = { 83 7d ec 01 0f 8e fe 76 ff ff 83 45 f4 01 83 7d f4 01 0f 8e e4 76 ff ff 8b 45 e4 89 04 24 e8 12 74 ff ff 83 ec 04 a1 [2] 01 b1 85 c0 75 0e 8b 45 e4 89 04 24 e8 fb 73 ff ff 83 ec 04 a1 28 ?? 01 b1 c7 44 24 04 00 00 00 00 c7 04 24 00 00 00 00 ff d0 83 ec 08 b8 00 00 00 00 c9 c2 04 00 55 89 e5 83 ec 10 c7 45 f4 00 ?? 01 70 8b 45 08 83 e8 01 a3 70 ?? 01 b1 c7 05 74 ?? 01 b1 00 00 00 00 c7 05 a0 ?? 02 b1 00 00 00 00 8b 15 70 ?? 01 b1 a1 74 ?? 01 b1 01 d0 83 e0 fe 89 c2 a1 [2] 01 b1 29 c2 89 d0 25 ff 0f 00 00 a3 5c ?? 01 b1 a1 74 ?? 01 b1 a3 a0 ?? 02 b1 8b 15 70 ?? 01 b1 a1 74 ?? 01 b1 01 d0 d1 e8 83 c0 01 a3 74 ?? 01 b1 8b 15 70 ?? 01 b1 a1 74 ?? 01 b1 01 d0 83 e0 fe 89 c2 a1 [2] 01 b1 29 c2 89 d0 25 ff 0f 00 00 a3 5c ?? 01 b1 a1 74 ?? 01 b1 a3 a0 ?? 02 b1 8b 15 70 ?? 01 b1 a1 74 ?? 01 b1 01 d0 d1 e8 83 c0 01 a3 74 ?? 01 b1 8b 15 70 ?? 01 b1 a1 74 ?? 01 b1 01 d0 83 e0 fe 89 c2 a1 [2] 01 b1 29 c2 89 d0 25 ff 0f 00 00 a3 5c ?? 01 b1 a1 74 ?? 01 b1 a3 a0 ?? 02 b1 8b 15 70 ?? 01 b1 a1 74 ?? 01 b1 01 d0 d1 e8 83 c0 01 a3 74 ?? 01 b1 8b 15 70 ?? 01 b1 a1 74 ?? 01 b1 01 d0 83 e0 fe 89 c2 a1 [2] 01 b1 29 c2 89 }
		$seq2 = { a1 74 ?? 01 b1 83 e8 01 83 e0 01 85 c0 74 0e 8b 15 5c ?? 01 b1 8b 45 f4 01 d0 89 45 fc 8b 15 70 ?? 01 b1 a1 74 ?? 01 b1 01 d0 83 e0 fe 89 c2 a1 [2] 01 b1 29 c2 89 d0 25 ff 0f 00 00 a3 5c ?? 01 b1 a1 74 ?? 01 b1 a3 a0 ?? 02 b1 8b 15 70 ?? 01 b1 a1 74 ?? 01 b1 01 d0 d1 e8 83 c0 01 a3 74 ?? 01 b1 83 7d 0c 00 74 1d a1 74 ?? 01 b1 83 e8 01 83 e0 01 85 c0 74 0e 8b 15 5c ?? 01 b1 8b 45 f4 01 d0 89 45 fc 8b 15 70 ?? 01 b1 a1 74 ?? 01 b1 01 d0 83 e0 fe 89 c2 a1 [2] 01 b1 29 c2 89 d0 25 ff 0f 00 00 a3 5c ?? 01 b1 a1 74 ?? 01 b1 a3 a0 ?? 02 b1 8b 15 70 ?? 01 b1 a1 74 ?? 01 b1 01 d0 d1 e8 83 c0 01 a3 74 ?? 01 b1 83 7d 0c 00 74 1d a1 74 ?? 01 b1 83 e8 01 83 e0 01 85 c0 74 0e 8b 15 5c ?? 01 b1 8b 45 f4 01 d0 89 45 fc 8b 15 70 ?? 01 b1 a1 74 ?? 01 b1 01 d0 83 e0 fe 89 c2 a1 [2] 01 b1 29 c2 89 d0 25 ff 0f 00 00 a3 5c ?? 01 b1 a1 74 ?? 01 b1 a3 a0 ?? 02 b1 8b 15 70 ?? 01 b1 a1 74 ?? 01 b1 01 d0 d1 e8 83 c0 01 a3 74 ?? 01 b1 83 7d 0c 00 75 0e 8b 15 5c ?? 01 b1 8b 45 f4 01 d0 89 45 fc c7 45 f8 00 00 00 00 eb 19 8b 45 f8 05 e2 ff ff 7f 8d 14 00 8b 45 fc 01 d0 66 c7 00 01 00 83 45 f8 01 83 7d f8 3b 7e e1 8b 45 fc }

	condition:
		filesize > 10KB and filesize < 10000KB and all of them
}
rule SIGNATURE_BASE_APT_KE3CHANG_TMPFILE : APT KE3CHANG TMPFILE FILE
{
	meta:
		description = "Detects Strings left in TMP Files created by K3CHANG Backdoor Ketrican"
		author = "Markus Neis, Swisscom"
		id = "84d411af-ea3d-5862-8c2f-7caca60c1b66"
		date = "2020-06-18"
		modified = "2023-12-05"
		reference = "https://app.any.run/tasks/a96f4f9d-c27d-490b-b5d3-e3be0a1c93e9/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ke3chang.yar#L1-L21"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "4ef11e84d5203c0c425d1a76d4bf579883d40577c2e781cdccc2cc4c8a8d346f"
		logic_hash = "75c97fe2eeb82e09f52e98d76bd529824f171da4c802b5febc1036314d8145f0"
		score = 75
		quality = 85
		tags = "APT, KE3CHANG, TMPFILE, FILE"

	strings:
		$pps1 = "PSParentPath             : Microsoft.PowerShell.Core\\Registry::HKEY_CURRENT_USE" fullword ascii
		$pps2 = "PSPath                   : Microsoft.PowerShell.Core\\Registry::HKEY_CURRENT_USE" fullword ascii
		$psp1 = ": Microsoft.PowerShell.Core\\Registry" ascii
		$s4 = "PSChildName  : PhishingFilter" fullword ascii
		$s1 = "DisableFirstRunCustomize : 2" fullword ascii
		$s7 = "PSChildName  : 3" fullword ascii
		$s8 = "2500         : 3" fullword ascii

	condition:
		uint16( 0 ) == 0x5350 and filesize < 1KB and $psp1 and 1 of ( $pps* ) and 1 of ( $s* )
}
rule SIGNATURE_BASE_APT_MAL_Ke3Chang_Ketrican_Jun20_1 : FILE
{
	meta:
		description = "Detects Ketrican malware"
		author = "Florian Roth (Nextron Systems)"
		id = "ccd8322e-c822-512a-9ac5-eabc9d09640b"
		date = "2020-06-18"
		modified = "2023-12-05"
		reference = "BfV Cyber-Brief Nr. 01/2020"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ke3chang.yar#L23-L42"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "02ea0bc17875ab403c05b50205389065283c59e01de55e68cee4cf340ecea046"
		hash = "f3efa600b2fa1c3c85f904a300fec56104d2caaabbb39a50a28f60e0fdb1df39"
		logic_hash = "a2806de18432dbab24f08c7c2863fd694c91192cf7df4388dfeb87b237f22257"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$xc1 = { 00 59 89 85 D4 FB FF FF 8B 85 D4 FB FF FF 89 45
               FC 68 E0 58 40 00 8F 45 FC E9 }
		$op1 = { 6a 53 58 66 89 85 24 ff ff ff 6a 79 58 66 89 85 }
		$op2 = { 8d 45 bc 50 53 53 6a 1c 8d 85 10 ff ff ff 50 ff }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 300KB and 1 of ( $x* ) or 2 of them
}
rule SIGNATURE_BASE_MAL_Gopuram_Apr23 : FILE
{
	meta:
		description = "Detects Lazarus Gopuram malware"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "e0bb43b0-542b-5c8e-bcba-0326f80efaa0"
		date = "2023-04-04"
		modified = "2023-12-05"
		reference = "https://securelist.com/gopuram-backdoor-deployed-through-3cx-supply-chain-attack/109344/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_lazarus_gopuram.yar#L1-L16"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "beb775af5196f30e0ee021790a4978ca7a7ac2a7cf970a5a620ffeb89cc60b2c"
		hash = "97b95b4a5461f950e712b82783930cb2a152ec0288c00a977983ca7788342df7"
		logic_hash = "58d978bd09a656f2a10a4d5d2585e51efe5cfb6b6648a4b3c2ce8c4f5d2256d4"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/SigmaHQ/Detection-Rule-License"

	strings:
		$path = "%s.TxR.0.regtrans-ms"

	condition:
		uint16( 0 ) == 0x5A4D and $path and filesize < 10MB
}
rule SIGNATURE_BASE_MAL_Wshrat_Dotnet_Packer_Feb21 : FILE
{
	meta:
		description = "Yara Rule for WSH rat .NET packer of February 2021 "
		author = "Yoroi Malware ZLab"
		id = "62e043fc-7d13-5b91-9fdd-e71d91194da2"
		date = "2021-03-09"
		modified = "2023-12-05"
		reference = "https://yoroi.company/research/threatening-within-budget-how-wsh-rat-is-abused-by-cyber-crooks/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_wsh_rat.yar#L1-L17"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "18159b140c314a00111fb9453e60d19c11633628a4fe2ad8299b839165b39424"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$a1 = { BE DD 60 8C 34 49 9A 54 D2 40 }
		$a2 = { 1D D7 24 22 47 A6 B1 A5 }
		$a3 = { 13 30 03 00 07 00 00 00 01 }
		$a4 = { 11 02 03 7D 78 00 00 04 2A }
		$a5 = { A8 8A F4 C8 61 2B CA 07 }
		$a6 = { 15 AE 5E AB 5A 20 FE B5 56 B4 61 2B BB 06 2A}

	condition:
		uint16( 0 ) == 0x5A4D and 3 of them
}
rule SIGNATURE_BASE_SUSP_MAL_EXFIL_Stealer_Output_Characteristics_Sep22_1 : FILE
{
	meta:
		description = "Detects typical stealer output files as created by RedLine or Racoon stealer"
		author = "Florian Roth (Nextron Systems)"
		id = "c1cab3c3-c4f3-5a19-9ea3-9e4242238359"
		date = "2022-09-17"
		modified = "2023-12-05"
		reference = "https://twitter.com/cglyer/status/1570965878480719873"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_stealer_exfil_zip.yar#L2-L30"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "8ce14c6b720281f43c75ce52e23ec13d08e7b2be1c5fbc2d704238f1fdd1a07f"
		hash = "011c19d18fa446a2619b3a2512dacb2694e1da99a2c2ea7828769f1373ecd8fe"
		hash = "418530bc7210f74ada8e7f16b41ea2033054e99f0c4423ce1d3ebf973c89e3a3"
		hash = "aa6e2c8447f66527f9b6f4d54f57edc6cabe56095df94dc0656dca02e11356ab"
		hash = "bbfb608061931565debac405ffebe3c4bb5dac8042443fe4e80aa03395955bd2"
		hash = "c15107beecf3301fb12d140690034717e16bd5312a746e7ff43a7925e5533260"
		logic_hash = "197bb4b837cdd635f9340547b10a90c3a2a17f0113076c5ccbc0a91b7ae18eeb"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$sa1 = "passwords.txt" ascii
		$sa2 = "autofills/" ascii
		$sa3 = "browsers/cookies/" ascii
		$sa4 = "wallets/" ascii
		$sb1 = "Passwords.txt" ascii
		$sb2 = "Autofills/" ascii
		$sb3 = "Browsers/Cookies/" ascii
		$sb4 = "Wallets/" ascii

	condition:
		uint16( 0 ) == 0x4b50 and filesize < 5000KB and ( 2 of ( $sa* ) or 2 of ( $sb* ) )
}
rule SIGNATURE_BASE_APT_PS1_Sysaid_EXPL_Forensicartifacts_Nov23_1 : SCRIPT CVE_2023_47246
{
	meta:
		description = "Detects forensic artifacts found in attacks on SysAid on-prem software exploiting CVE-2023-47246"
		author = "Florian Roth"
		id = "df7997d3-9309-58b3-8cd7-de9fea36d3c7"
		date = "2023-11-09"
		modified = "2023-12-05"
		reference = "https://www.sysaid.com/blog/service-desk/on-premise-software-security-vulnerability-notification"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_sysaid_cve_2023_47246.yar#L2-L15"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "85efeea88961ca99b22004726d88efc46c748273b9a0b3be674f4cbb12cd3dd1"
		score = 85
		quality = 85
		tags = "SCRIPT, CVE-2023-47246"

	strings:
		$x1 = "if ($s -match '^(Sophos).*\\.exe\\s') {echo $s; $bp++;}" ascii wide
		$x2 = "$s=$env:SehCore;$env:SehCore=\"\";Invoke-Expression $s;" ascii wide

	condition:
		1 of them
}
rule SIGNATURE_BASE_MAL_Loader_Turtleloader_Nov23 : CVE_2023_47246 FILE
{
	meta:
		description = "Detects Tutle loader used in attacks against SysAid CVE-2023-47246"
		author = "Florian Roth"
		id = "c7b5d03d-52c4-59b4-ac69-55e532a21340"
		date = "2023-11-09"
		modified = "2023-12-05"
		reference = "https://www.sysaid.com/blog/service-desk/on-premise-software-security-vulnerability-notification"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_sysaid_cve_2023_47246.yar#L17-L38"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "b5acf14cdac40be590318dee95425d0746e85b1b7b1cbd14da66f21f2522bf4d"
		logic_hash = "14a1636ed4dc3c897fefe53946e67339f91da9e2fbed2c99b9b4119dcc2649c0"
		score = 85
		quality = 85
		tags = "CVE-2023-47246, FILE"

	strings:
		$s1 = "No key in args!" ascii fullword
		$s2 = "Bad data file!" ascii fullword
		$s3 = "Data file loaded. Running..." ascii
		$op1 = { 48 8d 55 c8 4c 8d 3d ac 8f 00 00 45 33 c9 45 33 d2 4d 8b e7 44 21 0a 45 33 db 4c 8d 3d 16 ec ff ff }
		$op2 = { 48 d3 e8 0f b6 c8 49 03 cb 49 81 c3 00 01 00 00 45 33 8c 8f a0 e4 00 00 41 83 fa 04 7c c7 41 ff c0 }
		$op3 = { 48 83 c1 04 48 ff ca 89 41 1c 75 ef 03 f6 48 83 c3 20 48 ff cd 0f 85 77 ff ff ff }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 200KB and 3 of them
}
rule SIGNATURE_BASE_MAL_Grace_Dec22
{
	meta:
		description = "Detects Grace (aka FlawedGrace and GraceWire) RAT"
		author = "X__Junior"
		id = "fc2214dc-f1e5-52d7-a9de-88709a03b04e"
		date = "2022-12-13"
		modified = "2023-12-05"
		reference = "https://blog.talosintelligence.com/breaking-the-silence-recent-truebot-activity/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_sysaid_cve_2023_47246.yar#L40-L59"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "a66df3454b8c13f1b92d8b2cf74f5bfcdedfbff41a5e4add62e15277d14dd169"
		hash = "e113a8df3c4845365f924bacf10c00bcc5e17587a204b640852dafca6db20404"
		logic_hash = "8276662dadfa2f8e07dd7882a60e55bd22ecf1f8f66a09940f16236598646560"
		score = 70
		quality = 85
		tags = ""

	strings:
		$sa1 = "Grace finalized, no more library calls allowed." ascii
		$sa2 = "Socket forcibly closed due to no response to DISCONNECT signal from other side, worker id(%d)" ascii
		$sa3 = "AVWireCleanupThread" ascii
		$sa4 = "AVTunnelClientDirectIO" ascii
		$sa5 = "AVGraceTunnelWriteThread" ascii
		$sa6 = "AVGraceTunnelClientDirectIO" ascii

	condition:
		2 of them
}
rule SIGNATURE_BASE_EXT_APT_Bitter_Win32K_0Day_Feb21 : FILE
{
	meta:
		description = "Detects code that exploits a Windows 0day exploited by Bitter APT group"
		author = "dbappsecurity_lieying_lab"
		id = "b1892b52-4b94-5571-ad63-8750a321f1f2"
		date = "2021-01-01"
		modified = "2023-12-05"
		reference = "https://ti.dbappsecurity.com.cn/blog/index.php/2021/02/10/windows-kernel-zero-day-exploit-is-used-by-bitter-apt-in-targeted-attack/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_bitter.yar#L2-L21"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "84a8d0ae14469eb6431e73295d821609c7a8b313630d645085ffd8faff6e5e43"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "NtUserConsoleControl" ascii wide
		$s2 = "NtCallbackReturn" ascii wide
		$s3 = "CreateWindowEx" ascii wide
		$s4 = "SetWindowLong" ascii wide
		$a1 = {48 C1 E8 02 48 C1 E9 02 C7 04 8A}
		$a2 = {66 0F 1F 44 00 00 80 3C 01 E8 74 22 FF C2 48 FF C1}
		$a3 = {48 63 05 CC 69 05 00 8B 0D C2 69 05 00 48 C1 E0 20 48 03 C1}

	condition:
		uint16( 0 ) == 0x5a4d and all of ( $s* ) and 1 of ( $a* )
}
rule SIGNATURE_BASE_SUSP_LNX_SH_Cryptominer_Indicators_Dec20_1 : FILE
{
	meta:
		description = "Detects helper script used in a crypto miner campaign"
		author = "Florian Roth (Nextron Systems)"
		id = "e376e0e1-1490-5ad4-8ca2-d28ca1c0b51a"
		date = "2020-12-31"
		modified = "2023-12-05"
		reference = "https://www.intezer.com/blog/research/new-golang-worm-drops-xmrig-miner-on-servers/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_crypto_miner.yar#L2-L17"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "3298dbd985c341d57e3219e80839ec5028585d0b0a737c994363443f4439d7a5"
		logic_hash = "4acd1b77307dbf23f95f7a2024209bee714c6931182aff16455ea6b7e4a6f287"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "miner running" fullword ascii
		$x2 = "miner runing" fullword ascii
		$x3 = " --donate-level 1 "
		$x4 = " -o pool.minexmr.com:5555 " ascii

	condition:
		filesize < 20KB and 1 of them
}
rule SIGNATURE_BASE_PUA_WIN_XMRIG_Cryptocoin_Miner_Dec20 : FILE
{
	meta:
		description = "Detects XMRIG crypto coin miners"
		author = "Florian Roth (Nextron Systems)"
		id = "4dfb04e9-fbba-5a6f-ad20-d805025d2d74"
		date = "2020-12-31"
		modified = "2023-12-05"
		reference = "https://www.intezer.com/blog/research/new-golang-worm-drops-xmrig-miner-on-servers/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_crypto_miner.yar#L19-L33"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "b6154d25b3aa3098f2cee790f5de5a727fc3549865a7aa2196579fe39a86de09"
		logic_hash = "c39aee669a98bcc9d07821aef248096e45a6c54ab22b8b98c0a393b445f3934e"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "xmrig.exe" fullword wide
		$x2 = "xmrig.com" fullword wide
		$x3 = "* for x86, CRYPTOGAMS" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 6000KB and 2 of them or all of them
}
rule SIGNATURE_BASE_APT_APT28_Drovorub_Library_And_Unique_Strings : FILE
{
	meta:
		description = "Rule to detect Drovorub-server, Drovorub-agent, and Drovorub-client"
		author = "NSA / FBI"
		id = "8e010356-09c7-5897-9cbe-051cd0800502"
		date = "2020-08-13"
		modified = "2026-05-15"
		reference = "https://www.nsa.gov/news-features/press-room/Article/2311407/nsa-and-fbi-expose-russian-previously-undisclosed-malware-drovorub-in-cybersecu/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt28_drovorub.yar#L24-L43"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "adb0d4cb6d589213e6a125d3cc20fcea8164b697bdd24d897ce75e7c7f06120a"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Poco" ascii wide
		$s2 = "Json" ascii wide
		$s3 = "OpenSSL" ascii wide
		$a1 = "clientid" ascii wide
		$a2 = "-----BEGIN" ascii wide
		$a3 = "-----END" ascii wide
		$a4 = "tunnel" ascii wide

	condition:
		( filesize > 1MB and filesize < 10MB and ( uint32( 0 ) == 0x464c457f ) ) and ( #s1 > 20 and #s2 > 15 and #s3 > 15 and all of ( $a* ) )
}
rule SIGNATURE_BASE_APT_APT28_Drovorub_Unique_Network_Comms_Strings
{
	meta:
		description = "Rule to detect Drovorub-server, Drovorub-agent, or Drovorub-client based"
		author = "NSA / FBI"
		id = "c6a930e8-c1c0-5d96-9051-7516df848b45"
		date = "2020-08-13"
		modified = "2026-05-15"
		reference = "https://www.nsa.gov/news-features/press-room/Article/2311407/nsa-and-fbi-expose-russian-previously-undisclosed-malware-drovorub-in-cybersecu/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt28_drovorub.yar#L45-L73"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8c82766b76c36fe64c6aa99577e1997d7181dbd36a4c27329845ae8a413f5327"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s_01 = "action" wide ascii
		$s_02 = "auth.commit" wide ascii
		$s_03 = "auth.hello" wide ascii
		$s_04 = "auth.login" wide ascii
		$s_05 = "auth.pending" wide ascii
		$s_06 = "client_id" wide ascii
		$s_07 = "client_login" wide ascii
		$s_08 = "client_pass" wide ascii
		$s_09 = "clientid" wide ascii
		$s_10 = "clientkey_base64" wide ascii
		$s_11 = "file_list_request" wide ascii
		$s_12 = "module_list_request" wide ascii
		$s_13 = "monitor" wide ascii
		$s_14 = "net_list_request" wide ascii
		$s_15 = "server finished" wide ascii
		$s_16 = "serverid" wide ascii
		$s_17 = "tunnel" wide ascii

	condition:
		all of them
}
rule SIGNATURE_BASE_EXPL_CVE_2021_40444_Document_Rels_XML : CVE_2021_40444 FILE
{
	meta:
		description = "Detects indicators found in weaponized documents that exploit CVE-2021-40444"
		author = "Jeremy Brown / @alteredbytes"
		id = "812bb68e-71ea-5a9a-8d39-ab99fdaa6c58"
		date = "2021-09-10"
		modified = "2023-12-05"
		reference = "https://twitter.com/AlteredBytes/status/1435811407249952772"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cve_2021_40444.yar#L6-L25"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b05c3b33c3cab2c9109d808ed197758bc987f07beee77e1f61094715e0c1a1e7"
		score = 75
		quality = 85
		tags = "CVE-2021-40444, FILE"

	strings:
		$b1 = "/relationships/oleObject" ascii
		$b2 = "/relationships/attachedTemplate" ascii
		$c1 = "Target=\"mhtml:http" nocase
		$c2 = "!x-usc:http" nocase
		$c3 = "TargetMode=\"External\"" nocase

	condition:
		uint32( 0 ) == 0x6D783F3C and filesize < 10KB and 1 of ( $b* ) and all of ( $c* )
}
rule SIGNATURE_BASE_EXPL_MAL_Maldoc_OBFUSCT_MHTML_Sep21_1 : CVE_2021_40444 FILE
{
	meta:
		description = "Detects suspicious office reference files including an obfuscated MHTML reference exploiting CVE-2021-40444"
		author = "Florian Roth (Nextron Systems)"
		id = "781cfd61-d5ac-58e5-868f-dbd2a2df3500"
		date = "2021-09-18"
		modified = "2023-12-05"
		reference = "https://twitter.com/decalage2/status/1438946225190014984?s=20"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cve_2021_40444.yar#L27-L41"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "84674acffba5101c8ac518019a9afe2a78a675ef3525a44dceddeed8a0092c69"
		logic_hash = "11a73572970d2d85d308330119a2c5243f2848ae78a861decdb0cdbde0d9d1c2"
		score = 90
		quality = 85
		tags = "CVE-2021-40444, FILE"

	strings:
		$h1 = "<?xml " ascii wide
		$s1 = "109;&#104;&#116;&#109;&#108;&#58;&#104;&#116;&#109;&#108" ascii wide

	condition:
		filesize < 25KB and all of them
}
rule SIGNATURE_BASE_EXPL_XML_Encoded_CVE_2021_40444 : CVE_2021_40444 FILE
{
	meta:
		description = "Detects possible CVE-2021-40444 with no encoding, HTML/XML entity (and hex notation) encoding, or all 3"
		author = "James E.C, Proofpoint"
		id = "4bf9ec64-c662-5c8f-9e58-12a7412ef07d"
		date = "2021-09-18"
		modified = "2021-09-19"
		reference = "https://twitter.com/sudosev/status/1439205606129377282"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cve_2021_40444.yar#L44-L61"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "13de9f39b1ad232e704b5e0b5051800fcd844e9f661185ace8287a23e9b3868e"
		hash = "84674acffba5101c8ac518019a9afe2a78a675ef3525a44dceddeed8a0092c69"
		logic_hash = "feaeadd8e7e262f191ea0c2f85377531208262e5ac19d6706703e62cf8b4ec90"
		score = 70
		quality = 85
		tags = "CVE-2021-40444, FILE"

	strings:
		$h1 = "<?xml " ascii wide
		$t_xml_r = /Target[\s]{0,20}=[\s]{0,20}\["']([Mm]|&#(109|77|x6d|x4d);)([Hh]|&#(104|72|x68|x48);)([Tt]|&#(116|84|x74|x54);)([Mm]|&#(109|77|x6d|x4d);)([Ll]|&#(108|76|x6c|x4c);)(:|&#58;|&#x3a)/
		$t_mode_r = /TargetMode[\s]{0,20}=[\s]{0,20}\["']([Ee]|&#(x45|x65|69|101);)([Xx]|&#(x58|x78|88|120);)([Tt]|&#(x74|x54|84|116);)/

	condition:
		filesize < 500KB and $h1 and all of ( $t_* )
}
rule SIGNATURE_BASE_SUSP_OBFUSC_Indiators_XML_Officedoc_Sep21_1 : WINDOWS CVE FILE
{
	meta:
		description = "Detects suspicious encodings in fields used in reference files found in weaponized MS Office documents"
		author = "Florian Roth (Nextron Systems)"
		id = "ffcaf270-f574-5692-90e5-6776c34eb71b"
		date = "2021-09-18"
		modified = "2023-12-05"
		reference = "https://twitter.com/sudosev/status/1439205606129377282"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cve_2021_40444.yar#L64-L81"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "13de9f39b1ad232e704b5e0b5051800fcd844e9f661185ace8287a23e9b3868e"
		hash = "84674acffba5101c8ac518019a9afe2a78a675ef3525a44dceddeed8a0092c69"
		logic_hash = "fc8f0dd02460ab8f8cc6717c66eba51e6ed74881a48e92fd0bf978467dfb40e3"
		score = 65
		quality = 85
		tags = "WINDOWS, CVE, FILE"

	strings:
		$h1 = "<?xml " ascii wide
		$xml_e = "Target=\"&#" ascii wide
		$xml_mode_1 = "TargetMode=\"&#" ascii wide

	condition:
		filesize < 500KB and $h1 and 1 of ( $xml* )
}
rule SIGNATURE_BASE_SUSP_OBFUSC_Indiators_XML_Officedoc_Sep21_2 : WINDOWS CVE FILE
{
	meta:
		description = "Detects suspicious encodings in fields used in reference files found in weaponized MS Office documents"
		author = "Florian Roth (Nextron Systems)"
		id = "c3c5ec4f-5d2a-523c-bd4b-b75c04bac87d"
		date = "2021-09-18"
		modified = "2023-12-05"
		reference = "https://twitter.com/sudosev/status/1439205606129377282"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cve_2021_40444.yar#L83-L98"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "82c70e0f0b72a57302e5853cc53ae18dbb0bc8dabdfd27b473a7664b2fc5e874"
		score = 65
		quality = 85
		tags = "WINDOWS, CVE, FILE"

	strings:
		$h1 = "<?xml " ascii wide
		$a1 = "Target" ascii wide
		$a2 = "TargetMode" ascii wide
		$xml_e = "&#x0000" ascii wide

	condition:
		filesize < 500KB and all of them
}
rule SIGNATURE_BASE_MAL_RANSOM_INC_Aug24 : FILE
{
	meta:
		description = "Detects INC ransomware and it's variants like Lynx"
		author = "X__Junior"
		id = "b776490b-f26a-55d9-bb26-ec3c617f070c"
		date = "2024-08-08"
		modified = "2024-12-12"
		reference = "https://twitter.com/rivitna2/status/1701739812733014313"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_inc_ransomware.yar#L1-L30"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "eaa0e773eb593b0046452f420b6db8a47178c09e6db0fa68f6a2d42c3f48e3bc"
		hash = "1754c9973bac8260412e5ec34bf5156f5bb157aa797f95ff4fc905439b74357a"
		logic_hash = "335b92027c551d074015b830d137cf2fdee81d792cd7360f2499c83cc895fbbb"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "tarting full encryption in" wide
		$s2 = "oad hidden drives" wide
		$s3 = "ending note to printers" ascii
		$s4 = "uccessfully delete shadow copies from %c:/" wide
		$op1 = { 33 C9 03 C6 83 C0 02 0F 92 C1 F7 D9 0B C8 51 E8 }
		$op2 = { 8B 44 24 [1-4] 6A 00 50 FF 35 ?? ?? ?? ?? 50 FF 15}
		$op3 = { 57 50 8D 45 ?? C7 45 ?? 00 00 00 00 50 6A 00 6A 00 6A 02 6A 00 6A 02 C7 45 ?? 00 00 00 00 FF D6 FF 75 ?? E8 ?? ?? ?? ?? 83 C4 04 8B F8 8D 45 ?? 50 8D 45 ?? 50 FF 75 ?? 57 6A 02 6A 00 6A 02 FF D6 }
		$op4 = { 6A FF 8D 4? ?? 5? 8D 4? ?? 5? 8D 4? ?? 5? 5? FF 15 ?? ?? ?? ?? 85 C0 }
		$op5 = { 56 6A 00 68 01 00 10 00 FF 15 ?? ?? ?? ?? 8B F0 83 FE FF 74 ?? 6A 00 56 FF 15 ?? ?? ?? ?? 68 88 13 00 00 56 FF 15 ?? ?? ?? ?? 56 FF 15}

	condition:
		uint16( 0 ) == 0x5A4D and ( 3 of ( $s* ) or 3 of ( $op* ) or ( 2 of ( $s* ) and 2 of ( $op* ) ) )
}
rule SIGNATURE_BASE_APT_APT41_CN_ELF_Speculoos_Backdoor : FILE
{
	meta:
		description = "Detects Speculoos Backdoor used by APT41"
		author = "Florian Roth (Nextron Systems)"
		id = "efe2b368-33af-5382-a5f0-0e7dd7f4dea4"
		date = "2020-04-14"
		modified = "2026-10-29"
		reference = "https://unit42.paloaltonetworks.com/apt41-using-new-speculoos-backdoor-to-target-organizations-globally/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt41.yar#L233-L267"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "6943fbb194317d344ca9911b7abb11b684d3dca4c29adcbcff39291822902167"
		hash = "99c5dbeb545af3ef1f0f9643449015988c4e02bf8a7164b5d6c86f67e6dc2d28"
		logic_hash = "ee4cbbc5fc51fb24cbf6017dfb4763ac72a0b23a3b6e794b909e678ebfbabc03"
		score = 90
		quality = 85
		tags = "FILE"

	strings:
		$xc1 = { 2F 70 72 69 76 61 74 65 2F 76 61 72 00 68 77 2E
               70 68 79 73 6D 65 6D 00 68 77 2E 75 73 65 72 6D
               65 6D 00 4E 41 2D 4E 41 2D 4E 41 2D 4E 41 2D 4E
               41 2D 4E 41 00 6C 6F 30 00 00 00 00 25 30 32 78
               2D 25 30 32 78 2D 25 30 32 78 2D 25 30 32 78 2D
               25 30 32 78 2D 25 30 32 78 0A 00 72 00 4E 41 00
               75 6E 61 6D 65 20 2D 76 }
		$s1 = "badshell" ascii fullword
		$s2 = "hw.physmem" ascii fullword
		$s3 = "uname -v" ascii fullword
		$s4 = "uname -s" ascii fullword
		$s5 = "machdep.tsc_freq" ascii fullword
		$s6 = "/usr/sbin/config.bak" ascii fullword
		$s7 = "enter MessageLoop..." ascii fullword
		$s8 = "exit StartCBProcess..." ascii fullword
		$sc1 = { 72 6D 20 2D 72 66 20 22 25 73 22 00 2F 70 72 6F
               63 2F }

	condition:
		uint16( 0 ) == 0x457f and filesize < 600KB and 1 of ( $x* ) or 4 of them
}
rule SIGNATURE_BASE_EXPL_Gitlab_CE_RCE_CVE_2021_22205 : CVE_2021_22205
{
	meta:
		description = "Detects signs of exploitation of GitLab CE CVE-2021-22205"
		author = "Florian Roth (Nextron Systems)"
		id = "21cc6fa7-e50d-5b8e-815d-27315ab5635d"
		date = "2021-10-26"
		modified = "2023-12-05"
		reference = "https://security.humanativaspa.it/gitlab-ce-cve-2021-22205-in-the-wild/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/exploit_gitlab_cve_2021_22205.yar#L2-L27"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "54b841716a6bd56706c1c38fcda9a27ffd7feba2660602b191e8e347983e578d"
		score = 70
		quality = 85
		tags = "CVE-2021-22205"

	strings:
		$sa1 = "VXNlci5maW5kX2J5KHVzZXJuYW1l" ascii
		$sa2 = "VzZXIuZmluZF9ieSh1c2VybmFtZ" ascii
		$sa3 = "Vc2VyLmZpbmRfYnkodXNlcm5hbW" ascii
		$sb1 = "dXNlci5hZG1pb" ascii
		$sb2 = "VzZXIuYWRtaW" ascii
		$sb3 = "1c2VyLmFkbWlu" ascii
		$sc1 = "dXNlci5zYXZlI" ascii
		$sc2 = "VzZXIuc2F2ZS" ascii
		$sc3 = "1c2VyLnNhdmUh" ascii

	condition:
		1 of ( $sa* ) and 1 of ( $sb* ) and 1 of ( $sc* )
}
rule SIGNATURE_BASE_EXPL_Gitlab_CE_RCE_Malformed_JPG_CVE_2021_22204 : CVE_2021_22204 CVE_2021_22205 FILE
{
	meta:
		description = "Detects malformed JPG files exploting EXIF vulnerability CVE-2021-22204 and used in the exploitation of GitLab vulnerability CVE-2021-22205"
		author = "Florian Roth (Nextron Systems)"
		id = "3d769340-0306-596d-8783-2b37b93a5673"
		date = "2021-10-26"
		modified = "2023-12-05"
		reference = "https://attackerkb.com/topics/D41jRUXCiJ/cve-2021-22205/rapid7-analysis?referrer=blog"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/exploit_gitlab_cve_2021_22205.yar#L29-L44"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "0718ad24337acbb746c6e0d7e0b42d2d034ff583ec6fd12b34fda4737d7e78b0"
		score = 70
		quality = 83
		tags = "CVE-2021-22204, CVE-2021-22205, FILE"

	strings:
		$h1 = { 41 54 26 54 46 4F 52 4D }
		$sr1 = /\(metadata[\s]{0,3}\([A-Za-z]{1,20} "\\/

	condition:
		filesize < 10KB and $h1 and $sr1
}
rule SIGNATURE_BASE_APT_CN_MAL_Reddelta_Shellcode_Loader_Oct20_1 : FILE
{
	meta:
		description = "Detects Red Delta samples"
		author = "Florian Roth (Nextron Systems)"
		id = "47417488-e843-5346-9baa-fcce30b884d1"
		date = "2020-10-14"
		modified = "2023-12-05"
		reference = "https://twitter.com/JAMESWT_MHT/status/1316387482708119556"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_reddelta.yar#L2-L29"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "30b2bbce0ca4cb066721c94a64e2c37b7825dd72fc19c20eb0ab156bea0f8efc"
		hash = "42ed73b1d5cc49e09136ec05befabe0860002c97eb94e9bad145e4ea5b8be2e2"
		hash = "480a8c883006232361c5812af85de9799b1182f1b52145ccfced4fa21b6daafa"
		hash = "7ea7c6406c5a80d3c15511c4d97ec1e45813e9c58431f386710d0486c4898b98"
		logic_hash = "1f2406563b863b8ccd0fd8d8d33c576c4b82dabb55a1e4fa8291859323389834"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "InjectShellCode" ascii fullword
		$s1 = "DotNetLoader.exe" wide ascii fullword
		$s2 = "clipboardinject" ascii fullword
		$s3 = "download.php?raw=1" wide
		$s4 = "Windows NT\\CurrentVersion\\AppCompatFlags\\TelemetryController\\Levint" wide
		$s5 = "FlashUpdate.exe" wide
		$s6 = "raw_cc_url" ascii fullword
		$op1 = { 48 8b 4c 24 78 48 89 01 e9 1a ff ff ff 48 8b 44 }
		$op2 = { ff ff 00 00 77 2a 8b 44 24 38 8b 8c 24 98 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 200KB and $x1 or 3 of them
}
rule SIGNATURE_BASE_APT_CN_MAL_Reddelta_Shellcode_Loader_Oct20_2 : FILE
{
	meta:
		description = "Detects Red Delta samples"
		author = "Florian Roth (Nextron Systems)"
		id = "acb1024a-64af-51ac-84c8-7fe9a5bd4538"
		date = "2020-10-14"
		modified = "2023-12-05"
		reference = "https://twitter.com/JAMESWT_MHT/status/1316387482708119556"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_reddelta.yar#L31-L57"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "260ebbf392498d00d767a5c5ba695e1a124057c1c01fff2ae76db7853fe4255b"
		hash = "9ccb4ed133be5c9c554027347ad8b722f0b4c3f14bfd947edfe75a015bf085e5"
		hash = "b3fd750484fca838813e814db7d6491fea36abe889787fb7cf3fb29d9d9f5429"
		logic_hash = "179265c0b2175bc3d2d581a69e50e9b8b9cc918a6fdc7bcef42fb163c49b077a"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "\\CLRLoader.exe" wide fullword
		$x2 = "/callback.php?token=%s&computername=%s&username=%s" ascii fullword
		$s1 = "DotNetLoader.Program" wide fullword
		$s2 = "/download.php?api=40" ascii fullword
		$s3 = "get %d URLDir" ascii fullword
		$s4 = "Read code failed" ascii fullword
		$s5 = "OpenFile fail!" wide fullword
		$s6 = "Writefile success" wide fullword
		$op1 = { 4c 8d 45 e0 49 8b cc 41 8d 51 c3 e8 34 77 02 00 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 3000KB and 1 of ( $x* ) or 4 of them
}
rule SIGNATURE_BASE_APT_CN_MAL_Reddelta_Shellcode_Loader_Oct20_3 : FILE
{
	meta:
		description = "Detects Red Delta samples"
		author = "Florian Roth (Nextron Systems)"
		id = "b52836bb-cdef-5416-a8e1-72d0b2298546"
		date = "2020-10-14"
		modified = "2022-12-21"
		reference = "https://twitter.com/JAMESWT_MHT/status/1316387482708119556"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_reddelta.yar#L59-L78"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "740992d40b84b10aa9640214a4a490e989ea7b869cea27dbbdef544bb33b1048"
		logic_hash = "64402f6265f23abf7d6a711aa888c89386c1a754f12286b0efe5fd5d81f15b01"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Taskschd.dll" ascii fullword
		$s2 = "AddTaskPlanDllVerson.dll" ascii fullword
		$s3 = "\\FlashUpdate.exe" ascii
		$s4 = "D:\\Project\\FBIRedTeam" ascii fullword
		$s5 = "Error %s:%d, ErrorCode: %x" ascii fullword

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 400KB and 4 of them
}
rule SIGNATURE_BASE_HKTL_Venom_LIB_Dec22 : FILE
{
	meta:
		description = "Detects Venom - a library that meant to perform evasive communication using stolen browser socket"
		author = "Ido Veltzman, Florian Roth"
		id = "b13b8a9c-52a4-53ac-817e-9f729fbf17c2"
		date = "2022-12-17"
		modified = "2023-12-05"
		reference = "https://github.com/Idov31/Venom"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_hktl_venom_lib.yar#L2-L30"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "fa143946479a45b272d507c3aa2b17026bfdcbb4abefd833f95ff78537568ec1"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "[ + ] Created detached hidden msedge process: " fullword ascii
		$ss1 = "WS2_32.dll" fullword ascii
		$ss2 = "WSASocketW" fullword ascii
		$ss3 = "WSADuplicateSocketW" fullword ascii
		$ss5 = "\\Device\\Afd" wide fullword
		$sx1 = "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe --no-startup-window" fullword wide
		$sx2 = "[ + ] Data sent!" fullword ascii
		$sx3 = "[ + ] Socket obtained!" fullword ascii
		$op1 = { 4c 8b f0 48 3b c1 48 b8 ff ff ff ff ff ff ff 7f }
		$op2 = { 48 8b cf e8 1c 34 00 00 48 8b 5c 24 30 48 8b c7 }
		$op3 = { 48 8b da 48 8b f9 45 33 f6 48 85 c9 0f 84 34 01 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 500KB and ( ( 3 of ( $ss* ) and all of ( $op* ) ) or 2 of ( $sx* ) ) or $x1 or all of ( $sx* )
}
rule SIGNATURE_BASE_EXPL_CVE_2024_21413_Microsoft_Outlook_RCE_Feb24 : CVE_2024_21413 FILE
{
	meta:
		description = "Detects emails that contain signs of a method to exploit CVE-2024-21413 in Microsoft Outlook"
		author = "X__Junior, Florian Roth"
		id = "4512ca7b-0755-565e-84f1-596552949aa5"
		date = "2024-02-17"
		modified = "2024-02-19"
		reference = "https://github.com/xaitax/CVE-2024-21413-Microsoft-Outlook-Remote-Code-Execution-Vulnerability/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_outlook_cve_2024_21413.yar#L2-L20"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "06cfafe0b92949e493dca6d54f671d0607242d97341144b69f563a0cc24dc6a1"
		score = 75
		quality = 85
		tags = "CVE-2024-21413, FILE"

	strings:
		$a1 = "Subject: "
		$a2 = "Received: "
		$xr1 = /file:\/\/\/\\\\[^"']{6,600}\.(docx|txt|pdf|xlsx|pptx|odt|etc|jpg|png|gif|bmp|tiff|svg|mp4|avi|mov|wmv|flv|mkv|mp3|wav|aac|flac|ogg|wma|exe|msi|bat|cmd|ps1|zip|rar|7z|targz|iso|dll|sys|ini|cfg|reg|html|css|java|py|c|cpp|db|sql|mdb|accdb|sqlite|eml|pst|ost|mbox|htm|php|asp|jsp|xml|ttf|otf|woff|woff2|rtf|chm|hta|js|lnk|vbe|vbs|wsf|xls|xlsm|xltm|xlt|doc|docm|dot|dotm)!/

	condition:
		filesize < 1000KB and all of ( $a* ) and 1 of ( $xr* )
}
rule SIGNATURE_BASE_Mal_Babbleloader_Win_Jan24 : FILE
{
	meta:
		description = "This rule detects intrinsic patterns of BabbleLoader."
		author = "0x0d4y"
		id = "b2f18ab3-b4df-4e2f-aa23-de8694beb221"
		date = "2025-01-27"
		modified = "2026-05-15"
		reference = "https://0x0d4y.blog/babbleloader-technical-malware-analysis/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_babbleloader_win_jan24.yar#L1-L24"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "fa3d03c319a7597712eeff1338dabf92"
		logic_hash = "d4f7915146b1f3fe50febc231247e14323e9d68a94b2b9c8149a5727c06162ca"
		score = 100
		quality = 85
		tags = "FILE"
		license = "CC BY 4.0"
		rule_matching_tlp = "TLP:WHITE"
		rule_sharing_tlp = "TLP:WHITE"

	strings:
		$str_decryption_algorithm = { 48 63 44 24 ?? 48 8b 4c 24 ?? 0f b6 04 ?? 33 44 ?? ?? 0f b6 4c ?? ?? d2 c8 48 63 4c ?? ?? 48 8b 54 ?? ?? 88 04 0a 6b 44 24 ?? ?? 89 44 ?? ?? 8b 44 24 ?? ff c0 89 44 24 }
		$hashing_algorithm = { 48 8b 44 24 ?? 0f be ?? 89 44 24 ?? 8b 44 24 ?? 89 44 24 ?? 48 8b 44 24 ?? 48 ff c0 48 89 44 24 ?? 83 7c 24 08 ?? ?? ?? 8b 44 24 ?? 8b 0c ?? 03 c8 8b c1 89 04 24 8b 44 24 ?? 05 ?? ?? ?? ?? 8b 0c 24 0f af c8 8b c1 89 04 }
		$halos_gate = { 48 8b 44 24 ?? 0f b6 ?? 83 f8 4c 0f ?? ?? ?? ?? ?? 48 8b 44 ?? ?? 0f b6 ?? ?? 3d 8b ?? ?? ?? 75 ?? 48 8b 44 ?? ?? 0f b6 40 ?? 3d d1 ?? ?? ?? 75 ?? 48 8b 44 ?? ?? 0f b6 40 ?? 3d b8 ?? ?? ?? 75 ?? 48 8b 44 ?? ?? 0f b6 40 ?? 85 c0 75 ?? 48 8b 44 ?? ?? 0f b6 40 ?? 85c0 75 ?? 48 8b 44 ?? ?? 0f b6 40 ?? 88 44 ?? ?? 48 8b 44 24 ?? 0f b6 40 ?? 88 44 ?? ?? 0f b6 44 ?? ?? c1 e0 08 0f b6 4c ?? ?? 0b c1 48 8b 8c ?? ?? ?? ?? ?? 89 01 ?? ?? ?? ?? ?? 48 8b 44 ?? ?? 0f b6 00 3d e9 }
		$get_syscall_offset = { 4d 33 db 4c 8b d9 c3 }
		$jump_syscall_offset = { 4c 8b d1 41 8b 03 41 ff 63 ?? }

	condition:
		uint16( 0 ) == 0x5a4d and $str_decryption_algorithm and $hashing_algorithm and ( 1 of ( $halos_gate , $get_syscall_offset , $jump_syscall_offset ) )
}
rule SIGNATURE_BASE_MAL_ELF_Reverseshell_Sslshell_Jun23_1 : CVE_2023_2868 FILE
{
	meta:
		description = "Detects reverse shell named SSLShell used in Barracuda ESG exploitation (CVE-2023-2868)"
		author = "Florian Roth"
		id = "91b34eb7-61d2-592e-a444-249da43994ca"
		date = "2023-06-07"
		modified = "2023-12-05"
		reference = "https://www.barracuda.com/company/legal/esg-vulnerability"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_lnx_barracuda_cve_2023_2868.yar#L2-L19"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "8849a3273e0362c45b4928375d196714224ec22cb1d2df5d029bf57349860347"
		logic_hash = "57e9afb2f6928656242b8257cc3b98ae3b03e38c75ad40b544e3fc6afaea794d"
		score = 75
		quality = 85
		tags = "CVE-2023-2868, FILE"

	strings:
		$sc1 = { 00 2D 63 00 2F 62 69 6E 2F 73 68 00 }
		$s1 = "SSLShell"

	condition:
		uint32be( 0 ) == 0x7f454c46 and uint16( 0x10 ) == 0x0002 and filesize < 5MB and all of them
}
rule SIGNATURE_BASE_MAL_ELF_SALTWATER_Jun23_1 : CVE_2023_2868 FILE
{
	meta:
		description = "Detects SALTWATER malware used in Barracuda ESG exploitations (CVE-2023-2868)"
		author = "Florian Roth"
		id = "10a038f6-6096-5d3a-aaf5-db441685102b"
		date = "2023-06-07"
		modified = "2023-12-05"
		reference = "https://www.barracuda.com/company/legal/esg-vulnerability"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_lnx_barracuda_cve_2023_2868.yar#L21-L46"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "601f44cc102ae5a113c0b5fe5d18350db8a24d780c0ff289880cc45de28e2b80"
		logic_hash = "cb35898c0ee726170da93b4364920ac065f083f9f02db8eb5d293b1ce127cb78"
		score = 80
		quality = 85
		tags = "CVE-2023-2868, FILE"

	strings:
		$x1 = "libbindshell.so"
		$s1 = "ShellChannel"
		$s2 = "MyWriteAll"
		$s3 = "CheckRemoteIp"
		$s4 = "run_cmd"
		$s5 = "DownloadByProxyChannel"
		$s6 = "[-] error: popen failed"
		$s7 = "/home/product/code/config/ssl_engine_cert.pem"

	condition:
		uint16( 0 ) == 0x457f and filesize < 6000KB and ( ( 1 of ( $x* ) and 2 of them ) or 3 of them ) or all of them
}
rule SIGNATURE_BASE_LOG_EXPL_Adselfservice_CVE_2021_40539_ADSLOG_Sep21 : LOG CVE_2021_40539 FILE
{
	meta:
		description = "Detects suspicious log lines produeced during the exploitation of ADSelfService vulnerability CVE-2021-40539"
		author = "Florian Roth (Nextron Systems)"
		id = "156317c6-e726-506d-8b07-4f74dae2807f"
		date = "2021-09-20"
		modified = "2023-12-05"
		reference = "https://us-cert.cisa.gov/ncas/alerts/aa21-259a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_adselfservice_cve_2021_40539.yar#L2-L14"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "49b7857187c15f48e928747266adca44c227964cef72914616ea269b0e88fe73"
		score = 70
		quality = 85
		tags = "LOG, CVE-2021-40539, FILE"

	strings:
		$x1 = "Java traceback errors that include references to NullPointerException in addSmartCardConfig or getSmartCardConfig" ascii wide

	condition:
		filesize < 50MB and 1 of them
}
rule SIGNATURE_BASE_Mal_Lockbit4_Rc4_Win_Feb24 : FILE
{
	meta:
		description = "Detect the implementation of RC4 Algorithm by Lockbit4.0"
		author = "0x0d4y"
		id = "4de48ced-b9fa-4286-aac4-c263ad20d67d"
		date = "2024-02-13"
		modified = "2026-05-15"
		reference = "https://0x0d4y.blog/lockbit4-0-evasion-tales/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_lockbit4_rc4_win_feb24.yar#L1-L21"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "062311f136d83f64497fd81297360cd4"
		logic_hash = "85e8087f875c45ce39b7014fc0737dc86f1e18d4643fdbb0a80d18feff774680"
		score = 100
		quality = 85
		tags = "FILE"
		license = "CC BY 4.0"
		rule_matching_tlp = "TLP:WHITE"
		rule_sharing_tlp = "TLP:WHITE"
		malpedia_family = "win.lockbit"

	strings:
		$rc4_alg = { 48 3d 00 01 00 00 74 0c 88 84 04 ?? ?? ?? ?? 48 ff c0 eb ec 29 c9 41 b8 ?? ?? ?? ?? 4c 8d 0d 15 7b 00 00 45 31 d2 48 81 f9 00 01 00 00 74 34 44 8a 9c 0c ?? ?? ?? ?? 45 00 da 89 c8 99 41 f7 f8 46 02 14 0a 41 0f b6 c2 8a 94 04 ?? ?? ?? ?? 88 94 0c ?? ?? ?? ?? 44 88 9c 04 ?? ?? ?? ?? 48 ff c1 eb c3 29 c0 48 8b 0d 14 9e 00 00 31 d2 45 29 c0 48 3d ?? ?? ?? ?? 74 4b 41 ff c0 45 0f b6 c0 46 8a 8c 04 ?? ?? ?? ?? 44 00 ca 44 0f b6 d2 46 8a 9c 14 ?? ?? ?? ?? 46 88 9c 04 ?? ?? ?? ?? 46 88 8c 14 ?? ?? ?? ?? 46 02 8c 04 ?? ?? ?? ?? 45 0f b6 c9 46 8a 8c 0c ?? ?? ?? ?? 44 30 0c 01 48 ff c0 eb ad }

	condition:
		uint16( 0 ) == 0x5a4d and $rc4_alg
}
rule SIGNATURE_BASE_APT_UNC1151_Windowsinstaller_Silent_Installproduct_Macromethod : FILE
{
	meta:
		description = "No description has been set in the source file - Signature Base"
		author = "Proofpoint Threat Research"
		id = "9ae80d54-33b9-55d7-957f-0738243e089f"
		date = "2021-07-28"
		modified = "2023-12-05"
		reference = "Thttps://www.proofpoint.com/us/blog/threat-insight/asylum-ambuscade-state-actor-uses-compromised-private-ukrainian-military-emails"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_unc1151_ua.yar#L1-L16"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "1561ece482c78a2d587b66c8eaf211e806ff438e506fcef8f14ae367db82d9b3"
		hash = "a8fd0a5de66fa39056c0ddf2ec74ccd38b2ede147afa602aba00a3f0b55a88e0"
		logic_hash = "aec1bb992061fdf1abf5c1a61cf9ec9e54c1f13be36ceb84890b058ade273b70"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$doc_header = {D0 CF 11 E0 A1 B1 1A E1}
		$s1 = ".UILevel = 2"
		$s2 = "CreateObject(\"WindowsInstaller.Installer\")"
		$s3 = ".InstallProduct \"http"

	condition:
		$doc_header at 0 and all of ( $s* )
}
rule SIGNATURE_BASE_BKDR_Xzutil_Script_CVE_2024_3094_Mar24_1 : CVE_2024_3094
{
	meta:
		description = "Detects make file and script contents used by the backdoored XZ library (xzutil) CVE-2024-3094."
		author = "Florian Roth"
		id = "6b62ffc2-d0a7-5810-97a3-c48f7fac300e"
		date = "2024-03-30"
		modified = "2024-04-24"
		reference = "https://www.openwall.com/lists/oss-security/2024/03/29/4"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/bkdr_xz_util_cve_2024_3094.yar#L2-L17"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "d44d0425769fa2e0b6875e5ca25d45b251bbe98870c6b9bef34f7cea9f84c9c3"
		logic_hash = "8d3f5f078a5c827208e04acb7ac1496f473e1236f92561f94d2a3c8156c68ea6"
		score = 80
		quality = 85
		tags = "CVE-2024-3094"

	strings:
		$x1 = "/bad-3-corrupt_lzma2.xz | tr " ascii
		$x2 = "/tests/files/good-large_compressed.lzma|eval $i|tail -c +31265|" ascii
		$x3 = "eval $zrKcKQ" ascii

	condition:
		1 of them
}
rule SIGNATURE_BASE_BKDR_Xzutil_Binary_CVE_2024_3094_Mar24_1 : CVE_2024_3094 FILE
{
	meta:
		description = "Detects injected code used by the backdoored XZ library (xzutil) CVE-2024-3094."
		author = "Florian Roth"
		id = "6ccdeb6d-67c4-5358-a76b-aef7f047c997"
		date = "2024-03-30"
		modified = "2024-04-24"
		reference = "https://www.openwall.com/lists/oss-security/2024/03/29/4"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/bkdr_xz_util_cve_2024_3094.yar#L19-L46"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "319feb5a9cddd81955d915b5632b4a5f8f9080281fb46e2f6d69d53f693c23ae"
		hash = "605861f833fc181c7cdcabd5577ddb8989bea332648a8f498b4eef89b8f85ad4"
		hash = "8fa641c454c3e0f76de73b7cc3446096b9c8b9d33d406d38b8ac76090b0344fd"
		hash = "b418bfd34aa246b2e7b5cb5d263a640e5d080810f767370c4d2c24662a274963"
		hash = "cbeef92e67bf41ca9c015557d81f39adaba67ca9fb3574139754999030b83537"
		hash = "5448850cdc3a7ae41ff53b433c2adbd0ff492515012412ee63a40d2685db3049"
		logic_hash = "ed364484ff598b0818f9b3249673e684b52394c25b14e47fbca25a5f96ecc970"
		score = 75
		quality = 85
		tags = "CVE-2024-3094, FILE"

	strings:
		$op1 = { 48 8d 7c 24 08 f3 ab 48 8d 44 24 08 48 89 d1 4c 89 c7 48 89 c2 e8 ?? ?? ?? ?? 89 c2 }
		$op2 = { 31 c0 49 89 ff b9 16 00 00 00 4d 89 c5 48 8d 7c 24 48 4d 89 ce f3 ab 48 8d 44 24 48 }
		$op3 = { 4d 8b 6c 24 08 45 8b 3c 24 4c 8b 63 10 89 85 78 f1 ff ff 31 c0 83 bd 78 f1 ff ff 00 f3 ab 79 07 }
		$xc1 = { F3 0F 1E FA 55 48 89 F5 4C 89 CE 53 89 FB 81 E7 00 00 00 80 48 83 EC 28 48 89 54 24 18 48 89 4C 24 10 }

	condition:
		uint16( 0 ) == 0x457f and ( all of ( $op* ) or $xc1 )
}
rule SIGNATURE_BASE_BKDR_Xzutil_Killswitch_CVE_2024_3094_Mar24_1 : CVE_2024_3094
{
	meta:
		description = "Detects kill switch used by the backdoored XZ library (xzutil) CVE-2024-3094."
		author = "Florian Roth"
		id = "0d28bec4-1d3a-5af0-9e9e-49486fcc62e1"
		date = "2024-03-30"
		modified = "2024-04-24"
		reference = "https://gist.github.com/q3k/af3d93b6a1f399de28fe194add452d01?permalink_comment_id=5006558#gistcomment-5006558"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/bkdr_xz_util_cve_2024_3094.yar#L48-L60"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b2024d4b8346c4f74524bb7f3c6b2850684c19471a00e6fa60fff1c41e4a86b6"
		score = 85
		quality = 85
		tags = "CVE-2024-3094"

	strings:
		$x1 = "yolAbejyiejuvnup=Evjtgvsh5okmkAvj"

	condition:
		$x1
}
rule SIGNATURE_BASE_LOG_F5_BIGIP_Exploitation_Artefacts_CVE_2021_22986_Mar21_1 : LOG
{
	meta:
		description = "Detects forensic artefacts indicating successful exploitation of F5 BIG IP appliances as reported by NCCGroup"
		author = "Florian Roth (Nextron Systems)"
		id = "e109ebeb-e5c3-5999-95dc-0963ed8461a6"
		date = "2021-03-20"
		modified = "2023-12-05"
		reference = "https://research.nccgroup.com/2021/03/18/rift-detection-capabilities-for-recent-f5-big-ip-big-iq-icontrol-rest-api-vulnerabilities-cve-2021-22986/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/exploit_f5_bigip_cve_2021_22986_log.yar#L2-L15"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "748bb429d4a086e2890773558ea502ef06f507aed5f0f70470e2cd97a3fd5007"
		score = 80
		quality = 85
		tags = "LOG"

	strings:
		$x1 = "\",\"method\":\"POST\",\"uri\":\"http://localhost:8100/mgmt/tm/util/bash\",\"status\":200," ascii
		$x2 = "[com.f5.rest.app.RestServerServlet] X-F5-Auth-Token doesn't have value, so skipping" ascii

	condition:
		1 of them
}
rule SIGNATURE_BASE_MAL_EXPL_Perfctl_Oct24 : FILE
{
	meta:
		description = "Detects exploits used in relation with Perfctl malware campaigns"
		author = "Florian Roth"
		id = "1f525eaf-445c-592e-bfa4-e9846390dd1d"
		date = "2024-10-09"
		modified = "2024-12-12"
		reference = "https://www.aquasec.com/blog/perfctl-a-stealthy-malware-targeting-millions-of-linux-servers/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_perfctl_oct24.yar#L2-L21"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "22e4a57ac560ebe1eff8957906589f4dd5934ee555ebcc0f7ba613b07fad2c13"
		logic_hash = "44d4683efc66b3c6c2d32be6b83a2bbc1db39c9a020365dddd27c20667bc6a66"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Exploit failed. Target is most likely patched." ascii fullword
		$s2 = "SHELL=pkexec" ascii fullword
		$s3 = "/dump_" ascii fullword
		$s4 = ".EYE$" ascii

	condition:
		uint16( 0 ) == 0x457f and filesize < 30000KB and 2 of them or all of them
}
rule SIGNATURE_BASE_MAL_LNX_Perfctl_Oct24 : FILE
{
	meta:
		description = "Detects Perfctl malware samples"
		author = "Florian Roth"
		id = "391513ae-3348-5297-a22a-6f06e50f06d2"
		date = "2024-10-09"
		modified = "2024-12-12"
		reference = "https://www.aquasec.com/blog/perfctl-a-stealthy-malware-targeting-millions-of-linux-servers/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_perfctl_oct24.yar#L23-L42"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "a6d3c6b6359ae660d855f978057aab1115b418ed277bb9047cd488f9c7850747"
		hash = "ca3f246d635bfa560f6c839111be554a14735513e90b3e6784bedfe1930bdfd6"
		logic_hash = "d47df34240f59124542acc41484e8935327490c04c4e15a558b2ffc6f9c52ea8"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$op1 = { 83 45 f8 01 8b 45 f8 48 3b 45 98 0f 82 1b ff ff ff 90 c9 c3 55 }
		$op2 = { 48 8b 55 a0 48 01 ca 0f b6 0a 48 8b 55 a8 89 c0 88 4c 02 18 8b 45 fc 83 e0 3f }
		$op3 = { 88 4c 10 58 83 45 f8 01 83 7d f8 03 0f 86 68 ff ff ff 90 c9 c3 55 }
		$op4 = { 48 83 ec 68 48 89 7d a8 48 89 75 a0 48 89 55 98 48 8b 45 a8 48 8b 00 83 e0 3f 89 45 fc }

	condition:
		uint16( 0 ) == 0x457f and filesize < 300KB and 2 of them
}
rule SIGNATURE_BASE_SUSP_Reversed_Base64_Encoded_EXE : FILE
{
	meta:
		description = "Detects an base64 encoded executable with reversed characters"
		author = "Florian Roth (Nextron Systems)"
		id = "3b52e59e-7c0a-560f-8123-1099c52e7e3d"
		date = "2020-04-06"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_susp_obfuscation.yar#L63-L84"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "7e6d9a5d3b26fd1af7d58be68f524c4c55285b78304a65ec43073b139c9407a8"
		logic_hash = "0a2f1caf2235ee24f531c9f9a5ebdc0c97a90890218669749a4c83bede80a336"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "AEAAAAEQATpVT"
		$s2 = "AAAAAAAAAAoVT"
		$s3 = "AEAAAAEAAAqVT"
		$s4 = "AEAAAAIAAQpVT"
		$s5 = "AEAAAAMAAQqVT"
		$sh1 = "SZk9WbgM1TEBibpBib1JHIlJGI09mbuF2Yg0WYyd2byBHIzlGaU" ascii
		$sh2 = "LlR2btByUPREIulGIuVncgUmYgQ3bu5WYjBSbhJ3ZvJHcgMXaoR" ascii
		$sh3 = "uUGZv1GIT9ERg4Wag4WdyBSZiBCdv5mbhNGItFmcn9mcwBycphGV" ascii

	condition:
		filesize < 10000KB and 1 of them
}
rule SIGNATURE_BASE_SUSP_Script_Base64_Blocks_Jun20_1
{
	meta:
		description = "Detects suspicious file with base64 encoded payload in blocks"
		author = "Florian Roth (Nextron Systems)"
		id = "cef759a5-b02a-53e7-bf27-184eee6bc3fa"
		date = "2020-06-05"
		modified = "2026-05-15"
		reference = "https://posts.specterops.io/covenant-v0-5-eee0507b85ba"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_susp_obfuscation.yar#L86-L99"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7d456cbbbd76f543afe144a2876a02db834aa6b09ecd4d6aa2f25ce8eeac5de8"
		score = 70
		quality = 85
		tags = ""

	strings:
		$sa1 = "<script language=" ascii
		$sb2 = { 41 41 41 22 2B 0D 0A 22 41 41 41 }

	condition:
		all of them
}
rule SIGNATURE_BASE_SUSP_Reversed_Hacktool_Author : FILE
{
	meta:
		description = "Detects a suspicious path traversal into a Windows folder"
		author = "Florian Roth (Nextron Systems)"
		id = "33e20d75-af07-5df2-82c3-c48aec37a947"
		date = "2020-06-10"
		modified = "2026-05-15"
		reference = "https://hackingiscool.pl/cmdhijack-command-argument-confusion-with-path-traversal-in-cmd-exe/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_susp_obfuscation.yar#L101-L115"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3681fb11dabf9905915d23f4198145b503a260d628415fd79ad71d7703ba9f6f"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "iwiklitneg" fullword ascii wide
		$x2 = " eetbus@ " ascii wide

	condition:
		filesize < 4000KB and 1 of them
}
rule SIGNATURE_BASE_SUSP_Base64_Encoded_Hacktool_Dev : FILE
{
	meta:
		description = "Detects a suspicious base64 encoded keyword"
		author = "Florian Roth (Nextron Systems)"
		id = "6dc7db4b-a614-51e4-a9a5-f869154dbbb1"
		date = "2020-06-10"
		modified = "2026-05-15"
		reference = "https://twitter.com/cyb3rops/status/1270626274826911744"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_susp_obfuscation.yar#L117-L137"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7345a528a12f87e5cbcabccf649566a038dd2115e8aec4f39599e357c8c6d57f"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$ = "QGdlbnRpbGtpd2" ascii wide
		$ = "BnZW50aWxraXdp" ascii wide
		$ = "AZ2VudGlsa2l3a" ascii wide
		$ = "QGhhcm1qMH" ascii wide
		$ = "BoYXJtajB5" ascii wide
		$ = "AaGFybWowe" ascii wide
		$ = "IEBzdWJ0ZW" ascii wide
		$ = "BAc3VidGVl" ascii wide
		$ = "gQHN1YnRlZ" ascii wide

	condition:
		filesize < 6000KB and 1 of them
}
rule SIGNATURE_BASE_MAL_LNX_Camarodragon_Sheel_Oct23 : FILE
{
	meta:
		description = "Detects CamaroDragon's tool named sheel"
		author = "Florian Roth"
		id = "f6f08c0e-236c-5194-9369-da8fdef4aa21"
		date = "2023-10-06"
		modified = "2023-12-05"
		reference = "https://research.checkpoint.com/2023/the-dragon-who-sold-his-camaro-analyzing-custom-router-implant/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_camaro_dragon_oct23.yar#L2-L25"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "7985f992dcc6fcce76ee2892700c8538af075bd991625156bf2482dbfebd5a5a"
		logic_hash = "b06f645b766a099adb71c144bdced70c130735e75d5be6451f71077c7d3a5d19"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "-h server_ip -p server_port -i update_index[0-4] [-r]" ascii fullword
		$s1 = "read_ip" ascii fullword
		$s2 = "open fail.%m" ascii fullword
		$s3 = "ri:h:p:" ascii fullword
		$s4 = "update server list success!" ascii fullword

	condition:
		uint16( 0 ) == 0x457f and filesize < 30KB and ( 1 of ( $x* ) or 3 of them ) or 4 of them
}
rule SIGNATURE_BASE_MAL_LNX_Camarodragon_Horseshell_Oct23 : FILE
{
	meta:
		description = "Detects CamaroDragon's HorseShell implant for routers"
		author = "Florian Roth"
		id = "9e54745f-146f-50a6-b30f-53aaaa6907b5"
		date = "2023-10-06"
		modified = "2023-12-05"
		reference = "https://research.checkpoint.com/2023/the-dragon-who-sold-his-camaro-analyzing-custom-router-implant/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_camaro_dragon_oct23.yar#L27-L56"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "998788472cb1502c03675a15a9f09b12f3877a5aeb687f891458a414b8e0d66c"
		logic_hash = "73adaa286b345cffd35e6ba017b3204d8818dcaeea8a48ca93959566461ac3ca"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "echo \"start shell '%s' failed!\" > .remote_shell.log" ascii fullword
		$x2 = "*****recv NET_REQ_HORSE_SHELL REQ_CONNECT_PORT*****" ascii fullword
		$s1 = "m.cremessage.com" ascii fullword
		$s2 = "POST http://%s/index.php HTTP/1.1" ascii fullword
		$s3 = "wzsw_encrypt_buf" ascii fullword
		$s4 = "body:%d-%s" ascii fullword
		$s5 = "User-Agent: Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident" ascii fullword
		$s6 = "process_http_read_events" ascii fullword
		$op1 = { c4 34 42 00 02 30 63 00 40 10 60 00 09 ae 62 00 48 8e 62 00 cc }
		$op2 = { 27 f4 8c 46 27 f0 03 20 f8 09 00 60 28 21 }

	condition:
		uint16( 0 ) == 0x457f and filesize < 600KB and ( 1 of ( $x* ) or 3 of them ) or 5 of them
}

rule SIGNATURE_BASE_Crime_Win32_Dridex_Socks5_Mod
{
	meta:
		description = "Detects Dridex socks5 module"
		author = "@VK_Intel"
		id = "cee256b1-ad80-55dd-bbd3-0d3f7bc49664"
		date = "2020-04-06"
		modified = "2023-12-05"
		reference = "https://twitter.com/VK_Intel/status/1247058432223477760"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_evilcorp_dridex_banker.yar#L8-L20"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "5ca09e9c7d94e949e453d1bb69b566c12b253579cbcae700929d4f517df35a0a"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s0 = "socks5_2_x32.dll"
		$s1 = "socks5_2_x64.dll"

	condition:
		any of ( $s* ) and pe.exports ( "start" )
}

rule SIGNATURE_BASE_Crime_Win32_Hvnc_Banker_Gen
{
	meta:
		description = "Detects malware banker hidden VNC"
		author = "@VK_Intel"
		id = "5e13f4a9-2231-524f-82b2-fbc6d6a43b6f"
		date = "2020-04-06"
		modified = "2023-12-05"
		reference = "https://twitter.com/VK_Intel/status/1247058432223477760"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_evilcorp_dridex_banker.yar#L22-L31"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b01af685c3826834aadaf4eac1f1d8171db288a2efa7b769d8122421f7af8d7e"
		score = 75
		quality = 85
		tags = ""

	condition:
		pe.exports( "VncStartServer" ) and pe.exports ( "VncStopServer" )
}

rule SIGNATURE_BASE_MAL_RANSOM_Venus_Nov22_1 : FILE
{
	meta:
		description = "Detects Venus Ransomware samples"
		author = "Florian Roth (Nextron Systems)"
		id = "0f7e0ca4-c5e2-5557-92de-2e0d73035f12"
		date = "2022-11-16"
		modified = "2023-12-05"
		reference = "https://twitter.com/dyngnosis/status/1592588860168421376"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_ransom_venus.yar#L3-L38"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "46f9cbc3795d6be0edd49a2c43efe6e610b82741755c5076a89eeccaf98ee834"
		hash = "6d8e2d8f6aeb0f4512a53fe83b2ef7699513ebaff31735675f46d1beea3a8e05"
		hash = "931cab7fbc0eb2bbc5768f8abdcc029cef76aff98540d9f5214786dccdb6a224"
		hash = "969bfe42819e30e35ca601df443471d677e04c988928b63fccb25bf0531ea2cc"
		hash = "db6fcd33dcb3f25890c28e47c440845b17ce2042c34ade6d6508afd461bfa21c"
		hash = "ee036f333a0c4a24d9aa09848e635639e481695a9209474900eb71c9e453256b"
		hash = "fa7ba459236c7b27a0429f1961b992ab87fc8b3427469fd98bfc272ae6852063"
		logic_hash = "3c94d59015897f180ef55608a2761b37c7b52193e28895ea6a4c0548acf3ad34"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "<html><head><title>Venus</title><style type = \"text" ascii fullword
		$x2 = "xXBLTZKmAu9pjcfxrIK4gkDp/J9XXATjuysFRXG4rH4=" ascii fullword
		$x3 = "%s%x%x%x%x.goodgame" wide fullword
		$s1 = "/c ping localhost -n 3 > nul & del %s" ascii fullword
		$s2 = "C:\\Windows\\%s.png" wide
		$op1 = { 8b 4c 24 24 46 8b 7c 24 14 41 8b 44 24 30 81 c7 00 04 00 00 81 44 24 10 00 04 00 00 40 }
		$op2 = { 57 c7 45 fc 00 00 00 00 7e 3f 50 33 c0 74 03 9b 6e }
		$op3 = { 66 89 45 d4 0f 11 45 e8 e8 a8 e7 ff ff 83 c4 14 8d 45 e8 50 8d 45 a4 50 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 700KB and ( pe.imphash ( ) == "bb2600e94092da119ee6acbbd047be43" or 1 of ( $x* ) or 2 of them ) or 4 of them
}
rule SIGNATURE_BASE_SUSP_Themebleed_Theme_Sep23 : FILE
{
	meta:
		description = "Detects domain or IP placement in Windows theme files"
		author = "@m_haggis, @nas_bench"
		id = "76d0042b-655d-5d03-bcc4-150ebc92eb43"
		date = "2023-09-13"
		modified = "2023-12-05"
		reference = "https://github.com/gabe-k/themebleed"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/exploit_cve_2023_38146.yar#L1-L17"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "577003741f07aeffafd2b0b22913de44ea4f5ed264f4104ee013104355f65311"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = /Path=\\\\[0-9a-zA-Z\.-]{1,20}\\/
		$s2 = "[VisualStyles]"
		$s3 = "[Theme]"

	condition:
		filesize < 1MB and all of them
}
rule SIGNATURE_BASE_SUSP_Maldoc_Excelmacro : FILE
{
	meta:
		description = "Detects malicious Excel macro Artifacts"
		author = "James Quinn"
		id = "76806717-a9a8-520e-b6b6-7718eb088de5"
		date = "2020-11-03"
		modified = "2023-12-05"
		reference = "YARA Exchange - Undisclosed Macro Builder"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_macro_builders.yar#L2-L19"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c5d0655eaf2ca36c828675f9673a1d4284ef8719fd9ec1d354ee3284d1fb0a0c"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$artifact1 = {5c 00 ?? 00 ?? 00 ?? 00 ?? 00 ?? 00 ?? 00 ?? 00 2e 00 ?? 00 ?? 00}
		$url1 = "http://" wide
		$url2 = "https://" wide
		$import1 = "URLDownloadToFileA" wide ascii
		$macro = "xl/macrosheets/"

	condition:
		uint16( 0 ) == 0x4b50 and filesize < 2000KB and $artifact1 and $macro and $import1 and 1 of ( $url* )
}
rule SIGNATURE_BASE_SUSP_Macro_Sheet_Obfuscated_Char : FILE
{
	meta:
		description = "Finding hidden/very-hidden macros with many CHAR functions"
		author = "DissectMalware"
		id = "791e9bba-3e4e-5efd-a800-a612c6f92cfb"
		date = "2020-04-07"
		modified = "2023-12-05"
		reference = "https://twitter.com/DissectMalware/status/1247595433305800706"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_susp_office_dropper.yar#L122-L139"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0e9ec7a974b87f4c16c842e648dd212f80349eecb4e636087770bc1748206c3b"
		logic_hash = "0953d1f916df570cb3d053bf4fdac196bdbd806df4b6c0a982ed9949a3676e6c"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$ole_marker = {D0 CF 11 E0 A1 B1 1A E1}
		$s1 = "Excel" fullword ascii
		$macro_sheet_h1 = {85 00 ?? ?? ?? ?? ?? ?? 01 01}
		$macro_sheet_h2 = {85 00 ?? ?? ?? ?? ?? ?? 02 01}
		$char_func = {06 ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? 1E 3D  00 41 6F 00}

	condition:
		$ole_marker at 0 and 1 of ( $macro_sheet_h* ) and #char_func > 10 and $s1
}
rule SIGNATURE_BASE_APT_MAL_CISA_10365227_03_Clientuploader_Dec21 : FILE
{
	meta:
		description = "Detects ClientUploader onedrv"
		author = "CISA Code & Media Analysis"
		id = "4eeadb28-9312-5602-932a-36acb48772f4"
		date = "2021-12-23"
		modified = "2021-12-24"
		reference = "https://www.cisa.gov/uscert/ncas/analysis-reports/ar22-277a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_stealer_cisa_ar22_277a.yar#L4-L23"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "84164e1e8074c2565d3cd178babd93694ce54811641a77ffdc8d1084dd468afb"
		logic_hash = "76f552b2416ae2426b73a321485f34a611c2a3c1ca35791bc9f1834072dc28be"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Decoder2"
		$s2 = "ClientUploader"
		$s3 = "AppDomain"
		$s4 = { 5F 49 73 52 65 70 47 ?? 44 65 63 6F 64 65 72 73 }
		$s5 = "LzmaDecoder"
		$s6 = "$ee1b3f3b-b13c-432e-a461-e52d273896a7"

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule SIGNATURE_BASE_APT_MAL_CISA_10365227_01_APPSTORAGE_Dec21 : APPSTORAGE FILE
{
	meta:
		description = "Detects AppStorage ntstatus msexch samples"
		author = "CISA Code & Media Analysis"
		id = "a44c5609-980f-5961-921c-6b1824cdd49c"
		date = "2021-12-23"
		modified = "2021-12-24"
		reference = "https://www.cisa.gov/uscert/ncas/analysis-reports/ar22-277a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_stealer_cisa_ar22_277a.yar#L25-L46"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "157a0ffd18e05bfd90a4ec108e5458cbde01015e3407b3964732c9d4ceb71656"
		hash = "30191b3badf3cdbc65d0ffeb68e0f26cef10a41037351b0f562ab52fce7432cc"
		logic_hash = "6a46bc4efa1f22d9fc65d946dbaa7b94de6074e65c228373bb6001f152d5b603"
		score = 80
		quality = 85
		tags = "APPSTORAGE, FILE"
		family = "APPSTORAGE"

	strings:
		$s1 = "026B924DD52F8BE4A3FEE8575DC"
		$s2 = "GetHDDId"
		$s3 = "AppStorage"
		$s4 = "AppDomain"
		$s5 = "$1e3e5580-d264-4c30-89c9-8933c948582c"
		$s6 = "hrjio2mfsdlf235d" wide

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule SIGNATURE_BASE_APT_MAL_CISA_10365227_02_Clientuploader_Dec21 : FILE
{
	meta:
		description = "Detects ClientUploader_mqsvn"
		author = "CISA Code & Media Analysis"
		id = "84351df9-e225-5c3f-9385-523246681a97"
		date = "2021-12-23"
		modified = "2021-12-24"
		reference = "https://www.cisa.gov/uscert/ncas/analysis-reports/ar22-277a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_stealer_cisa_ar22_277a.yar#L48-L67"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "3585c3136686d7d48e53c21be61bb2908d131cf81b826acf578b67bb9d8e9350"
		logic_hash = "f9f82b4577568d0bd60bac0d3132ed7ffcb338f508a8689f3126f3d2440432ef"
		score = 80
		quality = 81
		tags = "FILE"

	strings:
		$s1 = "UploadSmallFileWithStopWatch"
		$s2 = "UploadPartWithStopwatch"
		$s3 = "AppVClient"
		$s4 = "ClientUploader"
		$s5 = { 46 69 6C 65 43 6F 6E 74 61 69 6E 65 72 2E 46 69 6C 65 41 72 63 68 69 76 65 }
		$s6 = { 4F 6E 65 44 72 69 76 65 43 6C 69 65 6E 74 2E 4F 6E 65 44 72 69 76 65 }

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule SIGNATURE_BASE_HKTL_NFS_Fuse_NFS
{
	meta:
		description = "Detects the nfs-security-tooling fuse_nfs by HvS Consulting"
		author = "Moritz Oettle"
		id = "287fbe7d-ee1c-58a4-aa2d-9d9bec8321b4"
		date = "2024-10-22"
		modified = "2025-03-20"
		reference = "https://github.com/hvs-consulting/nfs-security-tooling"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/hktl_HvS_nfs_security_tooling.yar#L1-L24"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "0bd3714b865d77660404e5f3ed1e9c7b55aadc6f58d16761111be57597784686"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "NFS3ConnectionFactory" fullword ascii
		$s2 = "fuse_to_nfs_timestamp" fullword ascii
		$s3 = "--manual-fh" fullword ascii
		$s4 = "--fake-uid-allow-root" fullword ascii
		$s5 = "nfs.rpc.credential" fullword ascii
		$s6 = "nfs.readlink" fullword ascii
		$s7 = "pyfuse3.EntryAttributes" fullword ascii
		$s8 = "Make nested exports on NetApp servers work" fullword ascii
		$s9 = "add_mutually_exclusive_group" fullword ascii

	condition:
		4 of them
}
rule SIGNATURE_BASE_HKTL_NFS_NFS_Analyze
{
	meta:
		description = "Detects the nfs-security-tooling nfy_analyze by HvS Consulting"
		author = "Marc Stroebel"
		id = "3350d0ae-e638-5c8f-a578-ba0ac5521053"
		date = "2024-10-22"
		modified = "2025-03-20"
		reference = "https://github.com/hvs-consulting/nfs-security-tooling"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/hktl_HvS_nfs_security_tooling.yar#L26-L53"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "83a9e5b5b404bf28b0334611fe4f38227212783cecea3c9996d23cb00cad42ed"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "no_root_squash_exports" fullword ascii
		$s2 = "nfs lock manager" fullword ascii
		$s3 = "netapp partner" fullword ascii
		$s4 = "xdrdef.mnt3_type" fullword ascii
		$s5 = "BTRFS subvolumes" fullword ascii
		$s6 = "Unsupported fsid" fullword ascii
		$s7 = "nfs3_read_etc_shadow" fullword ascii
		$s8 = "nfs3_check_no_root_squash" fullword ascii
		$s9 = "krb5i" fullword ascii
		$s10 = "nfs4_overview" fullword ascii
		$s11 = "--btrfs-subvolumes" fullword ascii
		$s12 = "when escaping a BTRFS export" fullword ascii
		$s13 = "No NFS server detected" fullword ascii

	condition:
		6 of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Csharpsetthreadcontext : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "883bb859-d5ab-501d-8c83-0c5a2cf1f6c8"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/djhohnstein/CSharpSetThreadContext"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L6-L20"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1fab70ce4bb1a00d8e8155ce7d859aa2f8d193dd40378a8fff0fdfb1c94f9a76"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "a1e28c8c-b3bd-44de-85b9-8aa7c18a714d" ascii wide
		$typelibguid1lo = "87c5970e-0c77-4182-afe2-3fe96f785ebb" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_DLL_Injection : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "aec4fc28-9aa2-5eef-9fb1-d187a83a72b3"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/ihack4falafel/DLL-Injection"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L22-L35"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a9ad0c7a68602214cf31d9b065b9b2c5f7eb616bcec0f3428e958c0f762282b2"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "3d7e1433-f81a-428a-934f-7cc7fcf1149d" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Limeusb_Csharp : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "dfa96b36-e84c-510b-b16b-bd686777b83d"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/NYAN-x-CAT/LimeUSB-Csharp"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L37-L50"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "cd5b12c43046e56ebef78104fd7a9389476686bd4adca4964fc8b559432ae236"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "94ea43ab-7878-4048-a64e-2b21b3b4366d" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Ladon : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "57e3d2fa-d430-561b-9d42-cf58cda5ed7a"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/k8gege/Ladon"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L52-L65"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1a2c6d3bb2964847aaff4828bbd7b75301e287bcff3f27324bc7767c0f73820f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "c335405f-5df2-4c7d-9b53-d65adfbed412" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Whitelistevasion : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "cd2740d0-0315-5a32-b34a-1998024fcc06"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/khr0x40sh/WhiteListEvasion"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L67-L80"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "38838b45c3c7359e49f890f5f7608e5a6026421e83b0ef7371c8558c571395a6"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "858386df-4656-4a1e-94b7-47f6aa555658" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Lime_Downloader : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "bfb0f97c-6d95-5e11-ad11-5297bcf7c3df"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/NYAN-x-CAT/Lime-Downloader"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L82-L95"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8086f6be648bcb5535b98aafc5fd898dc975273eec3c19a54263f74bb7c0f629"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "ec7afd4c-fbc4-47c1-99aa-6ebb05094173" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Darkeye : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "5dc6702f-a398-5be2-9df8-9a2ddc636a1f"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/K1ngSoul/DarkEye"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L97-L110"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7571ed93fd3ea690549ab35682b0073e1c2b9ac57e36394d35794aba7c50b79e"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "0bdb9c65-14ed-4205-ab0c-ea2151866a7f" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpkatz : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "ff084b4c-4b00-5504-85ee-d6d17b5be504"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/b4rtik/SharpKatz"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L112-L125"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8899192a8006bb31ce4277fc371a30b301ffc1a42030ca3a4059a2b53c889bae"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "8568b4c1-2940-4f6c-bf4e-4383ef268be9" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Externalc2 : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "1bbdfbb9-a3e8-5ffe-9db9-b50937e6a14d"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/ryhanson/ExternalC2"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L127-L141"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "81042972411ab82da8460f9e263614f563bc67e3ce585f1a955b565b066ee8c9"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "7266acbb-b10d-4873-9b99-12d2043b1d4e" ascii wide
		$typelibguid1lo = "5d9515d0-df67-40ed-a6b2-6619620ef0ef" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Povlsomware : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "0eba43d2-b415-5e72-9677-4a3238ff7c34"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/povlteksttv/Povlsomware"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L143-L156"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f8e246080ffcaa73ad727d2d9a1f2b75f2d413b49dff0c3b50831a41e1f14a2f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "fe0d5aa7-538f-42f6-9ece-b141560f7781" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Runshellcode : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "249da967-68b0-59b1-b414-4eb4fe67b8f3"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/zerosum0x0/RunShellcode"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L158-L171"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "5df20e170651f32e41a905992d0bb52542638e2d0a56841db900b70e324c9afe"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "a3ec18a3-674c-4131-a7f5-acbed034b819" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharploginprompt : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "e9a493d9-21b6-5ff1-9e5e-e8fbacc34c0c"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/shantanu561993/SharpLoginPrompt"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L173-L186"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e8abbc67d568956bf98e733b1e98910d0501225d4a0dc0bec6be9b572fcc2b36"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "c12e69cd-78a0-4960-af7e-88cbd794af97" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Adamantium_Thief : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "82225b2e-ab4a-50b8-a3fd-7ad4947d052e"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/LimerBoy/Adamantium-Thief"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L188-L201"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "37303dd37952d08ca2f85d03b4a9a8d52a3c55870e1350bca7ac84749942dfd8"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "e6104bc9-fea9-4ee9-b919-28156c1f2ede" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Psbypassclm : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "dad6729f-3d96-5d2d-b72c-a96d1a3eae74"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/padovah4ck/PSByPassCLM"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L203-L216"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a2646ff961b5fc94035fae0b7e5afedc054dfcfe710701dbf9ba17674c2bb6c8"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "46034038-0113-4d75-81fd-eb3b483f2662" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Physmem2Profit : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "75a27970-c469-53da-b0c3-b3d0faea0b6f"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/FSecureLABS/physmem2profit"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L218-L231"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "57e6159bc047c372bb7fa9ac0f77183fe06fe3f41b83039f8b0185f2743cc774"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "814708c9-2320-42d2-a45f-31e42da06a94" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Noamci : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "5fab1551-9d35-53cf-a04f-c14370119553"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/med0x2e/NoAmci"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L233-L246"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7d934503bab7318930f958b1818037f00d3d5be7f5f89f3b519c5072bb4fee03"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "352e80ec-72a5-4aa6-aabe-4f9a20393e8e" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpblock : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "b84538da-1b0e-50c7-abfa-e93d6de5a49b"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/CCob/SharpBlock"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L248-L261"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7bc689efc6f89ac685f1066da4e9735a0e2b985008679c51e14664cebdaebe4a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "3cf25e04-27e4-4d19-945e-dadc37c81152" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Nopowershell : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "0fd7496b-e34f-51f7-9270-ad424ed6a7a8"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/bitsadmin/nopowershell"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L263-L276"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "5e4088d451cdc939608fb82f0259d3b60ce8247dfd2f76de839681c9e3d60414"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "555ad0ac-1fdb-4016-8257-170a74cb2f55" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Limelogger : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "0798f01b-76b7-5c4d-9ddb-5e377b86f8b9"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/NYAN-x-CAT/LimeLogger"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L278-L291"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "58588726f5f548b9aa948eac6d752404aa43fed18ccd4340422a652b9b061c9b"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "068d14ef-f0a1-4f9d-8e27-58b4317830c6" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Aggressorscripts : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "d5903db5-010b-5b9d-8a5b-5d61aec52e7a"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/harleyQu1nn/AggressorScripts"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L293-L306"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b5d84b6dea0290b901f1d911f341a2b15ab42cf9197775d9bb2f613f4baeb69d"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "afd1ff09-2632-4087-a30c-43591f32e4e8" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Gopher : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "e3015719-9085-584d-8237-f377ec995149"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/EncodeGroup/Gopher"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L308-L321"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "430727d064ae07a4ca4411ee78fe74c684ce21d287283467c1afb9795545003e"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "b5152683-2514-49ce-9aca-1bc43df1e234" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Aviator : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "52acd520-52aa-5bb9-ab3b-66a940aa5f5a"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/Ch0pin/AVIator"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L323-L336"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9101444f7d9306058a42b0325fefc0a088d1669932e4a6ba23b387829f01a097"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "4885a4a3-4dfa-486c-b378-ae94a221661a" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Njcrypter : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "c30c8323-9418-521a-a4fc-6be0113b99b5"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/0xPh0enix/njCrypter"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L338-L352"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "2e3c616b75e15ad082cf0871b7ef8e04f0c2a937000f4bea6927962451ac7f12"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "8a87b003-4b43-467b-a509-0c8be05bf5a5" ascii wide
		$typelibguid1lo = "80b13bff-24a5-4193-8e51-c62a414060ec" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpminidump : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "e91e6711-d992-5a8a-97e6-1ed7847f38a4"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/b4rtik/SharpMiniDump"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L354-L367"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "eea9a60c5d0acb1ffa7cbfec59f2a3f7f29b507fba2c3694480627c583d24c97"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "6ffccf81-6c3c-4d3f-b15f-35a86d0b497f" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Cinarat : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "c6b4c919-0fc6-5096-b29b-963142a2c831"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/wearelegal/CinaRAT"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L369-L383"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d3e006450f3bd35d9d8b0d5c74470f555917d8b3583285ac3ac925ce2a83972b"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "8586f5b1-2ef4-4f35-bd45-c6206fdc0ebc" ascii wide
		$typelibguid1lo = "fe184ab5-f153-4179-9bf5-50523987cf1f" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Toxiceye : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "0b7b62ce-9c24-5d81-8d87-22f6e461a62b"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/LimerBoy/ToxicEye"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L385-L398"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "58070408e4c08d20a3f37a2bf59f4b125ef4608e9ee3e7ed5fe1e26ad51b6c88"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "1bcfe538-14f4-4beb-9a3f-3f9472794902" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Disable_Windows_Defender : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "9a673427-e66e-594b-942a-64a2272319f3"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/NYAN-x-CAT/Disable-Windows-Defender"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L400-L413"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "65cc86433a3c4cb22ad54065b90010a0f3eb18ad8791c45343d103deea880195"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "501e3fdc-575d-492e-90bc-703fb6280ee2" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Dinvoke_Poc : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "f3b0ef47-a92c-5c5d-a9e2-09579fcb438e"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/dtrizna/DInvoke_PoC"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L415-L428"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "51299abecf7244d150e7c148b5896cd64bcf5817a9a962013d6a986891bd321f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "5a869ab2-291a-49e6-a1b7-0d0f051bef0e" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Reverseshell : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "876932d5-a65d-5230-9cb8-24038ad8af0d"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/chango77747/ReverseShell"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L430-L444"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "cf8220444b6ffe810451e4754f8561e80acd99f8b5fbb013e8eef488b3c4243e"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "980109e4-c988-47f9-b2b3-88d63fababdc" ascii wide
		$typelibguid1lo = "8abe8da1-457e-4933-a40d-0958c8925985" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpc2 : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "2ed6d74e-2b95-5c70-807a-4da5e62f5853"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/SharpC2/SharpC2"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L446-L464"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "5439cbe057d5735e3d35ac01966fc65ca0727e1c1c353564d38d1c20bb04484a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "62b9ee4f-1436-4098-9bc1-dd61b42d8b81" ascii wide
		$typelibguid1lo = "d2f17a91-eb2d-4373-90bf-a26e46c68f76" ascii wide
		$typelibguid2lo = "a9db9fcc-7502-42cd-81ec-3cd66f511346" ascii wide
		$typelibguid3lo = "ca6cc2ee-75fd-4f00-b687-917fa55a4fae" ascii wide
		$typelibguid4lo = "a1167b68-446b-4c0c-a8b8-2a7278b67511" ascii wide
		$typelibguid5lo = "4d8c2a88-1da5-4abe-8995-6606473d7cf1" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sneakyexec : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "853b630d-77ba-5847-a129-c9fa0538f81b"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/HackingThings/SneakyExec"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L466-L479"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "cb2d505666c4395c9e43607468332c7559807d4da063eb69b31638f2520fee0e"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "612590aa-af68-41e6-8ce2-e831f7fe4ccc" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Urbanbishoplocal : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "53b690ec-7d20-5e46-b368-b458ce56073d"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/slyd0g/UrbanBishopLocal"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L481-L494"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "cd0ded2fbfbf0fb8c53928e3f1bc4425bfa6112b92b609f421d517f931814faa"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "88b8515e-a0e8-4208-a9a0-34b01d7ba533" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpshell : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "5966be44-c010-5c63-9576-1aaf36397d6c"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/cobbr/SharpShell"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L496-L510"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9d49e6a85514fb47bd6875372cbbc8fc1d30e8572ce6e5caa594da07f58d4c06"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "bdba47c5-e823-4404-91d0-7f6561279525" ascii wide
		$typelibguid1lo = "b84548dc-d926-4b39-8293-fa0bdef34d49" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Evilwmiprovider : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "3a6cf00e-28c4-5e6f-a28d-b3f28fca6eed"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/sunnyc7/EvilWMIProvider"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L512-L525"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "431aa788d1cd192803ad7a5cc66ea48b7a83d47e009c42280e3e77c6ffb8662c"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "a4020626-f1ec-4012-8b17-a2c8a0204a4b" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Gadgettojscript : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "e296795f-d006-52a9-92c4-fb60c930564b"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/med0x2e/GadgetToJScript"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L527-L541"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b072024bc927eaff8bb81bc660dd55a126f9b78e5db591042137b59647631544"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "af9c62a1-f8d2-4be0-b019-0a7873e81ea9" ascii wide
		$typelibguid1lo = "b2b3adb0-1669-4b94-86cb-6dd682ddbea3" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Azurecli_Extractor : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "f595545a-a7a6-577c-b3f4-febf7bf1b6c3"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/0x09AL/AzureCLI-Extractor"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L543-L556"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6c55a291ba3475a7c7faa2a0152c04b01066a3b3569a5fb052c092b08a8e75ae"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "a73cad74-f8d6-43e6-9a4c-b87832cdeace" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_UAC_Escaper : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "ea95ff3c-0cbb-5230-b5e4-bd8b2ff975eb"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/NYAN-x-CAT/UAC-Escaper"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L558-L571"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8b7315970124c7997ca7d7d21e6c26ac9c905cdbc1ee009f7800b6bc98f9c3d4"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "95359279-5cfa-46f6-b400-e80542a7336a" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Httpsbeaconshell : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "d66e3566-6082-570a-a168-f44c9d8c7619"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/limbenjamin/HTTPSBeaconShell"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L573-L586"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4e51832b9a5f7b82da2f11bcb34664b0a8d0308b0e823436f4339233c07213b3"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "aca853dc-9e74-4175-8170-e85372d5f2a9" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Amsiscanbufferbypass : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "12a15e61-30fb-50a3-a59b-39f9871444f0"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/rasta-mouse/AmsiScanBufferBypass"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L588-L601"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "227b9878e11d1e14aa216cc9d46364cff727b1443f4c18f083971be8dd5e603c"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "431ef2d9-5cca-41d3-87ba-c7f5e4582dd2" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Shellcodeloader : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "b8787dac-48a3-5711-86ba-0fda86b6224e"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/Hzllaga/ShellcodeLoader"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L603-L616"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3461e21a0a0661be9830023d56ecdd0434ab9f32328118ad87b2216061851127"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "a48fe0e1-30de-46a6-985a-3f2de3c8ac96" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Keystrokeapi : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "e715bce8-531b-5e2a-bd02-b2fc4990c499"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/fabriciorissetto/KeystrokeAPI"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L618-L632"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "36690992d1e5f3df52ad3a3fc218335ee78ce5e1bf7433fa769c8ee618f00b9e"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "f6fec17e-e22d-4149-a8a8-9f64c3c905d3" ascii wide
		$typelibguid1lo = "b7aa4e23-39a4-49d5-859a-083c789bfea2" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Shellcoderunner : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "949364e7-dcb6-5afd-ade9-cc34a6e15e97"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/antman1p/ShellCodeRunner"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L634-L648"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "fecb1562fe42fa512ab3dd932019fa9ba2c09d574e909361c3af9e190cd5db17"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "634874b7-bf85-400c-82f0-7f3b4659549a" ascii wide
		$typelibguid1lo = "2f9c3053-077f-45f2-b207-87c3c7b8f054" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Offensivecsharp : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "339f6858-6076-5320-ba5f-2903e642ea42"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/diljith369/OffensiveCSharp"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L650-L674"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "64beb345845aeb7083a2c35d94fa433e95dd810b82c0cf392dd5e3de3bb5b110"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "6c3fbc65-b673-40f0-b1ac-20636df01a85" ascii wide
		$typelibguid1lo = "2bad9d69-ada9-4f1e-b838-9567e1503e93" ascii wide
		$typelibguid2lo = "512015de-a70f-4887-8eae-e500fd2898ab" ascii wide
		$typelibguid3lo = "1ee4188c-24ac-4478-b892-36b1029a13b3" ascii wide
		$typelibguid4lo = "5c6b7361-f9ab-41dc-bfa0-ed5d4b0032a8" ascii wide
		$typelibguid5lo = "048a6559-d4d3-4ad8-af0f-b7f72b212e90" ascii wide
		$typelibguid6lo = "3412fbe9-19d3-41d8-9ad2-6461fcb394dc" ascii wide
		$typelibguid7lo = "9ea4e0dc-9723-4d93-85bb-a4fcab0ad210" ascii wide
		$typelibguid8lo = "6d2b239c-ba1e-43ec-8334-d67d52b77181" ascii wide
		$typelibguid9lo = "42e8b9e1-0cf4-46ae-b573-9d0563e41238" ascii wide
		$typelibguid10lo = "0d15e0e3-bcfd-4a85-adcd-0e751dab4dd6" ascii wide
		$typelibguid11lo = "644dfd1a-fda5-4948-83c2-8d3b5eda143a" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_SHAPESHIFTER : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "8903c65a-624f-5e8d-a3f6-4572b56bd2f7"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/matterpreter/SHAPESHIFTER"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L676-L689"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "87804b4f657dd838e969e41320d08455470611688f1624632df03868d204490d"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "a3ddfcaa-66e7-44fd-ad48-9d80d1651228" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Evasor : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "457959ed-3e90-52c7-89f9-e1b17b35260e"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/cyberark/Evasor"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L691-L704"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "883dcb8214c036d4a81ee09f97f206f19f24c6a6526437ba61145cb01cb2b1ba"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "1c8849ef-ad09-4727-bf81-1f777bd1aef8" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Stracciatella : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "5b1a8102-6d59-5f2f-8ae2-b3c1f75a561d"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/mgeeky/Stracciatella"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L706-L719"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ca28e325cd98f2c9793c434dfd57404e17ed80e57023095d877993a01ee718ee"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "eaafa0ac-e464-4fc4-9713-48aa9a6716fb" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Logger : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "82937fef-8280-5bc6-af4a-55c5cb3a7553"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/xxczaki/logger"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L721-L734"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "bf77dcb7fccad566e998df42e9a8248a117a8636500b80fe885d756cfa999f37"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "9e92a883-3c8b-4572-a73e-bb3e61cfdc16" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Internal_Monologue : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "ce2773a2-b0b7-560e-ba21-3f018ddcacb3"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/eladshamir/Internal-Monologue"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L736-L750"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "983273ebcba36e8a22d5bda8bdbba0e1fb31fb128a76a7b39aa012bc83873aff"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "0c0333db-8f00-4b68-b1db-18a9cacc1486" ascii wide
		$typelibguid1lo = "84701ace-c584-4886-a3cf-76c57f6e801a" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_GRAT2 : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "e731d563-0d16-5f84-8127-624a71f8b646"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/r3nhat/GRAT2"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L752-L765"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "535f24d46b317dc5c74779931deb92dd922a79cba4f48588763a3d717bbdec82"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "5e7fce78-1977-444f-a18e-987d708a2cff" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Powershdll : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "3f582a47-078e-525f-9d02-4ee7a455a3b2"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/p3nt4/PowerShdll"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L767-L780"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "0c2b4a2e3008605c35296d2064d4ab3dbb62230db57d1756f0c11e47a303c007"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "36ebf9aa-2f37-4f1d-a2f1-f2a45deeaf21" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Csharpamsibypass : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "ca97004e-edc1-5b5a-ac67-e81ae24631aa"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/WayneJLee/CsharpAmsiBypass"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L782-L795"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "65daf297f51dd75ed3616504df96aea9b7a61aebd5a3b43c208f1709daedc193"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "4ab3b95d-373c-4197-8ee3-fe0fa66ca122" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Hastyseries : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "0d35acf4-c763-593c-94e2-c499d3826375"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/obscuritylabs/HastySeries"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L797-L819"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4987c7afbf339a6a21634eb4647a0b09bfa149d330b7fb2aea2467a25e629c62"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "8435531d-675c-4270-85bf-60db7653bcf6" ascii wide
		$typelibguid1lo = "47db989f-7e33-4e6b-a4a5-c392b429264b" ascii wide
		$typelibguid2lo = "300c7489-a05f-4035-8826-261fa449dd96" ascii wide
		$typelibguid3lo = "41bf8781-ae04-4d80-b38d-707584bf796b" ascii wide
		$typelibguid4lo = "620ed459-18de-4359-bfb0-6d0c4841b6f6" ascii wide
		$typelibguid5lo = "91e7cdfe-0945-45a7-9eaa-0933afe381f2" ascii wide
		$typelibguid6lo = "c28e121a-60ca-4c21-af4b-93eb237b882f" ascii wide
		$typelibguid7lo = "698fac7a-bff1-4c24-b2c3-173a6aae15bf" ascii wide
		$typelibguid8lo = "63a40d94-5318-42ad-a573-e3a1c1284c57" ascii wide
		$typelibguid9lo = "56b8311b-04b8-4e57-bb58-d62adc0d2e68" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Dreamprotectorfree : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "9ebee989-3441-5a76-b243-08de978b541c"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/Paskowsky/DreamProtectorFree"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L821-L834"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "bd8a6373695b9ab69fdf9e7f4a65c2db4e7a5f6f04f6d308ec352322a396aa44"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "f7e8a902-2378-426a-bfa5-6b14c4b40aa3" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Redsharp : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "2aa62d61-075c-5664-a7fc-2b9d84b954ed"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/padovah4ck/RedSharp"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L836-L849"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b751bedba84e8fc253686a7acd33e46a96140f2903f99ce1df6b4932d475bf30"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "30b2e0cf-34dd-4614-a5ca-6578fb684aea" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_ESC : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "a57c47e8-62bf-5425-9735-35a3e3a0c218"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/NetSPI/ESC"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L851-L865"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "0a8244145b25260912c8b1d2968fe33fb8497762a6d8f2bbb88a734346990d55"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "06260ce5-61f4-4b81-ad83-7d01c3b37921" ascii wide
		$typelibguid1lo = "87fc7ede-4dae-4f00-ac77-9c40803e8248" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Csharp_Loader : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "bf0c3d93-cbea-54c7-b950-fd4e5a600d07"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/NYAN-x-CAT/Csharp-Loader"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L867-L880"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "aa1a176ce3dbf6ae43d921822d2ab1689a4bf74077fa2a9aa72534ab3cfa3ecc"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "5fd7f9fc-0618-4dde-a6a0-9faefe96c8a1" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Bantam : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "0ed3f5e5-d954-51e2-b7fb-4c25ca3d9f10"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/gellin/bantam"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L882-L895"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "2dce37cd31fa359658519bd50fbb335fc6fd82af5e78a4d86d173d3628e0951f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "14c79bda-2ce6-424d-bd49-4f8d68630b7b" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharptask : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "2cdd1a15-c70c-5eea-b5a7-8b4a445b9323"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/jnqpblc/SharpTask"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L897-L910"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c3f4ddf4ea9389e01611880a47f2a199938e9a5e0f05df4e7f772f7a9acedc61"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "13e90a4d-bf7a-4d5a-9979-8b113e3166be" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Windowsplague : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "89729c43-ae01-5c1f-af04-06d7a6c4e7fc"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/RITRedteam/WindowsPlague"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L912-L925"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "01ad0621f2bb129fd963093b65cd054bc2a2e185f21041c779b02b1e63475a1c"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "cdf8b024-70c9-413a-ade3-846a43845e99" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Misc_Csharp : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "d25fa706-2254-5a82-a961-f57a0daa447c"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/jnqpblc/Misc-CSharp"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L927-L941"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "32893d4396842c3df3756d7090a1e86bf73c5ad2476aab5d6c53db8bdae9c31a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "d1421ba3-c60b-42a0-98f9-92ba4e653f3d" ascii wide
		$typelibguid1lo = "2afac0dd-f46f-4f95-8a93-dc17b4f9a3a1" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpspray : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "e9312c96-be10-5942-a4da-1fe708cc6699"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/jnqpblc/SharpSpray"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L943-L956"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "15ad567589656894f0da6ee56c26f48868936db015d0b41c04ccd6fd56f5753e"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "51c6e016-1428-441d-82e9-bb0eb599bbc8" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Obfuscator : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "d9988b00-1f10-5421-8ffe-49849a5d5902"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/3xpl01tc0d3r/Obfuscator"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L958-L971"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "523ce9e83bd6cd7152d86fe77a441a3f721d79f8df45c4041e47cae4b15673d5"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "8fe5b811-a2cb-417f-af93-6a3cf6650af1" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Safetykatz : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "5f6d7432-0bb5-5782-98ec-2c2168f2fc1f"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/GhostPack/SafetyKatz"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L973-L986"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "08b1e8ee951140dc6ac07f2646e0bf84bb22bea9948d231e1ba8d4cf0a28a2e8"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "8347e81b-89fc-42a9-b22c-f59a6a572dec" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Dropless_Malware : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "0da3b6d8-2002-590e-a8d5-f6c84acfb083"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/NYAN-x-CAT/Dropless-Malware"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L988-L1001"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "833b7758aea58d3065c2c3153f0ab21b7b6a54f7e7083655f2a52c2861080f7d"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "23b739f7-2355-491e-a7cd-a8485d39d6d6" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_UAC_Silentclean : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "2dde9632-10c5-5c91-8bd9-2fb80d6f0c49"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/EncodeGroup/UAC-SilentClean"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1003-L1016"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "32d331148578923e7f5017ce874f9daa234a759ea5a87cbddc1e111834acf920"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "948152a4-a4a1-4260-a224-204255bfee72" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Desktopgrabber : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "7db07291-d6d4-5527-a879-27f899dbd6fe"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/NYAN-x-CAT/DesktopGrabber"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1018-L1031"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1937fa6b9e5af3c12a2eef6356aed2c93e6534db492ebc7a8955c4cac240a840"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "e6aa0cd5-9537-47a0-8c85-1fbe284a4380" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Wsmanager : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "b8c330dc-74aa-5a33-8af6-17c9beb8be81"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/guillaC/wsManager"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1033-L1046"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "cbcdcf8c4895263b881f45f54df01b6a6a3d76cf1be195475217ccffa9eedfed"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "9480809e-5472-44f3-b076-dcdf7379e766" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Uglyexe : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "5833e6c5-f078-5eb5-9519-76710d7da0e1"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/fashionproof/UglyEXe"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1048-L1061"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "caf7c8ae7060822e0014710e521020e5d502eedb505165374b7600b11dea7bad"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "233de44b-4ec1-475d-a7d6-16da48d6fc8d" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpdump : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "b613092f-9006-5405-b07e-59737410ac1e"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/GhostPack/SharpDump"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1063-L1076"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "95217122df1b56132e7774c10c0e993d914cdf8e2463f949cfbab59cb0d99ca4"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "79c9bba3-a0ea-431c-866c-77004802d8a0" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Educationalrat : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "b1d54bea-a6c4-5c57-9ee1-7438d503b01d"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/securesean/EducationalRAT"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1078-L1091"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c46fee5ff948537fb1defe636f3987b3de52b2e37a1130b4b425c6645d74b11b"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "8a18fbcf-8cac-482d-8ab7-08a44f0e278e" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Stealth_Kid_RAT : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "f26e040a-dcc7-518f-89f2-3333f83fa14a"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/ctsecurity/Stealth-Kid-RAT"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1093-L1107"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9a885a48053d501273fc8043e990166558458239781feb9e09f972c52d57e8da"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "bf43cd33-c259-4711-8a0e-1a5c6c13811d" ascii wide
		$typelibguid1lo = "e5b9df9b-a9e4-4754-8731-efc4e2667d88" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpcradle : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "e2123a73-2609-559d-a122-923ebf8fd668"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/anthemtotheego/SharpCradle"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1109-L1122"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4213877aaf5606c9e5f3f38a1f057f8068e0fa062a5f1eb4389d83c6032df6c3"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "f70d2b71-4aae-4b24-9dae-55bc819c78bb" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Bypassuac : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "327f581e-1d8c-5d20-bdd7-a29810c619c9"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/cnsimo/BypassUAC"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1124-L1138"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "05dbd4d443664735a10bd48dbbda4edf7ba3756c9dd3f53cb25e066e8f5f1b61"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "4e7c140d-bcc4-4b15-8c11-adb4e54cc39a" ascii wide
		$typelibguid1lo = "cec553a7-1370-4bbc-9aae-b2f5dbde32b0" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Hanzoinjection : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "c432bf68-49bf-57c7-bbfa-7bd2f3506c52"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/P0cL4bs/hanzoInjection"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1140-L1153"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "692e5288fffb8eb65b6f84017c31bb3d5d7320c141cd5a60eef6d9482385bb88"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "32e22e25-b033-4d98-a0b3-3d2c3850f06c" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Clr_Meterpreter : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "1d8a9717-4d80-5fb1-9c57-9b5f6c5a18b0"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/OJ/clr-meterpreter"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1155-L1173"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "5d48897457c5f3ea7a9c24a24ab63207c3841bc3ac444d1c42987cb291f05941"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "6840b249-1a0e-433b-be79-a927696ea4b3" ascii wide
		$typelibguid1lo = "67c09d37-ac18-4f15-8dd6-b5da721c0df6" ascii wide
		$typelibguid2lo = "e05d0deb-d724-4448-8c4c-53d6a8e670f3" ascii wide
		$typelibguid3lo = "c3cc72bf-62a2-4034-af66-e66da73e425d" ascii wide
		$typelibguid4lo = "7ace3762-d8e1-4969-a5a0-dcaf7b18164e" ascii wide
		$typelibguid5lo = "3296e4a3-94b5-4232-b423-44f4c7421cb3" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_BYTAGE : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "4f87ca2c-3ac1-5733-893e-79665b80ffc3"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/KNIF/BYTAGE"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1175-L1188"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "2d295501a64515a68bbd9a3c7f0f5ca0bbf59df5f6c91dd66d2ce6e744ce3fc1"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "8e46ba56-e877-4dec-be1e-394cb1b5b9de" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Multios_Reverseshell : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "f54bcb1a-b0cd-5988-bf1d-4fa6c012d6b9"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/belane/MultiOS_ReverseShell"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1190-L1203"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a0b7f881aee1097dcbbd39a832073aada103b23ebc5b167052e9483083fec02d"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "df0dd7a1-9f6b-4b0f-801e-e17e73b0801d" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Hidefromamsi : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "0fa1ce82-b662-5e18-a5da-8359c96cd6e9"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/0r13lc0ch4v1/HideFromAMSI"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1205-L1218"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "05fccd4c7346c1ac1830984f945f5d37ca3e44a479287d681dfdb06d200764f1"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "b91d2d44-794c-49b8-8a75-2fbec3fe3fe3" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Dotnetavbypass_Master : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "4004271b-4fbe-58bb-9613-a077e76324b3"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/lockfale/DotNetAVBypass-Master"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1220-L1233"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3382613db4970475922fb7db70b6ce4f9c247f083a2164b86ba9e81a770e0e36"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "4854c8dc-82b0-4162-86e0-a5bbcbc10240" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpdpapi : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "1394323f-b336-548f-925c-c276d439e9eb"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/GhostPack/SharpDPAPI"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1235-L1249"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "70f40bc48eeba3f835a280e7e2ce06b2a16179be9914d5c2548c820b02f4c837"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "5f026c27-f8e6-4052-b231-8451c6a73838" ascii wide
		$typelibguid1lo = "2f00a05b-263d-4fcc-846b-da82bd684603" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Telegra_Csharp_C2 : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "495a5f3e-cf05-5a66-b01c-8176ded88768"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/sf197/Telegra_Csharp_C2"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1251-L1264"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ebdec8d1781ffc106f93f3686eb96e6b79810fbb0c7b1eb7cbbb161397298adc"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "1d79fabc-2ba2-4604-a4b6-045027340c85" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpcompile : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "c5e053c4-1c90-581a-a6c3-087b252254b2"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/SpiderLabs/SharpCompile"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1266-L1279"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a8b46bf3017f336dc669b6c81a339953cc8931df49283b67172f45d1715ef422"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "63f81b73-ff18-4a36-b095-fdcb4776da4c" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Carbuncle : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "4a87882e-570b-5b40-a8e3-47ebac01d257"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/checkymander/Carbuncle"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1281-L1294"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f792c3ed1f62915635dc9090cc608475701d1a4ec60810946336a5d72280af48"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "3f239b73-88ae-413b-b8c8-c01a35a0d92e" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Ossfiletool : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "fa9aeae1-2aa5-51af-81e2-22a1b6fcda81"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/B1eed/OSSFileTool"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1296-L1309"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "0dda05d0a53babdf83a2edf9ac0ed21954c059baa73963c79fb840c737865df1"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "207aca5d-dcd6-41fb-8465-58b39efcde8b" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Rubeus : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "54638fe4-84b5-51a8-8c88-9c50ab09ff49"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/GhostPack/Rubeus"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1311-L1324"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3d2df79b86b2c1eb4721ee9b6fce920db3e48f9cf96fa693876a6d7d8dad54e6"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "658c8b7f-3664-4a95-9572-a3e5871dfc06" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Simple_Loader : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "4c26aaf9-187d-5990-b956-1bbf630411f0"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/cribdragg3r/Simple-Loader"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1326-L1339"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "0dff8268f2c0c0764736727c78c648567b42cd3e177a7b73aa47a5afdf2f6d4a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "035ae711-c0e9-41da-a9a2-6523865e8694" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Minidump : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "51f64c64-f3fa-5543-83fc-5f0bf881ef03"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/3xpl01tc0d3r/Minidump"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1341-L1354"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "798c1c569b224442c2f7b98254062e8cd3b008cb6d7aefef3063d9d57dbfbaee"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "15c241aa-e73c-4b38-9489-9a344ac268a3" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpbypassuac : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "474d40aa-4bcc-58b5-a129-40bbd3a89e99"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/FatRodzianko/SharpBypassUAC"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1356-L1369"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "fa9aae20fc35bba3b88e32f03e832579ee48d03303e789a13949a859a6da1a3d"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "0d588c86-c680-4b0d-9aed-418f1bb94255" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharppack : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "633d074a-b8c2-5148-ad80-6226b99be818"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/Lexus89/SharpPack"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1371-L1391"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "43701a68c6bbb5fc1217f9b47096dcc87d2b1ffa9399ba50df9f7e99cec2c0d8"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid1lo = "b59c7741-d522-4a41-bf4d-9badddebb84a" ascii wide
		$typelibguid2lo = "fd6bdf7a-fef4-4b28-9027-5bf750f08048" ascii wide
		$typelibguid3lo = "6dd22880-dac5-4b4d-9c91-8c35cc7b8180" ascii wide
		$typelibguid5lo = "f3037587-1a3b-41f1-aa71-b026efdb2a82" ascii wide
		$typelibguid6lo = "41a90a6a-f9ed-4a2f-8448-d544ec1fd753" ascii wide
		$typelibguid7lo = "3787435b-8352-4bd8-a1c6-e5a1b73921f4" ascii wide
		$typelibguid8lo = "fdd654f5-5c54-4d93-bf8e-faf11b00e3e9" ascii wide
		$typelibguid9lo = "aec32155-d589-4150-8fe7-2900df4554c8" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Salsa_Tools : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "50db578e-6ddb-54d1-a978-e3630a3548c3"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/Hackplayers/Salsa-tools"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1393-L1407"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "086108496c5ff6df15a26453da7f0922c29132fd4136cca9a02c21afc9c55ad5"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "276004bb-5200-4381-843c-934e4c385b66" ascii wide
		$typelibguid1lo = "cfcbf7b6-1c69-4b1f-8651-6bdb4b55f6b9" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Windowsdefender_Payload_Downloader : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "6e494a91-c05e-5a2e-8aa9-77600f3bdd47"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/notkohlrexo/WindowsDefender-Payload-Downloader"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1409-L1422"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "587784216f3cf47e291219e08dc2b38bd43b11519d612eaccc631539ecc27c60"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "2f8b4d26-7620-4e11-b296-bc46eba3adfc" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Privilege_Escalation : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "28615807-6637-57fc-ba56-efc64b041b80"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/Mrakovic-ORG/Privilege_Escalation"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1424-L1437"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "18f5d4f917e1e3f0902ab50d6ae2c249782c65d0fc1ed4bc4d06ffae4d286598"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "ed54b904-5645-4830-8e68-52fd9ecbb2eb" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Marauder : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "f2783477-2853-5dcd-95f5-9f1e07a4a6e8"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/maraudershell/Marauder"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1439-L1452"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b1a14c6dd80beedd1f385f3b85cec44a443020a76d4da03ea3a53e1c7c0a7b82"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "fff0a9a3-dfd4-402b-a251-6046d765ad78" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_AV_Evasion_Tool : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "d4257465-38a0-56b9-8402-b92e21b96cb0"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/1y0n/AV_Evasion_Tool"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1454-L1468"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9962ed855d43e12ecfcb38337e20db714315d0ec9d83f74d115765a973939b5c"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "1937ee16-57d7-4a5f-88f4-024244f19dc6" ascii wide
		$typelibguid1lo = "7898617d-08d2-4297-adfe-5edd5c1b828b" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Fenrir : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "cfc6312d-5997-5261-b771-c7f3f30bf86c"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/nccgroup/Fenrir"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1470-L1483"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9b62914aea33db4027c62ecf57854d20942197d1b9212245d1932c0a6b80fe5f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "aecec195-f143-4d02-b946-df0e1433bd2e" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Stormkitty : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "09d66661-5b67-5846-9bea-ec682afb62cf"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/LimerBoy/StormKitty"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1485-L1499"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e346a56a555fe8fae6d5f3704a39b97e82de79160da93cba7646eb7d6a98d5a8"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "a16abbb4-985b-4db2-a80c-21268b26c73d" ascii wide
		$typelibguid1lo = "98075331-1f86-48c8-ae29-29da39a8f98b" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Crypter_Runtime_AV_S_Bypass : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "726cd57b-d88a-5854-b2e1-76d9bd71a155"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/netreverse/Crypter-Runtime-AV-s-bypass"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1501-L1514"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4427fdd90b88576b05bc47c0a24a6daa92e066868e3c738007bfcf9c29058b2e"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "c25e39a9-8215-43aa-96a3-da0e9512ec18" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Runasuser : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "ead7819a-1397-5953-888f-2176e4041375"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/atthacks/RunAsUser"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1516-L1529"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8ac64be85ae1a55c3390dace5e43580453568758a712bdca0a5e81817d0a7fb0"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "9dff282c-93b9-4063-bf8a-b6798371d35a" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Hwidbypass : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "62b0541b-6eec-546e-8445-85d25bb0d784"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/yunseok/HWIDbypass"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1531-L1544"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1b19d3560fdf5bfbfd3c4fb434474cdde5efa42de611fb97e76312664b8cedb7"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "47e08791-d124-4746-bc50-24bd1ee719a6" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Xoredreflectivedll : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "9b584bfb-98ef-50ee-b546-780c4b210a1b"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/r3nhat/XORedReflectiveDLL"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1546-L1560"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "92df3b5c8d1b531dd4b4d04ba53aa6ae5ebf9d1f6869a0d46cd972b082fa1b9f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "c0e49392-04e3-4abb-b931-5202e0eb4c73" ascii wide
		$typelibguid1lo = "30eef7d6-cee8-490b-829f-082041bc3141" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharp_Suite : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "ab3cf358-a41d-584d-baaf-5e8f7232ca85"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/FuzzySecurity/Sharp-Suite"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1562-L1596"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "cffb4eae9fe3f2034fb03defcd0e0f3f1abaaa2638b137bdfdf67d071e055d42"
		score = 75
		quality = 83
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "19657be4-51ca-4a85-8ab1-f6666008b1f3" ascii wide
		$typelibguid1lo = "0a382d9a-897f-431a-81c2-a4e08392c587" ascii wide
		$typelibguid2lo = "467ee2a9-2f01-4a71-9647-2a2d9c31e608" ascii wide
		$typelibguid3lo = "eacaa2b8-43e5-4888-826d-2f6902e16546" ascii wide
		$typelibguid4lo = "629f86e6-44fe-4c9c-b043-1c9b64be6d5a" ascii wide
		$typelibguid5lo = "ecf2ffe4-1744-4745-8693-5790d66bb1b8" ascii wide
		$typelibguid6lo = "0a621f4c-8082-4c30-b131-ba2c98db0533" ascii wide
		$typelibguid7lo = "72019dfe-608e-4ab2-a8f1-66c95c425620" ascii wide
		$typelibguid8lo = "f0d28809-b712-4380-9a59-407b7b2badd5" ascii wide
		$typelibguid9lo = "956a5a4d-2007-4857-9259-51cd0fb5312a" ascii wide
		$typelibguid10lo = "a3b7c697-4bb6-455d-9fda-4ab54ae4c8d2" ascii wide
		$typelibguid11lo = "a5f883ce-1f96-4456-bb35-40229191420c" ascii wide
		$typelibguid12lo = "28978103-d90d-4618-b22e-222727f40313" ascii wide
		$typelibguid13lo = "0c70c839-9565-4881-8ea1-408c1ebe38ce" ascii wide
		$typelibguid14lo = "fa1d9a36-415a-4855-8c01-54b6e9fc6965" ascii wide
		$typelibguid15lo = "252676f8-8a19-4664-bfb8-5a947e48c32a" ascii wide
		$typelibguid16lo = "447edefc-b429-42bc-b3bc-63a9af19dbd6" ascii wide
		$typelibguid17lo = "04d0b3a6-eaab-413d-b9e2-512fa8ebd02f" ascii wide
		$typelibguid18lo = "5611236e-2557-45b8-be29-5d1f074d199e" ascii wide
		$typelibguid19lo = "53f622eb-0ca3-4e9b-9dc8-30c832df1c7b" ascii wide
		$typelibguid20lo = "414187db-5feb-43e5-a383-caa48b5395f1" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Rat_Shell : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "8f206175-f7e4-5543-8059-24f102fcd4b9"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/stphivos/rat-shell"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1598-L1612"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3d88c891393c914b4b1520bbdb575e78740f21bd361fe4187fdd08aeed708540"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "7a15f8f6-6ce2-4ca4-919d-2056b70cc76a" ascii wide
		$typelibguid1lo = "1659d65d-93a8-4bae-97d5-66d738fc6f6c" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Dotnet_Gargoyle : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "5efd0c83-cb65-5bda-b55e-4a89db5f337c"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/countercept/dotnet-gargoyle"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1614-L1629"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c7ad2c6c775ed6355dd93b06e31e04916277564301b45fe13b69d3e25dcd7bad"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "76435f79-f8af-4d74-8df5-d598a551b895" ascii wide
		$typelibguid1lo = "5a3fc840-5432-4925-b5bc-abc536429cb5" ascii wide
		$typelibguid2lo = "6f0bbb2a-e200-4d76-b8fa-f93c801ac220" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Aresskit : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "8265cd84-c8e7-5654-9d3a-774dab52d938"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/BlackVikingPro/aresskit"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1631-L1644"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3f7c2cb5dee0d77f70ea1fe231e498d1a16c11f92a8b930c9a603fa64a54cec0"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "8dca0e42-f767-411d-9704-ae0ba4a44ae8" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_DLL_Injector : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "301e70f4-89ed-539c-b7f3-9fc6ae1393b3"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/tmthrgd/DLL-Injector"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1646-L1660"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "fe92cb643d8ddbc0d8d09a88e90655965001375d05c799d6c2437e6c94b26c7a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "4581a449-7d20-4c59-8da2-7fd830f1fd5e" ascii wide
		$typelibguid1lo = "05f4b238-25ce-40dc-a890-d5bbb8642ee4" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Trufflesnout : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "8135d39e-6a9e-567d-840f-8d8c6338cce1"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/dsnezhkov/TruffleSnout"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1662-L1675"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "03b340ccf4b314ec5d3c33e83e5a47b55e935a8e55acbd6bd9daba43443d53a1"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "33842d77-bce3-4ee8-9ee2-9769898bb429" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Anti_Analysis : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "bd527841-065e-57e9-b70e-c9d232072f1b"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/NYAN-x-CAT/Anti-Analysis"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1677-L1690"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1a4141b376afbf36a7a9aa340ea5514b85dd6b0fab003554bae06c0240c98a79"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "3092c8df-e9e4-4b75-b78e-f81a0058a635" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Backnet : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "91824d18-f46b-5b95-b650-4d710d711cf9"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/valsov/BackNet"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1692-L1708"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "82ab970de2e27e711c502903cc2ede47da296df3ea346c870698c920a4ece282"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "9fdae122-cd1e-467d-a6fa-a98c26e76348" ascii wide
		$typelibguid1lo = "243c279e-33a6-46a1-beab-2864cc7a499f" ascii wide
		$typelibguid2lo = "a7301384-7354-47fd-a4c5-65b74e0bbb46" ascii wide
		$typelibguid3lo = "982dc5b6-1123-428a-83dd-d212490c859f" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Allthethings : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "c35160cb-ad31-5195-a7c6-0af91a58737d"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/johnjohnsp1/AllTheThings"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1710-L1723"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a4a562e4db2477be34fa4ccf2c83afafc7aafead3a9eae434b4bc0a5ea6430f7"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "0547ff40-5255-42a2-beb7-2ff0dbf7d3ba" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Addreferencedotredteam : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "59299a72-9b7a-5108-81c2-d8f6d2e99b20"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/ceramicskate0/AddReferenceDotRedTeam"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1725-L1738"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ec7e0c39db13d212ff9aac4ec8d7d9b4274f3a404997f9291dcbfeaf311f31b4"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "73c79d7e-17d4-46c9-be5a-ecef65b924e4" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Lime_Crypter : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "484c7a15-7ab2-57d3-848c-0fddff753d52"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/NYAN-x-CAT/Lime-Crypter"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1740-L1753"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ab4243f5e4efcadc9d1a9a34bdb4d5aedcf500accf4cb3681a73015c7f3f6900"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "f93c99ed-28c9-48c5-bb90-dd98f18285a6" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}

rule SIGNATURE_BASE_HKTL_NET_GUID_Browserghost : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "adcc5d12-c393-5708-ae0b-a85f2187c881"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/QAX-A-Team/BrowserGhost"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1755-L1770"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "448177aae4b0b2f17faefb22599649b7264c85e3af96b1d78bab6ada891b7a82"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "2133c634-4139-466e-8983-9a23ec99e01b" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them and not pe.is_dll ( )
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpshot : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "9d59cd53-53b1-57db-b391-eee4dd6feec0"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/tothi/SharpShot"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1772-L1785"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "65bbe20eb2aac648648b828c176e418648ebdc6372d287e4bc3b0d3edf233e86"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "057aef75-861b-4e4b-a372-cfbd8322c8e1" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Offensive__NET : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "b98495fb-0338-5042-a7ce-d117204eb91e"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/mrjamiebowman/Offensive-.NET"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1787-L1800"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "dddbee2e6d1cd4046f91192fe26841cc6c359dd9188d472c8b2acca691c15a34"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "11fe5fae-b7c1-484a-b162-d5578a802c9c" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Ruralbishop : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "8fd89465-1ecc-5eda-b2ab-273172ad945d"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/rasta-mouse/RuralBishop"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1802-L1815"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8dfa8652507851305da814b1410a7854be2c1c78cac325881118829be3456776"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "fe4414d9-1d7e-4eeb-b781-d278fe7a5619" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Deviceguardbypasses : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "3790faac-b5be-5999-b35f-71a2ef02b6ed"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/tyranid/DeviceGuardBypasses"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1817-L1835"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "aff1a0236c532d5822a440f1d9a0a0265b422ebe0b53d799d53e838aef5f64ad"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "f318466d-d310-49ad-a967-67efbba29898" ascii wide
		$typelibguid1lo = "3705800f-1424-465b-937d-586e3a622a4f" ascii wide
		$typelibguid2lo = "256607c2-4126-4272-a2fa-a1ffc0a734f0" ascii wide
		$typelibguid3lo = "4e6ceea1-f266-401c-b832-f91432d46f42" ascii wide
		$typelibguid4lo = "1e6e9b03-dd5f-4047-b386-af7a7904f884" ascii wide
		$typelibguid5lo = "d85e3601-0421-4efa-a479-f3370c0498fd" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_AMSI_Handler : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "40768acf-fa9e-531a-83fd-187814ddc2d4"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/two06/AMSI_Handler"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1837-L1853"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3b27157331b3b9f6897134172f7dd9198fad7747c12d1020cb3e2d924c2910ce"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "d829426c-986c-40a4-8ee2-58d14e090ef2" ascii wide
		$typelibguid1lo = "86652418-5605-43fd-98b5-859828b072be" ascii wide
		$typelibguid2lo = "1043649f-18e1-41c4-ae8d-ac4d9a86c2fc" ascii wide
		$typelibguid3lo = "1d920b03-c537-4659-9a8c-09fb1d615e98" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_RAT_Telegramspybot : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "57d22201-a051-5040-927c-30da3fc684fd"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/SebastianEPH/RAT.TelegramSpyBot"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1855-L1868"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9fc671ef600548d962a2d5ab12ba3111ed19e83ef96d2d536eb343bb8fb4b0d2"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "8653fa88-9655-440e-b534-26c3c760a0d3" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Thehacktoolboxteek : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "ad8cf2c8-f70e-5f46-92fa-46e1fa5e683c"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/teeknofil/TheHackToolBoxTeek"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1870-L1889"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f18d6be2789371f3db649d0df3fc31a2e97604b399873c9843c1e08c981be0da"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "2aa8c254-b3b3-469c-b0c9-dcbe1dd101c0" ascii wide
		$typelibguid1lo = "afeff505-14c1-4ecf-b714-abac4fbd48e7" ascii wide
		$typelibguid2lo = "4cf42167-a5cf-4b2d-85b4-8e764c08d6b3" ascii wide
		$typelibguid3lo = "118a90b7-598a-4cfc-859e-8013c8b9339c" ascii wide
		$typelibguid4lo = "3075dd9a-4283-4d38-a25e-9f9845e5adcb" ascii wide
		$typelibguid5lo = "295655e8-2348-4700-9ebc-aa57df54887e" ascii wide
		$typelibguid6lo = "74efe601-9a93-46c3-932e-b80ab6570e42" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Usbtrojan : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "d25c9033-13e8-5fc9-8561-f8862cca39b8"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/mashed-potatoes/USBTrojan"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1891-L1904"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "2280803c42311b8b78a51f0917d9fb4cdd8ca427ce2361372914e5922a1a0b68"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "4eee900e-adc5-46a7-8d7d-873fd6aea83e" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_IIS_Backdoor : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "44264dd9-f8e9-5a60-847f-94378e07a327"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/WBGlIl/IIS_backdoor"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1906-L1920"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "61fcba7e59ac005db140d8eee1d8a1fd4ce8cd18c069053270e0195ee9d63ccc"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "3fda4aa9-6fc1-473f-9048-7edc058c4f65" ascii wide
		$typelibguid1lo = "73ca4159-5d13-4a27-8965-d50c41ab203c" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Shellgen : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "538a4f12-5020-5c76-9208-363f435ed9a9"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/jasondrawdy/ShellGen"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1922-L1935"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "80c7291653e6cb5d7ef4d69390f7508cd95149d92b59aa3b5c8e6e0fe3723bfe"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "c6894882-d29d-4ae1-aeb7-7d0a9b915013" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Mass_RAT : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "90b742da-6fd7-5c72-96cf-7a37a3e5d808"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/NYAN-x-CAT/Mass-RAT"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1937-L1952"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "53ef9b1d44e6497bafe0982f2e6be65240fcf5684a7b5a6c32a704ab3b7e085c"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "6c43a753-9565-48b2-a372-4210bb1e0d75" ascii wide
		$typelibguid1lo = "92ba2a7e-c198-4d43-929e-1cfe54b64d95" ascii wide
		$typelibguid2lo = "4cb9bbee-fb92-44fa-a427-b7245befc2f3" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Browser_Externalc2 : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "8c309522-90e7-5f5a-b456-3a472756d397"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/mdsecactivebreach/Browser-ExternalC2"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1954-L1967"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1a0027775fb2a06d01cfe30c85ce03e11cf43976abe9bf7b2c61895a55d26404"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "10a730cd-9517-42d5-b3e3-a2383515cca9" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Offensivepowershelltasking : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "d221e24d-a2ef-51e2-95bf-4b91b438d9cf"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/leechristensen/OffensivePowerShellTasking"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1969-L1983"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "21d7192eaefeeed030b1ef1be29b54c12826914dc6f0945789f3690a39bee217"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "d432c332-3b48-4d06-bedb-462e264e6688" ascii wide
		$typelibguid1lo = "5796276f-1c7a-4d7b-a089-550a8c19d0e8" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Dohc2 : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "0bb38f10-ca5c-5c18-97c9-540b6367d150"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/SpiderLabs/DoHC2"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L1985-L1998"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1601c438c4359d3daa1b5b3cc36a82e049a5ed379ec7a52cdd4a9bca83518dd3"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "9877a948-2142-4094-98de-e0fbb1bc4062" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Syscallpoc : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "1ed5e226-0dcd-5397-b5e8-41f8a14981a1"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/SolomonSklash/SyscallPOC"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2000-L2014"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a12628052d5c1043b3aae0bedb62908a35cb27871e329f84b0fc22e29149f89e"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "1e54637b-c887-42a9-af6a-b4bd4e28cda9" ascii wide
		$typelibguid1lo = "198d5599-d9fc-4a74-87f4-5077318232ad" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_The_Collection : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "4ae78576-ab75-5679-9a29-4d9a1ff03f15"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/Tlgyt/The-Collection"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2042-L2059"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d8e28d972aaf44caff35bf982788a6e9b69d0acce4b11c8cfa00c65466412305"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "579159ff-3a3d-46a7-b069-91204feb21cd" ascii wide
		$typelibguid1lo = "5b7dd9be-c8c3-4c4f-a353-fefb89baa7b3" ascii wide
		$typelibguid2lo = "43edcb1f-3098-4a23-a7f2-895d927bc661" ascii wide
		$typelibguid3lo = "5f19919d-cd51-4e77-973f-875678360a6f" ascii wide
		$typelibguid4lo = "17fbc926-e17e-4034-ba1b-fb2eb57f5dd3" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Change_Lockscreen : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "a817c6e8-95f9-56c6-97b8-4be06658629f"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/nccgroup/Change-Lockscreen"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2061-L2074"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6b3cd265c6ccdae529a52c3609610f0e633f0112180afd63a5d9892e78d12ef1"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "78642ab3-eaa6-4e9c-a934-e7b0638bc1cc" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_LOLBITS : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "66454ac0-742b-51a3-ac45-1ac9606e8b89"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/Kudaes/LOLBITS"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2076-L2089"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "fa5978a49940cef63308ae228607eff22d19ea05373b2c4a3a293074af422b20"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "29d09aa4-ea0c-47c2-973c-1d768087d527" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Keylogger : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "0576756e-26d5-5165-b621-917126a75a38"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/BlackVikingPro/Keylogger"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2091-L2104"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "490fb06375b32c70041754e8855cc1d26b76531d24a58bb0b719a998fdb809d6"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "7afbc9bf-32d9-460f-8a30-35e30aa15879" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_CVE_2020_1337 : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "4b79867d-761c-5aa8-bf8a-60caa50d8aa6"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/neofito/CVE-2020-1337"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2106-L2119"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "05d557a3592845030880c3b87d8134565c2858db89218e1c38edbb025b945d72"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "d9c2e3c1-e9cc-42b0-a67c-b6e1a4f962cc" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharplogger : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "5cce395b-4f6f-5015-b45e-7eb79853296a"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/djhohnstein/SharpLogger"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2121-L2134"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9f63dc6bf41b6a062e80b6726c86bbeb7db68e319a78d1bd0187eef234a1c090"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "36e00152-e073-4da8-aa0c-375b6dd680c4" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Asyncrat_C_Sharp : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "858a079d-71e8-516e-a2a9-f0969edc758b"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/NYAN-x-CAT/AsyncRAT-C-Sharp"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2136-L2159"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ac6319ecfbfc2ddb096b8674a9b494d9460181ebaa2b32ee337d46f6dd33f21d"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "619b7612-dfea-442a-a927-d997f99c497b" ascii wide
		$typelibguid1lo = "424b81be-2fac-419f-b4bc-00ccbe38491f" ascii wide
		$typelibguid2lo = "37e20baf-3577-4cd9-bb39-18675854e255" ascii wide
		$typelibguid3lo = "dafe686a-461b-402b-bbd7-2a2f4c87c773" ascii wide
		$typelibguid4lo = "ee03faa9-c9e8-4766-bd4e-5cd54c7f13d3" ascii wide
		$typelibguid5lo = "8bfc8ed2-71cc-49dc-9020-2c8199bc27b6" ascii wide
		$typelibguid6lo = "d640c36b-2c66-449b-a145-eb98322a67c8" ascii wide
		$typelibguid7lo = "8de42da3-be99-4e7e-a3d2-3f65e7c1abce" ascii wide
		$typelibguid8lo = "bee88186-769a-452c-9dd9-d0e0815d92bf" ascii wide
		$typelibguid9lo = "9042b543-13d1-42b3-a5b6-5cc9ad55e150" ascii wide
		$typelibguid10lo = "6aa4e392-aaaf-4408-b550-85863dd4baaf" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Darkfender : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "0aea5e05-7788-5581-8bcc-d2e75a291dd9"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/0xyg3n/DarkFender"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2161-L2174"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "2afa4ff5719cb5b3a53b45a880e08e2cac6df8bb1ff053ee290ad6b025f9a6b5"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "12fdf7ce-4a7c-41b6-9b32-766ddd299beb" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Minerdropper : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "607f72df-b0c1-53df-bf2c-592f55cbfcb7"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/DylanAlloy/MinerDropper"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2194-L2208"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1a604745a0d95c54be0d1b183486aad0751aee825574500fbff6380571565a18"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "46a7af83-1da7-40b2-9d86-6fd6223f6791" ascii wide
		$typelibguid1lo = "8433a693-f39d-451b-955b-31c3e7fa6825" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpdomainspray : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "cffd3350-4a86-5035-ab15-adbc3ac2a0e9"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/HunnicCyber/SharpDomainSpray"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2210-L2223"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "da8a964691758e8179199b5725b0811a5b37de964f6a5fa01d6adac286bc544a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "76ffa92b-429b-4865-970d-4e7678ac34ea" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Ispykeylogger : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "8607de67-b472-5afc-b2b9-cc758b5ec474"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/mwsrc/iSpyKeylogger"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2225-L2241"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "0c0b0a8d53efc5e922f73eec7550e6927f19aaef950921fde95b7bd651adeec7"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "ccc0a386-c4ce-42ef-aaea-b2af7eff4ad8" ascii wide
		$typelibguid1lo = "816b8b90-2975-46d3-aac9-3c45b26437fa" ascii wide
		$typelibguid2lo = "279b5533-d3ac-438f-ba89-3fe9de2da263" ascii wide
		$typelibguid3lo = "88d3dc02-2853-4bf0-b6dc-ad31f5135d26" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Solarflare : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "3645e14c-6025-59fa-a5a2-d8dacba8cd94"
		date = "2020-12-15"
		modified = "2025-08-15"
		reference = "https://github.com/mubix/solarflare"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2243-L2256"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9968c4f65672e98ec1ced26e2344e9b12141e3ea7e58be650d077089c9f6bd1c"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "ca60e49e-eee9-409b-8d1a-d19f1d27b7e4" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Snaffler : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "d4b9a8c5-e0d9-5c85-af81-05f6e0f52bff"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/SnaffCon/Snaffler"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2258-L2272"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a99f8012e45bbc7b689c49d2f6b5e86918b3984ce211fc4b459b6297d75c233a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "2aa060b4-de88-4d2a-a26a-760c1cefec3e" ascii wide
		$typelibguid1lo = "b118802d-2e46-4e41-aac7-9ee890268f8b" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpshares : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "e96aa79b-1da2-5b0c-9ac2-b6e201e06ec6"
		date = "2020-12-13"
		modified = "2025-08-15"
		reference = "https://github.com/djhohnstein/SharpShares/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2274-L2287"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "09151f0ee360aaa74ebd0fe809ee45135705475a8559f78762ea80e261d173f3"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "fe9fdde5-3f38-4f14-8c64-c3328c215cf2" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpedrchecker : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "f7ff344e-f8ee-5c3a-bdd1-de3cae8e7dfb"
		date = "2020-12-18"
		modified = "2025-08-15"
		reference = "https://github.com/PwnDexter/SharpEDRChecker"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2289-L2302"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9a5a192bb5aedf801465760fd362e0917c7a68c97058c82d0954ce44d3632c43"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "bdfee233-3fed-42e5-aa64-492eb2ac7047" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpcliphistory : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "89ca4717-a4ec-5371-8dc3-bdb9933384af"
		date = "2020-12-21"
		modified = "2025-08-15"
		reference = "https://github.com/FSecureLABS/SharpClipHistory"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2304-L2317"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "18558f9c446847d2021c3f2a99315c490fc26b1c585dd8a7a0ba4470be8d1e45"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "1126d5b4-efc7-4b33-a594-b963f107fe82" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpgpo_Remoteaccesspolicies : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "642c2672-2327-5a4a-af91-6e0559996908"
		date = "2020-12-21"
		modified = "2025-08-15"
		reference = "https://github.com/FSecureLABS/SharpGPO-RemoteAccessPolicies"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2319-L2332"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e2e3168f733ce8a3e6129e4f2faa6a90a47f6cfc683c840032c0323170720a1b"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "fbb1abcf-2b06-47a0-9311-17ba3d0f2a50" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Absinthe : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "8f25593b-b9d2-5807-b299-b039ecfd43a5"
		date = "2020-12-21"
		modified = "2025-08-15"
		reference = "https://github.com/cameronhotchkies/Absinthe"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2334-L2347"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "54040db5bdcfc711a26401d082693471c3f98fc043a550d1253f72a2d2611ae4"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "9936ae73-fb4e-4c5e-a5fb-f8aaeb3b9bd6" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Exploitremotingservice : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "2f0b9635-2b2e-5825-baeb-69d7ae3791b1"
		date = "2020-12-21"
		modified = "2025-08-15"
		reference = "https://github.com/tyranid/ExploitRemotingService"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2349-L2364"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b22513722be15f582d06c23fb6db53722c0edf2f89f17e28ca067f431ffd4616"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "fd17ae38-2fd3-405f-b85b-e9d14e8e8261" ascii wide
		$typelibguid1lo = "1850b9bb-4a23-4d74-96b8-58f274674566" ascii wide
		$typelibguid2lo = "297cbca1-efa3-4f2a-8d5f-e1faf02ba587" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Xploit : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "11ba6c14-06b6-5d9f-ac69-08ae506877e7"
		date = "2020-12-21"
		modified = "2025-08-15"
		reference = "https://github.com/shargon/Xploit"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2366-L2389"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "0b622acce9ff8186266c69d4ca097902027f5ca652408bfa4ec36fa145e14737"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "4545cfde-9ee5-4f1b-b966-d128af0b9a6e" ascii wide
		$typelibguid1lo = "33849d2b-3be8-41e8-a1e2-614c94c4533c" ascii wide
		$typelibguid2lo = "c2dc73cc-a959-4965-8499-a9e1720e594b" ascii wide
		$typelibguid3lo = "77059fa1-4b7d-4406-bc1a-cb261086f915" ascii wide
		$typelibguid4lo = "a4a04c4d-5490-4309-9c90-351e5e5fd6d1" ascii wide
		$typelibguid5lo = "ca64f918-3296-4b7d-9ce6-b98389896765" ascii wide
		$typelibguid6lo = "10fe32a0-d791-47b2-8530-0b19d91434f7" ascii wide
		$typelibguid7lo = "679bba57-3063-4f17-b491-4f0a730d6b02" ascii wide
		$typelibguid8lo = "0981e164-5930-4ba0-983c-1cf679e5033f" ascii wide
		$typelibguid9lo = "2a844ca2-5d6c-45b5-963b-7dca1140e16f" ascii wide
		$typelibguid10lo = "7d75ca11-8745-4382-b3eb-c41416dbc48c" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Poc : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "5669bc1a-b32e-5ae7-bf94-8ed2a124c765"
		date = "2020-12-21"
		modified = "2025-08-15"
		reference = "https://github.com/thezdi/PoC"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2391-L2404"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f3001a60ce4b6415de2cb035ab56023cd2ee5f4c73e745d87409e5fef1fc9e8a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "89f9d411-e273-41bb-8711-209fd251ca88" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpgpoabuse : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "ea27044f-69be-5db7-8d77-28dafb18c7e5"
		date = "2020-12-21"
		modified = "2025-08-15"
		reference = "https://github.com/FSecureLABS/SharpGPOAbuse"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2406-L2419"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "683be1b4cee3ba705146f62cdc36c99ce5e4711cd38aec8103584321afd934f1"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "4f495784-b443-4838-9fa6-9149293af785" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Watson : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "6dc7bb08-0b34-50a0-8ae8-02d96d66a334"
		date = "2020-12-21"
		modified = "2025-08-15"
		reference = "https://github.com/rasta-mouse/Watson"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2421-L2434"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "0fa1d96e9c9fdd612f092dbdcde980956cf4bf24b384991d77737af43637bb34"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "49ad5f38-9e37-4967-9e84-fe19c7434ed7" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Standin : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "2af3c28a-ce5d-5dea-9abe-ff54b180049e"
		date = "2020-12-21"
		modified = "2025-08-15"
		reference = "https://github.com/FuzzySecurity/StandIn"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2436-L2449"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "db008e841cef47916e06167661b3825d1272357a347f522ccea25cc887438480"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "01c142ba-7af1-48d6-b185-81147a2f7db7" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Azure_Password_Harvesting : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "681cf9da-d664-5402-b7ac-eb2cfad85da9"
		date = "2020-12-21"
		modified = "2025-08-15"
		reference = "https://github.com/guardicore/azure_password_harvesting"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2451-L2464"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "eac946e4110f9e7fdcc69ca562ed37a5e77216a325ccd11e29ec7348c2dd12d4"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "7ad1ff2d-32ac-4c54-b615-9bb164160dac" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Powerops : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "3ef9f099-13c9-5b6f-8615-232240530078"
		date = "2020-12-21"
		modified = "2025-08-15"
		reference = "https://github.com/fdiskyou/PowerOPS"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2466-L2479"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7afb5a5c5eaaba574f31d2041ec2e23f969508bac76aeb58a98714b06b8e6ae7"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "2a3c5921-7442-42c3-8cb9-24f21d0b2414" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Random_Csharptools : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "ad8b5573-ad20-50cd-927b-a6401b10e653"
		date = "2020-12-21"
		modified = "2025-08-15"
		reference = "https://github.com/xorrior/Random-CSharpTools"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2481-L2500"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "633cfdc2f1950f36474e15cb186fc4673e7cbc9417fdbee61409b14be94bc6cb"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "f7fc19da-67a3-437d-b3b0-2a257f77a00b" ascii wide
		$typelibguid1lo = "47e85bb6-9138-4374-8092-0aeb301fe64b" ascii wide
		$typelibguid2lo = "c7d854d8-4e3a-43a6-872f-e0710e5943f7" ascii wide
		$typelibguid3lo = "d6685430-8d8d-4e2e-b202-de14efa25211" ascii wide
		$typelibguid4lo = "1df925fc-9a89-4170-b763-1c735430b7d0" ascii wide
		$typelibguid5lo = "817cc61b-8471-4c1e-b5d6-c754fc550a03" ascii wide
		$typelibguid6lo = "60116613-c74e-41b9-b80e-35e02f25891e" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_CVE_2020_0668 : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "54c87578-f0f1-5108-a736-b6acd9624d29"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/RedCursorSecurityConsulting/CVE-2020-0668"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2502-L2515"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ac81e20fa9e5a4f701172d3e68c016b33e5cbda6053505d46f761337fb374161"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "1b4c5ec1-2845-40fd-a173-62c450f12ea5" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Windowsrpcclients : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "70fd7431-8c32-52a4-be9f-2a19ef77f2cc"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/tyranid/WindowsRpcClients"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2517-L2536"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "2e99c98514bde102450b119cda3cc3c20d7680de5ccbbf64124b719fb8333e8d"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "843d8862-42eb-49ee-94e6-bca798dd33ea" ascii wide
		$typelibguid1lo = "632e4c3b-3013-46fc-bc6e-22828bf629e3" ascii wide
		$typelibguid2lo = "a2091d2f-6f7e-4118-a203-4cea4bea6bfa" ascii wide
		$typelibguid3lo = "950ef8ce-ec92-4e02-b122-0d41d83065b8" ascii wide
		$typelibguid4lo = "d51301bc-31aa-4475-8944-882ecf80e10d" ascii wide
		$typelibguid5lo = "823ff111-4de2-4637-af01-4bdc3ca4cf15" ascii wide
		$typelibguid6lo = "5d28f15e-3bb8-4088-abe0-b517b31d4595" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpfruit : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "bf318530-b17d-5275-84b2-c284528bdae6"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/rvrsh3ll/SharpFruit"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2538-L2551"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "da59a7c8fb038171a560d337a49f33a28a2ea88e4c7b08df12eaeb85906c0753"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "3da2f6de-75be-4c9d-8070-08da45e79761" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpwitness : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "5e707da6-b2dd-511e-89ad-d19b93e8fca6"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/rasta-mouse/SharpWitness"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2553-L2566"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9a9bc18362347f55b77ec275ad377da9e72ac8a65cab06a867ae55b61b69e7cd"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "b9f6ec34-4ccc-4247-bcef-c1daab9b4469" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Rexcrypter : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "5ebbeab3-3e93-5544-8f74-3d1b47335d8b"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/syrex1013/RexCrypter"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2568-L2581"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "fc8bd8eaa3561431bc8886de74b1d569d5fa1f2de7f866146669b4e918a3bf30"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "10cd7c1c-e56d-4b1b-80dc-e4c496c5fec5" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpersist : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "0c181186-7bb4-502b-8937-60cfd88ce689"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/fireeye/SharPersist"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2583-L2596"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "265f42a83973cacb82d4ff12db210ad6cb10265acc38724ed895dc772cf7855e"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "9d1b853e-58f1-4ba5-aefc-5c221ca30e48" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_CVE_2019_1253 : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "3e18b533-1b85-5eaf-bb3d-aa5b90fd2e28"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/padovah4ck/CVE-2019-1253"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2598-L2611"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f365dcec83696032370192d95312999d3baa950379472b99af17687a501dfa9c"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "584964c1-f983-498d-8370-23e27fdd0399" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Scout : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "cd24cca7-3bc0-5e7a-9817-dc3b26ec8358"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/jaredhaight/scout"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2613-L2626"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b677eb07dde231e1d6d542aaafcc0350ce51a66c5396949dd0f1d41311a822b5"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "d9c76e82-b848-47d4-8f22-99bf22a8ee11" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Grouper2 : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "a9cd9a16-b2a5-5d15-af89-7a8d0f1835bb"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/l0ss/Grouper2/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2628-L2641"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b89180f81c4231ea03bb49631b0931b2b7e4ff9e97f44798dd50f6fa4d12b75f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "5decaea3-2610-4065-99dc-65b9b4ba6ccd" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Casperstager : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "0ad18d2b-b7cc-5316-a8e8-b05d4439b8e1"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/ustayready/CasperStager"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2643-L2657"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "556dd774b6ba38371951ca416133573b0539d699671200e3accfe5bc6fbc979d"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "c653a9f2-0939-43c8-9b93-fed5e2e4c7e6" ascii wide
		$typelibguid1lo = "48dfc55e-6ae5-4a36-abef-14bc09d7510b" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Tellmeyoursecrets : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "b00c353b-0446-5faa-87e5-0a7ba6ec2286"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/0xbadjuju/TellMeYourSecrets"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2659-L2672"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b606c11986ff26d279db58c088633f39eddb41c96c2510f7738cfcef5ff4941f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "9b448062-7219-4d82-9a0a-e784c4b3aa27" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpexcel4_DCOM : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "12d3f26b-40ca-5034-a7c2-9be9c8a7599b"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/rvrsh3ll/SharpExcel4-DCOM"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2674-L2687"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "278eeabdfa26eec5f9e6d2fba093b4698a9813813f644b65e4e28791b600a5dc"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "68b83ce5-bbd9-4ee3-b1cc-5e9223fab52b" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpshooter : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "a59e6fe9-dbaf-5830-8cf1-485ff4dd939a"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/mdsecactivebreach/SharpShooter"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2689-L2702"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "79a63f9a24b94327b5b720c415143977c7fba088930dd94f6f2f2784770d182d"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "56598f1c-6d88-4994-a392-af337abe5777" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Nomsbuild : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "9bc0661d-c60f-582b-8f88-87e3dfa13ddd"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/rvrsh3ll/NoMSBuild"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2704-L2718"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "df8bfecf2f983975a4885cbabc79d2b42c1281bdd918aa0fc9fa50ef75bbfe5d"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "034a7b9f-18df-45da-b870-0e1cef500215" ascii wide
		$typelibguid1lo = "59b449d7-c1e8-4f47-80b8-7375178961db" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Teleshadow2 : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "5b22f2c4-0bd1-5a5a-8867-8fbc773d2b44"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/ParsingTeam/TeleShadow2"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2720-L2734"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "df4f26856b5ee348393ddb41e53bdfc8e2bed58ed9fc7b4f758cd1746431d85c"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "42c5c356-39cf-4c07-96df-ebb0ccf78ca4" ascii wide
		$typelibguid1lo = "0242b5b1-4d26-413e-8c8c-13b4ed30d510" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Badpotato : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "8bee12fc-fc29-5256-b559-d914ef202c0c"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/BeichenDream/BadPotato"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2736-L2749"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b78b623666279dab22c263a5a925fc665646ddcc24d1638ebe54bad2ccd5ed4c"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "0527a14f-1591-4d94-943e-d6d784a50549" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Lethalhta : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "e8e1ad03-a5f0-5508-b78d-0de7bdaf4704"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/codewhitesec/LethalHTA"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2751-L2765"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ebcf9df0cdbab82ee2eea25479058366651746990b32e5af7cbf4da7dae8fafe"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "784cde17-ff0f-4e43-911a-19119e89c43f" ascii wide
		$typelibguid1lo = "7e2de2c0-61dc-43ab-a0ec-c27ee2172ea6" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpstat : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "649c6cc0-e43b-558c-9567-00f352af528b"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/Raikia/SharpStat"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2767-L2780"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b163520c47d593244a66ee64071147824486bde4174a5276972a3329b0271a73"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "ffc5c721-49c8-448d-8ff4-2e3a7b7cc383" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sneakyservice : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "d02d34f0-7aa1-5110-b7ea-670b5fb98150"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/malcomvetter/SneakyService"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2782-L2795"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3f9e4a9666875e8b70ced55924f7dae661e9be6e033bafe4efc1614fb65a7f08"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "897819d5-58e0-46a0-8e1a-91ea6a269d84" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpexec : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "5faff0aa-9ffe-5ac0-b9e0-ca9f79350036"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/anthemtotheego/SharpExec"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2797-L2810"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "099c18601efc20cb50e7e463755ebda5898cce5d4a0253216a72018337da07f4"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "7fbad126-e21c-4c4e-a9f0-613fcf585a71" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpcom : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "94da3da4-a8aa-5735-9a04-1f2447a330aa"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/rvrsh3ll/SharpCOM"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2812-L2825"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f409d4390fbf8eea8b288e02fbe75d4ecf338a239d8015511f4a9979a1e8a7df"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "51960f7d-76fe-499f-afbd-acabd7ba50d1" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Inception : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "8d18f1d5-9c9a-5258-9f96-fa24b702c6ad"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/two06/Inception"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2827-L2840"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "846dfe525380eae42905a3adfbfc56f6c0e6de8abfa4f92e5f02889448dbcc29"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "03d96b8c-efd1-44a9-8db2-0b74db5d247a" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpwmi_1 : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "cd5a1c7b-a45a-5541-b1b0-cf19c991ed22"
		date = "2020-12-28"
		modified = "2025-08-15"
		old_rule_name = "HKTL_NET_GUID_sharpwmi"
		reference = "https://github.com/QAX-A-Team/sharpwmi"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2842-L2856"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "295315b876579ee0d2eb60a44e4be643c143ec1331b155faf0ba61ab016df07f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "bb357d38-6dc1-4f20-a54c-d664bd20677e" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_CVE_2019_1064 : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "4640e874-faa4-58dc-a3f3-18246a343f15"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/RythmStick/CVE-2019-1064"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2858-L2871"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "5f72f2569d7e3c1ee6fcd742e22d56331bcbf130b9f2bbc63fbc1504c6597e57"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "ff97e98a-635e-4ea9-b2d0-1a13f6bdbc38" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Tokenvator : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "84ebb6b3-cf11-5172-95d4-d114bfeb0bc7"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/0xbadjuju/Tokenvator"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2873-L2886"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "45e75eee8ece293a35ac385311994cf8b23fd4f38d84bf53bd724e03ec092e4e"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "4b2b3bd4-d28f-44cc-96b3-4a2f64213109" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Wheresmyimplant : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "c99523ce-e2c0-5a21-89d1-70c0dd970731"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/0xbadjuju/WheresMyImplant"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2888-L2901"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e25816823669753dc475c059320634203e9f9450c320baac3af0d6c996a17264"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "cca59e4e-ce4d-40fc-965f-34560330c7e6" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Naga : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "3a9d3154-a8f1-57a4-8b61-498e2ebdfa42"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/byt3bl33d3r/Naga"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2903-L2917"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c579546957c1b05d5fff7ad914d4b6de22ccf216bda92972abd66b0dae89895b"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "99428732-4979-47b6-a323-0bb7d6d07c95" ascii wide
		$typelibguid1lo = "a2c9488f-6067-4b17-8c6f-2d464e65c535" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpbox : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "fda1a67f-d746-5ddb-a33f-97d608b13bc9"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/P1CKLES/SharpBox"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2919-L2932"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1a52663ffad8b36d8e6be74c341fb26205b9605df35530b19ab2f4a4c454eb16"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "616c1afb-2944-42ed-9951-bf435cadb600" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Rundotnetdll32 : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "266c8add-d2ca-5e46-8594-5d190447d133"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/0xbadjuju/rundotnetdll32"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2934-L2947"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d0a0fa8604eaca14e2fc8545c5b008d26ef1a09f3d792b62549d76fb2d5155d1"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "a766db28-94b6-4ed1-aef9-5200bbdd8ca7" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Antidebug : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "f381081b-d0cb-593d-ad3d-28816f770b67"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/malcomvetter/AntiDebug"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2949-L2962"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b665c72e191cc42307f6eecbf0a9ea9238da886e8d5d73b2d569cda2dabe2b1a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "997265c1-1342-4d44-aded-67964a32f859" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Dinvisibleregistry : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "98409bbe-6346-5825-b7f7-c1afeac2b038"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/NVISO-BE/DInvisibleRegistry"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2964-L2977"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7703b24ca72770547d76ebfb8b94b5d13d9d7fa1c65cc8e2ffbf8eca30c1f8d0"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "31d576fb-9fb9-455e-ab02-c78981634c65" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Tikitorch : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "354ee690-a0d0-5cc5-a73b-53b916ed0169"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/rasta-mouse/TikiTorch"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L2979-L2998"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "394b4e7ecb7333e7d0944690276de6d942dfa949ba04d28d5576da639a5489bc"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "806c6c72-4adc-43d9-b028-6872fa48d334" ascii wide
		$typelibguid1lo = "2ef9d8f7-6b77-4b75-822b-6a53a922c30f" ascii wide
		$typelibguid2lo = "8f5f3a95-f05c-4dce-8bc3-d0a0d4153db6" ascii wide
		$typelibguid3lo = "1f707405-9708-4a34-a809-2c62b84d4f0a" ascii wide
		$typelibguid4lo = "97421325-b6d8-49e5-adf0-e2126abc17ee" ascii wide
		$typelibguid5lo = "06c247da-e2e1-47f3-bc3c-da0838a6df1f" ascii wide
		$typelibguid6lo = "fc700ac6-5182-421f-8853-0ad18cdbeb39" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Hivejack : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "10567ef4-780f-5e93-9061-3214116d6bbb"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/Viralmaniar/HiveJack"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3000-L3013"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "46eb7b01deb14eb7a9e1b59f04844b442a47a5c3545fa9925448349ef50e317e"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "e12e62fe-bea3-4989-bf04-6f76028623e3" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Decryptautologon : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "3ef58da9-16c1-54cf-9d06-a05680548cf5"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/securesean/DecryptAutoLogon"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3015-L3028"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "122f265f812e81aef554c1907c8397ac4ad03ff85f53254806abe36049c9b746"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "015a37fc-53d0-499b-bffe-ab88c5086040" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Unstoppableservice : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "8c65fbee-d779-57a8-851b-7583be66c67a"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/malcomvetter/UnstoppableService"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3030-L3043"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ad88047730485852c1d051f168b762da18a85242acf0850204dd5fc86b313390"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "0c117ee5-2a21-dead-beef-8cc7f0caaa86" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpwmi_2 : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "e6ab2f5e-2a5a-5be9-9b66-96cb745fd199"
		date = "2020-12-28"
		modified = "2025-08-15"
		old_rule_name = "HKTL_NET_GUID_SharpWMI"
		reference = "https://github.com/GhostPack/SharpWMI"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3045-L3059"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "968eddc046e0629fed50d77c3b6c55a6d88d4fa68f05bab77f4b43bea6ad62fc"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "6dd22880-dac5-4b4d-9c91-8c35cc7b8180" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Ewstoolkit : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "acde7744-d17f-5e47-a5e2-ff4f4c4d8093"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/rasta-mouse/EWSToolkit"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3061-L3074"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d8e10bc2bc8dc0b526f919eed141660555334b97f528d3a74c5b91db05394fad"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "ca536d67-53c9-43b5-8bc8-9a05fdc567ed" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sweetpotato : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "0e347d94-51eb-5589-93d8-b19fec7f2365"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/CCob/SweetPotato"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3076-L3090"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "36430e0c2874aed1d86e061f9413c16bbb4527d0d04dfb8993214920083cc30a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "6aeb5004-6093-4c23-aeae-911d64cacc58" ascii wide
		$typelibguid1lo = "1bf9c10f-6f89-4520-9d2e-aaf17d17ba5e" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Memscan : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "35175fe1-a583-50d1-8b0c-71f19b898817"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/nccgroup/memscan"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3092-L3105"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9885512853fc46cc680b70ab26b40d4e51393b1f0b744565d4a4aa063cb78440"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "79462f87-8418-4834-9356-8c11e44ce189" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpstay : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "e5bde5a9-8e09-59ce-ad01-e29836813cf8"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/0xthirteen/SharpStay"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3107-L3120"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "91fe0fd4bea7678df8bdb0948a0952e01b6588e07836d535f5aaa3700294d838"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "2963c954-7b1e-47f5-b4fa-2fc1f0d56aea" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharplocker : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "9525422a-d670-5475-abdc-b7ecd1ab9943"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/Pickfordmatt/SharpLocker"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3122-L3135"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "030b7a87042ce70c9de6031d0e03f07e508563f4ca2da4d6dc80e87f8bf483de"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "a6f8500f-68bc-4efc-962a-6c6e68d893af" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sauroneye : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "3b624dde-a63e-58ac-a4db-af931f1d8553"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/vivami/SauronEye"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3137-L3151"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "feeda6aec173cb13209559dc3a156bdc3d4be6e14cbe52ffb2e1bb7bf652441a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "0f43043d-8957-4ade-a0f4-25c1122e8118" ascii wide
		$typelibguid1lo = "086bf0ca-f1e4-4e8f-9040-a8c37a49fa26" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sitrep : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "5f2ac63e-4be1-520c-82b1-1957027a63e2"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/mdsecactivebreach/sitrep"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3153-L3166"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "113e3a23c3f8258707f9d0c1baa143b3599e5da10928f275fca908c3a57f76e8"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "12963497-988f-46c0-9212-28b4b2b1831b" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpclipboard : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "fd1b7786-8853-5858-ab03-da350e44f738"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/slyd0g/SharpClipboard"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3168-L3181"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "5070ae56bb7f5df31e915104ce42e18dbf86b93a327c49dabddcfbd141d468ac"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "97484211-4726-4129-86aa-ae01d17690be" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpcookiemonster : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "87be6949-f4f5-5a5a-b804-c627ed0f4355"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/m0rv4i/SharpCookieMonster"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3183-L3196"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1aac6d1c4e1d28805ec7e61ee00d105795ce355dce6238981b22b6f7cf9d4e29"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "566c5556-1204-4db9-9dc8-a24091baaa8e" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_P0Wnedshell : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "390b94d1-dda9-5a85-80ae-c79a3f7b0b9d"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/Cn33liz/p0wnedShell"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3198-L3211"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7c6d8dbcd1ff31a9b34c36b4db2867f0b9e3fac98c7039d2a51bfe5a45afcc71"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "2e9b1462-f47c-48ca-9d85-004493892381" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpmove : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "e52392f9-614c-596e-8efd-aa0a2fa44e60"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/0xthirteen/SharpMove"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3213-L3226"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4980a9b197479b2514e12b78aa5a3bf9825772f8578d3abd219607e39af7e470"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "8bf82bbe-909c-4777-a2fc-ea7c070ff43e" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_C_Sharp_R_A_T_Client : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "f5df8257-d202-58e3-9c4a-1dfc9dd52f2a"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/AdvancedHacker101/C-Sharp-R.A.T-Client"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3228-L3241"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a090996b8453fb41483888f433da57340a6509221439ffd8f17e546424686c55"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "6d9e8852-e86c-4e36-9cb4-b3c3853ed6b8" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpprinter : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "10270351-ad80-5330-971b-bc8f635f05f4"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/rvrsh3ll/SharpPrinter"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3243-L3256"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "86eb7194039aa8bb89f77041215a3421bb35acd790aa769156298f30a124e9b3"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "41b2d1e5-4c5d-444c-aa47-629955401ed9" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Evilfoca : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "2b2f5f6f-4224-5013-9e85-0ac088826bea"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/ElevenPaths/EvilFOCA"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3258-L3271"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f903e2552bdb75a985065e9b78229b56c8005041cf3a75be355192684582caee"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "f26bdb4a-5846-4bec-8f52-3c39d32df495" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Poshc2_Misc : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "245803cb-63d8-5c75-b672-912091cf4a80"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/nettitude/PoshC2_Misc"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3273-L3287"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "2ad0da62428f8412c748418b44d943a143191bbe789394ffc7b21658f87c27b9"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "85773eb7-b159-45fe-96cd-11bad51da6de" ascii wide
		$typelibguid1lo = "9d32ad59-4093-420d-b45c-5fff391e990d" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpire : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "32bdaa0f-3afc-5e0e-a20f-e21f33909af7"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/0xbadjuju/Sharpire"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3289-L3302"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c53b3205e58257292e34526ea4fd0e0550bbdcf4039f94d268a313ae28733182"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "39b75120-07fe-4833-a02e-579ff8b68331" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharp_Smbexec : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "6a1024af-734c-5974-af50-db51dbd694ff"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/checkymander/Sharp-SMBExec"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3304-L3317"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d6938d7492904a202e80525ff8f1b95c19bd65b1450f2f7e4271ab01f2e25a50"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "344ee55a-4e32-46f2-a003-69ad52b55945" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Misctools : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "ce49cc7b-a5a5-52b7-a7bf-bbb0c5b29b8a"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/rasta-mouse/MiscTools"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3319-L3336"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ffa89aeac49c1652618def1b63506915ec6a364708eb805ef2d9abe710111edf"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "384e9647-28a9-4835-8fa7-2472b1acedc0" ascii wide
		$typelibguid1lo = "d7ec0ef5-157c-4533-bbcd-0fe070fbf8d9" ascii wide
		$typelibguid2lo = "10085d98-48b9-42a8-b15b-cb27a243761b" ascii wide
		$typelibguid3lo = "6aacd159-f4e7-4632-bad1-2ae8526a9633" ascii wide
		$typelibguid4lo = "49a6719e-11a8-46e6-ad7a-1db1be9fea37" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Memorymapper : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "c978be10-315c-54e7-afea-f97e9a5f2d18"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/jasondrawdy/MemoryMapper"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3338-L3351"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "691aae2ac0c6dec88c64fd1195f67e34235514037c54ebd1f1ac04d92aa3bbb1"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "b9fbf3ac-05d8-4cd5-9694-b224d4e6c0ea" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Vanillarat : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "9448e8d0-5bfc-5683-b633-284e43d24642"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/DannyTheSloth/VanillaRAT"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3353-L3367"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7e3dd2e631b06201fa3065ebf10c1bb258839106443228af7f07706530a3070d"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "d0f2ee67-0a50-423d-bfe6-845da892a2db" ascii wide
		$typelibguid1lo = "a593fcd2-c8ab-45f6-9aeb-8ab5e20ab402" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Unmanagedpowershell : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "49ff1362-0ac5-580d-97f3-516f2a10072b"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/leechristensen/UnmanagedPowerShell"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3369-L3382"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "027b0dcbbacaafe6709e18a29b0c001f17f14128648cb64afdcf946804aa8796"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "dfc4eebb-7384-4db5-9bad-257203029bd9" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Quasar : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "b938cf7d-27fd-5fa2-b0e5-d4da5670f3ef"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/quasar/Quasar"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3384-L3398"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "51eed0545b985c20db7aae64251a0e7513cb352f2ff76f64d7697d2767f95db2"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "cfda6d2e-8ab3-4349-b89a-33e1f0dab32b" ascii wide
		$typelibguid1lo = "c7c363ba-e5b6-4e18-9224-39bc8da73172" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpadidnsdump : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "51d50b22-4e73-5378-9e0d-ad7730987293"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/b4rtik/SharpAdidnsdump"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3400-L3413"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "edda1bb7a0a1702941fa35b38120f7e9ae64b6188a47e63a0939a864980b6281"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "cdb02bc2-5f62-4c8a-af69-acc3ab82e741" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Dotnettojscript : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "31827074-fc63-5690-b6c7-8e89daacc07f"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/tyranid/DotNetToJScript"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3415-L3428"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "07f220695607b5aa6cda9045c3bc1e434828cb5835154710969666482dbe09c4"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "7e3f231c-0d0b-4025-812c-0ef099404861" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Inferno : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "af2d9832-c7f9-5879-a19b-a3c4d91b8b3f"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/LimerBoy/Inferno"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3430-L3443"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6e286b28bdc490d16892926ba95227d39aebb151067896e740d497024c526c0e"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "26d498f7-37ae-476c-97b0-3761e3a919f0" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpsearch : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "459d8a34-f311-5459-8257-e7aa519174b5"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/djhohnstein/SharpSearch"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3445-L3458"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1a383fd8e4ec8fa9f1fbc01bdeb3d5b1e32ec825a24c1eaad6c42e86ac682530"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "98fee742-8410-4f20-8b2d-d7d789ab003d" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpsecdump : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "492dfb79-541a-589d-ac69-468e9b2ab9db"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/G0ldenGunSec/SharpSecDump"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3460-L3473"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "749130efbcdbd068bf4711cc5e4960eb97a3ae2ddadde2beb0ff707429495484"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "e2fdd6cc-9886-456c-9021-ee2c47cf67b7" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Net_Gpppassword : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "a718f9fc-acf5-536e-81d6-d393cebe8f77"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/outflanknl/Net-GPPPassword"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3475-L3488"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "46ae3156e5428c40278b124b7206b68922f955a297077df3288722c154d09fba"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "00fcf72c-d148-4dd0-9ca4-0181c4bd55c3" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Filesearcher : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "1b5f1f68-f87b-5e60-94a4-e2556b4e6c5d"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/NVISO-BE/FileSearcher"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3490-L3503"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b72d3a7104ca7718d3d490149483a5d2d30790fb6d2b00b10c69da43c491e577"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "2c879479-5027-4ce9-aaac-084db0e6d630" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Adfsdump : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "8cb2edcd-3696-5857-90ca-e99b1af54320"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/fireeye/ADFSDump"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3505-L3518"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3735495d2c3a0b6f9de278014d5450f3d2e78dda9c04ede614550c75a05b43d2"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "9ee27d63-6ac9-4037-860b-44e91bae7f0d" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharprdp : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "d316ec0b-0313-52bb-923d-512fa08112f9"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/0xthirteen/SharpRDP"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3520-L3533"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "96a5d82e8d03b6242d69cbd5bca2fcc3d4403e7a51099a37dcf9091a0bd53b6e"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "f1df1d0f-ff86-4106-97a8-f95aaf525c54" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpcall : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "172415b6-0383-5da4-a88f-8ebe5daf9294"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/jhalon/SharpCall"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3535-L3548"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4b4a8943e4fc07f41ce87d64266fd56af9912832b688f21769f4fe5a8152703b"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "c1b0a923-0f17-4bc8-ba0f-c87aff43e799" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Ysoserial_Net : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "80483cd4-76e6-5629-bed7-4ae2e455222c"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/pwntester/ysoserial.net"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3550-L3564"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7d775864610e2e60faa3570746aa7a689bd719b02c3a47f43a2be097e4a81c5a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "e1e8c029-f7cd-4bd1-952e-e819b41520f0" ascii wide
		$typelibguid1lo = "6b40fde7-14ea-4f57-8b7b-cc2eb4a25e6c" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Managedinjection : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "c66e7666-b54f-532d-90e1-870292047aec"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/malcomvetter/ManagedInjection"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3566-L3581"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "eac722f30fea497f98d75293514e0f6f4dd17263c7377211605b1ab2f13ddf2f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "e5182bff-9562-40ff-b864-5a6b30c3b13b" ascii wide
		$typelibguid1lo = "fdedde0d-e095-41c9-93fb-c2219ada55b1" ascii wide
		$typelibguid2lo = "0dd00561-affc-4066-8c48-ce950788c3c8" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
