/*
    Umay heuristics: Windows executables.

    Import-based rules describe a capability, not an intent: debuggers,
    installers and security tools use the same calls. Weights are set so one
    capability alone never reports a file.
*/

import "pe"

rule PE_RemoteThreadInjection
{
    meta:
        umay_name = "Heur.PE.RemoteThreadInjection"
        umay_weight = 35
        description = "Can write code into another running process and start it there"
    condition:
        umay_kind == "pe" and pe.is_pe
        and pe.imports("kernel32.dll", "VirtualAllocEx")
        and pe.imports("kernel32.dll", "WriteProcessMemory")
        and (
            pe.imports("kernel32.dll", "CreateRemoteThread")
            or pe.imports("kernel32.dll", "CreateRemoteThreadEx")
            or pe.imports("ntdll.dll", "NtCreateThreadEx")
            or pe.imports("ntdll.dll", "RtlCreateUserThread")
            or pe.imports("kernel32.dll", "QueueUserAPC")
        )
}

rule PE_ProcessHollowing
{
    meta:
        umay_name = "Heur.PE.ProcessHollowing"
        umay_weight = 50
        description = "Can start a legitimate program suspended, replace its code and resume it as a disguise"
    condition:
        umay_kind == "pe" and pe.is_pe
        and (pe.imports("ntdll.dll", "NtUnmapViewOfSection") or pe.imports("ntdll.dll", "ZwUnmapViewOfSection"))
        and pe.imports("kernel32.dll", "WriteProcessMemory")
        and pe.imports("kernel32.dll", "SetThreadContext")
        and pe.imports("kernel32.dll", "ResumeThread")
}

rule PE_KeystrokeCapture
{
    meta:
        umay_name = "Heur.PE.KeystrokeCapture"
        umay_weight = 30
        description = "Installs a system-wide keyboard hook and tracks which window is active"
    condition:
        umay_kind == "pe" and pe.is_pe
        and (pe.imports("user32.dll", "SetWindowsHookExA") or pe.imports("user32.dll", "SetWindowsHookExW"))
        and (pe.imports("user32.dll", "GetAsyncKeyState") or pe.imports("user32.dll", "GetKeyboardState"))
        and pe.imports("user32.dll", "GetForegroundWindow")
}

rule PE_SandboxEvasion
{
    meta:
        umay_name = "Heur.PE.SandboxEvasion"
        umay_weight = 30
        description = "Looks for debuggers, virtual machines and analysis sandboxes before running"
    strings:
        $vm1 = "VBoxService" nocase ascii wide
        $vm2 = "vmtoolsd" nocase ascii wide
        $vm3 = "SbieDll.dll" nocase ascii wide
        $vm4 = "wine_get_unix_file_name" ascii
        $vm5 = "\\\\.\\VBoxMiniRdrDN" ascii wide
        $vm6 = "HARDWARE\\ACPI\\DSDT\\VBOX__" nocase ascii wide
        $vm7 = "cuckoomon" nocase ascii wide
    condition:
        umay_kind == "pe" and pe.is_pe and 3 of ($vm*)
}

rule PE_BrowserCredentialTheft
{
    meta:
        umay_name = "Heur.PE.BrowserCredentialTheft"
        umay_weight = 45
        description = "References saved-password stores of several browsers and wallets"
    strings:
        $c1 = "\\Google\\Chrome\\User Data" nocase ascii wide
        $c2 = "\\Microsoft\\Edge\\User Data" nocase ascii wide
        $c3 = "\\BraveSoftware\\Brave-Browser\\User Data" nocase ascii wide
        $c4 = "\\Mozilla\\Firefox\\Profiles" nocase ascii wide
        $d1 = "Login Data" ascii wide
        $d2 = "logins.json" ascii wide
        $d3 = "wallet.dat" nocase ascii wide
        $d4 = "encrypted_key" ascii wide
        $d5 = "\\Exodus\\exodus.wallet" nocase ascii wide
        $d6 = "\\Electrum\\wallets" nocase ascii wide
    condition:
        umay_kind == "pe" and pe.is_pe and 2 of ($c*) and 2 of ($d*)
}

rule PE_DefenderTampering
{
    meta:
        umay_name = "Heur.PE.DefenderTampering"
        umay_weight = 45
        description = "Carries the registry settings that switch Microsoft Defender off"
    strings:
        $key = "SOFTWARE\\Policies\\Microsoft\\Windows Defender" nocase ascii wide
        $v1 = "DisableAntiSpyware" nocase ascii wide
        $v2 = "DisableRealtimeMonitoring" nocase ascii wide
        $v3 = "DisableBehaviorMonitoring" nocase ascii wide
        $v4 = "DisableOnAccessProtection" nocase ascii wide
    condition:
        umay_kind == "pe" and pe.is_pe and $key and 2 of ($v*)
}

rule PE_BackupDestruction
{
    meta:
        umay_name = "Heur.PE.BackupDestruction"
        umay_weight = 55
        description = "Contains the commands used to delete restore points and disable recovery before encrypting files"
    strings:
        $s1 = /vssadmin(\.exe)?\s+delete\s+shadows/ nocase ascii wide
        $s2 = /wmic(\.exe)?\s+shadowcopy\s+delete/ nocase ascii wide
        $s3 = /wbadmin(\.exe)?\s+delete\s+catalog/ nocase ascii wide
        $s4 = /recoveryenabled\s+no/ nocase ascii wide
        $s5 = /bootstatuspolicy\s+ignoreallfailures/ nocase ascii wide
    condition:
        umay_kind == "pe" and pe.is_pe and 2 of them
}

rule PE_RansomNoteText
{
    meta:
        umay_name = "Heur.PE.RansomNoteText"
        umay_weight = 40
        description = "Embeds the text of a ransom demand"
    strings:
        $t1 = "files have been encrypted" nocase ascii wide
        $t2 = "decrypt your files" nocase ascii wide
        $t3 = "recover your files" nocase ascii wide
        $t4 = "private key" nocase ascii wide
        $t5 = /[a-z2-7]{16,56}\.onion/ ascii wide
        $t6 = "bitcoin" nocase ascii wide
        $t7 = "Tor Browser" nocase ascii wide
    condition:
        (umay_kind == "pe" or umay_kind == "elf" or umay_kind == "macho") and 4 of them
}
