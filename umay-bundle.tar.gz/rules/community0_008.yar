import "dotnet"
import "hash"
import "pe"

rule DITEKSHEN_INDICATOR_KB_ID_Bazarloader : FILE
{
	meta:
		description = "Detects Bazar executables with specific email addresses found in the code signing certificate"
		author = "ditekShen"
		id = "94b814e3-56c2-5cdb-9335-c92eea8ec668"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L11-L21"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "fd47a1d996c78a6efc144f0fe0a28951c34becab3101e7d25acc980bb6b9f8ce"
		score = 75
		quality = 71
		tags = "FILE"

	strings:
		$s1 = "skarabeyllc@gmail.com" ascii wide nocase
		$s2 = "admin@intell-it.ru" ascii wide nocase
		$s3 = "support@pro-kon.ru" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Amadey : FILE
{
	meta:
		description = "Detects Amadey executables with specific email addresses found in the code signing certificate"
		author = "ditekShen"
		id = "f9abbf1d-2077-52a8-bfb0-df3732649624"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L39-L47"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "3df3fe67835f76e51743b1b4fa2cbc48277d82689c2fc27457b4d7d820e56e43"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "tochka.director@gmail.com" ascii wide nocase

	condition:
		uint16( 0 ) == 0x5a4d and any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_UNK01 : FILE
{
	meta:
		description = "Detects Amadey executables with specific email addresses found in the code signing certificate"
		author = "ditekShen"
		id = "56e83bfb-e17d-5d27-87fa-e275cc540148"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L49-L58"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		hash = "37d08a64868c35c5bae8f5155cc669486590951ea80dd9da61ec38defb89a146"
		logic_hash = "d85461f74186fcabcbf7f2bc1dce06b0012c504cf3235a6fc3e1499dc6f8a3ee"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "etienne@tetracerous.br" ascii wide nocase

	condition:
		uint16( 0 ) == 0x5a4d and any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Goldenaxe
{
	meta:
		description = "Detects files referencing identities associated with GoldenAxe ransomware"
		author = "ditekShen"
		id = "cd6486eb-742f-50fb-bd99-c5d778886477"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L82-L91"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "2540da85880dc08b51a2d096cefd8ed3cb14ccd171b71b434ccf26e7c5f1b54b"
		score = 75
		quality = 71
		tags = ""

	strings:
		$s1 = "xxback@keemail.me" nocase ascii wide
		$s2 = "darkusmbackup@protonmail.com" nocase ascii wide

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Ransomwareexx
{
	meta:
		description = "Detects files referencing identities associated with RansomwareEXX Linux ransomware"
		author = "ditekShen"
		id = "dfcff8cb-c50c-559e-b5b9-8c2cdac7a3dc"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L142-L150"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a83ada5d29c6d62a292c4b3a1379558cddcaf63d97dbdfc6afd27cc52f6f656d"
		score = 75
		quality = 73
		tags = ""

	strings:
		$s1 = "france.eigs@protonmail.com" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Phobos
{
	meta:
		description = "Detects files referencing identities associated with Phobos ransomware"
		author = "ditekShen"
		id = "cee09220-4038-5190-b595-28f67c845588"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L152-L161"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "cf9e163d2315d465afb47bf83f30d5d27e14c4cbbc1c235dcb15b75fb509ba7d"
		score = 75
		quality = 71
		tags = ""

	strings:
		$s1 = "helprecover@foxmail.com" ascii wide nocase
		$s2 = "recoverhelp2020@thesecure.biz" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Epsilon
{
	meta:
		description = "Detects files referencing identities associated with Epsilon ransomware"
		author = "ditekShen"
		id = "acdeb3b1-872b-5892-9dfe-2e506f767da2"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L163-L171"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "163694ed2ae181764fc6e62027487d183114be35a689dd44d4d9761149df244b"
		score = 75
		quality = 73
		tags = ""

	strings:
		$s1 = "neftet@tutanota.com" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Thanos
{
	meta:
		description = "Detects files referencing identities associated with Thanos ransomware"
		author = "ditekShen"
		id = "22ffb4c9-f113-5d3e-a466-6c384c0c6e8a"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L173-L182"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "039ea384136a1aaa261702ed75ab9358aaa1ec2d5a8d35fe4789647f39490c7c"
		score = 75
		quality = 71
		tags = ""

	strings:
		$s1 = "my-contact-email@protonmail.com" ascii wide nocase
		$s2 = "get-my-data@protonmail.com" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Vovalex
{
	meta:
		description = "Detects files referencing identities associated with Vovalex ransomware"
		author = "ditekShen"
		id = "95e9ddce-8a19-59f1-baf4-bdac61c9c396"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L184-L192"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0e8b426e55c1efaf59e5f255f1da9cdfbb509561d3f7ea5baa2815c3131866eb"
		score = 75
		quality = 73
		tags = ""

	strings:
		$s1 = "vovanandlexus@cock.li" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Alumnilocker
{
	meta:
		description = "Detects files referencing identities associated with AlumniLocker ransomware"
		author = "ditekShen"
		id = "64b6aff8-3758-5837-b814-e2505a9c12a3"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L194-L202"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "aeab9cb2b2da246e1863cd1102d901d322017d0b309e852d83e4f66f6e4bdd22"
		score = 75
		quality = 73
		tags = ""

	strings:
		$s1 = "alumnilocker@protonmail.com" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Doejocrypt
{
	meta:
		description = "Detects files referencing identities associated with DoejoCrypt ransomware"
		author = "ditekShen"
		id = "bdf67fd3-8614-52f0-8804-9905f067a848"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L204-L213"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b76996ef413d017fa571115f7331154c808fed0f1b1e0c97241cadbbef260a00"
		score = 75
		quality = 71
		tags = ""

	strings:
		$s1 = "konedieyp@airmail.cc" ascii wide nocase
		$s2 = "uenwonken@memail.com" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Purge
{
	meta:
		description = "Detects files referencing identities associated with Purge ransomware"
		author = "ditekShen"
		id = "2a0f2c69-b179-5e48-9db6-be25e329f72b"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L215-L224"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "49f3f5a88212d4bed1f0237a4437fb537e84cd6dd26c5fe224250f3b6e39d384"
		score = 75
		quality = 71
		tags = ""

	strings:
		$s1 = "rscl@dr.com" ascii wide nocase
		$s2 = "rscl@usa.com" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Zeoticus
{
	meta:
		description = "Detects files referencing identities associated with Zeoticus ransomware"
		author = "ditekShen"
		id = "4d5f0d6d-f792-563d-9a9b-1986f5af8743"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L226-L235"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "7a83b15b0c8e81f67d11f8b5d9a43ba4e1e3a0f6741ddd0daafe4e742dd91cd8"
		score = 75
		quality = 71
		tags = ""

	strings:
		$s1 = "anobtanium@tutanota.com" ascii wide nocase
		$s2 = "anobtanium@cock.li" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Unlockyourfiles
{
	meta:
		description = "Detects files referencing identities associated with UnlockYourFiles ransomware"
		author = "ditekShen"
		id = "fdc3ec49-66cc-5a0b-87a6-3660dd6f3b72"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L279-L288"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a33dae7f08eb0c2415fbfdadf2cbbf90c68bc802352277422c6d0a2dbd62cd82"
		score = 75
		quality = 71
		tags = ""

	strings:
		$s1 = "4lok3r@tutanota.com" ascii wide nocase
		$s2 = "4lok3r@protonmail.com" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Darkside
{
	meta:
		description = "Detects files referencing identities associated with DarkSide ransomware"
		author = "ditekShen"
		id = "7b29b9b9-4657-551e-b770-880a2278ef60"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L290-L299"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		hash = "bafa2efff234303166d663f967037dae43701e7d63d914efc8c894b3e5be9408"
		logic_hash = "3c6cdb15cad19f1db38c0fe03ecb24d5cd4861a699aa2bee0f99b8dddacc8bd1"
		score = 75
		quality = 73
		tags = ""

	strings:
		$s1 = "breathcojunktab1987@yahoo.com" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Spyro
{
	meta:
		description = "Detects files referencing identities associated with Spyro ransomware"
		author = "ditekShen"
		id = "9a42a9fd-dfaf-5719-acae-e7c3b92ecdc9"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L301-L310"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b12b24b7b1b9800d249fd322532d957ddfc020c495ca89414d8d7e9fa7d58eb7"
		score = 75
		quality = 71
		tags = ""

	strings:
		$s1 = "blackspyro@tutanota.com" ascii wide nocase
		$s2 = "blackspyro@mailfence.com" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Ryzerlo
{
	meta:
		description = "Detects files referencing identities associated with Ryzerlo / HiddenTear / RSJON ransomware"
		author = "ditekShen"
		id = "1e8b79dc-4a81-5126-a7a3-ad7a2e8f62bf"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L312-L320"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "2d925cac74411c3e408d674e27a27ae029d39977026a79df8f90edae345a31db"
		score = 75
		quality = 73
		tags = ""

	strings:
		$s1 = "darkjon@protonmail.com" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Ranzylocker
{
	meta:
		description = "Detects files referencing identities associated with RanzyLocker ransomware"
		author = "ditekShen"
		id = "33478dc4-c0ec-5cc8-8620-79e770f6a773"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L354-L363"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "dc345257a3cca82a95e20505c94e90d8ac42240e1491ea1f34be121871673e26"
		score = 75
		quality = 71
		tags = ""

	strings:
		$s1 = "eviluser@tutanota.com" ascii wide nocase
		$s2 = "evilpr0ton@protonmail.com" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Alkhal
{
	meta:
		description = "Detects files referencing identities associated with AlKhal ransomware"
		author = "ditekShen"
		id = "32e14a6e-fc2e-5c0a-b8e3-33e219923d90"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L365-L374"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "bd2d66a9cd33ab15b451158cd6c0e6579735653611ee2e6c8045a5807091938d"
		score = 75
		quality = 71
		tags = ""

	strings:
		$s1 = "alkhal@tutanota.com" ascii wide nocase
		$s2 = "cyrilga@tutanota.com" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_DECAF
{
	meta:
		description = "Detects files referencing identities associated with DECAF ransomware"
		author = "ditekShen"
		id = "24422015-56f3-503e-a902-0183eb601b22"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L376-L408"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "8fca3a6564cd11e625b65e7f0f278b79678368dd0c77440e9f8d46035e0c3426"
		score = 75
		quality = 73
		tags = ""

	strings:
		$s1 = "22eb687475f2c5ca30b@protonmail.com" ascii wide nocase
		$s2 = { 4d 49 49 42 43 67 4b 43 41 51 45 41 71 34 6b 31
                48 64 62 31 54 48 72 7a 42 42 65 4f 31 38 34 6b
                6e 43 62 42 4b 72 30 33 61 70 66 58 71 6c 4f 6b
                53 64 74 48 53 4a 67 66 79 49 71 4a 50 47 78 6c
                0a 2f 63 46 69 73 4a 6d 56 58 52 33 2f 74 34 65
                39 46 62 4c 73 45 49 75 54 70 39 50 4a 54 63 69
                6f 6d 48 66 72 35 43 67 43 51 7a 68 6e 41 5a 30
                41 76 6a 47 42 61 57 50 36 4b 70 43 79 66 44 6e
                73 0a 79 62 72 75 79 4b 71 79 67 61 57 70 5a 53
                41 6e 7a 52 64 42 2b 54 41 6b 75 35 69 71 79 38
                71 31 56 77 6e 4e 35 37 51 42 6c 74 72 6f 30 59
                4a 5a 38 65 6e 4b 5a 52 54 6c 63 7a 6d 74 6a 65
                4f 70 0a 42 2f 78 75 54 4f 75 44 6a 6d 55 53 4e
                69 47 79 69 6a 57 42 56 66 59 6b 37 73 56 58 6c
                2f 6c 51 38 74 61 58 72 33 36 78 50 57 68 4d 49
                47 30 45 71 52 56 72 46 56 2b 63 61 76 53 37 5a
                34 76 61 0a 79 58 6d 63 66 35 35 4e 6b 70 4d 47
                4b 4b 59 38 75 71 76 77 62 34 61 4c 49 4b 61 62
                65 6b 32 6e 55 57 42 67 4e 67 53 4f 74 71 42 4c
                4c 4c 32 41 32 62 59 2f 35 73 30 47 4a 2f 56 56
                2b 45 6d 49 0a 58 37 2f 7a 49 2b 46 63 65 55 2b
                64 63 4e 58 2f 69 72 30 75 6a 50 34 79 73 34 6d
                2f 6a 6a 5a 44 34 77 49 44 41 51 41 42 }

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Rapid
{
	meta:
		description = "Detects files referencing identities associated with Rapid ransomware"
		author = "ditekShen"
		id = "a1c6f3c0-2fec-5d96-9965-8129a843ae90"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L428-L436"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ea82a3fcb1d836e1c250e9a576064e1babdb82b4970555260af2eb68726cfd16"
		score = 75
		quality = 73
		tags = ""

	strings:
		$s1 = "jimmyneytron@tuta.io" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Satana
{
	meta:
		description = "Detects files referencing identities associated with Satana ransomware"
		author = "ditekShen"
		id = "a362d4ca-d475-5392-a3ac-45337425d8e7"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L438-L447"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "6d82e2497044518cee1b56da85f1ad6ac7934eec9ca68501932d55add4236d45"
		score = 75
		quality = 73
		tags = ""

	strings:
		$s1 = "adamadam@ausi.com" ascii wide nocase
		$s2 = "XsrR2he2Z8un5ysGWnJ1wveZRPRS96XEoX" ascii wide

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Diavol
{
	meta:
		description = "Detects files referencing identities associated with Diavol ransomware"
		author = "ditekShen"
		id = "ea499318-ed5b-5597-8f9f-4ece7942cf4b"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L482-L491"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c72f4d7854f7ba813c4872d47aad69edb8c2927f380b9213ced1aca52454eee5"
		score = 75
		quality = 71
		tags = ""

	strings:
		$s1 = "/noino.5fws6uqv5byttg2r//:sptth" ascii wide nocase
		$s2 = "https://r2gttyb5vqu6swf5.onion/" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Maze
{
	meta:
		description = "Detects files referencing identities associated with Maze ransomware"
		author = "ditekShen"
		id = "7cc11912-e5d2-5477-ab9b-0c470bb5e1d6"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L513-L521"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "46070d46c502837e5fb87d0fb75244a1a21e90b4e0ce4b73c408b8dc67fe1bcb"
		score = 75
		quality = 73
		tags = ""

	strings:
		$s1 = "getmyfilesback@airmail.cc" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Lokilocker
{
	meta:
		description = "Detects files referencing identities associated with LokiLocker ransomware"
		author = "ditekShen"
		id = "ab2cf390-4544-54ed-913c-d463d0f1bdb0"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L523-L531"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "1ab9a2ce7e39d916b389e2adb975e3558ddb7d87f7e9494e6b20cb25edd3cb84"
		score = 75
		quality = 73
		tags = ""

	strings:
		$s1 = "Unlockpls.dr01@yahoo.com" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Blackcat
{
	meta:
		description = "Detects files referencing identities associated with BlackCat ransomware"
		author = "ditekShen"
		id = "21038f8e-73cd-59d2-9eb3-6947d263ab79"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L533-L569"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "eb0a4d26170f030775f778cc524749ca283dfa983f84bd364e4df6321eb96cf1"
		score = 75
		quality = 73
		tags = ""

	strings:
		$pk1 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0B0ni9tyKHSJmU6gc1iRwNTklYocRKmLPUyOthUIHnZHwL1M2pKlMBwXx81bboVS6Cf8YaCoWW1bCmLwPX421sG22xkmtMy/SfiG8jaYtYiA7r7hOdIUnJgRo6vDvNafZlSD32tFVVjuX8Ec79qj2FM7/MmNcseUgpIQaEACuZcSzMK+jZA4BLT9b5Akkec2hPOXGTPmgaXjL9EJE+0rhNZcm/m6xe4/S5eL2kSCVsNUeG8xWuSO2kDRS8xY3rtJOCNEdqZp1rxzTkhgj3hHqr7AoFAkxNblQ538JcdF5+CGINxckA/ldmP7wQd92tmFk2vcl2WeQykFwMM6L6MsQwIDAQAB" ascii wide
		$pk2 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA49gzJwP9UwEuYQZT1cdgSpxG6z8TVNLPfS4Qwd3vpWHEOAuvi8JGVEpHPGZnrD1QFoDLSTva3PZ4mqtIVO79GOYb5uQkP7LdJGWbLAjUGptVGmB67jKOOLLrjmuBDHpJXSOGG/vw5vajr4MhNnsvoBLPOC0AOzPM6GBDgKdC9zdUGNEreAjOR4neqwZ2jfYl5k5e3eRF86hmWhGXJQaU1uTmDJwgQIzmUZKo+YCfAHbEbSA4HhsumJfw0MJN7RfKPEQkEVvRIBibHnJuIp1bxk3IGPzTCbyQLHMVLz8wgElEexu8/aO3FT6w4uPY3qD+r2W+ri7xIdEN/pTz6TBKvwIDAQAB" ascii wide
		$pk3 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA8tKPNFCbU5Unr9jxlTk4RmUdVhcRydJFts6hMpLzcAXIR2yxiNC0QiF4UovAIpGwX6kxOW7kOaOvABJQP6QENMNSg030VlLoTP+ndfFwIt+X+RUflG4UWPE8yu+kzGpCwp7UjX+hD/SpFbSFRRh3BvL3vEq04DzE0AzifEBE4yxKpLsrMsXyZzWy9Nza8NTO2jrBxoEVM2xCLkULp0wZEPDwgeKGkoxMzqavVWBC+Vxi0atKstbo7/TloNenPagl/eUErk9C8tT67zKgbEh3TFtREgaxa/yrjBvN48BU8JGGxLxy4AeGF0vOUdD0WkJsWYzLVg21ApgJaCDr5zDPuQIDAQAB" ascii wide
		$pk4 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApw3tWdMaWJvNf2Mejy5H0Y6kuj+lstNpwFyismGDEYhWKPps9c68xl+84o6uLKfqPzNvLnSxlVa6DitcJGeKJEQkzN+C1e1KsfzM63jHybREB2hs+dHbqBq4dbamIQcTrrr4mKzuHJ7aok4mlpRx2Un1XOJaodoV7xOHO7ui5v6uK39MJ3rvitSEBvv5oI0WDlp3IFmtd6UM6r2nygY1ncAUuasalZgF1Vaz7VXOWyX2ReQHbYWWRCR1qyKMQcBtjT5POXx9B8ek1pnU4p65kGe9M794Bhhh20GN24gY5a+zwXwstaNTO9luwd4xjjRQAVsDgjrjkzti27G11ICn6wIDAQAB" ascii wide
		$pk5 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAq8kj5LQJngPsY7AhTaJsUXc5FrSGeKS5gw5PIqk2QPM9TY6+us8TRRzWZ7rGk1zns2klpzpRMUzLIqB8lpCkJjqkOUGfgqs+HN4VIOpoJgFY897xstJCxTc+8pYQEsSqClxJllscU0okkLSQqndIR2Gznlg3qfcwyncJAFBInyqM+L4kbwCQZ6x5HNiLe2lJn8RP2aDiMI+RS1uLYron2G7rxDTUQnxThMtgLAeko8ulaB3TpB0g4lmHCenkEZeBNs81986+MjHnv7KkiscZ7ZrezKjNaIxRs8BAcD9y+Q9QQxCvZMS01ITNXcgiItbA4dsGq1fPJ42yBkkiIodsEQIDAQAB" ascii wide
		$pk6 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqEoytNrMZRoqyIsFpcjiqVWpuV+cC9jS1umXNg/AnJF/xE7LONAmb1p8Dsx1igIUd65IXfFUxmJjFO5hf8LIBzvjUbBll4lbSgGTAUHa3Jbmr/imle6QftmY32J7dDb4WuJUOx+vLNT0I72CESiyotSzwgvLwjyubTmzTJMkqviYOcgDj45NVOx669cG6FWEaJo3PUZzRx9LS6pkOn8tW+W4NzmHMcrma+LOakan7NU6Khv5Hf5ARNsAA+KvDfP1WXJ/VsLXj6x8SdX0v2iS+y58ehUUmlxc8HNsYdOGFwrwYX9zLyJDedsbPg02c4AE4KXt8vH4+j4lVFtruSy4vwIDAQAB" ascii wide
		$pk7 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAt9uYkHzaizNXg/S11ncTTLybkMtqrKW8gg6TyzbGWnRNROl9O+l1VZBLG0xiMt1mZbuStl8Lt3l1vlkMa92kgLjN+UfKmq3KhBEheN2uMmR0WpwV83kceVRmzr5lug4RyQ/xA6/OXK4NptDIT4L6CUTBWMyk2mmY0Cq9HyyrjdnHeAXWAcQGFEac7W4jTjONZqI+lgScPewS+cPFnz1hAD0IAqzj5X2mZVSfFGR3tDoIe42jw5wb6W2yi8zb3mgKrGtTBbw0Ppj0UgKrmdN5iFmfUQHLEzKAakDggLcBtrW1o5+4WMaZOLw8maU5byvjXu3F3i3GdQe8SKTYcVK5OQIDAQAB" ascii wide
		$pk8 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAugqZ4ATE9+9FqununW/DBvGosnUX/bNxQzMYUmE14GJIbNa6vwYSNXOlG09mvdAqZqD3lXihWDjy25+gzqSeS+Fs2qNyTdfGPA8iu2xx5RRUXKLGFThxtIzg3fohAK3+LxJVhxtuITAT38IHacc7dVLHsrddu4UDjiHGFdvXjB55Nwe5cu1BYylHsARMYycBA2FwLP57cKvc2/C3OXBAF6qbsVXBcyFhrKOOYA/+5IjFfEhgHy2FLHRf8lmPQPbSlrM6dk+W4D5KVqOPx/eFp0geUJJlmlre3flI29qWS20bkGqAEz9j07y69HGYN9Nt7+DRgBwrpNo/EkZkuaSTtQIDAQAB" ascii wide
		$pk9 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuuAQlnowSGaSi2XgnwaHQAFZ6e7C0SwpAyyLTncJ4l5cwFbM+mwnV+iV3a+ert8WqOmW1aKOCjTPXrXNoirQgboVpLfhIIT1uOOss4O8lodRxgB6QrLCI7PYMZ+8VgIdEPPzsjmTFLxFc7DERxnSjhGdRQIjZNjm7bGScJD0MayDL9KTkVdJtC+C9n5dwEwg6XtQbwLDeaGZaByOgB/zR6tlcPQCNU9rj1qfcVrI/dFW4br/NnJbqrH714z+dvCa18IJTcu3kW74CAilvHrl5qFDd8CCQhjLrjQDPxAoCba9aXKr6dwt34/MU0tVRTYjzMAxR4yTh3oEjVT+HifvVwIDAQAB" ascii wide
		$pk10 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwcPjnPl8bI1A0iudX70FKkTjnLjHyetHN2kAIcyOG10K8vm67n/Ma9mAnoDggD3D6UtAbwjvHwPW1m9WF+MrnBXmBizE0JpwOLtVFcHeVLJXlYn/C5RNZziTCwjauH6TlT7Mo/oHfg7nX4IXEuaeAZz8g9ioeJ1Lydi9ZZM1gmdNk8KuKR0zrrJ6MMAGrhMtblLFVwtMn7IlNjT/BgSL4pDyNa++wI5P4R2rMykJwGu/7o2kKE2IFimtFDyZ5a+CX46cdKt7uo5eKFiqf/jTes9/y5AgoS69mt4fRvWFhP7qHXRO2gG8XAc+9suhiuVUWZTAu3xXz5VsmBtk8pzcpwIDAQAB" ascii wide
		$pk11 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwMQXFMtYf60KrbUVwNVoPhhrCTNMY3Zv+/WULZRZfJ4dMhYozDxtRVdtBDKtuYuHCGLu/Ymf9wKFFXgVH3En7qI1sU2UdjNR4086X8oSTMUn/GwEAEIZAHtSFuk6AXcXW+eO0yxPF+lt5AZcNnJocWBVZ8RWGvsQdtGgtZalttAynROC4RUGkvD1h1ssMteHWneFLpfzSPGlbu0s0cemsrTPmhexGIenup/YjNdmhbfvvYE9kZfPebGtZHw6oQXWcG7sAlvkGciJl3Eo9FznNj0K+v8WQW5L/UbosZaYVJbxlbtySvqUqZbkLKsmp91tr9bvTiDMZuXZS7iHVqchUQIDAQAB" ascii wide
		$pk12 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxbKVxwYe4PpnPm0XtuqShDqFWCFRBw0tYo2vmLwVPlwa+0+ox8+nF0mzWC3ZZT2XkGSodszosOoocfKAwOjQnA+4/Hokl4hgG6K8O7wWuWlvgo4fkcZShy2cMY9FaC6e4bMfurlDFt7OVrKKWAyEGv49Etq6LNoyl5ddM/XmspG52gscRoIcOTwBL4bD8nVcamZXqE4j2mS62HicQ6q9YgRVs1PLbgVPbg8c2rFzpN1e8wZdPtvyGON0m3CmxsYa63yianbnBAS4WnxEnoI7eCZZNkblr+kZB4J9War5VYHu9lFw4XWeuHget/Rn8oGCJOMHkZMz23NpUVaX9htQAwIDAQAB" ascii wide
		$url1 = "://zujgzbu5y64xbmvc42addp4lxkoosb4tslf5mehnh7pvqjpwxn5gokyd.onion" ascii wide
		$url2 = "://alphvmmm27o3abo3r2mlmjrpdmzle3rykajqc5xsj7j7ejksbpsa36ad.onion" ascii wide
		$url3 = "://2cuqgeerjdba2rhdiviezodpu3lc4qz2sjf4qin6f7std2evleqlzjid.onion" ascii wide
		$url4 = "://aoczppoxmfqqthtwlwi4fmzlrv6aor3isn6ffaiic55wrfumxslx3vyd.onion" ascii wide
		$url5 = "://b4twqa2mvob3s6uvuyfra5xk3qgps2v5kkt7k2qnb7rpdu3j4fkntead.onion" ascii wide
		$url6 = "://b6v4ojs7jfvftvcoagjxp7qz33yeljydqy6afzsh26vqbzcjwz4b3zad.onion" ascii wide
		$url7 = "://htnpafzbvddr2llstwbjouupddflqm7y7cr7tcchbeo6rmxpqoxcbqqd.onion" ascii wide
		$url8 = "://id7seexjn4bojn5rvo4lwcjgufjz7gkisaidckaux3uvjc7l7xrsiqad.onion" ascii wide
		$url9 = "://mu75ltv3lxd24dbyu6gtvmnwybecigs5auki7fces437xvvflzva2nqd.onion" ascii wide
		$url10 = "://odf3dt34tkqndw5h2l5gt2gwwd3jct5rwwjusbd3vlin2jueyv2qkgid.onion" ascii wide
		$url11 = "://rfosusl6qdm4zhoqbqnjxaloprld2qz35u77h4aap46rhwkouejsooqd.onion" ascii wide
		$url12 = "://sty5r4hhb5oihbq2mwevrofdiqbgesi66rvxr5sr573xgvtuvr4cs5yd.onion" ascii wide
		$url13 = "://xqoykemmcivwtpxh3a6pu3w7sstr2y7hapxdiv4caaxidurmwwbjx2id.onion" ascii wide
		$url14 = "://y4722ss64vel5hmph75te7lx2x5xz463322ypjirm5ytxviijtdpybid.onion" ascii wide

	condition:
		(1 of ( $pk* ) and 1 of ( $url* ) )
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Koxic
{
	meta:
		description = "Detects files referencing identities associated with LokiLocker ransomware"
		author = "ditekShen"
		id = "4c4ff722-cac1-5967-9e79-681f47566e96"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L571-L580"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ca4d0e85cf4c7a134609262e21d5cef98100ba0a046d17ffe51bf3975dc7cae9"
		score = 75
		quality = 73
		tags = ""

	strings:
		$s1 = "wilhelmkox@tutanota.com" ascii wide nocase
		$s2 = "F3C777D22A0686055A3558917315676D607026B680DA5C8D3D4D887017A2A844F546AE59F59F" ascii wide

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Ryuk
{
	meta:
		description = "Detects files referencing identities associated with Ryuk ransomware"
		author = "ditekShen"
		id = "00cf99da-ff3c-5c91-8966-69a8afc8613a"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L582-L592"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a2b6106fc49dd254ca936e285fa0c2a3aee7110832686638d20d369d77f6c48f"
		score = 75
		quality = 71
		tags = ""

	strings:
		$s1 = "WayneEvenson@protonmail.com" ascii wide nocase
		$s2 = "WayneEvenson@tutanota.com" ascii wide nocase
		$s3 = "14hVKm7Ft2rxDBFTNkkRC3kGstMGp2A4hk" ascii wide

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Lockdown
{
	meta:
		description = "Detects files referencing identities associated with LockDown / cantopen ransomware"
		author = "ditekShen"
		id = "603f0113-d77b-590c-b2a0-804c6d1fbfbc"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L594-L603"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "cb17bb92d6e8189a08508481b75d301a1227906815c684753859914d77d7b3e7"
		score = 75
		quality = 73
		tags = ""

	strings:
		$s1 = "CCWhite@onionmail.org" ascii wide nocase
		$s2 = "bc1q6ug0vrxz66d564qznclu9yyyvn6zurskezmt64" ascii wide

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Powershellcookiestealer
{
	meta:
		description = "Detects email accounts used for exfiltration observed in PowerShellCookieStealer"
		author = "ditekShen"
		id = "c2bbb9a8-3e4c-5676-9676-2708a196ef8d"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L706-L715"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "bd404e94939acb92dd56a7d2a1f7536bcb3f520ca1e9dc614b53828afbc6dac8"
		score = 75
		quality = 71
		tags = ""

	strings:
		$s1 = "senmn0w@gmail.com" ascii wide nocase
		$s2 = "mohamed.trabelsi.ena2@gmail.com" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_Gobuildid_Zebrocy : FILE
{
	meta:
		description = "Detects Golang Build IDs in known bad samples"
		author = "ditekSHen"
		id = "fc805e9d-47a0-5fcb-9b21-4806c13ab7b4"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L1541-L1550"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "16b88460896012b42ca576995f5de98a7a9d2fcc53f8e148427bca31a883d19b"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Go build ID: \"l6RAKXh3Wg1yzn63nita/b2_Y0DGY05NFWuZ_4gUT/H91sCRktnyyYVzECfvvA/l8f-yII0L_miSjIe-VQu\"" ascii
		$s2 = "Go build ID: \"fiGGvLVFcvIhuJsSaail/jLt9TEPQiusg7IpRkp4H/hlcoXZIfsl1D4521LqEL/yL8dN86mCNc39WqQTgGn\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 8000KB and 1 of them
}
rule DITEKSHEN_INDICATOR_KB_Gobuildid_Gostealer : FILE
{
	meta:
		description = "Detects Golang Build IDs in known bad samples"
		author = "ditekSHen"
		id = "25c0eb8b-c69c-5f50-b622-daaa3c8c62a4"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L1552-L1562"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d548bc2580c8e8233a5fcdf85b947547c10f2c4d0056d14e990f30dd7b9a0672"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Go build ID: \"xQV-b1Fr7d576TTTpbXi/gq4FgVQqMcg--9tmY13y/76rKNEUBENlDFDcecmm_/mbw17A_6WrROaNCYDEQF\"" ascii
		$s2 = "Go build ID: \"x4VqrSSsx8iysxVdfB-z/gIF3p7SUxiZsVgTuq7bN/93XHuILGnGYq2L83fRpj/eoY6nTqwk1sdMHTaXzlw\"" ascii
		$s3 = "Go build ID: \"BPRThIYWbHcZQQ4K1y2t/2mO0-FjLC50P0QZuMTgC/9i6TYw_akiEF9ZPN0s3p/s1XoqXr7EyXMDVw5TTP3\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 8000KB and 1 of them
}
rule DITEKSHEN_INDICATOR_KB_Gobuildid_Goldenaxe : FILE
{
	meta:
		description = "Detects Golang Build IDs in known bad samples"
		author = "ditekSHen"
		id = "e734d5b4-2332-5b46-a05e-fb35134ea070"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L1564-L1573"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4ab9aeaa74530de4a62ddfa8d7e8607e455d0ba4330260037327bec6d8d7abab"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Go build ID: \"BrJuyMRdiZ7pC9Cah0is/rbDB__hXWimivbSGiCLi/B35SPLQwHal3ccR2gXNx/hEmVzhJWWatsrKwnENh_\"" ascii
		$s2 = "Go build ID: \"5bgieaBe9PcZCZf23WFp/bCZ0AUHYlqQmX8GJASV6/fGxRLMDDYrTm1jcLMt8j/Wof3n5634bwiwLHFKHTn\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 8000KB and 1 of them
}
rule DITEKSHEN_INDICATOR_KB_Gobuildid_Nemty : FILE
{
	meta:
		description = "Detects Golang Build IDs in known bad samples"
		author = "ditekSHen"
		id = "512fe910-e38c-513c-b678-a0592bdc4ae2"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L1575-L1588"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "246766ab1d2871b5c22323f622d39ce9fa9b46a2d43bace122ed5549484f3aac"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Go build ID: \"R6dvaUktgv2SjVXDoMdo/kKgwagwoLRC88DpIXAmx/eipNq7_PQCTCOhZ6Q74q/RHJkCaNdTbd6qgYiA-EC\"" ascii
		$s2 = "Go build ID: \"vsdndTwlj03gbEoDu06S/anJkXGh7N08537M0RMms/VG58d99axcdeD_z1JIko/tfDVbCdWUId-VX90kuT7\"" ascii
		$s3 = "Go build ID: \"FG9JEesXBQ04oNCv2bIS/MmjCdGa3ogU_6DIz6bZR/AjrqKBSezDfY1t7U9xr-/-06dIpZsukiVcN0PtOCb\"" ascii
		$s4 = "Go build ID: \"MJ8bS1emWrrlXiE_C61E/A6GaZzhLls_pFKMGfU1H/ZgswGQy_lzK-I4cZykwm/8JzjhV06jZosSa5Qih5O\"" ascii
		$s5 = "Go build ID: \"_vQalVQKn2O8kxxA4vVM/slXlklhnjEF5tawjlPzW/t26rDRURK6ii0MqU7gIx/MNq6vj_uM15RhjVC2QuX\"" ascii
		$s6 = "Go build ID: \"KWssFDTp6mq16xlI5c0t/mQLgof0oyp-eYKqNYUFL/Np8S71zE5W5_BsJCpjsj/hXpFDaVCtay2509R05fd\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 1 of them
}
rule DITEKSHEN_INDICATOR_KB_Gobuildid_Qnapcrypt : FILE
{
	meta:
		description = "Detects Golang Build IDs in known bad samples"
		author = "ditekSHen"
		id = "4cdea15f-d8fd-5720-ba25-eb60e9b0f9ce"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L1590-L1598"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b3ee583c395701350c091041a72f988d1b5ae607b642b42152fcda29f9be63e2"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Go build ID: \"XcBqbQohm7UevdYNABvs/2RcJz1616naXSRu2xvTX/b6F3Jt1-5WAIexSyzeun/MpHqs5fJA5G2D9gVuUCe\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 8000KB and 1 of them
}
rule DITEKSHEN_INDICATOR_KB_Gobuildid_Snatch : FILE
{
	meta:
		description = "Detects Golang Build IDs in known bad samples"
		author = "ditekSHen"
		id = "6ab6b7bc-c905-5ff9-8059-a2d512ba13b3"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L1600-L1610"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5a19c791ed0d829c4c97e35cfa604a8716bad3f02632712903d765db95ba87f6"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Go build ID: \"8C2VvDTH-MuUPx8tL42E/PWF9iuE2j_Zt0ANsTlty/c64swZ5TtuaIpHuEFmga/6sS0KWNryc-YAduDnWWO\"" ascii
		$s2 = "Go build ID: \"UBrfJ_wztDfCHWakqvlV/LhzfkJwvKFrNhKCHtU9_/sveCupt8GVbvu6WZiyA-/GcimfL_TPl6FTPPriBDr\"" ascii
		$s3 = "Go build ID: \"5zCy9jt7UZaIs5YPk4tt/1Yt6v7gCpDG---pRFyW-/7729nLSeKJik31ftz_Ve/Z5EVG3lWak3ynxNrJ4ih\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 1 of them
}
rule DITEKSHEN_INDICATOR_KB_Gobuildid_Godownloader : FILE
{
	meta:
		description = "Detects Golang Build IDs in known bad samples"
		author = "ditekSHen"
		id = "da53c062-4a55-543d-b2b6-52acdf13febc"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L1612-L1622"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e0f5ee6ade4608a8b5c5bd02bf5aef0fcb9cb1fe1cc3a9d00b1ace91e5d0d33f"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Go build ID: \"1OzJqWaH4h1VtrLP-zk8/G9w32ha7_ziW1Fa-0Byj/gLtfhbXZ6i_W0e5e_tFF/ekG0n9hOcZjmwzRQnRqC\"" ascii
		$s2 = "Go build ID: \"kKxyj14l4NhGbuhOgzef/ab_yr_pUn6q2idYdoBhn/hFAjO_Yxc_rN6mHFuHM9/SmS3qmOyJBc_4xV_qg3B\"" ascii
		$s3 = "Go build ID: \"MiW7XJnQsBXxlBHro8GW/HMqQknRgJg-mCXomgFRt/88ccKMrfA_s6AcOJs3aM/jSUAU_l3RrMzlV6ANEYE\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 1 of them
}
rule DITEKSHEN_INDICATOR_KB_Gobuildid_Ranumbot : FILE
{
	meta:
		description = "Detects Golang Build IDs in known bad samples"
		author = "ditekSHen"
		id = "f368cd9d-f974-56cf-a2b5-bd300f30cedc"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L1624-L1633"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c3d0ba55ca2be1b11ebf1b82490c5d26f2b35958b31a7e55892e27f24bf4118f"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Go build ID: \"hOhuOA4W60aBBRoFQTDA/dl9DuLAgEcabYGK6ZT2t/ECsse3630jV_957OqqK3/ZRA_JRPFzxutK16zlEcM\"" ascii
		$s2 = "Go build ID: \"NivDrAudWE-E6xtBXeww/3pv6fDzDqt4v0YxoTkPt/8vd79TNE-9Bt38ftxf_V/_GNqnqEUsRf-WTSmn8dM\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 1 of them
}
rule DITEKSHEN_INDICATOR_KB_Gobuildid_Banload : FILE
{
	meta:
		description = "Detects Golang Build IDs in known bad samples"
		author = "ditekSHen"
		id = "5955afd5-f26f-5df1-b355-b8f168b694b0"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L1635-L1643"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "534de1ce161e5e27f380f96b83630aa75031f268658aa7e8ff8ecce82ed5d4cd"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Go build ID: \"a3629ee6ab610a57f242f59a3dd5e5f6de73da40\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 1 of them
}
rule DITEKSHEN_INDICATOR_KB_Gobuildid_Hive : FILE
{
	meta:
		description = "Detects Golang Build IDs in Hive ransomware"
		author = "ditekSHen"
		id = "7d7f7757-de7b-52a7-aab0-8fda38a86fd1"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L1645-L1653"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f311a3661ea3a26ebca6cd283d1e219011acfdfbb13fa8b919ca2724b9f4aae7"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Go build ID: \"XDub7DGmWVQ2COC6W4If/XHMqRPf2lnJUiVkG1CR6/u_MaUU0go2UUmLb_INuv/WrZSyz-WMW1st_NaM935\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 1 of them
}
rule DITEKSHEN_INDICATOR_KB_Gobuildid_Nodachi : FILE
{
	meta:
		description = "Detects Golang Build IDs in Nodachi"
		author = "ditekSHen"
		id = "9d578768-7995-5fb0-8bf1-9c2221cdef80"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L1655-L1666"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "177269623e0f3850c37c6b203d9a637fa92c0ed3fa823cc8d885f28cb383bf7d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Go build ID: \"3AAyhKK0wFfCYLdz5oRV/zKyiBHCsAEyDIWhaW5AW/Rb8NLT3q8A2OLm6izDGP/8G9k_gjOTX_PXKna_IMj\"" ascii
		$s2 = "Go build ID: \"-eyFd8kbpwxUsutpqZn_/vqzQXX5Ra4qk1XHoqocW/wd-6gLzQKZyEyhVp7qOj/Jr14hyc7pLLgeIZNbfLD\"" ascii
		$s3 = "Go build ID: \"xDSqp4KGmd0SAf5irMGh/-kA7PGjKoJcvCgsZDStn/lHeQ1LQOVyQB2NnwIwFP/-D5oEBc23ND7IGLTESdM\"" ascii
		$s4 = "Go build ID: \"67RcwNspLH__QJrElMcB/zMJf7Go1s0ZoXqd30Lb_/NaJl4rfcuLEG5LeZ-Y4k/MzFNvW79enRRdx3LmA47\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 1 of them
}
rule DITEKSHEN_INDICATOR_KB_Gobuildid_Gobrut : FILE
{
	meta:
		description = "Detects Golang Build IDs in GoBrut"
		author = "ditekSHen"
		id = "65953012-fc84-50d0-b769-64df66d8a54b"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L1668-L1676"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "40c305f019cb31222fa75a24315764cb5e5356afaa72aefb59916d615a8fca28"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Go build ID: \"sf_2_ylcjquGBe4mQ99L/aPvdLbM2z9HfoDN3RazG/8bhYeVA67N-ifbDYCDJe/UZzCu_EFL9f10gSfO4L0\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 1 of them
}
rule DITEKSHEN_INDICATOR_KB_Gobuildid_Biopassdropper : FILE
{
	meta:
		description = "Detects Golang Build IDs in BioPass dropper"
		author = "ditekSHen"
		id = "b82d34d9-7774-5f99-9d76-b5426e015981"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L1678-L1686"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "3b586e886b9f901dde1c73aa07ce0d45e4ff417459f298094359ec1c1e02e522"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Go build ID: \"OS0VlkdEIlcl3WDDr9Za/_oVwEipaaX6V4mEEYg2V/PytlyeIYgV65maz4wT2Y/IQvgbHv3bbLV42i10qq2\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 1 of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Rhysida
{
	meta:
		description = "Detects files referencing identities associated with Rhysida ransomware"
		author = "ditekShen"
		id = "7ee0fb41-9267-5b65-ada3-229f2e390da6"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L1688-L1697"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e3e07bab2982a30a5372e6708ede6707d132d410aa5b5b1a29bdb5d06910a88e"
		score = 75
		quality = 71
		tags = ""

	strings:
		$s1 = "SethZemlak@onionmail.org" ascii wide nocase
		$s2 = "JacquieKunze@onionmail.org" ascii wide nocase

	condition:
		any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Ransomware_Payola
{
	meta:
		description = "Detects files referencing identities associated with Payola ransomware"
		author = "ditekShen"
		id = "7c1fc06b-fc71-5679-befd-686b2e05e3a4"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L1699-L1708"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "568141c03d14faef0cfc4f5fbdec45a5109a1ad5cbbe99e76a1db86e7ef4dc5d"
		score = 75
		quality = 71
		tags = ""

	strings:
		$s1 = "pcsupport@skiff.com" ascii wide nocase
		$s2 = "pctalk01@tutanota.com" ascii wide nocase

	condition:
		any of them
}
/*
 * YARA Rule Set
 * Repository Name: WithSecureLabs
 * Repository: https://github.com/WithSecureLabs/iocs
 * Retrieval Date: 2026-11-15
 * Git Commit: 1a8384468dd292c6d2c5114c32e42dc0da1f5ae1
 * Number of Rules: 24
 * Skipped: 0 (age), 3 (quality), 0 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * BSD 2-Clause License

Copyright (c) [2022], [WithSecure Oyj]

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
rule WITHSECURELABS_DAYLIGHT
{
	meta:
		description = "Detects common strings found across samples obfuscated with DAYLIGHT"
		author = "WithSecure"
		id = "bbd4aad0-a156-5692-9b4a-ebdb5143a2bf"
		date = "2026-05-28"
		modified = "2026-05-28"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/GREYVIBE/greyvibe.yara#L1-L11"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "bc16cbe538d2d4bba7ec3332b525d79e74ab9dec8f545e5f12720e185b24d3dd"
		score = 75
		quality = 73
		tags = ""

	strings:
		$a = "$encryptedstream, $keystream" nocase ascii wide
		$b = "Daylight savings time is active" ascii wide

	condition:
		any of them
}
rule WITHSECURELABS_TEASOUP
{
	meta:
		description = "Detects common strings found across samples obfuscated with TEASOUP"
		author = "WithSecure"
		id = "b983f58c-7d53-51d4-b574-1feb8719c2ac"
		date = "2026-05-28"
		modified = "2026-05-28"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/GREYVIBE/greyvibe.yara#L13-L24"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "357e3d23dac84db54b65ff1727e89eb1dab6e0d06461ebd8368d265c3d1f88bd"
		score = 75
		quality = 75
		tags = ""

	strings:
		$a = "s += String.fromCharCode(charCode)" ascii wide
		$b = "var ts = arr[i]" ascii wide
		$c = "System Maintenance Script" ascii wide

	condition:
		2 of ( $* )
}
rule WITHSECURELABS_LOOKVALPS
{
	meta:
		description = "Detects common strings found across samples obfuscated with LOOKVALPS"
		author = "WithSecure"
		id = "9dec92aa-123c-5c32-beb6-308b8c936ca4"
		date = "2026-05-28"
		modified = "2026-05-28"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/GREYVIBE/greyvibe.yara#L26-L36"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "ef694f6fee59578d9ccd909ca506771ec5cda94a64232895558cc141a09cf6e3"
		score = 75
		quality = 75
		tags = ""

	strings:
		$a = "currentValue = $LookupTable" ascii wide
		$b = "foreach($b in $data){$d+=[char]($b -bxor $key)}" ascii wide

	condition:
		any of them
}
rule WITHSECURELABS_LOOKVALJS
{
	meta:
		description = "Detects a common string found across samples obfuscated with LOOKVALJS"
		author = "WithSecure"
		id = "35168369-c940-51ed-b1e2-a29c68bf4fec"
		date = "2026-05-28"
		modified = "2026-05-28"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/GREYVIBE/greyvibe.yara#L38-L47"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "4714815c64a6ba989d4d7554d3ac39702d067fd7299460a6db80dbd3e4b3abff"
		score = 75
		quality = 75
		tags = ""

	strings:
		$a = "currentValue = lookupTable" ascii wide

	condition:
		all of them
}
rule WITHSECURELABS_GREYVIBE_JSLOADER_1
{
	meta:
		description = "Detects common strings found across one of GREYVIBE's loaders (observed across PrincessClub and PhantomMail campaigns)"
		author = "WithSecure"
		id = "f6cb348d-7d82-5514-9059-3679aa979aee"
		date = "2026-05-28"
		modified = "2026-05-28"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/GREYVIBE/greyvibe.yara#L49-L59"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "e00567601c35f15985e97cb37b272ecf6fbf928b78c192123f418810b0061a8e"
		score = 75
		quality = 75
		tags = ""

	strings:
		$a = "wmizzzz"
		$b = "runzzzz"

	condition:
		all of them
}
rule WITHSECURELABS_GREYVIBE_JSLOADER_2
{
	meta:
		description = "Detects common strings found across one of GREYVIBE's loaders (observed in PhantomMail campaign)"
		author = "WithSecure"
		id = "9901d2df-6539-51c6-a24d-c06a7e898a6a"
		date = "2026-05-28"
		modified = "2026-05-28"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/GREYVIBE/greyvibe.yara#L61-L73"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "c6fc0969bb62de731e9770447df565e427b03c69851708a0a30a4da20f176236"
		score = 75
		quality = 75
		tags = ""

	strings:
		$a = "// String Reconstruction"
		$b = "Math.cos"
		$c = "Math.sin"
		$d = ".join(\"\")"

	condition:
		all of them
}
rule WITHSECURELABS_Phantomrelay_Fingerprint
{
	meta:
		description = "Detects PhantomRelay's fingerprinting script"
		author = "WithSecure"
		id = "b7191fdf-f270-5949-bb54-a5dea2a6e2a0"
		date = "2026-05-28"
		modified = "2026-05-28"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/GREYVIBE/greyvibe.yara#L75-L89"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "88e2cf9106731fe9e7e76ed00a09e81828029e68e0e40ca58c8efad93e9e16b5"
		score = 75
		quality = 75
		tags = ""
		target_entity = "file"

	strings:
		$a1 = "$env:COMPUTERNAME"
		$a2 = "$env:USERNAME"
		$a3 = "$PID"
		$a4 = "Win32_Computer"
		$user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/534.36 (KHTML, like Gecko) Chrome/95.4.4476.124 Safari/537.36"

	condition:
		all of them
}
rule WITHSECURELABS_GREYVIBE_Phantomrelay_Watchdog : FILE
{
	meta:
		description = "Detects GREYVIBE's watchdog script for PhantomRelay"
		author = "WithSecure"
		id = "c59eef2e-22c8-5df2-aa81-111cce4d20c8"
		date = "2026-05-28"
		modified = "2026-05-28"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/GREYVIBE/greyvibe.yara#L91-L103"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "19d5fdaf2e2c98637971427761e316fd405a0f6d8e7f539dc9f72d20313ba43c"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$a1 = "--headless"
		$a2 = "/watchdog"
		$a3 = "Register-ScheduledTask"
		$a4 = "DownloadFile"

	condition:
		filesize < 50KB and all of them
}
rule WITHSECURELABS_Legionrelay_Client
{
	meta:
		description = "Detects LegionRelay client script"
		author = "WithSecure"
		id = "ec6b7aae-414d-5e54-9fc0-6826c7e9e1b8"
		date = "2026-05-28"
		modified = "2026-05-28"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/GREYVIBE/greyvibe.yara#L105-L119"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "ba3fff2de891e880884434150f7a6331356a234ad0b2bc572e158a9b7ac03c0c"
		score = 75
		quality = 75
		tags = ""

	strings:
		$a1 = "powershell_ise"
		$a2 = "pwsh"
		$a3 = "/status"
		$a4 = "/commands?client_id="
		$a5 = "[^\\w\\-]"
		$a6 = "client_config.json"

	condition:
		all of them
}
rule WITHSECURELABS_Fallspy
{
	meta:
		description = "Detects FallSpy Android malware"
		author = "WithSecure"
		id = "8d0823be-3a64-5e2d-995c-0b2fccf77a98"
		date = "2026-05-28"
		modified = "2026-05-28"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/GREYVIBE/greyvibe.yara#L121-L139"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "29575182e5399930764cdc33d1a62d020618ad630a01d4f503a38a241069fe4d"
		score = 75
		quality = 75
		tags = ""

	strings:
		$a = "DataCollectorWork" fullword
		$b = "UpdateChecker" fullword
		$c = "/check_update?version="
		$e = "&call_logs=" fullword
		$f = "&sim_numbers=" fullword
		$g = "&wifi_ssid=" fullword
		$h = "Public IP: " fullword
		$i = "uploaded_hashes" fullword
		$n = "Android ID: " fullword
		$o = "Call Logs: " fullword

	condition:
		4 of them
}
rule WITHSECURELABS_Phantomrelay_Client : FILE
{
	meta:
		description = "Detects PhantomRelay client script"
		author = "WithSecure"
		id = "d65c65a3-beab-51cd-8700-1204ce40791e"
		date = "2026-05-28"
		modified = "2026-05-28"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/GREYVIBE/greyvibe.yara#L141-L153"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "3d5ad744d1689b71604d55ec75a971f1a1f89c3f030c069a5ea205e4a3e4fac4"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$a = ".idc"
		$b = ".cmd"
		$c = ".psh"
		$d = "WebSockets.ClientWebSocket"

	condition:
		filesize < 100KB and all of them
}
rule WITHSECURELABS_Andariel_Undercrypt
{
	meta:
		description = "Detects UnderCrypt samples based on shared code portions"
		author = "WithSecure"
		id = "840d250f-7ad5-53df-aad9-20d405bf81bf"
		date = "2026-01-22"
		modified = "2026-01-22"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/Andariel2025/andariel.yara#L40-L53"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "38ae107a8eeea3d54c34fa62fb8e8eb133489fc90337920c14319a2e7b51603a"
		score = 75
		quality = 75
		tags = ""

	strings:
		$1 = {C0746F4C8BDE498D1C024D2B5D304C3BD3735FBF00F0000041BE00A0000041833A00744E458B42044D8D4A084983E80849D1E84585C0742E90410FB71141FFC8}
		$2 = {00448B461C448B4E244C03C2448B56204C03CA4C03D2F7C50000FFFF752B8B4E100FB7D53BD17213034E143BD1730C0FB7C5418B1C804903DBEB6433C04881C4}
		$6 = {119C4000C04FA30A3E23672FCB3AABD2119C4000C04FA30A3E9EDB32D3B3B925418207A14884F532168D1880928E0E6748B30C7FA83884E8DED2D139BD2FBA6A4889B0B4B0CB466891DC96F605292B6336AD8BC4389CF2A7132205931904000000}
		$7 = {647265488D5424204863403C448BC366C744242C7373885C242E428B8C10880000004903CA448B49208B79244D03CA8B711C4903FA448B59144903F24585DB7441418B01B1474903C23A08750E0FB64A0148FFC248FFC084C975EE0FB608380A741341FFC0488D5424204983C104453BC3}
		$8 = {4C8BD0C745E04765745033D2C745E4726F63418BFA8855EE4863403C448BC2C745E864647265488D55E066C745EC7373428B8C10880000004903CA448B4920448B69244D03CA8B411C4D03EA448B59144903C2488945484585DB744C660F1F440000418B01B1474903C23A08750E0FB64A0148FFC248FF}

	condition:
		any of them
}

rule WITHSECURELABS_Andariel_Undercrypt_Versioninfo
{
	meta:
		description = "Detects UnderCrypt samples based on version info"
		author = "WithSecure"
		id = "03ed3929-12e9-5a8f-bdef-394396679a19"
		date = "2026-01-22"
		modified = "2026-01-22"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/Andariel2025/andariel.yara#L54-L67"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "2d87246f89128a97136c021653211109d44dc9c75be747e58c7d09ebdac092ed"
		score = 75
		quality = 75
		tags = ""

	condition:
		(pe.version_info [ "ProductName" ] == "Microsoft@Windows@OperatingSystem" ) or ( pe.version_info [ "InternalName" ] contains "_crypted." and pe.version_info [ "FileVersion" ] contains "10.0.19041.1" )
}

rule WITHSECURELABS_Andariel_Starshellrat
{
	meta:
		description = "Detects StarshellRAT samples"
		author = "WithSecure"
		id = "ecc377fd-2754-5f6a-a26b-c6c12b9e18c8"
		date = "2026-01-22"
		modified = "2026-01-22"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/Andariel2025/andariel.yara#L68-L85"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "b210ab8790710a8d53a0775550d94e0604dd80c4681a90dcd093ec8ceccc6da5"
		score = 75
		quality = 75
		tags = ""

	strings:
		$str1 = "StarShell" ascii
		$str2 = "ReadRlt" ascii
		$str3 = "SendRlt" ascii
		$str4 = "ProcessShell" ascii
		$str5 = "Screan ok" wide
		$str6 = "<==>" wide
		$str7 = "\\r\\nStarted..." wide
		$str8 = "\\r\\nDownload End." wide
		$str9 = "\\r\\nupload end" wide

	condition:
		pe.is_pe and 3 of them
}

rule WITHSECURELABS_Andariel_Gopherrat
{
	meta:
		description = "Detects GopherRAT samples"
		author = "WithSecure"
		id = "88627e61-43fa-5d5b-94f3-77d540131f90"
		date = "2026-01-22"
		modified = "2026-01-22"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/Andariel2025/andariel.yara#L86-L105"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "2a42590be19b4b9a258c63f683c724165d64cc7bf22e4b7e7dec3ff73ea9175c"
		score = 75
		quality = 75
		tags = ""

	strings:
		$cmdName1 = "GetMACHashID"
		$cmdName2 = "startHeartbeat"
		$cmdName3 = "encodeTo949"
		$cmdName4 = "xorDecrypt"
		$cmdName5 = "StartShell"
		$cmdName6 = "getLogicalDrives"
		$cmdName7 = "sendSocksCommand"
		$xorKey = {357095A221F033AC}

	condition:
		pe.is_pe and ( 3 of ( $cmdName* ) or $xorKey )
}

rule WITHSECURELABS_Andariel_Portscanner_Versioninfo
{
	meta:
		description = "Detects custom port scanner based on file version info"
		author = "WithSecure"
		id = "ffa12319-188e-5050-86b9-6c80575548df"
		date = "2026-01-22"
		modified = "2026-01-22"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/Andariel2025/andariel.yara#L106-L114"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "b7be7cbaeb686c55425695ee324b87c6e01c46c9850cf160025cb5dd8ce7ea1f"
		score = 75
		quality = 75
		tags = ""

	condition:
		pe.version_info[ "InternalName" ] == "PortScan.exe" and pe.version_info [ "ProductName" ] == "Chrome"
}
rule WITHSECURELABS_Andariel_EDR_KILLER_Script
{
	meta:
		description = "Detects strings found in EDR killer batch script"
		author = "WithSecure"
		id = "72228388-7d17-5a61-97ad-eb7f0e701ce4"
		date = "2026-01-22"
		modified = "2026-01-22"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/Andariel2025/andariel.yara#L115-L124"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "c26618981d6fafd81cfbae6ad302e8e742fa6fb97589f26ea811c910904960a6"
		score = 75
		quality = 75
		tags = ""

	strings:
		$a1 = "PageSvc" ascii
		$a2 = "page.sys" ascii

	condition:
		all of them
}
rule WITHSECURELABS_Andariel_Jelusrat_PDB : FILE
{
	meta:
		description = "Detects JelusRAT packer and payload samples via PDB path"
		author = "WithSecure"
		id = "1820e77e-818a-5de5-8483-84ec9448a58f"
		date = "2026-01-22"
		modified = "2026-01-22"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/Andariel2025/andariel.yara#L125-L141"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "a14d808ff783b7c42f3e4600386d578d63c88a0cd7c492cb1a026e0580b551f3"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$str_pdb = /jelus *rat[\x20-\x7F]{0,100}\.pdb\x00/ nocase

	condition:
		filesize <= 16MB and uint16( 0 ) == 0x5A4D and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}

rule WITHSECURELABS_Andariel_Jelusrat_Plugin
{
	meta:
		description = "Detects JelusRAT plugins"
		author = "WithSecure"
		id = "0ac026fa-ce23-5473-ac70-e08d70743b48"
		date = "2026-01-22"
		modified = "2026-01-22"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/Andariel2025/andariel.yara#L142-L152"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "4006238e639232a6f01db518fa666ae23600cbfb19746bddad991ac04011a87b"
		score = 75
		quality = 75
		tags = ""

	condition:
		pe.exports( "testPlugin" ) and pe.exports ( "beginPlugin" ) and pe.exports ( "endPlugin" ) and pe.exports ( "processCommand" )
}
rule WITHSECURELABS_Ducktail_Artifacts : FILE
{
	meta:
		description = "Detects artifacts found in files associated to DUCKTAIL malware"
		author = "WithSecure"
		id = "937c9688-b74f-5e02-838f-ab6757a8d2a1"
		date = "2022-07-18"
		modified = "2022-07-26"
		reference = "https://labs.withsecure.com/publications/ducktail"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/DUCKTAIL/ducktail_artifacts.yar#L1-L20"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		hash = "3dbd9e1c3d0fd6358d4adcba04fdfc0b6e8acc49"
		hash = "9370243589327b458486e3f7637779c2a96b4250"
		hash = "b98170b18b906aee771dbd4dbd31e5963a90a50e"
		logic_hash = "1daa5e654058c802826b6a306b5bfc9d0c05c4ee54607e94e618a8d409ce74d9"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1.0"

	strings:
		$pdb_path_1 = /[a-z]\:\\projects\\(viruttest|virot)\\/i nocase ascii
		$pdb_path_2 = /[a-z]\:\\users\\ductai\\/i nocase ascii
		$pdb_path_3 = "\\dataextractor.pdb" nocase ascii
		$email = "ductai2308@gmail.com" wide ascii

	condition:
		uint16( 0 ) == 0x5A4D and any of them
}

rule WITHSECURELABS_Ducktail_Nativeaot : FILE
{
	meta:
		description = "Detects NativeAOT variants of DUCKTAIL malware"
		author = "WithSecure"
		id = "1961d3e1-987b-588b-bfc2-8239797cd049"
		date = "2022-11-17"
		modified = "2022-11-22"
		reference = "https://labs.withsecure.com/publications/ducktail_returns"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/DUCKTAIL/ducktail_nativeaot.yara#L2-L22"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		hash = "b043e4639f89459cae85161e6fbf73b22470979e"
		hash = "073b092bf949c31628ee20f7458067bbb05fda3a"
		hash = "d1f6b5f9718a2fe9eaac0c1a627228d3f3b86f87"
		logic_hash = "976b28ac45e5a13d4ce900b857e6bd3afc82b65b0235791fd698b762287cd60e"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1.0"

	condition:
		uint16( 0 ) == 0x5A4D and filesize > 15MB and ( pe.section_index ( ".managed" ) >= 0 or pe.exports ( "DotNetRuntimeDebugHeader" ) ) and pe.exports ( "SendFile" ) and pe.exports ( "Start" ) and pe.exports ( "Open" )
}
rule WITHSECURELABS_Tanglecrypt : FILE
{
	meta:
		description = "Detects samples packed with TangleCrypt"
		author = "WithSecure"
		id = "d208791a-5edf-5c79-87e2-78ed5023ece7"
		date = "2025-11-25"
		modified = "2025-11-24"
		reference = "https://labs.withsecure.com/publications/tanglecrypt"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/TangleCrypt/TangleCrypt_YARA.yar#L1-L27"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		hash = "2936f5f3ff24f5bb42eace4ad2d64989b19dc6cd75d8f4ee83496ee6bdf169f6"
		hash = "fb3fc93dc627c7dfd8d95c1d66c2cb66caac92783b6d6eb33ac5b91647871ae6"
		logic_hash = "0d980d72e6ddcc9eedc5977bf895f358144f5720c2ca32266854497afad4a382"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1.0"

	strings:
		$str1 = { 43 61 6E 27 74 20 63 61 6C 6C 20 57 69 6E 41 50 49 20 66 75 6E 63 74 69 6F 6E }
		$opc_x64 = { 41 B8 D7 08 00 00 [0-10] ( E8 | FF 15 ) }
		$opc_x86 = { 68 D7 08 00 00 [0-10] ( E8 | FF 15 ) }

	condition:
		uint16( 0 ) == 0x5A4D and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of ( $str* ) and ( #opc_x64 > 50 or #opc_x86 > 50 )
}
rule WITHSECURELABS_Fake_Vpn_Client_Hta
{
	meta:
		description = "Detects HTA files masqeurading as fake VPN clients"
		author = "WithSecure"
		id = "8c8da6db-edde-5a34-8fe8-7ad7887e7078"
		date = "2026-08-26"
		modified = "2026-08-26"
		reference = "https://github.com/WithSecureLabs/iocs"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/Initial_Access_SEO_Poisoning/fake_vpn_client_hta.yara#L1-L12"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		logic_hash = "1dfcaabcd99b0ca271e27d4302f1287f0a59619ef9996f078c867e4f442be8c7"
		score = 75
		quality = 75
		tags = ""
		target_entity = "file"

	strings:
		$a = "yes-hta-2025"
		$b = "X-From-HTA"

	condition:
		any of them
}

rule WITHSECURELABS_SILKLOADER
{
	meta:
		description = "Detects SILKLOADER samples"
		author = "WithSecure"
		id = "bb8a543e-fdbf-5be1-901e-3e2a9965fd62"
		date = "2023-03-15"
		modified = "2023-03-15"
		reference = "https://labs.withsecure.com/publications/silkloader"
		source_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/SILKLOADER/silkloader.yar#L2-L20"
		license_url = "https://github.com/WithSecureLabs/iocs/blob/1a8384468dd292c6d2c5114c32e42dc0da1f5ae1/LICENSE"
		hash = "c83ac6dc96febd49c7c558e8cf85dd8bcb3a84fdc78b3ba72ebf681566dc1865"
		hash = "e4dadabd1cee7215ff6e31e01f6b0dd820851685836592a14f982f2c7972fc25"
		hash = "d77a59e6ba3a8f3c000a8a8955af77d2898f220f7bf3c0968bf0d7c8ac25a5ad"
		logic_hash = "48aa249ea78e5a3bfe9934fd0dfa26b79f9e6cbe1e5b1426b84f8d8a3d77d742"
		score = 75
		quality = 75
		tags = ""
		version = "1.0"

	strings:
		$str1 = {5400520041004e005300460045005200}
		$str2 = {760062006300630073006200}

	condition:
		pe.is_pe and pe.characteristics & pe.DLL and all of them
}
/*
 * YARA Rule Set
 * Repository Name: HarfangLab
 * Repository: https://github.com/HarfangLab/iocs
 * Retrieval Date: 2026-11-15
 * Git Commit: 3e2b674bf2f591ac46301420671ba553de094dea
 * Number of Rules: 38
 * Skipped: 0 (age), 2 (quality), 0 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * NO LICENSE SET
 */
rule HARFANGLAB_Masepie_Campaign_Htmlstarter : FILE
{
	meta:
		description = "Detect Malicious Web page HTML file from CERT-UA#8399"
		author = "HarfangLab"
		id = "0cca485c-7941-5760-8c24-d993dcbf376d"
		date = "2024-01-24"
		modified = "2026-05-18"
		reference = "TRR240101;https://cert.gov.ua/article/6276894"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L1-L16"
		license_url = "N/A"
		hash = "628bc9f4aa71a015ec415d5d7d8cb168359886a231e17ecac2e5664760ee8eba"
		logic_hash = "d131372c6ad01ae77e5630bae0c0a04ce311718eb1bcf423e6575f3b0ecdba5d"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$s1 = "<link rel=\"stylesheet\" href=\"a.css\">" ascii wide fullword
		$s2 = "src=\".\\Capture" ascii wide

	condition:
		filesize > 600 and filesize < 5KB and ( all of them )
}
rule HARFANGLAB_Masepie_Campaign_Webdavlnk : FILE
{
	meta:
		description = "Detect Malicious LNK from CERT-UA#8399"
		author = "HarfangLab"
		id = "de7fd592-e733-52d0-af9b-55adf37eaf74"
		date = "2024-01-24"
		modified = "2026-05-18"
		reference = "TRR240101;https://cert.gov.ua/article/6276894"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L17-L39"
		license_url = "N/A"
		hash = "19d0c55ac466e4188c4370e204808ca0bc02bba480ec641da8190cb8aee92bdc"
		logic_hash = "26075e47b54404c55f4ca5eb757efa2b1711d919de0ffbfbdf6935e2e4dd3f3d"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$a1 = "[system.Diagnostics.Process]::Start('msedge','http" wide nocase fullword
		$a2 = "\\Microsoft\\Edge\\Application\\msedge.exe" wide nocase fullword
		$a3 = "powershell.exe" ascii wide fullword
		$s1 = "win-j5ggokh35ap" ascii fullword
		$s2 = "desktop-q0f4sik" ascii fullword

	condition:
		filesize > 1200 and filesize < 5KB and ( uint16be( 0 ) == 0x4c00 ) and ( ( all of ( $a* ) ) or ( any of ( $s* ) ) )
}
rule HARFANGLAB_Masepie_Campaign_Masepie : FILE
{
	meta:
		description = "Detect MASEPIE from CERT-UA#8399"
		author = "HarfangLab"
		id = "f0a034fa-38d4-5c54-b865-f830f85e245e"
		date = "2024-01-24"
		modified = "2026-05-18"
		reference = "TRR240101;https://cert.gov.ua/article/6276894"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L40-L60"
		license_url = "N/A"
		hash = "18f891a3737bb53cd1ab451e2140654a376a43b2d75f6695f3133d47a41952b6"
		logic_hash = "02da8119267978e63e3ee5ecdefb52285718f8875ec64d320f2752460c05588d"
		score = 75
		quality = 78
		tags = "FILE"
		context = "file"

	strings:
		$t1 = "Try it againg" ascii wide fullword
		$t2 = "{user}{SEPARATOR}{k}" ascii wide fullword
		$t3 = "Error transporting file" ascii wide fullword
		$t4 = "check-ok" ascii wide fullword
		$a1 = ".join(random.SystemRandom().choice(string.ascii_letters + string.digits) for _ in range(16))" ascii wide fullword
		$a2 = "dec_file_mes(mes, key)" ascii wide fullword
		$a3 = "os.popen('whoami').read()" ascii wide fullword

	condition:
		filesize > 2KB and filesize < 15MB and ( 4 of them )
}
rule HARFANGLAB_Masepie_Campaign_Oceanmap : FILE
{
	meta:
		description = "Detect OCEANMAP from CERT-UA#8399"
		author = "HarfangLab"
		id = "7dcbce01-ab91-56ae-8789-e2e25ba1bf8c"
		date = "2024-01-24"
		modified = "2024-01-31"
		reference = "TRR240101;https://cert.gov.ua/article/6276894"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L61-L95"
		license_url = "N/A"
		hash = "24fd571600dcc00bf2bb8577c7e4fd67275f7d19d852b909395bebcbb1274e04"
		logic_hash = "5fe244025f49358b4285e1272489378a46363ae915881dece26691d971aa93f3"
		score = 75
		quality = 78
		tags = "FILE"
		context = "file"

	strings:
		$dotNet = ".NETFramework,Version" ascii fullword
		$a1 = "$ SELECT INBOX.Drafts" wide fullword
		$a2 = "$ SELECT Drafts" wide fullword
		$a3 = "$ UID SEARCH subject \"" wide fullword
		$a4 = "$ APPEND INBOX {" wide fullword
		$a5 = "+FLAGS (\\Deleted)" wide fullword
		$a6 = "$ EXPUNGE" wide fullword
		$a7 = "BODY.PEEK[text]" wide fullword
		$t1 = "change_time" ascii fullword
		$t2 = "ReplaceBytes" ascii fullword
		$t3 = "fcreds" ascii fullword
		$t4 = "screds" ascii fullword
		$t5 = "r_creds" ascii fullword
		$t6 = "comp_id" ascii fullword
		$t7 = "changesecond" wide fullword
		$t8 = "taskkill /F /PID" wide fullword
		$t9 = "cmd.exe" wide fullword

	condition:
		filesize > 8KB and filesize < 100KB and ( uint16be( 0 ) == 0x4D5A ) and $dotNet and ( 3 of ( $a* ) ) and ( 2 of ( $t* ) )
}
rule HARFANGLAB_Gamaredon_Gammadrop : FILE
{
	meta:
		description = "Matches Gamaredon GammaDrop VBScript samples used in late 2025 - mid 2026"
		author = "HarfangLab"
		id = "cd8c645a-7b8b-5d3f-923a-f73af9a102c5"
		date = "2026-05-13"
		modified = "2026-05-18"
		reference = "TRR260501"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L96-L121"
		license_url = "N/A"
		hash = "62818ae5e305b89b9461536dac1b9daf4cebd99d24e417357e27e2ae4582a704"
		logic_hash = "23405d6ec961f7c3d30702fdc414e2ff2f4c856f719e26207b5241def426530a"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$vbs = "On Error Resume Next" ascii
		$a1 = "Function " ascii
		$a2 = "End Function" ascii
		$a3 = ".Run " ascii
		$a4 = "= Eval(" ascii
		$a5 = "randomize" ascii
		$a6 = "CreateObject(" ascii nocase
		$a7 = ", false" ascii
		$b1 = " + \"" ascii

	condition:
		filesize < 600KB and $vbs in ( 0 .. 80 ) and #vbs >= 4 and #a1 >= 2 and #a2 >= 2 and #a3 >= 1 and 5 of ( $a* ) and #b1 > 150
}
rule HARFANGLAB_Gamaredon_Gammaload_HTA : FILE
{
	meta:
		description = "Matches Gamaredon GammaLoad HTA wrapped VBScript samples used in late 2025 - mid 2026"
		author = "HarfangLab"
		id = "b585a530-82ad-51f1-a346-757120a23d14"
		date = "2026-05-13"
		modified = "2026-05-18"
		reference = "TRR260501"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L122-L151"
		license_url = "N/A"
		hash = "69cdde1ec82099a471283de89dd5e17266b1d8dda57d3c1589b7754b009fa2ed"
		logic_hash = "016250fb11909dabf6f3e5580ecaf9aab16f02f8cfea36841d4d591601a607b0"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$hta = "<!DOCTYPE html>" ascii
		$vbs = "on error resume next" ascii nocase
		$a1 = "Function " ascii
		$a2 = "End Function" ascii nocase
		$a3 = "<script type=\"text/vbscript\">" ascii
		$a4 = "=\"ZGltIG" ascii
		$a5 = ".shellexecute " ascii
		$a6 = "%TEMP%" ascii
		$a7 = "\"REG_SZ\"" ascii
		$a8 = "Close" ascii fullword
		$a9 = ".createelement(" ascii
		$a10 = "\"utf-8\"" ascii
		$b1 = " + \"" ascii

	condition:
		filesize < 900KB and $hta and #vbs >= 5 and #a1 >= 3 and #a2 >= 2 and 4 of ( $a* ) and #b1 > 30
}
rule HARFANGLAB_Vbscript_RAR_CVE_2025_8088 : CVE_2025_8088 FILE
{
	meta:
		description = "Matches RAR5 archives exploiting CVE-2025-8088 to drop VBScript into Startup folder, used by Gamaredon in late 2025 - mid 2026"
		author = "HarfangLab"
		id = "2ad8fcfd-a85c-5cdf-87b2-a921d35aada1"
		date = "2026-05-13"
		modified = "2026-05-18"
		reference = "TRR260501"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L152-L187"
		license_url = "N/A"
		hash = "00b8e381046d4e024a97d0402c3fe29f9d7f5114b2a932003d3e089cfdf992c1"
		logic_hash = "41a02b26607b6f662282c592ea2dec2152216903ed7b0427a7f63c977d9a2d64"
		score = 75
		quality = 80
		tags = "CVE-2025-8088, FILE"
		context = "file"

	strings:
		$rar5_magic = { 52 61 72 21 1A 07 01 00 }
		$stm_header = {
            03           // Header Type = Service Header
            23           // Header flags
            [17-20]      // Flags, sizes, extra data
            00           // Windows OS
            03           // Name length = 3
            53 54 4D     // "STM"
            [1-2]        // vint size of stream name
            07           // Data type = Service data
            3A           // Colon ":" starting ADS path
            2E 2E 5C    // "..\\" path traversal start
        }
		$startup_path = "AppData\\Roaming\\Microsoft\\Windows\\" ascii
		$startup_folder = "\\Startup\\" ascii
		$vbs = ".vbs" ascii
		$vbe = ".vbe" ascii

	condition:
		$rar5_magic at 0 and filesize < 700KB and $stm_header and $startup_path and $startup_folder and any of ( $vb* )
}
rule HARFANGLAB_Allasenhamaycampaign_Allasenha
{
	meta:
		description = "Detects AllaSenha banking trojan DLLs."
		author = "HarfangLab"
		id = "787c4e66-2053-5f14-a52e-6b0415700e8c"
		date = "2024-05-28"
		modified = "2026-05-18"
		reference = "TRR240501"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L207-L229"
		license_url = "N/A"
		logic_hash = "affe75ade6c8d9eeba00006f78678a48b1cfc5ffa9f9675fdea6ffd6cb3a02bd"
		score = 75
		quality = 80
		tags = ""
		context = "file,memory"

	strings:
		$a1 = "<|NOSenha|>" wide fullword
		$a2 = "<|SENHA|>QrCode: " wide fullword
		$a3 = "<|SENHA|>Senha 6 : " wide fullword
		$a4 = "<|SENHA|>Snh: " wide fullword
		$a5 = "<|SENHA|>Token: " wide fullword
		$a6 = "<|BB-AMARELO|>" wide fullword
		$a7 = "<|BB-AZUL|>" wide fullword
		$a8 = "<|BB-PROCURADOR|>" wide fullword
		$a9 = "<|ITAU-SNH-CARTAO|>" wide fullword
		$a10 = "<|ITAU-TK-APP|>" wide fullword
		$dga = { 76 00 00 00 B0 04 02 00 FF FF FF FF 01 00 00 00 78 00 00 00 B0 04 02 00 FF FF FF FF 01 00 00 00 7A 00 00 00 B0 04 02 00 FF FF FF FF 01 00 00 00 77 00 00 00 B0 04 02 00 FF FF FF FF 01 00 00 00 6B 00 00 00 B0 04 02 00 FF FF FF FF 01 00 00 00 79 00 00 00 }

	condition:
		$dga and ( 4 of ( $a* ) )
}
rule HARFANGLAB_Trr260101_Sloppymio : FILE
{
	meta:
		description = "Detects SloppyMIO, a C# implant leveraged by an Iranian threat actor in January 2026."
		author = "HarfangLab"
		id = "20448ee1-67ac-58fe-b902-edbca425a3b8"
		date = "2026-01-28"
		modified = "2026-05-18"
		reference = "TRR260101"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L230-L272"
		license_url = "N/A"
		hash = "6d474cf5aeb58a60f2f7c4d47143cc5a11a5c7f17a6b43263723d337231c3d60"
		logic_hash = "2601a9d1f287e55872fa977b42388961d956a45b2c1952786a4e11297ab5f197"
		score = 75
		quality = 78
		tags = "FILE"
		context = "file"

	strings:
		$s1 = "AppVStreamingUXMainOff" fullword
		$s2 = "Process exiting. Restart if allowed." wide fullword
		$s3 = "[ errors in module '" wide fullword
		$s4 = "[Error] Method '' not found in module '" wide fullword
		$s5 = "href=[\"'](.*?/raw/.*?/" wide
		$s6 = "FREE|" wide fullword
		$s7 = "USED|" wide fullword
		$s8 = "GET FAILED:" wide fullword
		$s9 = "PATCH FAILED: " wide fullword
		$s10 = "FILE NOT FOUND IN GIST" wide fullword
		$s11 = "CONTENT FIELD NOT FOUND" wide fullword
		$m1 = "StegoLsb" fullword
		$m2 = "CachedModule" fullword
		$m3 = "SystemEvents_SessionEnding" fullword
		$m4 = "ExecuteCoreLogic" fullword
		$m5 = "BuildInputParams" fullword
		$m6 = "SendAsFileFromMemory" fullword
		$m7 = "SendReplyInParts" fullword
		$m8 = "ExecuteLib" fullword
		$m9 = "ExecuteDirectModule" fullword
		$m10 = "ExecuteModule" fullword
		$m11 = "DownloadModuleCode" fullword
		$m12 = "CompileDirectModuleCode" fullword
		$m13 = "CompileModuleCode" fullword
		$m14 = "GistRawLink" fullword
		$m15 = "GetRemoteConfig" fullword
		$m16 = "GetGistJson" fullword
		$m17 = "UpdateGist" fullword

	condition:
		filesize < 100KB and uint16be( 0 ) == 0x4D5A and ( 6 of ( $s* ) or ( all of ( $m* ) ) )
}
rule HARFANGLAB_Nhas_Reverse_Shell_Unpacked_Large : FILE
{
	meta:
		description = "Matches unpacked NHAS reverse_ssh file samples"
		author = "HarfangLab"
		id = "7d910d10-49a1-5fb5-b5bd-49155413c433"
		date = "2024-09-24"
		modified = "2026-05-18"
		reference = "TRR250201"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L389-L410"
		license_url = "N/A"
		hash = "18556a794f5d47f93d375e257fa94b9fb1088f3021cf79cc955eb4c1813a95da"
		logic_hash = "eedbf91f9ea7607dc68126840da338035b48509c5649a89f490d8cdfb32844b2"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$s1 = "/NHAS/reverse_ssh/cmd/client" ascii
		$s2 = "/handlers.runCommandWithPty" ascii
		$s3 = "/connection.RegisterChannelCallbacks" ascii
		$s4 = "/internal.RemoteForwardRequest" ascii
		$s5 = "github.com/pkg/sftp" ascii
		$s6 = "github.com/creack/pty" ascii
		$s7 = "main.Fork" ascii fullword

	condition:
		filesize > 2MB and filesize < 30MB and ( ( uint32be( 0 ) == 0x7F454C46 ) or ( uint16be( 0 ) == 0x4D5A ) ) and ( 5 of them )
}
rule HARFANGLAB_Nhas_Reverse_Shell_Pe_Inmem_Large
{
	meta:
		description = "Matches packed NHAS reverse_ssh PE samples in-memory during execution"
		author = "HarfangLab"
		id = "f6b38e11-c405-5623-bea3-3a8d96b435af"
		date = "2024-09-24"
		modified = "2026-05-18"
		reference = "TRR250201"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L411-L429"
		license_url = "N/A"
		hash = "7798b45ffc488356f7253805dc9c8d2210552bee39db9082f772185430360574"
		logic_hash = "b9bbbbd93dc39f8c16c7f8275fa73f4c345c3ba8f21da76ae491e89d3a22c473"
		score = 75
		quality = 80
		tags = ""
		context = "memory"

	strings:
		$s1 = "\\rprichard\\proj\\winpty\\src\\agent\\" ascii
		$s2 = "\\Users\\mail\\source\\winpty\\src\\" ascii
		$s3 = "Successfully connnected" ascii
		$s4 = "*main.decFunc" ascii fullword
		$s6 = "keepalive-rssh@golang.org" ascii fullword
		$s7 = ".(*sshFxpSetstatPacket)." ascii

	condition:
		( all of them )
}
rule HARFANGLAB_Nhas_Reverse_Shell_Elf_Inmem_Large
{
	meta:
		description = "Matches packed NHAS reverse_ssh ELF samples in-memory during execution"
		author = "HarfangLab"
		id = "cd6f7b81-b8df-5e2b-9da6-981d1f62c131"
		date = "2024-09-24"
		modified = "2026-05-18"
		reference = "TRR250201"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L430-L447"
		license_url = "N/A"
		hash = "9f97997581f513166aae47b3664ca23c4f4ea90c24916874ff82891e2cd6e01e"
		logic_hash = "54ba4fc366fb6e4a252d51528ede3ec418b369881ad98e9119d1a9650b6a1bab"
		score = 75
		quality = 80
		tags = ""
		context = "memory"

	strings:
		$s1 = "/NHAS/reverse_ssh/cmd/client" ascii
		$s2 = "/handlers.runCommandWithPty" ascii
		$s3 = "/connection.RegisterChannelCallbacks" ascii
		$s4 = "/internal.RemoteForwardRequest" ascii
		$s7 = "main.Fork" ascii fullword

	condition:
		( all of them )
}
rule HARFANGLAB_Trr250801_Csharp_Downloader_Combined : FILE
{
	meta:
		description = "Detects C# downloaders as likely leveraged by UNC1151, and observed between May and July 2025"
		author = "HarfangLab"
		id = "8eb59b6e-281b-5e05-bf1c-c44542816cfc"
		date = "2025-08-08"
		modified = "2026-05-18"
		reference = "TRR250801"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L448-L481"
		license_url = "N/A"
		hash = "559ee2fad8d16ecaa7be398022aa7aa1adbd8f8f882a34d934be9f90f6dcb90b"
		hash = "a2a2f0281eed6ec758130d2f2b2b5d4f578ac90605f7e16a07428316c9f6424e"
		logic_hash = "169ee7f19394402d22235ad85a8f0c9462d6a2472a65d9abf77830519f58f62f"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$dotNet = ".NETFramework,Version=" ascii
		$a1 = "set_SecurityProtocol" ascii fullword
		$a2 = "SecurityProtocolType" ascii fullword
		$a3 = "ManagementObjectSearcher" ascii fullword
		$a4 = "WebClient" ascii fullword
		$a5 = "DownloadString" ascii fullword
		$a6 = "get_Headers" ascii fullword
		$a7 = "StringBuilder" ascii fullword
		$a8 = "kernel32.dll" ascii fullword
		$a9 = "VirtualProtect" ascii fullword
		$a10 = "GetHINSTANCE" ascii fullword
		$a11 = "get_FullyQualifiedName" ascii fullword
		$a12 = "Marshal" ascii fullword
		$a13 = "get_OSVersion" ascii fullword
		$a14 = "get_MachineName" ascii fullword
		$a15 = "CreateDirectory" ascii fullword
		$a16 = "ToBase64String" ascii fullword
		$a17 = { 00 20C03F0000 28 }

	condition:
		filesize < 100KB and filesize > 10KB and ( uint16be( 0 ) == 0x4D5A ) and $dotNet and ( all of ( $a* ) )
}
rule HARFANGLAB_Trr250801_Cpp_Downloader : FILE
{
	meta:
		description = "Detects C++ downloaders as likely leveraged by UNC1151, and observed during May 2025"
		author = "HarfangLab"
		id = "fc83655d-3b08-5e99-a4e6-7cc38e16f8ba"
		date = "2025-08-08"
		modified = "2026-05-18"
		reference = "TRR250801"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L482-L502"
		license_url = "N/A"
		hash = "5fa19aa32776b6ab45a99a851746fbe189f7a668daf82f3965225c1a2f8b9d36"
		logic_hash = "c3e7f4a8b18d941a782056e76a576d90e83dbb28cdf7d5d316b58edf316be2c7"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$u = { 00 60 be 00 ?? ?? 00 8d be 00 ?? ?? ff 57 83 cd ff eb 10 90 90 90 90 90 90 8a 06 46 88 07 47 01 db 75 07 8b 1e 83 ee fc 11 db }
		$s0 = "RTW0" fullword
		$s1 = "RTW1" fullword
		$s2 = "RTW2" fullword
		$e = "Start" fullword

	condition:
		filesize < 1MB and filesize > 10KB and ( uint16be( 0 ) == 0x4D5A ) and $u and ( 2 of ( $s* ) ) and $e
}
rule HARFANGLAB_Charmingkitten_Cyclops : FILE
{
	meta:
		description = "Detects Cyclops Golang Malware"
		author = "HarfangLab"
		id = "2cc7b2ff-25ca-5eac-a607-c3ee5136e0aa"
		date = "2024-08-05"
		modified = "2026-05-18"
		reference = "TRR240801"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L503-L523"
		license_url = "N/A"
		hash = "fafa68e626f1b789261c4dd7fae692756cf71881c7273260af26ca051a094a69"
		logic_hash = "70ab3f44b6889d478a94dc6aefcd30f0e82e0b80bcf26921167b72f35bdb7fa8"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$go = " Go build ID: \"" ascii
		$a1 = "dep\tback-service\t(devel)" ascii fullword
		$a2 = "/brain-loader-enc.go\x00" ascii
		$a3 = "back-service/go-mux/api" ascii
		$a4 = "/JD-M42KItJncJfqb38qh/" ascii

	condition:
		filesize > 2MB and filesize < 20MB and ( uint16( 0 ) == 0x5A4D ) and $go and ( 2 of ( $a* ) )
}
rule HARFANGLAB_Samecoin_Campaign_Loader : FILE
{
	meta:
		description = "Matches the loader used in the SameCoin campaign"
		author = "HarfangLab"
		id = "ab4d59f6-300d-5cdf-b91f-87f8cc1f0eac"
		date = "2024-02-13"
		modified = "2026-05-18"
		reference = "TRR240201"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L524-L544"
		license_url = "N/A"
		hash = "cff976d15ba6c14c501150c63b69e6c06971c07f8fa048a9974ecf68ab88a5b6"
		logic_hash = "7df04ab208d2caa5a137b1c3481ef734df54bbe8330979f524b16e9ba8cf48d5"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$hebrew_layout = "0000040d" fullword ascii
		$runas = "runas" fullword ascii
		$jpg_magic = { FF D8 FF E0 00 10 4A 46 49 46 00 01 }
		$wl_1 = "C:\\Users\\Public\\Microsoft Connection Agent.jpg" ascii
		$wl_2 = "C:\\Users\\Public\\Video.mp4" ascii
		$wl_3 = "C:\\Users\\Public\\Microsoft System Agent.exe" ascii
		$wl_4 = "C:\\Users\\Public\\Microsoft System Manager.exe" ascii
		$wl_5 = "C:\\Users\\Public\\Windows Defender Agent.exe"

	condition:
		uint16( 0 ) == 0x5A4D and filesize > 5MB and filesize < 7MB and $hebrew_layout and $runas and $jpg_magic and 3 of ( $wl_* )
}
rule HARFANGLAB_Samecoin_Campaign_Wiper : FILE
{
	meta:
		description = "Matches the wiper used in the SameCoin campaign"
		author = "HarfangLab"
		id = "695e9181-cc96-5212-b33c-4d55065b7b85"
		date = "2024-02-13"
		modified = "2026-05-18"
		reference = "TRR240201"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L545-L563"
		license_url = "N/A"
		hash = "e6d2f43622e3ecdce80939eec9fffb47e6eb7fc0b9aa036e9e4e07d7360f2b89"
		logic_hash = "ebe7c90398464ecf74ede17551c2ebc58b851ba6502092320934d1f5353581a2"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$code = { 68 57 04 00 00 50 E8 }
		$wl_1 = "C:\\Users\\Public\\Microsoft Connection Agent.jpg" ascii
		$wl_2 = "C:\\Users\\Public\\Video.mp4" ascii
		$wl_3 = "C:\\Users\\Public\\Microsoft System Agent.exe" ascii
		$wl_4 = "C:\\Users\\Public\\Microsoft System Manager.exe" ascii
		$wl_5 = "C:\\Users\\Public\\Windows Defender Agent.exe" ascii

	condition:
		uint16( 0 ) == 0x5A4D and filesize < 200KB and $code and 3 of ( $wl_* )
}
rule HARFANGLAB_Samecoin_Campaign_Tasksspreader : FILE
{
	meta:
		description = "Detect .NET Task Scheduler that is dropper by SameCoin Loader"
		author = "HarfangLab"
		id = "7dcfdecd-00c3-502a-b29e-a10a1fd9543f"
		date = "2024-02-13"
		modified = "2026-05-18"
		reference = "TRR240201"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L564-L601"
		license_url = "N/A"
		hash = "b447ba4370d9becef9ad084e7cdf8e1395bafde1d15e82e23ca1b9808fef13a7"
		logic_hash = "61d602c343365608e5bc587ee9c7898e256f2411d78c7fe74c211e68bf4ab707"
		score = 75
		quality = 78
		tags = "FILE"
		context = "file"

	strings:
		$dotNet = ".NETFramework,Version" ascii fullword
		$a1 = "System.DirectoryServices.ActiveDirectory" ascii fullword
		$a2 = "GetTypeFromProgID" ascii fullword
		$a3 = "DirectorySearcher" ascii fullword
		$a4 = "SearchResultCollection" ascii fullword
		$a5 = "UnaryOperation" ascii fullword
		$b1 = "$dc1b29f0-9a87-4383-ad8b-01285614def1" ascii fullword
		$b2 = "Windows Defender Agent" ascii fullword
		$b3 = "Windows Defender Agent.exe" wide ascii fullword
		$b4 = /(\\)?C(:|\$)\\Users\\Public\\Microsoft System Agent\.exe/ wide fullword
		$b5 = "MicrosoftEdgeUpdateTaskMachinesCores" wide fullword
		$b6 = "WindowsUpdate" wide fullword
		$c1 = "RegisterTaskDefinition" wide fullword
		$c2 = "DisallowStartIfOnBatteries" wide fullword
		$c3 = "StopIfGoingOnBatteries" wide fullword
		$c4 = "Schedule.Service" wide fullword
		$c5 = "\\Domain Users" wide fullword
		$c6 = "(objectClass=computer)" wide fullword

	condition:
		filesize > 8KB and filesize < 40KB and ( uint16be( 0 ) == 0x4D5A ) and $dotNet and ( 4 of ( $a* ) ) and ( ( ( any of ( $b* ) ) and ( any of ( $c* ) ) ) or ( all of ( $c* ) ) )
}
rule HARFANGLAB_Samecoin_Campaign_Nativewiper : FILE
{
	meta:
		description = "Matches the native Android library used in the SameCoin campaign"
		author = "HarfangLab"
		id = "9c77c26e-50f7-5ee4-bc6b-c0333e268b2c"
		date = "2024-05-28"
		modified = "2024-02-13"
		reference = "TRR240201"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L602-L622"
		license_url = "N/A"
		hash = "248054658277e6971eb0b29e2f44d7c3c8d7c5abc7eafd16a3df6c4ca555e817"
		logic_hash = "2779664830df3b5be72b7fe7d4da3d27e2a86b289ee3974596abf1df12317cd8"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$native_export = "Java_com_example_exampleone_MainActivity_deleteInCHunks" ascii
		$f1 = "_Z9chunkMainv" ascii
		$f2 = "_Z18deleteFilesInChunkRKNSt6__" ascii
		$f3 = "_Z18overwriteWithZerosPKc" ascii
		$s1 = "/storage/emulated/0/" ascii
		$s2 = "FileLister" ascii
		$s3 = "Directory chunks deleted."
		$s4 = "Current Chunk Size is:  %dl\n" ascii

	condition:
		filesize < 500KB and uint32( 0 ) == 0x464C457F and ( $native_export or all of ( $f* ) or all of ( $s* ) )
}
rule HARFANGLAB_Supposed_Grasshopper_Downloader : FILE
{
	meta:
		description = "Detects the Nim downloader from the Supposed Grasshopper campaign."
		author = "HarfangLab"
		id = "e53656b5-a1be-53f0-a4d4-908f24e08bd6"
		date = "2024-06-20"
		modified = "2026-05-18"
		reference = "TRR240601"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L623-L638"
		license_url = "N/A"
		logic_hash = "93509319ab8028b0215fcfb81d1ff5d3d810922999f1dd8359b706a965221b2f"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file,memory"

	strings:
		$pdb_path = "C:\\Users\\or\\Desktop\\nim-" ascii
		$code = "helo.nim" ascii
		$function_1 = "DownloadExecute" ascii fullword
		$function_2 = "toByteSeq" ascii fullword

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule HARFANGLAB_Donut_Shellcode : FILE
{
	meta:
		description = "Detects Donut shellcode in memory."
		author = "HarfangLab"
		id = "54facb12-3f33-5430-b4bf-0d223dc2a413"
		date = "2024-06-20"
		modified = "2026-05-18"
		reference = "TRR240601"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L639-L687"
		license_url = "N/A"
		logic_hash = "1bf4e253195e39cc0b3cf45797c35a9f06078350aa35e65d9d36adbcc09a150b"
		score = 75
		quality = 80
		tags = "FILE"
		context = "memory"

	strings:
		$amsi_patch = { 48 8B 44 24 (28 | 30) 83 20 00 33 C0 C3 }
		$wldp_patch = { 41 C7 00 01 00 00 00 33 C0 C3 }
		$api_hashing = { 8B C2 C1 C9 08 41 03 C8 8B D3 41 33 C9 C1 CA 08 41 03 D1 41 C1 C0 03 41 33 D2 41 C1 C1 03 44 33 CA 44 33 C1 41 FF C2 41 8B DB 44 8B D8 41 83 FA 1B }
		$loaded_dlls = "ole32;oleaut32;wininet;mscoree;shell32" ascii
		$function_1 = "WldpQueryDynamicCodeTrust" ascii
		$function_2 = "WldpIsClassInApprovedList" ascii
		$function_3 = "AmsiInitialize" ascii
		$function_4 = "AmsiScanBuffer" ascii
		$function_5 = "AmsiScanString" ascii

	condition:
		uint8( 0 ) == 0xE8 and ( ( #amsi_patch > 1 and $wldp_patch and $api_hashing ) or ( $loaded_dlls and all of ( $function_* ) ) )
}
rule HARFANGLAB_Muddywater_Ateraagent_Operators : FILE
{
	meta:
		description = "Detect Atera Agent abused by MuddyWater"
		author = "HarfangLab"
		id = "1494a0da-92de-5cfb-a870-325d02e2cdfb"
		date = "2024-04-17"
		modified = "2026-05-18"
		reference = "TRR240402"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L688-L718"
		license_url = "N/A"
		hash = "9b49d6640f5f0f1d68f649252a96052f1d2e0822feadd7ebe3ab6a3cadd75985"
		logic_hash = "63d5d3a6723191dccd20c8d9f25607df512b91f57ac891ef8c87b2dd107ee5a2"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$s1 = "COMPANYID001Q3000009snPyIAIACCOUNTID"
		$s2 = "COMPANYID001Q3000006FpmoIACACCOUNTID"
		$s3 = "COMPANYID001Q3000008IyacIACACCOUNTID"
		$s4 = "COMPANYID001Q3000009QoSEIA0ACCOUNTID"
		$s5 = "COMPANYID001Q30000023c7iIAAACCOUNTID"
		$s6 = "COMPANYID001Q3000008qXbDIAUACCOUNTID"
		$s7 = "COMPANYID001Q3000008cfLjIAIACCOUNTID"
		$s8 = "COMPANYID001Q3000007hJubIAEACCOUNTID"
		$s9 = "COMPANYID001Q3000008ryO3IAIACCOUNTID"
		$s10 = "COMPANYID001Q300000A5nnAIARACCOUNTID"
		$s11 = "COMPANYID001Q3000008JfioIACACCOUNTID"
		$s12 = "COMPANYID001Q300000BeUp3IAFACCOUNTID"
		$s13 = "COMPANYID001Q3000005gMamIAEACCOUNTID"
		$s15 = "mrrobertcornish@gmail.comINTEGRATORLOGINCOMPANYID"
		$cert1 = { 0A 28 49 99 78 E5 89 8D F4 0A 23 8E B8 A5 52 E8 }
		$cert2 = { 06 7F 60 47 95 66 24 A7 15 99 61 74 3D 81 94 93 }

	condition:
		filesize > 1MB and filesize < 4MB and ( uint16be( 0 ) == 0xD0CF ) and any of ( $s* ) and any of ( $cert* )
}
rule HARFANGLAB_Xdspy_LNK_2025 : FILE
{
	meta:
		description = "Matches XDSpy malicious LNK files, used in 2025"
		author = "HarfangLab"
		id = "ddd86b11-2d48-5383-9893-d7ed44210a38"
		date = "2025-05-16"
		modified = "2026-05-18"
		reference = "TRR250601"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L719-L740"
		license_url = "N/A"
		hash = "904db68a915b4bbd0b4b2d665bb1e2c51fa1b71b9c44ce45ccd4b4664f2bfd8e"
		hash = "536cd589cd685806b4348b9efa06843a90decae9f4135d1b11d8e74c7911f37d"
		hash = "0b705938e0063e73e03645e0c7a00f7c8d8533f1912eab5bf9ad7bc44d2cf9c3"
		logic_hash = "742dc83a60812609810e30b7f9d60ed0e0f6ce1294b2d29b084b0ea939ee71cb"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$c1 = "/nologo /r:System.IO.Compression.FileSystem.dll /out:%TEMP%" wide fullword
		$c2 = "%SystemRoot%\\Microsoft.Net\\Framework\\*jsc.exe" wide fullword
		$c3 = "+Convert.ToChar(46)+Convert.ToChar(105)+Convert.ToChar(110)+Convert.ToChar(105)" wide fullword

	condition:
		( filesize > 1KB ) and ( filesize < 10KB ) and ( uint32( 0 ) == 0x0000004C ) and ( ( uint32be( 4 ) == 0x01140200 ) and ( uint32be( 8 ) == 0x00000000 ) and ( uint32be( 12 ) == 0xC0000000 ) and ( uint32be( 16 ) == 0x00000046 ) ) and ( uint8( 0x14 ) & 0x20 == 0x20 ) and ( uint8( 0x14 ) & 0x80 == 0x80 ) and ( any of ( $c* ) )
}
rule HARFANGLAB_Xdspy_Etdownloader : FILE
{
	meta:
		description = "Matches XDSpy 1st stage ET Downloader malware"
		author = "HarfangLab"
		id = "b335d868-7904-5270-a55e-c1445f0c4c9c"
		date = "2025-05-16"
		modified = "2026-05-18"
		reference = "https://github.com/HarfangLab/iocs"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L741-L774"
		license_url = "N/A"
		hash = "792c5a2628ec1be86e38b0a73a44c1a9247572453555e7996bb9d0a58e37b62b"
		logic_hash = "050bf26c5665c68055f1f31b4cdce40fb8c6d2b9d8e08925e684cf70e80eb2dd"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$dotNet = ".NETFramework,Version=" ascii
		$s1 = "$fcca44e8-9635-4cd7-974b-e86e6bce12cd" ascii fullword
		$s2 = "/startup" wide fullword
		$s3 = "ExportTests.dll" ascii wide fullword
		$s4 = "+<PayloadDownload>d__" ascii
		$s5 = "+<PayloadDownloadExecution>d__" ascii
		$f1 = "HttpWebResponse" ascii fullword
		$f2 = "set_UseShellExecute" ascii fullword
		$f3 = "set_CreateNoWindow" ascii fullword
		$f4 = "FromBase64String" ascii fullword
		$f5 = "set_ServerCertificateValidationCallback" ascii fullword
		$f6 = "AsyncTaskMethodBuilder" ascii fullword
		$f7 = "rangeDecoder" ascii fullword
		$f8 = "NumBitLevels" ascii fullword
		$f9 = "GetCallingAssembly" ascii fullword
		$f10 = "BlockCopy" ascii fullword
		$f11 = "MemoryStream" ascii fullword

	condition:
		uint16( 0 ) == 0x5a4d and filesize > 20KB and filesize < 120KB and $dotNet and ( ( ( 2 of ( $s* ) ) and ( 3 of ( $f* ) ) ) or ( all of ( $f* ) ) )
}
rule HARFANGLAB_Xdspy_Xdigo : FILE
{
	meta:
		description = "Rule to catch XDSpy Main module, written in golang"
		author = "HarfangLab"
		id = "d7df9c81-c237-5ee9-a368-fb8a90ac1889"
		date = "2025-05-16"
		modified = "2026-05-18"
		reference = "https://github.com/HarfangLab/iocs"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L775-L802"
		license_url = "N/A"
		hash = "49714e2a0eb4d16882654fd60304e6fa8bfcf9dbd9cd272df4e003f68c865341"
		hash = "0d983f5fb403b500ec48f13a951548d5a10572fde207cf3f976b9daefb660f7e"
		hash = "3adeda2a154dcf017ffed634fba593f80df496eb2be4bee0940767c8631be7c1"
		logic_hash = "3d98768a15eda41b156355919d9876c3f4a9cf1f4a2207ad3e3a391255960438"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$a1 = "main.oooo_" ascii
		$b1 = "anti.go" ascii fullword
		$b2 = "crypto.go" ascii fullword
		$b3 = "file.go" ascii fullword
		$b4 = "main.go" ascii fullword
		$b5 = "net.go" ascii fullword
		$b6 = "log.go" ascii fullword
		$b7 = "settings.go" ascii fullword
		$b8 = "screenshot_windows.go" ascii fullword
		$c1 = "passwords.go" ascii fullword
		$c2 = "keylog.go" ascii fullword

	condition:
		uint16( 0 ) == 0x5a4d and filesize > 1MB and filesize < 15MB and #a1 > 100 and ( any of ( $c* ) or all of ( $b* ) )
}
rule HARFANGLAB_Packxor : FILE
{
	meta:
		description = "Detection rule for PackXOR"
		author = "Harfanglab"
		id = "6b4b6d61-b698-5e15-90b1-de2bdb76e425"
		date = "2024-08-05"
		modified = "2026-05-18"
		reference = "https://harfanglab.io/insidethelab/unpacking-packxor/"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L803-L942"
		license_url = "N/A"
		hash = "0506372e2c2b6646c539ac5a08265dd66d0da58a25545e444c25b9a02f8d9a44"
		logic_hash = "ecc7e241f98da8bcd248493f6443676e4c1e516f1fd19f488a62acd314be1898"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$s_packer_xor = {
            4? 63 [3]                       // movsxd  rax, dword [rsp+0x50 {var_78}]
            4? 8b [2-6]                     // mov     rcx, qword [rsp+0xd0 {arg_8}]
            4? 8b [2-6]                     // mov     rcx, qword [rcx+0x8]
            4? 0? [2]                       // add     rax, qword [rcx+0x50]
            4? 8d [5]                       // lea     rcx, [rel data_140003020]
            0f (b6|b7) [1-5]                // movzx   eax, byte [rcx+rax]
            0f (b6|b7) [1-5]                // movzx   ecx, byte [rel data_14002399c]
            4? 8b [2-6]                     // mov     rdx, qword [rsp+0xd0 {arg_8}]
            4? 8b [2-6]                     // mov     rdx, qword [rdx+0x8]
            4? 0? [2]                       // add     rcx, qword [rdx+0x68]
            0f (b6|b7) [1-5]                // movzx   ecx, cl
            33 ??                           // xor     eax, ecx
            4? 63 [3]                       // movsxd  rcx, dword [rsp+0x50 {var_78}]
            4? 8b [2-6]                     // mov     rdx, qword [rsp+0xd0 {arg_8}]
            4? 8b [2-6]                     // mov     rdx, qword [rdx+0x8]
            4? 0? [2]                       // add     rcx, qword [rdx+0x48]
            4? 8d [5]                       // lea     rdx, [rel data_140003020]
            88 04 0a                        // mov     byte [rdx+rcx], al
            0f (b6|b7)                      // movzx   eax, byte [rel data_14000301e]
        }
		$s_packer_decrypt_conf = {
            8b [1-3]            // mov     eax, dword [rsp+0x4 {i}]
            ff ??               // inc     eax
            89 [1-3]            // mov     dword [rsp+0x4 {i}], eax
            0f b6 [1-3]         // movzx   eax, byte [rsp {var_128}]
            39 [1-3]            // cmp     dword [rsp+0x4 {i}], eax
            73 ??               // jae     0x140001d59
            8b [1-3]            // mov     eax, dword [rsp+0x4 {i}]
            83 ?? 05            // add     eax, 0x5
            8b ??               // mov     eax, eax
            4? 8b [2-6]         // mov     rcx, qword [rsp+0x130 {arg_8}]
            0f be [1-3]         // movsx   eax, byte [rcx+rax]
            85 ??               // test    eax, eax
            74 ??               // je      0x140001d40
            0f b6 [1-3]         // movzx   eax, byte [rsp+0x2 {var_126}]
            8b [3]              // mov     ecx, dword [rsp+0x4 {i}]
            83 ?? 05            // add     ecx, 0x5
            8b ??               // mov     ecx, ecx
            4? 8b [4-6]         // mov     rdx, qword [rsp+0x130 {arg_8}]
            0f (be|bf) [1-3]    // movsx   ecx, byte [rdx+rcx]
            33 ??               // xor     eax, ecx
            2b [1-3]            // sub     eax, dword [rsp+0x4 {i}]
            ff ??               // dec     eax
            8b [1-3]            // mov     ecx, dword [rsp+0x4 {i}]
            88 [1-3]            // mov     byte [rsp+rcx+0x20 {var_108}], al
            eb ??               // jmp     0x140001d57
            b8 01 00 00 00      // mov     eax, 0x1
            4? 6b ?? 00         // imul    rax, rax, 0x0
            4? 8b [4-6]         // mov     rcx, qword [rsp+0x130 {arg_8}]
            c6 [1-3] 00         // mov     byte [rcx+rax], 0x0
            eb ??               // jmp     0x140001d59
            eb                  // jmp     0x140001ce7
        }
		$s_packer_find_entry_point = {
            4? 63 [1-4]             // movsxd  rax, dword [rsp {var_38_1}]
            4? 3b [1-4]             // cmp     rax, qword [rsp+0x20 {var_18_1}]
            73 ??                   // jae     0x140001c7f
            48 8b [1-4]             // mov     rax, qword [rsp+0x10 {var_28_1}]
            0f b7 [1-4]             // movzx   eax, word [rax]
            c1 ?? 0c                // sar     eax, 0xc
            83 ?? 0a                // cmp     eax, 0xa
            75 ??                   // jne     0x140001c7d
            4? 8b [1-4]             // mov     rax, qword [rsp+0x8 {var_30}]
            8b [1-4]                // mov     eax, dword [rax]
            4? 03 [1-4]             // add     rax, qword [rsp+0x40 {arg_8}]
            4? 8b [1-4]             // mov     rcx, qword [rsp+0x10 {var_28_1}]
            0f b7 [1-4]             // movzx   ecx, word [rcx]
            81 ?? ff 0f 00 00       // and     ecx, 0xfff
            4? 63 [1-4]             // movsxd  rcx, ecx
            4? 03 [1-4]             // add     rax, rcx
            4? 89 [1-4]             // mov     qword [rsp+0x18 {var_20_1}], rax
            4? 8b [1-4]             // mov     rax, qword [rsp+0x18 {var_20_1}]
            4? 8b [1-4]             // mov     rax, qword [rax]
            4? 03 [1-4]             // add     rax, qword [rsp+0x50 {arg_18}]
            4? 8b [1-4]             // mov     rcx, qword [rsp+0x18 {var_20_1}]
            4? 89 [1-4]             // mov     qword [rcx], rax
            eb 93                   // jmp     0x140001c12
        }
		$s_packer_find_entry_point_rtlcreateuserthtread = {
            4? 8b [1-4]                // mov     rax, qword [rsp+0x70 {var_58_1}]
            8b [1-4]                   // mov     eax, dword [rax+0x28]
            4? 03 [1-4]                // add     rax, qword [rsp+0x68 {var_60_1}]
            4? 89 [2-6]                // mov     qword [rsp+0x88 {var_40_1}], rax
            ff [2-6]                   // call    qword [rsp+0x88 {var_40_1}]
            4? 8d [2-6]                // lea     rax, [rsp+0x9c {var_2c}]
            4? 89 [1-4]                // mov     qword [rsp+0x48 {var_80_1}], rax {var_2c}
            4? 8d [2-6]                // lea     rax, [rsp+0xb8 {var_10}]
            4? 89 [1-4]                // mov     qword [rsp+0x40 {var_88_1}], rax {var_10}
            4? c7 [3-7]                // mov     qword [rsp+0x38 {var_90}], 0x0
            4? 8b [2-6]                // mov     rax, qword [rsp+0x88 {var_40_1}]
            4? 89 [1-4]                // mov     qword [rsp+0x30 {var_98_1}], rax
            4? c7 [3-7]                // mov     qword [rsp+0x28 {var_a0}], 0x0
            4? c7 [3-7 ]               // mov     qword [rsp+0x20 {var_a8}], 0x0
            4? 33 ??                   // xor     r9d, r9d  {0x0}
            4? ?? 01                   // mov     r8b, 0x1
            33 ??                      // xor     edx, edx  {0x0}
            4? c? ?? ff ff ff ff       // mov     rcx, 0xffffffffffffffff
            ff                         // call    qword [rsp+0xa0 {var_28_1}]
        }
		$s_packer_string_encryption = {
            0f B? [1-2]      // movzx   eax, [rsp+128h+size_string]
            39 [1-3]         // cmp     [rsp+128h+var_124], eax
            73 ??            // jnb     short loc_140001CC9
            8B [1-3]         // mov     eax, [rsp+128h+var_124]
            83 ?? 05         // add     eax, 5
            8B ??            // mov     eax, eax
            4? 8B [1-6]      // mov     rcx, [rsp+128h+arg_0]
            0F B? [1-2]      // movsx   eax, byte ptr [rcx+rax]
            85 ??            // test    eax, eax
            74 ??            // jz      short loc_140001CB0
            0f B? [1-3]      // movzx   eax, [rsp+128h+key]
            8B [1-3]         // mov     ecx, [rsp+128h+var_124]
            83 ?? 05         // add     ecx, 5
            8B ??            // mov     ecx, ecx
            4? 8B [1-6]      // mov     rdx, [rsp+128h+arg_0]
            0F B? [1-2]      // movsx   ecx, byte ptr [rdx+rcx]
            33 ??            // xor     eax, ecx
            2B [1-3]         // sub     eax, [rsp+128h+var_124]
            FF ??            // dec     eax
            8B [1-3]         // mov     ecx, [rsp+128h+var_124]
            88 [1-3]         // mov     [rsp+rcx+128h+decrypted_string], al
            EB               // jmp     short loc_140001CC7
        }

	condition:
		uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 and filesize < 20MB and 2 of ( $s_packer* )
}
rule HARFANGLAB_Gamaredon_Pterolnk_Vbscript : FILE
{
	meta:
		description = "Matches Gamaredon PteroLNK VBScript samples used in late 2024 to early 2025"
		author = "HarfangLab"
		id = "3781749e-7f4e-55db-bdf7-2a0a056f41f4"
		date = "2025-04-04"
		modified = "2026-05-18"
		reference = "TRR250401"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L943-L962"
		license_url = "N/A"
		hash = "d5538812b9a41b90fb9e7d83f2970f947b1e92cb68085e6d896b97ce8ebff705"
		logic_hash = "b6aad0ca4653c111a4f481f9d4636e272712dc7ad53fa3b2041f2c47a1eee527"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$vbs = "on error resume next" ascii wide
		$a1 = "=\"b24gZXJyb3IgcmVzdW1lIG5leHQNC" ascii wide
		$b1 = "\"\"%PUBLIC%\"\"" ascii wide
		$b2 = "\"\"%APPDATA%\"\"" ascii wide
		$b3 = "\"\"REG_DWORD\"\"" ascii wide

	condition:
		filesize < 400KB and $vbs in ( 0 .. 2 ) and $a1 and 1 of ( $b* )
}
rule HARFANGLAB_Gamaredon_Pterolnk_LNK : FILE
{
	meta:
		description = "Matches Gamaredon PteroLNK-generated LNK files used in late 2024 to early 2025"
		author = "HarfangLab"
		id = "e6e0c2cb-049a-5d80-b167-56079aefe38b"
		date = "2025-04-04"
		modified = "2026-05-18"
		reference = "TRR250401"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L963-L981"
		license_url = "N/A"
		hash = "n/a"
		logic_hash = "69565365da1632407e223f87978a91543b1281879aa372cd055d08e26e1a2d93"
		score = 75
		quality = 78
		tags = "FILE"
		context = "file"

	strings:
		$a1 = "javascript:eval('w=new%20ActiveXObject(\\\"\"WScript.Shell\\\"\");w.run(\\\"\"wscript.exe //e:vb\"\"+\"\"Script" ascii wide
		$a2 = "javascript:eval('w=new%20ActiveXObject(\\\"\"WScript.Shell\\\"\");w.run(\\\"\"explorer" ascii wide
		$b1 = "\"\");window.close()')" ascii wide nocase

	condition:
		filesize < 10KB and uint32( 0 ) == 0x0000004C and uint32( 4 ) == 0x00021401 and 1 of ( $a* ) and $b1
}
rule HARFANGLAB_Gamaredon_Pterolnk_Vbscript_Update2506 : FILE
{
	meta:
		description = "Matches Gamaredon PteroLNK VBScript samples used in 2025"
		author = "HarfangLab"
		id = "e1feefb6-7070-53b0-98e7-4a3d784ee014"
		date = "2025-06-23"
		modified = "2026-05-18"
		reference = "TRR250401;TRR250401_update2506"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L982-L1008"
		license_url = "N/A"
		hash = "d5538812b9a41b90fb9e7d83f2970f947b1e92cb68085e6d896b97ce8ebff705"
		hash = "4787fe23a4ba66137e41d6caa877251092a7f4957ccd89ed374b71aa6f6e2037"
		logic_hash = "e754fcdd1de5d00972f1c8352b61701f833f28bfa38e54234b3c2ced59b7f491"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$vbs = "on error resume next" ascii wide
		$a1 = "b24gZXJyb3IgcmVzdW1lIG5leHQNC" ascii wide
		$b1 = "\"\"%PUBLIC%\"\"" ascii wide
		$b2 = "\"\"%APPDATA%\"\"" ascii wide
		$b3 = "\"\"REG_DWORD\"\"" ascii wide
		$b4 = "\"\"%USERPROFILE%\"\"" ascii wide
		$c1 = "\"\":SRV\"\"" ascii wide
		$c2 = "\"\":GTR\"\"" ascii wide
		$c3 = "\"\":LNK\"\"" ascii wide
		$c4 = "\"\":URLS\"\"" ascii wide
		$c5 = "\"\":IPS\"\"" ascii wide

	condition:
		filesize < 600KB and $vbs in ( 0 .. 500 ) and $a1 and ( any of ( $b* ) or any of ( $c* ) )
}
rule HARFANGLAB_Apt31_Rawdoor_Dropper : FILE
{
	meta:
		description = "Matches the RawDoor dropper"
		author = "HarfangLab"
		id = "b278a157-20e2-5271-aca0-0692929b881d"
		date = "2024-04-12"
		modified = "2026-05-18"
		reference = "TRR240401"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L1009-L1030"
		license_url = "N/A"
		hash = "c3056e39f894ff73bba528faac04a1fc86deeec57641ad882000d7d40e5874be"
		logic_hash = "d0cbe02c4fafb4895bd0126d2496802a3fee6a0362e55bfa91cfd1c75043d94a"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$service_target = "%SystemRoot%\\system32\\svchost.exe -k netsvcs" ascii
		$service_dispname = "Microsoft .NET Framework NGEN" ascii
		$drop_name = "~DF313.msi" ascii
		$msg1 = "RegOpenKeyEx %s  error:%d\x0D\x0A" ascii
		$msg2 = "RegDeleteValue Wow64 . %d\x0D\x0A" ascii
		$msg3 = "CreateService %s success! but Start Faile.. %d\x0D\x0A" ascii
		$msg4 = "OutResFile to %s%s False!" ascii
		$msg5 = "Can't GetNetSvcs Buffer!" ascii

	condition:
		uint16( 0 ) == 0x5A4D and filesize > 350KB and filesize < 600KB and ( ( $service_target and $service_dispname and $drop_name ) or 3 of ( $msg* ) )
}
rule HARFANGLAB_Apt31_Rawdoor_Payload : FILE
{
	meta:
		description = "Matches the RawDoor payload"
		author = "HarfangLab"
		id = "5fef27fe-a2ea-56b4-8cf6-8f6c4bf85d80"
		date = "2024-04-12"
		modified = "2026-05-18"
		reference = "TRR240401"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L1031-L1055"
		license_url = "N/A"
		hash = "fade96ec359474962f2167744ca8c55ab4e6d0700faa142b3d95ec3f4765023b"
		logic_hash = "51bd04603419d5bc77f12618df986f6b31ea8ddea553c6bc7580698fa236b3ed"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$name = "\x0D\x0A=================RawDoor %g================\x0D\x0A" ascii
		$key = /SOFTWARE\\Clients\\Netra(u|w)/ ascii
		$cmd1 = "Shell <powershell.exe path>" ascii
		$cmd2 = "Selfcmd <self cmd string>" ascii
		$cmd3 = "Wsrun <process name>" ascii
		$cmd4 = "ping 127.0.0.1 > nul\x0D\x0A"
		$cmd5 = "/c netsh advfirewall firewall add rule name=" ascii
		$msg1 = "Allocate pSd memory to failed!" ascii
		$msg2 = "Allocate SID or ACL to failed!" ascii
		$msg3 = "OpenSCManager error:%d" ascii
		$msg4 = "%u:TCP:*:Enabled:%u" ascii

	condition:
		uint16( 0 ) == 0x5A4D and filesize < 200KB and ( ( $name and $key ) or ( 3 of ( $cmd* ) and 3 of ( $msg* ) ) )
}
rule HARFANGLAB_Iis_Module_Hijackserver_Native : FILE
{
	meta:
		description = "Matches the IIS HijackServer module"
		author = "HarfangLab"
		id = "f53af298-c715-5243-a8a7-5abe8f56b9ab"
		date = "2025-08-25"
		modified = "2026-05-18"
		reference = "TRR251001"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L1056-L1089"
		license_url = "N/A"
		hash = "c1ca053e3c346513bac332b5740848ed9c496895201abc734f2de131ec1b9fb2"
		logic_hash = "f0539a40958b34bb8372f8a8a6ca22617626fc7806556d6353175aa5f2ec0aea"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$c1 = ".?AVCHttpModule@@" ascii fullword
		$c2 = ".?AVCGlobalModule@@" ascii fullword
		$m1 = "RegisterModule" ascii fullword
		$s1 = "hack1234" ascii
		$s2 = "<!- GP -->" ascii fullword
		$s3 = /\.cseo\d{1,3}\.com\/config\// ascii
		$s4 = ":(80|443)(?=/|$)" ascii fullword
		$s5 = "TryCleanTmp:" ascii
		$s6 = "no excute " ascii
		$s7 = "\\b(\\d{1,2})-(\\d{1,2})-(\\d{4})\\b" ascii fullword
		$s8 = "/Tqpn0tGX550fVwt5D6g4CGWP6" ascii
		$s9 = "\\IISCPP-GM\\" ascii
		$s10 = "\\Dongtai.pdb\x00" ascii
		$s11 = "_FAB234CD3-09434-88" ascii
		$s12 = "<input type='text' name='cmdml' place" ascii
		$s13 = ".?AVHiJackServer@@" ascii fullword
		$s14 = ".?AVWebdllServer@@" ascii fullword
		$s15 = ".?AVAffLinkServer@@" ascii fullword

	condition:
		uint16be( 0 ) == 0x4D5A and filesize > 200KB and filesize < 2MB and $m1 and ( any of ( $c* ) ) and ( 4 of ( $s* ) )
}
rule HARFANGLAB_Iis_Module_Hijackserver_Dotnet : FILE
{
	meta:
		description = "Matches the IIS HijackServer .NET module"
		author = "HarfangLab"
		id = "1c45ecc4-865d-5213-bd50-380123cc5877"
		date = "2025-10-14"
		modified = "2026-05-18"
		reference = "TRR251001"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L1090-L1121"
		license_url = "N/A"
		hash = "915441b7d7ddb7d885ecfe75b11eed512079b49875fc288cd65b023ce1e05964"
		logic_hash = "83476157c66ac9586d28bf2e8614575c4950ab3e3538fd12d0a31fc451970686"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$dotNet = ".NETFramework,Version=" ascii
		$c1 = "HttpApplication" ascii fullword
		$c2 = "IHttpModule" ascii fullword
		$s1 = "YourSecretKey123" wide fullword
		$s2 = "<!- GP -->" wide fullword
		$s3 = /\.cseo\d{1,3}\.com\/config\// wide
		$s4 = ":(80|443)(?=/|$)" wide fullword
		$s5 = "clean?type=all" wide fullword
		$s6 = "DealRequest" ascii
		$s7 = "\\Tiquan\\CustomIISModule\\" ascii
		$s8 = "\\CustomIISModule.pdb\x00" ascii
		$s9 = "\\Temp\\AcpLogs\\conf\\" wide
		$s10 = "RobotTxtServer" ascii fullword
		$s11 = "HijackServer" ascii fullword
		$s12 = "WebdllServer" ascii fullword
		$s13 = "AffLinkServer" ascii fullword

	condition:
		uint16be( 0 ) == 0x4D5A and filesize > 200KB and filesize < 2MB and $dotNet and ( all of ( $c* ) ) and ( 4 of ( $s* ) )
}
rule HARFANGLAB_Apache_Module_Hijackserver_Php_Decoded : FILE
{
	meta:
		description = "Matches the decompressed and decoded Apache HijackServer PHP module"
		author = "HarfangLab"
		id = "86337024-575a-5c08-97a8-e7768a60ced7"
		date = "2025-10-15"
		modified = "2026-05-18"
		reference = "TRR251001"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L1122-L1149"
		license_url = "N/A"
		hash = "e107bf25abc1cff515b816a5d75530ed4d351fa889078e547d7381b475fe2850"
		logic_hash = "bf40ee8ae3a491c311d5221cb96adef6bd55153d602f1d534f2cb42a12aa68ec"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$php = /\$_SERVER\[\s*['"]PHP_SELF['"]\s*\]/ ascii wide fullword
		$s1 = "hj_clean_cache_dir" ascii wide fullword
		$s2 = "hj_get_file_content" ascii wide fullword
		$s3 = "\"清理目录空间 目录:\"" ascii wide fullword
		$s4 = "'/:(80|443)$/'" ascii wide fullword
		$s5 = "isCleanRequest()" ascii wide fullword
		$s6 = "shuffle_file_current_line" ascii wide fullword
		$s7 = "self::replaceAffLinkUrl" ascii wide fullword
		$s8 = "/Tqpn0tGX550fVwt5D6g4CGWP6" ascii wide
		$s9 = "HJ_CONFIG_URL_FORMAT" ascii wide fullword
		$s10 = "HJ_DEFAULT_LOCAL_LINK_NUM" ascii wide fullword
		$s11 = "renderHealthCheck" ascii wide fullword
		$s12 = "renderRedirect" ascii wide fullword
		$s13 = "renderAffLink" ascii wide fullword

	condition:
		filesize > 50KB and filesize < 600KB and $php and ( 4 of ( $s* ) )
}
rule HARFANGLAB_Apache_Module_Hijackserver_Php : FILE
{
	meta:
		description = "Matches the encoded Apache HijackServer PHP module"
		author = "HarfangLab"
		id = "d9f5c018-78f4-5747-af09-73b32700f5f5"
		date = "2025-10-15"
		modified = "2026-05-18"
		reference = "TRR251001"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L1150-L1165"
		license_url = "N/A"
		hash = "e107bf25abc1cff515b816a5d75530ed4d351fa889078e547d7381b475fe2850"
		logic_hash = "fe503e8d30a354927c1d4e1cffa18411b4c3ac5058cd3aef8df0e7d87624fe43"
		score = 75
		quality = 78
		tags = "FILE"
		context = "file"

	strings:
		$s1 = "\"display_errors\"" ascii wide fullword
		$s2 = /\$code\s*=\s*['"]eJztvWl7XMXRMPydX3GsKJmRGS22sQF5IbIkYwVZ/ ascii wide
		$s3 = /eval\(\s*gzuncompress\(\s*base64_decode\(\s*\$code\s*\)\s*\)\s*\);/ ascii wide nocase fullword

	condition:
		filesize > 10KB and filesize < 200KB and ( all of them )
}
rule HARFANGLAB_Wingtb_Rootkit : FILE
{
	meta:
		description = "Matches the customized Hidden rootkit, Wingtb.sys."
		author = "HarfangLab"
		id = "4bc062e0-a3af-5e53-8301-d91ff651bd08"
		date = "2025-10-15"
		modified = "2026-05-18"
		reference = "TRR251001"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L1166-L1192"
		license_url = "N/A"
		hash = "f9dd0b57a5c133ca0c4cab3cca1ac8debdc4a798b452167a1e5af78653af00c1"
		hash = "88fd3c428493d5f7d47a468df985c5010c02d71c647ff5474214a8f03d213268"
		logic_hash = "d27c5b8770ac842ab5e0e5fb6f6796a4ce250a8da61df33469f54f35cff0ae4e"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$a1 = "\\Device\\WinkbjDamen" wide fullword
		$a2 = "\\DosDevices\\WinkbjDamen" wide fullword
		$s1 = "Kbj_Zhuangtai" wide fullword
		$s2 = "Kbj_YinshenMode" wide fullword
		$s3 = "Kbj_WinkbjFsDirs" wide fullword
		$s4 = "Kbj_WinkbjFsFiles" wide fullword
		$s5 = "Kbj_WinkbjRegKeys" wide fullword
		$s6 = "Kbj_WinkbjRegValues" wide fullword
		$s7 = "Kbj_FangxingImages" wide fullword
		$s8 = "Kbj_BaohuImages" wide fullword
		$s9 = "Kbj_WinkbjImages" wide fullword
		$pdb = "D:\\DriverSpace\\hidden\\x64\\Release\\Winkbj.pdb" fullword

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and ( ( 1 of ( $a* ) and 6 of ( $s* ) ) or $pdb )
}
rule HARFANGLAB_Wingtb_Rootkit_Commandline_Tool_Wingtbcli : FILE
{
	meta:
		description = "Matches the usermode command-line tool for rootkit, WingtbCLI.exe."
		author = "HarfangLab"
		id = "14ee884b-55cf-568e-99c1-73ac66a3f2f7"
		date = "2025-10-15"
		modified = "2026-05-18"
		reference = "TRR251001"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/hl_public_reports_master.yar#L1193-L1223"
		license_url = "N/A"
		hash = "913431f1d36ee843886bb052bfc89c0e5db903c673b5e6894c49aabc19f1e2fc"
		logic_hash = "57a180c8eb395694611c02c674ab94cc721f572a513a88dfe951f56b1ece1cb5"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$s1 = ".?AVCommandUnignore@@" fullword
		$s2 = ".?AVCommandUnprotect@@" fullword
		$s3 = ".?AVCommandYinshen@@" fullword
		$s4 = "System\\CurrentControlSet\\Services\\Wingtb" wide fullword
		$s5 = "/buxiaoshi" wide fullword
		$s6 = "/fangxing" wide fullword
		$s7 = "/bufangxing" wide fullword
		$s8 = "/bubaohu" wide fullword
		$s9 = "/zhuangtai" wide fullword
		$s10 = "/yinshen" wide fullword
		$s11 = "Kbj_ShanchuFile" wide fullword
		$s12 = "Kbj_ShanchuDir" wide fullword
		$s13 = "Kbj_WinkbjRegValues" wide fullword
		$s14 = "Kbj_FangxingImages" wide fullword
		$s15 = "Kbj_Zhuangtai" wide fullword
		$s16 = "\\\\.\\WinkbjDamen" wide fullword
		$pdb = "D:\\DriverSpace\\hidden\\x64\\Release\\HiddenCLI.pdb" fullword

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and ( 8 of ( $s* ) or $pdb )
}
rule HARFANGLAB_Custom_Ateraagent_Operator : FILE
{
	meta:
		description = "Detect Atera Agent configured to certain email addresses, or email domains"
		author = "HarfangLab"
		id = "af0fae1d-2d25-5551-8720-ff1172ff4eea"
		date = "2024-04-17"
		modified = "2024-04-22"
		reference = "TRR240402"
		source_url = "https://github.com/HarfangLab/iocs/blob/3e2b674bf2f591ac46301420671ba553de094dea/TRR240402/trr240402_yara-template.yar#L1-L20"
		license_url = "N/A"
		logic_hash = "71622b61c5f645dd846327b79bf6dddefef458b73a82caa34d086da2ba48cd8c"
		score = 75
		quality = 80
		tags = "FILE"
		context = "file"

	strings:
		$email = "email@domain.tld"
		$s1 = "PREVIOUSFOUNDWIX_UPGRADE_DETECTED"
		$s2 = "INTEGRATORLOGIN"
		$sc1 = { 0A 28 49 99 78 E5 89 8D F4 0A 23 8E B8 A5 52 E8 }
		$sc2 = { 06 7F 60 47 95 66 24 A7 15 99 61 74 3D 81 94 93 }

	condition:
		filesize > 1MB and filesize < 4MB and ( uint16be( 0 ) == 0xD0CF ) and @s1 < @email and @email < @s2 [ 3 ] and any of ( $sc* )
}
/*
 * YARA Rule Set
 * Repository Name: SEKOIA
 * Repository: https://github.com/SEKOIA-IO/Community
 * Retrieval Date: 2026-11-15
 * Git Commit: ae52d3fed661f7459c3877fec630e66a1771d5d0
 * Number of Rules: 700
 * Skipped: 0 (age), 42 (quality), 7 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * # Detection Rule License (DRL) 1.1

Permission is hereby granted, free of charge, to any person obtaining a copy of this rule set and associated documentation files (the "Rules"), to deal in the Rules without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Rules, and to permit persons to whom the Rules are furnished to do so, subject to the following conditions:

If you share the Rules (including in modified form), you must retain the following if it is supplied within the Rules:

1. identification of the authors(s) ("author" field) of the Rule and any others designated to receive attribution, in any reasonable manner requested by the Rule author (including by pseudonym if designated).

2. a URI or hyperlink to the Rule set or explicit Rule to the extent reasonably practicable

3. indicate the Rules are licensed under this Detection Rule License, and include the text of, or the URI or hyperlink to, this Detection Rule License to the extent reasonably practicable

If you use the Rules (including in modified form) on data, messages based on matches with the Rules must retain the following if it is supplied within the Rules:

1. identification of the authors(s) ("author" field) of the Rule and any others designated to receive attribution, in any reasonable manner requested by the Rule author (including by pseudonym if designated).

THE RULES ARE PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE RULES OR THE USE OR OTHER DEALINGS IN THE RULES.

 */
rule SEKOIA_Apt_Luckymouse_Rshell_Strings_All_Platform : FILE
{
	meta:
		description = "Detects LuckyMouse RShell Mach-O implant"
		author = "Sekoia.io"
		id = "e79a5ee1-96b3-4643-ab11-0b1095e96488"
		date = "2022-08-05"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_luckymouse_rshell_strings_all_platform.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ef923b6633a2b7dfa645a31c7c2d0e00872ebad6ec7748568c2b306c29b6b29b"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = { 6C 6F 67 69 6E 00 68 6F
        73 74 6E 61 6D 65 00 6C
        61 6E 00 75 73 65 72 6E
        61 6D 65 00 76 65 72 73
        69 6F 6E }

	condition:
		filesize < 1MB and all of them
}
rule SEKOIA_Tool_Cheat_Engine : FILE
{
	meta:
		description = "Detects Cheat Engine driver"
		author = "Sekoia.io"
		id = "51d4246c-f7a1-4589-8f97-bd85d1fe4a0e"
		date = "2024-07-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_cheat_engine.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "2a70016be13c4eff7f7381fd0e34c345c95f09d4cd8b754ea68d59adfe3fe4b6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "ObOpenObjectByName" wide
		$s2 = "PsGetProcessImageFileName" wide
		$s3 = "PsRemoveCreateThreadNotifyRoutine" wide
		$s4 = "PsSuspendProcess" wide
		$s5 = "PsResumeProcess" wide
		$s6 = "\\device\\physicalmemory" wide
		$log = "%sCPU%d.trace" wide
		$ioctl_code = {04 E1 22 00}

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 200KB and all of them
}
rule SEKOIA_Tool_Win_Lightrail : FILE
{
	meta:
		description = "Detect the LIGHTRAIL tunneler used by UNC1549"
		author = "Sekoia.io"
		id = "39259f2c-11fe-4edd-8a9e-f36920132272"
		date = "2024-02-29"
		modified = "2024-12-19"
		reference = "https://www.mandiant.com/resources/blog/suspected-iranian-unc1549-targets-israel-middle-east"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_win_lightrail.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "e7ddab967b0487827db069833221aa2fe4ca05f7cda976cbc528ecb306a22774"
		hash = "4ecd511d9654f7fd66a61eb4ab6d7153040b5092d1594ff39935f01fbdbd4914"
		hash = "3472bc8ed6182eb17811c97ada7ebd48034ad09b6a7062b341fe09818d7a309f"
		hash = "ec7b97092278123f0c0613c5f9252eeccf55265d4aa5f2cfed57a63ebf3530ac"
		hash = "8f3757b8f5888a1303af71cbc1a106927d3d6c45552ee192c3ed0347804c2194"
		hash = "8b47b5ed1ed7afcc9194e1350d4e1996bd91ca3204747b586f309f4609a1a4cc"
		logic_hash = "84491bf7e955930c04e96f63ffb8c8f35ad02d9a917eceb727bf87c9ed3d831e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "lastenzug.dll"
		$s2 = "Lastenzug.dll"
		$azure = ".cloudapp.azure.com" wide

	condition:
		uint16be( 0 ) == 0x4d5a and 1 of ( $s* ) and $azure
}
rule SEKOIA_Rat_Lin_Gobrat_2023 : FILE
{
	meta:
		description = "This rule detect samples that are downloaded on the GobRAT C2 URL path /a, /b and /c."
		author = "Sekoia.io"
		id = "ca36a586-f87f-445f-95dc-52d447c1d2a2"
		date = "2023-06-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_lin_gobrat_2023.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "36cb17d9d118bd9692106c8aafab2462aacf1cdad3a6afb0e4f1de898a7db0e1"
		hash = "28a714f7cec4445dbd507b85016c8e96ed5e378bcabe2e422c499975122b3f03"
		hash = "1e80a084ab89da2375bc3cc2f5a37975edff709ef29a3fa2b4df4ccb6d5afe10"
		logic_hash = "b9831cefded9e48ef169aa56c18628a9871760ae613f75b232019b4798944e16"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "Z:/Go/awesomeProject3/main.go" wide ascii

	condition:
		uint32( 0 ) == 0x464c457f and filesize < 4000KB and $s1
}
rule SEKOIA_Infostealer_Win_Vidar_Str_Jul22 : FILE
{
	meta:
		description = "Detect the Vidar infostealer based on specific strings"
		author = "Sekoia.io"
		id = "1dc18694-aaac-41e6-979a-c06d5d62f5ea"
		date = "2022-07-26"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_vidar_str_jul22.yar#L1-L29"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "394d148155d46753df188a252678c5ce9d0aa321da8907e74b844d5aa8494a47"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		modification_date = "2022-08-23"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "vcruntime140.dll" ascii
		$str02 = "\\screenshot.jpg" ascii
		$str03 = "HARDWARE\\DESCRIPTION\\System\\CentralProcessor" ascii
		$str04 = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall" ascii
		$str05 = "%s\\%s\\%s\\chrome-extension_%s_0.indexeddb.leveldb" ascii
		$str06 = "\\CC\\%s_%s.txt" ascii
		$str07 = "\\Autofill\\%s_%s.txt" ascii
		$str08 = "\\History\\%s_%s.txt" ascii
		$str09 = "\\Downloads\\%s_%s.txt" ascii
		$str10 = "Content-Disposition: form-data; name=" ascii
		$str11 = "Exodus\\exodus.wallet" ascii
		$str12 = "*%DRIVE_REMOVABLE%*" ascii
		$opc = {55 8b ec 51 56 8b 75 ?? 33 c0 c7 46 14 ?? ?? ?? ?? 89 46 ?? 68 ?? ?? ?? ?? 8b ce 89 45 ?? 88 06 e8 1f b6 ff ff 8b c6 5e c9 c2 ?? ??}

	condition:
		uint16( 0 ) == 0x5A4D and ( 7 of them or $opc )
}
rule SEKOIA_Apt_Unk_Hrserv_Memory_Commands_Strings
{
	meta:
		description = "Detects HrServ web shell memory commands"
		author = "Sekoia.io"
		id = "1b5f442a-e758-4bd5-a612-8b504a542d29"
		date = "2023-11-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_unk_hrserv_memory_commands_strings.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a87c35658ded301c098f9ee8ee5886a54e89537eabd145cf82b0286c703a77d2"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "list all the process" ascii wide
		$ = "equal with cmd /c tasklist" ascii wide
		$ = "start target service by name" ascii wide
		$ = "query local process information by wmi." ascii wide
		$ = "upload local shellcode to" ascii wide

	condition:
		all of them
}
rule SEKOIA_Apt_Lazarus_Blindingcan_Rtti
{
	meta:
		description = "Detects BLINDINGCAN with RTTI"
		author = "Sekoia.io"
		id = "9a16c189-ffc1-4aa6-8582-298abaecd0ef"
		date = "2022-10-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_lazarus_blindingcan_rtti.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "fbec1f9a180782bf330d86facbada9af018741897c58f4ab6e0b52a1b38ae966"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = ".?AVCHTTP_Protocol@@" ascii wide fullword
		$s2 = ".?AVCFileRW@@" ascii wide fullword

	condition:
		all of them
}
rule SEKOIA_Luckymouse_Sysupdate_Payload : FILE
{
	meta:
		description = "Detects decryption routine prologue of sysupdate samples"
		author = "Sekoia.io"
		id = "97df4700-de35-49a0-869e-ed89a6d9cbdd"
		date = "2022-08-19"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/luckymouse_sysupdate_payload.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e8501a50c65330153e613ae5bd6bbfbe4372d85175c3ed81d202ec5f177a94be"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = { DB ?? ?? C9 66 B9 ?? ?? E8 FF FF FF FF }

	condition:
		filesize < 1MB and all of them
}
rule SEKOIA_Generic_Sharpshooter_Payload_6 : FILE
{
	meta:
		description = "Detects payload created by SharpShooter"
		author = "Sekoia.io"
		id = "53506a3e-b0d8-4a1e-88d9-485e829f25cb"
		date = "2023-02-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/generic_sharpshooter_payload_6.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "38919408d2d0a9f51822302f4f821bf5776f119bf0d1b54b71b1040c7ad59da5"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "function ${rc4Function}(r,o){for("
		$ = "function ${b64AndRC4Function}(r,o){var"
		$ = "Real-Time Scanning: No threats detected"
		$ = "Please wait while your file is being downloaded..."

	condition:
		3 of them and filesize < 2MB
}
rule SEKOIA_Apt_Unc4990_Explorer_Ps1
{
	meta:
		description = "Detects powershell script (explorer.ps1)"
		author = "Sekoia.io"
		id = "2e1abbbf-f9b7-4147-b7da-3544cbc4a5f1"
		date = "2024-02-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_unc4990_explorer_ps1.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5085f738e23b801c7e36408d189755086d91c0bb266af6738c80510eb85e598f"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s0 = "$(get-location).Path"
		$s1 = "+ \"\\Runtime Broker.exe"
		$s2 = "Start-Process -FilePath"
		$s3 = "-Wait;"
		$s4 = "Start-Sleep -s"

	condition:
		all of them and @s3- @s2 < 35
}
rule SEKOIA_Infostealer_Win_Titan : FILE
{
	meta:
		description = "Finds samples of the Titan Stealer"
		author = "Sekoia.io"
		id = "0adbe616-0d91-4b05-b7a8-812cd79f9252"
		date = "2023-01-12"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_titan.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "996dc320c83f57c47afe50ad032bac43ad1fbfbbd5a86e517089a062b0382993"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str0 = "/sendlog" ascii
		$str1 = "/stealer/grabfiles.go" ascii
		$str2 = "/stealer/installedsoft.go" ascii
		$str3 = "/stealer/screenshot.go" ascii
		$str4 = "/stealer/sendlog.go" ascii
		$str5 = "/stealer/userinformation.go" ascii
		$str6 = "C:/Program Files (x86)/Steam/config/" ascii
		$str7 = "/com.liberty.jaxx/IndexedDB/file__0.indexeddb.leveldb/" ascii
		$str8 = "MAC Adresses:" ascii
		$str9 = "/Coowon/Coowon/" ascii
		$str10 = "_/C_/Users/admin/Desktop/stealer_v7/stealer" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 5 of them
}
rule SEKOIA_Tool_Tacticalrmm_Installer_Strings : FILE
{
	meta:
		description = "Detects TacticalRMM installer"
		author = "Sekoia.io"
		id = "c4a0ba33-b458-4c2a-abfa-4c33481d6491"
		date = "2024-05-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_tacticalrmm_installer_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0f8d66eb1c9c6ed9571a1dd7de05072aec6d3cda874618889d4fd51e5965bb26"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "TacticalRMMInstaller" ascii
		$ = "tacticalagent-" ascii
		$ = "tactical/go" ascii
		$ = "tacticalrmm." ascii

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize > 3MB and filesize < 8MB and 3 of them
}
rule SEKOIA_Apt_Lazarus_Dll_C2_Comms : FILE
{
	meta:
		description = "Detects DLL communicating with the C2"
		author = "Sekoia.io"
		id = "9b379aa8-77ce-4c76-ab13-05e35ebfbdfe"
		date = "2023-04-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_lazarus_dll_c2_comms.yar#L1-L33"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "fe948451df90df80c8028b969bf89ecbf501401e7879805667c134080976ce2e"
		hash = "bb1066c1ca53139dc5a2c1743339f4e6360d6fe4f2f3261d24fc28a12f3e2ab9"
		hash = "dca33d6dacac0859ec2f3104485720fe2451e21eb06e676f4860ecc73a41e6f9"
		hash = "69dd140f45c3fa3aaa64c69f860cd3c74379dec37c46319d7805a29b637d4dbf"
		logic_hash = "b5ba5ae25822cf54d530d1a18c8196194d44e4fd76be1a0bf98c193772286282"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$x1 = "vG2eZ1KOeGd2n5fr" ascii fullword
		$s1 = "Windows %d(%d)-%s" ascii fullword
		$s2 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36" wide fullword
		$op1 = {B8 C8 00 00 00 83 FB 01 44 0F 47 E8 41 8B C5 48 8B B4 24 E0 18 00 00 4C 8B A4 24 E8 18 00 00 48 8B 8D A0 17 00 00 48 33 CC}
		$op2 = {33 D2 46 8D 04 B5 00 00 00 00 66 0F 1F 44 00 00 49 63 C0 41 FF C0 8B 4C 84 70 31 4C 94 40 48 FF C2}
		$op3 = {89 5C 24 50 0F 57 C0 C7 44 24 4C 04 00 00 00 C7 44 24 48 40 00 00 00 0F 11 44 24 60 0F 11 44 24 70 0F 11 45 80 0F 11 45 90}

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and ( filesize < 500KB and ( 1 of ( $x* ) or 2 of them ) or ( $x1 and 1 of ( $s* ) or 3 of them ) )
}
rule SEKOIA_Infostealer_Win_Xenostealer_Strings : FILE
{
	meta:
		description = "Finds XenoStealer standalone samples based on the strings"
		author = "Sekoia.io"
		id = "0a41788b-1fa7-44ff-af85-9c1ff1892aad"
		date = "2024-10-30"
		modified = "2024-12-19"
		reference = "https://github.com/moom825/XenoStealer/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_xenostealer_strings.yar#L1-L35"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "b74733d68e95220ab0630a68ddf973b0c959fd421628e639c1b91e465ba9299b"
		logic_hash = "1c48b15b8e9648c1c4d2f9c0a9ee3f4c48605fa44772b87a03ad81923e5adf15"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "XenoStealer" ascii wide
		$str02 = "$d05de59c-9ee5-4e7e-abb5-8f2cc3f72cd1" ascii
		$str03 = "SteamInfo" ascii
		$str04 = "TelegramInfo" ascii
		$str05 = "NgrokInfo" ascii
		$str06 = "pAuthInfo" ascii
		$str07 = "FoxMailInfo" ascii
		$str08 = "_hasNitro" ascii
		$str09 = "_games" ascii
		$str10 = "_profiles" ascii
		$str11 = "_cookies" ascii
		$str12 = "_creditCards" ascii
		$str13 = "_cryptoExtensions" ascii
		$str14 = "_passwordManagerExtensions" ascii
		$str15 = "ChromiumBrowsersLikelyLocations" ascii
		$str16 = "EdgeCryptoExtensions" ascii
		$str17 = "ChromePasswordManagerExtensions" ascii
		$str18 = "GeckoBrowserOptions" ascii
		$str19 = "get_programFiles" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 15 of them
}
rule SEKOIA_Apt_Badmagic_Ld_Dll_Loader_Pshscript : FILE
{
	meta:
		description = "Detects BadMagic DLL Loader powershell script"
		author = "Sekoia.io"
		id = "d4a23afc-693f-4fab-b2c4-15eecba047f7"
		date = "2023-05-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_badmagic_ld_dll_loader_pshscript.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8482521fe1f90c008948e551df35448b870145cf8b58f3c5019cafb66bb0ae36"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "$ModulePath = \"$folder_path\\$name"
		$ = "$ModuleExport ="
		$ = "start-job -ScriptBlock $ScriptBlock"
		$ = "Invoke-WebRequest -Uri"

	condition:
		all of them and filesize < 1KB
}
rule SEKOIA_Tool_Chisel_Strings : FILE
{
	meta:
		description = "Detects Chisel"
		author = "Sekoia.io"
		id = "667a8aa3-772b-45f1-8c89-acb7b976888d"
		date = "2024-03-14"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_chisel_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "fe389d9d0ae73c79f1040274e21135d4df645c5ac672fc824923f0a5a085be8a"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "tunnel.(*Tunnel).handleSSHChannel."
		$ = "server.(*Server).handleWebsocket"
		$ = "tunnel.(*udpHandler)"
		$ = "server.(*Server).tlsLetsEncrypt"
		$ = "cnet.(*wsConn).SetPingHandler.(*Conn)"
		$ = "tunnel.(*udpConns).dial."

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 15MB and 3 of them
}

rule SEKOIA_Backdoor_Win_Ketrum2
{
	meta:
		description = "Detect Ke3chang's Ketrum backdoor version 2"
		author = "Sekoia.io"
		id = "afcc349a-d44b-4b66-b86f-c62e700fa899"
		date = "2022-10-19"
		modified = "2024-12-19"
		reference = "https://www.intezer.com/blog/research/the-evolution-of-apt15s-codebase-2020/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_win_ketrum2.yar#L4-L35"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "271384a078f2a2f58e14d7703febae8a28c6e2d7ddb00a3c8d3eead4ea87a0c0"
		hash = "aa467945dd7b9b095e592fc96384bb385f2c95d00d5424e42bb6ab09827cb0ce"
		hash = "aacaf0d4729dd6fda2e452be763d209f92d107ecf24d8a341947c545de9b7311"
		hash = "ac5cb6e17f094068686225075251153e3eb21dc2d1ae744a97ab113cab034a36"
		logic_hash = "5317b133337ad333c97bbfa6c9d62aea5fd81f3b570f1d6b1ac93ea82062ef61"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "powershell.exe" wide
		$ = "cmd.exe" wide
		$ = "%s\\adult.sft" wide
		$ = "%s\\Notice" wide
		$ = "%s\\Message" wide
		$ = "\\Microsoft\\Media Player" wide
		$ = "Windows\\CurrentVersion\\Explorer\\Shell Folders" wide ascii
		$ = "Windows\\CurrentVersion\\Internet Settings" wide ascii

	condition:
		all of them and for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "49a60be4b95b6d30da355a0c124af82b35000bce8f24f957d1c09ead47544a1e" )
}
rule SEKOIA_Hacktool_Mimilite : FILE
{
	meta:
		description = "Detects Mimilite"
		author = "Sekoia.io"
		id = "abb92a9d-0978-4ef2-b2cc-53ce6e83e3e4"
		date = "2023-12-05"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_mimilite.yar#L1-L37"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "504bc58e1c4143cc2322d564b637b0e014a4ead44f56a75fe1202b0d0a2e8bbc"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$chunk = {
        FF C7
        48 63 D7
        46 0F B6 04 22
        41 03 F0
        81 E6 ?? ?? ?? ??
        7D ??
        FF CE
        81 CE ?? ?? ?? ??
        FF C6
        48 63 CE
        42 0F B6 04 21
        42 88 04 22
        46 88 04 21 }
		$imp1 = "CryptGetHashParam"
		$imp2 = "CryptDestroyHash"
		$imp3 = "CryptHashData"
		$imp4 = "CryptReleaseContext"
		$imp5 = "CryptCreateHash"
		$imp6 = "CryptAcquireContextA"
		$imp7 = "VirtualAlloc"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 200KB and all of ( $imp* ) and $chunk
}
rule SEKOIA_Backdoor_Win_Sponsor : FILE
{
	meta:
		description = "Detect the Sponsor backdoor"
		author = "Sekoia.io"
		id = "d410cdb7-a2a8-481e-a90a-49ef15a7a0e3"
		date = "2024-03-29"
		modified = "2024-12-19"
		reference = "https://www.welivesecurity.com/en/eset-research/sponsor-batch-filed-whiskers-ballistic-bobcats-scan-strike-backdoor/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_win_sponsor.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "e5ee874bd59bb2a6dec700686544e7914312abff166a7390b34f7cb29993267a"
		hash = "e2b74ed355d68bed2e7242baecccd7eb6eb480212d6cc54526bc4ff7e6f57629"
		hash = "2a99cf7d73d453f3554e24bf3efa49d8109da9e8543db815a8f813559d083f8f"
		hash = "c4dbda41c726af9ba3d9224f2e38fc433d2b60f4a23512437adeae8ef8986c57"
		logic_hash = "844104863e8e0c49da3a41d39fe210e01329eeaecec6ffc231aae12392773ef6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Content-Type: application/x-www-form-urlencoded"
		$ = "SYSTEM\\CurrentControlSet\\Control\\TimeZoneInformation"
		$ = "\\Uninstall.bat"
		$ = "\\config.txt"
		$ = "\\node.txt"

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Apt_Icepeony_Iceevent : FILE
{
	meta:
		description = "Detects IceEvent Backdoor"
		author = "Sekoia.io"
		id = "7d1f8b90-fde4-4d5c-a8a3-375db8aa88a1"
		date = "2024-10-21"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_icepeony_iceevent.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "07c291c9cea4430676c303128bbbb8e3"
		hash = "489b573b37ab8bc74cca3704e723b895"
		hash = "265f6cf778d26e62903fb295f89507e3"
		hash = "f5eb28dd29c91cc84818b74d7f138ff6"
		logic_hash = "8afe4a94513e9aa5d20849153c76cfe5c684c9a529710947930c76098a36540e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Created a process" ascii fullword
		$ = "CreateProcess failed: %d"
		$ = "bind error:"
		$ = "Error creating pip: %d"
		$ = "listen error:"

	condition:
		uint16be( 0 ) == 0x4d5a and 4 of them and filesize < 500KB
}
rule SEKOIA_Webshell_Icesword_Strings : FILE
{
	meta:
		description = "Detects icesword webshell"
		author = "Sekoia.io"
		id = "2c6b3cec-4200-4386-8cd5-4004c9b5b96a"
		date = "2024-11-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/webshell_icesword_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "0447352827e61696304a8e3d34e1d270"
		hash = "f49cfcda0abdefa385eda7ec7e7a5411"
		hash = "e1518388375ba772ed20503ec6dc6c8a"
		hash = "ecf08cd6af127e01f913354529174a23"
		logic_hash = "25ea8c1f4756595e63f09dfdfd1cb0e9bbf1d05e46150e22993de95d9f758385"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "&fsAction=rename&newName="
		$ = "&fsAction=copyto&dstPath="

	condition:
		2 of them and filesize < 100KB
}
rule SEKOIA_Apt_Kimsuky_Powershell : FILE
{
	meta:
		description = "Powershell scripts used by Kimsuky. If size < 3KB ok. If between 3 and 15, a check is needed"
		author = "Sekoia.io"
		id = "b7f812e0-d08b-40fe-908a-dc5765d6bc66"
		date = "2024-09-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_kimsuky_powershell.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "6babb53d881448dc58dd7c32fcd4208a"
		hash = "29ec7a4495ea512d44d33c9847893200"
		hash = "fde68771cebd7ecd81721b0dff5b7869"
		hash = "0c3fd7f45688d5ddb9f0107877ce2fbd"
		hash = "1a1723be720c1d9cd57cf4a6a112df79"
		logic_hash = "7436d8cba8a8caaf95786c38c4ceee4426dc7e36ae3eeed5d3162310cd76091d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = ".ToCharArray();[array]::Reverse(" ascii
		$ = ");$res = -join ($bytes -as [char[]]);Invoke-Expression $res;" ascii

	condition:
		all of them and filesize < 15KB
}
rule SEKOIA_Apt_Badmagic_Startngrok_Pshscript : FILE
{
	meta:
		description = "Detects BadMagic StartNgrok powershell script"
		author = "Sekoia.io"
		id = "94d64482-3033-4531-8530-58546364ac06"
		date = "2023-05-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_badmagic_startngrok_pshscript.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f15f9dc2c35f3f7cd816aa539c03b857254c3628c9b14eacca1110bb85b1a24c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "$ExecutablePath http \"\"file:///$Disk"
		$ = "write \"$ExecutablePath not found"
		$ = "$ng_proxy_string ="
		$ = "$ng_auth_token ="
		$ = "$env:ALLUSERSPROFILE\\$NGrokFolderName"

	condition:
		all of them and filesize < 1KB
}
rule SEKOIA_Infostealer_Win_Stealc_Str_Oct24 : FILE
{
	meta:
		description = "Finds Stealc standalone samples (or dumps) based on the strings"
		author = "Sekoia.io"
		id = "7448fafe-206c-4f9c-b5a3-cbabec12a45b"
		date = "2024-10-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_stealc_str_oct24.yar#L1-L27"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "4f7fece81c3fe1e56b57aed4030b48331b53443a200799046fe84c895b591a71"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "-nop -c \"iex(New-Object Net.WebClient).DownloadString(" ascii
		$str02 = "Azure\\.IdentityService" ascii
		$str03 = "steam_tokens.txt" ascii
		$str04 = "\"encrypted_key\":\"" ascii
		$str05 = "prefs.js" ascii
		$str06 = "browser: FileZilla" ascii
		$str07 = "profile: null" ascii
		$str08 = "url:" ascii
		$str09 = "login:" ascii
		$str10 = "password:" ascii
		$str11 = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe" ascii
		$str12 = "ChromeFuckNewCookies" ascii
		$str13 = "/c timeout /t 10 & del /f /q \"" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 9 of them
}
rule SEKOIA_Apt_Cloudatlas_Powershower_Obfuscated : FILE
{
	meta:
		description = "Detects obfuscated version of PowerShower"
		author = "Sekoia.io"
		id = "f76ab9d8-7753-4a17-aedd-fc9c3b8cd322"
		date = "2022-11-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_cloudatlas_powershower_obfuscated.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "fdb1edb3982eb5356cdf5fd1fa9fcc41d5048848b2a05589e87836ac0b05ec7a"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "{0}{1}{2}{3}{4}{5}{6}{7}{8}" ascii wide
		$s2 = "{000}{001}{002}{003}{004}{005}{006}{007}{008}" ascii wide
		$s3 = "::Unicode.GetString([System.Convert]::FromBase64String(" ascii wide

	condition:
		($s1 in ( 0 .. 100 ) or $s2 in ( 0 .. 100 ) ) and $s3 in ( filesize -200 .. filesize )
}
rule SEKOIA_Malware_Win_Passlib : FILE
{
	meta:
		description = "Detect the Passlib malware"
		author = "Sekoia.io"
		id = "609999e2-a644-4bf3-bce2-b0e1b0e7094b"
		date = "2022-07-28"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/malware_win_passlib.yar#L1-L32"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5e76f7c40a00182ee076720b4c19a45e82a8ce11740fdd8e9419f9d9e93cdb41"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Passlib test utility - Version %s" wide
		$ = "-l <full_path_to_dll_to_load_into_lsass> (arbitrary dll injection into LSASS)" wide
		$ = "-u <dll_to_unload_from_lsass> (arbitrary dll uninjection from LSASS)" wide
		$ = "DLL %s injection was successful requested!" wide
		$ = "DLL %s uninjection was successful requested!" wide
		$ = "Process %s was succesfully created with full privileges and system integrity!" wide
		$ = "full_path_to_volatile_payload_dll" wide
		$ = "%s: [%s]:[%s] (http_only:%d)" wide
		$ = "LEX server has been deployed at lsass." wide
		$ = "LEX client is using volatile payload at: %s" wide
		$ = "LEX client is using permanent payload at: %s" wide
		$ = "Passlib execution finished" wide
		$ = "Running on Passlib version %ws" wide
		$ = "There was a problem initializing passlib manager interface." wide
		$ = "Passlib running without high integrity" wide
		$ = "About to dump passwords through passlib manager interface" wide

	condition:
		uint16( 0 ) == 0x5A4D and filesize > 1500KB and all of them
}
rule SEKOIA_Apt_Aptk47_Maliciouslnk : FILE
{
	meta:
		description = "Detects APT-K-47 malicious LNK"
		author = "Sekoia.io"
		id = "2ccc8777-26fe-4018-9646-4ea91394fe78"
		date = "2024-11-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_aptk47_maliciouslnk.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "6a405d4e88b4acb9706e19a83aad9cf6"
		logic_hash = "865bb08f57affb3795853aa3c9f49577efb74df9b32e7760263b9fb08246a3ab"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[/c for /f" wide
		$ = "2^>nul') do copy" wide
		$ = "%F in ('where /r %Temp%" wide

	condition:
		uint32be( 0 ) == 0x4c000000 and all of them
}
rule SEKOIA_Tool_Bypassgodzilla : FILE
{
	meta:
		description = "Detects payload of BypassGodzilla"
		author = "Sekoia.io"
		id = "fa492f97-a46c-422d-a617-c503744ee22e"
		date = "2024-09-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_bypassgodzilla.yar#L1-L38"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "571c9042c627abba19ba1d591e2083eb"
		hash = "56cfc5a876f8f55bf184be9f368b6d8a"
		hash = "d4f7ca537701aee8849c474bc4df19d1"
		hash = "e4be04331c5f447b3ca03aa637d16c85"
		hash = "905fa3b692577a086ac654ef89e8b83d"
		logic_hash = "47e52267c73209c6191910ac21bca44acac2100be96250fd5dda1f889fb03b07"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$jsp_1a = "response.getWriter().write(\""
		$jsp_1b = "\".substring("
		$jsp_2a = "response.getWriter().write(java.util.Base64/*"
		$jsp_2b = "*/.getEncoder()/*"
		$jsp_2c = ".toByteArray(),true)));"
		$asp_1 = "[\"payload\"]).CreateInstance(\"LY\");"
		$asp_2 = "\\U00000045\\U00000071\\U00000075\\U00000061\\U0000006C\\U00000073(Context);"
		$php_1 = "=(\"!\"^\"@\").'ss'.Chr(\"101\").'rs';"
		$php_2 = "*/md5/*"
		$php_3 = "*/isset($_SESSION/*"
		$php_4 = "@set_time_limit(Chr(\"48\"))"

	condition:
		(( all of ( $jsp_* ) and ( @jsp_1b- @jsp_1a < 70 ) and ( @jsp_2b- @jsp_2a < 70 ) and ( @jsp_2c - @jsp_2a < 160 ) ) or ( all of ( $asp_* ) and ( @asp_2 > @asp_1 ) ) or ( all of ( $php_* ) ) ) and filesize < 30KB and true
}
rule SEKOIA_Apt_Polonium_Megacreep_Strings : FILE
{
	meta:
		description = "Tries to detect POLONIUM's MegaCreep implant"
		author = "Sekoia.io"
		id = "4d62d5bc-2ec9-58ef-bfe7-c0b04fa73b6f"
		date = "2022-10-12"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_polonium_megacreep_strings.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f4881e15854b082d8e6b8a28a7eb1518c559577b1b3ce76e404d67b1fe723fde"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"
		orig_id = "927c5fd6-0574-43bf-8db9-6ecc328estrin56c7"

	strings:
		$ = "[#!#]" ascii wide
		$ = "[$$%$$]" ascii wide
		$ = ".e##x##e" ascii wide
		$ = "WHLib.dll" ascii wide
		$ = "TestService.txt" ascii wide
		$ = "X = Stop" ascii wide
		$ = "Sess.dll" ascii wide
		$ = "filepathOnTarget" ascii wide
		$ = "FileNameOnMega" ascii wide
		$ = "Missing Parameter.. Format of command:" ascii wide
		$ = "Your Old K##E##Y is Wronge" ascii wide
		$ = "Your Upgrage Is Success" ascii wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 2MB and 3 of them
}
rule SEKOIA_Unknown_7777_Xlogin : FILE
{
	meta:
		description = "Detects the xlogin bind shell and its variants"
		author = "Sekoia.io"
		id = "ce0beffc-f957-43ef-a739-f4a1099a7a67"
		date = "2024-07-18"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/unknown_7777_xlogin.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "4d9067e7cf517158337123a30a9bd0e3"
		hash = "43ea387b8294cc4d0baaef6d26ff7c72"
		hash = "777d6f907da38365924a0c2a12e973c5"
		hash = "8542a3cbe232fe78baa0882736c61926"
		logic_hash = "1c38d8019734affdebac32050097bbcf89e9069fb2145a976588eca04ecc78df"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$string1 = { 2f 62 69 6e 2f 73 68 00 2f 74 6d 70 2f 6c 6f 67 69 6e }
		$string2 = { 2F 64 65 76 2F 6E 75 6C 6C [1-3] 2F 62 69 6E 2F 73 68 00 2D 63 }

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 180KB and ( ( @string2 - @string1 < 3400 ) )
}
rule SEKOIA_Apt_Apt29_Quarterrig
{
	meta:
		description = "Detects QUARTERRIG"
		author = "Sekoia.io"
		id = "e370ed7e-5e12-4add-95f3-3773ea8e2d03"
		date = "2023-04-19"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt29_quarterrig.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "9628418789a9bc24c7e44dbc9106ffa6316aefebe33b91c749b54cb5462b1309"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str_dll_name = "hijacker.dll"
		$str_import_name = "VCRUNTIME140.dll"
		$op_resolve_and_call_openthread = { 48 [6] 48 [6] 8B D8 E8 [4] [3] 33 D2 B9 FF FF 1F 00 FF D0 }
		$op_resolve_and_call_suspendthread = { E8 [4] 48 8B CB FF D0 83 F8 FF }

	condition:
		all of them
}
rule SEKOIA_Tool_Exploit_Rottenpotato_Strings : FILE
{
	meta:
		description = "Detects RottenPotato compiled binaries"
		author = "Sekoia.io"
		id = "453646d4-b128-40ea-8840-4c53b8f1e486"
		date = "2022-09-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_exploit_rottenpotato_strings.yar#L1-L27"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c634fcced6889caf895ddf57bab5564fb2b0a4c83f1d6ba4dae655f2e5d935db"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "WSAStartup failed with error: %d"
		$ = "getaddrinfo failed with error: %d"
		$ = "RPC -> send failed with error: %d"
		$ = "RPC-> Connection closed"
		$ = "COM -> bytes sent: %d"
		$ = "COM -> recv failed with error: %d"
		$ = "Running %S with args %S"
		$ = "[-] Failed to create proc: %d"
		$ = "Waiting for auth..."
		$ = "Auth result: %d"
		$ = "SeImpersonatePrivilege" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and 8 of them
}
rule SEKOIA_Apt_Gamaredon_Htmlsmuggling_2024 : FILE
{
	meta:
		description = "Detects HTML Smuggling webpages of Gamaredon used in 2024"
		author = "Sekoia.io"
		id = "8fa1f80b-2261-4d63-92d8-7c360be73fe2"
		date = "2024-09-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gamaredon_htmlsmuggling_2024.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "ab2807824e68d5efb4c896e1af82e693"
		hash = "926b7e65d0d61cd6ba9e085193ae8b1d"
		logic_hash = "9cd82f497fd7b82f02fec4ce1d131cd2685861c7c02aaae992e07a7d8bd30595"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "').innerHTML;window['" ascii fullword
		$ = "='at'+'ob';"
		$ = "]('*','');"
		$ = "display:none"
		$ = "0px;\" onerror=\""
		$ = "'ev'+'"
		$ = "<!DOCTYPE html PUBLIC"

	condition:
		5 of them and filesize < 1MB
}
rule SEKOIA_Tool_Pivotnacci
{
	meta:
		description = "Detects Pivotnacci"
		author = "Sekoia.io"
		id = "31ecb08a-fc92-4cbe-a865-7ce869a5fa6a"
		date = "2024-04-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_pivotnacci.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b0e4bc997775fb5ff258a23e07a58b4897a2ce9d3fffab86e93919857e566d18"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$pivotnacci = "pivotnacci"
		$s1 = "Socks server => %s:%s"
		$s2 = "The default listening address"
		$s3 = "Socks server for HTTP agents"
		$s4 = "Message returned by the agent web page"
		$s5 = "Password to communicate with the agent"
		$s6 = "To specify agent type in case is not automatically detected."

	condition:
		$pivotnacci and 3 of ( $s* )
}
rule SEKOIA_Apt_Rusticweb_Stealer : FILE
{
	meta:
		description = "Detects stealer used by RusticWeb"
		author = "Sekoia.io"
		id = "813072e0-28de-4cb7-b2cc-71d77a1e8508"
		date = "2024-01-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_rusticweb_stealer.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "68f802ef442e68cbcca789eae2bb8a4395af86699320e5a8101c07469e7555fb"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "-FTT=@"
		$s2 = "https://oshi.at"
		$s3 = "curl-T"
		$s4 = "upload/upload.php"
		$s5 = "cargo"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 4MB and 3 of them
}
rule SEKOIA_Rat_Win_Ratel_Strings : FILE
{
	meta:
		description = "Detect RATel based on characteristic strings"
		author = "Sekoia.io"
		id = "d0c8b89b-c811-47aa-9e03-717998c40d91"
		date = "2023-04-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_ratel_strings.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ff5640b03ec3e535cdb86c2a0feb52d0c472928ff88a36ec9f66ac8aa07c9f69"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "[-] Error when changing folder." ascii
		$s2 = "cmd.exe" wide
		$s3 = "back slash find: " ascii
		$s4 = "MOD_ALL:" wide
		$s5 = "MOD_PERSISTENCE" wide
		$s6 = "MOD_DESTRUCTION:" wide
		$s7 = "MOD_RECONNECT" wide
		$s8 = "Software\\Microsoft\\Windows\\CurrentVersion\\Run" wide
		$s9 = "powershell.exe -command \"([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] 'Administrator')\"" wide
		$s10 = "The command was executed successfully but no data was returned."
		$s11 = "[-] TIMEOUT IN CREATEPROCESS, but all the processes in the name of: " ascii
		$s12 = "we were well and truly killed." ascii

	condition:
		( uint16be( 0 ) == 0x4d5a ) and filesize > 500KB and filesize < 3MB and 8 of them
}
rule SEKOIA_Apt_Reaper_2Fa_Phishing_Webpage
{
	meta:
		description = "Detects Reaper 2FA phishing webpage"
		author = "Sekoia.io"
		id = "348ca2ad-c8f9-4aed-8a27-95caa3a34f4b"
		date = "2023-03-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_reaper_2fa_phishing_webpage.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "3f0ae0b35ea181b4712feeb34e866519921917179297148982e5298df9f133a9"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "setTimeout(checkUpload,"
		$ = "commChannel.addListener("
		$ = "else if(commType =="
		$ = "?dir=DOWN&method=READ&id="
		$ = "Content : base64_encode(upload_data)"
		$ = "$.post(upHttpRelayer"
		$ = "var ablyUpData = {"
		$ = "initComm();"
		$ = "function Next(arg) {"

	condition:
		3 of them
}

rule SEKOIA_Backdoor_Win_Nukesped_Andariel
{
	meta:
		description = "Detect the NukeSped variant type 1 used by Andariel in October 2023"
		author = "Sekoia.io"
		id = "a3601f0b-5782-4546-ac22-8a0514791f8f"
		date = "2023-11-27"
		modified = "2024-12-19"
		reference = "https://asec.ahnlab.com/en/59073/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_win_nukesped_andariel.yar#L4-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "d6421f3d0a3059e4104cfdceebb237269592f8ace7cc8d5bd613d239e4c010f4"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "4ce43c7e358e3951f4c4ebd050d570786cbb473ee353974fc7414e3d753da9f6" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "355485cbe2bec406d60a48d7d8d25c71d9ded3c508c87273d936a92b94720d9b" )
}
rule SEKOIA_Apt_Toneshell_Loader : FILE
{
	meta:
		description = "Detects loader of ToneShell (exception based)"
		author = "Sekoia.io"
		id = "b4bf284b-cab6-455e-a1c1-ad341d43bfdd"
		date = "2024-10-02"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_toneshell_loader.yar#L1-L40"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "41e0d172d900344a3692b88fff7527d9"
		hash = "782cf7183735935f3f7aad041cec3184"
		hash = "97c1f436028c58b51d4c92ee9c9ce424"
		hash = "d6c771f2afd8ce35e8727f95f3a3c6c4"
		hash = "b8520c5bad88ade394086cb7b1b7b631"
		hash = "0b3e8571e70a32490da19f6b3283151c"
		hash = "f6784c65ee115a9ae4c0fb03e0045285"
		hash = "38888696e5223c77f5f8680922396123"
		hash = "b52d0707e4e5d5c0d5fd5f5a177ba712"
		hash = "fd54c6d17ff91640b377ff41353efdaa"
		hash = "a6efe263acc794a212647a96e52ddf1f"
		hash = "6e8c80c5f2f9a1da504618e984d2a56c"
		hash = "0839666697ccc562a9c1fe77d6755931"
		hash = "f367f2fe580e556176b60da202c742a5"
		hash = "e8b2fcc14494ada2f28d1f6ecd2521a2"
		hash = "c08589e10812cc7d636dcbe2a36d43b4"
		hash = "fa848a05cfecc0c25cd21364c9516584"
		hash = "be231f7879d8d2159b67b7f277527268"
		hash = "2acd8b48202dcc30d88a871370c4f37a"
		hash = "72963bfc2837695f038680471d4f061c"
		logic_hash = "40e1b918a4d83a4918260d8b1cc56e5097665a366f94bd5068e4ae519e3a681b"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$exception = {00 00 00 00 2e 44 00 00}
		$code = {02 00 00 00 66 89 96}
		$kernel32 = "Kernel32.dll" wide
		$outputdbgstr = "OutputDebugStringA"
		$content = "ResetEvent"

	condition:
		uint16be( 0 ) == 0x4d5a and all of them and filesize < 2MB
}
rule SEKOIA_Tool_Petitpotato : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "72808202-a124-478e-bc60-59d35824b948"
		date = "2023-08-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_petitpotato.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "93a46c7765ad9f18c2176b98c91edf97827707ffdefcedc40078c87c30343508"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s2 = "set_FileName" ascii wide
		$s3 = "VarFileInfo" ascii wide
		$s4 = "PetitPotato.exe" ascii wide
		$s5 = "0.0.0.0" ascii wide

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 4MB and all of them
}

rule SEKOIA_Loader_Win_Svcready_Imports : FILE
{
	meta:
		description = "Finds samples of the SVCReady loader"
		author = "Sekoia.io"
		id = "e89aa736-acee-4881-b367-a9abfe9784ec"
		date = "2022-06-08"
		modified = "2024-12-19"
		reference = "https://threatresearch.ext.hp.com/svcready-a-new-loader-reveals-itself/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_svcready_imports.yar#L3-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f210c5363d19dbc822b8476f8ecfd86184af8f1c36819a6c868f171152e7cb74"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str0 = "Svc:RunPEDllNative" ascii
		$str1 = "RunPEDllNative::" ascii

	condition:
		uint16( 0 ) == 0x5A4D and filesize > 200KB and filesize < 2MB and pe.imports ( "GDI32.dll" , "Ellipse" ) and pe.imports ( "GDI32.dll" , "SelectObject" ) and pe.imports ( "GDI32.dll" , "GetStockObject" ) and pe.imports ( "GDI32.dll" ) == 3 and all of them
}
rule SEKOIA_Apt_Lazarus_Pondrat : FILE
{
	meta:
		description = "Detects PondRAT via mangled command names"
		author = "Sekoia.io"
		id = "a957c158-a79a-4d7a-8473-b6960cf02d9b"
		date = "2024-09-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_lazarus_pondrat.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "b62c912de846e743effdf7e5654a7605"
		hash = "61d7b2c7814971e5323ec67b3a3d7f45"
		hash = "ce35c935dcc9d55b2c79945bac77dc8e"
		hash = "f50c83a4147b86cdb20cc1fbae458865"
		hash = "05957d98a75c04597649295dc846682d"
		hash = "33c9a47debdb07824c6c51e13740bdfe"
		logic_hash = "49c5f635e3873a145479bb164838043921d012eef7dc8ad6373c43c8cf1f14e0"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$cmd_PondRAT1 = "_Z7MsgDownP11_TRANS_INFO" ascii
		$cmd_PondRAT2 = "_Z5MsgUpP11_TRANS_INFO" ascii
		$cmd_PondRAT3 = "_Z6MsgRunP11_TRANS_INFO" ascii
		$cmd_PondRAT4 = "_Z6MsgCmdP11_TRANS_INFO" ascii

	condition:
		3 of them and filesize < 4MB
}
rule SEKOIA_Hacktool_Earthworm_Strings : FILE
{
	meta:
		description = "Detects Mac/Win/Linux EarthWorm based on strings"
		author = "Sekoia.io"
		id = "6c9b0225-8c41-49f9-9745-245bc7ef942f"
		date = "2022-02-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_earthworm_strings.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0460c62fefc3d594ca758a37fbe1716182ffdca2920fedd32a707f7117702176"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "the read url is %s"
		$ = "--> %3d <-- (close)used tunnel %d , unused tunnel %d"
		$ = "ssocksd 0.0.0.0:%d <--[%4d usec]--> socks server"
		$ = "could not create one way tunnel"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a or uint32be( 0 ) == 0xcffaedfe ) and filesize < 100KB and 3 of them
}
rule SEKOIA_Miner_Lin_Xmrig_Strings : FILE
{
	meta:
		description = "Detects XMRig ELF"
		author = "Sekoia.io"
		id = "2f99020b-424c-4433-860c-5e9ab4e1f1de"
		date = "2022-09-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/miner_lin_xmrig_strings.yar#L1-L36"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "4946e5099d7d342c8cf6644146ffec8506e786a1d4de0b05ef039bcf2b0fdad2"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		modification_date = "2024-01-04"
		classification = "TLP:CLEAR"

	strings:
		$ = "XMRig "
		$ = "pool_wallet"
		$ = "IP Address currently banned"
		$ = "rigid"
		$ = "diff_current"
		$ = "shares_good"
		$ = "shares_total"
		$ = "avg_time"
		$ = "avg_time_ms"
		$ = "hashes_total"
		$ = "pool address"
		$ = "ping time"
		$ = "connection time"
		$ = "daemon+wss://"
		$ = "daemon+https://"
		$ = "daemon+http://"
		$ = "socks5://"
		$ = "stratum+ssl://"
		$ = "stratum+tcp://"

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 10MB and 7 of them
}
rule SEKOIA_Storm_1811_Files_Dat
{
	meta:
		description = "Detects files used in a campaign performed by the intrusion set Storm-1811"
		author = "Sekoia.io"
		id = "8b14f276-0c39-422b-9b19-d96b139a7ae8"
		date = "2024-06-10"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/storm_1811_files_dat.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "d1d5b76671cefe8b876ca8df50205a04ebbcd973f115919b901f6a7946492904"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "RuntimeBroker" ascii fullword
		$s2 = "InstallSpamFilters" ascii fullword
		$s3 = "newfile333.txt" ascii fullword
		$s4 = "Installing spam filter kb_outlook" ascii fullword
		$s5 = "s.zip" ascii fullword
		$s6 = "Update completed" ascii fullword
		$s7 = "Updates installed" ascii fullword
		$s8 = "update_log.tgz uploaded ok" ascii fullword
		$s9 = "HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run" ascii fullword
		$s10 = "runtimebroker_connect" ascii fullword

	condition:
		5 of them
}
rule SEKOIA_Bot_Lin_Zerobot_Dec22 : FILE
{
	meta:
		description = "Detect the linux Zerobot implant using specific strings"
		author = "Sekoia.io"
		id = "ce028297-a526-4a6a-95db-8762fb5895f6"
		date = "2022-08-05"
		modified = "2024-12-19"
		reference = "https://www.fortinet.com/blog/threat-research/zerobot-new-go-based-botnet-campaign-targets-multiple-vulnerabilities"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/bot_lin_zerobot_dec22.yar#L1-L30"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0f4faba9873fa360615b20bc637ecb40f56e6c7f65153f61a762e378320f94c1"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "rm -rf "
		$str02 = "wget http://"
		$str03 = "curl -O http://"
		$str04 = "tftp"
		$str05 = "-c get"
		$str06 = "ftpget -v -u anonymous -P"
		$str07 = "chmod 777"
		$str08 = "nohup"
		$str09 = "/dev/null 2>&1 &"
		$str10 = "zero."
		$str11 = "ppc64le"
		$str12 = "riscv64"
		$str13 = "s390x"
		$str14 = "rm -rf ~/.bash_history"
		$str15 = "history -c"

	condition:
		11 of ( $str* ) and filesize < 10KB
}
rule SEKOIA_Apt_Aptc60_Downloader_Strings : FILE
{
	meta:
		description = "Detects a simple downloader abusing wlrmdr.exe and used by APT-C-60"
		author = "Sekoia.io"
		id = "02fd6d5b-7211-46cc-bcff-ab5d78e459c0"
		date = "2024-09-05"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_aptc60_downloader_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "b14ef85a60ac71c669cc960bdf580144"
		logic_hash = "f05480834e6d91a852a190a2ecec05aaea1affa8a605a56c80962a9fbfc8f0c0"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "mydllmain" fullword
		$ = "-s 3600 -f 0 -t _ -m _ -a 11 -u" wide
		$ = "WlrMakeService" wide
		$ = "Trigger1" wide

	condition:
		uint16be( 0 ) == 0x4d5a and all of them and filesize < 500KB
}
rule SEKOIA_Apt_Apt28_Powershell_Ntlm_Stealer : FILE
{
	meta:
		description = "Detects the NTLM Stealer used by APT28 against UA energy sector"
		author = "Sekoia.io"
		id = "3fb5c472-6b1c-490e-b38f-4d4f1c472f43"
		date = "2023-09-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt28_powershell_ntlm_stealer.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "29d039bf7d7018ebbae187ae0f057161c3f9256076324f06167872adc0accfa7"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "'NTLM ' = [Convert]::ToBase64String"
		$ = ".Prefixes.Add('http://localhost:8080/')"
		$ = ".AddHeader('WWW-Authenticate', 'NTLM')"
		$ = "GetValues('Authorization');"
		$ = "[0] -split '\\s+';"

	condition:
		3 of them and filesize < 4000
}
rule SEKOIA_Apt_Tortoiseshell_Wateringhole_Script : FILE
{
	meta:
		description = "Detect's Tortoiseshell WH script"
		author = "Sekoia.io"
		id = "58c5ae66-fe09-497c-80bf-20feee4d95e7"
		date = "2023-05-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_tortoiseshell_wateringhole_script.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8ad886443b1bd17048054b57650d38cda1ffccc10fedfac86283a41daf956dc2"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "btoa(pluggin.toString())"
		$ = "btoa(document.referrer)"
		$ = "pluggin.push(navigator.plugins[i]"
		$ = "navigator.language"
		$ = "window.RTCPeerConnection"
		$ = "sha256(canvas.toDataURL("
		$ = "canvas.getContext('2d"
		$ = "noop = function() {},"

	condition:
		5 of them and filesize < 10000
}
rule SEKOIA_Crime_Sload_Zip_Archives : FILE
{
	meta:
		description = "Detects ZIP archives used by sLOad"
		author = "Sekoia.io"
		id = "5335ad65-bca5-4937-8634-46cbd7aa1b0e"
		date = "2022-08-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/crime_sload_zip_archives.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f2bc6464de008f2ce40acabd87ebbd91659d317f57e223118937ba51f70d0f7f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$pic = { 00 00 00 [6] 2E ( 70 6E 67 | 67 69 66 | 6a 70 67 | 6A 70 65 67 ) }
		$pdf = { 00 00 00 [8] 2E 70 64 66 }
		$vbs = { ( 4c 65 67 67 69 6d 69 | 66 69 73 63 ) 2e ( 77 73 66 | 76 62 73 ) }

	condition:
		uint16be( 0 ) == 0x504B and filesize < 30KB and all of them
}
rule SEKOIA_Apt_Gamaredon_Ddrdoh_Powershell_Backdoor : FILE
{
	meta:
		description = "Detects GAMAREDON's DDRDOH PowerShell Backdoor"
		author = "Sekoia.io"
		id = "3413dedd-e3ec-4231-8af7-c7f709ab82d7"
		date = "2023-01-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gamaredon_ddrdoh_powershell_backdoor.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "32d088affb65d410b2715fde28227792ea9f406e324de4a2e204e9850f0b81ce"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "hidden iex $env:" ascii wide
		$ = ".substring(0,4) -eq \"http" ascii wide
		$ = ".split('!')[1];" ascii wide
		$ = " -bxor $key[$i % $key.Length]" ascii wide
		$s = "Filter $fil | Select-Object VolumeSerialNumber" ascii wide

	condition:
		uint8( 0 ) == 0x24 and 4 of them and filesize < 10KB
}
rule SEKOIA_Infostealer_Win_Raccoon_Str_Takemypainback : FILE
{
	meta:
		description = "Detect Raccoon based on specific strings"
		author = "Sekoia.io"
		id = "2148636e-47c7-4bf2-8d1e-df68faf65111"
		date = "2022-10-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_raccoon_str_takemypainback.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "50d30828dab7e197619eeac4ebd2ab6692a9ac40a5091e23642cd1bdde8e9910"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str0 = "\\ffcookies.txt" wide
		$str1 = "TakeMyPainBack" wide
		$str2 = "wallet.dat" wide
		$str3 = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall" wide
		$str4 = "Network\\Cookies" wide

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule SEKOIA_Apt_Toddycat_Toddybox_Strings : FILE
{
	meta:
		description = "Detects ToddyCat's ToddyBox binary"
		author = "Sekoia.io"
		id = "fde3df24-ebd7-4327-998e-bddaa08835da"
		date = "2023-11-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_toddycat_toddybox_strings.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b71fad12d4485268cbeff98b8a8d6067ac8f62164be60cdb61f3f37ab471a247"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Wait a while to upload the next file..."
		$ = "[-] Error Msg: %s"
		$ = "[-] Error Msg: Connect Errors or Proxy Errors"
		$ = "[-] arg missing!"
		$ = "[-] Get module dir failed!"
		$ = "[-] Dir error!"
		$ = "Auto Get Proxy %S"
		$ = "Dropbox-API-Arg"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and all of them
}

rule SEKOIA_Rat_Win_Nighthawk : FILE
{
	meta:
		description = "Detects Nighthawk RAT"
		author = "Sekoia.io"
		id = "91bc3c5b-83fd-47f8-9652-df0f6a70b693"
		date = "2022-11-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_nighthawk.yar#L3-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "0551ca07f05c2a8278229c1dc651a2b1273a39914857231b075733753cb2b988"
		hash = "9a57919cc5c194e28acd62719487c563a8f0ef1205b65adbe535386e34e418b8"
		hash = "38881b87826f184cc91559555a3456ecf00128e01986a9df36a72d60fb179ccf"
		hash = "f3bba2bfd4ed48b5426e36eba3b7613973226983a784d24d7a20fcf9df0de74e"
		hash = "b775a8f7629966592cc7727e2081924a7d7cf83edd7447aa60627a2b67d87c94"
		logic_hash = "9a0c72de5b097f74d3c44586b8355c410470992f37d9a09c5f6db36ad6286d70"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$pattern1 = { 48 8d 0d ?? ?? ?? ?? 51 5a 48 81 c1 ?? ?? ?? ?? 48 81 c2 ?? ?? ?? ?? ff e2 }
		$pattern2 = { 66 03 D2 66 33 D1 66 C1 E2 02 66 33 D1 66 23 D0 0F B7 C1 }

	condition:
		uint16( 0 ) == 0x5A4D and filesize < 2MB and ( ( 1 of them ) or ( pe.section_index ( ".profile" ) and pe.section_index ( ".detourc" ) ) )
}
rule SEKOIA_Infostealer_Win_Monster_Stub : FILE
{
	meta:
		description = "Finds Monster Stealer stub (Python payload) based on specific strings."
		author = "Sekoia.io"
		id = "10d27d49-79ae-4edc-8c30-35506bdf2c42"
		date = "2024-08-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_monster_stub.yar#L1-L31"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "d6362c54b1f56ffa878423fbb1a3f57508d20e06b573c732f892494178a49200"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "https://t.me/monster_free_cloud" ascii
		$str02 = "MonsterUpdateService" ascii
		$str03 = "Monster.exe" ascii
		$str04 = "schtasks /create /f /sc daily /ri 30 /tn" ascii
		$str05 = "C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\StartUp\\" ascii
		$str06 = "banned_uuids" ascii
		$str07 = "banned_computer_names" ascii
		$str08 = "banned_process" ascii
		$str09 = "register_X_browsers" ascii
		$str10 = "register_payload" ascii
		$str11 = "tiktok_sessions.txt" ascii
		$str12 = "spotify_sessions.txt" ascii
		$str13 = "network_info.txt" ascii
		$str14 = "lolz.guru" ascii
		$str15 = "echo ####System Info####" ascii
		$str16 = "echo ####Firewallinfo####" ascii
		$str17 = "/injection/main/injection.js" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 10 of them
}
rule SEKOIA_Apt_Gamaredon_Gamaredon_Lnk_Usb_Spreader_Encoded : FILE
{
	meta:
		description = "Detects encoded version of Gamaredon LNK USB Spreader"
		author = "Sekoia.io"
		id = "e42bb654-d1aa-4219-b3da-dd4053d59a83"
		date = "2023-06-19"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gamaredon_gamaredon_lnk_usb_spreader_encoded.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "28358a4a6acdcdfc6d41ea642220ef98c63b9c3ef2268449bb02d2e2e71e7c01"
		logic_hash = "81ab55330b3003cb698ade7e14eaea5fb03e5d2d3dd310b7db682aeef9b51f6e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "[System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String(" ascii
		$s2 = " 1000000){" base64
		$s3 = "+\"\\$" base64
		$s4 = ",3\";" base64

	condition:
		$s1 at 0 and 3 of them and filesize < 4000
}
rule SEKOIA_Implant_Win_Havoc_Default_Strings : FILE
{
	meta:
		description = "Finds Havoc implants based on the embedded default strings"
		author = "Sekoia.io"
		id = "955c2211-4502-4258-ba4c-0d96a5624283"
		date = "2022-10-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_win_havoc_default_strings.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "dbf17e579071f265961657d73c6a2e51630b23e80376491df2e631cee5ffb1b4"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "C:\\Windows\\System32\\notepad.exe" ascii
		$str02 = "C:\\Windows\\SysWOW64\\notepad.exe" ascii
		$str03 = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36" ascii
		$str04 = "POST" wide
		$str05 = "\\??\\C:\\Windows\\System32\\ntdll.dll" wide
		$str06 = "X-Havoc: true" ascii
		$str07 = "X-Havoc-Agent: Demon" ascii
		$str08 = "/text.gif" ascii
		$str09 = "SeImpersonatePrivilege" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 6 of them
}

rule SEKOIA_Infostealer_Win_Eternity : FILE
{
	meta:
		description = "Detect the Eternity infostealer based on specific strings"
		author = "Sekoia.io"
		id = "0ed8d4bd-d57f-40a8-a709-d69531d59847"
		date = "2022-03-23"
		modified = "2024-12-19"
		reference = "hxxp://xssforumv3isucukbxhdhwz67hoa5e2voakcfkuieq4ch257vsburuid.]onion/threads/62331/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_eternity.yar#L3-L31"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "06f0f7f51100278160f5bc4f588bb6a9d749be308f879bd5704666bf90764bf9"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str0 = "Sending info to Eternity.." wide
		$str1 = "Debug mode, dont share this stealer anywhere." wide
		$str2 = "\\Growtopia.exe" wide
		$str3 = "Software\\Growtopia" wide
		$str4 = "Corrupting Growtopia.." wide
		$str5 = "Disabling Task Manager.." wide
		$str6 = "Deleting previous file from startup and copying new one." wide
		$str7 = "Hiding file in Startup folder.." wide
		$str8 = "Initializing File watcher.." wide
		$str9 = "Decoder: Failed to delete temp login. No problem, continuing.." wide
		$str10 = "dcd.exe" wide

	condition:
		uint16( 0 ) == 0x5A4D and ( for any i in ( 0 .. pe.number_of_sections -1 ) : ( pe.sections [ i ] . name == ".eter0" ) and for any i in ( 0 .. pe.number_of_sections -1 ) : ( pe.sections [ i ] . name == ".eter1" ) ) or 4 of ( $str* )
}

rule SEKOIA_Merlin_Win_Exe : FILE
{
	meta:
		description = "Detects Merling agent (PE)"
		author = "Sekoia.io"
		id = "c9c57f5e-26c3-43be-b2cf-10f5129d3be4"
		date = "2022-01-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/merlin_win_exe.yar#L4-L27"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6a42e9ea9749dc894788d80cd4395da026ef3c49eab1de6802e09f8b1751f5bd"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "B.symtab" ascii
		$s2 = "github.com/Ne0nd0g/merlin" ascii
		$s3 = "github.com/lucas-clemente" ascii
		$s4 = "SendMerlinMessage" ascii

	condition:
		uint16( 0 ) == 0x5A4D and for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "07b5472d347d42780469fb2654b7fc54" ) and all of them and $s1 at 591 and filesize < 15MB
}
rule SEKOIA_Apt_Gamaredon_Subtle_Paws : FILE
{
	meta:
		description = "SUBTLE-PAWS powershell backdoor used by Gamaredon"
		author = "Sekoia.io"
		id = "1950f886-97d2-4aa1-8f13-2947eba706e4"
		date = "2024-02-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gamaredon_subtle_paws.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "2fcebcf3401912e06ca4a34bf4e8d5318c6b2e08b00c4939ab932f3fb94cbc89"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "$splitter" ascii wide
		$s2 = "[System.Convert]::FromBase64String" ascii wide
		$s3 = "$_;$var2 =\"var1\";$var3" ascii wide
		$s4 = "foreach-object{$_|powershell -noprofile -}" ascii wide

	condition:
		$s1 and $s2 and ( $s3 or $s4 ) and filesize < 100KB
}
rule SEKOIA_Apt_Uta0218_Upstyle_Backdoor_Strings : FILE
{
	meta:
		description = "Detects UPSTYLE backdoor"
		author = "Sekoia.io"
		id = "098fbad7-efaf-4198-83de-208c2ae16f89"
		date = "2024-04-16"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_uta0218_upstyle_backdoor_strings.yar#L1-L27"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "bcba657b0b302f4b46f09bc4b815a581d22208b5d9f99e1233878f775241f92e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1_1 = "f.write(b'''import base64;exec(base64.b64decode(b" ascii
		$s1_2 = "atime=os.path.getatime(" ascii
		$s2_1 = "exec(base64.b64decode(functioncode))" ascii base64
		$s2_2 = "os.path.exists(systempth):" ascii base64
		$s2_3 = ".read().replace(b\"\\x00\",b\" \")" ascii base64
		$s3_1 = "if WRITE_FLAG:" ascii base64
		$s3_2 = "re.search(SHELL_PATTERN" ascii base64
		$s3_3 = "import threading,time,os,re,base64" ascii base64

	condition:
		filesize < 1500 and ( 2 of ( $s1_* ) or 2 of ( $s2_* ) or 2 of ( $s3_* ) )
}
rule SEKOIA_Rat_Win_Xworm_V3 : FILE
{
	meta:
		description = "Finds XWorm (version XClient, v3) samples based on characteristic strings"
		author = "Sekoia.io"
		id = "5fb1cbd3-1e37-43b9-9606-86d896f2150b"
		date = "2023-03-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_xworm_v3.yar#L1-L30"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "0016647c3c7031e744c0af6f9eadb73ab5cab1ca4f8ce7633f4aa069b62755cd"
		hash = "07e747a9313732d2dcf7609b6a09ac58d38f5643299440b827ec55f260e33c12"
		hash = "de0127ba872c0677c3594c66b2298edea58d097b5fa697302a16b1689147b147"
		logic_hash = "9a50f41f6c295f48597f6db3f5d9141345b3711ef110a0f925c881f3a75580ca"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "$VB$Local_Port" ascii
		$str02 = "$VB$Local_Host" ascii
		$str03 = "get_Jpeg" ascii
		$str04 = "get_ServicePack" ascii
		$str05 = "Select * from AntivirusProduct" wide
		$str06 = "PCRestart" wide
		$str07 = "shutdown.exe /f /r /t 0" wide
		$str08 = "StopReport" wide
		$str09 = "StopDDos" wide
		$str10 = "sendPlugin" wide
		$str11 = "OfflineKeylogger Not Enabled" wide
		$str12 = "-ExecutionPolicy Bypass -File \"" wide
		$str13 = "Content-length: 5235" wide

	condition:
		uint16( 0 ) == 0x5A4D and 8 of them
}
rule SEKOIA_Loader_Latrodectus_Dll : FILE
{
	meta:
		description = "Finds Latrodectus samples based on the specific strings"
		author = "Sekoia.io"
		id = "c60676ad-31cb-4f4d-9073-757a0ad7d23d"
		date = "2023-12-08"
		modified = "2024-12-19"
		reference = "https://twitter.com/Myrtus0x0/status/1732997981866209550"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_latrodectus_dll.yar#L1-L35"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "57aae1944eded14537cdc1c17b21cfc503687a416551b782fc76f8c7858e936e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "c:\\temp\\debug.pdb" fullword ascii
		$str02 = "Bottmp64.dll" fullword ascii
		$str03 = "scab" fullword ascii
		$str04 = "&wmic=" fullword ascii
		$str05 = "&ipconfig=" fullword ascii
		$str06 = "&systeminfo=" fullword ascii
		$str07 = "&domain_trusts=" fullword ascii
		$str08 = "&domain_trusts_all=" fullword ascii
		$str09 = "&net_view_all_domain=" fullword ascii
		$str10 = "&net_view_all=" fullword ascii
		$str11 = "&net_group=" fullword ascii
		$str12 = "&net_config_ws=" fullword ascii
		$str13 = "&net_wmic_av=" fullword ascii
		$str14 = "&whoami_group=" fullword ascii
		$str15 = "\"subproc\": [" fullword ascii
		$str16 = "&proclist=[" fullword ascii
		$str17 = "&desklinks=[" fullword ascii
		$str18 = "Update_%x" fullword wide
		$str19 = "Custom_update" fullword wide
		$str20 = "\\update_data.dat" fullword wide

	condition:
		uint16( 0 ) == 0x5A4D and 10 of them
}
rule SEKOIA_Downloader_Mac_Rustbucket : FILE
{
	meta:
		description = "RustBucket fake PDF reader"
		author = "Sekoia.io"
		id = "5a003b68-ad9a-47f9-b157-dd898181dac2"
		date = "2023-04-24"
		modified = "2024-12-19"
		reference = "https://www.jamf.com/blog/bluenoroff-apt-targets-macos-rustbucket-malware/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/downloader_mac_rustbucket.yar#L1-L31"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "38106b043ede31a66596299f17254d3f23cbe1f983674bf9ead5006e0f0bf880"
		hash = "bea33fb3205319868784c028418411ee796d6ee3dfe9309f143e7e8106116a49"
		hash = "7981ebf35b5eff8be2f3849c8f3085b9cec10d9759ff4d3afd46990520de0407"
		hash = "e74e8cdf887ae2de25590c55cb52dad66f0135ad4a1df224155f772554ea970c"
		logic_hash = "1b9e9a3f4fb4804eb94ab8d3573781d67f96d180b258cfc10be384eec44509ed"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$down_exec1 = "_down_update_run" nocase
		$down_exec2 = "downAndExec" nocase
		$encrypt1 = "_encrypt_pdf"
		$encrypt2 = "_encrypt_data"
		$error_msg1 = "_alertErr"
		$error_msg2 = "_show_error_msg"
		$view_pdf1 = "-[PEPWindow view_pdf:]"
		$view_pdf2 = "-[PEPWindow viewPDF:]"
		$macho_magic = {CF FA ED FE}
		$java_magic = {CA FE BA BE}

	condition:
		($macho_magic at 0 or $java_magic at 0 ) and 5 of them and filesize > 50KB
}
rule SEKOIA_Apt_Kimsuky_Sharpext_Jsexfil_Strings : FILE
{
	meta:
		description = "Detects the exfiltration JS code of SharpExt"
		author = "Sekoia.io"
		id = "c9ebd123-6450-4424-93d1-60322bd97bf6"
		date = "2022-07-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_kimsuky_sharpext_jsexfil_strings.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "37ea72b369baaced89f30f655901cc4a9d6a70d00cfca3b92a1015aca64d4e2c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "var req_url" ascii fullword
		$ = "var newReqId" ascii fullword
		$ = "chrome.tabs.query" ascii fullword
		$ = "payload.message.flags = new Object();" ascii fullword

	condition:
		all of them and filesize < 50KB
}

rule SEKOIA_Crybercrime_Prophetspider_Proxy : FILE
{
	meta:
		description = "Detects the Winntaa decryption loop or imphash"
		author = "Sekoia.io"
		id = "b7637fc3-bf81-40c4-869c-1c283574e0a7"
		date = "2022-02-17"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/crybercrime_prophetspider_proxy.yar#L3-L41"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "711ef3fc6ac488200415b7178c7f639ad9f6c72077bbebac2e6d5e0bed7120dd"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = { 56
        57
        48 8D 95 F0 FE FF FF
        31 C0
        66 21 02
        48 89 CE
        AC
        48 89 D7
        4C 89 C2
        88 D4
        30 C2
        0F B6 CA
        48 89 95 E8 FE FF FF
        AC
        30 E0
        AA
        E2 FA
        88 C8
        AA
        48 8D 85 F0 FE FF FF
        48 8B 95 E8 FE FF FF
        5F
        5E
        C3 }

	condition:
		uint16be( 0 ) == 0x4d5a and ( all of them or pe.imphash ( ) == "55e0b8e5b4d787c680ada4e450789a4d" )
}
rule SEKOIA_Tool_Edrsandblast_Cli_Strings : FILE
{
	meta:
		description = "Detects EDRSandblast CLI strings"
		author = "Sekoia.io"
		id = "baf3c68a-1d28-464e-8240-28cc66c8c151"
		date = "2024-01-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_edrsandblast_cli_strings.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "dd6b3836b2f368c8d0ed06770f2469ef70d850ae1a9da26c7835f1877379efe9"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[!] LSASS dump might fail if RunAsPPL" wide
		$ = "[!] You did not provide at least one option between" wide
		$ = "[+] Detecting userland hooks in all loaded DLLs" wide
		$ = "[+] Saving them to the CSV file" wide

	condition:
		uint16be( 0 ) == 0x4d5a and 4 of them
}
rule SEKOIA_Backdoor_Mul_Supershell_Client : FILE
{
	meta:
		description = "Detect the Supershell client (unpacked) by looking for github references"
		author = "Sekoia.io"
		id = "3498ca9e-a165-4dda-bc15-2e5d6d43d9c1"
		date = "2024-04-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_mul_supershell_client.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "a42906f8b392089fa1fe3ea264f6cb549ce5437b5ea253d9e1b8dd94bf115dad"
		hash = "d97b41e8cd6b63cd55c9a4f99ccadf5a9141088319bc9eb467d96e54080f3c85"
		hash = "2b54d1c064892a22f48b5742ba6da55bf62b73e5b1e0649e8b7880b286498735"
		hash = "0dedab2ef8d44f9beef782a29dd8f628dd0218b90f23f729b315660437019ccd"
		hash = "2484de7944889d784b8229f4fd756d3930e55c91654921019db4437877e30ab7"
		logic_hash = "93490f4a16fb7dcde671b82e3187341abf4fc95e965219233ca7689f3cd3855f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "github.com/NHAS/reverse_ssh/internal/client/"
		$ = "golang.org"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and all of them
}
rule SEKOIA_Apt_Andariel_Nestdoor_Variants_Strings : FILE
{
	meta:
		description = "Detects Nestdoor based on (weak) strings"
		author = "Sekoia.io"
		id = "dcfc48ad-f17b-4224-912b-b01740080fea"
		date = "2024-06-17"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_andariel_nestdoor_variants_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "bc01138d1fc079c2b778175742e121f10cb47f29cc4eb04d38b4f0f5740f05a4"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$v_11 = "Error occurs while reading" wide
		$v_12 = "{DECIMAL}" wide
		$v_13 = "lnk_" wide
		$v_21 = "Cannot connect with your ip and your operating system." wide
		$v_22 = "del /q /f %1" ascii
		$v_23 = "/f /tn %2" ascii

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and ( all of ( $v_1* ) or all of ( $v_2* ) )
}
rule SEKOIA_Crime_Sload_Powershellarchiveexfiltrator_Strings : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "3934696a-2116-49cb-9f75-3740767ad6f3"
		date = "2022-08-02"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/crime_sload_powershellarchiveexfiltrator_strings.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "7d6234ced7e5915a5b27ce2065772c74adb5c2398a8c972421fb5ec6b1b7771f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "if ($wr1 -or $wr2){"
		$ = "if ($zp1 -or $zp2){"
		$ = "-join ((65..90) + (97..122) | Get-Random -Count 16 | % {[char]$_});"

	condition:
		all of them and filesize < 1KB
}
rule SEKOIA_Exploit_Cve20191458_Strings : CVE_2019_1458 FILE
{
	meta:
		description = "Detects compiled exploit for CVE-2019-1458 (Generic)"
		author = "Sekoia.io"
		id = "0be4a550-0f0a-4596-ab32-aafaececf919"
		date = "2022-08-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/exploit_cve20191458_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8e22a79b3d7dc45d63062c71909faee61584c71b6ea7353ba0f40c00745a2075"
		score = 75
		quality = 80
		tags = "CVE-2019-1458, FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[-] Failed to create SploitWnd window"
		$ = "[+] ProcessCreated with pid %d!"
		$ = "[!] Exploit fail, test:0x%p,tagWND:0x%p, error:0x%lx"
		$ = "[*] tagWND: 0x%p, tagCLS:0x%p, gap:0x%llx"
		$ = "[*] Simulating alt key press"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 200KB and 3 of them
}
rule SEKOIA_Bot_Lin_Enemybot_April22 : FILE
{
	meta:
		description = "Detect enemybot based on command line observed in strings"
		author = "Sekoia.io"
		id = "5778c653-39ce-4f5d-b10b-1503b74e5041"
		date = "2022-04-14"
		modified = "2024-12-19"
		reference = "https://twitter.com/3xp0rtblog/status/137520616938452173://www.fortinet.com/blog/threat-research/enemybot-a-look-into-keksecs-latest-ddos-botnet"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/bot_lin_enemybot_april22.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "18ea06e60259f8d7d639b0e4659f0f5e166e9589d617f5766c06968af5e56aa6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$cmd0 = "wget http://%s/update.sh" ascii
		$cmd1 = "busybox wget http://%s/update.sh" ascii
		$cmd2 = "curl http://%s/update.sh" ascii
		$cmd3 = "chmod 777 update.sh" ascii
		$cmd4 = "rm -rf update.sh" ascii
		$str0 = "ENEMEYBOT" ascii xor
		$str1 = "KEKSEC" ascii xor
		$str2 = "/tmp/.pwned" ascii xor
		$str3 = "echo -e \"\x65\x6e\x65\x6d\x79"

	condition:
		( uint32( 0 ) == 0x464c457f or uint32( 0 ) == 0xfeedfacf ) and ( 4 of ( $cmd* ) or 2 of ( $str* ) )
}
rule SEKOIA_Apt_Implant_Xdealer_Vbs_Launcher_Strings : FILE
{
	meta:
		description = "Detects XDealer VBS Launcher"
		author = "Sekoia.io"
		id = "ebfc8a33-70dc-44d5-bc4a-07afc56f8254"
		date = "2024-03-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_implant_xdealer_vbs_launcher_strings.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e206189fd21ed7b3bf48a51d955df9055b7f7aa502b7fac52b274cc414adea0d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "Dim objws"
		$s2 = "Set objws="
		$s3 = "objws.Run \"\"\"C:\\ProgramData\\"

	condition:
		$s1 at 0 and all of them and filesize < 200
}
rule SEKOIA_Apt_Agent_Racoon_Strings : FILE
{
	meta:
		description = "Detects Agent Racoon used by CL-STA-0002"
		author = "Sekoia.io"
		id = "ec89f1db-0ba8-48c8-8c1a-c38c410f3e39"
		date = "2023-12-05"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_agent_racoon_strings.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "4e32606edffab0907e343ab2fef8642c0064d83c2933531619f9dee8957d2fe4"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Command failed:" wide
		$ = "Not uploaded:" wide
		$ = "Not downloaded:" wide
		$ = "xn--cc" wide
		$ = "xn--ac" wide
		$ = "xn--bc" wide
		$ = "cmd.exe" wide
		$ = ".xn--" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and all of them
}
rule SEKOIA_Apt_Cloudatlas_Powertunnel : FILE
{
	meta:
		description = "Detects PowerTunnel DLL of CloudAtlas"
		author = "Sekoia.io"
		id = "04981493-de8b-4662-ae81-8866c182f8b2"
		date = "2022-11-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_cloudatlas_powertunnel.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "aadb2739957d17c7e82e3abf7a178ab7b6e4a598fbbdb1a06d0c0531656d4ef6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "BeginGetHostEntry"
		$ = "get_AddressList"
		$ = "time_stop_delay_seconds"
		$ = "<connect><result>{0}</result></connect>"
		$ = "_CorDllMain"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and all of them
}
rule SEKOIA_Loader_Win_Squirrelwaffle_Doc : FILE
{
	meta:
		description = "Detect the Squirrelwaffle malicious document (not xls)"
		author = "Sekoia.io"
		id = "caadeac3-d4c7-4d84-b539-c03cc4c6c274"
		date = "2021-09-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_squirrelwaffle_doc.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b9f7c3605e25c8c7caa5f70e492d46fb70e7cb6002704440e7346ebfb2bbc7bf"
		score = 75
		quality = 76
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = {4f4b31203d2022636d64202f632072756e646c6c33322e65786520433a5c50726f6772616d446174615c777777312e646c6c2c6c647222}
		$s2 = {4145524f2042495a20434f4d20434f4f502045445520474f5620494e464f20494e54204d494c204d555345554d204e414d45204e4554204f52472050524f}

	condition:
		any of them and filesize > 100KB
}
rule SEKOIA_Hacktool_Fscan_Strings : FILE
{
	meta:
		description = "Detects fscan based on strings"
		author = "Sekoia.io"
		id = "6bef80c3-370c-4168-9d88-3fac88f986b1"
		date = "2023-12-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_fscan_strings.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b1c88af2f90921fab4ac32ef65e226a652b8df2915abc62de0a28af9ad59811c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Plugins.RdpScan.func1"
		$ = "Plugins.smb1AnonymousConnectIPC.func1"
		$ = "WebScan/WebScan.go"
		$ = "Plugins/CVE-2020-0796.go"
		$ = "Plugins.SshConn.func4"
		$ = "Plugins.PostgresScan"
		$ = "Plugins.(*FCGIClient).Request.func1"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 30MB and 4 of them
}
rule SEKOIA_Rootkit_Diamorphine_Strings : FILE
{
	meta:
		description = "Detects Diamorphine linux rootkit based on strings"
		author = "Sekoia.io"
		id = "5a28be5c-9a57-4204-a7cc-42dfcaa2c2da"
		date = "2024-10-21"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rootkit_diamorphine_strings.yar#L1-L31"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "622675e83bab630adc0f1c6c46c4d6d1"
		hash = "013b23213975d2646e2435f058afcacf"
		hash = "f068e83721f10ad74bb6f386a4375a91"
		hash = "ba9d6a6bbde602fd414cea09fcbd1aa0"
		hash = "fdd86788e295010c4e61bf6b589f340e"
		hash = "0d396c1763503b35a7f601831bd684de"
		hash = "66b8955188a3bda7ecdcd51cfd360313"
		hash = "1e4fd8c6bf0e381ac395d9bff1f98a31"
		hash = "ce08ce2b8bc1718052f5d0316e3e71b7"
		hash = "94982037875d4fdb17681866afc12ade"
		hash = "4fa2fe9ccde3e6bd4956e2b93ca5fcb6"
		hash = "644c4ce0bbe4f1f1e3aae537a111d5b8"
		hash = "fb7d594621fbb4f9bdb0eb74f6090ecd"
		hash = "9faf1493164e734f533f0ecfb1737a98"
		hash = "33d48b6c66715ab67a059ab940d759ff"
		logic_hash = "70e2e9155181a717f1c2483a748d5991488f0ba7371a2b3c9cfada2ecc5812f9"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "LKM rootkit" ascii fullword
		$ = "m0nad"

	condition:
		uint32be( 0 ) == 0x7f454c46 and all of them
}
rule SEKOIA_Crime_Sload_Vbs_Downloader_Strings_2 : FILE
{
	meta:
		description = "Detects an sLoad downloader based on strings"
		author = "Sekoia.io"
		id = "77ff0d21-9249-43b2-9a6d-87988a2dec3b"
		date = "2022-08-02"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/crime_sload_vbs_downloader_strings_2.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "06e4fcb6c48078c6c44d779820fc901b0f335b9495097ed28206826a959d0712"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "On Error Resume Next"
		$ = {0A [4] 3D 41 72 72 61 79}
		$ = { 2E 50 61 74 74 65 72 6E 20 3D 20 22 28 [4-10] 7C [4-10] 7C [4-10] 7C [4-10] 7C [4-10] 7C [4-10] 7C [4-10] 7C }

	condition:
		all of them and filesize < 20KB
}
rule SEKOIA_Hacktool_Mimikatz_Obfuscated : FILE
{
	meta:
		description = "Detects Mimikatz on strings obfuscation"
		author = "Sekoia.io"
		id = "bac4bb61-d250-4fc3-95a5-edd4e3c7ff83"
		date = "2022-07-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_mimikatz_obfuscated.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "9f75e10122df0f57382e939d82b0ab4047d3d42f198c59faa22177d6d5d9afd7"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$xor1 = "Benjamin Delpy" xor
		$xor2 = "sekurlsa" xor wide
		$xor3 = "minidumpfile.dmp" wide
		$xor4 = "lsadump_dcsync" xor wide
		$xor5 = "kuhl_m_lsadump_getSamKey" xor wide
		$b1 = "Benjamin Delpy" base64
		$b2 = "sekurlsa" base64 wide
		$b3 = "minidumpfile.dmp" base64 wide
		$b4 = "lsadump_dcsync" base64 wide
		$b5 = "kuhl_m_lsadump_getSamKey" base64 wide

	condition:
		uint16be( 0 ) == 0x4d5a and 3 of them and filesize < 5MB
}
rule SEKOIA_Guloader_Vbscript : FILE
{
	meta:
		description = "visual basic script delivering GuLoader"
		author = "Sekoia.io"
		id = "3472e403-b1e6-4fdf-9770-af42d505b556"
		date = "2024-02-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/guloader_vbscript.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "d0398b19ec57cff8afd52b06dc9da18788b1eefdf6be70650138e9b342d91d24"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = " = CreateObject(\"WScript.Shell\")"
		$s2 = " = Join("
		$s3 = ",vbnullstring)"

	condition:
		filesize < 20KB and all of them and #s1 > 1 and @s3- @s2 < 16
}
rule SEKOIA_Apt_Toneshell_Shellcode : FILE
{
	meta:
		description = "Detects first bytes of ToneShell used to call the shellcode or the code to check the MagicNumber (0x17 0x03 0x03)"
		author = "Sekoia.io"
		id = "5ac8d2e9-dbeb-42f9-8343-1281510d4411"
		date = "2024-10-02"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_toneshell_shellcode.yar#L1-L34"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0e164677681dce2aa75d3621d9f3df1449c3e67a3551817693856d80ccc48eca"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$code = {55 8b ec 83 ec 0c e8 85 00 00 00 6a 00 6a 00 6a 02 6a 00 6a 00 68 00 00 00 10}
		$MagicNumberParser = {
        B8 01 00 00 00
        6B C8 00
        8B 55 ??
        0F BE 04 0A
        83 F8 17
        75 ??
        B9 01 00 00 00
        C1 E1 00
        8B 55 ??
        0F BE 04 0A
        83 F8 03
        75 ??
        B9 01 00 00 00
        D1 E1
        8B 55 ??
        0F BE 04 0A
        83 F8 03
        }

	condition:
		any of them and filesize < 1MB
}
rule SEKOIA_Apt_Coathanger_Files : FILE
{
	meta:
		description = "Detects COATHANGER files"
		author = "Sekoia.io"
		id = "615f5ac1-14bc-4f5b-a02e-7b13cd179917"
		date = "2024-02-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_coathanger_files.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5406d8a99e16f08f1ffca548ea1dd1e27e7707506e796e0fc263bcdbb681632d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "/data2/"
		$ = "/httpsd"
		$ = "/preload.so"
		$ = "/authd"
		$ = "/tmp/packfile"
		$ = "/smartctl"
		$ = "/etc/ld.so.preload"
		$ = "/newcli"
		$ = "/bin/busybox"

	condition:
		( uint32( 0 ) == 0x464c457f or uint32( 4 ) == 0x464c457f ) and filesize < 5MB and 4 of them
}
rule SEKOIA_Hacktool_Ipmipwner_Strings : FILE
{
	meta:
		description = "Detects ipmiPwner script"
		author = "Sekoia.io"
		id = "2ac736b5-33bb-477f-a98c-57cc2744d251"
		date = "2023-12-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_ipmipwner_strings.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "122311e1791d018f08f3d5ecdf2e0efe3aa5bb913b2c1ce6a3797e8ceb2676eb"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "{status} Using the list of users that the {lgcyan}script"
		$ = "--host 192.168.1.12 -p 624 -uW /opt/SecLists/Usernames/"

	condition:
		all of them and filesize < 10KB
}
rule SEKOIA_Killfloor_Avkiller_Strings : FILE
{
	meta:
		description = "Kill-Floor strings"
		author = "Sekoia.io"
		id = "ae6908c3-27d4-4d2c-af21-a9548dfcd487"
		date = "2024-10-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/killfloor_avkiller_strings.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "9f16176ac20f7855fa960d321e156d69"
		hash = "4b019e9ed2de734e242602abce06f7c1"
		hash = "81ae32d9de8fd21acfc61d62f3292277"
		hash = "7cb2c4560e02c25463ec70e222ad0018"
		logic_hash = "e89d0936612104f98b7f56dca09702f31f07868f239c2d11dd738e015e757b3a"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "sc create aswArPot.sys type=kernel binpath=%s" ascii
		$ = "sc start aswArPot.sys" ascii
		$ = "[*] Enumerating target processes" ascii
		$ = "[*] Entering main loop... " ascii
		$ = "aswArPot.pdb" ascii
		$ = "SeConvertStringSecurityDescriptorToSecurityDescriptor" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and filesize > 20KB and 6 of them
}
rule SEKOIA_Apt_Muddywater_Powgoop_Decoded : FILE
{
	meta:
		description = "Detects decoded PowGoop malware"
		author = "Sekoia.io"
		id = "194cb9ef-da96-42b6-a3b5-b0aee7495f2c"
		date = "2022-01-13"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_muddywater_powgoop_decoded.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6654d8107bb2ad6344f1fa03c6525ed9a0b8e49627787355efe857e80a02eca4"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$h1 = "[System.Net.WebRequest]::Create(" ascii wide
		$h2 = "Headers.Add('Authorization'" ascii wide
		$h3 = "Headers.Add('Cookie',('value=' + $ec + ';')" ascii wide
		$h4 = ".GetResponse()" ascii wide
		$h5 = "GetResponseStream()" ascii wide
		$c1 = "return (65..90) + (97..122) | Get-Random -Count" ascii wide
		$c2 = "% {[char]$_}" ascii wide

	condition:
		filesize > 1KB and filesize < 1MB and ( $h2 in ( @h1 .. @h5 ) and $h3 in ( @h1 .. @h5 ) and $h4 in ( @h1 .. @h5 ) ) or ( $c2 in ( @c1 .. @c1 + 50 ) ) and true
}
rule SEKOIA_Infostealer_Win_Stormkitty_Exfil_Urls : FILE
{
	meta:
		description = "Detect the open-source StormKitty spyware by looking for the github path"
		author = "Sekoia.io"
		id = "d3b6e778-85da-4ab6-bc98-921897677485"
		date = "2022-04-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_stormkitty_exfil_urls.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ccf0efe9ccba8e37bc19fa241e2d7698b1a798a3e8026b1b6930452b8a8ba9b4"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "https://github.com/LimerBoy/StormKitty" ascii
		$telegram = "https://api.telegram.org" wide
		$discord = "https://cdn.discordapp.com" wide

	condition:
		uint16( 0 ) == 0x5A4D and all of them and ( #telegram > 3 or #discord > 3 )
}
rule SEKOIA_Apt_Apt_K_47_Walkershell : FILE
{
	meta:
		description = "Detects WalkerShell used by APT-K-47"
		author = "Sekoia.io"
		id = "201f8415-32d4-4af1-ba80-734554ced728"
		date = "2024-02-14"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt_k_47_walkershell.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0dffd8e4d6c244a4faea0f8b8cda1e544a732ad9982e7963b21d5f71080f8f5d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "\\n kuskure" ascii wide
		$s2 = "col.log.txt" ascii wide
		$s3 = "polor" ascii wide
		$s4 = "emit" ascii wide
		$s5 = "delta" ascii wide
		$s6 = "under process" ascii wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 4MB and all of them
}
rule SEKOIA_Infostealer_Win_Nekostealer : FILE
{
	meta:
		description = "Detect the NekoStealer infostealer based on specific strings"
		author = "Sekoia.io"
		id = "8b7d2708-9d33-4855-8e02-f6afedb7dda8"
		date = "2023-01-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_nekostealer.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f027775bebb48ceb128392040ec2ac8ad84f2a2009760c040e4d376c2f06b663"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$nek = "NekoStealer.Stealing" ascii
		$str01 = "\\Local Storage\\leveldb" wide
		$str02 = "======================= Discord Tokens =======================" wide
		$str03 = "======================== IP Information ========================" wide
		$str04 = "https://ipapi.co/" wide

	condition:
		uint16( 0 ) == 0x5A4D and ( #nek > 10 or all of ( $str* ) )
}

rule SEKOIA_Stealer_Win_Luca : FILE
{
	meta:
		description = "Detect Luca stealer. Open source Rust stealer."
		author = "Sekoia.io"
		id = "d2cc1442-0ba5-4e81-9fea-e9e078903eed"
		date = "2022-07-26"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/stealer_win_luca.yar#L3-L49"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "3694db49d84f92c70c51e4fe6f126fd56b3d7d8ed26619137fd55b0adb97865e"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "cookies"
		$ = "creditcards"
		$ = "/Default/Network/CookiesUser Data/Default/Network/Cookies_cookies"
		$ = "/Default/Web DataUser Data/Default/Web Data_webdata"
		$ = "SELECT action_url, username_value, password_value FROM loginsSELECT card_number_encrypted, name_on_card, expiration_month, expiration_year FROM credit_cardsSELECT host_key, name, encrypted_value, path, expires_utc, is_secure FROM cookiesLOCALAPPDATA"
		$ = "\\logsxc\\passwords_.txt"
		$ = " Name:"
		$ = "User: "
		$ = "Installed Languages:  "
		$ = "Operating System: "
		$ = "Used/Installed RAM:  GB "
		$ = "Cores available: "
		$ = "\\screen-.png"
		$ = "Username: "
		$ = "Computer name: "
		$ = "OS: "
		$ = "Language: "
		$ = "Hostname: "
		$ = "=> networks: B"
		$ = "=> system:total memory:  KB"
		$ = "used memory : "
		$ = "total swap  : "
		$ = "used swap   : "
		$ = "NB CPUs: "
		$ = "Passwords: "
		$ = "Wallets: "
		$ = "Files: "
		$ = "Credit Cards: "
		$ = "sensfiles.zip"

	condition:
		uint16( 0 ) == 0x5A4D and filesize > 4000KB and pe.rich_signature.toolid ( 0 , 0 ) and pe.number_of_resources == 0 and 15 of them
}
rule SEKOIA_Apt_Luckymouse_Sysupdate_Removing_Tool : FILE
{
	meta:
		description = "Detects the SysUpdate removing tool"
		author = "Sekoia.io"
		id = "711d059c-6229-49ef-aa20-a04d505838dc"
		date = "2022-08-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_luckymouse_sysupdate_removing_tool.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6a23fac99f26f4b0f9099e435ad53d9e83bf1322d190c565abf0c06dceeeaf34"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "KsWAYYYXXsFUCK" wide
		$ = "remove Services:%s %d" wide
		$ = "remove dir:%s %d" wide
		$ = "remove reg %d" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 11MB and 2 of them
}

rule SEKOIA_Wiper_Win_Caddywiper : FILE
{
	meta:
		description = "Detect CaddyWiper"
		author = "Sekoia.io"
		id = "869d44ff-79fc-403d-a45d-d33712da5bd0"
		date = "2022-03-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/wiper_win_caddywiper.yar#L4-L37"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "b66b179eac03afafdc69f62c207819eceecfbf994c9efa464fda0d2ba44fe2d7"
		hash = "ea6a416b320f32261da8dafcf2faf088924f99a3a84f7b43b964637ea87aef72"
		hash = "a294620543334a721a2ae8eaaf9680a0786f4b9a216d75b55cfd28f39e9430ea"
		logic_hash = "01a9910b42f402398bbe84546074256f56b10fe0f8524a9a9723aebe43b26a14"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "NETAPI32.dll" ascii
		$ = "DsRoleGetPrimaryDomainInformation" ascii

	condition:
		uint16( 0 ) == 0x5A4D and filesize > 5KB and filesize < 20KB and pe.number_of_sections == 3 and pe.number_of_resources == 0 and all of them or pe.imphash ( ) == "ea8609d4dad999f73ec4b6f8e7b28e55" or pe.imphash ( ) == "bae2d138abe43164fb5e95f313de3d14" or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "f0d4c11521fc3891965534e6c52e128b" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "6be6e878d1e8fed277c5feaf60b57a19" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "11f22fc72c3ca7dd6b874bda37c1fe82" )
}
rule SEKOIA_Backdoor_Lin_Bpfdoor : FILE
{
	meta:
		description = "Detect the BPFDoor backdoor used by the Chinese TA Red Menshen"
		author = "Sekoia.io"
		id = "1776ff6f-6fbb-4a81-bcad-c43b5117c67c"
		date = "2022-05-05"
		modified = "2024-12-19"
		reference = "https://github.com/Neo23x0/signature-base/blob/master/yara/mal_lnx_implant_may22.yar"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_lin_bpfdoor.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c917bd12731d761645adea72bc68c50927a0c2b0c31b2109f7065a992d338329"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$op1 = { e8 ?? ff ff ff 80 45 ee 01 0f b6 45 ee 3b 45 d4 7c 04 c6 45 ee 00 80 45 ff 01 80 7d ff 00 }
		$op2 = { 55 48 89 e5 48 83 ec 30 89 7d ec 48 89 75 e0 89 55 dc 83 7d dc 00 75 0? }
		$op3 = { e8 a? fe ff ff 0f b6 45 f6 48 03 45 e8 0f b6 10 0f b6 45 f7 48 03 45 e8 0f b6 00 8d 04 02 }
		$op4 = { c6 80 01 01 00 00 00 48 8b 45 c8 0f b6 90 01 01 00 00 48 8b 45 c8 88 90 00 01 00 00 c6 45 ef 00 0f b6 45 ef 88 45 ee }

	condition:
		uint32( 0 ) == 0x464c457f and filesize > 10KB and filesize < 50KB and ( all of ( $op* ) )
}
rule SEKOIA_Win_Loader_Astasialoader_Strings : FILE
{
	meta:
		description = "AstasiaLoader strings"
		author = "Sekoia.io"
		id = "8dfabf28-4b5a-43db-87e9-5b9080541ec3"
		date = "2023-08-16"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/win_loader_astasialoader_strings.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "44b6f7508a82ff6a4d65defc189303eeee393b5fd498de73d74d0a2c75c87401"
		logic_hash = "02a7bed506865d761ec03b8de4b7fc636b71f48c62e933013f2ffa23deabb62e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "newuploaders" wide
		$s2 = "\\infected.exe" wide
		$s3 = "AstasiaLoader" wide
		$s4 = "Astasia.pdb" ascii
		$s5 = "ip-api.com/line/?fields=hosting" wide
		$s6 = "https://api.telegram.org/bot" wide
		$s7 = "currentscript.txt" wide
		$s8 = "sessionlog.txt" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize > 50KB and filesize < 1MB and 5 of them
}

rule SEKOIA_Tool_Win_Blackfly_Proxy_Config : FILE
{
	meta:
		description = "Detect Blackfly proxy configuration tool"
		author = "Sekoia.io"
		id = "c8a8be5d-bd28-4306-9466-ad582e53fede"
		date = "2023-02-28"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_win_blackfly_proxy_config.yar#L4-L29"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a421d933209f3a81f7430f1b933074701a1fc965c1b4bc321cc7b4e89802f483"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "c:\\ProgramData\\l.dat"
		$ = "C:\\ProgramData\\b.dat"
		$ = "winmm_DotNetfile.dll"

	condition:
		pe.imphash( ) == "ff47f65286cc51a1328bc94efbf4007f" or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "f5923d4331f7e84fbbbd6fd84b6d3e6a" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "56acc10233c711a4eba9ca9aeab47e30" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "824dcebe93ac83bf5c95c781a60b3578" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "ec716a08b5e647f5c00c5dfc079dfa62" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "5cb63f7392c9e05c22e89cd86bd7f718" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "ee04e245066e25edd3062d823f15deda" ) or ( uint16( 0 ) == 0x5A4D and 1 of them )
}
rule SEKOIA_Unk_Quad7_Updtae_Reverse_Shell_Strings : FILE
{
	meta:
		description = "Reverse shell used by Quad7 operators"
		author = "Sekoia.io"
		id = "02d5394e-734c-4744-b293-1bf96bf1518c"
		date = "2024-08-19"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/unk_quad7_updtae_reverse_shell_strings.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "40b5ac87ff87634c48fdd2cf64ccb66b"
		hash = "4b8e97260d9ef6ca774675be682d9c8c"
		logic_hash = "0e816716d4d7fd35617b1ac96ae99d68d5b96f64f8bef83d0f6aba2a3fbd9326"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "User-Agent: IOT"
		$ = "/iot/post"
		$ = "vender"
		$ = "Response:  %s"
		$ = "cmdNum"
		$ = "UPDTAE"
		$ = "cmdResult"

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 5MB and 4 of them
}
rule SEKOIA_Strongpity_Malware : FILE
{
	meta:
		description = "Detects obfuscation used by StrongPity"
		author = "Sekoia.io"
		id = "f19a685c-599d-42cf-a5d8-7a2375102f97"
		date = "2024-02-26"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/strongpity_malware.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "14be5eccb4e754d6dad69cda51a924241cc75f5d758bc2d746acfe41e1684b3a"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$rand_edi = {E8 ?? ?? ?? ??    8B F8 81 E7 07 00 00 80    79 ?? 4F 83 CF F8 47 83 C7 02}
		$rand_esi = {E8 ?? ?? ?? ?? 8B F0 81 E6 07 00 00 80 79 ?? 4E 83 CE F8 46 83 C6 02}
		$rand_eax = {E8 ?? ?? ?? ??    25 07 00 00 80 79 ?? 48 83 C8 F8 40 83 C0 02}

	condition:
		uint16be( 0 ) == 0x4d5a and #rand_edi + #rand_esi + #rand_eax > 20
}
rule SEKOIA_Apt_Cloudatlas_Stagescalldllmainafterexec
{
	meta:
		description = "Detects call to dllmain after execution of exported function"
		author = "Sekoia.io"
		id = "a24b7887-87f6-44e3-80c5-cd117e694595"
		date = "2023-10-31"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_cloudatlas_stagescalldllmainafterexec.yar#L1-L46"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6d1c1717b4012e72b0069068158265dfd215cd7685a5489aba3de4a9024bfa28"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$chunk_1 = {
        55
        8B EC
        83 EC 10
        C7 45 ?? 00 00 00 00
        83 7D ?? 00
        74 ??
        8B 45 ??
        89 45 ??
        8B 4D ??
        8B 51 ??
        03 55 ??
        89 55 ??
        8B 45 ??
        8B 48 ??
        03 4D ??
        89 4D ??
        6A 00
        6A 00
        FF 75 ??
        FF 55 ??
        68 00 80 00 00
        6A 00
        8B 55 ??
        52
        FF 15 ?? ?? ?? ??
        C7 45 ?? 01 00 00 00
        8B 45 ??
        8B E5
        5D
        C2 04 00
        }

	condition:
		any of them
}
rule SEKOIA_Rat_Win_Dcrat_Qwqdanchun : FILE
{
	meta:
		description = "Find DcRAT samples (qwqdanchun) based on specific strings"
		author = "Sekoia.io"
		id = "8206a410-48b3-425f-9dcb-7a528673a37a"
		date = "2023-01-26"
		modified = "2024-12-19"
		reference = "https://github.com/qwqdanchun/DcRat"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_dcrat_qwqdanchun.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e6f8664e57ecce3bd7b2af5c67d564d526b32d12218b772b0e9f53709044e14d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "DcRatByqwqdanchun" wide
		$str02 = "U09GVFdBUkVcTWljcm9zb2Z0XFdpbmRvd3NcQ3VycmVudFZlcnNpb25cUnVuXA==" wide
		$str03 = "Po_ng" wide
		$str04 = "Pac_ket" wide
		$str05 = "Perfor_mance" wide
		$str06 = "Install_ed" wide
		$str07 = "get_IsConnected" ascii
		$str08 = "get_ActivatePo_ng" ascii
		$str09 = "isVM_by_wim_temper" ascii
		$str10 = "save_Plugin" wide
		$str11 = "timeout 3 > NUL" wide
		$str12 = "ProcessHacker.exe" wide
		$str13 = "Select * from Win32_CacheMemory" wide

	condition:
		uint16( 0 ) == 0x5A4D and 8 of them
}
rule SEKOIA_Tool_Edrsandblast_Api_Strings : FILE
{
	meta:
		description = "Detects EDRSandblast API strings"
		author = "Sekoia.io"
		id = "8a5dc171-dce8-4b5a-96e9-53dd1855e8c1"
		date = "2024-01-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_edrsandblast_api_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "cd6afe68cf04e4949add323e0b5af5ea577b3dca07743e312e8236bf5c937672"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[!] Required driver file not present at" wide
		$ = "[!] New uninstall / install attempt failed" wide
		$ = "[!] Kernel offsets are missing from the CSV" wide
		$ = "[+] Downloading wdigest offsets from the MS Symbol Server" wide
		$ = "[+] Check if EDR callbacks are registered on process" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and 4 of them
}
rule SEKOIA_Apt_Gamaredon_Doc_External_Template : FILE
{
	meta:
		description = "Detects malicious templates used by Gamaredon"
		author = "Sekoia.io"
		id = "5f6bbf92-2fdf-428d-af49-2d3e754c29d7"
		date = "2023-01-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gamaredon_doc_external_template.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "51412081fa7e62fa342b0ed6da18009b39e3952286f2bd319fbe10e0b1761e02"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "USERPROFILE" ascii
		$ = "msxml2" ascii
		$ = "T24gRXJyb3IgUmVzdW1lIE5leHQ" ascii

	condition:
		uint32be( 0 ) == 0xd0cf11e0 and filesize < 100KB and all of them
}
rule SEKOIA_Apt_Lazarus_Lambload_Timecheck : FILE
{
	meta:
		description = "Detects timeCheck routine in LambLoad"
		author = "Sekoia.io"
		id = "8807c752-c34e-4c3b-9194-3a9bd2575a88"
		date = "2023-11-27"
		modified = "2024-12-19"
		reference = "https://www.microsoft.com/en-us/security/blog/2023/11/22/diamond-sleet-supply-chain-compromise-distributes-a-modified-cyberlink-installer/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_lazarus_lambload_timecheck.yar#L1-L67"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "019e559f3596cf83f7e7ada05f6550b50b2d45d577600fa549470b98af93e23b"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$chunk_1 = {
        0F 85 ?? ?? ?? ??
        8D 85 ?? ?? ?? ??
        50
        E8 ?? ?? ?? ??
        83 C4 ??
        83 78 ?? ??
        0F 85 ?? ?? ?? ??
        8B 48 ??
        83 F9 ??
        0F 8C ?? ?? ?? ??
        83 F9 ??
        0F 8D ?? ?? ?? ??
        8B 40 ??
        83 F8 ??
        0F 8C ?? ?? ?? ??
        83 F8 ??
        0F 8D ?? ?? ?? ??
        53
        57
        68 ?? ?? ?? ??
        8D 85 ?? ?? ?? ??
        6A ??
        50
        C7 85 ?? ?? ?? ?? ?? ?? ?? ??
        }

	condition:
		uint16be( 0 ) == 0x4d5a and any of them
}
rule SEKOIA_Apt_Oilrig_Oilbooster_Strings : FILE
{
	meta:
		description = "Detects OilBooster malware based on strings"
		author = "Sekoia.io"
		id = "001d12bc-1e7e-4a6c-9172-66687d08d827"
		date = "2023-12-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_oilrig_oilbooster_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "9562d373ba7602d250aec1eefa2d671da64e897e490da284ffa0e310074266cf"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "/rt.ovf" wide ascii
		$ = "User-Agent: " wide ascii
		$ = "/me/drive/items" wide ascii
		$ = "client_secret" wide ascii

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 5MB and all of them
}
rule SEKOIA_Malware_Httpshell_Strings : FILE
{
	meta:
		description = "Detects HTTPShell based on URL patterns"
		author = "Sekoia.io"
		id = "58f25666-5dc2-4f4f-9fac-fc05d1e66945"
		date = "2024-01-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/malware_httpshell_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8f6f6ad459cc6edd80432528a507ca2cb84e6859be94f2e1caaea801bf809375"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "/api/v1/Client/Info" wide ascii
		$ = "/api/v1/Client/Download" wide ascii
		$ = "/api/v1/Client/Upload" wide ascii
		$ = "/api/v1/Client/Info" base64 base64wide
		$ = "/api/v1/Client/Download" base64 base64wide
		$ = "/api/v1/Client/Upload" base64 base64wide

	condition:
		3 of them and filesize < 5MB
}
rule SEKOIA_Tool_Multidump_Strings : FILE
{
	meta:
		description = "Detects MultiDump"
		author = "Sekoia.io"
		id = "4897c898-01dd-40d2-bf28-266231c88f8a"
		date = "2024-03-19"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_multidump_strings.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8d98cf89d56f5a949023364f94c8d55f8875408b082fb52e118f99d46533124d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "--nodump\tDisable LSASS dumping"
		$ = "-r 192.168.1.100:5000"
		$ = "Path to save procdump.exe"
		$ = "[!] CreateFileW [R] Failed With Error"
		$ = "LSASS is Running, Continuin"
		$ = "Dumping LSASS Using ProcDump"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and 3 of them
}

rule SEKOIA_Loader_Win_Revil_Loader
{
	meta:
		description = "Detect the REvil loader using DDL side loading. The detected ressource is a legitimate executable used to load the malicious .dll containing the ransomware"
		author = "Sekoia.io"
		id = "3c293e87-e2d7-475a-9536-8b991961fa11"
		date = "2021-07-19"
		modified = "2024-12-19"
		reference = "https://www.mcafee.com/blogs/other-blogs/mcafee-labs/revil-ransomware-uses-dll-sideloading"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_revil_loader.yar#L4-L34"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "1fe9b489c25bb23b04d9996e8107671edee69bd6f6def2fe7ece38a0fb35f98e"
		hash = "50416e50797cf88a48d086e718c003e2d10c3847b1a251669d6f10f8d3546e03"
		hash = "66490c59cb9630b53fa3fa7125b5c9511afde38edab4459065938c1974229ca8"
		hash = "81d0c71f8b282076cd93fb6bb5bfd3932422d033109e2c92572fc49e4abc2471"
		hash = "aae6e388e774180bc3eb96dad5d5bfefd63d0eb7124d68b6991701936801f1c7"
		hash = "d55f983c994caa160ec63a59f6b4250fe67fb3e8c43a388aec60a4a6978e9f1e"
		hash = "dc6b0e8c1e9c113f0364e1c8370060dee3fcbe25b667ddeca7623a95cd21411f"
		hash = "df2d6ef0450660aaae62c429610b964949812df2da1c57646fc29aa51c3f031e"
		logic_hash = "15680c5e5d801d65e581869ad88d89863c8a51e3f94a3d2f37c02c5fd14df07f"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$crypto = ".\\crypto\\" ascii
		$dropped_name1 = "MsMpEng.exe" wide
		$dropped_name2 = "mpsvc.dll" ascii

	condition:
		all of ( $dropped_name* ) and #crypto > 100 and for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "33bc14d231a4afaa18f06513766d5f69d8b88f1e697cd127d24fb4b72ad44c7a" )
}
rule SEKOIA_Malware_Venom_Agent_Strings : FILE
{
	meta:
		description = "Detects Venom agent strings"
		author = "Sekoia.io"
		id = "87633510-8b39-4eb1-b95b-4ebff21f3bba"
		date = "2022-08-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/malware_venom_agent_strings.yar#L1-L31"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "66dd1cb7bd66fcf78c8eaad8aaab7cfd624b898b7b479e571bacf5c4e48edac9"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "dispather.handleDownloadCmd"
		$ = "dispather.handleUploadCmd"
		$ = "dispather.handleShellCmd"
		$ = "dispather.handleSocks5Cmd"
		$ = "dispather.handleLForwardCmd"
		$ = "dispather.localLForwardServer"
		$ = "dispather.handleRForwardCmd"
		$ = "dispather.AgentHandShake"
		$ = "dispather.AgentParseTarget"
		$ = "dispather.PipeWhenClose"
		$ = "dispather.handleSshConnectCmd"
		$ = "node.(*NetworkTopology).InitNetworkMap"
		$ = "node.CopyNet2Node"
		$ = "node.(*Node).CommandHandler.func1"
		$ = "node.(*Buffer).WriteLowLevelPacket"
		$ = "protocol.(*Packet).ResolveDat"
		$ = "netio.InitTCP.func2"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 10MB and 6 of them
}
rule SEKOIA_Apt_Oilrig_Saitama_Backdoor_May2022 : FILE
{
	meta:
		description = "Detects tje Saitama backdoor"
		author = "Sekoia.io"
		id = "4ea8c27f-c441-4616-a29b-2b5dfdd3bd20"
		date = "2022-05-13"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_oilrig_saitama_backdoor_may2022.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b3876995fde9c26052c39859684cec05e8c1bc8e2a62946b49ed328e84499dc6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = { 7E [4] 7E [4] 59 0A 02 8E 69 06 28 [4] D1 0B 02 16 7E [4] 7E [4] 07 }
		$ = "systeminfo | findstr" wide
		$ = "powershell -exec bypass -enc" wide
		$ = "SendAndReceive : {0}" wide
		$ = "SleepSecond : Start" wide

	condition:
		uint16be( 0 ) == 0x4d5a and 2 of them
}
rule SEKOIA_Infostealer_Win_Xfiles : FILE
{
	meta:
		description = "Detect the X-FILES infostealer based on specific strings"
		author = "Sekoia.io"
		id = "3ad3ee19-6be8-484b-943c-05813cdcbd18"
		date = "2022-02-03"
		modified = "2024-12-19"
		reference = "https://twitter.com/3xp0rtblog/status/1375206169384521730"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_xfiles.yar#L1-L50"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "404ee02fa1905f49c3c3ca525cfb3c5ba1d2ec46554239035c1891d21f547a2c"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$xfi0 = "Telegram bot - @XFILESShop_Bot" wide
		$xfi1 = "Telegram support - @XFILES_Seller" wide
		$brw0 = "\\Google\\Chrome\\User Data\\Default\\Network\\Cookies" wide
		$brw1 = "\\Chromium\\User Data\\Default\\Cookies" wide
		$brw2 = "\\Slimjet\\User Data\\Default\\Cookies" wide
		$brw3 = "\\Vivaldi\\User Data\\Default\\Cookies" wide
		$brw4 = "\\Opera Software\\Opera GX Stable\\Cookies" wide
		$brw5 = "\\Opera Software\\Opera Stable\\Cookies" wide
		$crp00 = "Tronlink" wide
		$crp01 = "NiftyWallet" wide
		$crp02 = "MetaMask" wide
		$crp03 = "MathWallet" wide
		$crp04 = "Coinbase" wide
		$crp05 = "BinanceChain" wide
		$crp06 = "GuardaWallet" wide
		$crp07 = "EqualWallet" wide
		$crp08 = "BitAppWallet" wide
		$crp09 = "iWallet" wide
		$crp10 = "Wombat" wide
		$crp11 = "Zcash" wide
		$crp12 = "Armory" wide
		$crp13 = "Bytecoin" wide
		$crp14 = "Jaxx" wide
		$crp15 = "Exodus" wide
		$crp16 = "Ethereum" wide
		$crp17 = "AtomicWallet" wide
		$crp18 = "Guarda" wide
		$crp19 = "Coinomi" wide
		$crp20 = "Litecoin" wide
		$crp21 = "Dash" wide
		$crp22 = "Bitcoin" wide

	condition:
		uint16( 0 ) == 0x5A4D and any of ( $xfi* ) or 5 of ( $brw* ) and 20 of ( $crp* )
}
rule SEKOIA_Infostealer_Win_Leaf : FILE
{
	meta:
		description = "Find samples of Leaf Stealer based on specific strings"
		author = "Sekoia.io"
		id = "17d8e384-1092-4f27-b4f7-c0c0f7efcaa3"
		date = "2023-02-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_leaf.yar#L1-L32"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f8c0ff694c9f7a02613000d85a40f6b400dcca60711e589f7ccd3546f571aea6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "Leaf $tealer" ascii
		$str02 = "KiwiFolder" ascii
		$str03 = "key_wordsFiles" ascii
		$str04 = "**[Click to copy](https://superfurrycdn.nl/copy/" ascii
		$str05 = "Early_Verified_Bot_Developer" ascii
		$str06 = "getCookie.<locals>.<genexpr>" ascii
		$str07 = "C:\\Program Files (x86)\\Steam\\config" ascii
		$str08 = "[crunchyroll](https://crunchyroll.com)" ascii
		$str09 = "-m pip install" ascii
		$str10 = "taskkill /im " ascii
		$str11 = "/loginusers.vdf" ascii
		$str12 = "mot_de_passe" ascii
		$str13 = "Interesting files found on user PC" ascii
		$str14 = "NationsGlory/Local Storage/leveldb" ascii
		$str15 = "wppassw.txt" ascii
		$str16 = "wpcook.txt" ascii
		$str17 = "ProcesName < 1 >" ascii
		$str18 = "Metamask_" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 10 of them
}

rule SEKOIA_Rat_Win_Romcom_Payload
{
	meta:
		description = "Detect the RomCom malware"
		author = "Sekoia.io"
		id = "c391f84c-f0cb-42d8-a8d8-d59725bf74c2"
		date = "2022-11-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_romcom_payload.yar#L4-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "56f016df8e9165522e18f34bdb7c3044ee8927f53dd6818fa2b3d6424191d8e0"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "160ed1cdf6e9321cef19cfed6a63b4b5557dd35e174b821bf8a81c4146fa6536" )
}
rule SEKOIA_Koiloader_Powershell_Reflective_Loading : FILE
{
	meta:
		description = "Powershell script loading service.exe (related to Koi Loader)"
		author = "Sekoia.io"
		id = "9bbe4cea-3e64-4377-bf93-def9fb629734"
		date = "2024-03-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/koiloader_powershell_reflective_loading.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "27deec01027a73129c6c8057eff1b48190c89ac18dcd7c390fc177d82a897290"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "[Byte[]]$image" ascii fullword
		$s2 = "function GDT"
		$s3 = "function GPA"
		$s4 = "GDT @([IntPtr], [UInt32], [IntPtr], [IntPtr], [UInt32], [IntPtr]) ([IntPtr])"
		$s5 = "$marshal::GetDelegateForFunctionPointer($CTAddr, $CTDeleg)"

	condition:
		$s1 at 0 and 4 of them
}
rule SEKOIA_Apt_Oilrig_Odagent_Strings : FILE
{
	meta:
		description = "Detects ODAgent malware based on strings"
		author = "Sekoia.io"
		id = "1c5c0eb5-7c6f-4a34-b2e2-4a7c6d7030d6"
		date = "2023-12-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_oilrig_odagent_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "14a1399ff3519632e3bbb6eea0d44e9908cfc03728bd26f610ab75fff6a8d2c6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "application/x-www-form-urlencoded" ascii wide
		$ = "dly>" ascii wide
		$ = "DELETE" ascii wide
		$ = "nok!" ascii wide
		$ = ".c:/content" ascii wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 5MB and all of them
}
rule SEKOIA_Apt_Gelsemium_Wolfsbane_Launcher : FILE
{
	meta:
		description = "Detects Gelsemium's WolfsBane launcher"
		author = "Sekoia.io"
		id = "26fbf4df-aa08-47b6-a73c-e8f80a408454"
		date = "2024-11-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gelsemium_wolfsbane_launcher.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "87e437cf74ce4b1330b8af9ff71edae2"
		logic_hash = "9ecc3a8cb82f6183c263dde03a14f721d2e3aeb2338afc28e0368c323e5d51a9"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "rm -f /dev/shm/sem*%s"
		$ = "/etc/ld.so.preload"
		$ = "kill -9 %d 2>/dev/null"
		$ = "/,1d' %s 2>/dev/null"

	condition:
		uint32be( 0 ) == 0x7F454C46 and filesize < 500KB and all of them
}
rule SEKOIA_Tool_Juicypotato_Exploit_Strings : FILE
{
	meta:
		description = "Detects the JuicyPotato exploit based on strings"
		author = "Sekoia.io"
		id = "03d697ae-69a7-490b-8b3c-9a8c21fb46a2"
		date = "2022-09-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_juicypotato_exploit_strings.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ef23ea2931a1b6e094c0d7bb813305c09a2214ce36680ae057926dfdc1105c80"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "JuicyPotato v%s"
		$ = "-t createprocess call: <t> CreateProcessWithTokenW"
		$ = "-p <program>: program to launch"
		$ = "-l <port>: COM server listen port"
		$ = "-m <ip>: COM server listen address"
		$ = "-n <port>: RPC server listen port"
		$ = "Error - Unknown NTLM message type..."
		$ = "[+] authresult %d"
		$ = "Waiting for auth..."

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 500KB and 2 of them
}
rule SEKOIA_Downloader_Mac_Rustbucket_Swiftloader
{
	meta:
		description = "Detect the file com.EdoneViewer in the new version of RustBucker 2023-10"
		author = "Sekoia.io"
		id = "bdbc95db-5d58-4c96-91f9-34b653e67f50"
		date = "2023-12-05"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/downloader_mac_rustbucket_swiftloader.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "7c5bf60787bfd076c8806eaa4f1185f5b9fda69008376624ab3d17f207eb16a4"
		hash = "bc90adde92bd47b4de7d384e5b20c1a1791d603629bd0fcba4b550fb35e93216"
		hash = "c9a7b42c7b29ca948160f95f017e9e9ae781f3b981ecf6edbac943e52c63ffc8"
		logic_hash = "acb5b88f8af53cd3d83de0fd6c3049ce017f038dc7c8b31f70e65e60bf713dfb"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "/Users/ghost/Desktop/EdoneViewer/EdoneViewer/"
		$ = "EdoneViewerApp.swift"

	condition:
		1 of them
}
rule SEKOIA_Tool_Htran_Strings : FILE
{
	meta:
		description = "Detects HTran based on strings"
		author = "Sekoia.io"
		id = "0184937e-eefa-4c6d-ae00-9b0af80dc7db"
		date = "2022-09-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_htran_strings.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6a414cec8ad623c735779b9005074f88b07d88b29b23918d98a541a2612a3fa0"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "-slave <ConnectHost> <ConnectPort> <TransmitHost> <TransmitPort>"
		$ = "-tran <ConnectPort> <TransmitHost> <TransmitPort>"
		$ = "-listen <ConnectPort> <TransmitPort>"
		$ = "[-] There is a error...Create a new connection."
		$ = "[+] Start Transmit (%s:%d <-> %s:%d) ......"
		$ = "[+] Accept a Client on port %d from %s"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and 3 of them
}
rule SEKOIA_Infostealer_Win_Phoenix : FILE
{
	meta:
		description = "Finds Phoenix Stealer samples based on specific strings"
		author = "Sekoia.io"
		id = "d63a8fcf-f897-4c36-a6ce-4bd4ae0154e5"
		date = "2023-06-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_phoenix.yar#L1-L33"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c8a3a9a36c978cfc28fc6e21af10894161279dfd2e2ad665c3296fda10f6303d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "nkbihfbeogaeaoehlefnkodbefgpgknn" ascii
		$str02 = "Discord\\Tokens.txt" ascii
		$str03 = "SOFTWARE\\OpenVP" ascii
		$str04 = "config_dir" ascii
		$str05 = "| Last Login:" ascii
		$str06 = "| Games:" ascii
		$str07 = "| Host:" ascii
		$str08 = "| Port:" ascii
		$str09 = "| User:" ascii
		$str10 = "| Pass:" ascii
		$str11 = "Grabber.rar" ascii
		$str12 = "\\GHISLER\\wcx_ftp.ini" ascii
		$str13 = "Clipboard.txt" ascii
		$str14 = "PROCESSOR_ARCHITECTURE" ascii
		$str15 = "PROCESSOR_IDENTIFIER" ascii
		$str16 = "Log.txt" ascii
		$str17 = "xXxXxXxXxXx" ascii
		$str18 = "hq101ejedmwcvvasd02kw" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 15 of them and filesize > 500KB
}
rule SEKOIA_Apt_Apt28_Htmlsmuggling
{
	meta:
		description = "Detects some kind of HTMLSmuggling used by APT28"
		author = "Sekoia.io"
		id = "2e20c992-d971-4c0f-99b3-a7d528c7055a"
		date = "2023-09-11"
		modified = "2024-12-19"
		reference = "https://www.zscaler.com/blogs/security-research/steal-it-campaign"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt28_htmlsmuggling.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "47cca1d0a0843c8df43661ee8188dae86cce06e1f3982973871863728d328e89"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "click();" ascii
		$s2 = "window.location.replace("

	condition:
		$s1 in ( @s2 .. @s2-100 )
}
rule SEKOIA_Apt_Lazarus_Vhd_Ransomware_Loader : FILE
{
	meta:
		description = "Detects VHD ransomware x64 loader "
		author = "Sekoia.io"
		id = "377f3ec5-fa2a-431e-93d2-6a1eb9e01d28"
		date = "2022-11-28"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_lazarus_vhd_ransomware_loader.yar#L1-L30"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "33000fd79b5aae59dcbf445bb4d0d65cf5f939f376a4e3d9e23e14b11ca297da"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = { B8 64 [8] B8 75 [8] B8 6D [8] B8 70 [8] B8 2E [8] B8 62 [8] B8 69 [8] B8 6E }
		$ = { 48 63 ?? ?? ??
        48 8B ?? ?? ??
        0F BE ?? ??
        B9 ?? ?? ?? ??
        48 6B ?? ??
        48 8B ?? ?? ??
        0F BE ?? ??
        ?? ??
        48 63 ?? ?? ??
        48 8B ?? ?? ??
        88 ?? ??
        EB }
		$ = { 25 00 73 00 5c [3-15] 25 00 64 00 25 00 64 00 2e 00 62 00 69 00 6e }

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 200KB and 2 of them
}

rule SEKOIA_Dotnet_Injector_New_Payload : FILE
{
	meta:
		description = "New dotnet injector"
		author = "Sekoia.io"
		id = "b0a1d471-5381-4fa8-8563-7e72ecd15bed"
		date = "2022-12-21"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/dotnet_injector_new_payload.yar#L3-L30"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8b5e2f6e7947471e10e0ec85eef1cebe1904c2e77b7cfe92e578ebe306041842"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$f1 = "DownloadFile" ascii
		$f2 = "StreamReader" ascii
		$f3 = "ReadToEnd" ascii
		$f4 = "Reverse" ascii
		$f5 = "Load" ascii
		$f6 = "StringToByteArray" ascii
		$s1 = "Admin" wide
		$s2 = "User" wide
		$p1 = "\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\" wide
		$p2 = ".lnk" wide

	condition:
		filesize < 300KB and all of ( $f* ) and all of ( $s* ) and all of ( $p* ) and dotnet.is_dotnet
}
rule SEKOIA_Apt_Mustangpanda_Tonedrop : FILE
{
	meta:
		description = "TONEDROP strings"
		author = "Sekoia.io"
		id = "39df631c-5766-4804-838f-6c9b800c0cc9"
		date = "2023-06-19"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_mustangpanda_tonedrop.yar#L1-L43"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "97f9138810fbc56fa1cab671865b3234f63fcd0f9a15ba012dfe76e86c6dbd48"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$window1 = "PROCMON_WINDOW_CLASS" ascii wide
		$window2 = "OLLYDBG" ascii wide
		$window3 = "WinDbgFrameClass" ascii wide
		$window4 = "OllyDbg - [CPU]" ascii wide
		$window5 = "Immunity Debugger - [CPU]" ascii wide
		$errormsg1 = "Unable to open file %s for writing" ascii wide
		$proc_01 = "cheatengine-x86_64.exe" ascii wide
		$proc_02 = "ollydbg.exe" ascii wide
		$proc_03 = "ida.exe" ascii wide
		$proc_04 = "ida64.exe" ascii wide
		$proc_05 = "radare2.exe" ascii wide
		$proc_06 = "x64dbg.exe" ascii wide
		$proc_07 = "procmon.exe" ascii wide
		$proc_08 = "procmon64.exe" ascii wide
		$proc_09 = "procexp.exe" ascii wide
		$proc_10 = "processhacker.exe" ascii wide
		$proc_11 = "pestudio.exe" ascii wide
		$proc_12 = "systracerx32.exe" ascii wide
		$proc_13 = "fiddler.exe" ascii wide
		$proc_14 = "tcpview.exe" ascii wide
		$opcodes_check_PEsize = {C7 85 94 FD FF FF 2C 02}
		$opcodes_ShellExecute_1 = {C7 45 BC 53 68 65 6C}
		$opcodes_ShellExecute_2 = {C7 45 C0 6C 45 78 65}
		$opcodes_ShellExecute_3 = {C7 45 C4 63 75 74 65}
		$opcodes_ShellExecute_4 = {66 C7 45 C8 41 00}

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 8MB and 3 of ( $window* ) and $errormsg1 and 10 of ( $proc_* ) and 3 of ( $opcodes* )
}
rule SEKOIA_Malware_Valleyrat_Strings_Config : FILE
{
	meta:
		description = "ValleyRAT strings based on HIVE KEYS and config. "
		author = "Sekoia.io"
		id = "bb186ab7-60cd-487e-8b9c-c2ff8f121454"
		date = "2024-08-19"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/malware_valleyrat_strings_config.yar#L1-L27"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "b1887a48e59ac7b1b1742854d2a228af"
		hash = "f6c69e83ce61aacacfbc410345008268"
		hash = "63ad42e03aca6ce447fb447e21aeb385"
		hash = "e1d41e5fdfebf8062911ef3c3853b807"
		hash = "e6cafb4136a9438227086a5826eafe10"
		hash = "54ba4bbeacd1521164a40e92262b15f6"
		logic_hash = "89a3d3ca32f9c57e932686f0ed03821350770f82e598948ed86414e231e27a30"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$key1 = "IpDateInfo" ascii fullword
		$key2 = "IpDate" ascii fullword
		$key3 = "SelfPath" ascii fullword
		$config1 = {7c 00 69 00 3a 00 }
		$config2 = {7c 00 70 00 3a 00 }

	condition:
		uint16be( 0 ) == 0x4d5a and 1 of ( $key* ) and $config2 in ( @config1 .. @config1 + 100 ) and filesize > 300KB and filesize < 100MB
}
rule SEKOIA_Apt_Polonium_Technocreep_Strings : FILE
{
	meta:
		description = "Tries to detect TechnoCreep implant"
		author = "Sekoia.io"
		id = "dad79df3-b081-458e-9c14-1d5e2b43ba91"
		date = "2022-10-12"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_polonium_technocreep_strings.yar#L1-L27"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6fbd14d39f215b835c0fe7709041ca982774be42d389397d19a41fda6f7a00d1"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.1"
		classification = "TLP:CLEAR"

	strings:
		$ = "file name : " ascii wide
		$ = "copy to : " ascii wide
		$ = "download" ascii wide
		$ = "persistence" ascii wide
		$ = "/cmdResult created!" ascii wide
		$ = "/downloadsResulat created!" ascii wide
		$ = "Downloading will take minets..." ascii wide
		$ = "powershell -Command \"$c1 = " ascii wide
		$ = "Missing Parameter.. Format of command:" ascii wide
		$ = "File Fath On Target Device Not Exists>" ascii wide
		$ = "/MissingDownloadParameter.txt" ascii wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and 4 of them
}
rule SEKOIA_Weevely_Webshell_Payload : FILE
{
	meta:
		description = "Detects weevely webshell"
		author = "Sekoia.io"
		id = "f2879c6e-3d1b-41be-8b1d-4f0503fd4b29"
		date = "2024-04-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/weevely_webshell_payload.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "bb02ec519d77526cc81ebd7743336b333b9498f79079f7008970cf1bb51c4948"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "<?php include \""
		$s2 = ".basename(__FILE__).\""
		$s3 = ";__HALT_COMPILER(); ?>"

	condition:
		all of them and filesize < 1MB and @s1 == 0 and @s2 < @s3
}
rule SEKOIA_Apt_Blackwood_Nspx30_Plugin : FILE
{
	meta:
		description = "Detects plugins of NSPX30 backdoor based on RTTI and rundll32 string"
		author = "Sekoia.io"
		id = "ef8e0d51-c78c-426b-8008-910e27546f23"
		date = "2024-01-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_blackwood_nspx30_plugin.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "cf7c232a5a817ff5c0da04744abf99ed2fcea587e3e6f6e8bf3aef7ca8f2b51b"
		score = 75
		quality = 76
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = {2E 3F 41 56 43 43 61 62 69 6E 65 74 40 40}
		$s2 = {2E 3F 41 56 43 45 6E 63 6F 64 65 72 40 40}
		$s3 = "rundll32.exe \"%hs\",#1" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and all of them
}
rule SEKOIA_Loader_Win_Jinxloader_Strings : FILE
{
	meta:
		description = "Finds JinxLoader samples based on the specific strings"
		author = "Sekoia.io"
		id = "fd2f7e8c-f4a8-4452-bbc6-e03790f8ed89"
		date = "2023-12-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_jinxloader_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "816cb6019cba1aa2e229ab476fcdf378348981920cbe17d3dfb875f8b2dcbf81"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "JinxV2" ascii
		$str02 = "main.main.func1" ascii
		$str03 = "go.shape.struct" ascii
		$str04 = ".glob..func" ascii

	condition:
		uint16( 0 ) == 0x5A4D and all of them and #str04 > 100 and filesize > 8MB
}
rule SEKOIA_Exploit_Linux_Eop_Dirtyc0W_Strings : FILE
{
	meta:
		description = "Detects DirtyCow exploit"
		author = "Sekoia.io"
		id = "f0551e56-b08f-4f6f-81df-f30fbb8ee7b8"
		date = "2023-12-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/exploit_linux_eop_dirtyc0w_strings.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "70f0dda642e7892e35c1afabb4fa6a9fe62ad82d5aa2d90787e83809bc6f5859"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "DirtyCow root privilege escalation"
		$ = "Backing up %s to /tmp/bak"
		$ = "(o o)_____/"

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 1MB and all of them
}
rule SEKOIA_Tool_Paexec_Strings : FILE
{
	meta:
		description = "Detects PAExec based on strings"
		author = "Sekoia.io"
		id = "c48b897c-0d88-4fa9-b64b-0e14a38a62d7"
		date = "2022-09-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_paexec_strings.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "9c3bae822fd317bdc89c07542b05f6255d6af214071194570500eb2a12924ff6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "\\\\%s\\%s\\PAExec_Move%u.dat" wide
		$ = "PAExec_Move%u.dat" wide
		$ = "Usage: PAExec [\\\\computer[,computer2[,...]]" wide
		$ = "PAExec returning exit code %d" wide

	condition:
		uint16be( 0 ) == 0x4d5a and 3 of them and filesize < 500KB
}
rule SEKOIA_Apt_Luckymouse_Compromised_Electronapp : FILE
{
	meta:
		description = "Detects compromised ElectronApp"
		author = "Sekoia.io"
		id = "7702217d-771f-47af-8eaa-d5acf1e14f4d"
		date = "2022-08-05"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_luckymouse_compromised_electronapp.yar#L1-L15"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "939546b75d5f7161bb8eb1fd838a9a7c0c88cb58a0f01f67e687523e5b31b0aa"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s = "module.exports=function(t){eval(function(p,a,c,k,e,r)"

	condition:
		$s at 0 and filesize < 100KB
}
rule SEKOIA_Rat_Win_Babylon : FILE
{
	meta:
		description = "Finds Babylon RAT samples based on specific strings"
		author = "Sekoia.io"
		id = "ba9ab80a-ad7e-4746-aff2-9328440cbb25"
		date = "2023-08-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_babylon.yar#L1-L27"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "142f10e519561d6552c9cb8d267280b9ede203a2f4723d904ab07217b0565bd1"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "ParadoxRAT_Client" ascii
		$str02 = "*** in database %s ***" ascii
		$str03 = "\\drivers\\etc\\HOSTS" ascii
		$str04 = "Babylon RAT Client" wide
		$str05 = "ClipBoard.txt" wide
		$str06 = "a,ccs=UTF-16LE" wide
		$str07 = "[%02d/%02d/%d %02d:%02d:%02d] [%s] (%s):" wide
		$str08 = "Update Failed [OpenProcess]..." wide
		$str09 = "DoS Already Active..." wide
		$str10 = "File Download and Execution Failed..." wide
		$str11 = "LgDError33x98dGetProcAddress" wide
		$str12 = "FriendlyName" wide
		$str13 = "@SPYNET" wide

	condition:
		uint16( 0 ) == 0x5a4d and 8 of ( $str* )
}
rule SEKOIA_Apt_Ta410_Flowcloud_Loader : FILE
{
	meta:
		description = "Detects FlowCloud Loader"
		author = "Sekoia.io"
		id = "0a11dfa0-5a59-477b-baf6-6a777d020860"
		date = "2024-05-27"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_ta410_flowcloud_loader.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "450cfdfbd9a42b623fc1acb55f3ea309ae54282b480edcb9495f4d45874d3922"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$decryption_function = {8A C8 80 C1 26 32 D1 30 14 38}
		$derivation_key = {6B 04 00 00 F7 ?? 81 c2 a8 01 00 00}
		$new_pattern_1 = {50 33 c0 58 74 01 e8}
		$new_pattern_2 = {89 44 24 fc 58 8D 64
        24 fc 81 fc 00 10 00
        00 77 06 81 c4 ?? ??
        ?? ?? 8B 44 24 FC}
		$patch_bytes = {68 78 56 34 12 C3 90 90 90 90 90 00}

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 4MB and 2 of them
}
rule SEKOIA_Apt_Ta410_Flowcloud_Rtti : FILE
{
	meta:
		description = "Detects FlowCloud via RTTI"
		author = "Sekoia.io"
		id = "c6a18c08-8b98-46d7-a6c3-dc171c7791ac"
		date = "2022-10-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_ta410_flowcloud_rtti.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "97f052c409c9b5de025d34180979cd4c322e67bab9f894d3b56c928340a6859b"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$RTTI_1 = ".?AVdllloader@@" ascii fullword
		$RTTI_2 = ".?AVel_cryptowrapper@@" ascii fullword
		$RTTI_3 = ".?AVAntiVirusCheck@@" ascii fullword

	condition:
		uint16( 0 ) == 0x5A4D and filesize < 10MB and all of them
}
rule SEKOIA_Apt_Spikedwine_Malicious_Hta
{
	meta:
		description = "Detects malicious HTA used by SPIKEDWINE"
		author = "Sekoia.io"
		id = "e4526142-d98a-bf35-9d2c-ca2e83638c4b"
		date = "2024-02-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_spikedwine_malicious_hta.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "305896cde5d95c29de511541a961063730709d40d67a8788f084c17f181e3baf"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "<HTA:APPLICATION ID=" nocase
		$ = "return _0x"
		$ = "font-size: 18px;"

	condition:
		all of them
}
rule SEKOIA_Water_Sigbin_Group
{
	meta:
		description = "Detects IOCs related to the 8220 Mining group."
		author = "Sekoia.io"
		id = "c49728e8-db7e-4d83-97d2-7d56b51f8a52"
		date = "2024-06-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/water_sigbin_group.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "dd51945bf79e37b50d377eda3641eb32438dcb5a1c55fb4a9b66a5b5a8b5ed0d"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "Z12A3" ascii fullword
		$s2 = "FromBase64String" ascii fullword
		$s3 = "Start-Process" ascii fullword
		$s4 = "WriteAllBytes" ascii fullword

	condition:
		all of them
}
rule SEKOIA_Hacktool_Impacket_Compiled_Binary : FILE
{
	meta:
		description = "Detects generic PE embbeding impacket"
		author = "Sekoia.io"
		id = "43936dcc-0d74-43dd-996a-c27a28cef283"
		date = "2022-02-28"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_impacket_compiled_binary.yar#L1-L36"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "133f9d0103774701894ea884bc2c52840b405fa21acb9ebab615816ec411b0bf"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$i1 = "impacket.crypto" fullword
		$i2 = "impacket.dcerpc" fullword
		$i3 = "impacket.ese" fullword
		$i4 = "impacket.hresult_errors" fullword
		$i5 = "impacket.krb5" fullword
		$i6 = "impacket.nmb" fullword
		$i7 = "impacket.nt_errors" fullword
		$i8 = "impacket.ntlm" fullword
		$i9 = "impacket.smb" fullword
		$i10 = "impacket.smb3" fullword
		$i11 = "impacket.smb3structs" fullword
		$i12 = "impacket.smbconnection" fullword
		$i13 = "impacket.spnego" fullword
		$i14 = "impacket.structure" fullword
		$i15 = "impacket.system_errors" fullword
		$i16 = "impacket.tds" fullword
		$i17 = "impacket.uuid" fullword
		$i18 = "impacket.version" fullword
		$i19 = "impacket.winregistry" fullword
		$py = "PYZ-00.pyz"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize > 1MB and 3 of ( $i* ) and $py
}
rule SEKOIA_Apt_Kimsuky_Powershell_Dropper_Strings : FILE
{
	meta:
		description = "Detects a PowerShell dropper used by Kimsuky"
		author = "Sekoia.io"
		id = "8b346e05-215b-46c0-82bf-fce3a65440f3"
		date = "2024-06-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_kimsuky_powershell_dropper_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e98f23ddf02049126786e9300e7b6661b2a74817b36e2f3a661b07b24ef4402d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "try { " ascii wide
		$s2 = "); } catch(e){} } if ("
		$s3 = "WScript.Sleep("
		$s4 = " } catch(e) { }"

	condition:
		filesize > 500KB and $s1 at 0 and $s2 in ( filesize -1000 .. filesize ) and $s3 in ( filesize -1000 .. filesize ) and $s4 in ( filesize -1000 .. filesize )
}
rule SEKOIA_Apt_Polonium_Deepcreep_Strings : FILE
{
	meta:
		description = "Tries to detect POLONIUM's DeepCreep implant"
		author = "Sekoia.io"
		id = "b04af229-2bea-4ee8-9e17-8e4befa06e3a"
		date = "2022-10-12"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_polonium_deepcreep_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "60724d2eb964e2c3681b72bdb732ca640b603af7dc94b4eb6608c77cddb94011"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = ";Invoke-Expression -Command '$shortcut =" ascii wide
		$ = "CreateShortcut($c1" ascii wide
		$ = "svchostdp.exe" ascii wide
		$ = "HNlIC91IA==" ascii wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 3MB and 3 of them
}
rule SEKOIA_Ursnif_Ldr4
{
	meta:
		description = "Ursnif LDR4"
		author = "Sekoia.io"
		id = "73e63481-8a89-4342-87f0-8dc7ad459396"
		date = "2024-12-19"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ursnif_ldr4.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6fe237c6370a1b99bddb7bee4170d29cbb780dc445f5d5039201ddbaf05c63db"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str1 = "LOADER.dll" fullword
		$str2 = "DllRegisterServer" fullword
		$str3 = ".bss" fullword
		$x64_code1 = { 3D 2E 62 73 73 74 0A 48 83 C7 28 }
		$x64_code2 = { 8B 17 48 83 C7 04 8B CA 8b C2 23 CB 0B C3 F7 D1 23 C8 41 2B CA 44 8B D2 41 89 08 41 8B CB 49 83 C0 04 83 E1 07 FF C1 41 D3 C2 41 83 EB 04 79 }
		$x64_code3 = { 41 0F B6 01 49 FF C1 8B C8 8B D0 83 E1 03 C1 E1 03 D3 E2 44 03 C2 41 83 C2 FF 75 }
		$x64_code4 = { 45 8D 45 08 48 8D 8C 24 [4] BA 30 00 FE 7F E8 }
		$x64_code5 = { 48 8D 8C 24 [4] BA 30 00 FE 7F 41 B8 08 00 00 00 E8 }
		$x86_code1 = { 81 F9 2E 62 73 73 74 09 83 C6 28 }
		$x86_code2 = { 8B 06 8B D0 23 55 0C 8B D8 0B 5D 0C F7 D2 23 D3 2B D1 8A 4D 08 80 E1 07 83 C6 04 89 17 83 C7 04 FE C1 D3 C0 83 6D 08 04 8B C8 79 }
		$x86_code3 = { 8A 0E 0F B6 D1 8B CA 83 E1 03 C1 E1 03 D3 E2 46 03 C2 4F 75 }
		$x86_code4 = { 6A 08 8D 45 F8 68 30 00 FE 7F 50 E8 }

	condition:
		true and 5 of them
}
rule SEKOIA_Infostealer_Win_Enigma_Loader_Module : FILE
{
	meta:
		description = "Find loader module of Enigma Stealer based on specific strings"
		author = "Sekoia.io"
		id = "664fe8de-b406-4d63-9a4b-1c350b444f01"
		date = "2023-01-30"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_enigma_loader_module.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "f1623c2f7c00affa3985cf7b9cdf25e39320700fa9d69f9f9426f03054b4b712"
		logic_hash = "f5485b14291acc299d66b72aefd2d5e558d82f6a90450d293eb147f05423f2d8"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "Enigma.Loader.Driver_x64.dll" ascii
		$str02 = "C:\\projects\\driver\\Driver\\x64\\Release\\driver.pdb" ascii
		$str03 = "/getFile?file_id=" ascii
		$str04 = "/file/bot" ascii
		$str05 = "Fatal error: failed to acquire SE_LOAD_DRIVER_PRIVILEGE. Make sure you are running as administrator." wide
		$str06 = "[GetTgFileById][GetTgRequest] reply is NULL" wide
		$str07 = "Telegram request failed" wide
		$str08 = "Vul driver data destroyed before unlink" wide
		$str09 = "GetExportAddress hash not found: %x" wide
		$str10 = "\\REGISTRY\\MACHINE\\HARDWARE\\RESOURCEMAP\\PnP Manager\\PnpManager" wide

	condition:
		uint16( 0 ) == 0x5A4D and 4 of them
}
rule SEKOIA_Downloader_Mac_Smooth_Operator : FILE
{
	meta:
		description = "Detect the Smooth_Operator malware"
		author = "Sekoia.io"
		id = "c132b3f0-f536-4a66-bcf8-2a95c258c414"
		date = "2023-07-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/downloader_mac_smooth_operator.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "031f766d6ab7d94ed7ba4324d4bdfa3fbc11986fba35487a88a1ee3aba090c82"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "%s/.main_storage"
		$ = "%s/UpdateAgent"

	condition:
		uint32be( 0 ) == 0xcafebabe and all of them
}
rule SEKOIA_Loader_Win_Goshellcode : FILE
{
	meta:
		description = "Finds GoShellcode samples based on the specific strings"
		author = "Sekoia.io"
		id = "61346225-325a-4067-a4d6-3b8c001dd380"
		date = "2023-11-15"
		modified = "2024-12-19"
		reference = "https://github.com/yoda66/GoShellcode/blob/main/gosc.go"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_goshellcode.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "94445af999055bf7d7cddc0d1d5183ab2776d85285f0522a28fac6c5a6101906"
		hash = "fdea8b01b2597ceafe6f08b5fd12cc603b1e3ce2037731c0b6defde6935b1ce0"
		logic_hash = "48ec87f284fbd14cbdb6b6b0f2e0fa6eb5ea19f112648660e0b8e525c562e3fc"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "main.VirtualAlloc" ascii
		$str02 = "main.RtlMoveMemory" ascii
		$str03 = "syscall.Syscall" ascii
		$str04 = "syscall.NewLazyDLL" ascii
		$str05 = "runtime.getGetProcAddress" ascii
		$str06 = "runtime.useAeshash" ascii

	condition:
		uint16( 0 ) == 0x5A4D and all of ( $str* ) and filesize < 8MB
}
rule SEKOIA_Apt_Apt37_Malicious_Hta_File : FILE
{
	meta:
		description = "Detects malicious APT37 files"
		author = "Sekoia.io"
		id = "22a98c27-8ff4-4760-b505-f8eacf4dabda"
		date = "2023-03-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt37_malicious_hta_file.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "85289bea86641ea9c359c361d075783449d453017485170abc87c47872792210"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "<HTML>" nocase
		$s2 = " UwB0AGEAcgB0AC0AUwBs" ascii
		$s3 = "= new ActiveXObject(" ascii
		$s4 = "\", \"\", \"open\", 0);" ascii
		$s5 = ".moveTo(" ascii
		$s6 = "self.close();"

	condition:
		$s1 at 0 and all of them and filesize < 1MB
}
rule SEKOIA_Tool_Godpotato : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "cc396771-f187-43ae-903f-147d15483c46"
		date = "2023-08-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_godpotato.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ea182b187fcd1ba61d3e2d10a689cf0212267dede1342e817e47551506a780ab"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "[!] Cannot create process Win32Error:{0}" ascii wide
		$s2 = "[*] process start with pid {0}" ascii wide
		$s3 = "MEOW" ascii wide
		$s4 = "2ae886c3-3272-40be-8d3c-ebaede9e61e1" ascii wide
		$s5 = "GodPotatoUnmarshalTrigger" ascii wide
		$s6 = "GodPotato.exe" ascii wide
		$s7 = "GodPotato.exe" wide

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 4MB and all of them
}
rule SEKOIA_Tool_Masky_Strings : FILE
{
	meta:
		description = "Detects Masky tool"
		author = "Sekoia.io"
		id = "542670ee-9f2e-4148-853d-a3f055bd584c"
		date = "2022-08-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_masky_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "35dc536879d9464919028ace6b65b225455621035184d7b58468d259ccda62aa"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "caa1aa2e-8a2a-4f98-bc51-b7cf10663fa9" ascii
		$s2 = "Masky" ascii
		$s3 = "\\Windows\\Temp\\" wide
		$s4 = "Length must be non-negative" wide
		$s5 = "CSP does not contain a private key" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and 4 of them or $s1
}

rule SEKOIA_Yara_Runascs : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "1720f042-2cc6-4ef1-b66c-fe8a4214366a"
		date = "2023-08-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/yara_runascs.yar#L3-L33"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "fe9b02704d07b5ebe6ad94283e4c1ec2846a54f5c1fb2115a1f6411cf8c19059"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "RunasCs" ascii wide
		$s2 = "LOGON32_LOGON_INTERACTIVE" ascii wide
		$s3 = "LOGON32_LOGON_NETWORK" ascii wide
		$s4 = "LOGON32_LOGON_BATCH" ascii wide
		$s5 = "LOGON32_LOGON_SERVICE" ascii wide
		$s6 = "dwLogonProvider" ascii wide
		$s7 = "LogonUser" ascii wide
		$s8 = "CreateProcessAsUser" ascii wide

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 4MB and all of them and not ( pe.version_info [ "OriginalFilename" ] == "Atera.AgentPackages.CommonLib.dll" and for any sig in pe.signatures : ( sig.subject contains "CN=Atera Networks Ltd" and sig.issuer contains "CN=DigiCert Trusted G4 Code Signing RSA4096 SHA384 2021 CA1" ) )
}
rule SEKOIA_Ransomware_Win_Blackcat : FILE
{
	meta:
		description = "Detect the BlackCat ransomware (Windows version)"
		author = "Sekoia.io"
		id = "873355f7-3942-4171-9df7-f524bb6b6903"
		date = "2022-01-19"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_win_blackcat.yar#L1-L31"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8a60fd14835f9e8683c3e60a19f23bc00020ccd22e74bffbc8ed19fcb8d0e39a"
		score = 75
		quality = 80
		tags = "FILE"
		classification = "TLP:CLEAR"
		version = "1.1"

	strings:
		$s1 = "desktop_image::set_desktop_wallpaper=" ascii
		$s2 = "C:\\Users\\Public\\All Usersdeploy_note_and_image_for_all_users=" ascii
		$s3 = "propagate::none" ascii
		$s4 = "propagate::failed=" ascii
		$s5 = "propagate::ok=" ascii
		$s6 = "query_status_process::ok=" ascii
		$s7 = "enum_dependent_services::ok=" ascii
		$s8 = "enum_dependent_services::error=" ascii
		$s9 = "try_stop=" ascii
		$s10 = "try_stop::ok=" ascii
		$s11 = "try_stop::failed=" ascii
		$s12 = "stop=" ascii
		$s13 = "dependent_service_name=" ascii
		$s14 = "kill_all=" ascii
		$s15 = "detach=" ascii

	condition:
		uint16( 0 ) == 0x5A4D and filesize > 2MB and filesize < 4MB and all of them
}
rule SEKOIA_Infostealer_Win_Whitesnake_Xor_Rc4_July12 : FILE
{
	meta:
		description = "Detects WhiteSnake Stealer XOR and RC4 version"
		author = "Sekoia.io"
		id = "f2ebfcbd-9667-459a-a543-ce0be62c0dc4"
		date = "2023-07-12"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_whitesnake_xor_rc4_july12.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f14b95e5cb6ffaab14d0890847fe6e9dcfc3ee0b884c34d24d786420e2411a80"
		score = 75
		quality = 76
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$1 = {FE 0C 00 00 FE 09 00 00 FE 0C 02 00 6F ?? 00 00 0A FE 0C 03 00 61 D1 FE 0E 04 00 FE}
		$2 = {61 6e 61 6c 2e 6a 70 67}
		$3 = {73 68 69 74 2e 6a 70 67}
		$4 = {FE 0C ?? 00 20 00 01 00 00 3F ?? FF FF FF 20 00 00 00 00 FE 0E ?? 00 38 ?? 00 00 00 FE 0C}
		$5 = "qemu" wide
		$6 = "vbox" wide

	condition:
		($1 and $2 and filesize < 600KB ) or ( $3 and $4 and $5 and $6 and filesize < 300KB )
}
rule SEKOIA_Trojan_Android_Xenomorph : FILE
{
	meta:
		description = "Detect samples of the Android banking trojan Xenomorph"
		author = "Sekoia.io"
		id = "ec65ca1b-e71f-4772-8be0-2a2b6a690987"
		date = "2022-02-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/trojan_android_xenomorph.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "d44e5742449cd9c19b50ab23f452378d5627e19140554d12086994d820df9c64"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ass0 = "assets/shadows/knife_shadow_"
		$ass1 = "assets/knife_"
		$ass2 = "okhttp3"

	condition:
		uint32be( 0 ) == 0x504B0304 and filesize > 1MB and filesize < 4MB and #ass0 > 10 and #ass1 > 10 and $ass2
}
rule SEKOIA_Apt_Malware_Pocoproxy : FILE
{
	meta:
		description = "Detects strings in PocoProxy"
		author = "Sekoia.io"
		id = "8b37e37f-339e-4f8b-b792-435096f56af0"
		date = "2024-08-13"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_malware_pocoproxy.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "2b89f15012512002c656ff821bbbeca0"
		hash = "8d850fed6bb1f3b60365ed656c6791c5"
		logic_hash = "217f4eabb5ff4534878b6dd192ae446e651d8510f03ceb501eb33e91199c15a8"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "-listen" ascii fullword
		$ = "-connect" ascii fullword
		$ = "-proxy" ascii fullword
		$ = "%d-%d-%d %d:%d:%d" ascii fullword
		$ = "%S://%S:%u%S" wide
		$ = "\\r\\n[%u(%u/%u/%u/%u)]==> %S  %S>> %S:%d connect ok." wide
		$ = "\\r\\nnconnect to %S:%d faild." wide
		$ = "\\r\\nI'm listen %S:%d,welcome..." wide

	condition:
		uint16be( 0 ) == 0x4d5a and 5 of them
}
rule SEKOIA_Apt_Gamaredon_Lnk : FILE
{
	meta:
		description = "Detects lnk file used by Gamaredon"
		author = "Sekoia.io"
		id = "bfa69d84-433c-4f37-93b7-5b1b11677fbb"
		date = "2024-02-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gamaredon_lnk.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "be73ffca4b88f11e33532cf9a179743508bfa7a60c6f4de98c245b350b5fb910"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "-windowstyle hidden $(gc " wide
		$s2 = "|out-string)|powershell -noprofile -" wide

	condition:
		uint32be( 0 ) == 0x4c000000 and any of them and filesize < 100KB
}
rule SEKOIA_Apt_Cerana_Keeper_Yk0130 : FILE
{
	meta:
		description = "Detects YK0130 reverse shell"
		author = "Sekoia.io"
		id = "3da898a9-68e7-472f-8478-a0243840ec0a"
		date = "2024-10-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_cerana_keeper_yk0130.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "2554e4864294dc96a5b4548dd42c7189"
		logic_hash = "4462c6b7f46520207f49275292a3be873540becb593176d771d3489fba6f4cb0"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$pdb = "C:\\Users\\admin\\source\\repos\\YK0130" ascii fullword

	condition:
		uint16be( 0 ) == 0x4d5a and all of them and filesize < 300KB
}
rule SEKOIA_Tool_3Proxy_Strings : FILE
{
	meta:
		description = "Detects 3proxy based on strings"
		author = "Sekoia.io"
		id = "daf6cd97-8033-4bfd-88b5-41c06eb417b0"
		date = "2024-03-14"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_3proxy_strings.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f1d9bea9975af9bfa3f1a8cbf2c1d65fe1d39f303d5dbe6131887653cbbe7021"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "of 3proxy-"
		$ = "-pPORT - service port to accept connections"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 500KB and all of them
}
rule SEKOIA_Apt_Darkpink_Sample : FILE
{
	meta:
		description = "Detects two parts of cmd.exe /c "
		author = "Sekoia.io"
		id = "91b4c64a-7622-4f03-bd3f-9fe56f01dfbe"
		date = "2023-06-05"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_darkpink_sample.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "8dc3f6179120f03fd6cb2299dbc94425451d84d6852b801a313a39e9df5d9b1a"
		logic_hash = "c9d3952036bffe2d924ea553fd53f8b6f0b3f16f1060fbde69496c800d4d5ad9"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$cmd_xor_part_1 = {DF 00 A1 00 E4 00 F0 00 4B 00 3A 00 D1 00 C4 00}
		$cmd_xor_part_2 = {bc 00 cc 00 80 00 d0 00 64 00 59 00 F1 00 E6 00 FD 00 83 00 C6}

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 1MB and all of them
}
rule SEKOIA_Koi_Powershell_Loading_Obfuscatednet
{
	meta:
		description = "Powershell script loading obfuscated .NET Koi module"
		author = "Sekoia.io"
		id = "75a7460d-cc28-470e-9841-da8e46ee0101"
		date = "2024-03-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/koi_powershell_loading_obfuscatednet.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "82f30c04474ea77af5169771a2c0e75ba792fd32dc559b8c29172b73ace4ef10"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "# [Net.ServicePointManager]::SecurityProtocol +='tls12'"
		$s2 = "$binary[$i] = $binary[$i] -bxor $k[$i % $k.Length]"
		$s3 = "\").Split('|')"
		$s4 = "$ep.Invoke($null, "

	condition:
		$s3 and 3 of them
}
rule SEKOIA_Rootkit_Win_Purplefox_Svchost_Txt : FILE
{
	meta:
		description = "Detects Purple Fox payloads used during end-2021 and 2022 campaigns based on characteristics shared by TrendMicro details."
		author = "Sekoia.io"
		id = "e992d574-6a44-4bea-97e2-6d5579ce8d02"
		date = "2022-03-28"
		modified = "2024-12-19"
		reference = "https://www.trendmicro.com/en_us/research/22/c/purple-fox-uses-new-arrival-vector-and-improves-malware-arsenal.html"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rootkit_win_purplefox_svchost_txt.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a1de949cb2e898ed031f5c796f7152af12dfae5431dfaf269f25ebe72f0ae004"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str0 = "C:\\ProgramData\\dll.dll,luohua" wide
		$str1 = "C:\\ProgramData\\7z.exe" wide
		$str2 = "F:\\hidden-master\\x64\\Debug\\QAssist.pdb" ascii
		$str3 = "F:\\Root\\sources\\MedaiUpdateV8\\Release\\MedaiUpdateV8.pdb" ascii
		$str4 = "cmd.exe /c RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 255" ascii
		$str5 = "del /s /f %appdata%\\Mozilla\\Firefox\\Profiles\\*.db" ascii

	condition:
		4 of ( $str* ) and filesize > 7000KB and filesize < 9500KB
}
rule SEKOIA_Apt_Gamaredon_Lnk_Spreader : FILE
{
	meta:
		description = "Detects LNK generated by Gamaredon LNK spreader"
		author = "Sekoia.io"
		id = "2866ca1d-c094-49ba-b1de-ff9a60680e28"
		date = "2023-06-19"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gamaredon_lnk_spreader.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "7d6264ce74e298c6d58803f9ebdb4a40b4ce909d02fd62f54a1f8d682d73519a"
		logic_hash = "e8a82fd4cdce7bc888184ccf8d182ab5bb53e30de04b02b7c63379bae5d21b1f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "windoWSTYLE hiDdEn -NOlOgo iEX" wide nocase
		$ = "(IeX (geT-coNtEnT" wide nocase

	condition:
		uint32be( 0 ) == 0x4C000000 and filesize < 3KB and all of them
}
rule SEKOIA_Apt_Stripedfly : FILE
{
	meta:
		description = "Detects string relative to Stripedfly malware"
		author = "Sekoia.io"
		id = "81968d34-3247-4965-ba44-55747370c90e"
		date = "2023-11-30"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_stripedfly.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ded64ae30cf994162d4af649a34eadd4b8619cbced4392a6684129f8cf906136"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "{\"id\":%d,\"jsonrpc\":\"2.0\",\"method\":\"%s\",\"params\":%s}"
		$s2 = "{\"login\":\"%s\",\"pass\":\"%s\",\"agent\":\"\"}"
		$s3 = "(tcp|ssl)://([A-Za-z0-9\\.\\-]+):([0-9]+)"

	condition:
		filesize < 3MB and 2 of them
}
rule SEKOIA_Hacktool_Win_Powertool : FILE
{
	meta:
		description = "Detect PowerTool based on strings"
		author = "Sekoia.io"
		id = "ab8355b8-322d-41a4-82f0-43896c96b9bc"
		date = "2022-09-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_win_powertool.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "aeccba821e528ca03abc8b50362d450ba2c12ab443454faf5b2809aecd163648"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str0 = "C:\\dev\\pt64_en\\Release\\PowerTool.pdb" ascii
		$str1 = "Chage language nedd to restart PowerTool" ascii
		$str2 = "(http://twitter.com/ithurricanept && https://www.linkedin.com/in/powertool)" wide
		$str3 = "Infected=Before Fix, whether to back up the drive files will be fixed?" wide
		$str4 = "Infected?-Are you sure to Fix the Infected Driver File?" wide
		$str5 = "shellex\\ContextMenuHandlers\\PowerTool" wide
		$str6 = "[PowerTool] name=%s, size=%d, %d" ascii

	condition:
		uint16( 0 ) == 0x5A4D and any of them
}
rule SEKOIA_Malware_Win_Lyceum_Maldoc_Macro_20220613
{
	meta:
		description = "Detect the macro contained in Lyceum maldoc to deploy its malware"
		author = "Sekoia.io"
		id = "3046bffd-261f-4d5b-9015-f2e5fc31c9c9"
		date = "2022-06-13"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/malware_win_lyceum_maldoc_macro_20220613.yar#L1-L15"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a9f4957e8198b4cb2229913a405b3e0fc97cbd3598bb583dbfdaf56ca278d4cb"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "ActiveDocument.InlineShapes(i).PictureFormat.Brightness = 0.5" ascii

	condition:
		all of them
}
rule SEKOIA_Apt_Shadowpad_First_Called_Function : FILE
{
	meta:
		description = "Detects entrypoint of shadowpad"
		author = "Sekoia.io"
		id = "3ce1ffd3-5c30-4b36-b7cc-c9fa873ebc25"
		date = "2023-01-30"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_shadowpad_first_called_function.yar#L1-L36"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a40db3fad01f4177973fd50bd489e5c4ff6d3592dfff063c2c31694007c31e0b"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$chunk_1 = {
        48 83 EC 28
        33 C9
        FF 15 ?? ?? ?? ??
        8B 80 ?? ?? ?? ??
        3B 05 ?? ?? ?? ??
        74 ??
        E8 ?? ?? ?? ??
        E8 ?? ?? ?? ??
        EB ??
        48 8B 0D ?? ?? ?? ??
        E8 ?? ?? ?? ??
        8B C8
        FF 15 ?? ?? ?? ??
        90
        B9 28 04 00 00
        FF 15 ?? ?? ?? ??
        90
        48 83 C4 28
        C3
        }

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Apt_Implant_Xdealer_Stealer_Strings : FILE
{
	meta:
		description = "Detects stealer module of XDealer"
		author = "Sekoia.io"
		id = "6314cf6c-2c3b-4e9a-87a1-b56ee148474c"
		date = "2024-03-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_implant_xdealer_stealer_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "79ba2fd14cd2eb73848026f79ce6115df813e0fda3a071ab26659874e04e2201"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "%sbmp.tmp"
		$ = "%sjgp.tmp"
		$ = "%sma_%s_%05u_%u."
		$ = "%s%s_%05u_%u."

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 500KB and all of them
}

rule SEKOIA_Backdoor_Win_Mgbot_Main
{
	meta:
		description = "Detect MgBot main.dll file"
		author = "Sekoia.io"
		id = "528baa11-58d5-470a-bd6d-963d4ac75d97"
		date = "2024-03-20"
		modified = "2024-12-19"
		reference = "https://symantec-enterprise-blogs.security.com/blogs/threat-intelligence/apt-attacks-telecoms-africa-mgbot"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_win_mgbot_main.yar#L4-L35"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "706c9030c2fa5eb758fa2113df3a7e79257808b3e79e46869d1bf279ed488c36"
		hash = "017187a1b6d58c69d90d81055db031f1a7569a3b95743679b21e44ea82cfb6c7"
		logic_hash = "61b335c88ce8bc56396b597c7c6f27b1d431941682401f0b3950c80edf7d8403"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		pe.imphash( ) == "8e1ee04a99c77bd54c6dc55214ffa2e3" or hash.md5 ( pe.rich_signature.clear_data ) == "67e8e8b75b981b5c8ff31149dc2c61b2" or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "7c6adf9987e6dfbf19b5f156b0314798" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "46fa9f5a035c8ae8de1a0d14150bd5ef" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "f7895f9456f8d51125e6744960c38133" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "5d82bb8a7ef37c417615381b446f715c" ) or for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "d7808c6662f098e685040f7c61bc033d9e73002f674de7cf2ffcd6230d60d429" )
}
rule SEKOIA_Loader_Win_Operationmagalenha_Vbs
{
	meta:
		description = "Finds VBS file loading the PeepingTitle backdoor"
		author = "Sekoia.io"
		id = "b1f705d1-de3e-4ce6-9bb7-0e39b6e79add"
		date = "2023-05-31"
		modified = "2024-12-19"
		reference = "https://www.sentinelone.com/labs/operation-magalenha-long-running-campaign-pursues-portuguese-credentials-and-pii/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_operationmagalenha_vbs.yar#L1-L39"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "bb1c48ea6a4d9f0bc04df558837f2d448b38eac920cb4030e01b915a4e442708"
		score = 75
		quality = 78
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "'Skip to content" ascii
		$str02 = "'Search" ascii
		$str03 = "'Sign in" ascii
		$str04 = "'Sign up" ascii
		$str05 = "'Code" ascii
		$str06 = "'Terms" ascii
		$str07 = "'Privacy" ascii
		$str08 = "'Security" ascii
		$str09 = "'Status" ascii
		$str10 = "'Docs" ascii
		$str11 = "'Contact GitHub" ascii
		$str12 = "'Pricing" ascii
		$str13 = "'API" ascii
		$str14 = "'Training" ascii
		$str15 = "'Blog" ascii
		$str16 = "'About" ascii
		$vbs01 = "WScript.Sleep" ascii nocase
		$vbs02 = "Set obj" ascii nocase
		$vbs03 = "Dim obj" ascii nocase
		$vbs04 = "https://tinyurl.com" ascii nocase
		$vbs05 = "C:\\Users\\Public" ascii nocase
		$vbs06 = "CreateObject(\"WScript.Shell\")" ascii nocase
		$vbs07 = ".SaveToFile" ascii nocase

	condition:
		10 of ( $str* ) and 5 of ( $vbs* )
}
rule SEKOIA_Infostealer_Win_Cinoshistealer : FILE
{
	meta:
		description = "Finds Cinoshi Stealer samples based on specific strings, or PE resources"
		author = "Sekoia.io"
		id = "2e9c066b-d5e3-4a25-8954-c10af285bcd3"
		date = "2023-06-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_cinoshistealer.yar#L1-L29"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c4d8418a7bd1bf205295100d993562c89b17b80889cad5aac7a74f89e66543ce"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "Anaida.exe" ascii wide
		$str02 = "Anaida.pdb" ascii
		$str03 = "embedder_download_data" ascii
		$str04 = "date_password_modified" ascii
		$str05 = "card_number_encrypted" ascii
		$str06 = "set_UseZip64WhenSaving" ascii
		$str07 = "set_CommandText" ascii
		$str08 = "Nss3CouldNotBeLoaded" ascii
		$str09 = "formhistory.sqlite" wide
		$str10 = "logins.json" wide
		$str11 = "\\nss3.dll" wide
		$str12 = "\\cookies.sqlite" wide
		$str13 = "\\places.sqlite" wide
		$str14 = "\\autofill-profiles.json" wide

	condition:
		uint16( 0 ) == 0x5a4d and 9 of them and filesize > 400KB
}
rule SEKOIA_Infostealer_Win_Nosu : FILE
{
	meta:
		description = "Finds Nosu samples based on characteristic strings"
		author = "Sekoia.io"
		id = "9823af25-e30b-4514-a59c-02dd19fe368d"
		date = "2022-12-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_nosu.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f18db2008aa9175fc423133fd6d5872c5750d011aad73c373505347443d5032c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str0 = "C:\\xampp\\htdocs\\nosu\\core\\release\\lilly.pdb" ascii
		$str1 = "{\"gp\":\"%s\",\"app\":\"%S\"," ascii
		$str2 = "stored in zip:\\%s" wide

	condition:
		uint16( 0 ) == 0x5A4D and 1 of them and filesize < 1MB
}
rule SEKOIA_Apt_Cottonsandstorm_Win_Implant : FILE
{
	meta:
		description = "Detects a simple win implant used by Cotton Sandstorm"
		author = "Sekoia.io"
		id = "04a5255c-f9bb-4612-b0e2-ed0326867055"
		date = "2024-11-05"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_cottonsandstorm_win_implant.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "f797d71ed07d6e05556300e4ce0f2927"
		logic_hash = "dcb25ee236ca52f23cc6bfdbcedcbc6d407e88f06341e684f202a59954733ade"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "DIR =>" wide
		$ = "type=machines&md5=" wide
		$ = "File =>" wide
		$ = "&ip=" wide fullword
		$ = "&un=" wide fullword
		$ = "&cp=" wide fullword
		$ = "myFile\";filename=" ascii
		$ = "ifB75BcjsRBhy2et" ascii

	condition:
		uint16be( 0 ) == 0x4d5a and 4 of them and filesize < 500KB
}
rule SEKOIA_Tool_Efspotato : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "4440ea37-d7d0-4107-867c-576c6e2f4f7e"
		date = "2023-08-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_efspotato.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "cbfd72a16f02903b1ad6fdf3e25f6c5508145d6be4c1776bb77f1ccd6c1954b3"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "usage: EfsPotato <cmd> [pipe]" ascii wide
		$s2 = "Exploit for EfsPotato(MS-EFSR EfsRpcEncryptFileSrv with SeImpersonatePrivilege local privalege escalation vulnerability)." ascii wide
		$s3 = "Part of GMH's fuck Tools, Code By zcgonvh." ascii wide

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 4MB and all of them
}
rule SEKOIA_Implant_Win_Pingpull : FILE
{
	meta:
		description = "Detect the PingPull malware used by GALLUM in 2022"
		author = "Sekoia.io"
		id = "521615d4-912b-4581-b5a9-a8b158ac9496"
		date = "2022-06-13"
		modified = "2024-12-19"
		reference = "https://unit42.paloaltonetworks.com/pingpull-gallium/#Protections-and-Mitigations"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_win_pingpull.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "778d429e4c6d7575ddeea5144f9554f2b6ca46175d4202d338bef01dc9668b97"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "PROJECT_%s_%s_%08X"

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}

rule SEKOIA_Backdoor_Win_Minibike : FILE
{
	meta:
		description = "Detect the MINIBIKE malware"
		author = "Sekoia.io"
		id = "d758c41a-279c-4706-9cf3-87740e45f71d"
		date = "2024-04-08"
		modified = "2024-12-19"
		reference = "https://www.mandiant.com/resources/blog/suspected-iranian-unc1549-targets-israel-middle-east"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_win_minibike.yar#L4-L37"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "985967e245d8fbc722e30371c9ed48c3269ceaa6b9b9b80caf2b95c920c856c2"
		hash = "ab0b602665b609392eacdcbfc6c1981f216c19f21e2156a55cf9998eab02227b"
		hash = "8e2429d70989bbdd2ea8842dce7c3d790ebe148490ee519b47767557f4a4a733"
		hash = "be86b8559a84d97aa1cc9852e60a553f5164477bacfc69b7f3453ad37fb6fd2a"
		hash = "78065411e7e8eb205ddae7215a229b7c93bdca5d628670f89caa982238ac7eb6"
		hash = "73bf3a5877a7fe16544d15670e3ece034e4826323ba555b3527ad4d061f44ec4"
		logic_hash = "d09ab10aff629c6edafa7df640e98bcb6b2523a9bf4e2f2ca87f6694ccfe21bf"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Mini-Junked.dll"

	condition:
		uint16( 0 ) == 0x5A4D and all of them or pe.imphash ( ) == "75a9ae7d4394abdc30e2a873908fa09d" or hash.md5 ( pe.rich_signature.clear_data ) == "06b2ec5892ac9ad566693b04cf427f3f" or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "612006b6f68cd0b8b0d48252dbdef4be" )
}
rule SEKOIA_Bot_Lin_Lucifer_Strings : FILE
{
	meta:
		description = "Catch Lucifer DDoS - lin version - malware based on strings"
		author = "Sekoia.io"
		id = "c341b6d0-bc22-4a85-aebb-ed323487f524"
		date = "2024-09-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/bot_lin_lucifer_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "23276c627d27f36c1ec15b1779835b921652a8fcff898041f1920902262faf41"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "DealwithDDoS" ascii
		$s2 = "DecryptData" ascii
		$s3 = "They say I'm rude. I'm not rude at all, but I still want to say, fuck your mother" ascii
		$s4 = "stratum+tcp://" ascii
		$s5 = "gethostip" ascii
		$s6 = "GetmyName" ascii

	condition:
		uint32( 0 ) == 0x464c457f and all of them
}
rule SEKOIA_Backdoor_Powershellempire_Batlauchers : FILE
{
	meta:
		description = "Detect BAT launchers for Empire"
		author = "Sekoia.io"
		id = "ad371665-ec59-45c8-9d99-2a675842c384"
		date = "2022-04-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_powershellempire_batlauchers.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0453c739ad936b0cc5ed2e36ba4a011a90600b74ca23c08165c23a3e63fe60e9"
		score = 75
		quality = 74
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "powershell -noP -sta -w 1 -enc  SQB" nocase wide ascii
		$ = "powershell -ep bypass -noP -sta -w 1 -enc SQB" nocase wide ascii
		$ = "-nol -nop -ep bypass \"[IO.File]::ReadAllText('%~f0')|iex" nocase wide ascii

	condition:
		any of them and filesize < 1MB
}
rule SEKOIA_Apt_Mustangpanda_Coolclient : FILE
{
	meta:
		description = "Detect COOLCLIENT via obfuscation & specific string"
		author = "Sekoia.io"
		id = "2f8fdb66-03a2-400f-808b-56ae1b276d2f"
		date = "2023-03-27"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_mustangpanda_coolclient.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "9fd552604299ecb8fa28042ee26e72bbe4fb9804ad087bf4a373b2c2e17d43b0"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = {eb 14 ea 50 eb 0b ea 8b c4 a8 01 74 06 eb 0b}
		$s2 = {66 0f d6 44 24 eb eb}
		$s3 = "c:\\windows\\syste" fullword

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 1MB and all of them
}
rule SEKOIA_Apt_Polonium_Powershell_Creepydrive_Strings
{
	meta:
		description = "Detects POLONIUM CreepyDrive Powershell implant"
		author = "Sekoia.io"
		id = "0ba196bd-9cd6-4553-b7bf-69989cdb8be4"
		date = "2022-06-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_polonium_powershell_creepydrive_strings.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "28b8f10a36d13e97e606b082f20c50c3d48241409e7f1aca621e2af9d756dbe5"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "function Exec($comm)" base64 ascii wide
		$ = "$comm = $comm + \"| outstring" base64 ascii wide
		$ = "Invoke-Expression -Command:$comm" base64 ascii wide
		$ = "microsoft.com" base64 ascii wide
		$ = "$req = Invoke-WebRequest" base64 ascii wide
		$ = "$j += $data" base64 ascii wide
		$ = "$res = Exec($arr[$i])" base64 ascii wide
		$ = "$arr = @(iex \"$req\")" base64 ascii wide
		$ = "elseif ($req -cmatch" base64 ascii wide
		$ = "graph.microsoft.com" base64 ascii wide

	condition:
		3 of them
}
rule SEKOIA_Infostealer_Win_Xehook_Str : FILE
{
	meta:
		description = "Finds XehookStealer standalone samples based on specific strings."
		author = "Sekoia.io"
		id = "fa76988d-f0a2-4fc2-a122-c104fd585f34"
		date = "2024-06-12"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_xehook_str.yar#L1-L32"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "543ec3b523e5f00d3c285e453c8d11f3d5c7778b2986b7fe03f2d62ff18c2778"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "xehook" ascii
		$str02 = "Classes.LogRecord" ascii
		$str03 = "__  _____| |__   ___   ___ | | __" wide
		$str04 = "\\ \\/ / _ \\ '_ \\ / _ \\ / _ \\| |/ /" wide
		$str05 = " >  <  __/ | | | (_) | (_) |   <" wide
		$str06 = "/_/\\_\\___|_| |_|\\___/ \\___/|_|\\_\\" wide
		$str07 = "https://t.me/xehook" wide
		$str08 = "About PC.txt" wide
		$str09 = "Browser: {4} v{5} ({6})" wide
		$str10 = "http://ip-api.com/json/?fields=11827" wide
		$str11 = "{0}gate.php?id={1}&build={2}&passwords={3}&cookies={4}" wide
		$str12 = "getjson.php?id=" wide
		$com01 = "CheckRemoteDebuggerPresent" ascii
		$com02 = "get_CurrentThread" ascii
		$com03 = "get_InstalledInputLanguages" ascii
		$com04 = "get_Ticks" ascii
		$com05 = "System.Security.Cryptography" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 2 of ( $str* ) and 4 of ( $com* )
}
rule SEKOIA_Ransomware_Win_Shrinklocker
{
	meta:
		description = "Detects files related to the ShrinkLocker ransomware"
		author = "Sekoia.io"
		id = "93a6fbdd-ad62-456a-a1a5-b5ae3b242004"
		date = "2024-06-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_win_shrinklocker.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "7770b0946b9bb482f23c4ce0d753393e0d42a6fd8b31029847d74356296f0cf1"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$a = "shrinkdisk" ascii fullword
		$b = "BitLocker" ascii fullword
		$c = "diskpart" ascii fullword
		$d = "disk.vbs" ascii fullword
		$e = "strDriveLetter" ascii fullword
		$f = "shrinkcomplate" ascii fullword
		$g = "ADODB.Stream" ascii fullword
		$h = "Win32_OperatingSystem" ascii fullword
		$i = "HKLM\\System\\CurrentControlSet\\Control\\Terminal Server" ascii fullword
		$j = "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" ascii fullword
		$k = "HKLM\\SOFTWARE\\Policies\\Microsoft\\FVE" ascii fullword

	condition:
		9 of them
}
rule SEKOIA_Backdoor_Sandman_Strings : FILE
{
	meta:
		description = "Detect the Sandman backdoor based on strings"
		author = "Sekoia.io"
		id = "7bac7a1e-7d4a-4410-9ad4-1c85beb6faaf"
		date = "2022-08-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_sandman_strings.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "74ee1b73532d9050d5ed7ea0bed158322288a2f5b65255804ebf10dc1a4ea55b"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "e9f7c24c-879d-49f2-b9bf-2477dc28e2ee"
		$s2 = "System.Net.Sockets"
		$s3 = "ntpServer"
		$s4 = "payloadUrl"
		$s5 = "keepRunning"
		$s6 = "payloadSize"
		$s7 = "defaultNtpMessageSize"
		$s8 = "InjectShellcode"

	condition:
		uint16be( 0 ) == 0x4d5a and 7 of them or $s1
}
rule SEKOIA_Tool_Sharpsecdump : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "359bf48b-81c8-4d12-ac02-777d4865411a"
		date = "2023-06-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_sharpsecdump.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f183069d843767daa97bc81385e5e1b3a19c556f8171f28f8806aebe7a226176"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "SharpSecDump"
		$s2 = "e2fdd6cc-9886-456c-9021-ee2c47cf67b7"
		$s3 = "Md4Hash2"
		$s4 = "RidToKey"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 1MB and all of them
}
rule SEKOIA_Apt_Turla_Kazuar_Variant_2023 : FILE
{
	meta:
		description = "New variant of Kazuar observed in 2023"
		author = "Sekoia.io"
		id = "51e9de6a-5d8a-4627-8063-b70f78e78726"
		date = "2023-11-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_turla_kazuar_variant_2023.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "98207fef906c922ff09f72b0dea7103c0fb86c5ec4712a23ecba6840b79b0ad5"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "Started from file '" ascii wide
		$s2 = "Zombifying user's" ascii wide
		$s3 = "Result #{0:X16} already exists in {1}" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and 2 of them
}
rule SEKOIA_Apt_Kimsuky_Klogexe : FILE
{
	meta:
		description = "Detects KLogExe, a keylogger used by Kimsuky"
		author = "Sekoia.io"
		id = "f6e3b1a5-43b6-4dac-83c2-a365c41de38d"
		date = "2024-09-27"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_kimsuky_klogexe.yar#L1-L32"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "e1d683ee1746c08c5fff1c4c2b3b02f0"
		hash = "90946c6358eacd119fe1eb36ec7a0a18"
		hash = "9760f489a390665b5e7854429b550c83"
		logic_hash = "4b616908ceacd85c5d8b527cd1a718082c709071dc1fa9c9ccc96e71dc4e7449"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$event = "Norton_BreakHelper" ascii wide
		$log = "------ %d/%d/%d : %d/%d ------" ascii wide
		$keylog_1 = "[RM+]"
		$keylog_2 = "[Tab+]"
		$keylog_3 = "[Home+]"
		$keylog_4 = "[End+]"
		$keylog_5 = "[clip_s]: %s "
		$keylog_6 = "%s[Too many clip_tail]"
		$keylog_7 = "%s[F%d]"
		$user_agent = "Chrome/31.0." wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 600KB and 8 of them
}
rule SEKOIA_Apt_Evasive_Panda_Downloader_Certificate_Exe : FILE
{
	meta:
		description = "Detects downloader used by Evasive Panda (certificate.exe)"
		author = "Sekoia.io"
		id = "1b40fca9-04b1-46b3-b48c-5a148a1b36b9"
		date = "2024-03-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_evasive_panda_downloader_certificate_exe.yar#L1-L15"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "38115b463378f58035a0ef0536a6af4adbec7c275164758d312e95300670b695"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = {C6 45 D4 44 C6 45 D5 74 C6 45 D6 7C C6 45 D7 74 C6 45 D8 79}

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Malware_Valleyrat_1Ststage_Strings : FILE
{
	meta:
		description = "Detects ValleyRat 1stage"
		author = "Sekoia.io"
		id = "6628ba47-37ad-4bdb-bbc0-7286d777000e"
		date = "2024-06-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/malware_valleyrat_1ststage_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "78c45b8bd9241646512483d179d48b0e42e97fa1c18d6afd1af4423f7b7ce3c6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "%016llX.DLL" wide
		$ = "%s\\%s" wide
		$ = "%016llX\\%s" wide
		$ = "connection already in progress"
		$ = "SleepConditionVariableSRW"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 4MB and all of them
}
rule SEKOIA_Apt_Gamaredon_Stealer_Obfuscation_2 : FILE
{
	meta:
		description = "Matches the Gamaredon Stealer obfuscation"
		author = "Sekoia.io"
		id = "fd278a90-537b-4c67-9421-01c9f2416b60"
		date = "2022-02-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gamaredon_stealer_obfuscation_2.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6ffd8504ba8ca614d3941bd46b944d85e0ad4b9d8d2960d508f50550497d2852"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = { 3d 20 6e 65 77 20 73 74 72 69 6e 67 5b 5d 20 7b 20 [50-200] 20 7d 3b }

	condition:
		uint16be( 0 ) == 0x4d5a and filesize > 100MB and #s1 > 40
}
rule SEKOIA_Trojan_Win_Bbtok_Lnk_Sep23 : FILE
{
	meta:
		description = "Finds BBTok installation LNK file"
		author = "Sekoia.io"
		id = "b1d5dae6-d92f-4a4a-ae90-528cdb3e9e4c"
		date = "2023-09-26"
		modified = "2024-12-19"
		reference = "https://research.checkpoint.com/2023/behind-the-scenes-of-bbtok-analyzing-a-bankers-server-side-components/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/trojan_win_bbtok_lnk_sep23.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "32bf07e3740399105359b62d8a612dfa731b024e06c9104b71b496919b5efe9e"
		logic_hash = "5783487585dde1314c485bdcf3942b7e8b572c0689522ea136240833d2a64f5b"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$lnk = {4C 00 00 00}
		$str01 = "%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe" ascii wide
		$str02 = ".pdf /Y & start" wide
		$str03 = "\\Microsoft.NET\\Framework\\v4.0.30319\\MSBuild.exe -nologo" wide

	condition:
		all of them and filesize < 10KB
}
rule SEKOIA_Apt_Ir_Sugarush_Implant : FILE
{
	meta:
		description = "Detects the SUGARUSH implant"
		author = "Sekoia.io"
		id = "bcf057cc-272c-4cb6-bb76-928788675282"
		date = "2022-08-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_ir_sugarush_implant.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0d249552013c29ce1eb66dca2d93e5cde0a1b0fb80aae55469bec3bda224be91"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "You are offline at " wide
		$ = "\\Logs\\ServiceLog_" wide
		$ = "Service is recall at" wide
		$ = "add_OutputDataReceived" ascii
		$ = "get_CurrentDomain" ascii

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 100KB and all of them
}
rule SEKOIA_Loader_Win_Fudloader : FILE
{
	meta:
		description = "Finds FUD-Loader samples based on specific strings"
		author = "Sekoia.io"
		id = "4c2ac614-89af-4449-9fd2-9f935e4c27b8"
		date = "2023-09-25"
		modified = "2024-12-19"
		reference = "https://github.com/0day2/FUD-Loader/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_fudloader.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "bf19169963cfcbcf41a2dc5f9447738e957878972590b2a8d310eed1c54f3676"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "set_WindowStyle" ascii
		$str02 = "set_FileName" ascii
		$str03 = "get_StartInfo" ascii
		$str04 = "GetRandomFileName" ascii
		$str05 = "DownloadFile" ascii
		$str06 = "GetTempPath" ascii
		$str07 = "ProcessStartInfo" ascii
		$str08 = "System.Diagnostics" ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them and filesize < 10KB
}
rule SEKOIA_Rat_Win_Reverserat
{
	meta:
		description = "Detect SideCopy's ReverseRAT v3 observed in January 2023"
		author = "Sekoia.io"
		id = "8fbd395f-f44e-46d5-a942-7c7e88f37127"
		date = "2023-02-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_reverserat.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "b277a824b2671f40298ce03586a2ccc0fca2a081a66230c57a3060c2028f13ee"
		hash = "8b87459483248d7b95424cd52b7d4f3031e89c6644adc2e167556e071d9ec3aa"
		logic_hash = "13a5a916e084996ce4d7840581250f7630652acdcad0f66e21763cb3a9cbccc3"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "SELECT maxclockspeed,  datawidth, name, manufacturer FROM Win32_Processor" wide
		$ = "select * from Win32_PhysicalMemory" wide
		$ = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall" wide

	condition:
		all of them
}
rule SEKOIA_Generic_Sharpshooter_Payload_10 : FILE
{
	meta:
		description = "Detects payload created by SharpShooter"
		author = "Sekoia.io"
		id = "477f8b92-e231-460c-8660-487d0a97f0e2"
		date = "2023-02-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/generic_sharpshooter_payload_10.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6ded3f5b7e9c7f2c09e3bc0869e41775e4bb31a39e6fef8209f50f5091e8d2e2"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "length = enc.GetByteCount_2(b);"
		$ = "ms.Write(ba, 0, (length / 4) * 3);"
		$ = "d.DynamicInvoke(al.ToArray()).CreateInstance(entry_class);"

	condition:
		all of them and filesize < 2MB
}
rule SEKOIA_Apt_Aridviper_Rustsysjoker : FILE
{
	meta:
		description = "Detects Rust Sysjoker variant via PDB path or key and Rust string"
		author = "Sekoia.io"
		id = "14ff3f76-0371-4b45-9864-bf69c74e60aa"
		date = "2023-11-27"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_aridviper_rustsysjoker.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "cb3c5d37095c27aa169a6aa61fa12972ff71877c615eaa254c3906ef10c662a9"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$Rust = "called `Option::unwrap()` on a `None` value"
		$Key = "QQL8VJUJMABL8H5YNRC9QNEOHA"
		$PDB = "C:\\Code\\Rust\\RustDown-Belal\\target\\release\\deps\\RustDown.pdb"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and ( $PDB or ( $Rust and $Key ) )
}
rule SEKOIA_Apt_Uta0178_Javascript_Inclusion_Strings
{
	meta:
		description = "Detects UTA0178 malicious inclusion strings"
		author = "Sekoia.io"
		id = "af816c35-1f00-47ea-86ee-c034607c625e"
		date = "2024-01-12"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_uta0178_javascript_inclusion_strings.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "d3fedf49417178df374d6ae20e57ffcfa00cb68a647769964c049d9a8e0f4958"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s0 = ".value"
		$s1 = "btoa("
		$s2 = "https://"
		$s3 = "new XMLHttpRequest();"
		$s4 = ".send(null);"

	condition:
		@s0< @s1 and @s1 < @s2 and @s2 < @s3 and @s3 < @s4 and @s4- @s0 < 350
}
rule SEKOIA_Apt_Apt28_Wayzgoose_Exploit_String : FILE
{
	meta:
		description = "Detects APT28's Wayzgoose exploit strings"
		author = "Sekoia.io"
		id = "23d9e09e-202c-47f5-abf7-6b5085e44400"
		date = "2024-04-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt28_wayzgoose_exploit_string.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "804de275f7e8c43fe5690c0bd9338b134c0c47f845f1c3b3a747c3765815084c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "wayzgoose.dll"
		$ = "wayzgoose_get_version"
		$ = "NtSetInformationFile"
		$ = "ZwDuplicateObject"
		$ = "ZwClose"

	condition:
		uint16be( 0 ) == 0x4d5a and 4 of them and filesize < 500KB
}
rule SEKOIA_Backdoor_Win_Feedload : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "29cc46c4-7ed7-4a34-9749-a8ba8d37eb4c"
		date = "2023-10-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_win_feedload.yar#L1-L15"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "f251144f7ad0be0045034a1fc33fb896e8c32874e0b05869ff5783e14c062486"
		logic_hash = "18eb3fc9b11ed21a76a2921c3d9681b09cf2f306263c2ece76c1bf4a65467777"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "                                        C:\\LibreSS5\\crypto\\"

	condition:
		uint16be( 0 ) == 0x4d5a and #s1 > 200
}
rule SEKOIA_Infostealer_Win_Solarmarker_Dll : FILE
{
	meta:
		description = "Finds SolarMarker DLL based on characteristic strings"
		author = "Sekoia.io"
		id = "a2fe7f09-7134-4054-ba40-5ea66785a26c"
		date = "2022-12-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_solarmarker_dll.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5be0a95adb7e486cdec5f0e8433afed41516fc1a990e1d1ba00db7e8fb32dbbb"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$zka = "zkabsr" wide
		$str0 = "set_PersistKeyInCsp" ascii
		$str1 = "get_IV" ascii
		$str2 = "get_MachineName" ascii
		$str3 = "get_Current" ascii
		$str4 = "ps_script" ascii
		$str5 = "request_data" ascii
		$str6 = "WindowsBuiltInRole" ascii
		$str7 = "DllImportAttribute" ascii
		$str8 = "get_BlockSize" ascii
		$str9 = "GetRequestStream" ascii

	condition:
		uint16( 0 ) == 0x5A4D and ( ( $zka and 3 of ( $str* ) ) or ( all of ( $str* ) ) ) and filesize < 1MB
}
rule SEKOIA_Apt_Granitetyphoon_Sword2023_Strings : FILE
{
	meta:
		description = "Detects Sword2023 malware based on strings"
		author = "Sekoia.io"
		id = "417b355f-9eb8-40ae-bc3b-f7f23b5ca63e"
		date = "2023-05-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_granitetyphoon_sword2023_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8644547f093295eeac30c9040796329a3e2222c06a942d14899545726c8bed78"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "TERM=linux"
		$ = ";echo"
		$ = "sh:time out"
		$ = "sh:read stdout error"
		$ = "/proc/sys/kernel/random/uuid"

	condition:
		( uint32be( 0 ) == 0x7f454c46 ) and filesize < 100KB and all of them
}
rule SEKOIA_Infostealer_Win_Banditstealer : FILE
{
	meta:
		description = "Finds BanditStealer samples based on specific strings"
		author = "Sekoia.io"
		id = "d1e45a5c-c06d-4161-8d30-fa94bcf0ea7a"
		date = "2023-07-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_banditstealer.yar#L1-L35"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "64d4860dd8a783be10541dd5c939dcd2a2b08309a7cd17b9dbbda1ba8b26485d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$spe01 = "Banditstealer" ascii
		$spe02 = "BANDIT STEALER" ascii
		$spe03 = "Location: Geolocation: " ascii
		$spe04 = "awesomeProject2/core.GetWallets" ascii
		$spe05 = "awesomeProject2/core.GetCreditCards" ascii
		$spe06 = "awesomeProject2/core.GetCookies" ascii
		$spe07 = "awesomeProject2/core.KillProcessByName" ascii
		$spe08 = "main.sendZipToTelegram" ascii
		$str01 = "json:\"city\"" ascii
		$str02 = "UAC disabled" ascii
		$str03 = "\\OpenVPN Connect\\profiles\\" ascii
		$str04 = "\\Documents\\Monero\\wallets\\" ascii
		$str05 = "cookies.sqlite" ascii
		$str06 = "creditcard.txt" ascii
		$str07 = "vmware.exe" ascii
		$str08 = "aeachknmefphepccionboohckonoeemg" ascii
		$str09 = "\\Documents\\NetSarang\\Xftp\\Sessions\\" ascii
		$str10 = "\\WhatsApp\\Local Storage\\leveldb\\" ascii
		$str11 = "Visited Time: %s" ascii
		$str12 = "\\Google\\Chrome\\User Data\\Telegram Desktop\\tdata\\" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 2 of ( $spe* ) and 6 of ( $str* )
}
rule SEKOIA_Tool_Bore_Rust_Any_Platform : FILE
{
	meta:
		description = "Detects bore tunneling tool"
		author = "Sekoia.io"
		id = "c0ec0d72-de8e-4b96-9db6-a7a4e2f693f1"
		date = "2023-07-28"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_bore_rust_any_platform.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c51d75088897aaffef904d560f750d780a0c814b89bf433a05189fbf7bb3285c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "bore_cli::" ascii
		$ = "server handshake failed" ascii
		$ = "server listening" ascii
		$ = "connected to server" ascii
		$ = "server requires authentication, but no client secret was provided" ascii
		$ = "client port number too low" ascii
		$ = "forwarding connection" ascii
		$ = "Address of the remote server to expose local ports" ascii

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint32be( 0 ) == 0xfeedface or uint32be( 0 ) == 0xfeedfacf or uint32be( 0 ) == 0xcafebabe or uint16be( 0 ) == 0x4d5a ) and filesize < 15MB and 5 of them
}
rule SEKOIA_Backdoor_Powershellempire_Gen : FILE
{
	meta:
		description = "Detects EmpirePowershell"
		author = "Sekoia.io"
		id = "36050a5b-bdca-45cd-8e26-7129fdcbf1e8"
		date = "2022-04-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_powershellempire_gen.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "21f255bcfb6da2aa996ed61ff5fb29a9355de6169095f7c3141a1b7f3cea5c2d"
		score = 75
		quality = 76
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "%{$J=($J+$S[$_]+$K[$_%$K.COUNt])%256;" nocase wide ascii
		$ = "($IV+$K))|IEX" nocase wide ascii

	condition:
		all of them and filesize < 1MB
}
rule SEKOIA_Backdoor_Win_Volgmer : FILE
{
	meta:
		description = "Detect the NukeSped variant called Volgmer used by Andariel"
		author = "Sekoia.io"
		id = "9468a66d-787c-488f-937b-22617c7a2ded"
		date = "2023-09-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_win_volgmer.yar#L1-L32"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "3098e6e7ae23b3b8637677da7bfc0ba720e557e6df71fa54a8ef1579b6746061"
		hash = "7339cfa5a67f5a4261c18839ef971d7f96eaf60a46190cab590b439c71c4742b"
		hash = "8daa6b20caf4bf384cc7912a73f243ce6e2f07a5cb3b3e95303db931c3fe339f"
		hash = "1b88b939e5ec186b2d19aec8f17792d493d74dd6ab3d5a6ddc42bfe78b01aff1"
		logic_hash = "700fcfcc3df1d81af99db38e305f64ca87f8368fc0149c9ad64d75c2917ec1f3"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Fixed" wide
		$ = "CDRom" wide
		$ = "Removable" wide
		$ = "%.2fGB" wide
		$ = "\\*.*" wide
		$ = "Folder" wide
		$ = "%.1fKB" wide
		$ = "%.1fMB" wide
		$ = "%s\\*.*" wide
		$ = "%s\\%s\\%s" wide
		$ = "%s\\%s%s" wide
		$ = "Remote PC" wide
		$ = "%s|%s|%s|%s|%s|%s|" wide
		$ = "%s\\cmd.exe" wide

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Loader_Fakebat_Powershell_Fingerprint_May24 : FILE
{
	meta:
		description = "Finds FakeBat PowerShell script fingerprinting the infected host."
		author = "Sekoia.io"
		id = "7efcf9cf-78fe-400e-abe3-6955c394e358"
		date = "2024-06-21"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_fakebat_powershell_fingerprint_may24.yar#L1-L27"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "04e5c888e5f71873c4fa2d732fbd8e40be3edf406300e65e489e1fa378028c5f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "Get-WmiObject Win32_ComputerSystem" ascii
		$str02 = "-Class AntiVirusProduct" ascii
		$str03 = "status = \"start\"" ascii
		$str04 = " | ConvertTo-Json" ascii
		$str05 = ".FromXmlString(" ascii
		$str06 = " = Invoke-RestMethod -Uri " ascii
		$str07 = ".Exception.Response.StatusCode -eq 'ServiceUnavailable'" ascii
		$str08 = "Invoke-WebRequest -Uri $url -OutFile " ascii
		$str09 = "--batch --yes --passphrase-fd" ascii
		$str10 = "--decrypt --output" ascii
		$str11 = "Invoke-Expression \"tar --extract --file=" ascii

	condition:
		7 of them and filesize < 10KB and true
}
rule SEKOIA_Apt_Muddywater_Powgoop_Loader : FILE
{
	meta:
		description = "Detects the loader of PowGoop malware"
		author = "Sekoia.io"
		id = "716b45e1-9f17-4546-a003-a7c78340d623"
		date = "2022-01-13"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_muddywater_powgoop_loader.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "70f20928d2bbe081f0595ecdbb6dbe58a2f0807032598d88d829513e6d75287f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "$d.Add($in[$i]);" ascii wide
		$s2 = "[System.Text.Encoding]::UTF8.GetString($o);" ascii wide
		$s3 = "$i+=(1+1)" ascii wide
		$t = { 24 ?? 3d [1-15] 20 24 ?? 3b ?? ?? ?? 20 24 ?? 3b }

	condition:
		filesize < 50KB and ( 3 of ( $s* ) or $t in ( filesize -50 .. filesize ) )
}
rule SEKOIA_Apt_Badmagic_Commonmagic_Main : FILE
{
	meta:
		description = "Detects CommonMagic related implants"
		author = "Sekoia.io"
		id = "99983df5-89d6-4fac-81e6-16e5ab20bde3"
		date = "2023-05-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_badmagic_commonmagic_main.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "9bcfd6e9e150399c7f11abc41205119ddf24ea0fef5816ed905cd9b1e9ec5c1e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "graph.microsoft.com" ascii wide
		$ = "children?select=name,size" ascii wide fullword
		$ = "\\\\.\\pipe\\PipeCrDtMd" ascii wide fullword

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and all of them
}
rule SEKOIA_Trojan_Win_Bbtok_Iso_Sep23 : FILE
{
	meta:
		description = "Finds BBTok installation ISO file"
		author = "Sekoia.io"
		id = "6032853d-b872-4b2e-913d-366e7f3d0f32"
		date = "2023-09-26"
		modified = "2024-12-19"
		reference = "https://research.checkpoint.com/2023/behind-the-scenes-of-bbtok-analyzing-a-bankers-server-side-components/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/trojan_win_bbtok_iso_sep23.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "140e83d2e0d012cdd5625ea89c3b3af05a80877cfc8215bbe20823e7e88c80b1"
		logic_hash = "efef1e4e50d84cd30c025c86beb751c73a996cca896f90729571f48259ffc110"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$iso = {43 44 30 30 31}
		$str01 = "POWERISO" ascii
		$str02 = "%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe" ascii wide
		$str03 = ".pdf /Y & start" wide
		$str04 = "\\MSBuild.exe -nologo \\\\" ascii wide

	condition:
		all of them and filesize < 500KB
}
rule SEKOIA_Apt_Nobelium_Acrobox_Downloader_Apr2022 : FILE
{
	meta:
		description = "Detects AcroBox downloader"
		author = "Sekoia.io"
		id = "77f7f01d-72a2-4b13-b23f-d938a415dd40"
		date = "2022-05-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_nobelium_acrobox_downloader_apr2022.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ebcbdf13908971eea3e5b291719527e2e454a9ee3b98b5dc66149b2bb3b8fe67"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = { 80 ?? 7B
        0F 84 ?? ?? 00 00
        80 ?? ?? 0F
        0F 84 ?? ?? 00 00
        80 ?? ?? 0F
        0F 84 ?? ?? 00 00
        80 ?? ?? 0F
        0F 84 ?? ?? 00 00 }

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 200KB and all of ( $s* )
}
rule SEKOIA_Generic_Sharpshooter_Payload_2 : FILE
{
	meta:
		description = "Detects payload created by SharpShooter"
		author = "Sekoia.io"
		id = "02bc795f-b8e0-44d4-b475-310359867577"
		date = "2023-02-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/generic_sharpshooter_payload_2.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c26779cd35d6430da3629df8b310356d663c05e82db0aca0fc974bc3a298c92e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "var e={},i,b=0,c,x,l=0,a,r="
		$ = "eval(plain);"
		$ = "var plain = rc4("

	condition:
		all of them and filesize < 2MB
}
rule SEKOIA_Hacktool_Lazagne_Strings : FILE
{
	meta:
		description = "Detects LaZagne hacktool based on strings"
		author = "Sekoia.io"
		id = "5a5e7a07-1252-48cc-ada5-46e796c4e00e"
		date = "2022-02-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_lazagne_strings.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a6db351fee9a28b1a6d82c2ce063088a1050ee8379cc13ca3cf8cc2038043951"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$w1 = "lazagne.softwares"
		$w2 = "pypykatz.lsadecryptor"
		$l0 = "PyModule_GetDict"
		$l1 = "softwares.sysadmin.filezilla"
		$l2 = "softwares.walle"
		$l3 = "softwares.databases.sqldeveloper"
		$l4 = "softwares.wifi.wpa_supplicant"

	condition:
		( uint32be( 0 ) == 0x7f454c46 and all of ( $l* ) ) or ( uint16be( 0 ) == 0x4d5a and all of ( $w* ) ) and filesize < 40MB
}
rule SEKOIA_Apt_Gamaredon_Ddrdoh_Vbs_Downloader : FILE
{
	meta:
		description = "Detects the core of the VBS Gamaredon's Telegram Downloader"
		author = "Sekoia.io"
		id = "c934b95d-d81d-4f58-a752-1bb31ba8593d"
		date = "2023-01-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gamaredon_ddrdoh_vbs_downloader.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "940635313b23e29ac98310fc0f20352405c96190d56cd36ef028bf4d6e77fa6b"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$a1 = "==([0-9\\@]+)==" ascii
		$a2 = "data\"\":\"\"(.*?)" ascii
		$a3 = ", vbcr ,\"\")" ascii
		$a4 = ", vblf ,\"\")" ascii
		$a5 = ", \"&&\" ,\"\")" ascii
		$a6 = "ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4" ascii
		$b1 = "==([0-9\\@]+)==" base64
		$b2 = "data\"\":\"\"(.*?)" base64
		$b3 = ", vbcr ,\"\")" base64
		$b4 = ", vblf ,\"\")" base64
		$b5 = ", \"&&\" ,\"\")" base64
		$b6 = "ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4" base64

	condition:
		(4 of ( $a* ) or 4 of ( $b* ) ) and filesize < 50KB
}
rule SEKOIA_Unk_Quad7_Fsynet_Strings : FILE
{
	meta:
		description = "Matches node-r-control, asr_node, node-relay"
		author = "Sekoia.io"
		id = "897b2421-c177-48c0-8f5b-82d8434208cb"
		date = "2024-08-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/unk_quad7_fsynet_strings.yar#L1-L33"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "f42849076e24b7827218f7a25bc11ccc"
		hash = "b3b09819f820a4ecd31f82f369000af2"
		hash = "92093dd7ba6ae8fe34a215c4c4bd1cd4"
		hash = "e6f6a6de285d7c2361c32b1f29a6c3f6"
		hash = "408152285671bbd0e6e63bd71d6abaaf"
		hash = "5efc7d824851be9ec90a97d889a40d23"
		logic_hash = "960119a025dedae7c5dfdf872cd515e2b6cf2999179ba84374d547047316caa2"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "prev_hop_port"
		$ = "next_hop_port"
		$ = "back_hop_port"
		$ = "next_tsn_port"
		$ = "prev_hop_ip"
		$ = "next_hop_ip"
		$ = "back_hop_ip"
		$ = "next_tsn_ip"
		$ = "ikcp_"
		$ = "/tmp/log_r"
		$ = "total_hop"

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 5MB and 6 of them
}
rule SEKOIA_Pe_Stealer_Scarletstealer_Strings : FILE
{
	meta:
		description = "ScarletStealer strings"
		author = "Sekoia.io"
		id = "ca930851-513f-44e5-abb4-ca0edfde3428"
		date = "2023-12-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/pe_stealer_scarletstealer_strings.yar#L1-L33"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "308055cbe960614112682585b5709a62c2639752df07661d6b2bb13e390b3b08"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "Scarlet Client" wide
		$s2 = "] PC NAME:   (" wide
		$s3 = "] IP:   (" wide
		$s4 = " - Wallets -" wide
		$s5 = "] Exodus:  (" wide
		$s6 = "] Electrum:  (" wide
		$s7 = "] Atomic:  (" wide
		$s8 = "] Guarda:  (" wide
		$s9 = "] Coinomi: (" wide
		$s10 = "] Monero:  (" wide
		$s11 = "] Ledger:  (" wide
		$s12 = "] Bitbox:  (" wide
		$s13 = "] Trezor:  (" wide
		$s14 = ") Support: PointX@exploit.im - @isPointX" wide
		$a2 = "/config/tk.txt" wide
		$a3 = "/config/chatid.txt" wide
		$a1 = "telebyt.com" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize > 50KB and filesize < 2MB and 13 of ( $s* ) and 2 of ( $a* )
}
rule SEKOIA_Apt_Badmagic_Commonmagic_Generic_2 : FILE
{
	meta:
		description = "Detects CommonMagic related implants"
		author = "Sekoia.io"
		id = "c6a16ecc-e00a-4756-b603-f6c85e4f4220"
		date = "2023-05-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_badmagic_commonmagic_generic_2.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "d3916ab749ae5b6e0a8abdc9641de13e0328809a6e20c6ce04ada5dbfb742689"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "\\CommonCommand\\" ascii wide
		$ = "\\\\.\\pipe\\PipeMd" ascii wide fullword
		$ = "\\\\.\\pipe\\PipeDtMd" ascii wide fullword
		$ = "\\\\.\\pipe\\PipeCrDtMd" ascii wide fullword

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and 2 of them
}
rule SEKOIA_Hacktool_Mimikat_Ssp_Strings : FILE
{
	meta:
		description = "Detects mimikat_ssp"
		author = "Sekoia.io"
		id = "33b3620f-e02d-4d29-adcc-fea3b49ab780"
		date = "2023-11-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_mimikat_ssp_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "06325bf495963db90b14fb16a5f3eafda9e4554f753d04405af51c6041a9b166"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[*] Building RPC packet" ascii
		$ = "[*] Connecting to lsasspirpc RPC service" ascii
		$ = "[*] Sending SspirConnectRpc call" ascii
		$ = "[*] Sending SspirCallRpc call" ascii

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 500KB and all of them
}
rule SEKOIA_Apt_Sandworm_Orcshred_Apr2022 : FILE
{
	meta:
		description = "Detects the ORCSHRED script"
		author = "Sekoia.io"
		id = "1a88800c-29e1-4e2c-8374-f5a93dd9fd91"
		date = "2022-04-12"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_sandworm_orcshred_apr2022.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "de38cf43fa5cc756c26ae241f2e60636c2aabbe4254fdeca2340c62873498de7"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "find /etc -name os-release >"
		$ = "/bin/bash /var/"
		$ = "crontab -l >"
		$ = ".sh & disown"

	condition:
		3 of them and filesize < 2KB
}
rule SEKOIA_Apt_Gamaredon_Powerrevshell : FILE
{
	meta:
		description = "Detects Powershell reverse shell"
		author = "Sekoia.io"
		id = "b5161c23-c607-4096-9f4a-1be516a0a614"
		date = "2023-02-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gamaredon_powerrevshell.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "fc5abcdf47641c1e7978cf076550f38987305bb2171b3e65f7865102a065af43"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "iex $enc.GetString("
		$ = "$stream.Write"
		$ = ".).FullName"
		$ = "Sockets.TcpClient"
		$ = "\">\";"

	condition:
		all of them and filesize < 3000
}
rule SEKOIA_Ursnif : FILE
{
	meta:
		description = "Ursnif Payload"
		author = "Sekoia.io"
		id = "ac392af3-c344-453c-9427-5bb46223e01c"
		date = "2024-12-19"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ursnif.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "fd3c3be5ede0a980b44560cfb9b8c4c1ee322091fa86bc9143f30dc900053c2b"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$crypto64_1 = {41 8B 02 ?? C1 [0-1] 41 33 C3 45 8B 1A 41 33 C0 D3 C8 41 89 02 49 83 C2 04 83 C2 FF 75 D?}
		$crypto64_2 = {44 01 44 24 10 FF C1 41 8B C0 D1 64 24 10 33 C3 41 8B D8 FF 4C 24 10 41 33 C3 01 44 24 10 D3 C8 01 44 24 10 41 89 02 49 83 C2 04 83 C2 FF 75 C3}
		$crypto64_3 = {33 C6 ?? C7 [0-1] 49 83 C2 04 33 C3 8B F1 8B CF D3 C8 89 02 48 83 C2 04 41 83 C3 FF 75 ?? 45 85 C9 75 ?? 41 83 E0 03}
		$crypto64_4 = {41 8B 02 41 8B CB 41 83 F3 01 33 C3 41 8B 1A C1 E1 03 41 33 C0 D3 C8 41 89 02 49 83 C2 04 83 C2 FF 75 C6}
		$decrypt_config64 = {44 8B D9 33 C0 45 33 C9 44 33 1D ?? ?? ?? 00 ?? ?? D2 ?? ?? D2 74 ?? 4C 8D 42 10 45 3B 0A 73 2? 45 39 58 F8 75 1C 41 F6 40 FC 01 74 12}
		$crypto32_1 = {01 45 FC D1 65 FC FF 4D FC 33 C1 33 45 0C 01 45 FC 43 8A CB D3 C8 8B CE 01 45 FC 89 02 83 C2 04 FF 4D 08 75 CD}
		$crypto32_2 = {33 C1 33 44 24 10 43 8A CB D3 C8 8B CE 89 02 83 C2 04 FF 4C 24 0C 75 D9}
		$decrypt_config32 = {8B ?? 08 5? 33 F? 3B [1-2] 74 14 A1 0? ?? ?? ?? 35 ?? ?? ?? ?? 50 8B D? E8 ?? D? 00 00 EB 02 33 C0 ?B ?? ?? ?? ?? ?? ?? ?? 74 14 8D 4D ?? ?? ?? 50 FF D? 85 C0 74 08}

	condition:
		true and uint16( 0 ) == 0x5A4D and ( ( $decrypt_config64 and any of ( $crypto64* ) ) or ( $decrypt_config32 and any of ( $crypto32* ) ) )
}
rule SEKOIA_Exploit_Linux_Eop_Pwnkit_Strings : FILE
{
	meta:
		description = "Detects Pwnkit Local Privesc exploit"
		author = "Sekoia.io"
		id = "8637c602-62da-4983-bcb7-ba546fb2ed82"
		date = "2023-12-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/exploit_linux_eop_pwnkit_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "9805cc7a6022f7a3372df5d74cef68c6fd0e51072154c82212415846f3603667"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "CHARSET=PWNKIT"
		$ = "i/do/not/exists"
		$ = "pwnkit/pwnkit.c"
		$ = "/usr/bin/pkexec"
		$ = "SHELL=pwnkit"
		$ = "pwnkit.so"
		$ = "./pwnkit/"

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 1MB and 2 of them
}
rule SEKOIA_Apt_Unk_Batcopier_Strings : FILE
{
	meta:
		description = "Detects BatCopier variant"
		author = "Sekoia.io"
		id = "eb76bbd0-a722-4fec-a4a7-c48c70a1880b"
		date = "2024-09-06"
		modified = "2024-12-19"
		reference = "https://www.seqrite.com/blog/operation-oxidovy-sophisticated-malware-campaign-targets-czech-officials-using-nato-themed-decoys/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_unk_batcopier_strings.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0007d6d00d5b8db048456bb566ef9ed4516c4e1b392cc73c40396785ba885f55"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "@echo off"
		$ = "echo F|xcopy"
		$ = "attrib +r +s +h"

	condition:
		all of them and filesize < 1KB
}
rule SEKOIA_Apt_Susp_Apt28_Uac0063_Hta_Loader
{
	meta:
		description = "Detects some suspected APT28 HTA loader"
		author = "Sekoia.io"
		id = "8e1889c1-c6ac-4048-9d3a-99ccbbd5435f"
		date = "2024-07-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_susp_apt28_uac0063_hta_loader.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "332d9db35daa83c5ad226b9bf50e992713bc6a69c9ecd52a1223b81e992bc725"
		logic_hash = "494331a8088d350e4e49e67fe64041d451886e501775413f908bd9b3faa98aeb"
		score = 65
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "<HEAD><HTA:APPLICATION ID" ascii fullword
		$ = "id=service>null</span" ascii fullword
		$ = "script Language=\"VBScript.Encode" ascii fullword

	condition:
		2 of them
}
rule SEKOIA_Tool_Ssf_Strings : FILE
{
	meta:
		description = "Detects SSF based on strings"
		author = "Sekoia.io"
		id = "47fc3df8-a153-4045-a5f0-ed30df662984"
		date = "2024-05-31"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_ssf_strings.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a6fa09a25c90e00466a2b59f8c604084996224c93021ad72ed8705bf05da5d97"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "could NOT read SSF reply"
		$ = "SSF reply NOT ok {}"
		$ = "SSF reply OK"
		$ = "SSF protocol error {}"
		$ = "SSF reply ok"
		$ = "SSF version NOT read {}"
		$ = "SSF version {}"
		$ = "SSF version NOT supported {}"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and 4 of them
}
rule SEKOIA_Loader_Win_Batloader_Scripts : FILE
{
	meta:
		description = "Finds BatLoader samples based on the specific download URL"
		author = "Sekoia.io"
		id = "31a04ad3-74f8-4aa5-b3fc-df792bdc71b5"
		date = "2022-11-30"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_batloader_scripts.yar#L1-L30"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "aab6c7780bbc7bed8994b4e70129107bb7b719642fae92b1d3f9146eb11efabc"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$url = /https?:\/\/[^\s]{15,35}\/index\/[^\s]{1,40}servername=msi/ ascii wide
		$str00 = "Invoke-WebRequest" ascii wide
		$str01 = "PSScriptRoot" ascii wide
		$str02 = "Add-MpPreference" ascii wide
		$str03 = "Install-GnuPG" ascii wide
		$str04 = "wmic computersystem get domain" ascii wide
		$str05 = "ArpInfo" ascii wide
		$str06 = "$script:List_ProccesCheck" ascii wide
		$str07 = "Get-Process -Name" ascii wide
		$str08 = "f001_SetProcessList" ascii wide
		$str09 = "var WshShell" ascii wide
		$str10 = "WScript.Sleep" ascii wide
		$str11 = "WshShell.Run" ascii wide
		$str12 = "powershell Invoke-WebRequest" ascii wide
		$str13 = "-nop -w hidden " ascii wide

	condition:
		$url and 2 of ( $str* ) and filesize < 50KB
}
rule SEKOIA_Tool_Nping_Strings : FILE
{
	meta:
		description = "Detects NPing"
		author = "Sekoia.io"
		id = "fcfd9539-b224-45b4-9252-0b4d56a40be4"
		date = "2022-08-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_nping_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0c7216438e9c974d889e4ccc8cdb99ab18d1dc403820d60914b80ff9bc4528fa"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "http://nmap.org/nping"
		$ = "nping scanme.nmap.org"
		$ = "Bogus target structure passed to %s"
		$ = "Packet too short."
		$ = "read_arp_reply_pcap"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and 3 of them and filesize < 1MB
}
rule SEKOIA_Crimeware_Njrat_Strings : FILE
{
	meta:
		description = "Detects njRAT based on some strings"
		author = "Sekoia.io"
		id = "215807ae-fbcb-478d-8941-e0787b883669"
		date = "2022-08-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/crimeware_njrat_strings.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "47102adde81682c3c1c856c3495c6f98a9e39aa052eac2ab0a803dab44d19c26"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "set cdaudio door closed" wide
		$ = "set cdaudio door open" wide
		$ = "ping 0" wide
		$ = "[endof]" wide
		$ = "TiGeR-Firewall" wide
		$ = "NetSnifferCs" wide
		$ = "IPBlocker" wide
		$ = "Sandboxie Control" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and 5 of them
}
rule SEKOIA_Apt_Sugardump_Credentials_Stealer_Http : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "47d01ba8-9fdd-42d5-9f10-115f982dc133"
		date = "2022-08-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_sugardump_credentials_stealer_http.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8d1725da41704fd534d3438021a98d0fb9b9b5bfdc63cc3144c4957954be1870"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "\\Google\\Chrome\\User Data" wide
		$ = "\\DebugLogWindowsDefender.txt" wide
		$ = "Opera Software\\Opera Stable" wide
		$ = "Microsoft\\Edge\\User Data" wide
		$ = "\"encrypted_key\":\"(.*?)\\" wide
		$ = "Url:" wide
		$ = "Username:" wide
		$ = "Password:" wide
		$ = "Application:" wide
		$ = "BCrypt.BCryptDecrypt" wide
		$ = "C:\\Users\\User\\" wide
		$ = "_CorExeMain"
		$ = "http://" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and 10 of them
}
rule SEKOIA_Loader_Win_Bumblebee : FILE
{
	meta:
		description = "Detect BUMBLEBEE based on specific strings"
		author = "Sekoia.io"
		id = "ff36f512-c700-4f52-bc89-68ab9c69462c"
		date = "2022-04-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_bumblebee.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "97755e8d593acbc9acc8ce7f1a82a345fc7eea049addbb96577f6abc1b6d5fd6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str0 = "Z:\\hooker2\\Common\\md5.cpp" wide
		$str1 = "3C29FEA2-6FE8-4BF9-B98A-0E3442115F67" wide
		$str2 = "bumblebee" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 2 of them
}
rule SEKOIA_Apt_Susp_Apt28_Uac0063_Malicious_Doc : FILE
{
	meta:
		description = "Detects some suspected APT28 document"
		author = "Sekoia.io"
		id = "2b9d597a-a6cd-49df-8938-7103342a1d06"
		date = "2024-07-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_susp_apt28_uac0063_malicious_doc.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "93322be0785556e627d2b09832c18e39c115e6a6fbff64b1e590e1ddcf8f6a43"
		logic_hash = "27aeadbb76dd4e670a85e8fcd1e885b69845537dd937aacc1808902e75008848"
		score = 65
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Sub pop() : : End Sub" ascii fullword
		$ = "%localappdata%\\Temp" ascii fullword
		$ = "rthedbv" ascii fullword

	condition:
		2 of them and filesize < 1MB
}
rule SEKOIA_Ransomware_Win_Avoslocker : FILE
{
	meta:
		description = "Detect AvosLocker ransomware (2021-07)"
		author = "Sekoia.io"
		id = "fc5c2483-48cb-4282-b6cb-ac728b948607"
		date = "2021-08-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_win_avoslocker.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "f810deb1ba171cea5b595c6d3f816127fb182833f7a08a98de93226d4f6a336f"
		hash = "c0a42741eef72991d9d0ee8b6c0531fc19151457a8b59bdcf7b6373d1fe56e02"
		hash = "84d94c032543e8797a514323b0b8fd8bd69b4183f17351628b13d1464093af2d"
		logic_hash = "d7f14f78ac569011ecf964109c72d75de4942361033a544350a2f73c7af64a0c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "cryptopp850\\rijndael_simd.cpp" ascii
		$s2 = "cryptopp850\\sha_simd.cpp" ascii
		$s3 = "cryptopp850\\gf2n_simd.cpp" ascii
		$s4 = "cryptopp850\\sse_simd.cpp" ascii

	condition:
		all of them and uint16( 0 ) == 0x5A4D and filesize > 900KB and filesize < 950KB
}
rule SEKOIA_Infostealer_Win_Blustealer : FILE
{
	meta:
		description = "Detect the BluStealer infostealer based on characteristic strings"
		author = "Sekoia.io"
		id = "a56b3c12-9d83-4a0b-81e8-43332e64d599"
		date = "2022-10-05"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_blustealer.yar#L1-L29"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "fc7c11a9ddd21228aa773da6054220211327727a87d48008b7edb202c48666d8"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$cha01 = "@top\\LOGGERS\\DARKCLOUD" wide
		$cha02 = "===============DARKCLOUD===============" wide
		$cha03 = "#######################################DARKCLOUD#######################################" wide
		$cha04 = "fireballsabadafirebricksfisherboat" ascii
		$cha05 = "Moonchild Pro2ductions" wide
		$str01 = "\\Microsoft\\Windows\\Templates\\credentials.txt" wide
		$str02 = "\\NETGATE Technologies\\BlackHawK\\Profiles" wide
		$str03 = "SysWOW64\\winsqlite3.dll" wide
		$str04 = "HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunOnce\\*RD_" wide
		$str05 = "Expiry Date;" wide
		$str06 = "SELECT c0subject, c3author, c4recipients, c1body  FROM messagesText_content" wide
		$str07 = "http://www.mediacollege.com/internet/utilities/show-ip.shtml" wide
		$str08 = "\\163MailContacts.txt" wide
		$key_0 = {ba ?? ?? 40 00 8d 4?}

	condition:
		uint16( 0 ) == 0x5A4D and 2 of ( $cha* ) and 4 of ( $str* ) and $key_0
}
rule SEKOIA_Tool_Quarkspwdump : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "859823f9-6d47-4b0f-844b-d3af7bad498b"
		date = "2023-06-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_quarkspwdump.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "4799e1d1c749a536d7920e3c333d69f7130376c6a0f0e0ca8f0b61e438266adb"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "quarks-pwdump.exe"
		$s2 = "--------------------------------------------- BEGIN DUMP --------------------------------------------"
		$s3 = "%s_hist%d:\"\":\"\":%s:%s"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 1MB and all of them
}
rule SEKOIA_Rat_Win_Tutclient : FILE
{
	meta:
		description = "Detect the open-source RAT TutClient"
		author = "Sekoia.io"
		id = "2bd2d61f-3654-4acd-9773-8d3617c67ee0"
		date = "2024-02-09"
		modified = "2024-12-19"
		reference = "https://github.com/AdvancedHacker101/C-Sharp-R.A.T-Client"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_tutclient.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f780948ab03dd0cd64d023367186a88c9eaa566170142e34aaa08788d9a684eb"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Clipboard Data Not Retrived!" wide
		$ = "Remote Cmd stream reading failed!" wide
		$ = "PasswordFox" wide
		$ = "[Right Click, Position: x = <rtd.xpos>; y = <rtd.ypos>]" wide
		$ = "SendCommand"
		$ = "HandleCommand"

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Backdoor_Powershellempire_Csharp : FILE
{
	meta:
		description = "Detects CSharp version of Empire"
		author = "Sekoia.io"
		id = "952e8e9b-8e4d-4550-9cf4-7ffd2f9d0672"
		date = "2022-04-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_powershellempire_csharp.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "536ef1167627c3dadb866d55e7eae2220c3fbd6961e2cfa71656656d984b9b90"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[-] Catastrophic .Net Agent Failure, Attempting Agent Restart:" ascii wide
		$ = "[!] Upload failed - No Delimiter" ascii wide
		$ = "SELECT * FROM Win32_IP4RouteTable" ascii wide
		$ = "no shell command supplied" ascii wide
		$ = "[-] CmdletInvocationException:" ascii wide
		$ = "[*] File download of" ascii wide
		$ = "Script successfully saved in memory" ascii wide
		$ = "Invoke-Empire" ascii wide
		$ = "website to reach:" ascii wide

	condition:
		uint16be( 0 ) == 0x4d5a and 5 of them and filesize < 1MB
}

rule SEKOIA_Loader_Win_Abcloader : FILE
{
	meta:
		description = "Detect ABCloader"
		author = "Sekoia.io"
		id = "c286ce75-a041-478e-a567-4bf1d5e66c01"
		date = "2024-08-19"
		modified = "2024-12-19"
		reference = "https://nsfocusglobal.com/new-apt-group-actor240524-a-closer-look-at-its-cyber-tactics-against-azerbaijan-and-israel/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_abcloader.yar#L4-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "0d1dca5eaad49c2dbd979e1bf0b5f8d0"
		hash = "9a640889e82407b06c546fea15be668f"
		logic_hash = "64d171d31c2f03ac18dde61d5b57fba91448045404b0ff619fb8cd437a561b1f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "qSii.LI4"
		$ = "Cabinet.dll"

	condition:
		uint16be( 0 ) == 0x4d5a and all of them or pe.imphash ( ) == "45c6b272631aa9e0c4b2ba675699b803" or hash.md5 ( pe.rich_signature.clear_data ) == "b33158757dc039859e272f4528e10e80"
}
rule SEKOIA_Infostealer_Win_Vulturi : FILE
{
	meta:
		description = "Detect the Vulturi infostealer based on specific strings"
		author = "Sekoia.io"
		id = "5369cbfb-ff94-4484-b5a4-894feeed97e1"
		date = "2022-03-14"
		modified = "2024-12-19"
		reference = "https://lamp-ret.club/t/vulturi-cracked-by-tr0uble-and-eshelon_mayskih.193/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_vulturi.yar#L1-L35"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "2d442768499ea0d4b6f5ac0d85521d73bb8337a53f1641485b0ce0054e2dc91c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$vul = "Vulturi_" ascii
		$str01 = "/C chcp 65001 && ping 127.0.0.1 && DEL /F /S /Q /A" wide
		$str02 = "SELECT ExecutablePath, ProcessID FROM Win32_Process" wide
		$str03 = "Apps\\Gaming\\Minecraft" wide
		$str04 = "Apps\\Gaming\\Steam\\Apps" wide
		$str05 = "Messengers\\Facebook\\Contacts.txt" wide
		$str06 = "Messengers\\Discord\\Tokens.txt" wide
		$str07 = "Apps\\VPN\\NordVPN\\accounts.txt" wide
		$str08 = "Apps\\VPN\\DUC\\credentials.txt" wide
		$str09 = "System\\Screenshots\\Webcam.png" wide
		$str10 = "System\\Screenshots\\Desktop.png" wide
		$str11 = "GTA San Andreas User Files\\SAMP\\USERDATA.DAT" wide
		$str12 = "http://ip-api.com/line?fields=query" wide
		$str13 = "Wireshark" wide
		$str14 = "KeePass.config.xml" wide
		$str15 = "Apps\\TheBat!" wide
		$str16 = "Vulturi" wide
		$str17 = "StealerStub" wide

	condition:
		uint16( 0 ) == 0x5A4D and ( #vul > 50 or 12 of ( $str* ) )
}
rule SEKOIA_Ransomware_Win_Redeemer : FILE
{
	meta:
		description = "Finds Redeemer samples based on characteristic strings"
		author = "Sekoia.io"
		id = "ef94c1b0-d292-4fae-9801-4860e7347745"
		date = "2022-12-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_win_redeemer.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c1798a18e763277d19a3b698459244a2bc2eeebbbf239db7540d1493955ce5f0"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str0 = "RedeemerMutex" ascii
		$str1 = "SOFTWARE\\Redeemer" ascii
		$str2 = "-----BEGIN REDEEMER PUBLIC KEY-----" ascii
		$str3 = "dnNzYWRtaW4gZGVsZXRlIHNoYWRvd3MgL0FsbCAvUXVpZXQ=" ascii
		$str4 = "d2V2dHV0aWwgY2xlYXItbG9nIEFwcGxpY2F0aW9u" ascii
		$str5 = "d2JhZG1pbiBkZWxldGUgc3lzdGVtc3RhdGViYWNrdXAgLWRlbGV0ZW9sZGVzdCAtcXVpZXQ=" ascii
		$str6 = "YXNzb2MgLnJlZGVlbT1yZWRlZW1lcg==" ascii
		$str7 = "UmVkZWVtZXIgUmFuc29td2FyZSAtIFlvdXIgRGF0YSBJcyBFbmNyeXB0ZWQ=" ascii
		$str8 = "redeemer\\DefaultIcon" wide
		$str9 = "\\Redeemer.sys" wide

	condition:
		uint16( 0 ) == 0x5A4D and 2 of them
}
rule SEKOIA_Exploit_Ez_Pwnkit_Strings : FILE
{
	meta:
		description = "Detects ez-pwnkit exploit"
		author = "Sekoia.io"
		id = "24301f35-8174-4e0d-b14a-fc7e45a29b26"
		date = "2024-01-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/exploit_ez_pwnkit_strings.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "36ec579f6c2dfeaf4ae6f6559d565d418a1f31199102eaa390ca36493f5b18cd"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "go.buildid"
		$s2 = "github.com/OXDBXKXO/ez-pwnkit"

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 5MB and $s1 and #s2 > 5
}
rule SEKOIA_Apt_Sidecopy_Malicious_Macro : FILE
{
	meta:
		description = "Detects malicious macro used by SideCopy"
		author = "Sekoia.io"
		id = "4b90c33e-48d4-48b6-87a7-c35686e7e913"
		date = "2023-05-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_sidecopy_malicious_macro.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b1d9d7af8507b478b2a8d34a4a5ca3714b219a42d5b3f9d5026d98351294e1cf"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "htmlFile$"
		$ = "Gecko/20100101 Firefox/91.0"
		$ = "Start Menu\\Programs\\Startup\\"
		$ = "Document_Close"
		$ = "ThisDocument" wide
		$ = "ServerXMLHTTP.6.0"

	condition:
		uint32be( 0 ) == 0xD0CF11E0 and all of them
}

rule SEKOIA_Typhon_Reborn_Stealer
{
	meta:
		description = "Typhon Reborn v2 string based detection"
		author = "Sekoia.io"
		id = "aab7279b-b651-4092-b988-d186d0a433de"
		date = "2023-05-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/typhon_reborn_stealer.yar#L3-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0db77a2e1d6b7274b0256fe469b72953c1b8598cbfc1715a43e5fbfa7899fe4c"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "api.telegram.org/bot" wide
		$s2 = "TyphonReborn Stealer v2 log!" wide

	condition:
		all of them and pe.is_pe
}
rule SEKOIA_Tool_Rsockstun_Strings : FILE
{
	meta:
		description = "Detects Rsockstun based on strings"
		author = "Sekoia.io"
		id = "94d8cb39-3421-441c-8404-62a591b86912"
		date = "2023-12-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_rsockstun_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8faf1004ec56728f1e451734ed651e8f77a49faf7f232df82e0b4950a9f1d198"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "main.connectviaproxy"
		$ = "main.connectForSocks"
		$ = "main.listenForClients"
		$ = "main.listenForSocks"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 10MB and all of them
}
rule SEKOIA_Generic_Sharpshooter_Payload_11 : FILE
{
	meta:
		description = "Detects payload created by SharpShooter"
		author = "Sekoia.io"
		id = "703d2eb2-c9fd-4891-ba95-f94a8313618e"
		date = "2023-02-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/generic_sharpshooter_payload_11.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "00c0dcc244db608d3a0d7500cdebadcc69ba0d56091a0a1fd7d58c27d255861f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "decodeHex = EL.NodeTypedValue"
		$ = "Private Function decodeHex(hex)"
		$ = "serialized_obj = serialized_obj & "
		$ = "d.DynamicInvoke(al.ToArray()).CreateInstance(entry_class)"

	condition:
		all of them and filesize < 2MB
}

rule SEKOIA_Hacktool_Win_Gmer : FILE
{
	meta:
		description = "Dtect the GMER hacktool based string and UPX usage"
		author = "Sekoia.io"
		id = "d2f1aba1-4222-45e5-95bd-4d7f08595cea"
		date = "2022-09-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_win_gmer.yar#L3-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "dbd4e97c343dcb14c6e814afa820a9fbb5aa4290c7ddf9d864029bb35bb96dbf"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$pac = "IDI_GMER" wide
		$str0 = "---- Processes - GMER %s ----" ascii
		$str1 = "E:\\projects\\cpp\\gmer\\Release\\gmer.pdb" ascii

	condition:
		uint16( 0 ) == 0x5A4D and ( ( $pac and for any i in ( 0 .. pe.number_of_sections -1 ) : ( pe.sections [ i ] . name == "UPX0" ) ) or any of ( $str* ) ) and filesize < 900KB
}
rule SEKOIA_Builder_Win_Royalroad_Rtf : FILE
{
	meta:
		description = "Detects RoyalRoad weaponized RTF documents"
		author = "Sekoia.io"
		id = "065e798b-eadd-4aac-a444-de61b75f0273"
		date = "2022-06-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/builder_win_royalroad_rtf.yar#L1-L15"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "831962105248e33422344d1431b90f2b567439b54252668f9294ea388f405b41"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "{\\object\\objocx{\\objdata"
		$ = "ods0000"

	condition:
		uint32be( 0 ) == 0x7B5C7274 and all of them
}
rule SEKOIA_Hacktool_Duplicatedump_Strings : FILE
{
	meta:
		description = "Detects Duplicate Dump"
		author = "Sekoia.io"
		id = "081d0124-4afe-418b-9767-3d987c0107ca"
		date = "2023-11-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_duplicatedump_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "feff083ed432781884941fc02eee6d6ce54f70f1b85d24db2f3e1d0147a81a7a"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "7d872e921a4b4b1b8b295395099b0209" wide ascii
		$ = "[+] Named pipe connected and replying with current PID" wide ascii
		$ = "[X] Named pipe connection error:" wide ascii
		$ = "[X] Error occur while compressing file:" wide ascii
		$ = "[+] Dump file saved to" wide ascii

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 500KB and 4 of them
}
rule SEKOIA_Apt_Granitetyphoon_Pingpulllinux_Strings : FILE
{
	meta:
		description = "Detects PingPull Linux variant"
		author = "Sekoia.io"
		id = "ee213206-d9ad-47fa-bea1-61a9d2cfba58"
		date = "2023-05-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_granitetyphoon_pingpulllinux_strings.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "89c89bb24d1996c04fba0e6ebfd2aaf1544d8a9e6333b896c1855747fb979308"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "chkconfig --add %s"
		$ = "chkconfig %s on"
		$ = "update-rc.d %s enable"
		$ = "service %s start"
		$ = "respawn limit 10 10"
		$ = "POST /%s HTTP/1.1"
		$ = "PROJECT_%s_%s_%08X"
		$ = "Description=The HTTP(S) Client"
		$ = "exec %s -f"

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 11MB and 7 of them
}
rule SEKOIA_Infostealer_Win_Ducklogs : FILE
{
	meta:
		description = "Detects DuckLogs based on specific strings"
		author = "Sekoia.io"
		id = "165c7d3d-de7e-4d71-b94a-8ab4a0e5ddd5"
		date = "2022-12-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_ducklogs.yar#L1-L30"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5db1a5595ec41488da620606bbcb36d0d686f9d6b7a0479439c53625df0886a0"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$dck = "DuckLogs" ascii wide
		$str01 = "CheckRemoteDebuggerPresent" ascii
		$str02 = "MozGlueNotFound" ascii
		$str03 = "get_DecryptedPassword" ascii
		$str04 = "get_Extension" ascii
		$str05 = "set_UseShellExecute" ascii
		$str06 = "FirefoxPasswords" ascii
		$str07 = "GetAllGeckoCookies" ascii
		$str08 = "GetAllBlinkDownloadsBy" ascii
		$str09 = "Grabbers" ascii
		$str10 = "Utility" ascii
		$str11 = "Persistance" ascii
		$str12 = "Clipboard" ascii
		$str13 = "WaterfoxGrabber" ascii
		$str14 = "AvastGrabber" ascii

	condition:
		uint16( 0 ) == 0x5A4D and ( ( #dck > 4 and 2 of ( $str* ) ) or 12 of them )
}
rule SEKOIA_Tool_Gsocket_Strings : FILE
{
	meta:
		description = "Detects Gsocket based on strings"
		author = "Sekoia.io"
		id = "55fb2f2b-1074-4b6d-9113-48eaeb0e1e27"
		date = "2024-06-10"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_gsocket_strings.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c54308293a9f64b571282eac9fba01e4671ba6b0cd45936fab92d4d9af904bbb"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "proxy. It allows multiple gs-netcat clients to (securely) relay"
		$ = "GS-NETCAT(1)            General Commands Manual          GS-NETCAT(1)"
		$ = "-T      Use TOR. The gs-netcat tool will connect via TOR to the GSRN."
		$ = "-D      Daemon & Watchdog mode. Start gs-netcat as a background process"
		$ = "gs-netcat [-rlgvqwCTSDiu] [-s secret] [-k keyfile] [-L logfile] [-d IP]"
		$ = "The gs-netcat utility is a re-implementation of netcat."

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a or uint32be( 0 ) == 0xfeedface or uint32be( 0 ) == 0xcffaedfe or uint32be( 0 ) == 0xcafebabe ) and filesize > 2MB and filesize < 6MB and 2 of them
}
rule SEKOIA_Apt_Badmagic_Commonmagic_Usbstealer : FILE
{
	meta:
		description = "Detects CommonMagic related implants"
		author = "Sekoia.io"
		id = "37d5becc-f1c3-4400-bc10-cd6036d4dbb1"
		date = "2023-05-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_badmagic_commonmagic_usbstealer.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a600f17bce9159b581c234cc101d1a0d093954fc9c79052dbca5451714fd7502"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "\\\\.\\pipe\\PipeDtMd" ascii wide fullword
		$ = "State USB" ascii wide
		$ = "DefaultNameDevice" ascii wide
		$ = "SerialNumber" ascii wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and all of them
}

rule SEKOIA_Ransomware_Win_Blackmatter
{
	meta:
		description = "Detect Black matter ransomware (2021-07-23)"
		author = "Sekoia.io"
		id = "9b2d8ac3-b4d1-40f5-ac57-411547dcb2cf"
		date = "2021-08-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_win_blackmatter.yar#L4-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5a407a9901314211e13bef30254f1d129cf3c731ea970abff8602f1ae40177cb"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "5e89d335de2021a2c268acf00ec513e5" )
}
rule SEKOIA_Apt_Mustangpanda_Windows_Remoteshell : FILE
{
	meta:
		description = "Detects Remote Shell of Mustang Panda by detecting internal structure intialization"
		author = "Sekoia.io"
		id = "cffdd11e-9700-462e-a965-f9f51db63f0b"
		date = "2022-12-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_mustangpanda_windows_remoteshell.yar#L1-L121"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "4a72ae1574022d6454e29a6b05a0279f2e774f8218d24a3a866721d958c52e1a"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$chunk_1 = {
        C7 45 ?? 0C 00 00 00
        8D 4E ??
        C6 01 03
        8B 87 ?? ?? ?? ??
        89 41 ??
        66 8B 87 ?? ?? ?? ??
        66 89 41 ??
        }
		$chunk_2 = {
        C7 45 ?? 0C 00 00 00
        8D 4E ??
        C6 01 02
        8B 87 ?? ?? ?? ??
        89 41 ??
        66 8B 87 ?? ?? ?? ??
        66 89 41 ??
        8B 45 ??
        83 E8 05
        50
        51
        E8 ?? ?? ?? ??
        }
		$chunk_3 = {
        C7 87 ?? ?? ?? ?? 01 00 00 00
        8D 4E ??
        C7 45 ?? 0C 00 00 00
        C6 01 04
        8B 87 ?? ?? ?? ??
        89 41 ??
        66 8B 87 ?? ?? ?? ??
        66 89 41 ??
        8B 45 ??
        83 E8 05
        50
        51
        E8 ?? ?? ?? ??
        }
		$chunk_4 = {
        83 65 ?? ??
        EB ??
        8B 45 ??
        40
        89 45 ??
        8B 45 ??
        3B 45 ??
        7D ??
        8B 45 ??
        03 45 ??
        0F B6 08
        8B 45 ??
        33 D2
        6A ??
        5E
        F7 F6
        0F B6 84 15 ?? ?? ?? ??
        33 C8
        8B 45 ??
        03 45 ??
        88 08
        EB ??
        83 65 ?? ??
        EB ??
        8B 45 ??
        40
        89 45 ??
        8B 45 ??
        }

	condition:
		filesize < 8MB and 3 of them
}
rule SEKOIA_Infostealer_Win_Daolpu_Str : FILE
{
	meta:
		description = "Finds Daolpu Stealer samples based on specific strings."
		author = "Sekoia.io"
		id = "dde1cf12-48d8-45b6-b453-b7196e6b1271"
		date = "2024-07-23"
		modified = "2024-12-19"
		reference = "https://www.crowdstrike.com/blog/fake-recovery-manual-used-to-deliver-unidentified-stealer/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_daolpu_str.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "9372a88efcdca6ca57f354fb31569522e5458271cc51dfedf09c6178a47a5b67"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "Content-Type: %s%s%s" ascii
		$str02 = "Content-Disposition: %s%s%s%s%s%s%s" ascii
		$str03 = "\\CocCoc\\Browser\\User Data\\Local State" ascii
		$str04 = "\\Microsoft\\Edge\\User Data\\Default\\Login Data" ascii
		$str05 = "\\Mozilla\\Firefox\\Profiles" ascii
		$str06 = "No MAC Address Found" ascii
		$str07 = "C:\\Windows\\Temp\\" ascii
		$str08 = "C:\\Windows\\Temp\\result.txt" ascii
		$str09 = "Privatekey@2211#$" ascii
		$str10 = "CryptStringToBinaryA Failed to convert BASE64 private key." ascii
		$str11 = "taskkill /F /IM chrome.exe" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 8 of them
}

rule SEKOIA_Apt_Menupass_Maliciouslibvlc_Dll
{
	meta:
		description = "Detects the malicious LibVLC variants used by MenuPass"
		author = "Sekoia.io"
		id = "8b6b56f3-33b5-41cf-8bcb-e653c98718bd"
		date = "2022-04-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_menupass_maliciouslibvlc_dll.yar#L3-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "de56e112a477d3a77146f1b84c8aa3e66a382a87f1492dd50aa1de9458b33717"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		pe.DLL and pe.number_of_exports < 15 and for all i in ( 0 .. pe.number_of_exports - 1 ) : ( pe.export_details [ i ] . name contains "libvlc_" )
}
rule SEKOIA_Infostealer_Win_Enigma_Initial_Loader : FILE
{
	meta:
		description = "Find initial loader of Enigma Stealer based on specific strings"
		author = "Sekoia.io"
		id = "664fe8de-b406-4d63-9a4b-1c350b444f00"
		date = "2023-01-30"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_enigma_initial_loader.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "03b9d7296b01e8f3fb3d12c4d80fe8a1bb0ab2fd76f33c5ce11b40729b75fb23"
		logic_hash = "b7687a480a2a633e7cc9a60d62f3392011712bd018ed634927419cfb4edb4a78"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "/getFile?file_id=" ascii
		$str02 = "/file/bot" ascii
		$str03 = "?file_id=" ascii
		$str04 = "pInternetSetOptionA failed" wide
		$str05 = "list_messages[file_path] failed" wide
		$str06 = "iE&xit" wide
		$str07 = "[GetTgFileById][GetTgRequest] reply is NULL" wide
		$str08 = "Telegram request failed" wide
		$str09 = "bot getted" wide

	condition:
		uint16( 0 ) == 0x5A4D and 4 of them
}
rule SEKOIA_Tool_Realblindingedr_Strings : FILE
{
	meta:
		description = "Detects RealBlindingEDR based on strings"
		author = "Sekoia.io"
		id = "505dcbee-ae37-47c1-a322-2c52d10e68d7"
		date = "2024-09-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_realblindingedr_strings.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "cb6219e2b6577b8d4a18114d595e10d7"
		hash = "d0a251709c24a8f4c26d456dea22d90f"
		logic_hash = "7b6a54c935bb40bd1be1d25be452d7185fd6f9dacbd7cbcde7cb37dfea09775e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Unload Driver Error 1"
		$ = "Failed to create pipe. Error %d"
		$ = "icacls \"%s\" /grant Everyone:(F)"
		$ = "Register MiniFilter Callback driver:"
		$ = "The driver's certificate has been revoked,"
		$ = "[Success] Killed %s(%s)."
		$ = "ntoskrnl.exe base address not found."

	condition:
		uint16be( 0 ) == 0x4d5a and 4 of them
}

rule SEKOIA_Apt_Mustangpanda_Maliciousdll_Loading_Plugx_Strings
{
	meta:
		description = "Detects MustangPanda malicious DLL"
		author = "Sekoia.io"
		id = "2296ac6e-63f5-4cff-aeb7-2c5205e6f559"
		date = "2023-12-18"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_mustangpanda_maliciousdll_loading_plugx_strings.yar#L3-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "651c096cf7043a01d939dff9ba58e4d69f15b2244c71b43bedb4ada8c37e8859"
		logic_hash = "667901d36585248a891b90ff8ed7006030151fbbbe0d4a85570944a94edba7f8"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "VirtualAlloc"
		$ = "VirtualFree"
		$ = "VirtualProtect"
		$ = "VirtualQuery"
		$ = "GCC: (MinGW-W64"

	condition:
		pe.exports( "MsiProvideQualifiedComponentW" ) and all of them
}
rule SEKOIA_Ransomware_Win_Voidcrypt : FILE
{
	meta:
		description = "Detect the Limbozar / VoidCrypt ransomware"
		author = "Sekoia.io"
		id = "394033cc-20fe-4ced-8d77-5f1061bb8c96"
		date = "2021-10-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_win_voidcrypt.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "7e28bae5830df779bf2367482fb966f5cab691a6c8c474950f7442d8fec054a0"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "C:\\ProgramData\\pkey.txt" ascii
		$s2 = "C:\\ProgramData\\IDk.txt" ascii
		$s3 = "fuckyoufuckyoufuckyoufuckyou" ascii

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule SEKOIA_Hacktool_Pplblade_Strings : FILE
{
	meta:
		description = "Detects PPLBlade"
		author = "Sekoia.io"
		id = "1a443621-fc95-4a70-873e-c1389943d4ab"
		date = "2023-11-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_pplblade_strings.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e853e109dbf5dfcba465f61cb689f261df5156e98297d3d00f700e20491de66e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "shirou/gopsutil/internal/"
		$ = ".miniDumpWriteDump"
		$ = ".DRIVER_FULL_PATH"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize > 4MB and filesize < 6MB and all of them
}
rule SEKOIA_Apt_Oilrig_Saitama_Backdoor_May2022_2 : FILE
{
	meta:
		description = "Detects Saitama backdoor variants"
		author = "Sekoia.io"
		id = "f885551a-d0f0-431d-aa4f-7caa93b1db6a"
		date = "2022-05-13"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_oilrig_saitama_backdoor_may2022_2.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "622c386d4b10b81a5c84f9c093d91add04497a707ba88e8395fda8587b5c3791"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "_CorExeMain"
		$ = "GetAgentID"
		$ = "ComputeStringHash"
		$ = ".Agent.pdb"
		$ = "TaskExecTimeout"

	condition:
		uint16be( 0 ) == 0x4d5a and 5 of them
}
rule SEKOIA_Apt_Kimsuky_Validator_Strings : FILE
{
	meta:
		description = "Detects Kimsuky validator"
		author = "Sekoia.io"
		id = "e055f2d4-8318-4342-812e-0f621d7886b4"
		date = "2024-06-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_kimsuky_validator_strings.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a627dae8c12f0f6f8472bc12b8e1a85137f92f6e389f817ab9023c90720a42b0"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "%s%sc %s >%s 2>&1" wide
		$ = "%s%sc %s 2>%s" wide

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Win_Clipper_Generic : FILE
{
	meta:
		description = "Clipper found during investigation: 892a9edb03db3fd88fecc1e1a2f56a7339f16f6734e8d77e6538ea2c8c9026d6"
		author = "Sekoia.io"
		id = "a94b3d01-dbc7-41e4-8d45-793bf443b1d2"
		date = "2024-07-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/win_clipper_generic.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f2fb2285adb10269aaf3d028d3803775ad86833b36cf24dabb8d404a6380b505"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s = { 24 72 61 6e 70 74 68 20 3d 20 69 66 20 28 28 47 65 74 2d 52 61 6e 64 6f 6d 29 20 25 20 32 29 20 7b 20 4a 6f 69 6e 2d 50 61 74 68 20 24 65 6e 76 3a 54 45 4d 50 20 22 24 72 61 6e 2e 70 73 31 22 20 7d 20 65 6c 73 65 20 7b 20 4a 6f 69 6e 2d 50 61 74 68 20 24 65 6e 76 3a 41 50 50 44 41 54 41 20 22 24 72 61 6e 2e 70 73 31 22 20 7d  }

	condition:
		filesize > 1KB and all of them
}
rule SEKOIA_Loader_Amadey_Stealer_Plugin : FILE
{
	meta:
		description = "Finds Amadey's stealer plugin based on characteristic strings"
		author = "Sekoia.io"
		id = "50154e39-98b3-40e5-8986-18bbb7b15647"
		date = "2023-05-16"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_amadey_stealer_plugin.yar#L1-L27"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0410492f9424797b670a14f43ce063458e59d7958e213c07c3d488a40bf370e6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "STEALERDLL.dll" ascii
		$str02 = "?wal=1" fullword ascii
		$str03 = "Content-Disposition: form-data; name=\"data\"; filename=\"" ascii
		$str04 = "tar.exe -cf \"" ascii
		$str05 = "SELECT origin_url, username_value, password_value FROM logins" ascii
		$str06 = "\\Google\\Chrome\\User Data\\Default\\Login Data" ascii
		$str07 = "\\SputnikLab\\Sputnik\\User Data\\Default\\Login Data" ascii
		$str08 = "\\Mozilla\\Firefox\\Profiles\\" ascii
		$str09 = "\"hostname\":\"([^\"]+)\"" ascii
		$str10 = "\"encryptedUsername\":\"([^\"]+)\"" ascii
		$str11 = "\"encryptedPassword\":\"([^\"]+)\"" ascii
		$str12 = "&cred=" fullword ascii
		$str13 = "D:\\Mktmp\\Amadey\\StealerDLL\\x64\\Release\\STEALERDLL.pdb" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 7 of them
}
rule SEKOIA_Koiloader_Lnk : FILE
{
	meta:
		description = "LNK file leading to deploy KoiLoader"
		author = "Sekoia.io"
		id = "e82975b9-94b7-4de8-8cd5-d594aa80cf02"
		date = "2024-03-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/koiloader_lnk.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "49953c76796f671ed80afa21872aac500d706f2af4426a5ec2854e16b9d0e474"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "bat & schtasks /create" wide
		$s2 = "/sc minute /mo 1" wide
		$s3 = "c3RhcnQgL21pbiBwb3dlcnNoZWxsIC1jb21tYW5kICJJV1IgLVVzZUJhc2ljUGFyc2luZyAnaHR0cHM6" wide
		$s4 = " & certutil -f -decode " wide

	condition:
		uint32( 0 ) == 0x0000004c and all of them
}
rule SEKOIA_Apt_Backdoordiplomaty_Phantomnet : FILE
{
	meta:
		description = "Detects PhantomNet based on strings"
		author = "Sekoia.io"
		id = "bbcc0664-ef2b-47db-a546-b5e0aa2a1e9a"
		date = "2024-06-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_backdoordiplomaty_phantomnet.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e4be9b9e092dcaa368650b7f696ca532f89752bdbe6b5fd09b4285a643c20b86"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "memory load plugin failed!" wide
		$ = "Event eee!!!" ascii
		$ = "LoadWin32_x64.pdb" ascii

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 2MB and 2 of them
}
rule SEKOIA_Apt_Toddycat_Tomberbil_Strings : FILE
{
	meta:
		description = "Detects TomBerBil password stealer"
		author = "Sekoia.io"
		id = "b16f4d35-ea59-4439-8ddb-2c0415b97b9b"
		date = "2024-04-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_toddycat_tomberbil_strings.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "92da6ba86cffec75a9af90a513840672b023c81baa9aedb2b706534cc39ecc09"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[+] Begin" ascii wide
		$ = "[+] Delete File" ascii wide
		$ = "[+] Current user" ascii wide
		$ = "[+] Impersonate user" ascii wide
		$ = "[+] Local State File" ascii wide
		$ = "[>] Profile" ascii wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and 4 of them
}
rule SEKOIA_Apt_Cloudatlas_Powershower_Module : FILE
{
	meta:
		description = "Detects CloudAtlas PowerShower module"
		author = "Sekoia.io"
		id = "dd688058-3d5d-46a7-8380-fe961c3327cd"
		date = "2022-11-30"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_cloudatlas_powershower_module.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "7542eb882ee44203d806ad936126be2476b6e3a85ad8c93b6fd6c8226fe82617"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "$env:temp" ascii wide
		$ = "foreach($item in $zip.items" ascii wide
		$ = "echo $result" ascii wide
		$ = "pass.txt" ascii wide

	condition:
		all of them and filesize < 10000
}
rule SEKOIA_Infostealer_Win_Phoenixwave : FILE
{
	meta:
		description = "Detect the PhoenixWave infostealer based on specific strings"
		author = "Sekoia.io"
		id = "67c05ea8-2f1b-4c60-b108-e05d7d0c6508"
		date = "2022-04-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_phoenixwave.yar#L1-L35"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "efeffb2f0df4c2f8156c401bac5f44c415c4c3e02e84e8db55dad68488f39fea"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str0 = "##################################################\n                  Information\n##################################################\n" wide
		$str1 = "Specify a single character: either D or F" wide
		$str2 = "// This SFX source file was generated by DotNetZip " wide
		$str3 = "aHR0cDovL2lwLWFwaS5jb20vanNvbg==" wide
		$str4 = "TG9jYWxBcHBEYXRh" wide
		$str5 = "UGhvZW5peFdhdmU=" wide
		$str6 = "virustotal" wide
		$str7 = "SELECT * FROM win32_operatingsystem" wide
		$str8 = "SELECT * FROM Win32_VideoController" wide
		$app0 = "\\discordcanary\\Local Storage\\leveldb" wide
		$app1 = "\\discordptb\\Local Storage\\leveldb" wide
		$app2 = "\\discorddevelopment\\Local Storage\\leveldb" wide
		$app3 = "\\D877F783D5D3EF8C\\" wide
		$app4 = "\\IndexedDB\\file__0.indexeddb.leveldb" wide
		$app5 = "\\Steam\\Games.txt" wide
		$app6 = "nkbihfbeogaeaoehlefnkodbefgpgknn" wide
		$app7 = "fhbohimaelbohpjbbldcngcnapndodjp" wide
		$app8 = "fnjhmkhhmkbjkkabndcnnogagogbneec" wide
		$app9 = "\\Opera Software\\Opera GX Stable" wide

	condition:
		uint16( 0 ) == 0x5A4D and 7 of ( $str* ) and 8 of ( $app* )
}
rule SEKOIA_Pe_Stealer_Axilestealer_Strings : FILE
{
	meta:
		description = "AxileStealer strings"
		author = "Sekoia.io"
		id = "412bfc3e-6bb7-4b0d-8bb3-96eae0cc9782"
		date = "2023-12-13"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/pe_stealer_axilestealer_strings.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "829b80c07ed4d9439d66956dbb106aa0cc9961dd2e5c05ffbe6c67e516613590"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "http://ip-api.com/line/?fields=query,country,countryCode,city,regionName,zip,isp" wide
		$s2 = "Axile.su" wide
		$s3 = "Unknown Tokens.txt" wide
		$a1 = "[ <b>General</b> ]" wide
		$a2 = "[ <b>Browsers</b> ]" wide
		$a3 = "[ <b>Wallets</b> ]" wide
		$a4 = "[ <b>Messengers</b> ]" wide
		$a5 = "[ <b>Applications</b> ]" wide
		$a6 = "[ <b>Games</b> ]" wide
		$a7 = "[ <b>Mails</b> ]" wide
		$a8 = "[ <b>VPNs</b> ]" wide
		$a9 = "[ <b>FTPs</b> ]" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize > 50KB and filesize < 200KB and 2 of ( $s* ) and 7 of ( $a* )
}
rule SEKOIA_Ransomware_Win_Chaos : FILE
{
	meta:
		description = "Detects the Chaos Ransomware"
		author = "Sekoia.io"
		id = "c1876a18-0618-44e2-8919-b4a041de97e7"
		date = "2022-01-18"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_win_chaos.yar#L1-L46"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "1947e6de8f74fe7bc52107d4a57e19eacf022121f5decee54a8c90797be844c6"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$rep00 = "\\Desktop" wide
		$rep01 = "\\Links" wide
		$rep02 = "\\Contacts" wide
		$rep03 = "\\Documents" wide
		$rep04 = "\\Downloads" wide
		$rep05 = "\\Pictures" wide
		$rep06 = "\\Music" wide
		$rep07 = "\\OneDrive" wide
		$rep08 = "\\Saved Games" wide
		$rep09 = "\\Favorites" wide
		$rep10 = "\\Searches" wide
		$rep11 = "\\Videos" wide
		$rep12 = "C:\\Users\\" wide
		$str0 = "svchost.exe" wide
		$str1 = "\\privateKey.chaos" wide
		$str2 = "Chaos Ransomware" wide
		$str3 = "read_it.txt" wide
		$str4 = "<EncryptedKey>" wide
		$str5 = "passwordBytes" ascii
		$str6 = "lookForDirectories" ascii
		$str7 = "Rfc2898DeriveBytes" ascii
		$str8 = "ICryptoTransform" ascii
		$str9 = "FromBase64String" ascii
		$ext0 = ".torrent" wide
		$ext1 = ".ibank" wide
		$ext2 = ".wallet" wide
		$ext3 = ".swift" wide
		$ext4 = ".onetoc2" wide

	condition:
		uint16( 0 ) == 0x5a4d and filesize > 50KB and filesize < 2MB and 6 of ( $str* ) and 10 of ( $rep* ) and 4 of ( $ext* )
}
rule SEKOIA_Loader_Win_Konni_Bat : FILE
{
	meta:
		description = "Detect the BAT files (named trap.bat or yup.bat) used by KONNI"
		author = "Sekoia.io"
		id = "e8921336-6c91-4b46-bd3f-3cf4a9b31082"
		date = "2023-09-26"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_konni_bat.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "3476e41461692c3ccfc0ef47a4d5b8822c4940987755763d2a5913e27d9350d4"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "del /f /q \"%~dp0\\*.zip\" > nul"
		$ = "del /f /q \"%~dp0\\*.xml\" > nul"
		$ = "del /f /q \"%~dp0\\wpnprv*.dll\" > nul"
		$ = "del /f /q \"%~dp0\\*.bat\" > nul"
		$ = "del /f /q \"%~dpnx0\" > nul"
		$ = "echo %~dp0 | findstr /i \"system32\" > nul"
		$ = "if %ERRORLEVEL% equ 0 (goto INSTALL) else (goto COPYFILE)"
		$ = "if exist \"%ProgramFiles(x86)%\" ("

	condition:
		3 of them and filesize < 3KB
}
rule SEKOIA_Ransomware_Win_Lorenz : FILE
{
	meta:
		description = "Detect the Lorenz ransomware"
		author = "Sekoia.io"
		id = "6936cc61-efe5-4d13-b76f-e808ab331457"
		date = "2022-02-10"
		modified = "2024-12-19"
		reference = "https://www.cybereason.com/blog/cybereason-vs.-lorenz-ransomware"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_win_lorenz.yar#L1-L27"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "355de0f172c9e877bbca7f75c0bfb07d83ae7f43e7674a7f84c4e4d519dfa7c0"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.1"
		classification = "TLP:CLEAR"

	strings:
		$s1 = ".onion" ascii
		$s2 = "---===Lorenz. Welcome. Again. ===--" ascii
		$s3 = ".Lorenz.sz40" ascii
		$url1 = "egypghtljedbs3x3ui45tfhosakzb376epl7baq2ruzfyewcypswhgqd.onion" ascii
		$url2 = "lorenzmlwpzgxq736jzseuterytjueszsvznuibanxomlpkyxk6ksoyd.onion" ascii
		$url3 = "vsoonropylvbfqnq2urk7uhaxn7afiwgldnj3ntc743awigojm4p7lid.onion" ascii
		$url4 = "kpb3ss3vwvfejd4g3gvpvqo6ad7nnmvcqoik4mxt2376yu2adlg5fwyd.onion" ascii
		$url5 = "vldkrmiqriwlgm2wuxg42nvc6kqsdzsdhsybn27hyn34d66465fxz7id.onion" ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize > 900KB and filesize < 1200KB and ( all of ( $s* ) or 1 of ( $url* ) )
}
rule SEKOIA_Guloader_Unpacker : FILE
{
	meta:
		description = "GuLoader Unpacker"
		author = "Sekoia.io"
		id = "dee4cad4-e3b4-4a12-860b-ff750b119fa8"
		date = "2024-02-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/guloader_unpacker.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6be9d7fa829480466aef2a7e78a7dadfac92f7774ab3374254305040c105496f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$p1 = "([Parameter(Position = 0)] [Type[]] $" base64
		$p2 = "+=2){" base64
		$p3 = "}else {" base64

	condition:
		$p1 in ( filesize -30000 .. filesize ) and $p2 in ( filesize -30000 .. filesize ) and $p3 in ( filesize -30000 .. filesize ) and filesize > 300KB
}
rule SEKOIA_Apt_Mustangpanda_Downloader : FILE
{
	meta:
		description = "Detects the MustangPanda Downloader"
		author = "Sekoia.io"
		id = "54850ffd-f93b-4082-b3ca-8e1d60b35422"
		date = "2022-03-02"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_mustangpanda_downloader.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0bff0ee2960ecfa29939720e7efacaa35359f4fe555ae160c674efebf29bf61e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Windows Api" wide nocase
		$ = "200 OK" wide
		$ = "200 ok" wide
		$ = "mscoree.dll" wide

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Generic_Php_Webshell : FILE
{
	meta:
		description = "Detects generic webshell"
		author = "Sekoia.io"
		id = "415a96bd-11a4-40e7-8335-ac1f1a99d17c"
		date = "2023-12-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/generic_php_webshell.yar#L1-L15"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "617264a785b8e9e87a39e12d7b72963d94e0686a174716347369fe71ab7a78af"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "system($_POST['a']);"

	condition:
		all of them and filesize < 500
}
rule SEKOIA_Backdoor_Lin_Sysupdate : FILE
{
	meta:
		description = "Detect the SysUpdate malware"
		author = "Sekoia.io"
		id = "9cb806cf-4ca1-44d8-809a-58cc5f364fb8"
		date = "2023-03-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_lin_sysupdate.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "93e17cd535444e9cabc7440b1226526e67ddb81a84eb6377689a62f268b9dfee"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "generate guid path=%s"
		$ = "3rd/asio/include/asio/detail/posix_event.hpp"
		$ = "expires_at"
		$ = "%s -f %s"
		$ = "expires_after"
		$ = "-run"

	condition:
		uint32( 0 ) == 0x464c457f and all of them
}
rule SEKOIA_Exploit_Linux_Eop_Ubuntu_Overlayfs_Local_Privesc_Strings : FILE
{
	meta:
		description = "Detects Ubuntu OverlayFS Local Privesc exploit"
		author = "Sekoia.io"
		id = "5e0e73f5-4cb3-4a79-adac-578b17ed7660"
		date = "2023-12-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/exploit_linux_eop_ubuntu_overlayfs_local_privesc_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "48ff9d2a10eef1e9b9088ba4a53aa77f43324e5d51da65b65a5829276067f011"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "./ovlcap"
		$ = "rm -rf '%s/'"
		$ = "./ovlcap/work"
		$ = "./ovlcap/lower"
		$ = "./ovlcap/upper"
		$ = "./ovlcap/merge"

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 1MB and all of them
}
rule SEKOIA_Infostealer_Win_Fwit_Strings : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "332e89ad-d1fe-4da6-9354-0978ef173e78"
		date = "2023-06-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_fwit_strings.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "4e28b6d67e2087b2f28817b19812b8bd56227175cd3d9c7037290127d4ec05a5"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "C:\\ProgramData\\Temp" wide
		$s2 = "{:08x}" wide
		$s3 = "CURL_SSLVERSION" ascii

	condition:
		( uint16be( 0 ) == 0x4d5a ) and all of them
}
rule SEKOIA_Implant_Mac_Rustbucket : FILE
{
	meta:
		description = "Detect the RustBucket malware"
		author = "Sekoia.io"
		id = "fcbb745d-7f56-4c51-9db5-427da22a0c68"
		date = "2023-04-24"
		modified = "2024-12-19"
		reference = "https://www.jamf.com/blog/bluenoroff-apt-targets-macos-rustbucket-malware/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_mac_rustbucket.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "9ca914b1cfa8c0ba021b9e00bda71f36cad132f27cf16bda6d937badee66c747"
		logic_hash = "ab7bc706b0d3f0dcd739ffe7f8153ba7377892143d8d53ce1591519ffe4ae84f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "/Users/hero/"
		$ = "PATHIpv6Ipv4Bodyslotpath"
		$macho_magic = {CF FA ED FE}
		$java_magic = {CA FE BA BE}

	condition:
		($macho_magic at 0 or $java_magic at 0 ) and all of them
}
rule SEKOIA_Backdoor_Win_Rokrat : FILE
{
	meta:
		description = "Detect the RokRAT malware"
		author = "Sekoia.io"
		id = "97a3acc1-4120-4d67-a6ad-fa204f2fd7f5"
		date = "2023-07-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_win_rokrat.yar#L1-L31"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "84760cac26513915ebfb0a80ad3ddabe62f03ec4fda227d63e764f9c4a118c4e"
		hash = "758348521331bb18241d1cfc90d7e687dbc5bad8d596a2b2d6a9deb6cfc8cb1d"
		hash = "2a253c2aa1db3f809c86f410e4bd21f680b7235d951567f24d614d8e4d041576"
		hash = "ebce34cdeb20bc8c75249ce87a3080054f48b03ef66572fbc9dc40e6c36310d6"
		hash = "a1e4e95a20120f16adacb342672eec1e73bd7826b332096f046bb7e2b7cd80a1"
		hash = "3be58a7a7a25dbceee9e7ef06ef20aa86aef083be19db9e5ffb181d3f9f6615a"
		hash = "fa4df84071b9ae20b321e4d22162d8480f6992206bc046e403c2fbedd1655503"
		hash = "aa76b4db29cf929b4b22457ccb8cd77308191f091cde2f69e578ade9708d7949"
		logic_hash = "42e0b8583570d32a5d6a5bed175a53951e7d68d8471a283ef245686621dc01c4"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "--wwjaughalvncjwiajs--"
		$ = {7b 00 22 00 70 00 61 00 74 00 68 00 22 00 3a 00 22 00 25 00 73 00 22 00 2c 00 22 00 6d 00 6f 00 64 00 65 00 22 00 3a 00 7b 00 22 00 2e 00 74 00 61 00 67 00 22 00 3a 00 22 00 6f 00 76 00 65 00 72 00 77 00 72 00 69 00 74 00 65 00 22 00 7d 00 7d}
		$ = {68 00 74 00 74 00 70 00 73 00 3a 00 2f 00 2f 00 63 00 6c 00 6f 00 75 00 64 00 2d 00 61 00 70 00 69 00 2e 00 79 00 61 00 6e 00 64 00 65 00 78 00 2e 00 6e 00 65 00 74 00 2f 00 76 00 31 00 2f 00 64 00 69 00 73 00 6b 00 2f 00 72 00 65 00 73 00 6f 00 75 00 72 00 63 00 65 00 73 00 2f 00 75 00 70 00 6c 00 6f 00 61 00 64 00 3f 00 70 00 61 00 74 00 68 00 3d 00 25 00 73 00 26 00 6f 00 76 00 65 00 72 00 77 00 72 00 69 00 74 00 65 00 3d 00 25 00 73}

	condition:
		uint16( 0 ) == 0x5A4D and any of them
}
rule SEKOIA_Backdoor_Opensource_Northstar_Strings : FILE
{
	meta:
		description = "Detects the NorthStar Backdoor strings"
		author = "Sekoia.io"
		id = "6bf2f428-ec1a-4115-9c5e-258e9176969a"
		date = "2022-08-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_opensource_northstar_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c4cf8935137c1420106807240de7583ca8f5c0b231f51bba279aedf672e25274"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "_SAMDUMP.zip" wide
		$ = "northstar" wide
		$ = "smanage.php?sid=" wide
		$ = "File Not Exists" wide
		$ = "<enablecmd or enable cmd>" wide
		$ = "getjuice.php" wide

	condition:
		uint16be( 0 ) == 0x4d5a and 6 of them
}
rule SEKOIA_Webshell_Wso_Webshell_Strings
{
	meta:
		description = "Detects the WSO webshells"
		author = "Sekoia.io"
		id = "84340792-73a4-4d61-9957-6cfa1f6444a7"
		date = "2022-04-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/webshell_wso_webshell_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "4d6966a34dc8e7390913857144da106affea14668d1c2c11a05be62a6e625c8f"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "decrypt($str,$pwd){$pwd=base64_encode($pwd);"
		$ = "prototype(md5($_SERVER['HTTP_HOST'])"
		$ = "$_COOKIE[md5($_SERVER['HTTP_HOST'])."
		$ = "set(a,c,p1,p2,p3,charset)"
		$ = "(($p & 0x0008) ? (($p & 0x0400)"
		$ = "gcc','lcc','cc','ld','make','php"

	condition:
		3 of them
}
rule SEKOIA_Tool_Sharphoundpowershell_Strings : FILE
{
	meta:
		description = "Detects SharpHound Powershell"
		author = "Sekoia.io"
		id = "f27a0bdc-1a8c-43f9-843c-6c8506726f37"
		date = "2022-08-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_sharphoundpowershell_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "29756acb0afd8aabac170ca8288f1dcffcb2e601c9bdba1cc7a30b8b415661f6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "function Invoke-BloodHound"
		$ = "$vars.Add($RealDNSName)"
		$ = "$vars.Add($Jitter)"
		$ = "CmdletBinding(PositionalBinding = $false)"
		$ = ").Invoke($Null, @(,$passed))"
		$ = "$EncodedCompressedFile ="

	condition:
		filesize < 2MB and 4 of them
}
rule SEKOIA_Backdoor_Blueshell : FILE
{
	meta:
		description = "Detects BlueShell backdoor"
		author = "Sekoia.io"
		id = "8f1cd966-c4d8-44f9-8cd5-4f5277332546"
		date = "2023-09-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_blueshell.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "348ae383f2aaef544951641dd7e2879afa23e37bdf429c6255254115bd3e10d5"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "BlueShell" ascii
		$s2 = "client.go" ascii
		$s3 = "server ip" ascii
		$s4 = "server port" ascii
		$s5 = "reconnect wait time" ascii
		$s6 = "shell" ascii
		$s7 = "socks" ascii
		$s8 = "socks5" ascii
		$s9 = "GetInteractiveShell" ascii

	condition:
		filesize < 11MB and all of them
}
rule SEKOIA_Tool_Tokenplayer_Strings : FILE
{
	meta:
		description = "Detects TokenPlayer based on strings"
		author = "Sekoia.io"
		id = "74ed8812-f113-47a9-9ff2-6cbe2746ee11"
		date = "2024-11-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_tokenplayer_strings.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "f01eae4ee3cc03d621be7b0af7d60411"
		logic_hash = "e419fa8c690816cd0e449f0a1d66d170e8806b38a99758631719b239363e330e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[*]Spawning Process as user: %s\\%s" wide
		$ = "[-]Target isn't vulnerable!"
		$ = "[+]Process spawned!"
		$ = "[+]Process Spawned"
		$ = "[+]OpenProcessToken() success!"
		$ = "CreateProcessWithLogonW() error : % u"
		$ = "[+]CreateProcessWithLogonW() succeed!"
		$ = "TokenPlayer.pdb"

	condition:
		uint16be( 0 ) == 0x4d5a and 5 of them and filesize < 500KB
}
rule SEKOIA_Backdoor_Oyster
{
	meta:
		description = "Detects files related to the Oyster backdoor."
		author = "Sekoia.io"
		id = "f95f98ea-1e52-45ae-8abf-a986f95d4ab2"
		date = "2024-08-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_oyster.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ffd84d0c7064bcd69121aa606bc642ff2b5c9927ba622260a02a9689c7ab8878"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "CleanUp30.dll" ascii fullword
		$s2 = "MSTeamsSetup_c_l_.exe" ascii fullword

	condition:
		all of them
}
rule SEKOIA_Apt_Andariel_Keylogger_Strings : FILE
{
	meta:
		description = "Detects one of the Andariel keylogger"
		author = "Sekoia.io"
		id = "59e94bee-9bd4-4f72-9358-858956bb4787"
		date = "2024-06-17"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_andariel_keylogger_strings.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "671698af4fbaed3d19f3d3498263183909db9422a5a0a8f12ba119409773c505"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Username:%s [%d/%02d/%02d %02d:%02d]" ascii fullword
		$ = "-------[%d/%02d/%02d %02d:%02d]"
		$ = "{Insert}"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 300KB and 2 of them
}
rule SEKOIA_Hacktool_Dnscat2_Strings : FILE
{
	meta:
		description = "Detects DNSCat2 based on strings"
		author = "Sekoia.io"
		id = "9655cdd7-c7fe-4033-bdd9-bdfcfd2bf827"
		date = "2022-02-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_dnscat2_strings.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "40d906ca3a00f7d3e2f8d043dbbc77a2a57fd133f4812b863aec6d5a0f57a8c9"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Creating a exec('%s') session!"
		$ = "RROR parsing --dns"
		$ = "Got a ping request! Responding!"
		$ = "[Tunnel %d] Received %zd bytes"
		$ = "[Tunnel %d] connection to %s:%d"
		$ = "You'll need to use --dns server=<server>"
		$ = "Setting delay between packets to %dms"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and 3 of them
}
rule SEKOIA_Hacktool_Sharpview_Strings : FILE
{
	meta:
		description = "Detects SharpView based on strings."
		author = "Sekoia.io"
		id = "585ead98-36d0-402c-b527-4dec308cb1c9"
		date = "2022-02-14"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_sharpview_strings.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "762e8d292e052cb0922743c2f5b14170e91fe440e05331892b20b5921e0559da"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Args_Get_DomainGPOComputerLocalGroupMapping"
		$ = "Args_Get_ForestGlobalCatalog"
		$ = "Args_Find_DomainLocalGroupMember"
		$ = "Args_Get_DomainFileServer"
		$ = "Ex: SharpView.exe Method-Name" wide
		$ = "[Get-PathAcl] error: {0}" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 800KB and 5 of them
}
rule SEKOIA_Infostealer_Win_Blackguard_Mar23 : FILE
{
	meta:
		description = "Finds BlackGuard samples based on specific strings (March 2023, version 5)"
		author = "Sekoia.io"
		id = "65804d31-2a0c-4b22-a8d9-8cbe1497f155"
		date = "2023-03-27"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_blackguard_mar23.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "63d77808036478da0c8d38a6d3581ccd2d4e46ae16ec9e817f09f8b633b01843"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "==================  5.0 ==============" wide
		$str02 = "/concerts/disk.php" wide
		$str03 = "/concerts/memory.php" wide
		$str04 = "/loader_v2.txt" wide
		$str05 = "io.solarwallet.app\\Local Storage\\leveldb" wide
		$str06 = "costura.dotnetzip.dll.compressed" ascii wide
		$str07 = "set_Laskakakaska" ascii
		$str08 = "get_Yliana" ascii
		$str09 = "set_Illeona" ascii
		$str10 = "set_Gyttettfd" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 4 of them
}
rule SEKOIA_Apt_Kimsuky_Vbs : FILE
{
	meta:
		description = "VBS files used by Kimsuky"
		author = "Sekoia.io"
		id = "3f92dbda-2ddb-4fa3-a587-743f65ced9e4"
		date = "2024-09-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_kimsuky_vbs.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "12386be22ca82fce98a83a5a19e632bc"
		hash = "7b5783d42240651af78ebf7e01b31fe8"
		hash = "ff7d68e5fb253664ce64c85457b28041"
		hash = "622358469e5e24114dd0eb03da815576"
		hash = "edbb2aa40408e2a7936067ace38b445b"
		hash = "73ed9b012785dc3b3ee33aa52700cfe4"
		logic_hash = "b4a05a50c8223198082f6f6aa7309cc19b019738fb99e37c6f2140b8ef7cecc9"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = ")):Next:Execute " ascii
		$ = "=\"\":" ascii
		$ = "\":for "

	condition:
		all of them and filesize < 10KB
}
rule SEKOIA_Downloader_Kimsuky_Lnk
{
	meta:
		description = "Detect Kimsuky LNK"
		author = "Sekoia.io"
		id = "3831d115-7874-4bc9-aeb4-d2cb9bc2b5c9"
		date = "2024-07-16"
		modified = "2024-12-19"
		reference = "https://blogs.jpcert.or.jp/en/2024/07/attack-activities-by-kimsuky-targeting-japanese-organizations.html"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/downloader_kimsuky_lnk.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "3065b8e4bb91b4229d1cea671e8959da8be2e7482067e1dd03519c882738045e"
		hash = "d912f49d24792aa7197509f76e2097ac3858cde23199e1b40f2516948d39c589"
		hash = "e936445935c4a636614f7113e4121695a5f3e4a6c137b7cdcceb6f629aa957c4"
		hash = "fe156159a26f8b7c140db61dd8b136e1c8103a800748fe9b70a3a3fdf179d3c3"
		logic_hash = "3512c8c21203a015b316c2a993db1a8c10420df06ea97d84a6e350550a628230"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "AType: Text Document" wide
		$ = "Size: 5.23 KB" wide
		$ = "Date modified: 01/02/2020 11:23" wide

	condition:
		all of them
}
rule SEKOIA_Apt_Oilrig_Powerexchange : FILE
{
	meta:
		description = "Detects OilRig's PowerExchange backdoor"
		author = "Sekoia.io"
		id = "cb6b370f-7b05-480b-865e-ac81ded4a2a4"
		date = "2023-10-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_oilrig_powerexchange.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5e505e9bbb17500f7e9a316b66bccb62089172582478230e0bda736bbefa1fd6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "($h.value).PadRight((($h.value).Length+($h.value).Length%4),'='" ascii wide
		$ = "(($h.value).Length%4 -ne 0)" ascii wide
		$ = "-match \"@@(.*)@@\"" ascii wide
		$ = "[Environment]::NewLine+$_.Exception.Message | Out-File -FilePath" ascii wide
		$ = "ContainsSubjectStrings.Add(\"@@\")" ascii wide

	condition:
		2 of them and filesize < 50KB
}
rule SEKOIA_Exploit_Linux_Eop_Polkit_Pkexec_Strings : FILE
{
	meta:
		description = "Detects Polkit Local Privesc exploit"
		author = "Sekoia.io"
		id = "de45c29e-432a-4e4f-b700-a016341d56d2"
		date = "2023-12-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/exploit_linux_eop_polkit_pkexec_strings.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "42d04204481c165ba1b5c4ee5ff1094c31400669b0eca041d736473d481e74b7"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[.] Spawning suid process (%s) ..."
		$ = "[.] Tracing midpid ..."
		$ = "PTRACE_TRACEME local root (CVE-2019-13272)"

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 1MB and all of them
}

rule SEKOIA_Loader_Win_Dodgebox
{
	meta:
		description = "Detect the DodgeBox malware using several criteria"
		author = "Sekoia.io"
		id = "8d5f94f3-1add-4f34-ba9e-f8f576c4e5b8"
		date = "2024-07-15"
		modified = "2024-12-19"
		reference = "https://www.zscaler.com/blogs/security-research/dodgebox-deep-dive-updated-arsenal-apt41-part-1"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_dodgebox.yar#L4-L29"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "c6a3a1ea84251aed908702a1f2a565496d583239c5f467f5dcd0cfc5bfb1a6db"
		hash = "33fd050760e251ab932e5ca4311b494ef72cee157b20537ce773420845302e49"
		logic_hash = "e859da15a065454d273c4040b4e3409c3046cbcee135497bdcce6cff620c3cfb"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		pe.imphash( ) == "aeea1135af87e6b6b23fa7da995967ea" or hash.md5 ( pe.rich_signature.clear_data ) == "1c850cf955b35f60ee6c12d01161d95d" or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "4a80edcce2a5ac85c3f849172ee89c0f" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "53781057440f51882c38d3a9ef611775" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "801b286d84a97fe919721843ab77210d" )
}
rule SEKOIA_Apt_Muddywater_Powershell_Reverse_Secure_Proxy
{
	meta:
		description = "Detects PowerShell Reverse Secure Proxy"
		author = "Sekoia.io"
		id = "b255f327-cb56-41b7-82f7-83ee23f791a5"
		date = "2023-11-14"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_muddywater_powershell_reverse_secure_proxy.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6507bc030d60af5559492bbb02bc619646306ab06c9bd9d3f78ae6ce55307bda"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "$CS.Read($buff,4,2) | Out-Null" ascii wide
		$ = "$DP = $buff[2]*256 + $buff[3]" ascii wide
		$ = "$PS3.BeginInvoke() | Out-Null" ascii wide

	condition:
		all of them
}
rule SEKOIA_Implant_Win_Quasarrat
{
	meta:
		description = "Detect QuasarRAT (reted from samples 2023-03)"
		author = "Sekoia.io"
		id = "492fdffc-8e5f-4225-a2eb-cd6d80e6bcb8"
		date = "2023-03-17"
		modified = "2024-12-19"
		reference = "https://blog.alyac.co.kr/5103"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_win_quasarrat.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "d3c1d65a23aaea5423025cb2f755d0f2298cbf02b2a4e34430eae8c3e1263185"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = {63 00 68 00 63 00 70 00 20 00 36 00 35 00 30 00 30 00 31 00}
		$ = {65 00 63 00 68 00 6f 00 20 00 44 00 4f 00 4e 00 54 00 20 00 43 00 4c 00 4f 00 53 00 45 00 20 00 54 00 48 00 49 00 53 00 20 00 57 00 49 00 4e 00 44 00 4f 00 57 00 21 00}
		$ = {70 00 69 00 6e 00 67 00 20 00 2d 00 6e 00 20 00 31 00 30 00 20 00 6c 00 6f 00 63 00 61 00 6c 00 68 00 6f 00 73 00 74 00 20 00 3e 00 20 00 6e 00 75 00 6c 00}
		$ = {64 00 65 00 6c 00 20 00 2f 00 61 00 20 00 2f 00 71 00 20 00 2f 00 66 00 20 00 22 00}
		$ = "DoShellExecute"
		$ = "DoDownloadFile"

	condition:
		all of them
}
rule SEKOIA_Tool_Generic_Python_Reverse_Shell_Strings : FILE
{
	meta:
		description = "Detects reverse shell"
		author = "Sekoia.io"
		id = "5b926d15-4f21-428c-a9fa-ee085a98d42b"
		date = "2024-04-16"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_generic_python_reverse_shell_strings.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "bb4fcef595f4be035815f536786987ac1343727f16c0560a1cb593e854ba8f17"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "import sys,socket,os,pty;"
		$ = "[os.dup2(s.fileno(),fd) for fd in (0,1,2)]"

	condition:
		all of them and filesize < 1000
}
rule SEKOIA_Ta410_Control_Flow_Obfuscation : FILE
{
	meta:
		description = "Detects control flow obfuscation used by TA410 in XXXModule_dlcore0"
		author = "Sekoia.io"
		id = "2a784f9b-3624-4c5d-8a64-db7d3c33a8f7"
		date = "2022-10-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ta410_control_flow_obfuscation.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "6cf78943728286d0bddd99049d81065673ab7f679029cdd5f5dc69f90197136e"
		logic_hash = "3ee6ee07e7a7be285290ec91de649afff3e5dc222bcfc58709b642d4dd53dc41"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$chunk_1 = {
        E8 ?? ?? ?? ??
        83 C0 10
        3D 00 00 00 80
        7D 01
        EB ff
        }
		$chunk_2 = {83 C0 10 3D 00 00 00 80 7d 01 eb ff e0 50 c3 75}

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 10MB and any of them
}
rule SEKOIA_Gen_Empire_Onedrive_Stager
{
	meta:
		description = "Detects the Empire OneDrive stager"
		author = "Sekoia.io"
		id = "2053416f-1f53-491e-9c70-787a04362d16"
		date = "2022-01-26"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/gen_empire_onedrive_stager.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "90b3548cd3f4f7f936da70ec95dbe0ff3c1421d40a6e8557952d28d358b7c1f1"
		score = 75
		quality = 76
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$sleep = "Start-Sleep -Seconds $(($PI -as [Int])*2)" wide ascii nocase
		$down = "wc.DownloadData" wide ascii nocase

	condition:
		$down in ( @sleep .. @sleep + 1000 )
}
