import "dotnet"
import "hash"
import "pe"

rule SEKOIA_Clipper_Win_Cryptoclippy : FILE
{
	meta:
		description = "Finds CryptoClippy samples"
		author = "Sekoia.io"
		id = "eaa98a8e-e29e-43a4-8b2d-2137d33d4116"
		date = "2023-04-11"
		modified = "2024-12-19"
		reference = "https://unit42.paloaltonetworks.com/crypto-clipper-targets-portuguese-speakers/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/clipper_win_cryptoclippy.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "057cb5bb957c2338a50c05cfa0177f75bcf263281ddcc5f365298bccafc64cb4"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "C:\\mbedtls\\library\\" ascii
		$str02 = "udp://8.8.8.8:53" ascii
		$str03 = "Upgrade: websocket" ascii
		$str04 = "%s\\%s.lnk" ascii
		$str05 = "%s\\%s.ps1" ascii
		$str06 = "%s\\%s.bat" ascii
		$str07 = "set PSExecutionPolicyPreference=Unrestricted" ascii
		$str08 = "schtasks /delete /tn \"%ls\" /f" ascii
		$str09 = "SetClipboardData" ascii
		$str10 = "SetWinEventHook" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 8 of them
}
rule SEKOIA_Malware_Swordldr : FILE
{
	meta:
		description = "Detects Swordldr. Maybe chunk_1 is too restrictive"
		author = "Sekoia.io"
		id = "4068c007-50f4-4913-a352-4a40dd4e452b"
		date = "2024-09-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/malware_swordldr.yar#L1-L29"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "d0cc758082e303275cbb8cd6b2048eff"
		hash = "7aa57da44718cd88f7d37b33a5d3ad74"
		logic_hash = "9e408181b9122925c0ff9efdaed688e659596b58b9108c0f280d9bc1624d73cb"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = { CC CC CC CC B0 01 C3 CC CC CC CC }
		$ = { CC CC CC CC B0 02 C3 CC CC CC CC }
		$ = { CC CC CC CC B0 03 C3 CC CC CC CC }
		$ = { CC CC CC CC B0 04 C3 CC CC CC CC }
		$ = { CC CC CC CC B0 05 C3 CC CC CC CC }
		$ = { CC CC CC CC B0 06 C3 CC CC CC CC }
		$ = { CC CC CC CC B0 07 C3 CC CC CC CC }
		$ = { CC CC CC CC B0 08 C3 CC CC CC CC }
		$ = { CC CC CC CC B0 09 C3 CC CC CC CC }
		$chunk_1 = {
        48 63 44 24 40 44 8B 44 86 04 48 63 44 24 40 45 23 ?? 45 03 C0 8B 54 86 04 48 63 44 24 40 41 2B D0 41 03 ?? 89 54 86 04
        }

	condition:
		uint16be( 0 ) == 0x4d5a and 4 of them and #chunk_1 > 5
}
rule SEKOIA_Tool_Win_Sharpshares : FILE
{
	meta:
		description = "Finds sharpshares EXE based on strings"
		author = "Sekoia.io"
		id = "ef90d573-12f8-4216-9a9e-96e7d1e841d0"
		date = "2024-06-10"
		modified = "2024-12-19"
		reference = "https://github.com/mitchmoser/SharpShares/releases"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_win_sharpshares.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6aa96d7c24638451bde98497cc7c844c87612d81cc7826113729c80bd5180442"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "<GetAllShares>b__0" ascii
		$str02 = "<SearchLDAP>b__0_0" ascii
		$str03 = "get_AccessControlType" ascii
		$str04 = "get_IdentityReference" ascii
		$str05 = "get_PropertiesToLoad" ascii
		$str06 = "SharpShares\\obj\\Release\\SharpShares.pdb" ascii
		$str07 = "/filter:SYSVOL,NETLOGON,IPC$,PRINT$" wide
		$str08 = "/threads:50 /ldap:servers" wide
		$str09 = "SharpShares.exe" ascii wide
		$str10 = "[+] LDAP Search Results:" wide
		$str11 = "[+] Finished Enumerating Shares" wide

	condition:
		uint16( 0 ) == 0x5A4D and 6 of them
}
rule SEKOIA_Apt_Kimsuky_Sharptongue_Vbslauncher_Strings : FILE
{
	meta:
		description = "Detects VBS Launchers used by SharpTongue"
		author = "Sekoia.io"
		id = "82bd648c-2961-4945-950e-8fb1e4650338"
		date = "2022-07-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_kimsuky_sharptongue_vbslauncher_strings.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "9e1383a71b4ab5ca1de5016061f0e9c83e6f3e1a41eef25dae15cd1aab8b581f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "powershell" ascii wide
		$ = "On Error Resume Next" ascii wide
		$ = "oShell.run(tmp0,0" ascii wide

	condition:
		all of them and filesize < 10KB
}
/*
 * YARA Rule Set
 * Repository Name: Synacktiv
 * Repository: https://github.com/synacktiv/synacktiv-rules
 * Retrieval Date: 2026-11-22
 * Git Commit: d234cc4da0783db7dca56ae8dd5252afdc248df8
 * Number of Rules: 3
 * Skipped: 0 (age), 0 (quality), 5 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * # Detection Rule License (DRL) 1.1

Permission is hereby granted, free of charge, to any person obtaining a copy of this rule set and associated documentation files (the "Rules"), to deal in the Rules without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Rules, and to permit persons to whom the Rules are furnished to do so, subject to the following conditions:

If you share the Rules (including in modified form), you must retain the following if it is supplied within the Rules:

1. identification of the authors(s) ("author" field) of the Rule and any others designated to receive attribution, in any reasonable manner requested by the Rule author (including by pseudonym if designated).

2. a URI or hyperlink to the Rule set or explicit Rule to the extent reasonably practicable

3. indicate the Rules are licensed under this Detection Rule License, and include the text of, or the URI or hyperlink to, this Detection Rule License to the extent reasonably practicable

If you use the Rules (including in modified form) on data, messages based on matches with the Rules must retain the following if it is supplied within the Rules:

1. identification of the authors(s) ("author" field) of the Rule and any others designated to receive attribution, in any reasonable manner requested by the Rule author (including by pseudonym if designated).

THE RULES ARE PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE RULES OR THE USE OR OTHER DEALINGS IN THE RULES.
 */
rule SYNACKTIV_SYNACKTIV_HKTL_Tunnel_GO_Iox_May25 : COMMODITY FILE
{
	meta:
		description = "Detects the iox tunneling tool used for port forwarding and SOCKS5 proxy"
		author = "Synacktiv, Maxence Fossat [@cybiosity]"
		id = "407d4f90-a281-4f0c-8d8e-ebe45217d3d9"
		date = "2025-05-12"
		modified = "2025-05-12"
		reference = "https://www.synacktiv.com/en/publications/open-source-toolset-of-an-ivanti-csa-attacker"
		source_url = "https://github.com/synacktiv/synacktiv-rules/blob/d234cc4da0783db7dca56ae8dd5252afdc248df8/2025/offensive_tools/hktl_tunnel_go_iox.yar#L1-L49"
		license_url = "https://github.com/synacktiv/synacktiv-rules/blob/d234cc4da0783db7dca56ae8dd5252afdc248df8/LICENSE.md"
		hash = "0500c9d0b91e62993447cdcf5f691092aff409eca24080ce149f34e48a0445e0"
		hash = "13c1cfb12017aa138e2f8d788dcd867806cc8fd6ae05c3ab7d886c18bcd4c48a"
		hash = "1a9524a2c39e76e0ea85abba1f0ddddc5d0d0a3a601a1b75e8d224ad93968b5e"
		hash = "1bd710dc054716bf5553abd05d282d9aeb7eb30a76320bd6be4ce2efc04b20bc"
		hash = "328570168780a5dd39e1b49db00430c02d3292ff1e8b14ff6aacce40d90d908f"
		hash = "35d83137ea70e94187a9ad9b7fa2d7b6c6b9128eb9d104380f2ac525784b9a78"
		hash = "4806fd64647e02a34dd49f9057c6bf95325dcc923764ff2ef61cbbab40ca8c48"
		hash = "4c4ec3314afe4284e4cf8bf2fdfb402820932ddcf16913a88a2b7c1d55a12a90"
		hash = "4d49ceb20ad85b117dd30f317977526e73cb5dd622705277b5cbc691972abb4b"
		hash = "63d32b6b29e5d4f8aab4b59681d853e481e858cbf1acfcb190469d8881f47aa6"
		hash = "92cc697b909c398de8533499271c9d3c2425a71feaa0d70bac7428d90423ddff"
		hash = "9480d060de29548bcf961267cec1e8c926b99dc93b65fd696bbedd308ad9f85f"
		hash = "a4139ffd12565edf5291dc5580a70e600f76695b03376e5c0130ade18a6a7bcd"
		hash = "aeddd8240c09777a84bb24b5be98e9f5465dc7638bec41fb67bbc209c3960ae1"
		hash = "b9c40960259b9b14d80c8b1cb3438913f8550fe56dbdfe314b53c7ceae77ccb0"
		hash = "ba661b3f18fa7865503523ce514367e05626c088a34c6c29269e3bde57d00ec3"
		hash = "c061952d49f03acf9e464ab927b0b6b3bc38da8caaf077e70ace77116b6d1b8c"
		hash = "c1ca82411e293ec5d16a8f81ed9466972a8ead23bd4080aaf9505baccce575ba"
		hash = "c6cf82919b809967d9d90ea73772a8aa1c1eb3bc59252d977500f64f1a0d6731"
		hash = "c8b40fbb5cd27f42c143c35b67c700f7ea42a2084418c5e2da82fb0ac094f966"
		hash = "cd5bbcf663f06003637e4aab348bbec3d4a47e53e8fa85826e161d34b86e93f8"
		hash = "d879ff9275cd62f4e7935261e17461d3a3cd1a29d65a5688bd382c47ae680ad6"
		hash = "e92c85b36d0848171ada787862413e0edd8291c8ae6a43e13b075b9ccbd53434"
		hash = "f22f2932c02bbd47ea556e15a51c20301ca7084c4b943672ade70bc49dc3e0c4"
		logic_hash = "39b68d6920b83e36942456b8ff0eeff18ae280e13e86df916c3586922d79aba8"
		score = 75
		quality = 80
		tags = "COMMODITY, FILE"
		license = "DRL-1.1"
		tlp = "TLP:CLEAR"
		pap = "PAP:CLEAR"

	strings:
		$s1 = "Forward UDP traffic between %s (encrypted: %v) and %s (encrypted: %v)"
		$s2 = "Open pipe: %s <== FWD ==> %s"
		$s3 = "Reverse socks5 server handshake ok from %s (encrypted: %v)"
		$s4 = "Recv exit signal from remote, exit now"
		$s5 = "socks consult transfer mode or parse target: %s"

	condition:
		( uint16be( 0 ) == 0x4d5a or uint32be( 0 ) == 0x7f454c46 or uint32be( 0 ) == 0xcffaedfe or uint32be( 0 ) == 0xcefaedfe ) and filesize < 5MB and all of them
}
rule SYNACKTIV_SYNACKTIV_WEBSHELL_ASPX_Suo5_May25 : WEBSHELL COMMODITY FILE
{
	meta:
		description = "Detects the .NET version of the suo5 webshell"
		author = "Synacktiv, Maxence Fossat [@cybiosity]"
		id = "d30a7232-f00b-45ab-9419-f43b1611445a"
		date = "2025-05-12"
		modified = "2025-05-12"
		reference = "https://www.synacktiv.com/en/publications/open-source-toolset-of-an-ivanti-csa-attacker"
		source_url = "https://github.com/synacktiv/synacktiv-rules/blob/d234cc4da0783db7dca56ae8dd5252afdc248df8/2025/offensive_tools/webshell_aspx_suo5.yar#L1-L46"
		license_url = "https://github.com/synacktiv/synacktiv-rules/blob/d234cc4da0783db7dca56ae8dd5252afdc248df8/LICENSE.md"
		hash = "06710575d20cacd123f83eb82994879367e07f267e821873bf93f4db6312a97b"
		hash = "e6979d7df0876679fc2481aa68fcec5b6ddc82d854f63da2bddb674064384f9a"
		hash = "3bbbef1b4ead98c61fba60dd6291fe1ff08f5eac54d820e47c38d348e4a7b1ec"
		hash = "345c383dd439eb523b01e1087a0866e13f04ff53bb8cc11f3c70b4a382f10c7e"
		hash = "838840dd76ff34cee45996fdc9a87856c9a0f14138e65cb9eb6603ed157d1515"
		hash = "d9657ac8dd562bdd39e8fcc1fff37ddced10f7f3f118d9cd4da6118a223dcc45"
		logic_hash = "68dc29b2cedc26e638eaa12bf2a2d0415de323097baf5ea61dba52bd20b5beee"
		score = 75
		quality = 80
		tags = "WEBSHELL, COMMODITY, FILE"
		license = "DRL-1.1"
		tlp = "TLP:CLEAR"
		pap = "PAP:CLEAR"

	strings:
		$user_agent = ".Equals(\"Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.1.2.3\")" ascii
		$header = "Response.AddHeader(\"X-Accel-Buffering\", \"no\")" ascii
		$xor = /= \(byte\)\(\w{1,1023}\[\w{1,1023}\] \^ \w{1,1023}\);/
		$s1 = "Request.Headers.Get(\"User-Agent\")" ascii
		$s2 = "if (Request.ContentType.Equals(\"application/plain\"))" ascii
		$s3 = "Response.ContentType = \"application/octet-stream\";" ascii
		$s4 = "= Request.BinaryRead(Request.ContentLength);" ascii
		$s5 = "= Response.OutputStream;" ascii
		$s6 = "new TcpClient()" ascii
		$s7 = ".BeginConnect(" ascii
		$s8 = ".GetStream().Write(" ascii
		$s9 = "new BinaryWriter(" ascii
		$s10 = "new BinaryReader(" ascii
		$s11 = ".ReadBytes(4)" ascii
		$s12 = "BitConverter.GetBytes((Int32)" ascii
		$s13 = "BitConverter.ToInt32(" ascii
		$s14 = "Array.Reverse(" ascii
		$s15 = "new Random().NextBytes(" ascii

	condition:
		filesize < 100KB and ( $user_agent or ( ( $header or $xor ) and 8 of ( $s* ) ) or 12 of ( $s* ) )
}
rule SYNACKTIV_SYNACKTIV_HKTL_Tunnel_X64_GO_Iox_May25 : COMMODITY FILE
{
	meta:
		description = "Detects the 64-bits version of the iox tunneling tool used for port forwarding and SOCKS5 proxy"
		author = "Synacktiv, Maxence Fossat [@cybiosity]"
		id = "0b5a4689-58ea-45d5-aa14-a1455276352a"
		date = "2025-05-12"
		modified = "2025-05-12"
		reference = "https://www.synacktiv.com/en/publications/open-source-toolset-of-an-ivanti-csa-attacker"
		source_url = "https://github.com/synacktiv/synacktiv-rules/blob/d234cc4da0783db7dca56ae8dd5252afdc248df8/2025/offensive_tools/hktl_tunnel_x64_go_iox.yar#L1-L96"
		license_url = "https://github.com/synacktiv/synacktiv-rules/blob/d234cc4da0783db7dca56ae8dd5252afdc248df8/LICENSE.md"
		hash = "0500c9d0b91e62993447cdcf5f691092aff409eca24080ce149f34e48a0445e0"
		hash = "13c1cfb12017aa138e2f8d788dcd867806cc8fd6ae05c3ab7d886c18bcd4c48a"
		hash = "1a9524a2c39e76e0ea85abba1f0ddddc5d0d0a3a601a1b75e8d224ad93968b5e"
		hash = "1bd710dc054716bf5553abd05d282d9aeb7eb30a76320bd6be4ce2efc04b20bc"
		hash = "2457a3241ec13c77b4132d6c5923e63b51a4d05a96dc0ae249c92a43ed9c7c04"
		hash = "328570168780a5dd39e1b49db00430c02d3292ff1e8b14ff6aacce40d90d908f"
		hash = "39d51ef91e189de44696ac67590b4251a6a320719668399127096dc57cbecba3"
		hash = "4c4ec3314afe4284e4cf8bf2fdfb402820932ddcf16913a88a2b7c1d55a12a90"
		hash = "4d1e87b372af0f52b9e2d7a2ac1d223575d29de5e3c0570a96b0d2ff346214f0"
		hash = "4d49ceb20ad85b117dd30f317977526e73cb5dd622705277b5cbc691972abb4b"
		hash = "5138090aee794a08de4b0482bbe58adbd918467d14dedf51961963b324e63f89"
		hash = "63d32b6b29e5d4f8aab4b59681d853e481e858cbf1acfcb190469d8881f47aa6"
		hash = "79d6dfacfa0e0e5bc48d8d894dae261b9412b9c04a39b6ebf992cb8a5a40de95"
		hash = "82aec8846232a43a77e2b5c5a80de523b2c7f912d60bce3ac28242156395b9d0"
		hash = "92cc697b909c398de8533499271c9d3c2425a71feaa0d70bac7428d90423ddff"
		hash = "9e3cba612d5f69e27534e3d2ceb7bb6067d44ac93e5b1e74bf994a94dfd706b6"
		hash = "a4139ffd12565edf5291dc5580a70e600f76695b03376e5c0130ade18a6a7bcd"
		hash = "a8bda8e1d39ee61998381a2f0bfeb7069b19035551b8895eb48642bf98ade3d1"
		hash = "aeddd8240c09777a84bb24b5be98e9f5465dc7638bec41fb67bbc209c3960ae1"
		hash = "b9c40960259b9b14d80c8b1cb3438913f8550fe56dbdfe314b53c7ceae77ccb0"
		hash = "c061952d49f03acf9e464ab927b0b6b3bc38da8caaf077e70ace77116b6d1b8c"
		hash = "c1ca82411e293ec5d16a8f81ed9466972a8ead23bd4080aaf9505baccce575ba"
		hash = "c6cf82919b809967d9d90ea73772a8aa1c1eb3bc59252d977500f64f1a0d6731"
		hash = "c8b40fbb5cd27f42c143c35b67c700f7ea42a2084418c5e2da82fb0ac094f966"
		hash = "d3190648bc428640a721b7d3c2b05c56e855355e8b44561e3b701e80e97f7ea7"
		hash = "d879ff9275cd62f4e7935261e17461d3a3cd1a29d65a5688bd382c47ae680ad6"
		hash = "d9e868af5567a8c823f48f0f30440f1a9d77b52b2e6d785e116c450c48df9fc6"
		logic_hash = "adf3e21aa146b3def9baa73829126d8738db9cedb96e783a6baa589c77d7d518"
		score = 75
		quality = 80
		tags = "COMMODITY, FILE"
		license = "DRL-1.1"
		tlp = "TLP:CLEAR"
		pap = "PAP:CLEAR"

	strings:
		$expand_key = {
            ( 48 8B 84 24 | 48 8B 9C 24 | 48 8B 8C 24 | 48 8B BC 24 | 48 8B B4 24 | 4C 8B 84 24 | 4C 8B 8C 24 | 4C 8B 94 24 | 4C 8B 9C 24 ) ?? ?? ?? ??
            ( 48 83 F8 20 | 48 83 FB 20 | 48 83 F9 20 | 48 83 FF 20 | 48 83 FE 20 | 49 83 F8 20 | 49 83 F9 20 | 49 83 FA 20 | 49 83 FB 20 )
            ( 0F 8D ?? ?? ?? ?? | 7D ?? )
            ( 48 89 ?? | 49 89 ?? | 4C 89 ?? | 4D 89 ?? )
            ( 48 83 E0 1F | 48 83 E3 1F | 48 83 E1 1F | 48 83 E7 1F | 48 83 E6 1F | 49 83 E0 1F | 49 83 E1 1F | 49 83 E2 1F | 49 83 E3 1F | 83 E0 1F | 83 E3 1F | 83 E1 1F | 83 E7 1F | 83 E6 1F | 41 83 E0 1F | 41 83 E1 1F | 41 83 E2 1F | 41 83 E3 1F )
            ( 83 C0 E0 | 83 C3 E0 | 83 C1 E0 | 83 C7 E0 | 83 C6 E0 | 41 83 C0 E0 | 41 83 C1 E0 | 41 83 C2 E0 | 41 83 C3 E0 )
            ( F7 D8 | F7 DB | F7 D9 | F7 DF | F7 DE | 41 F7 D8 | 41 F7 D9 | 41 F7 DA | 41 F7 DB )
        }
		$shuffle = {
            ( 44 0F B6 04 | 44 0F B6 0C | 44 0F B6 14 | 44 0F B6 1C | 44 0F B6 44 | 44 0F B6 4C | 44 0F B6 54 | 44 0F B6 5C | 46 0F B6 04 | 46 0F B6 0C | 46 0F B6 14 | 46 0F B6 1C | 46 0F B6 44 | 46 0F B6 4C | 46 0F B6 54 | 46 0F B6 5C ) [1-2]
            ( 45 0F AF C0 | 45 0F AF C1 | 45 0F AF C2 | 45 0F AF C3 | 45 0F AF C8 | 45 0F AF C9 | 45 0F AF CA | 45 0F AF CB | 45 0F AF D0 | 45 0F AF D1 | 45 0F AF D2 | 45 0F AF D3 | 45 0F AF D8 | 45 0F AF D9 | 45 0F AF DA | 45 0F AF DB | 44 0F AF C0 | 44 0F AF C1 | 44 0F AF C2 | 44 0F AF C3 | 44 0F AF C8 | 44 0F AF C9 | 44 0F AF CA | 44 0F AF CB | 44 0F AF D0 | 44 0F AF D1 | 44 0F AF D2 | 44 0F AF D3 | 44 0F AF D8 | 44 0F AF D9 | 44 0F AF DA | 44 0F AF DB )
            [0-4]
            ( 41 B8 | 41 B9 | 41 BA | 41 BB ) FF FF FF FF
            ( 45 0F B6 C0 | 45 0F B6 C1 | 45 0F B6 C2 | 45 0F B6 C3 | 45 0F B6 C8 | 45 0F B6 C9 | 45 0F B6 CA | 45 0F B6 CB | 45 0F B6 D0 | 45 0F B6 D1 | 45 0F B6 D2 | 45 0F B6 D3 | 45 0F B6 D8 | 45 0F B6 D9 | 45 0F B6 DA | 45 0F B6 DB )
            [0-4]
            ( 41 89 D0 | 41 89 D1 | 41 89 D2 | 41 89 D3 | 89 D0 | 89 D1 | 89 D2 | 89 D3 )
            31 D2
            ( 66 41 F7 F0 | 66 41 F7 F1 | 66 41 F7 F2 | 66 41 F7 F3 )
            ( 41 0F AF D0 | 41 0F AF D1 | 41 0F AF D2 | 41 0F AF D3 | 44 0F AF C2 | 44 0F AF CA | 44 0F AF D2 | 44 0F AF DA | 0F AF D0 | 0F AF D1 | 0F AF D2 | 0F AF D3 | 0F AF C2 | 0F AF CA | 0F AF D2 | 0F AF DA )
            ( 31 ?? | 41 31 ?? | 44 31 ?? | 45 31 ?? )
            ( 31 ?? | 41 31 ?? | 44 31 ?? | 45 31 ?? )
            ( 44 88 04 ?F | 44 88 0C ?F | 44 88 14 ?F | 44 88 1C ?F | 44 88 04 ?7 | 44 88 0C ?7 | 44 88 14 ?7 | 44 88 1C ?7 | 88 04 ?F | 88 0C ?F | 88 14 ?F | 88 1C ?F | 88 04 ?7 | 88 0C ?7 | 88 14 ?7 | 88 1C ?7 | 44 88 04 3? | 44 88 0C 3? | 44 88 14 3? | 44 88 1C 3? | 88 04 3? | 88 0C 3? | 88 14 3? | 88 1C 3? )
        }

	condition:
		( uint16be( 0 ) == 0x4d5a or uint32be( 0 ) == 0x7f454c46 or uint32be( 0 ) == 0xcffaedfe ) and filesize < 5MB and all of them
}
/*
 * YARA Rule Set
 * Repository Name: ArtifactDrop
 * Repository: https://github.com/matthieugras/artifact-drop/
 * Retrieval Date: 2026-11-22
 * Git Commit: d2bcbe820bc134a4ed672ef6013498f856561af4
 * Number of Rules: 1
 * Skipped: 0 (age), 0 (quality), 0 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * NO LICENSE SET
 */
rule ARTIFACTDROP_Go_Reflectiveloader_Decryption_Loop : FILE
{
	meta:
		description = "Detects the specific Odd/Even decryption loop in a Go-based loader for Vidar"
		author = "Matthieu Gras"
		id = "0e9de6a0-ccfc-542d-b68d-470caa32eaec"
		date = "2025-12-17"
		modified = "2025-12-18"
		reference = "https://github.com/matthieugras/artifact-drop/"
		source_url = "https://github.com/matthieugras/artifact-drop//blob/d2bcbe820bc134a4ed672ef6013498f856561af4/yara/vidar_go_loader.yar#L1-L40"
		license_url = "N/A"
		logic_hash = "c112da99b39738244bc86801cf8a7c8ef5548a3a067db0a617a31c23f892dde3"
		score = 75
		quality = 80
		tags = "FILE"

	strings:
		$go_build_id = "Go build ID: \"" ascii
		$decrypt_loop = {
            31 C0          // xor eax, eax (i = 0)
            EB ??          // jmp short loc_check
            48 FF C0       // inc rax (i++)
            [0-8]          // Alignment NOPs

            // Loop Check: i < len
            48 39 F0       // cmp rax, rsi
            7D ??          // jge loc_exit

            0F B6 14 08    // movzx edx, byte ptr [rax+rcx] (load byte)

            // Parity Check: Is index Odd?
            0F BA E0 00    // bt eax, 0
            72 ??          // jb loc_odd

            // Arithmetic Operation (Even path)
            // Wildcarded constant to catch variants (e.g., add edx, -47)
            83 C2 ??

            88 14 01       // mov [rcx+rax], dl (store byte)
            EB ??          // jmp loc_inc
        }

	condition:
		uint16( 0 ) == 0x5A4D and $go_build_id and $decrypt_loop
}
/*
 * YARA Rule Set
 * Repository Name: Signature Base
 * Repository: https://github.com/Neo23x0/signature-base
 * Retrieval Date: 2026-11-22
 * Git Commit: 78d979eef87786a613659ee82e55abdd45572a78
 * Number of Rules: 1052
 * Skipped: 2897 (age), 188 (quality), 858 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * # Detection Rule License (DRL) 1.1

Permission is hereby granted, free of charge, to any person obtaining a copy 
of this rule set and associated documentation files (the "Rules"), to deal 
in the Rules without restriction, including without limitation the rights to 
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies 
of the Rules, and to permit persons to whom the Rules are furnished to do so, 
subject to the following conditions:

If you share the Rules (including in modified form), you must retain the 
following if it is supplied within the Rules:

1. identification of the authors(s) ("author" field) of the Rule and any 
   others designated to receive attribution, in any reasonable manner 
   requested by the Rule author (including by pseudonym if designated).

2. a URI or hyperlink to the Rule set or explicit Rule to the extent 
   reasonably practicable

3. indicate the Rules are licensed under this Detection Rule License, and 
   include the text of, or the URI or hyperlink to, this Detection Rule 
   License to the extent reasonably practicable

If you use the Rules (including in modified form) on data, messages based on 
matches with the Rules must retain the following if it is supplied within the 
Rules:

1. identification of the authors(s) ("author" field) of the Rule and any 
   others designated to receive attribution, in any reasonable manner 
   requested by the Rule author (including by pseudonym if designated).

THE RULES ARE PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
OUT OF OR IN CONNECTION WITH THE RULES OR THE USE OR OTHER DEALINGS IN THE 
RULES.

 */
rule SIGNATURE_BASE_MAL_Compromised_Cert_Ducktail_Stealer_Jun23 : FILE
{
	meta:
		description = "Detects binaries signed with compromised certificates used by DuckTail stealer - identified in June 2023"
		author = "dr4k0nia"
		id = "b491e1b6-42c4-58e9-8efa-19e697804f96"
		date = "2023-06-16"
		modified = "2023-08-12"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_ducktail_compromised_certs_jun23.yar#L2-L37"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "17c75f2d14af9f00822fc1dba00ccc9ec71fc50962e196d7e6f193f4b2ee0183"
		hash = "b3cfdb442772d07a7f037b0bb093ba315dfd1e79b0e292736c52097355495270"
		hash = "9afe013cae0167993a6a7ccd650eb1221a5ec163110565eb3a49a8b57949d4ee"
		logic_hash = "9b7916700359d662e99003727f5293f5a937254ff265c3bc8bb8763e196daa0e"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$sx1 = "AZM MARKETING COMPANY LIMITED" ascii fullword
		$sx2 = "CONG TY TNHH" ascii
		$sx3 = {43 C3 94 4E 47 20 54 59 20 54 4E 48 48 20}
		$sx4 = "CONG TY TRACH" ascii
		$se1 = {65 78 BE 85 2D 48 E3 3D 4E 48 B8 D4 73 F5 B7 60}
		$se2 = {1D 53 38 32 74 2B 58 37 87 C0 A2 53 32 F7 FB 06}
		$se3 = {00 BD 7B 85 B2 6A 69 C9 7D 6D 68 CC 95 67 34 C0 6B}
		$se4 = {06 5F 5C 57 0B D6 A7 98 92 FB B0 E6 34 61 3A 4D}
		$se5 = {41 55 3F 07 13 37 11 7A 99 B4 58 57}
		$se6 = {1E AA E4 CE E7 EE 89 FB 20 32 59 27 88 13 D8 53}
		$se7 = {56 DC DB 85 D4 89 F9 87 B2 D6 76 72}
		$se8 = {2D A4 50 57 C2 74 3C 1A 3C A4 93 7A}
		$se9 = {37 AE 95 F5 4C 8E 9B D0 B6 47 68 6A}
		$se10 = {3D C8 F5 3B 62 7A 34 07 AC 7E 01 00 13 87 A3 B3}
		$se11 = {01 C9 87 5A 5F A8 59 68 6D 34 17 C9}
		$se12 = {1B 35 19 E1 CD C2 6B 57 DA EE 06 C9}
		$se13 = {79 7D 0B 5E 22 AA 0F C7 A2 97 E6 48}
		$se14 = {57 9E 5C 89 B0 85 A7 96 B3 3C F3 19}

	condition:
		uint16( 0 ) == 0x5a4d and 1 of ( $sx* ) and 1 of ( $se* )
}
rule SIGNATURE_BASE_EXT_SUSP_OBFUSC_Macos_Roothelper_Obfuscated : FILE
{
	meta:
		description = "Yara for the public tool 'roothelper'. Used by XCSSET (https://gist.github.com/NullArray/f39b026b9e0d19f1e17390a244d679ec)"
		author = "im0prtp3"
		id = "7ff91c00-8178-525c-bb41-d09cf7cda588"
		date = "2021-06-07"
		modified = "2023-12-05"
		reference = "https://twitter.com/imp0rtp3/status/1401912205621202944"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_hktl_roothelper.yar#L2-L55"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "2121de0409f3f8e4c4e079944efb605776e0475cadc25607eb888cc6461ecaf3"
		score = 65
		quality = 83
		tags = "FILE"

	strings:
		$a1 = "E: neither argv[0] nor $_ works." fullword
		$b1 = "shll=%s\n" fullword
		$b2 = "argv[%d]=%.60s\n" fullword
		$b3 = "getenv(%s)=%s\n" fullword
		$b4 = "argc=%d\n" fullword
		$b5 = "argv=<null>\n" fullword
		$c1 = "%s%s%s: %s\n" fullword
		$c2 = "x%lx" fullword
		$c3 = "=%lu %d" fullword
		$c4 = "%lu %d%c" fullword
		$f1 = "rmarg"
		$f2 = "chkenv"
		$f3 = "untraceable"
		$f4 = "arc4"
		$f6 = "stte"
		$f7 = "with_file"
		$opcodes_1 = { 99 F7 7D ?? 4C 63 C2 42 0F B6 14 01 0F B6 3D }
		$opcodes_2 = { C6 [3] 00 00 00 C6 [3] 00 00 00 C6 [3] 00 00 00 8A 05 [2] 00 00 0F B6 [3] 00 00 89 CA }
		$opcodes_3 = { E8 [2] FF FF	8B 85 ?? F? FF FF 2B 85 ?? F? FF FF	83 ?? 01 89 85 ?? F? FF FF E9 ?? 00 00 00 }
		$weak_opcodes_1 = {48 8B 45 ?? 48 8B 00 48 3B 45 ??	0F 95 C1 88 4D ??}
		$weak_opcodes_2 = {	48 8B 45 ??	48 83 38 ??	0F 95 C1 88 4D ?? }

	condition:
		( uint32( 0 ) == 0xfeedface or uint32( 0 ) == 0xcefaedfe or uint32( 0 ) == 0xfeedfacf or uint32( 0 ) == 0xcffaedfe or uint32( 0 ) == 0xcafebabe or uint32( 0 ) == 0xbebafeca ) and ( $a1 or 3 of ( $b* ) or 5 of ( $f* ) or all of ( $opcodes* ) or ( 2 of ( $b* ) and ( 2 of ( $c* ) or 2 of ( $opcodes* ) ) ) or ( 3 of ( $c* ) and 4 of ( $f* ) ) or ( 2 of ( $opcodes* ) and ( all of ( $weak_opcodes* ) or 3 of ( $c* ) ) ) )
}
rule SIGNATURE_BASE_APT_Sidewinder_NET_Loader_Aug_2020_1 : FILE
{
	meta:
		description = "Detected the NET loader used by SideWinder group (August 2020)"
		author = "Arkbird_SOLG"
		id = "61d96e2a-3a43-586f-85bc-a2c53b1318e6"
		date = "2020-08-24"
		modified = "2023-12-05"
		reference = "https://twitter.com/ShadowChasing1/status/1297902086747598852"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sidewinder.yar#L4-L22"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "4a0947dd9148b3d5922651a6221afc510afcb0dfa69d08ee69429c4c75d4c8b4"
		logic_hash = "5ee7029143c589f26e6c325e163bfac85507c950f09778bd51ec2bdf4d4263fa"
		score = 75
		quality = 83
		tags = "FILE"

	strings:
		$a1 = "DUSER.dll" fullword wide
		$s1 = "UHJvZ3JhbQ==" fullword wide
		$s2 = "U3RhcnQ=" fullword wide
		$s3 = ".tmp           " fullword wide
		$s4 = "FileRipper" fullword ascii
		$s5 = "copytight @" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 4KB and $a1 and 3 of ( $s* )
}
rule SIGNATURE_BASE_APT_MAL_Sidewinder_Implant : FILE
{
	meta:
		description = "Detects SideWinder final payload"
		author = "AT&T Alien Labs"
		id = "3a420c9c-7821-5405-8d4d-6931d0f311ba"
		date = "2020-08-25"
		modified = "2023-12-05"
		reference = "https://cybersecurity.att.com/blogs/labs-research/a-global-perspective-of-the-sidewinder-apt"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sidewinder.yar#L24-L50"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "c568238dcf1e30d55a398579a4704ddb8196b685"
		logic_hash = "bfad86dbdc04463e7e4cc126fd05fc9107617a7ea1bd3f283c0e0170862bd59b"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$code = { 1B 30 05 00 C7 00 00 00 00 00 00 00 02 28 03 00
               00 06 7D 12 00 00 04 02 02 FE 06 23 00 00 06 73
               5B 00 00 0A 14 20 88 13 00 00 15 73 5C 00 00 0A
               7D 13 00 00 04 02 02 FE 06 24 00 00 06 73 5B 00
               00 0A 14 20 88 13 00 00 15 73 5C 00 00 0A 7D 15
               00 00 04 02 7B 12 00 00 04 6F 0E 00 00 06 2C 1D
               02 28 1F 00 00 06 02 7B 12 00 00 04 16 6F 0F 00
               00 06 02 7B 12 00 00 04 6F 06 00 00 06 02 7B 12
               00 00 04 6F 10 00 00 06 2C 23 02 28 20 00 00 06
               02 28 21 00 00 06 02 7B 12 00 00 04 16 }
		$strings = { 
         2E 00 73 00 69 00 66 00 00 09 2E 00 66 00 6C 00
         63 00 00 1B 73 00 65 00 6C 00 65 00 63 00 74 00
         65 00 64 00 46 00 69 00 6C 00 65 00 73
      }

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule SIGNATURE_BASE_SUSP_Doc_Windowsinstaller_Call_Feb22_1 : FILE
{
	meta:
		description = "Triggers on docfiles executing windows installer. Used for deploying ThinBasic scripts."
		author = "Nils Kuhnert"
		id = "8f2e8f91-74e0-5574-9c0a-1479d6114212"
		date = "2022-02-26"
		modified = "2023-12-05"
		reference = "https://twitter.com/threatinsight/status/1497355737844133895"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_maldoc.yar#L1-L16"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "279182487ab7d35264adfbd0d122ee7634cd92ae1711de78ec7f20928df34f49"
		score = 65
		quality = 85
		tags = "FILE"
		tlp = "white"

	strings:
		$ = "WindowsInstaller.Installer$"
		$ = "CreateObject"
		$ = "InstallProduct"

	condition:
		uint32be( 0 ) == 0xd0cf11e0 and all of them
}
rule SIGNATURE_BASE_EXPL_Manageengine_CVE_2022_47966_Jan23_1
{
	meta:
		description = "Detects indicators of exploitation of ManageEngine vulnerability as described by Horizon3"
		author = "Florian Roth (Nextron Systems)"
		id = "07535b9c-8611-5a46-bcd7-f94070de2aea"
		date = "2023-01-13"
		modified = "2023-12-05"
		reference = "https://www.horizon3.ai/manageengine-cve-2022-47966-iocs/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_manageengine_jan23.yar#L2-L14"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a62064e4f12632ba6c14cbbd9369ee919536334f19021a177c126b5dff7e568c"
		score = 75
		quality = 85
		tags = ""

	strings:
		$ = "]: com.adventnet.authentication.saml.SamlException: Signature validation failed. SAML Response rejected|"

	condition:
		1 of them
}
rule SIGNATURE_BASE_MAL_APT_NK_JS_Contagiousinterview_TCP_Backdoor_Nov26 : FILE
{
	meta:
		description = "Detects the Node.js backdoor of the Contagious Interview campaign (git hook lure) that talks to its C2 over plain TCP with newline-delimited JSON. Works on the javascript-obfuscator output as distributed: it relies on top-level names that the obfuscator keeps (renameGlobals is off by default) and on key strings, which end up either as literals or in the base64 encoded string array"
		author = "n4uu"
		id = "fdd732d7-e852-4f09-b57c-f1893cc1ec64"
		date = "2026-11-05"
		modified = "2026-11-06"
		reference = "https://n4uu.github.io/2026/raw-tcp-backdoor-cleverstack/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_contagious_interview_nov26.yar#L1-L42"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "281d4d60fc99cf7f54819defb1c7c14b9202d46890936c4c6b9ebe3ddc75dd2f"
		hash = "6db4c3d2ab56227d36eff59d1dc9e13eadf9959996fab1e0b04591cc5e637d04"
		logic_hash = "63c4bceb7d5b6ef3bebcadaf4bd5f185a27c0d39823c17a423b3646438273215"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$r1 = "require(" ascii
		$g1 = "GIT_CHECKER_MARKER" ascii fullword
		$g2 = "LOCK_UPDATE_INTERVAL" ascii fullword
		$g3 = "getHandleParam" ascii fullword
		$g4 = "createSocketConnection" ascii fullword
		$g5 = "lockUpdateTimer" ascii fullword
		$g6 = "git_content" ascii fullword
		$g7 = "SERVER_API_URL" ascii fullword
		$g8 = "attemptReconnect" ascii fullword
		$s1 = "vscode-ext.lock" ascii
		$s2 = ".git-checker" ascii
		$s3 = "start /b cmd /c \"cd /d " ascii
		$s4 = "ss_exec " ascii
		$sb1 = "vscode-ext.lock" base64
		$sb2 = ".git-checker" base64
		$sb3 = "start /b cmd /c \"cd /d " base64
		$sb4 = "ss_exec " base64

	condition:
		filesize < 1MB and $r1 and ( 6 of ( $g* ) or ( 3 of ( $g* ) and 2 of ( $s* ) ) or 3 of ( $s* ) )
}

rule SIGNATURE_BASE_APT_Turlamosquito_MAL_Oct22_1 : FILE
{
	meta:
		description = "Detects Turla Mosquito malware"
		author = "Florian Roth (Nextron Systems)"
		id = "f5ad0c0f-81ca-5157-aefb-ead049ada30d"
		date = "2022-10-25"
		modified = "2023-12-05"
		reference = "https://www.welivesecurity.com/wp-content/uploads/2018/01/ESET_Turla_Mosquito.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_turla_mosquito.yar#L129-L156"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "6b9e48e3f4873cfb95639d9944fe60e3b056daaa2ea914add14c982e3e11128b"
		hash = "b868b674476418bbdffbe0f3d617d1cce4c2b9dae0eaf3414e538376523e8405"
		hash = "e7fd14ca45818044690ca67f201cc8cfb916ccc941a105927fc4c932c72b425d"
		logic_hash = "fbaca774d6398aac7c171a5d87aa456a1921c1b80449d06f392b088db33ee845"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Logger32.dll" ascii fullword
		$s4 = " executing %u command on drive %martCommand : CWin32ApiErrorExce" wide
		$s5 = "Unsupported drive!!!" ascii fullword
		$s7 = "D:\\Build_SVN\\PC_MAGICIAN_4." ascii fullword
		$op1 = { 40 cc 8b 8b 06 cc 55 00 70 8b 10 10 33 51 04 46 04 64 }
		$op2 = { c3 10 e8 50 04 00 cc ff 8d 00 69 8d 75 ff 68 ec 6a 4d }
		$op3 = { e8 64 a1 6e 00 64 a1 c2 04 08 75 40 73 1d 8b ff cc 10 89 cc 8b c3 cc af }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 2000KB and ( pe.imphash ( ) == "073235ae6dfbb1bf5db68a039a7b7726" or all of them )
}
rule SIGNATURE_BASE_APT_SH_Codecov_Hack_Apr21_1 : FILE
{
	meta:
		description = "Detects manipulated Codecov bash uploader tool that has been manipulated by an unknown actor during March / April 2021"
		author = "Florian Roth (Nextron Systems)"
		id = "b5fb74c4-073e-53af-a207-1672e63c9a64"
		date = "2021-04-16"
		modified = "2023-12-05"
		reference = "https://about.codecov.io/security-update/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_codecov_hack.yar#L2-L17"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1aa7723982a1b675ba6694f1af0eb28e5926b974874580bd727cf33a3f8d893a"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "Global report uploading tool for Codecov"
		$s1 = "curl -sm 0.5 -d"

	condition:
		uint16( 0 ) == 0x2123 and filesize < 70KB and all of them
}
rule SIGNATURE_BASE_Cobaltstrike_Sleep_Decoder_Indicator
{
	meta:
		description = "Detects CobaltStrike sleep_mask decoder"
		author = "yara@s3c.za.net"
		id = "d5b53d68-55f9-5837-9b0c-e7be2f3bd072"
		date = "2021-07-19"
		modified = "2023-12-05"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cobaltstrike_evasive.yar#L16-L26"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f3243c326df18edbd15c2d9120379588e61709efb9295b9584c0565c04ee38a5"
		score = 75
		quality = 85
		tags = ""

	strings:
		$sleep_decoder = { 48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 48 83 EC 20 4C 8B 51 08 41 8B F0 48 8B EA 48 8B D9 45 8B 0A 45 8B 5A 04 4D 8D 52 08 45 85 C9 }

	condition:
		$sleep_decoder
}
rule SIGNATURE_BASE_Cobaltstrike_MZ_Launcher
{
	meta:
		description = "Detects CobaltStrike MZ header ReflectiveLoader launcher"
		author = "yara@s3c.za.net"
		id = "461a4741-11c5-53d9-b8e1-52d64cfe755b"
		date = "2021-07-08"
		modified = "2023-12-05"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cobaltstrike_evasive.yar#L297-L307"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "aa188546db138dffdcdbf6538367b5d5bc37638a2784b24b7fcd913c15e56072"
		score = 75
		quality = 85
		tags = ""

	strings:
		$mz_launcher = { 4D 5A 41 52 55 48 89 E5 48 81 EC 20 00 00 00 48 8D 1D }

	condition:
		$mz_launcher
}
rule SIGNATURE_BASE_MAL_WIN_Akira_Apr25 : FILE
{
	meta:
		description = "This Yara rule from ISH Tecnologia's Heimdall Security Research Team detects key components of Akira Ransomware"
		author = "0x0d4y-Icaro Cesar"
		id = "76722cb6-70be-465f-9ef1-afd78f694289"
		date = "2025-04-11"
		modified = "2026-05-15"
		reference = "https://ish.com.br/wp-content/uploads/2025/04/A-Anatomia-do-Ransomware-Akira-e-sua-expansao-multiplataforma.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_win_akira_apr25.yar#L1-L28"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "205589629ead5d3c1d9e914b49c08589"
		logic_hash = "112f844dff4c48d861f86736503da51e8fbc58805f463df1f9358781034f2e24"
		score = 90
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"
		rule_matching_tlp = "TLP:WHITE"
		rule_sharing_tlp = "TLP:WHITE"
		malpedia_family = "win.akira"

	strings:
		$code_custom_algorithm = { 44 8B CF 90 42 0F B6 4C 0D ?? 83 E9 4E 44 8D 04 89 45 03 C0 B8 09 04 02 81 41 F7 E8 41 03 D0 C1 FA 06 8B C2 C1 E8 1F 03 D0 6B C2 7F 44 2B C0 41 83 C0 7F B8 09 04 02 81 41 F7 E8 41 03 D0 C1 FA 06 8B C2 C1 E8 1F 03 D0 6B C2 7F 44 2B C0 46 88 44 0D ?? 49 FF C1 }
		$code_aes_key_expansion = { 41 8D 41 FF 33 D2 8B 0C ?? 41 8B C1 41 F7 F2 85 D2 75 ?? 44 8B C1 0F B6 C1 0F B6 0C ?? 41 8B C0 48 C1 E8 ?? C1 E1 ?? 0F B6 04 ?? 0B C8 41 8B C0 48 C1 E8 ?? C1 E1 ?? 0F B6 D0 49 C1 E8 ?? 0F B6 04 ?? 0B C8 41 0F B6 C0 C1 E1 ?? 0F B6 14 ?? 0F B6 45 00 0B CA 33 C8 48 FF C5 }
		$akira_str_I = "akira" ascii
		$akira_str_II = "onion" ascii
		$akira_str_III = "powershell" ascii
		$akira_str_IV = "akira_readme.txt" ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of ( $code_* ) and all of ( $akira_str_* )
}
rule SIGNATURE_BASE_SUSP_Nullsoftinst_Combo_Oct20_1 : FILE
{
	meta:
		description = "Detects suspicious NullSoft Installer combination with common Copyright strings"
		author = "Florian Roth (Nextron Systems)"
		id = "380f30a6-df6b-50c6-bb2d-b8785564bbac"
		date = "2020-10-06"
		modified = "2023-12-05"
		reference = "https://twitter.com/malwrhunterteam/status/1313023627177193472"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_anomalies_keyword_combos.yar#L2-L33"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "686b5240e5e503528cc5ac8d764883413a260716dd290f114a60af873ee6a65f"
		hash = "93951379e57e4f159bb62fd7dd563d1ac2f3f23c80ba89f2da2e395b8a647dcf"
		hash = "a9ca1d6a981ccc8d8b144f337c259891a67eb6b85ee41b03699baacf4aae9a78"
		logic_hash = "8aef24295281da5ffa1c6f865eaa6cc8d60ea1df670058220bdb97651b6114cd"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "NullsoftInst" ascii
		$b1 = "Microsoft Corporation" wide fullword
		$b2 = "Apache Software Foundation" ascii wide fullword
		$b3 = "Simon Tatham" wide fullword
		$fp1 = "nsisinstall" fullword ascii
		$fp2 = "\\REGISTRY\\MACHINE\\Software\\" wide
		$fp3 = "Apache Tomcat" wide fullword
		$fp4 = "Bot Framework Emulator" wide fullword
		$fp5 = "Firefox Helper" wide fullword
		$fp6 = "Paint.NET Setup" wide fullword
		$fp7 = "Microsoft .NET Services Installation Utility" wide fullword
		$fp8 = "License: MPL 2" wide

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 2000KB and $a1 and 1 of ( $b* ) and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_MAL_APT_NK_Andariel_Scheduledtask_Loader : FILE
{
	meta:
		description = "Detects a scheduled task loader used by Andariel"
		author = "CISA.gov"
		id = "0c32758b-480c-5784-b28f-cee85d038850"
		date = "2024-07-25"
		modified = "2026-01-29"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L3-L18"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "2d32ee777cb40c6fa58787e92c0de074ea5b81d629a17ccb4f9432d62436f03c"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$obfuscation1 = { B8 02 00 00 00 48 6B C0 00 B9 CD FF 00 00 66 89 8C 04 60 01 00 00 B8 02 00 00 00 48 6B C0 01 B9 CC FF 00 00 66 89 8C 04 60 01 00 00 B8 02 00 00 00 48 6B C0 02 B9 8D FF 00 00 66 89 8C 04 60 01 00 00 B8 02 00 00 00 48 6B C0 03 B9 9A FF 00 00 66 89 8C 04 60 01 00 00 B8 02 00 00 00 48 6B C0 04 B9 8C FF 00 00 66 89 8C 04 60 01 00 00 B8 02 00 00 00 48 6B C0 05 B9 8A FF 00 00 66 89 8C 04 60 01 00 00 B8 02 00 00 00 48 6B C0 06 33 C9 66 89 8C 04 60 01 00 00 }
		$obfuscation2 = { 48 6B C0 02 C6 44 04 20 BA B8 01 00 00 00 48 6B C0 03 C6 44 04 20 9A B8 01 00 00 00 48 6B C0 04 C6 44 04 20 8B B8 01 00 00 00 48 6B C0 05 C6 44 04 20 8A B8 01 00 00 00 48 6B C0 06 C6 44 04 20 9C B8 01 00 00 00 }
		$obfuscation3 = { 48 6B C0 00 C6 44 04 20 A8 B8 01 00 00 00 48 6B C0 01 C6 44 04 20 9A B8 01 00 00 00 48 6B C0 02 C6 44 04 20 93 B8 01 00 00 00 48 6B C0 03 C6 44 04 20 96 B8 01 00 00 00 48 6B C0 04 C6 44 04 20 B9 B8 01 00 00 00 48 6B C0 05 C6 44 04 20 9A B8 01 00 00 00 48 6B C0 06 C6 44 04 20 8B B8 01 00 00 00 48 6B C0 07 C6 44 04 20 9E B8 01 00 00 00 48 6B C0 08 C6 44 04 20 9A B8 01 00 00 00 48 6B C0 09 C6 44 04 20 8D B8 01 00 00 00 48 6B C0 0A C6 44 04 20 BC B8 01 00 00 00 }

	condition:
		uint16( 0 ) == 0x5A4D and $obfuscation1 and $obfuscation2 and $obfuscation3
}
rule SIGNATURE_BASE_MAL_APT_NK_Andariel_Kaosrat_Yamabot
{
	meta:
		description = "Detects the KaosRAT variant"
		author = "CISA.gov"
		id = "cdde69cd-1b38-52f5-8552-cef2cf4ad69c"
		date = "2024-07-25"
		modified = "2026-01-29"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L20-L42"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "92182aac2e56041292102b0486b7de1ee6eb3d54a9fc6786c567acd92073cd84"
		score = 70
		quality = 85
		tags = ""

	strings:
		$str1 = "/kaos/"
		$str2 = "Abstand ["
		$str3 = "] anwenden"
		$str4 = "cmVjYXB0Y2hh"
		$str5 = "/bin/sh"
		$str6 = "utilities.CIpaddress"
		$str7 = "engine.NewEgg"
		$str8 = "%s%04x%s%s%s"
		$str9 = "Y2FwdGNoYV9zZXNzaW9u"
		$str10 = "utilities.EierKochen"
		$str11 = "kandidatKaufhaus"

	condition:
		3 of them
}
rule SIGNATURE_BASE_MAL_APT_NK_Trifaux_Easyrat_JUPITER : FILE
{
	meta:
		description = "Detects a variant of the EasyRAT malware family"
		author = "CISA.gov"
		id = "8bd72287-59da-53cf-9015-66149303e59f"
		date = "2024-07-25"
		modified = "2026-01-29"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L44-L59"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6108035dbebd34fe994fc1f8b4123321321f6ed5c022be6e84a88f905ea6fb73"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$InitOnce = "InitOnceExecuteOnce"
		$BREAK = { 0D 00 0A 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 2D 00 0D 00 0A }
		$Bytes = "4C,$00,$00,$00,$01,$14,$02,$00,$00,$00,$00,$00,$C0,$00,$00,$00,$00,$00,$00," wide

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule SIGNATURE_BASE_MAL_APT_NK_Andariel_Cutiedrop_Magicrat : FILE
{
	meta:
		description = "Detects the MagicRAT variant used by Andariel"
		author = "CISA.gov (modified by Florian Roth, Nextron Systems)"
		id = "104244de-83fb-5112-a2b6-e20d38a6ced6"
		date = "2024-07-25"
		modified = "2026-01-29"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L61-L85"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f289bbd71bdeaf2c42063642454679ec26de5ed24c020af40db694a0ced54884"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$config_os_w = "os/windows" ascii
		$config_os_l = "os/linux" ascii
		$config_os_m = "os/mac" ascii
		$config_comp_msft = "company/microsoft" ascii
		$config_comp_orcl = "company/oracle" ascii
		$POST_field_1 = "session=" ascii
		$POST_field_2 = "type=" ascii
		$command_misspelled = "renmae" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 7 of them
}
rule SIGNATURE_BASE_MAL_APT_NK_Andariel_HHSD_Filetransfertool : FILE
{
	meta:
		description = "Detects a variant of the HHSD File Transfer Tool"
		author = "CISA.gov"
		id = "46b6dbaf-1272-5bbd-a586-5e48ba6c5022"
		date = "2024-07-25"
		modified = "2025-07-09"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L87-L125"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "665c1b27d64d5377be98aa4e629b077e56f3a44273d98653a338439b3dc05b65"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$handshake = { 30 ?? ?? 81 7? ?? 22 C0 78 00 4? 88 }
		$err_xor_str = { 14 C7 [2] 14 00 41 00 C7 [2] 7A 00 7F 00 C7 [2] 7B 00 63 00 C7 [2] 7A 00 34 00 }
		$hash_call_loadlib = { B? 8D 10 B7 F8 E8 }
		$hash_call_unk = { B? 91 B8 F6 88 E8 }

	condition:
		uint16( 0 ) == 0x5a4d and 1 of ( $handshake , $err_xor_str ) and 1 of ( $hash_call_* ) or 2 of ( $handshake , $err_xor_str )
}
rule SIGNATURE_BASE_MAL_APT_NK_Andariel_Atharvan_3RAT : FILE
{
	meta:
		description = "Detects a variant of the Atharvan 3RAT malware family"
		author = "CISA.gov"
		id = "9ff6998a-a2dd-5671-bd3f-ee69561f71ef"
		date = "2024-07-25"
		modified = "2026-01-29"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L127-L141"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "741318234e245a35accc0b102a7891559ce5ef868ccdc3e6e4c8e59d8dea8b24"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$3RAT = "D:\\rang\\TOOL\\3RAT"
		$atharvan = "Atharvan_dll.pdb"

	condition:
		uint16( 0 ) == 0x5a4d and 1 of them
}
rule SIGNATURE_BASE_MAL_APT_NK_Andariel_Lilithrat_Variant : FILE
{
	meta:
		description = "Detects a variant of the Lilith RAT malware family"
		author = "CISA.gov (modified by Florian Roth, Nextron Systems)"
		id = "916a289b-db7b-5f09-9d3e-589c3f09101d"
		date = "2024-07-25"
		modified = "2024-07-26"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L143-L178"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3ce68908468ff85683b081842fa4faa579fbf6f7dc1a7fab5dcf7eac63d90aea"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$lilith_1 = "Initiate a CMD session first." ascii
		$lilith_2 = "CMD is not open" ascii
		$lilith_3 = "Couldn't write command" ascii
		$lilith_4 = "Couldn't write to CMD: CMD not open" ascii
		$unique_1 = "Upload Error!" ascii
		$unique_2 = "ERROR: Downloading is already running!" ascii
		$unique_3 = "ERROR: Unable to open file:" ascii
		$unique_4 = "General error" ascii
		$unique_5 = "CMD error" ascii
		$unique_6 = "killing self" ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 150KB and ( all of ( $lilith_* ) or 4 of ( $unique_* ) or 1 of ( $lilith_4 , $unique_2 ) )
}
rule SIGNATURE_BASE_MAL_APT_NK_Andariel_Sockstroy_Strings_Opcodes : FILE
{
	meta:
		description = "Detects a variant of the SocksTroy malware family"
		author = "CISA.gov"
		id = "9e7fb6ba-771e-5cae-a0d5-c0b95ee6d4e9"
		date = "2024-07-25"
		modified = "2026-01-29"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L180-L199"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6ab31b285d0dba1745a2d8b172bd02931c6138e2b8e541203b88f111d179549b"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$strHost = "-host" wide
		$strAuth = "-auth" wide
		$SocksTroy = "SocksTroy"
		$cOpCodeCheck = { 81 E? A0 00 00 00 0F 84 ?? ?? ?? ?? 83 E? 03 74 ?? 83 E? 02 74 ?? 83 F? 0B }

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $str* ) and all of ( $c* ) or all of ( $Socks* ) )
}
rule SIGNATURE_BASE_MAL_APT_NK_Andariel_Agni : FILE
{
	meta:
		description = "Detects samples of the Agni malware family"
		author = "CISA.gov"
		id = "ffe3f427-c10a-5ad4-ab29-c0d9b576c30f"
		date = "2024-07-25"
		modified = "2026-01-29"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L201-L216"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "302899b65e5a3a6beabbb46e80e3f0ff246c209206cc3a7f871011d68871d0b9"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$xor = { 34 ?? 88 01 48 8D 49 01 0F B6 01 84 C0 75 F1 }
		$stackstrings = { C7 44 24 [5-10] C7 44 24 [5] C7 44 24 [5-10] C7 44 24 [5-10] C7 44 24 }

	condition:
		uint16( 0 ) == 0x5a4d and #xor > 100 and #stackstrings > 5
}
rule SIGNATURE_BASE_MAL_APT_NK_Andariel_Golang_Validalpha_Handshake
{
	meta:
		description = "Detects a variant of the GoLang Validalpha malware"
		author = "CISA.gov"
		id = "51dafa43-9da0-569a-9123-7e9800284046"
		date = "2024-07-25"
		modified = "2026-01-29"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L218-L230"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1978210d07d3298c0051c9faca16685636e3fb45131b4c2fcb7053a0b3ef84d1"
		score = 75
		quality = 85
		tags = ""

	strings:
		$ = { 66 C7 00 AB CD C6 40 02 EF ?? 03 00 00 00 48 89 C1 ?? 03 00 00 00 }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_APT_NK_Andariel_Golang_Validalpha_Tasks
{
	meta:
		description = "Detects a variant of the GoLang Validalpha malware"
		author = "CISA.gov"
		id = "caa67a79-3ea6-5910-971c-f311722570ff"
		date = "2024-07-25"
		modified = "2026-01-29"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L232-L247"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "0d3fb944888b289d345ffc8dfcc988abd04b8cabd1729a66e8236f95ee6147ee"
		score = 80
		quality = 85
		tags = ""

	strings:
		$ = "main.ScreenMonitThread"
		$ = "main.CmdShell"
		$ = "main.GetAllFoldersAndFiles"
		$ = "main.SelfDelete"

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_APT_NK_Andariel_Golang_Validalpha_Blackstring : FILE
{
	meta:
		description = "Detects a variant of the GoLang Validalpha malware based on a file path found in the samples"
		author = "CISA.gov"
		id = "36f46a1d-69b6-5c99-9a54-6a14d62d2721"
		date = "2024-07-25"
		modified = "2026-01-29"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L249-L261"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "07ea38890e99dd53437a23b7c4002851604b69a83bd7fb8971609226249e5954"
		score = 90
		quality = 85
		tags = "FILE"

	strings:
		$ = "I:/01___Tools/02__RAT/Black"

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule SIGNATURE_BASE_MAL_APT_NK_Andariel_ELF_Backdoor_Fipps : FILE
{
	meta:
		description = "Detects a Linux backdoor named Fipps used by Andariel"
		author = "CISA.gov"
		id = "040bca78-8b7e-5397-8a2b-1ddeed59eea3"
		date = "2024-07-25"
		modified = "2026-01-29"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L291-L307"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3b57eb6c6b89e93863b9600c4a1384f3e064f236e827ef9ffc37b1e5dcff7d24"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$a = "found mac address"
		$b = "RecvThread"
		$c = "OpenSSL-1.0.0-fipps"
		$d = "Disconnected!"

	condition:
		uint32( 0 ) == 0x464c457f and all of them
}
rule SIGNATURE_BASE_MAL_APT_NK_Andariel_Grease2 : FILE
{
	meta:
		description = "Detects the Grease2 malware family used by Andariel"
		author = "CISA.gov (modified by Florian Roth, Nextron Systems)"
		id = "4defbe08-b3c6-5ab9-9a57-cec57ff42d9a"
		date = "2024-07-25"
		modified = "2024-07-26"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L330-L351"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "138fc915206e0c2834090ebc0a808913488121d51c17de3dbfadcb4099fbfa2f"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$str_rdpconf = "emp\\RDPConf.exe"
		$str_rdpwinst = "emp\\RDPWInst.exe"
		$str_net_user = "net user"
		$str_admins_add = "net localgroup administrators"

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule SIGNATURE_BASE_MAL_APT_NK_Andariel_Nopineapple_Dtrack_Unpacked : FILE
{
	meta:
		description = "Detects the Dtrack variant used by Andariel"
		author = "CISA.gov"
		id = "6ccaf24b-c110-5788-a792-fa7f39fb18f7"
		date = "2024-07-25"
		modified = "2026-01-29"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L353-L368"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "cf5f92a66ba3ff4db61102dcc50b781e8dd14ca7cb1eb70dae8eba2ed0910b66"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$str_nopineapple = "< No Pineapple! >"
		$str_qt_library = "Qt 5.12.10"
		$str_xor = { 8B 10 83 F6 ?? 83 FA 01 77 }

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule SIGNATURE_BASE_MAL_APT_NK_Andariel_Dtrack_Unpacked : FILE
{
	meta:
		description = "Detects DTrack variant used by Andariel"
		author = "CISA.gov (modified by Florian Roth, Nextron Systems)"
		id = "0c161275-2b2e-51a4-9e08-c118fb4c8671"
		date = "2024-07-25"
		modified = "2024-07-26"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L370-L393"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d8de583fc0de01e6784305d28dbf7cea859a24cf4df1dc59356601bc830e4770"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x_str_cmd_4 = "/c systeminfo > \"%s\" & tasklist > \"%s\" & netstat -naop tcp > \"%s\"" wide
		$x_str_cmd_2 = "/c ping -n 3 127.0.01 > NUL % echo EEE > \"%s\"" wide
		$str_mutex = "MTX_Global"
		$str_cmd_1 = "/c net use \\\\" wide
		$str_cmd_3 = "/c move /y %s \\\\" wide

	condition:
		uint16( 0 ) == 0x5A4D and ( 1 of ( $x* ) or 3 of them )
}
rule SIGNATURE_BASE_MAL_APT_NK_Andariel_Tigerrat_Crowdsourced_Rule : FILE
{
	meta:
		description = "Detects the Tiger RAT variant used by Andariel"
		author = "CISA.gov (modified by Florian Roth, Nextron Systems)"
		id = "6be65222-7d3c-5ff5-a9c7-d91dcf1deaa6"
		date = "2024-07-25"
		modified = "2024-07-26"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L395-L424"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "5d203d8c7e624796571f4597f70be0b8303f21c096640f25018cad29d4abc05b"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$m1 = ".?AVModuleKeyLogger@@" fullword ascii
		$m2 = ".?AVModulePortForwarder@@" fullword ascii
		$m3 = ".?AVModuleScreenCapture@@" fullword ascii
		$m4 = ".?AVModuleShell@@" fullword ascii
		$s1 = "\\x9891-009942-xnopcopie.dat" fullword wide
		$s2 = "(%02d : %02d-%02d %02d:%02d:%02d)--- %s[Clipboard]" fullword ascii
		$s3 = "[%02d : %02d-%02d %02d:%02d:%02d]--- %s[Title]" fullword ascii
		$s4 = "del \"%s\"%s \"%s\" goto " ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or ( all of ( $m* ) and 1 of ( $s* ) ) or ( 2 of ( $m* ) and 2 of ( $s* ) ) )
}
rule SIGNATURE_BASE_MAL_APT_NK_WIN_Tiger_RAT_Auto : FILE
{
	meta:
		description = "Detects the Tiger RAT variant used by Andariel"
		author = "CISA.gov"
		id = "4579af62-52be-5f5f-a577-16ec50297c05"
		date = "2024-07-25"
		modified = "2026-01-29"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L426-L565"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1deef66efb44c0d17f33508a8b6f0d6253f0308f309e81657f78eb0f87121bf5"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$sequence_0 = { 33 c0 89 44 24 38 89 44 24 30 44 8b cf 45 33 c0 }
		$sequence_1 = { 41 b9 01 00 00 00 48 8b d6 48 8b cb e8 ?? ?? ?? ?? }
		$sequence_2 = { 48 81 ec 90 05 00 00 8b 01 89 85 c8 04 00 00 8b 41 04 }
		$sequence_3 = { 48 8b 01 ff 10 48 8b 4f 08 4c 8d 4c 24 30 }
		$sequence_4 = { 48 8b 01 ff 10 48 8b 4e 18 48 8b 01 }
		$sequence_5 = { 48 81 ec a0 00 00 00 33 c0 48 8b d9 48 8d 4c 24 32 }
		$sequence_6 = { 48 8b 01 eb 03 48 8b c1 0f b6 00 }
		$sequence_7 = { 48 8b 01 8b 10 89 51 24 44 8b 41 24 45 85 c0 }
		$sequence_8 = { 4c 8d 0d 31 eb 00 00 c1 e9 18 c1 e8 08 41 bf 00 00 00 80 }
		$sequence_9 = { 48 8b d8 48 85 c0 75 2d ff 15 ?? ?? ?? ?? 83 f8 57 0f 85 e0 01 00 00 48 8d 0d a0 bd 00 00 }
		$sequence_10 = { 75 d4 48 8d 1d 7f 6c 01 00 48 8b 4b f8 48 85 c9 74 0b }
		$sequence_11 = { 0f 85 d9 00 00 00 48 8d 15 d0 c9 00 00 41 b8 10 20 01 00 48 8b cd e8 ?? ?? ?? ?? eb 6b b9 f4 ff ff ff }
		$sequence_12 = { 48 89 0d ?? ?? ?? ?? 48 89 05 ?? ?? ?? ?? 48 8d 05 ae 61 00 00 48 89 05 ?? ?? ?? ?? 48 8d 05 a0 55 00 00 48 89 05 ?? ?? ?? ?? }
		$sequence_13 = { 8b cf e8 ?? ?? ?? ?? 48 8b 7c 24 48 85 c0 0f 84 40 03 00 00 48 8d 05 60 25 01 00 }
		$sequence_14 = { ff 15 ?? ?? ?? ?? 8b 05 ?? ?? ?? ?? 23 05 ?? ?? ?? ?? ba 02 00 00 00 33 c9 89 05 ?? ?? ?? ?? 8b 05 ?? ?? ?? ?? }
		$sequence_15 = { 48 83 ec 30 49 8b d8 e8 ?? ?? ?? ?? 48 8b c8 48 85 c0 }

	condition:
		filesize < 600KB and 7 of them
}
rule SIGNATURE_BASE_MAL_APT_NK_WIN_Dtrack_Auto : FILE
{
	meta:
		description = "Detects DTrack variant used by Andariel"
		author = "CISA.gov"
		id = "1b40c685-beba-50fa-b484-c1526577cb23"
		date = "2024-07-25"
		modified = "2026-01-29"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa24-207a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_andariel_jul24.yar#L567-L706"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "2bd68ee6e5f35a9b80c07120beba3fe1f3ba9a9137ee15bb04bb2740381a9a44"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$sequence_0 = { 52 8b 45 08 50 e8 ?? ?? ?? ?? 83 c4 14 8b 4d 10 51 }
		$sequence_1 = { 3a 41 01 75 23 83 85 4c f6 ff ff 02 83 85 50 f6 ff ff 02 80 bd 4a f6 ff ff 00 75 ae c7 85 44 f6 ff ff 00 00 00 00 }
		$sequence_2 = { 50 ff 15 ?? ?? ?? ?? a3 ?? ?? ?? ?? 68 ?? ?? ?? ?? e8 ?? ?? ?? ?? 83 c4 04 50 }
		$sequence_3 = { 8d 8d d4 fa ff ff 51 e8 ?? ?? ?? ?? 83 c4 08 8b 15 ?? ?? ?? ?? }
		$sequence_4 = { 88 55 f5 6a 5c 8b 45 0c 50 e8 ?? ?? ?? ?? }
		$sequence_5 = { 51 e8 ?? ?? ?? ?? 83 c4 10 8b 55 8c 52 }
		$sequence_6 = { 8b 4d 0c 51 68 ?? ?? ?? ?? 8d 95 60 ea ff ff 52 e8 ?? ?? ?? ?? }
		$sequence_7 = { 83 c0 01 89 45 f4 83 7d f4 20 7d 2c 8b 4d f8 }
		$sequence_8 = { 83 c0 01 89 85 6c f6 ff ff 8b 8d 70 f6 ff ff 8a 11 }
		$sequence_9 = { 03 55 f0 0f b6 02 0f b6 4d f7 33 c1 0f b6 55 fc 33 c2 }
		$sequence_10 = { d1 e9 89 4d f8 8b 55 18 89 55 fc c7 45 f0 00 00 00 00 }
		$sequence_11 = { 8b 4d f0 3b 4d 10 0f 8d 90 00 00 00 8b 55 08 03 55 f0 0f b6 02 }
		$sequence_12 = { 89 4d 14 8b 45 f8 c1 e0 18 8b 4d fc c1 e9 08 0b c1 }
		$sequence_13 = { 0b c1 89 45 18 8b 55 14 89 55 f8 }
		$sequence_14 = { 8b 55 14 89 55 f8 8b 45 18 89 45 fc e9 ?? ?? ?? ?? 8b e5 }

	condition:
		filesize < 1700KB and 7 of them
}
rule SIGNATURE_BASE_MAL_WIPER_Bibi_Oct23 : FILE
{
	meta:
		description = "Detects BiBi wiper samples for Windows and Linux"
		author = "Florian Roth"
		id = "e1ea8016-e074-5208-8c98-54922bbcc407"
		date = "2023-11-01"
		modified = "2023-12-05"
		reference = "https://x.com/ESETresearch/status/1719437301900595444?s=20"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_bibi_wiper_oct23.yar#L24-L47"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "23bae09b5699c2d5c4cb1b8aa908a3af898b00f88f06e021edcb16d7d558efad"
		hash = "40417e937cd244b2f928150cae6fa0eff5551fdb401ea072f6ecdda67a747e17"
		logic_hash = "c22dc994005f91f81d0e8e5f8d400b12ecd28336866bc62b8527e104f6339372"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "send attempt while closed" ascii fullword
		$s2 = "[+] CPU cores: %d, Threads: %d" ascii fullword
		$s3 = "[+] Stats: %d | %d" ascii fullword
		$opw1 = { 33 c0 88 45 48 b8 01 00 00 00 86 45 48 45 8b f5 48 8d 3d de f5 ff ff 0f 57 c9 f3 0f 7f 4d b8 }
		$opw2 = { 2d ce b5 00 00 c5 fa e6 f5 e9 40 fe ff ff 0f 1f 44 00 00 75 2e c5 fb 10 0d 26 b4 00 00 44 8b 05 5f b6 00 00 e8 ca 0d 00 00 }
		$opl1 = { 4c 8d 44 24 08 48 89 f7 48 ff c2 48 83 c6 04 e8 c7 fb ff ff 41 89 c1 0f b6 42 ff 41 0f af c1 }
		$opl2 = { e8 6f fb ff ff 49 8d 78 f8 89 c0 48 01 c2 48 89 15 09 fb 24 00 e8 5a fb ff ff 49 8d 78 fc 6b f0 06 }

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0x457f ) and filesize < 4000KB and 2 of them
}
rule SIGNATURE_BASE_SUSP_LNK_Embedded_Worddoc : FILE
{
	meta:
		description = "check for LNK files with indications of the Word program or an embedded doc"
		author = "Greg Lesnewich"
		id = "9677d41a-9d29-510c-98cd-122dc0ca9606"
		date = "2023-01-02"
		modified = "2023-12-05"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_100days_of_yara_2023.yar#L3-L20"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "120ca851663ef0ebef585d716c9e2ba67bd4870865160fec3b853156be1159c5"
		logic_hash = "a53fbfe0ccb5a4ab2320cde10d17f29770d888cf21cda4fdccc3d7ae8d123293"
		score = 65
		quality = 85
		tags = "FILE"
		version = "1.0"
		DaysofYARA = "2/100"

	strings:
		$doc_header = {D0 CF 11 E0 A1 B1 1A E1}
		$icon_loc = "C:\\Program Files\\Microsoft Office\\Office16\\WINWORD.exe" ascii wide

	condition:
		uint32be( 0x0 ) == 0x4C000000 and filesize > 10KB and any of them
}
rule SIGNATURE_BASE_SUSP_LNK_Smallscreensize
{
	meta:
		description = "check for LNKs that have a screen buffer size and WindowSize dimensions of 1x1"
		author = "Greg Lesnewich"
		id = "6194a76b-36d6-51d1-8d53-2e11172e29d2"
		date = "2023-01-01"
		modified = "2023-12-05"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_100days_of_yara_2023.yar#L22-L44"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "285985c21e34f8412b49dbfe04abad9f93af195801d0a8870ec3795b8a9a3787"
		score = 65
		quality = 85
		tags = ""
		version = "1.0"
		DaysofYARA = "1/100"

	strings:
		$dimensions = {02 00 00 A0 ?? 00 ?? ?? 01 00 01 00 01}

	condition:
		uint32be( 0x0 ) == 0x4c000000 and all of them
}
rule SIGNATURE_BASE_MAL_Janicab_LNK
{
	meta:
		description = "detect LNK files used in Janicab infection chain"
		author = "Greg Lesnewich"
		id = "c21844d3-eeee-530e-a69c-b7f604616f0b"
		date = "2023-01-01"
		modified = "2023-12-05"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_100days_of_yara_2023.yar#L46-L68"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0c7e8427ee61672568983e51bf03e0bcf6f2e9c01d2524d82677b20264b23a3f"
		hash = "22ede766fba7551ad0b71ef568d0e5022378eadbdff55c4a02b42e63fcb3b17c"
		hash = "4920e6506ca557d486e6785cb5f7e4b0f4505709ffe8c30070909b040d3c3840"
		hash = "880607cc2da4c3213ea687dabd7707736a879cc5f2f1d4accf79821e4d24d870"
		hash = "f4610b65eba977b3d13eba5da0e38788a9e796a3e9775dd2b8e37b3085c2e1af"
		logic_hash = "f9c000ffb6a95d616459e00f0220ad26cb1df77e35582d14dfce1637ddfb466c"
		score = 75
		quality = 85
		tags = ""
		version = "1.0"
		DaysofYARA = "1/100"

	strings:
		$j_pdf1 = "%PDF-1.5" ascii wide
		$j_cmd = "\\Windows\\System32\\cmd.exe" ascii wide
		$j_pdf_stream = "endstream" ascii wide
		$j_pdb_obj = "endobj" ascii wide
		$dimensions = {02 00 00 A0 ?? 00 ?? ?? 01 00 01 00 01}

	condition:
		uint32be( 0x0 ) == 0x4C000000 and $dimensions and 2 of ( $j_* )
}
rule SIGNATURE_BASE_MAL_ELF_Torchtriton : FILE
{
	meta:
		description = "Detection for backdoor (TorchTriton) distributed with a nightly build of PyTorch"
		author = "Silas Cutler"
		id = "85e98ee7-30bf-554f-a0ac-9df263e6dfe4"
		date = "2023-01-02"
		modified = "2023-12-05"
		reference = "https://www.bleepingcomputer.com/news/security/pytorch-discloses-malicious-dependency-chain-compromise-over-holidays/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_100days_of_yara_2023.yar#L88-L117"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "2385b29489cd9e35f92c072780f903ae2e517ed422eae67246ae50a5cc738a0e"
		logic_hash = "12de3c3785aaf3623097db58abfe8ee2cbd9a0e712bf752165952de9a5fdb07d"
		score = 75
		quality = 85
		tags = "FILE"
		version = "1.0"
		DaysofYARA = "2/100"

	strings:
		$error = "failed to send packet"
		$aes_key = "gIdk8tzrHLOM)mPY-R)QgG[;yRXYCZFU"
		$aes_iv = "?BVsNqL]S.Ni"
		$func01 = "splitIntoDomains("
		$func02 = "packageForTransport"
		$func03 = "gatherFiles"
		$func04 = "void sendFile("
		$domain = "&z-%`-(*"

	condition:
		uint32( 0 ) == 0x464c457f and ( ( all of ( $aes_* ) ) or ( all of ( $func* ) and $error ) or ( $domain and 2 of them ) )
}
rule SIGNATURE_BASE_MAL_GOLDBACKDOOR_LNK
{
	meta:
		description = "No description has been set in the source file - Signature Base"
		author = "Greg Lesnewich"
		id = "9a80f875-4843-535c-9f2b-b04da55713b1"
		date = "2023-01-02"
		modified = "2023-12-05"
		reference = "https://stairwell.com/wp-content/uploads/2022/04/Stairwell-threat-report-The-ink-stained-trail-of-GOLDBACKDOOR.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_100days_of_yara_2023.yar#L119-L142"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "120ca851663ef0ebef585d716c9e2ba67bd4870865160fec3b853156be1159c5"
		logic_hash = "043d01758c722964e848e51cf2747c5879f03f0fd43af827e2035abf113daf9d"
		score = 75
		quality = 85
		tags = ""
		version = "1.0"
		DaysofYARA = "2/100"

	strings:
		$doc_header = {D0 CF 11 E0 A1 B1 1A E1}
		$doc_icon_loc = "C:\\Program Files\\Microsoft Office\\Office16\\WINWORD.exe" ascii wide
		$script_apionedrivecom_hex_enc_str = "6170692e6f6e6564726976652e636f6d" wide
		$script_kernel32dll_hex_enc_str = "6b65726e656c33322e646c6c" wide
		$script_GlobalAlloc_hex_enc_str = "476c6f62616c416c6c6f63" wide
		$script_VirtualProtect_hex_enc_str = "5669727475616c50726f74656374" wide
		$script_WriteByte_hex_enc_str = "577269746542797465" wide
		$script_CreateThread_hex_enc_str = "437265617465546872656164" wide

	condition:
		uint32be( 0x0 ) == 0x4C000000 and 1 of ( $doc* ) and 2 of ( $script* )
}

rule SIGNATURE_BASE_MAL_EXE_Prestigeransomware : FILE
{
	meta:
		description = "Detection for Prestige Ransomware"
		author = "Silas Cutler, modfied by Florian Roth"
		id = "5ac8033a-8b15-5abe-89d5-018a4fef9ab5"
		date = "2023-01-04"
		modified = "2023-01-06"
		reference = "https://www.microsoft.com/en-us/security/blog/2022/10/14/new-prestige-ransomware-impacts-organizations-in-ukraine-and-poland/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_100days_of_yara_2023.yar#L171-L195"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "5fc44c7342b84f50f24758e39c8848b2f0991e8817ef5465844f5f2ff6085a57"
		logic_hash = "2f51ca71d28c8d0df8de22011e16919672d5f9d3f3d94594c5d0cbf7f1585a1e"
		score = 80
		quality = 85
		tags = "FILE"
		version = "1.0"
		DaysofYARA = "4/100"

	strings:
		$x_ransom_email = "Prestige.ranusomeware@Proton.me" wide
		$x_reg_ransom_note = "C:\\Windows\\System32\\reg.exe add HKCR\\enc\\shell\\open\\command /ve /t REG_SZ /d \"C:\\Windows\\Notepad.exe C:\\Users\\Public\\README\" /f" wide
		$ransom_message01 = "To decrypt all the data, you will need to purchase our decryption software." wide
		$ransom_message02 = "Contact us {}. In the letter, type your ID = {:X}." wide
		$ransom_message03 = "- Do not try to decrypt your data using third party software, it may cause permanent data loss." wide
		$ransom_message04 = "- Do not modify or rename encrypted files. You will lose them." wide

	condition:
		uint16( 0 ) == 0x5A4D and ( 1 of ( $x* ) or 2 of them or pe.imphash ( ) == "a32bbc5df4195de63ea06feb46cd6b55" )
}
rule SIGNATURE_BASE_MAL_EXE_Royalransomware : FILE
{
	meta:
		description = "Detection for Royal Ransomware seen Dec 2022"
		author = "Silas Cutler, modfied by Florian Roth"
		id = "f83316f7-b8c4-5907-a38e-80535215e7ef"
		date = "2023-01-03"
		modified = "2023-12-05"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_100days_of_yara_2023.yar#L197-L222"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "a8384c9e3689eb72fa737b570dbb53b2c3d103c62d46747a96e1e1becf14dfea"
		logic_hash = "6f93bade7709945b478cbdc721d85ad9243d56ace19fba25835cec13a6210dfb"
		score = 75
		quality = 85
		tags = "FILE"
		version = "1.0"
		DaysofYARA = "3/100"

	strings:
		$x_ext = ".royal_" wide
		$x_fname = "royal_dll.dll"
		$s_readme = "README.TXT" wide
		$s_cli_flag01 = "-networkonly" wide
		$s_cli_flag02 = "-localonly" wide
		$x_ransom_msg01 = "If you are reading this, it means that your system were hit by Royal ransomware."
		$x_ransom_msg02 = "Try Royal today and enter the new era of data security!"
		$x_onion_site = "http://royal2xthig3ou5hd7zsliqagy6yygk2cdelaxtni2fyad6dpmpxedid.onion/"

	condition:
		uint16( 0 ) == 0x5A4D and ( 2 of ( $x* ) or 5 of them )
}
rule SIGNATURE_BASE_MAL_PY_Dimorf
{
	meta:
		description = "Detection for Dimorf ransomeware"
		author = "Silas Cutler"
		id = "78b53433-6926-58cd-8ec0-2195af803aab"
		date = "2023-01-03"
		modified = "2023-12-05"
		reference = "https://github.com/Ort0x36/Dimorf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_100days_of_yara_2023.yar#L224-L242"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7499b21f77d07364983b94134a60f7c99e71a5392386437d459a196bf71852fb"
		score = 75
		quality = 85
		tags = ""
		version = "1.0"

	strings:
		$func01 = "def find_and_encrypt"
		$func02 = "def check_os"
		$comment01 = "checks if the user has permission on the file."
		$misc01 = "log_dimorf.log"
		$misc02 = ".dimorf"

	condition:
		all of them
}
rule SIGNATURE_BASE_Shellcode_Apihashing_FIN8
{
	meta:
		description = "Detects FIN8 Shellcode APIHashing"
		author = "Frank Boldewin (@r3c0nst)"
		id = "bca5601c-2998-545b-8dd0-ec3c861e6291"
		date = "2021-03-16"
		modified = "2023-12-05"
		reference = "https://www.bitdefender.com/files/News/CaseStudies/study/394/Bitdefender-PR-Whitepaper-BADHATCH-creat5237-en-EN.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_fin8.yar#L1-L19"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "5d47119a588aa69b3e241618d6dbb9df6117a6751bbff39a1f95340bc26611a7"
		score = 75
		quality = 85
		tags = ""

	strings:
		$APIHashing32bit1 = {81 F7 99 5D 52 69 81 F3 30 D7 00 AB}
		$APIHashing32bit2 = {68 F2 55 03 88 68 65 19 6D 1E}
		$APIHashing32bit3 = {68 9B 59 27 21 C1 E9 17 33 4C 24 10 68 37 5C 32 F4}
		$APIHashing64bit1 = {49 BF 65 19 6D 1E F2 55 03 88 49 BE 37 5C 32 F4 9B 59 27 21}
		$APIHashing64bit2 = {48 B8 99 5D 52 69 30 D7 00 AB}

	condition:
		all of ( $APIHashing32bit* ) or all of ( $APIHashing64bit* )
}
rule SIGNATURE_BASE_HKTL_Cobaltstrike_Beacon_Strings
{
	meta:
		description = "Identifies strings used in Cobalt Strike Beacon DLL"
		author = "Elastic"
		id = "af558aa2-a3dc-5a7a-bc74-42bb2246091c"
		date = "2021-03-16"
		modified = "2026-05-26"
		reference = "https://www.elastic.co/blog/detecting-cobalt-strike-with-memory-signatures"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cobaltstrike.yar#L54-L67"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4349a7ad94df2269217b55c2aef9628c4eef078566c276936accdd4f996ba2cf"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "%02d/%02d/%02d %02d:%02d:%02d"
		$s2 = "Started service %s on %s"
		$s3 = "%s as %s\\%s: %d"

	condition:
		2 of them
}
rule SIGNATURE_BASE_HKTL_Cobaltstrike_Beacon_XOR_Strings
{
	meta:
		description = "Identifies XOR'd strings used in Cobalt Strike Beacon DLL"
		author = "Elastic"
		id = "359160a8-cf1c-58a8-bf7f-c09a8d661308"
		date = "2021-03-16"
		modified = "2026-05-26"
		reference = "https://www.elastic.co/blog/detecting-cobalt-strike-with-memory-signatures"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cobaltstrike.yar#L69-L90"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "214f0400863783ab4294d8acc820cf00ab9941d193b2b843f877207b9912d799"
		score = 75
		quality = 85
		tags = ""
		xor_s1 = "%02d/%02d/%02d %02d:%02d:%02d"
		xor_s2 = "Started service %s on %s"
		xor_s3 = "%s as %s\\%s: %d"

	strings:
		$s1 = "%02d/%02d/%02d %02d:%02d:%02d" xor(0x01-0xff)
		$s2 = "Started service %s on %s" xor(0x01-0xff)
		$s3 = "%s as %s\\%s: %d" xor(0x01-0xff)
		$fp1 = "MalwareRemovalTool" ascii wide
		$fp2 = "advanced malware removal tool" ascii wide

	condition:
		2 of ( $s* ) and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_HKTL_Cobaltstrike_Beacon_4_2_Decrypt
{
	meta:
		description = "Identifies deobfuscation routine used in Cobalt Strike Beacon DLL version 4.2"
		author = "Elastic"
		id = "63b71eef-0af5-5765-b957-ccdc9dde053b"
		date = "2021-03-16"
		modified = "2026-05-26"
		reference = "https://www.elastic.co/blog/detecting-cobalt-strike-with-memory-signatures"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cobaltstrike.yar#L92-L104"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8685b1626c8d263f49ccf129dcd4fe1b42482fcdb37c2e109cedcecaed8c2407"
		score = 75
		quality = 85
		tags = ""

	strings:
		$a_x64 = { 4C 8B 53 08 45 8B 0A 45 8B 5A 04 4D 8D 52 08 45 85 C9 75 05 45 85 DB 74 33 45 3B CB 73 E6 49 8B F9 4C 8B 03 }
		$a_x86 = { 8B 46 04 8B 08 8B 50 04 83 C0 08 89 55 08 89 45 0C 85 C9 75 04 85 D2 74 23 3B CA 73 E6 8B 06 8D 3C 08 33 D2 }

	condition:
		any of them
}
rule SIGNATURE_BASE_HKTL_Win_Cobaltstrike : COMMODITY
{
	meta:
		description = "The CobaltStrike malware family."
		author = "threatintel@volexity.com"
		id = "113ba304-261f-5c59-bc56-57515c239b6d"
		date = "2021-05-25"
		modified = "2026-05-26"
		reference = "https://www.volexity.com/blog/2021/05/27/suspected-apt29-operation-launches-election-fraud-themed-phishing-campaigns/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cobaltstrike.yar#L106-L124"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "b041efb8ba2a88a3d172f480efa098d72eef13e42af6aa5fb838e6ccab500a7c"
		logic_hash = "1e8a68050ff25f77e903af2e0a85579be1af77c64684e42e8f357eee4ae59377"
		score = 75
		quality = 85
		tags = "COMMODITY"

	strings:
		$s1 = "%s (admin)" fullword
		$s2 = { 48 54 54 50 2F 31 2E 31 20 32 30 30 20 4F 4B 0D 0A 43 6F 6E 74 65 6E 74 2D 54 79 70 65 3A 20 61 70 70 6C 69 63 61 74 69 6F 6E 2F 6F 63 74 65 74 2D 73 74 72 65 61 6D 0D 0A 43 6F 6E 74 65 6E 74 2D 4C 65 6E 67 74 68 3A 20 25 64 0D 0A 0D 0A 00 }
		$s3 = "%02d/%02d/%02d %02d:%02d:%02d" fullword
		$s4 = "%s as %s\\%s: %d" fullword
		$s5 = "%s&%s=%s" fullword
		$s6 = "rijndael" fullword
		$s7 = "(null)"

	condition:
		all of them
}
rule SIGNATURE_BASE_MSIL_SUSP_OBFUSC_Xorstringsnet : FILE
{
	meta:
		description = "Detects XorStringsNET string encryption, and other obfuscators derived from it"
		author = "dr4k0nia"
		id = "f0724ca6-4bfe-5b88-9396-a58aa7461fd6"
		date = "2023-03-26"
		modified = "2023-12-05"
		reference = "https://github.com/dr4k0nia/yara-rules"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_net_xorstrings.yar#L2-L27"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6d023a80bd8f5709721c3ace8a7230b847ca4bd2a1aff502a25333ffc8bf75ca"
		score = 75
		quality = 85
		tags = "FILE"
		version = "1.0"

	strings:
		$pattern = { 06 1E 58 07 8E 69 FE 17 }
		$a1 = "_CorDllMain" ascii
		$a2 = "_CorExeMain" ascii
		$a3 = "mscorlib" ascii fullword
		$a4 = ".cctor" ascii fullword
		$a5 = "System.Private.Corlib" ascii
		$a6 = "<Module>" ascii fullword
		$a7 = "<PrivateImplementationsDetails{" ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 25MB and $pattern and 2 of ( $a* )
}
rule SIGNATURE_BASE_APT_UNC4841_ESG_Barracuda_CVE_2023_2868_Forensic_Artifacts_Jun23_1 : SCRIPT CVE_2023_2868
{
	meta:
		description = "Detects forensic artifacts found in the exploitation of CVE-2023-2868 in Barracuda ESG devices by UNC4841"
		author = "Florian Roth"
		id = "50518fa1-33de-5fe5-b957-904d976fb29a"
		date = "2023-06-15"
		modified = "2023-06-16"
		reference = "https://www.mandiant.com/resources/blog/barracuda-esg-exploited-globally"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_barracuda_esg_unc4841_jun23.yar#L2-L28"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "fa7cac1e0f6cb6fa3ac271c1fff0039ff182b6859920b4eca25541457654acde"
		score = 75
		quality = 85
		tags = "SCRIPT, CVE-2023-2868"

	strings:
		$x01 = "=;ee=ba;G=s;_ech_o $abcdefg_${ee}se64" ascii
		$x02 = ";echo $abcdefg | base64 -d | sh" ascii
		$x03 = "setsid sh -c \"mkfifo /tmp/p" ascii
		$x04 = "sh -i </tmp/p 2>&1" ascii
		$x05 = "if string.match(hdr:body(), \"^[%w%+/=" ascii
		$x06 = "setsid sh -c \"/sbin/BarracudaMailService eth0\""
		$x07 = "echo \"set the bvp ok\""
		$x08 = "find ${path} -type f ! -name $excludeFileNameKeyword | while read line ;"
		$x09 = " /mail/mstore | xargs -i cp {} /usr/share/.uc/"
		$x10 = "tar -T /mail/mstore/tmplist -czvf "
		$sa1 = "sh -c wget --no-check-certificate http"
		$sa2 = ".tar;chmod +x "

	condition:
		1 of ( $x* ) or all of ( $sa* )
}
rule SIGNATURE_BASE_APT_MAL_UNC4841_SEASPY_Jun23_1 : CVE_2023_2868 FILE
{
	meta:
		description = "Detects SEASPY malware used by UNC4841 in attacks against Barracuda ESG appliances exploiting CVE-2023-2868"
		author = "Florian Roth"
		id = "bcff58f8-87f6-5371-8b96-5d4c0f349000"
		date = "2023-06-16"
		modified = "2023-12-05"
		reference = "https://blog.talosintelligence.com/alchimist-offensive-framework/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_barracuda_esg_unc4841_jun23.yar#L30-L55"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "3f26a13f023ad0dcd7f2aa4e7771bba74910ee227b4b36ff72edc5f07336f115"
		logic_hash = "c1dcb841fb872f0d5e661bfd90fca3075f5efc95b1f9dfff72fa318ed131e9d1"
		score = 85
		quality = 85
		tags = "CVE-2023-2868, FILE"

	strings:
		$sx1 = "usage: ./BarracudaMailService <Network-Interface>. e.g.: ./BarracudaMailService eth0" ascii fullword
		$s1 = "fcntl.tmp.amd64." ascii
		$s2 = "Child process id:%d" ascii fullword
		$s3 = "[*]Success!" ascii fullword
		$s4 = "NO port code" ascii
		$s5 = "enter open tty shell" ascii
		$op1 = { 48 89 c6 f3 a6 0f 84 f7 01 00 00 bf 6c 84 5f 00 b9 05 00 00 00 48 89 c6 f3 a6 0f 84 6a 01 00 00 }
		$op2 = { f3 a6 0f 84 d2 00 00 00 48 89 de bf 51 5e 61 00 b9 05 00 00 00 f3 a6 74 21 48 89 de }
		$op3 = { 72 de 45 89 f4 e9 b8 f4 ff ff 48 8b 73 08 45 85 e4 ba 49 3d 62 00 b8 44 81 62 00 48 0f 45 d0 }

	condition:
		uint16( 0 ) == 0x457f and filesize < 9000KB and 3 of them or 5 of them
}
rule SIGNATURE_BASE_APT_MAL_UNC4841_SEASPY_LUA_Jun23_1 : FILE
{
	meta:
		description = "Detects SEASPY malware related LUA script"
		author = "Florian Roth"
		id = "a44861d0-107e-589b-8cf1-3fbc2f5c78dc"
		date = "2023-06-16"
		modified = "2023-12-05"
		reference = "https://blog.talosintelligence.com/alchimist-offensive-framework/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_barracuda_esg_unc4841_jun23.yar#L57-L74"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "56e8066bf83ff6fe0cec92aede90f6722260e0a3f169fc163ed88589bffd7451"
		logic_hash = "f78823a4ba9e025ba4833a2d5234c7baba33c1167c0247f13b8b2baa430aa4e5"
		score = 90
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "os.execute('rverify'..' /tmp/'..attachment:filename())" ascii fullword
		$x2 = "log.debug(\"--- opening archive [%s], mimetype [%s]\", tmpfile" ascii fullword
		$xe1 = "os.execute('rverify'..' /tmp/'..attachment:filename())" ascii base64
		$xe2 = "log.debug(\"--- opening archive [%s], mimetype [%s]\", tmpfile" ascii base64

	condition:
		filesize < 500KB and 1 of them
}
rule SIGNATURE_BASE_APT_HKTL_Proxy_Tool_Jun23_1 : FILE
{
	meta:
		description = "Detects agent used as proxy tool in UNC4841 intrusions - possibly Alchemist C2 framework implant"
		author = "Florian Roth"
		id = "0e406737-3083-53c2-a6d2-14c07794125a"
		date = "2023-06-16"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/blog/barracuda-esg-exploited-globally"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_barracuda_esg_unc4841_jun23.yar#L76-L101"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "ca72fa64ed0a9c22d341a557c6e7c1b6a7264b0c4de0b6f717dd44bddf550bca"
		hash = "57e4b180fd559f15b59c43fb3335bd59435d4d76c4676e51a06c6b257ce67fb2"
		logic_hash = "7e2152e1aa74e1842519e2eecd2acd3ef8eb8d517f3c0ef9f05c983616f223c3"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$a2 = "/src/runtime/panic.go"
		$s1 = "main.handleClientRequest" ascii fullword
		$s2 = "main.sockIP.toAddr" ascii fullword

	condition:
		( uint16( 0 ) == 0x5a4d or uint32be( 0 ) == 0x7f454c46 or uint16( 0 ) == 0xfeca or uint16( 0 ) == 0xfacf or uint32( 0 ) == 0xbebafeca or uint32( 0 ) == 0xbebafeca ) and filesize < 10MB and all of them
}
rule SIGNATURE_BASE_SUSP_Fscan_Port_Scanner_Output_Jun23 : SCRIPT FILE
{
	meta:
		description = "Detects output generated by the command line port scanner FScan"
		author = "Florian Roth"
		id = "7eb4b27f-0c5b-5d7e-b759-95d7894d5822"
		date = "2023-06-15"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/blog/barracuda-esg-exploited-globally"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_barracuda_esg_unc4841_jun23.yar#L103-L117"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "49b5055c96d7b7446ee5ae8667a5aa3645f0f98d8b5f2bffcd6ef3b20bc64e05"
		score = 70
		quality = 85
		tags = "SCRIPT, FILE"

	strings:
		$s1 = "[*] NetInfo:" ascii
		$s2 = ":443 open" ascii
		$s3 = "   [->]"

	condition:
		filesize < 800KB and all of them
}
rule SIGNATURE_BASE_SUSP_PY_Shell_Spawn_Jun23_1 : SCRIPT
{
	meta:
		description = "Detects suspicious one-liner to spawn a shell using Python"
		author = "Florian Roth"
		id = "15fd2c9a-c425-5d4d-9209-fd3826074d6c"
		date = "2023-06-15"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/blog/barracuda-esg-exploited-globally"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_barracuda_esg_unc4841_jun23.yar#L119-L131"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "63e94447930d5a00399de753076facbfb2bf18dd8c815f01aaefd14678aea034"
		score = 70
		quality = 85
		tags = "SCRIPT"

	strings:
		$x1 = "python -c import pty;pty.spawn(\"/bin/" ascii

	condition:
		1 of them
}
rule SIGNATURE_BASE_APT_MAL_Hunting_LUA_SEASIDE_1 : FILE
{
	meta:
		description = "Hunting rule looking for strings observed in SEASIDE samples."
		author = "Mandiant"
		id = "86eaff7b-4ca0-53cd-8886-da66a36c778f"
		date = "2023-06-15"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/blog/barracuda-esg-exploited-globally"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_barracuda_esg_unc4841_jun23.yar#L136-L152"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "cd2813f0260d63ad5adf0446253c2172"
		logic_hash = "82b61325a78bf8ab09d426cfadceb614a256dfcafb2e1f75595de63593ed2574"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "function on_helo()"
		$s2 = "local bindex,eindex = string.find(helo,'.onion')"
		$s3 = "helosend = 'pd'..' '..helosend"
		$s4 = "os.execute(helosend)"

	condition:
		filesize < 1MB and all of ( $s* )
}
rule SIGNATURE_BASE_APT_MAL_LNX_Hunting_Linux_WHIRLPOOL_1 : FILE
{
	meta:
		description = "Hunting rule looking for strings observed in WHIRLPOOL samples."
		author = "Mandiant"
		id = "a997bd65-c502-53a0-8bb8-62daaa916f0d"
		date = "2023-06-15"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/blog/barracuda-esg-exploited-globally"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_barracuda_esg_unc4841_jun23.yar#L154-L173"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "177add288b289d43236d2dba33e65956"
		logic_hash = "d03c0e292b9b97bbf76585fc74208e4263d753807b8e4a445be80d41264d5432"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "error -1 exit" fullword
		$s2 = "create socket error: %s(error: %d)\n" fullword
		$s3 = "connect error: %s(error: %d)\n" fullword
		$s4 = {C7 00 20 32 3E 26 66 C7 40 04 31 00}
		$c1 = "plain_connect" fullword
		$c2 = "ssl_connect" fullword
		$c3 = "SSLShell.c" fullword

	condition:
		uint32( 0 ) == 0x464c457f and filesize < 15MB and ( all of ( $s* ) or all of ( $c* ) )
}
rule SIGNATURE_BASE_APT_MAL_LUA_Hunting_SKIPJACK_1
{
	meta:
		description = "Hunting rule looking for strings observed in SKIPJACK installation script."
		author = "Mandiant"
		id = "0026375c-7f37-5ef9-bd55-5b9fc499e5d2"
		date = "2023-06-15"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/blog/barracuda-esg-exploited-globally"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_barracuda_esg_unc4841_jun23.yar#L175-L193"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "e4e86c273a2b67a605f5d4686783e0cc"
		logic_hash = "8890cd9ab8190f12997e0653e43c89816df03c7bd41842e5ad21b1986819843e"
		score = 70
		quality = 85
		tags = ""

	strings:
		$str1 = "hdr:name() == 'Content-ID'" base64
		$str2 = "hdr:body() ~= nil" base64
		$str3 = "string.match(hdr:body(),\"^[%w%+/=\\r\\n]+$\")" base64
		$str4 = "openssl aes-256-cbc" base64
		$str5 = "mod_content.lua"
		$str6 = "#!/bin/sh"

	condition:
		all of them
}
rule SIGNATURE_BASE_APT_MAL_LUA_Hunting_Lua_SKIPJACK_2
{
	meta:
		description = "Hunting rule looking for strings observed in SKIPJACK samples."
		author = "Mandiant"
		id = "e1eac294-fe60-5bb2-bae4-0f7bcbe6b1db"
		date = "2023-06-15"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/blog/barracuda-esg-exploited-globally"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_barracuda_esg_unc4841_jun23.yar#L195-L212"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "87847445f9524671022d70f2a812728f"
		logic_hash = "093e8857c410bd30a076f87ef63d7e1e66f50e3dce75b4add67161782386ee24"
		score = 70
		quality = 85
		tags = ""

	strings:
		$str1 = "hdr:name() == 'Content-ID'"
		$str2 = "hdr:body() ~= nil"
		$str3 = "string.match(hdr:body(),\"^[%w%+/=\\r\\n]+$\")"
		$str4 = "openssl aes-256-cbc"
		$str5 = "| base64 -d| sh 2>"

	condition:
		all of them
}
rule SIGNATURE_BASE_APT_MAL_LUA_Hunting_Lua_SEASPRAY_1
{
	meta:
		description = "Hunting rule looking for strings observed in SEASPRAY samples."
		author = "Mandiant"
		id = "8c744b85-b61e-56d0-8a9e-ae6a954e1b95"
		date = "2023-06-15"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/blog/barracuda-esg-exploited-globally"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_barracuda_esg_unc4841_jun23.yar#L213-L228"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "35cf6faf442d325961935f660e2ab5a0"
		logic_hash = "856bfb47557b60f69aa1141477d6ce446ea13ebbe899022d7996ceef08bdefbb"
		score = 70
		quality = 85
		tags = ""

	strings:
		$str1 = "string.find(attachment:filename(),'obt075') ~= nil"
		$str2 = "os.execute('cp '..tostring(tmpfile)..' /tmp/'..attachment:filename())"
		$str3 = "os.execute('rverify'..' /tmp/'..attachment:filename())"

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_RANSOM_Gentlemen_Jun26_1 : FILE
{
	meta:
		description = "Detects The Gentlemen ransomware Windows locker (Storm-2697), a self-propagating Go-based encryptor"
		author = "Aryu-RU"
		id = "e93ade6d-c558-426c-b8b5-c6034baf6693"
		date = "2026-06-16"
		modified = "2026-06-16"
		reference = "https://www.microsoft.com/en-us/security/blog/2026/05/28/the-gentlemen-ransomware-dissecting-a-self-propagating-go-encryptor/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_ransom_gentlemen.yar#L2-L26"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "22b38dad7da097ea03aa28d0614164cd25fafeb1383dbc15047e34c8050f6f67"
		hash = "f918535f974591ef031bd0f30a8171e3da27a6754e6426a8ba095f83195661c8"
		logic_hash = "0821108fe45c60138cdfb5f79278b7f15c650dad7d94ba8abc559439a49f2c51"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "README-GENTLEMEN.txt" ascii
		$x2 = "gentlemen.bmp" ascii
		$x3 = "gentlemen_system" ascii
		$s1 = "[+] Encryption started" ascii
		$s2 = "Encrypt only mapped" ascii
		$s3 = "Silent mode" ascii

	condition:
		uint16( 0 ) == 0x5A4D and filesize < 30MB and ( 2 of ( $x* ) or ( 1 of ( $x* ) and 2 of ( $s* ) ) )
}
rule SIGNATURE_BASE_EXPL_HKTL_LNX_Dirtyfraglpe_May26 : FILE
{
	meta:
		description = "Detects dirtyfrag, a local privilege escalation exploit for Linux."
		author = "Pezier Pierre-Henri (Nextron Systems)"
		id = "7548b4c6-6b0f-5c05-acab-26dceac109ac"
		date = "2026-05-07"
		modified = "2026-05-15"
		reference = "https://github.com/V4bel/dirtyfrag/tree/master"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_lnx_dirtyfrag.yar#L1-L26"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "c35594d42f7a5d5d2895164147ee1bc62bb8e294c8468093b7d6fcaab0b174c8"
		logic_hash = "8b804b3f2d00eccb1f4208173fde15f0525ac710388f14d6a4f9844c49d3660e"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "gained CAP_NET_RAW within netn" ascii
		$x2 = "DIRTYFRAG_VERBOSE" ascii
		$s1 = { 15 7C 4A 7F B9 79 37 9E }
		$s2 = "/proc/self/setgroups" ascii fullword
		$s3 = "pcbc(fcrypt)" ascii fullword
		$s4 = { 17 bb c7 f3 3f 36 ba 71 8e 97 65 60 69 b6 f6 e6 }

	condition:
		filesize < 100KB and uint32be( 0 ) == 0x7f454c46 and ( 1 of ( $x* ) or 3 of ( $s* ) )
}
rule SIGNATURE_BASE_EXPL_HKTL_LNX_Dirtyfragshellcode_May26
{
	meta:
		description = "Detects a shellcode observed in dirtyfrag, a local privilege escalation exploit for Linux."
		author = "Pezier Pierre-Henri (Nextron Systems)"
		id = "c156da87-c029-5084-9cd3-a233fefdaf25"
		date = "2026-05-07"
		modified = "2026-05-15"
		reference = "https://github.com/V4bel/dirtyfrag/tree/master"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_lnx_dirtyfrag.yar#L28-L60"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "a02ea2ba8108a9b7a997faa8808cfc55bb69af54e69178fa5aa1785681cf0ced"
		logic_hash = "af23343955d917f302bbba3faf48d4a57ab3b37f77ec7556e17c3e9bac6cdc5f"
		score = 80
		quality = 85
		tags = ""

	strings:
		$op1 = {
         31 ff     // xor     edi, edi
         31 f6     // xor     esi, esi
         31 c0     // xor     eax, eax
         b0 6a     // mov     al, 6Ah ; 'j'
         0f 05     // syscall; LINUX - sys_setgid
         b0 69     // mov     al, 69h ; 'i'
         0f 05     // syscall; LINUX - sys_setuid
         b0 74     // mov     al, 74h ; 't'
         0f 05     // syscall; LINUX - sys_setgroups
         6a 00     // push    0
         48 [6]    // lea     rax, aTermXterm; "TERM=xterm"
         50        // push    rax
         48 89 e2  // mov     rdx, rsp
         48 [6]    // lea     rdi, aBinSh; "/bin/sh"
         31 f6     // xor     esi, esi
         6a 3b     // push    3Bh ; ';'
         58        // pop     rax
         0f 05     // syscall; LINUX - sys_execve
      }

	condition:
		$op1
}
rule SIGNATURE_BASE_EXPL_LNX_Dirtyfrag_Forensicartefacts_May26 : FILE
{
	meta:
		description = "Detects DirtyFrag exploit code POC usage in Linux environments"
		author = "Florian Roth"
		id = "bda5e087-8eb7-55bd-a5ff-0eef91d63bcf"
		date = "2026-05-08"
		modified = "2026-05-15"
		reference = "https://github.com/V4bel/dirtyfrag/tree/master"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_lnx_dirtyfrag.yar#L62-L77"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3790a19c180d1fcdcaf91c13b858d63adf126e9282999ccd424a0e6b9ae0e094"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$xa1 = "/V4bel/dirtyfrag.git" ascii
		$xa2 = "static const uint8_t shell_elf[PAYLOAD_LEN] = {" ascii
		$xa3 = "/usr/bin/su page-cache patched (entry 0x%x = shellcode)" ascii

	condition:
		filesize < 800KB and 1 of ( $xa* )
}
rule SIGNATURE_BASE_MAL_RANSOM_Lorenz_May21_1 : FILE
{
	meta:
		description = "Detects Lorenz Ransomware samples"
		author = "Florian Roth (Nextron Systems)"
		id = "0b18a4a3-82da-574b-8d10-daf2176448b9"
		date = "2021-05-04"
		modified = "2023-12-05"
		reference = "Internal Research - DACH TE"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_ransom_lorenz.yar#L1-L28"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "4b1170f7774acfdc5517fbe1c911f2bd9f1af498f3c3d25078f05c95701cc999"
		hash = "8258c53a44012f6911281a6331c3ecbd834b6698b7d2dbf4b1828540793340d1"
		hash = "c0c99b141b014c8e2a5c586586ae9dc01fd634ea977e2714fbef62d7626eb3fb"
		logic_hash = "aec940deb2c3bc099a50a2e8f014ae425d306d331078d9ac2abc2ec7b8bf572e"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "process call create \"cmd.exe /c schtasks /Create /F /RU System /SC ONLOGON " ascii fullword
		$x2 = "-----BEGIN PUBLIC KEY-----MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCn7fL/1qsWkJkUtXKZIJNqYfnVByVhK" ascii fullword
		$s1 = "process call create \"cmd.exe /c schtasks /Create /F " ascii fullword
		$s2 = "twr.ini" ascii fullword
		$s3 = "/c wmic /node:'" ascii fullword
		$op1 = { 0f 4f d9 81 ff dc 0f 00 00 5f 8d 4b 0? 0f 4e cb 83 fe 3c 5e 5b }
		$op2 = { 6a 02 e8 ?? ?? 0? 00 83 c4 18 83 f8 01 75 01 cc 6a 00 68 ?? ?? 00 00 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 4000KB and ( 1 of ( $x* ) or all of ( $op* ) or 3 of them )
}

rule SIGNATURE_BASE_SUSP_ENV_Folder_Root_File_Jan23_1 : SCRIPT FILE
{
	meta:
		description = "Detects suspicious file path pointing to the root of a folder easily accessible via environment variables"
		author = "Florian Roth (Nextron Systems)"
		id = "6067d822-5c1b-5b86-863c-fdcfa37da665"
		date = "2023-01-11"
		modified = "2023-12-05"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_susp_indicators.yar#L3-L22"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "5355ae567e6255e22f566bae9fe50f4995bafba07c261461d37d5b8ba200d33a"
		score = 70
		quality = 83
		tags = "SCRIPT, FILE"

	strings:
		$xr1 = /%([Aa]pp[Dd]ata|APPDATA)%\\[A-Za-z0-9_\-]{1,20}\.[a-zA-Z0-9]{1,4}[^\\]/ wide ascii
		$xr2 = /%([Pp]ublic|PUBLIC)%\\[A-Za-z0-9_\-]{1,20}\.[a-zA-Z0-9]{1,4}[^\\]/ wide ascii
		$xr4 = /%([Pp]rogram[Dd]ata|PROGRAMDATA)%\\[A-Za-z0-9_\-]{1,20}\.[a-zA-Z0-9]{1,4}[^\\]/ wide ascii
		$fp1 = "perl -MCPAN " ascii
		$fp2 = "CCleaner" ascii

	condition:
		filesize < 20MB and 1 of ( $x* ) and not 1 of ( $fp* ) and not pe.number_of_signatures > 0
}
rule SIGNATURE_BASE_MAL_JS_Efile_Apr23_1
{
	meta:
		description = "Detects JavaScript malware used in eFile compromise"
		author = "Florian Roth"
		id = "ba7a8b2c-789c-5bc5-be53-f2b92c7039e1"
		date = "2023-04-06"
		modified = "2023-12-05"
		reference = "https://twitter.com/Ax_Sharma/status/1643178696084271104/photo/1"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_efile_apr23.yar#L2-L15"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6d94162e5719b92d9df349e7d48cd70e218998b0e120870a435a8073fa49c532"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "let payload_chrome = "
		$s2 = "else if (agent.indexOf(\"firefox"

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_PHP_Efile_Apr23_1
{
	meta:
		description = "Detects malware "
		author = "Florian Roth"
		id = "d663b38e-b082-5cf7-9853-f4685bf3a87b"
		date = "2023-04-06"
		modified = "2023-12-05"
		reference = "https://twitter.com/malwrhunterteam/status/1642988428080865281?s=12&t=C0_T_re0wRP_NfKa27Xw9w"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_efile_apr23.yar#L18-L32"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ec4ac3f5c19f506a70eacb5fe3173cc06bf20567bbc9a96f3b269910382e5fa2"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff )" ascii
		$s2 = "C:\\\\ProgramData\\\\Browsers" ascii fullword
		$s3 = "curl_https($api_url." ascii

	condition:
		all of them
}
rule SIGNATURE_BASE_Cobaltstrike_Resources_Beacon_Dll_V3_8
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Versions 3.8"
		author = "gssincla@google.com"
		id = "6c65cbf8-2c60-5315-b3b2-48dfcee75733"
		date = "2022-11-18"
		modified = "2023-12-05"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_gcti_cobaltstrike.yar#L1020-L1061"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "67b6557f614af118a4c409c992c0d9a0cc800025f77861ecf1f3bbc7c293d603"
		logic_hash = "cde078a6ae7d0d835900e85498cf5ae20663ba8d5d3f912810e157261561e16a"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 48 57 8B F9 83 F8 4B 0F 87 5D 03 00 00 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 00 10 00 00 7C F1 }
		$xmrig_srcpath = "C:/Users/SKOL-NOTE/Desktop/Loader/script.go"
		$c2_1 = "ns7.softline.top" xor
		$c2_2 = "ns8.softline.top" xor
		$c2_3 = "ns9.softline.top" xor

	condition:
		$version_sig and $decoder and ( 2 of ( $c2_* ) or $xmrig_srcpath )
}
rule SIGNATURE_BASE_MAL_Qakbotloader_Export_Section_Feb23 : FILE
{
	meta:
		description = "QakBot Export Selection"
		author = "kevoreilly"
		id = "cb86e9fb-a8d2-5285-aeda-622704399f8e"
		date = "2023-02-17"
		modified = "2023-12-05"
		reference = "https://github.com/kevoreilly/CAPEv2/blob/master/LICENSE"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_qbot_feb23.yar#L22-L38"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "6f99171c95a8ed5d056eeb9234dbbee123a6f95f481ad0e0a966abd2844f0e1a"
		logic_hash = "0e40cd6acdbfb17670b414bd6f2ecdf1ae26ddd6a5d85931973b98963a43aba8"
		score = 75
		quality = 85
		tags = "FILE"
		cape_options = "export=$export"

	strings:
		$export = {55 8B EC 83 EC 50 (3A|66 3B) ?? 74}
		$wind = {(66 3B|3A) ?? 74 [1-14] BB 69 04 00 00 53 E8 [5-7] 74}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule SIGNATURE_BASE_Line_Dancer
{
	meta:
		description = "Targets code sections of Line Dancer, a shellcode loader targeting Cisco ASA devices."
		author = "NCSC"
		id = "3b49a861-8107-577a-bae1-ae28d424cc13"
		date = "2024-04-24"
		modified = "2024-04-29"
		reference = "https://www.ncsc.gov.uk/static-assets/documents/malware-analysis-reports/line/ncsc-tip-line-dancer.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cisco_asa_line_dancer_apr24.yar#L2-L16"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "179e58274a792bc4a16787d251f5ad25de1271084323e62e153fa6d461e3c07e"
		score = 75
		quality = 85
		tags = ""

	strings:
		$ = { 48 8D 5E 20 48 8D 3D BB FF FF FF BA 20 00 00 00 }
		$ = { 4C 89 EE 44 89 F2 48 8D 3D 9A 27 00 00 }
		$ = { 41 FF D7 41 5F 41 5E 41 5D 41 5C 5B 5D 48 C7 C0 01 00 00 00 5F }

	condition:
		all of them
}
rule SIGNATURE_BASE_SUSP_LNX_Sindoor_ELF_Obfuscation_Aug25 : FILE
{
	meta:
		description = "Detects ELF obfuscation technique used by Sindoor dropper related to APT 36"
		author = "Pezier Pierre-Henri"
		id = "97802224-0d8b-5691-a6f1-f031626cda53"
		date = "2025-08-29"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt36_operation_sindoor.yar#L1-L17"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "6879a2b730e391964afe4dbbc29667844ba0c29239be5503b7c86e59e7052443"
		logic_hash = "c1258c1f6d4b49104bedf3fbef932f1775ede7d32191df2e5479ca9b291add9e"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "UPX!"

	condition:
		filesize < 10MB and uint16( 0 ) == 0 and uint16( 4 ) > 0 and $s1 in ( 0xc0 .. 0x100 )
}
rule SIGNATURE_BASE_SUSP_LNX_Sindoor_Desktopfile_Aug25 : FILE
{
	meta:
		description = "Detects ELF obfuscation technique used by Sindoor dropper related to APT 36"
		author = "Pezier Pierre-Henri"
		id = "16719116-0cb2-5c70-a86f-f65f9ea32153"
		date = "2025-08-29"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt36_operation_sindoor.yar#L19-L36"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "9943bdf1b2a37434054b14a1a56a8e67aaa6a8b733ca785017d3ed8c1173ac59"
		logic_hash = "1549aac3132c5f3e73d984c3404a5530507e967df4ab6d5ccd408abc874a5306"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$hdr = "[Desktop Entry]"
		$s1 = "printf '\\\\x7FELF' | dd of"
		$s2 = "Future_Note_Warfare_OpSindoor.pdf"

	condition:
		filesize < 100KB and $hdr and any of ( $s* )
}
rule SIGNATURE_BASE_MAL_Sindoor_Decryptor_Aug25 : FILE
{
	meta:
		description = "Detects AES decryptor used by Sindoor dropper related to APT 36"
		author = "Pezier Pierre-Henri"
		id = "3c0c5217-b125-51a3-8129-30af5f0c7263"
		date = "2025-08-29"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt36_operation_sindoor.yar#L38-L63"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "9a1adb50bb08f5a28160802c8f315749b15c9009f25aa6718c7752471db3bb4b"
		logic_hash = "4172fd9aee39a1a0681483f6dada6394debc62149a588ab4807e3016a823bed3"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Go build"
		$s2 = "main.rc4EncryptDecrypt"
		$s3 = "main.processFile"
		$s4 = "main.deriveKeyAES"
		$s5 = "use RC4 instead of AES"

	condition:
		filesize < 100MB and ( uint16( 0 ) == 0x5a4d or uint32be( 0 ) == 0x7f454c46 or ( uint32be( 0 ) == 0xcafebabe and uint32be( 4 ) < 0x20 ) or uint32( 0 ) == 0xfeedface or uint32( 0 ) == 0xfeedfacf ) and all of them
}
rule SIGNATURE_BASE_MAL_Sindoor_Downloader_Aug25 : FILE
{
	meta:
		description = "Detects Sindoor downloader related to APT 36"
		author = "Pezier Pierre-Henri"
		id = "c1188abc-2bea-5cbc-a39d-9690626c0821"
		date = "2025-08-29"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt36_operation_sindoor.yar#L65-L90"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "38b6b93a536cbab5c289fe542656d8817d7c1217ad75c7f367b15c65d96a21d4"
		logic_hash = "c55be65cd077cb04b625636dffcb02af74efa06bb49da734c8616da233a34d1a"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Go build"
		$s2 = "main.downloadFile.deferwrap"
		$s3 = "main.decrypt"
		$s4 = "main.HiddenHome"
		$s5 = "main.RealCheck"

	condition:
		filesize < 100MB and ( uint16( 0 ) == 0x5a4d or uint32be( 0 ) == 0x7f454c46 or ( uint32be( 0 ) == 0xcafebabe and uint32be( 4 ) < 0x20 ) or uint32( 0 ) == 0xfeedface or uint32( 0 ) == 0xfeedfacf ) and all of them
}
rule SIGNATURE_BASE_EXPL_Exploit_TLB_Scripts : FILE
{
	meta:
		description = "Detects malicious TLB files which may be delivered via Visual Studio projects"
		author = "Rich Warren (slightly modified by Florian Roth)"
		id = "5151458e-4c30-50ff-a39e-e5b5b68b87aa"
		date = "2021-01-26"
		modified = "2023-12-05"
		reference = "https://github.com/outflanknl/Presentations/blob/master/Nullcon2020_COM-promise_-_Attacking_Windows_development_environments.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/exploit_tlb_scripts.yar#L2-L19"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "39bf626d60a867d054762043f74e86998d6848439655f84be72003c112db9953"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$a = ".sct" ascii nocase
		$b = "script:" ascii nocase
		$c = "scriptlet:" ascii nocase
		$d = "soap:" ascii nocase
		$e = "winmgmts:" ascii nocase

	condition:
		uint32be( 0 ) == 0x4D534654 and filesize < 100KB and any of them
}
rule SIGNATURE_BASE_VULN_PHP_Hack_Backdoored_Zlib_Zerodium_Mar21_1 : FILE
{
	meta:
		description = "Detects backdoored PHP zlib version"
		author = "Florian Roth (Nextron Systems)"
		id = "5e0ab8f8-776a-52b0-b5be-ff1d34bccfd1"
		date = "2021-03-29"
		modified = "2023-12-05"
		reference = "https://www.bleepingcomputer.com/news/security/phps-git-server-hacked-to-add-backdoors-to-php-source-code/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/vul_php_zlib_backdoor.yar#L2-L15"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "74bfd9e12cb7671cde953d361a2adeb9388edd9b2aab0f9ce04dce0d433561dc"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "REMOVETHIS: sold to zerodium, mid 2017" fullword ascii
		$x2 = "HTTP_USER_AGENTT" ascii fullword

	condition:
		filesize < 3000KB and all of them
}
rule SIGNATURE_BASE_EXPL_Keepass_CVE_2023_24055_Jan23 : CVE_2023_24055 FILE
{
	meta:
		description = "Detects suspicious entries in the Keepass configuration file, which could be indicator of the exploitation of CVE-2023-24055"
		author = "Florian Roth (Nextron Systems)"
		id = "2c031919-da19-5fd0-b21a-2e83679ad1e3"
		date = "2023-01-25"
		modified = "2023-12-05"
		reference = "https://github.com/alt3kx/CVE-2023-24055_PoC"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_keepass_cve_2023_24055.yar#L2-L20"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3ca00f317838819bb7fb80c9d00d94db498e1d3ef146b9af2664dae09302a86d"
		score = 75
		quality = 81
		tags = "CVE-2023-24055, FILE"

	strings:
		$a1 = "<TriggerCollection xmlns:xsi=" ascii wide
		$x1 = "<Parameter>KeePass XML (2.x)</Parameter>"
		$x2 = "::ReadAllBytes("
		$x3 = " -Method "
		$x4 = " bypass "
		$x5 = "powershell" nocase ascii wide fullword

	condition:
		filesize < 200KB and $a1 and 1 of ( $x* )
}
rule SIGNATURE_BASE_APT_MAL_Win_Bluelight : INKYSQUID
{
	meta:
		description = "The BLUELIGHT malware family. Leverages Microsoft OneDrive for network communications."
		author = "threatintel@volexity.com"
		id = "8bd45128-8b9a-40bb-a13f-3dec4e2a0626"
		date = "2021-04-23"
		modified = "2026-10-29"
		reference = "https://www.volexity.com/blog/2021/08/17/north-korean-apt-inkysquid-infects-victims-using-browser-exploits/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt37_bluelight.yar#L114-L144"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "7c40019c1d4cef2ffdd1dd8f388aaba537440b1bffee41789c900122d075a86d"
		hash = "94b71ee0861cc7cfbbae53ad2e411a76f296fd5684edf6b25ebe79bf6a2a600a"
		logic_hash = "52589348f42aadbe453ad8a40ac36b58fcc9e07cd298486f09b6f793823d8cc7"
		score = 75
		quality = 85
		tags = "INKYSQUID"
		license = "See license at https://github.com/volexity/threat-intel/LICENSE.txt"

	strings:
		$pdb1 = "\\Development\\BACKDOOR\\ncov\\"
		$pdb2 = "Release\\bluelight.pdb"
		$msg0 = "https://ipinfo.io" fullword
		$msg1 = "country" fullword
		$msg5 = "\"UserName\":\"" fullword
		$msg7 = "\"ComName\":\"" fullword
		$msg8 = "\"OS\":\"" fullword
		$msg9 = "\"OnlineIP\":\"" fullword
		$msg10 = "\"LocalIP\":\"" fullword
		$msg11 = "\"Time\":\"" fullword
		$msg12 = "\"Compiled\":\"" fullword
		$msg13 = "\"Process Level\":\"" fullword
		$msg14 = "\"AntiVirus\":\"" fullword
		$msg15 = "\"VM\":\"" fullword

	condition:
		any of ( $pdb* ) or all of ( $msg* )
}
rule SIGNATURE_BASE_APT_MAL_Maldoc_Cloudatlas_Oct20_1 : FILE
{
	meta:
		description = "Detects unknown maldoc dropper noticed in October 2020"
		author = "Florian Roth (Nextron Systems)"
		id = "e7caf2b2-caf2-5984-a792-8224f2641bda"
		date = "2020-10-13"
		modified = "2023-12-05"
		reference = "https://twitter.com/jfslowik/status/1316050637092651009"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cloudatlas.yar#L2-L16"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "7ba76b2311736dbcd4f2817c40dae78f223366f2404571cd16d6676c7a640d70"
		logic_hash = "772bdd8ec89edf2054e675e9ecb321a7bfe0307a7086a4e5b65f8d8b8cf80ecc"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "https://msofficeupdate.org" wide

	condition:
		uint16( 0 ) == 0xcfd0 and filesize < 300KB and 1 of ( $x* )
}
rule SIGNATURE_BASE_APT_MAL_URL_Cloudatlas_Oct20_2 : FILE
{
	meta:
		description = "Detects unknown maldoc dropper noticed in October 2020 - file morgue6visible5bunny6culvert7ambo5nun1illuminate4.url"
		author = "Florian Roth (Nextron Systems)"
		id = "91f6362f-1793-58a3-a750-04ec9812b9df"
		date = "2020-10-13"
		modified = "2023-12-05"
		reference = "https://twitter.com/jfslowik/status/1316050637092651009"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cloudatlas.yar#L18-L37"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "a6a58b614a9f5ffa1d90b5d42e15521f52e2295f02c1c0e5cd9cbfe933303bee"
		logic_hash = "8bb60c262a34babbe8839f5d39d1c972eeb41ea77eaae02cc877d908c7033f13"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$hc1 = { 5B 49 6E 74 65 72 6E 65 74 53 68 6F 72 74 63 75
               74 5D 0D 0A 55 52 4C 3D 68 74 74 70 73 3A 2F 2F
               6D 73 6F 66 66 69 63 65 75 70 64 61 74 65 2E 6F
               72 67 }

	condition:
		uint16( 0 ) == 0x495b and filesize < 200 and $hc1 at 0
}
rule SIGNATURE_BASE_EXPL_RAR_Archive_With_Path_Traversal_Aug25 : CVE_2025_8088 CVE_2025_6218 FILE
{
	meta:
		description = "Detects RAR archives abused for path traversal like CVE-2025-8088 and CVE-2025-6218"
		author = "Arnim Rupp (Nextron Systems)"
		id = "641c7e18-a887-5367-8584-2dc41c7ead53"
		date = "2025-08-11"
		modified = "2026-05-15"
		reference = "https://www.welivesecurity.com/en/eset-research/update-winrar-tools-now-romcom-and-others-exploiting-zero-day-vulnerability/#the-discovery-of-cve-2025-8088"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/exploit_rar_archive_with_path_traversal_aug25.yar#L1-L25"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "2a8fafa01f6d3863c87f20905736ebab28d6a5753ab708760c0b6cf3970828c3"
		hash = "dfab2f25c9d870f30bbc4abb873d155cf4904ece536714fb9cd32b2e0126dfab"
		hash = "107f3d1fe28b67397d21a6acca5b6b35def1aeb62a67bc10109bd73d567f9806"
		logic_hash = "eedc5cb144e516a1d50aa8cb2fa386cb44d4c6c2de89267dc1c4d14da972069d"
		score = 70
		quality = 85
		tags = "CVE-2025-8088, CVE-2025-6218, FILE"

	strings:
		$s1 = "..\\\\..\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu"
		$s2 = "..//../AppData/Roaming/Microsoft/Windows/Start Menu"
		$s3 = "/.. /.. /AppData/Roaming/Microsoft/Windows/Start Menu/"

	condition:
		1 of ( $s* ) and ( uint16( 0 ) == 0x4B50 or int32 ( 0 ) == 0x21726152 )
}
rule SIGNATURE_BASE_MAL_DOC_Zloader_Oct20_1 : FILE
{
	meta:
		description = "Detects weaponized ZLoader documents"
		author = "Florian Roth (Nextron Systems)"
		id = "34145746-9733-5dd9-9dcf-99e3a3ceee4f"
		date = "2020-10-10"
		modified = "2023-12-05"
		reference = "https://twitter.com/JohnLaTwC/status/1314602421977452544"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_zloader_maldocs.yar#L2-L22"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "668ca7ede54664360b0a44d5e19e76beb92c19659a8dec0e7085d05528df42b5"
		hash = "a2ffabbb1b5a124f462a51fee41221081345ec084d768ffe1b1ef72d555eb0a0"
		hash = "d268af19db475893a3d19f76be30bb063ab2ca188d1b5a70e51d260105b201da"
		logic_hash = "6f546a860361d3caff99c282465dbbd1880460c7491a1b5ad065c1b5d91e5d49"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$sc1 = { 78 4E FC 04 AB 6B 17 E2 33 E3 49 62 50 69 BB 60
               31 00 1E 00 02 4B BA E2 D8 E3 92 22 1E 69 96 20
               98 }
		$sc2 = { 6B 9E E2 36 E3 69 62 72 69 3A 60 55 6E }
		$sc3 = { 3E 69 76 60 59 6E 34 FB 87 6B 75 }

	condition:
		uint16( 0 ) == 0xcfd0 and filesize < 40KB and filesize > 30KB and all of them
}
rule SIGNATURE_BASE_SUSP_Appdomaininjection_Keyword_May26 : FILE
{
	meta:
		description = "Detects link files, archives and binaries that contain keywords related to AppDomain hijacking/injection a technique used by malware to sideload payloads."
		author = "Jonathan Peters (Nextron Systems)"
		id = "27e98663-c32e-4a7c-b473-7e30dfa97187"
		date = "2026-05-27"
		modified = "2026-10-29"
		reference = "https://attack.mitre.org/techniques/T1574/014/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/susp_generic_rules_may26.yar#L1-L21"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "eee657ffdb2af8ed6412221e7d5fbf4f5742f2ac2c88f43f12db46af0697de71"
		logic_hash = "a2a46b4f868235bf7f90c4e037a735cc670586f1f37aa4fe385ba4ded094848e"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "AppDomainInjection" ascii wide fullword
		$x2 = "AppDomainHijack" ascii wide fullword

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0x4b50 or uint32( 0x8000 ) == 0x30444301 or uint16( 0 ) == 0x004c and uint32( 4 ) == 0x00021401 ) and 1 of ( $x* )
}
rule SIGNATURE_BASE_SUSP_PE_Contains_Encrypted_Executable_May26 : FILE
{
	meta:
		description = "Detects executables containing an encrypted embedded payload using parameters commonly observed in malware, suggesting obfuscation or staged execution."
		author = "Jonathan Peters (Nextron Systems)"
		id = "b0430178-01ac-446f-9df3-553cb0f496dc"
		date = "2026-05-20"
		modified = "2026-10-29"
		reference = "https://www.nextron-systems.com/2026/06/01/detecting-nimbus-manticore-and-their-sideloading-infection-chains/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/susp_generic_rules_may26.yar#L23-L38"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "eee657ffdb2af8ed6412221e7d5fbf4f5742f2ac2c88f43f12db46af0697de71"
		logic_hash = "9fa6d5b569e28fa020d757fdbb4ae97a80d1ba54ee6a78d5bacb981adf044e88"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$op = { ae b6 8d 86 71 f0 a9 c8 90 66 53 31 ef 7f 1f d2 b4 a8 21 bc 39 77 c2 c2 60 db 24 4a 12 32 f9 69 09 09 46 22 a6 d1 0a 5e a7 dc 62 fa 96 56 ad dd }

	condition:
		uint16( 0 ) == 0x5a4d and 1 of them
}
rule SIGNATURE_BASE_HKTL_Sentinelone_Remotepotato0_Privesc : FILE
{
	meta:
		description = "Detects RemotePotato0 binary"
		author = "SentinelOne"
		id = "f6dffd6b-e794-5c4a-9700-5c2022168f44"
		date = "2021-04-26"
		modified = "2023-12-05"
		reference = "https://labs.sentinelone.com/relaying-potatoes-dce-rpc-ntlm-relay-eop"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_remote_potato0.yar#L2-L17"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f3a3a917908af6260f40b217f966750a095140abb6bf85cf3a728725bc16996f"
		score = 75
		quality = 79
		tags = "FILE"

	strings:
		$import1 = "CoGetInstanceFromIStorage"
		$istorage_clsid = "{00000306-0000-0000-c000-000000000046}" nocase wide ascii
		$meow_header = { 4d 45 4f 57 }
		$clsid1 = "{11111111-2222-3333-4444-555555555555}" wide ascii
		$clsid2 = "{5167B42F-C111-47A1-ACC4-8EABE61B0B54}" nocase wide ascii

	condition:
		( uint16( 0 ) == 0x5A4D ) and $import1 and $istorage_clsid and $meow_header and 1 of ( $clsid* )
}
rule SIGNATURE_BASE_HKTL_Redsun_Privilege_Escalation_Apr26 : FILE
{
	meta:
		description = "Detects RedSun hacktool used for privilege escalation through Microsoft Defender."
		author = "Jonathan Peters (cod3nym)"
		id = "64f86635-cf8c-5c65-b821-2d12e8ee9cdb"
		date = "2026-04-16"
		modified = "2026-05-15"
		reference = "https://github.com/Nightmare-Eclipse/RedSun"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/hktl_redsun_apr26.yar#L1-L25"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "57a70c383feb9af60b64ab6768a1ca1b3f7394b8c5ffdbfafc8e988d63935120"
		logic_hash = "fb756b0ec61e141fecaf8fc795d10818f4016955dda68772310f8249282f2438"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "\\??\\pipe\\REDSUN" wide
		$x2 = "The red sun shall prevail.\n" ascii fullword
		$x3 = "\\RedSun.pdb" ascii
		$s1 = "\\System32\\TieringEngineService.exe" wide
		$s2 = "SERIOUSLYMSFT" wide
		$s3 = "*H+H$!ELIF-TSET-SURIVITNA-DRADNATS-RACIE$}7)CC7)^P(45XZP\\4[PA@%P!O5X" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $x* ) or 2 of ( $s* ) ) or 3 of them
}
rule SIGNATURE_BASE_APT_UA_Hermetic_Wiper_Feb22_1 : FILE
{
	meta:
		description = "Detects Hermetic Wiper malware"
		author = "Florian Roth (Nextron Systems)"
		id = "2cbe4a69-e31a-5f5f-ab1a-9d71d16fb30f"
		date = "2022-02-24"
		modified = "2023-12-05"
		reference = "https://www.sentinelone.com/labs/hermetic-wiper-ukraine-under-attack/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ua_hermetic_wiper.yar#L2-L38"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0385eeab00e946a302b24a91dea4187c1210597b8e17cd9e2230450f5ece21da"
		hash = "3c557727953a8f6b4788984464fb77741b821991acbf5e746aebdd02615b1767"
		hash = "2c10b2ec0b995b88c27d141d6f7b14d6b8177c52818687e4ff8e6ecf53adf5bf"
		hash = "1bc44eef75779e3ca1eefb8ff5a64807dbc942b1e4a2672d77b9f6928d292591"
		logic_hash = "1cf124f7533a060da8aff1a18f64a94b183502e58ffdfca012d72d99d30225ba"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$xc1 = { 00 5C 00 5C 00 2E 00 5C 00 50 00 68 00 79 00 73
               00 69 00 63 00 61 00 6C 00 44 00 72 00 69 00 76
               00 65 00 25 00 75 00 00 00 5C 00 5C 00 2E 00 5C
               00 45 00 50 00 4D 00 4E 00 54 00 44 00 52 00 56
               00 5C 00 25 00 75 00 00 00 5C 00 5C 00 2E 00 5C
               00 00 00 00 00 25 00 73 00 25 00 2E 00 32 00 73
               00 00 00 00 00 24 00 42 00 69 00 74 00 6D 00 61
               00 70 00 00 00 24 00 4C 00 6F 00 67 00 46 00 69
               00 6C 00 65 }
		$sc1 = { 00 44 00 72 00 69 00 76 00 65 00 72 00 73 00 00
               00 64 00 72 00 76 00 00 00 53 00 79 00 73 00 74
               00 65 00 6D 00 33 00 32 }
		$s1 = "\\\\?\\C:\\Windows\\System32\\winevt\\Logs" wide fullword
		$s2 = "\\\\.\\EPMNTDRV\\%u" wide fullword
		$s3 = "DRV_XP_X64" wide fullword
		$s4 = "%ws%.2ws" wide fullword
		$op1 = { 8b 7e 08 0f 57 c0 8b 46 0c 83 ef 01 66 0f 13 44 24 20 83 d8 00 89 44 24 18 0f 88 3b 01 00 00 }
		$op2 = { 13 fa 8b 55 f4 4e 3b f3 7f e6 8a 45 0f 01 4d f0 0f 57 c0 }

	condition:
		( uint16( 0 ) == 0x5a53 or uint16( 0 ) == 0x5a4d ) and filesize < 400KB and ( 1 of ( $x* ) or 3 of them )
}
rule SIGNATURE_BASE_APT_UA_Hermetic_Wiper_Artefacts_Feb22_1
{
	meta:
		description = "Detects artefacts found in Hermetic Wiper malware related intrusions"
		author = "Florian Roth (Nextron Systems)"
		id = "77f793c1-b02c-59c3-b3e4-75758f5b3b8d"
		date = "2022-02-25"
		modified = "2023-12-05"
		reference = "https://symantec-enterprise-blogs.security.com/blogs/threat-intelligence/ukraine-wiper-malware-russia"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ua_hermetic_wiper.yar#L40-L70"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "5e917618a5172c68b4b32ba9e63402c2a98ccb027276b317ec169a4fef219de1"
		score = 75
		quality = 85
		tags = ""

	strings:
		$sx1 = "/c powershell -c \"rundll32 C:\\windows\\system32\\comsvcs.dll MiniDump" ascii wide
		$sx2 = "appdata\\local\\microsoft\\windows\\winupd.log" ascii wide
		$sx3 = "AppData\\Local\\Microsoft\\Windows\\Winupd.log" ascii wide
		$sx4 = "CSIDL_SYSTEM_DRIVE\\temp\\sys.tmp1" ascii wide
		$sx5 = "\\policydefinitions\\postgresql.exe" ascii wide
		$sx6 = "powershell -v 2 -exec bypass -File text.ps1" ascii wide
		$sx7 = "powershell -exec bypass gp.ps1" ascii wide
		$sx8 = "powershell -exec bypass -File link.ps1" ascii wide
		$sx9 = " 1> \\\\127.0.0.1\\ADMIN$\\__16" ascii wide
		$sa1 = "(New-Object System.Net.WebClient).DownloadFile(" ascii wide
		$sa2 = "CSIDL_SYSTEM_DRIVE\\temp\\" ascii wide
		$sa3 = "1> \\\\127.0.0.1\\ADMIN$" ascii wide
		$fp1 = "<html" ascii

	condition:
		1 of ( $sx* ) or all of ( $sa* ) and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_APT_UA_Hermetic_Wiper_Scheduled_Task_Feb22_1
{
	meta:
		description = "Detects scheduled task pattern found in Hermetic Wiper malware related intrusions"
		author = "Florian Roth (Nextron Systems)"
		id = "a628f773-9c71-5979-a4db-37b6b6bd6a56"
		date = "2022-02-25"
		modified = "2023-12-05"
		reference = "https://symantec-enterprise-blogs.security.com/blogs/threat-intelligence/ukraine-wiper-malware-russia"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ua_hermetic_wiper.yar#L72-L88"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "56368ba1c97fe3455312b6ee86dcd1a21677f7dfa3836e76ada4b236a5b2c171"
		score = 85
		quality = 85
		tags = ""

	strings:
		$a0 = "<Task version=" ascii wide
		$sa1 = "CSIDL_SYSTEM_DRIVE\\temp" ascii wide
		$sa2 = "postgresql.exe 1> \\\\127.0.0.1\\ADMIN$" ascii wide
		$sa3 = "cmd.exe /Q /c move CSIDL_SYSTEM_DRIVE" ascii wide

	condition:
		$a0 and 1 of ( $s* )
}
rule SIGNATURE_BASE_HKTL_EXPL_WIN_PS1_Badsuccessor_May25 : FILE
{
	meta:
		description = "Detects PowerShell tool called Get-BadSuccessorOUPermissions.ps1 that helps exploit a vulnerability in Active Directory. Lists every principal that can perform a BadSuccessor attack and the OUs where it holds the required permissions."
		author = "Florian Roth"
		id = "4f6ff5ff-831a-520c-8bc5-6fec5e65f9de"
		date = "2025-05-22"
		modified = "2026-05-15"
		reference = "https://www.akamai.com/blog/security-research/abusing-dmsa-for-privilege-escalation-in-active-directory"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/hktl_badsuccessor_helper_may25.yar#L2-L16"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a023bced4aec2b2c601088367766f42a3fcf36053c7eb92985cc7468c7cd6cb0"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "function Get-BadSuccessorOUPermissions" ascii wide
		$x2 = "\"0feb936f-47b3-49f2-9386-1dedc2c23765\"=\"msDS-DelegatedManagedServiceAccount\"" ascii wide
		$x3 = "CreateChild|GenericAll|WriteDACL|WriteOwner" ascii wide

	condition:
		filesize < 20MB and 1 of them
}
rule SIGNATURE_BASE_EXPL_Log4J_CVE_2021_44228_Dec21_Hard : FILE CVE_2021_44228
{
	meta:
		description = "Detects indicators in server logs that indicate the exploitation of CVE-2021-44228"
		author = "Florian Roth"
		id = "5297c42d-7138-507d-a3eb-153afe522816"
		date = "2021-12-10"
		modified = "2025-03-20"
		reference = "https://twitter.com/h113sdx/status/1469010902183661568?s=20"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_log4j_cve_2021_44228.yar#L118-L140"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9a4fc285dd1680ebc8a1042eeb5fbba73b9e2df70678adf3163122d84405325e"
		score = 65
		quality = 85
		tags = "FILE, CVE-2021-44228"

	strings:
		$x1 = /\$\{jndi:(ldap|ldaps|rmi|dns|iiop|http|nis|nds|corba):\/[\/]?[a-z-\.0-9]{3,120}:[0-9]{2,5}\/[a-zA-Z\.]{1,32}\}/
		$x2 = "Reference Class Name: foo"
		$fp1r = /(ldap|rmi|ldaps|dns):\/[\/]?(127\.0\.0\.1|192\.168\.|172\.[1-3][0-9]\.|10\.)/
		$fpg2 = "<html"
		$fpg3 = "<HTML"
		$fp1 = "/QUALYSTEST" ascii
		$fp2 = "w.nessus.org/nessus"
		$fp3 = "/nessus}"

	condition:
		1 of ( $x* ) and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_SUSP_Base64_Encoded_Exploit_Indicators_Dec21 : CVE_2021_44228
{
	meta:
		description = "Detects base64 encoded strings found in payloads of exploits against log4j CVE-2021-44228"
		author = "Florian Roth (Nextron Systems)"
		id = "09abc4f0-ace7-5f53-b1d3-5f5c6bf3bdba"
		date = "2021-12-10"
		modified = "2021-12-13"
		reference = "https://twitter.com/Reelix/status/1469327487243071493"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_log4j_cve_2021_44228.yar#L142-L165"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "703a83916c7279bcdc3cd61602472c2a3815140235be169f5b2063a547438c61"
		score = 70
		quality = 85
		tags = "CVE-2021-44228"

	strings:
		$sa1 = "Y3VybCAtcy"
		$sa2 = "N1cmwgLXMg"
		$sa3 = "jdXJsIC1zI"
		$sb1 = "fHdnZXQgLXEgLU8tI"
		$sb2 = "x3Z2V0IC1xIC1PLS"
		$sb3 = "8d2dldCAtcSAtTy0g"
		$fp1 = "<html"

	condition:
		1 of ( $sa* ) and 1 of ( $sb* ) and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_SUSP_Jdniexploit_Indicators_Dec21 : FILE
{
	meta:
		description = "Detects indicators of JDNI usage in log files and other payloads"
		author = "Florian Roth (Nextron Systems)"
		id = "2df8b8f3-8d8d-5982-8c85-692b7d91ebb2"
		date = "2021-12-10"
		modified = "2021-12-12"
		reference = "https://github.com/flypig5211/JNDIExploit"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_log4j_cve_2021_44228.yar#L167-L180"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7886a67672001f0db72575d96d3a12341bfcdc49a9951e3d5e2a88ab46bf5a5d"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$xr1 = /(ldap|ldaps|rmi|dns|iiop|http|nis|nds|corba):\/\/[a-zA-Z0-9\.]{7,80}:[0-9]{2,5}\/(Basic\/Command\/Base64|Basic\/ReverseShell|Basic\/TomcatMemshell|Basic\/JBossMemshell|Basic\/WebsphereMemshell|Basic\/SpringMemshell|Basic\/Command|Deserialization\/CommonsCollectionsK|Deserialization\/CommonsBeanutils|Deserialization\/Jre8u20\/TomcatMemshell|Deserialization\/CVE_2020_2555\/WeblogicMemshell|TomcatBypass|GroovyBypass|WebsphereBypass)\//

	condition:
		filesize < 100MB and $xr1
}
rule SIGNATURE_BASE_SUSP_Jdniexploit_Error_Indicators_Dec21_1
{
	meta:
		description = "Detects error messages related to JDNI usage in log files that can indicate a Log4Shell / Log4j exploitation"
		author = "Florian Roth (Nextron Systems)"
		id = "68bcf043-58b4-54a9-b024-64871b5d535f"
		date = "2021-12-10"
		modified = "2023-06-23"
		reference = "https://twitter.com/marcioalm/status/1470361495405875200?s=20"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_log4j_cve_2021_44228.yar#L213-L226"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "2ab98814b2ed66b0bda875fecc0b09db82035d7edcdb0af65f815817ec8c6cc8"
		score = 70
		quality = 85
		tags = ""

	strings:
		$x1 = "FATAL log4j - Message: BadAttributeValueException: "

	condition:
		1 of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Fakefilemaker : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "2c87114f-5295-583f-b567-623d478ce0eb"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/DamonMohammadbagher/FakeFileMaker"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L3-L16"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "27d402835f31b6383c837e90248ae5c6d22f4c267d52625ebfbcc2ee5099ccad"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "FakeFileMaker" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Wmipersistence : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "7a674596-c697-569d-a16c-3cefe4ff752a"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/mdsecactivebreach/WMIPersistence"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L18-L31"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f8f5e1b6d9b9e8e2f76a7e02385142bbeb755d1b1e41e501f4f74fcaba0a7dad"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "WMIPersistence" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_Adcollector_Sep22_1 : FILE
{
	meta:
		description = "Detects ADCollector Tool - a lightweight tool to quickly extract valuable information from the Active Directory environment for both attacking and defending"
		author = "Florian Roth (Nextron Systems)"
		id = "48b376e4-752b-523e-b34e-65b6944c33fb"
		date = "2022-09-15"
		modified = "2026-02-23"
		reference = "https://github.com/dev-2null/ADCollector"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L55-L75"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "241390219a0a773463601ca68b77af97453c20af00a66492a7a78c04d481d338"
		hash = "cc086eb7316e68661e3d547b414890d5029c5cc460134d8b628f4b0be7f27fb3"
		logic_hash = "66d5363e885378c442e7532f69d4c36618d7a0f5dbe67490631d1ed5078d3fba"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "ADCollector.exe --SPNs --Term key --Acls 'CN=Domain Admins,CN=Users,DC=lab,DC=local'" wide fullword
		$s1 = "ADCollector.exe" wide fullword
		$s2 = "ENCRYPTED_TEXT_PASSWORD_ALLOWED" ascii fullword
		$s3 = "\\Policies\\{31B2F340-016D-11D2-945F-00C04FB984F9}\\MACHINE\\Microsoft\\Windows NT\\SecEdit\\GptTmpl.inf" wide
		$s4 = "[-] Password Does Not Expire Accounts:" wide
		$s5 = "  * runAs:       {0}" wide fullword

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 300KB and ( 1 of ( $x* ) or 3 of them )
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Maliciousclickoncegenerator : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "683af3b4-4c91-5ff3-96bf-d5c1d9c19cc2"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/Mr-Un1k0d3r/MaliciousClickOnceGenerator"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L77-L90"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "91e5878d49ad9af5420d4e29afaa600337fb8051951598a997cd74d72c884206"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "MaliciousClickOnceGenerator" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Directinjectorpoc : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "d9a430d7-b062-554b-aff4-cfd98d91e9fe"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/badBounty/directInjectorPOC"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L92-L105"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ffdc5694668af6c82b493403373d2e2e915e45bca8d58ec1ab41c5a8bd28d781"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "directInjectorPOC" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Asstrongasfuck : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "4c63c8a2-5889-5177-9f66-8e5f755025a3"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/Charterino/AsStrongAsFuck"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L107-L120"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4765f2099bf8fa8ebccd8cdcc561354f4aeba28c2473fd8556f1ef1d5d28dadd"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "AsStrongAsFuck" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Magentoscanner : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "db3912bd-574c-57e2-a9b6-4b440d144471"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/soufianetahiri/MagentoScanner"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L122-L135"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "245dce3be07c8e84dfcd2cdb2d9f24406a9b11b437e74969f1472a6ee149fd9c"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "MagentoScanner" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Revengerat_Stub_Cssharp : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "06dce4f9-4d7a-5976-a87a-07c539e5dbe8"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/NYAN-x-CAT/RevengeRAT-Stub-CSsharp"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L137-L150"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a3bd1f8e52e6ed468b6a4fea83456ca813b69e2d676dfab687bbea5a746fed3c"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "RevengeRAT-Stub-CSsharp" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Sharpyshell : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "3069c5eb-446e-5bfa-9df0-2e03f229d4d1"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/antonioCoco/SharPyShell"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L152-L165"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "89d0010c08349f8982c7f5aa5f7855702556ce10f9f3b5b18b61349c5233e001"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "SharPyShell" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Ghostloader : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "d8d88f3f-f250-55ff-88a6-4623e12ef89d"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/TheWover/GhostLoader"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L167-L180"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "91527b4b35f2bb1aeee236647c5169c67f2b9cfb867f2b6d486bd8d8b7455d4b"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "GhostLoader" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Dotnetinject : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "468f89c4-5b94-53be-b9e6-ad21de7d98ba"
		date = "2021-01-22"
		modified = "2022-06-28"
		reference = "https://github.com/dtrizna/DotNetInject"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L182-L202"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "07ba4ba23372dbc2618dcea89ef643cd68371ace1116bfeb939b0f9adfc425bb"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "DotNetInject" ascii wide
		$compile = "AssemblyTitle" ascii wide
		$fp1 = "GetDotNetInjector" ascii
		$fp2 = "JetBrains.TeamCity.Injector." wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and filesize < 20MB and $name and $compile and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Atpminidump : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "97981569-fe94-5600-8319-946edb4265e7"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/b4rtik/ATPMiniDump"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L204-L217"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7498ed5d11b9c3646ebd2d1330a239c43e9c5b270b1778871c2821a2fefb5137"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "ATPMiniDump" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Sharpbuster : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "d30c8ee5-88b9-53b5-b209-51f6f3b988cf"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/passthehashbrowns/SharpBuster"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L236-L249"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "cdc19e03f75f34e6349937c0bff313298fc9310f361eec7af022c450d083ad96"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "SharpBuster" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Recon_AD : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "097de5cd-0cd4-59cc-a7b7-54cad8e6d230"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/outflanknl/Recon-AD"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L273-L286"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7bfafb2d3e85bb584bd02cb92457d22b07626f71d071c44a4aefbb5748045446"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "Recon-AD" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Sharpwatchdogs : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "5343be58-879a-5fe7-9036-ee6a22d85f22"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/RITRedteam/SharpWatchdogs"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L288-L301"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3b9410d7e502a5fd55e534d8fe79710d48cf65a0e9859bdd0fea6c8d32311df0"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "SharpWatchdogs" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Sharpcat : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "a46be8d3-bf7b-5d86-b88b-33e6c8c152d8"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/Cn33liz/SharpCat"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L303-L316"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b9e5946f8df1649e71abf014aa6579edbbc93a12ddcc56f8d85d97ae087c8711"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "SharpCat" ascii wide fullword
		$compile = "AssemblyTitle" ascii wide fullword

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_K8Tools : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "b30fc856-073d-542f-b222-a957322732c2"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/k8gege/K8tools"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L318-L331"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "370cab83917bbc76f7f3a1b7793773ddf139879880e55efe59c72a07b34120f1"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "K8tools" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Httpsbeaconshell : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "3bd7234b-a23e-5818-aed1-52d42023943b"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/limbenjamin/HTTPSBeaconShell"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L333-L346"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6a0d7e1f796ae6cefa297978c743916a08b2406c37fa2c1f3f697a17cb032517"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "HTTPSBeaconShell" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Ghostpack_Compiledbinaries : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "7cc81894-8c01-5a17-a7ed-1cb4cf1e2d53"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/r3motecontrol/Ghostpack-CompiledBinaries"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L348-L361"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a8e90f07b7d1ec309e51e3606169a05c4bb2b2aa7e31ca26b21f927d648c13cd"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "Ghostpack-CompiledBinaries" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Metasploit_Sharp : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "b425f241-4887-5368-b42b-3fbbd3b769c6"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/VolatileMindsLLC/metasploit-sharp"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L363-L376"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7a1c4e077e197a5cdca8cb12713abb3fa86a3f6ea8e8f2f632c9c8e42d829acc"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "metasploit-sharp" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Trevorc2 : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "d1634a0d-6964-5886-b836-85c3ce6b8a17"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/trustedsec/trevorc2"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L378-L391"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c1d56ef865e6619d9d0deff90b154c63cc3036a8521d3952819e45f51fca9fea"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "trevorc2" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Nativepayload_DNS2 : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "0fa01355-de57-573e-9056-0b7a5d24572d"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/DamonMohammadbagher/NativePayload_DNS2"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L393-L406"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "765e6117f69fb58e5e71544badc8135b2ec641a74cc0489a7c79308ca2837bd7"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "NativePayload_DNS2" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Aggressiveproxy : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "e2d3c4e2-404b-59f8-b3d0-a7cef4dfd0ff"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/EncodeGroup/AggressiveProxy"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L408-L421"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "702b0cc858cb1687962ac403a730e5f778bf51fc91627c50103e4299f4a3ca5f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "AggressiveProxy" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Msbuildapicaller : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "143da57f-b01f-5688-b741-1bc4d06cd7d1"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/rvrsh3ll/MSBuildAPICaller"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L423-L436"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3c1f33c759e6331c562dbf76ce7e34ee82d10070e331d0967143d9d7fad077fc"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "MSBuildAPICaller" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Graykeylogger : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "c63875b6-1701-5594-927e-833c25dc5d98"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/DarkSecDevelopers/GrayKeylogger"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L438-L451"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b8e12c5ddf0d50d0b3681594c8bc3410a24dab00035a5959e20d20045dacbbbd"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "GrayKeylogger" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Weevely3 : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "6bf766b6-d065-5a84-8258-3be448b9cbb8"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/epinna/weevely3"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L453-L466"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c57c6ba5276679a2d32e9b0ebb61059c5bed1ba45f9792ecef3d5c7244f38f24"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "weevely3" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Fudgec2 : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "a8e70bce-76dd-53dc-9a19-1cc6795fdef3"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/Ziconius/FudgeC2"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L468-L481"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "89f3bf4b81a901e813c3021422c362d7e075dec7fd76240be121f677039f1994"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "FudgeC2" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Nativepayload_Reverse_Tcp : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "a6b935cc-adb6-5ff4-a832-1043e77292f7"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/DamonMohammadbagher/NativePayload_Reverse_tcp"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L483-L496"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "055ee105cd46e54b4f49dd92975ecc08a6184fa8508585ee528d19de34914758"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "NativePayload_Reverse_tcp" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Sharphose : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "89b00eb0-f1a2-5c77-a5b0-2329b08aadb7"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/ustayready/SharpHose"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L498-L511"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e3af2a156c2451f7ed2fe3e888fdf2ae080298f7eff56801ddc0c612f04902ee"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "SharpHose" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_RAT_Njrat_0_7D_Modded_Source_Code : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "2b7d1f75-0164-561e-8199-32c601cbca98"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/AliBawazeEer/RAT-NjRat-0.7d-modded-source-code"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L513-L526"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f437195348452242adc8b55d6d517a17764c53188fa2de5cd15848fd23827381"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "RAT-NjRat-0.7d-modded-source-code" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Rdpthief : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "5ad4feec-50db-5ebb-a609-9196e72a24aa"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/0x09AL/RdpThief"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L528-L541"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8e472c8265d517e512eada819627d56ff449fae4d80054946e9ea96f74004f05"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "RdpThief" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Runascs : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "c5fc5b01-1d30-5af5-be99-e629cb23295b"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/antonioCoco/RunasCs"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L543-L556"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9fd22a3e92222134c101693b944a2ad53055f9cfafe99823fd6f412981f5afa3"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "RunasCs" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Nativepayload_IP6DNS : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "3b32b408-e71a-5f2a-ae6f-72a3d6572b71"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/DamonMohammadbagher/NativePayload_IP6DNS"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L558-L571"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "509c396b97524335735107644460eebed3146b2bc5f8dedb909c9754b2121f5f"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "NativePayload_IP6DNS" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Nativepayload_ARP : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "9fac11f8-4e40-5cbc-a990-2ae48df20828"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/DamonMohammadbagher/NativePayload_ARP"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L573-L586"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e8cecfe09f1cb80eb693eb293dfb8c1bc3885a96dfa045b2391216c5f6f6f983"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "NativePayload_ARP" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_C2Bridge : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "357051aa-61ea-5454-a996-b4e3a45ac865"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/cobbr/C2Bridge"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L588-L601"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d5f6d6e9d475bf2d8a49d7550bf3b718539753f3494b58462094bfc0a37b813a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "C2Bridge" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Infrastructure_Assessment : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "efacc12b-92b3-5b22-b5bb-cd5a7d7eea0e"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/NyaMeeEain/Infrastructure-Assessment"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L603-L616"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7b2f1481c2880b5b3ee158f2a526ab7fc5e587bbf3847ebe9ddf447742109a78"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "Infrastructure-Assessment" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Gray_Hat_Csharp_Code : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "0a94cadc-cc7b-5817-8788-bb1e53937fad"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/brandonprry/gray_hat_csharp_code"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L633-L646"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4520528cd6b1832c97fa79442f9d448d54bad4e6944984fa6e71f34246259e28"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "gray_hat_csharp_code" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Nativepayload_Reverseshell : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "eec77c09-02db-5d74-8526-e201d2fe6fc8"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/DamonMohammadbagher/NativePayload_ReverseShell"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L648-L661"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "79ebde95674d76e58938b06a97cb6c65e6ac0606398fc9c30d90e517bbdd62a8"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "NativePayload_ReverseShell" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Dotnetavbypass : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "918eba2b-150d-5e69-bed0-0979ae889165"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/mandreko/DotNetAVBypass"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L663-L676"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "574a5f1bc1873321042e932ddfd53853e8e06dff3b25f2ad41e6b8aaf150a8b2"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "DotNetAVBypass" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Hexyrunner : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "67741b4d-7336-5c88-8f2c-e48c10b187b9"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/bao7uo/HexyRunner"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L678-L691"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c55be1fe285358378a98fd1027650dd20dd8cd0aad4dc062df7a0d4538c78c3b"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "HexyRunner" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Sharpoffensiveshell : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "f223fb95-9f16-5504-a6ce-de9d75b38eaa"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/darkr4y/SharpOffensiveShell"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L693-L706"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "36bcae7817eed375e48822a49e6875295ea1037217231a7f9ae88a9b8af95530"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "SharpOffensiveShell" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Reconness : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "a30188e4-d96a-59d0-9f51-d7a7e07b14ba"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/reconness/reconness"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L708-L721"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9cb7a3522bada1c724999058ec4ddfde09b22166f8fb3ba184dfe6bec276cfc5"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "reconness" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Tvasion : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "324cddc6-36d9-5670-827e-24e80dcc66a9"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/loadenmb/tvasion"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L723-L736"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b6262f751cbb85e702d89e7c5b4efdc8eaf3085101cd7685218ab1e8a2599385"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "tvasion" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Ibombshell : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "02f3272f-8e75-5df4-9052-a315ae202050"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/Telefonica/ibombshell"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L738-L751"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "30de65328e2e2230eca3a30490e20c2c6d8ac9bdc835ee15d44300a00b801921"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "ibombshell" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Remoteprocessinjection : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "f1698cf2-211a-551a-8bc4-4faefcc6106f"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/Mr-Un1k0d3r/RemoteProcessInjection"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L753-L766"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "87d803c361462877f5ebba2a70f611c95b8684fe9f9f747ccf9643fc4e97d9df"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "RemoteProcessInjection" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_CACTUSTORCH : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "7b1e3015-fada-592c-b120-20aa12247d32"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/mdsecactivebreach/CACTUSTORCH"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L768-L781"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "51a125a44b5d1e73509bcd29865b26f44a5ee53f6907ee9abffa3eef1bbbdea8"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "CACTUSTORCH" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Pandasniper : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "006400fb-7e6d-563b-ba78-17937983c9ba"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/QAX-A-Team/PandaSniper"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L783-L796"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "c5a32f22a429777186d88f3fcfa79ad4d971e86ebd6117df74aae19728c6addd"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "PandaSniper" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Xbapappwhitelistbypasspoc : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "b05253ce-cba4-531d-8f39-d8fae71b114d"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/jpginc/xbapAppWhitelistBypassPOC"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L798-L811"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3c79b70d3a72084dff391ba297518c4fe748d35b794278c4edf2d1faa4bd216e"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "xbapAppWhitelistBypassPOC" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_HKTL_NET_NAME_Stagestrike : FILE
{
	meta:
		description = "Detects .NET red/black-team tools via name"
		author = "Arnim Rupp"
		id = "e3f9de04-87f6-5b07-b5b0-a26167937fcc"
		date = "2021-01-22"
		modified = "2026-02-23"
		reference = "https://github.com/RedXRanger/StageStrike"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_github_net_redteam_tools_names.yar#L813-L826"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "99abc2fee732f27ea94c8ce244dc1742ed01a7753adedd7e80226d1e1c8dee4a"
		score = 75
		quality = 85
		tags = "FILE"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"

	strings:
		$name = "StageStrike" ascii wide
		$compile = "AssemblyTitle" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule SIGNATURE_BASE_WEBSHELL_JAVA_Versamem_JAR_Aug24_1 : FILE
{
	meta:
		description = "Detects VersaMem Java webshell samples (as used by Volt Typhoon)"
		author = "blacklotuslabs (modified by Florian Roth and X__Junior)"
		id = "9b666e61-cfa8-58b3-a362-772cd907c57c"
		date = "2024-08-27"
		modified = "2024-08-29"
		reference = "https://x.com/ryanaraine/status/1828440883315999117"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_volttyphoon_versamem.yar#L2-L24"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d21558eb6c8e700b8a4cb86fdaa5487179828152af68828e878397859d6d3952"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$sa1 = "com.versa.vnms.ui.TestMain"
		$sa2 = "captureLoginPasswordCode"
		$sa3 = "com/versa/vnms/ui/services/impl/VersaAuthenticationServiceImpl"
		$sa4 = "/tmp/.temp.data"
		$sa5 = "getInsertCode"
		$sa6 = "VersaMem"
		$sa7 = "Versa-Auth"
		$sb1 = "/tmp/.java_pid"
		$sb2 = {2f 75 73 72 2f 62 69 6e 2f 70 67 72 65 70 01 00 02 2d 66 01 00 25 6f 72 67 2e 61 70 61 63 68 65 2e 63 61 74 61 6c 69 6e 61 2e 73 74 61 72 74 75 70 2e 42 6f 6f 74 73 74 72 61 70 07}

	condition:
		filesize < 5MB and ( 3 of them or all of ( $sb* ) )
}
rule SIGNATURE_BASE_APT_MAL_APT27_Rshell_Jul24 : MALWARE RSHELL___SYSUPDATE FILE
{
	meta:
		description = "YARA rule to detect RSHELL of APT27"
		author = "Bundesamt fuer Verfassungsschutz, modified by Florian Roth"
		id = "67c8ac4e-8e2f-5cca-90cb-5d5fdf6f86b5"
		date = "2024-07-11"
		modified = "2024-12-12"
		reference = "https://x.com/bfv_bund/status/1811364839656185985?s=12&t=C0_T_re0wRP_NfKa27Xw9w"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt27_rshell.yar#L2-L41"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0433edfad648e1e29be54101abaded690302dc7e49ad916cfbbddf99b3ade12c"
		hash = "10bb89fdf25c88d3c5623e8d68573124c9a42549750014e3675e2ca342aeba4a"
		hash = "2603e1f61363451891c97b0c4ce8acfbfb680d3df4282f9d151ecce3a5679616"
		hash = "70dac42491f8f19568a5d7b1d10b29f732a88d75e7f2bfa07b23202bacadf56f"
		hash = "b988a6583ce40f07e5fc8e890ae2b1c84a93db8a2e3ca8769241b94bea332a7a"
		hash = "c4fe1e56f601d411e2385352606524fb8bbf773bc2ba14889a8de605c2d14da0"
		hash = "c787144d285fcca8a542f7a5525a37bcd089b39068b9a4db7fe3554ee6c08301"
		hash = "ddaa4d23e4651a517fffbd29f0924607ba6b6253171144da5e49237afe91666b"
		logic_hash = "be5f6281d722bd07e53acd459c794fe3ae870a05ed8979de4c28d357110617bd"
		score = 75
		quality = 85
		tags = "MALWARE, RSHELL / SYSUPDATE, FILE"
		sharing = "TLP:WHITE"
		category = "MALWARE"
		malware = "RSHELL / SYSUPDATE"

	strings:
		$a1 = "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%" ascii
		$a2 = "/proc/self/exe" ascii
		$s1 = "HISTFILE" ascii fullword
		$s2 = "/tmp/guid" ascii fullword
		$sop1 = { e8 ?? ?? ?? ?? c7 43 04 00 00 00 00 8b 3b 85 ff 7e 2? e8 ?? ?? 0? 00 85 c0 7e 0? }
		$sop2 = { c7 43 04 00 00 00 00 8b 3b 85 ff 7e 2? e8 ?? ?? 0? 00 85 c0 7e 0? f7 d8 }

	condition:
		( uint32be( 0 ) == 0x7f454c46 or ( uint32be( 0 ) == 0xcafebabe and uint32be( 4 ) < 0x20 ) or uint32( 0 ) == 0xfeedface or uint32( 0 ) == 0xfeedfacf ) and filesize < 2MB and all of ( $a* ) and 2 of ( $s* ) or 3 of ( $s* )
}

rule SIGNATURE_BASE_VULN_Printerdriver_Privesc_CVE_2021_3438_Jul21 : FILE
{
	meta:
		description = "Detects affected drivers with PE timestamps older than the date of the initial report"
		author = "Florian Roth (Nextron Systems)"
		id = "34cd648a-3e3f-5832-8abe-18507931eb3d"
		date = "2021-07-20"
		modified = "2023-12-05"
		reference = "https://labs.sentinelone.com/cve-2021-3438-16-years-in-hiding-millions-of-printers-worldwide-vulnerable/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/vul_cve_2021_3438_printdriver.yar#L4-L22"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "7cc9ba2df7b9ea6bb17ee342898edd7f54703b93b6ded6a819e83a7ee9f938b4"
		logic_hash = "b58c2623c8fb84162c1c9390d0398639061ed5b1d4a8e007685e6fabe42bde54"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "This String is from Device Driver@@@@@ !!!" ascii
		$s2 = "\\DosDevices\\ssportc" wide fullword

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 400KB and all of ( $s* ) and 1613606400 >= pe.timestamp
}
rule SIGNATURE_BASE_MAL_Qbot_HTML_Smuggling_Indicators_Oct22_1 : FILE
{
	meta:
		description = "Detects double encoded PKZIP headers as seen in HTML files used by QBot"
		author = "Florian Roth (Nextron Systems)"
		id = "8034d6af-4dae-5ff6-b635-efb5175fe4d1"
		date = "2022-10-07"
		modified = "2023-12-05"
		reference = "https://twitter.com/ankit_anubhav/status/1578257383133876225?s=20&t=Bu3CCJCzImpTGOQX_KGsdA"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_qbot_payloads.yar#L2-L55"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "4f384bcba31fda53e504d0a6c85cee0ce3ea9586226633d063f34c53ddeaca3f"
		hash = "8e61c2b751682becb4c0337f5a79b2da0f5f19c128b162ec8058104b894cae9b"
		hash = "c5d23d991ce3fbcf73b177bc6136d26a501ded318ccf409ca16f7c664727755a"
		hash = "5072d91ee0d162c28452123a4d9986f3df6b3244e48bf87444ce88add29dd8ed"
		hash = "ff4e21f788c36aabe6ba870cf3b10e258c2ba6f28a2d359a25d5a684c92a0cad"
		logic_hash = "a5bd9eb72205f1398ec0b8773751309699b3267e0272dacf2728f8495c0c0ec2"
		score = 75
		quality = 83
		tags = "FILE"

	strings:
		$sd1 = "VUVzREJCUUFBUUFJQ"
		$sd2 = "VFc0RCQlFBQVFBSU"
		$sd3 = "VRXNEQkJRQUFRQUlB"
		$sdr1 = "QJFUUBFUUCJERzVUV"
		$sdr2 = "USBFVQBFlQCR0cFV"
		$sdr3 = "BlUQRFUQRJkQENXRV"
		$st1 = "VlVWelJFSkNVVUZCVVVGSl"
		$st2 = "ZVVnpSRUpDVVVGQlVVRkpR"
		$st3 = "WVVZ6UkVKQ1VVRkJVVUZKU"
		$st4 = "VkZjMFJDUWxGQlFWRkJTV"
		$st5 = "ZGYzBSQ1FsRkJRVkZCU1"
		$st6 = "WRmMwUkNRbEZCUVZGQlNV"
		$st7 = "VlJYTkVRa0pSUVVGUlFVbE"
		$st8 = "ZSWE5FUWtKUlFVRlJRVWxC"
		$st9 = "WUlhORVFrSlJRVUZSUVVsQ"
		$str1 = "UUpGVVVCRlVVQ0pFUnpWVV"
		$str2 = "FKRlVVQkZVVUNKRVJ6VlVW"
		$str3 = "RSkZVVUJGVVVDSkVSelZVV"
		$str4 = "VVNCRlZRQkZsUUNSMGNGV"
		$str5 = "VTQkZWUUJGbFFDUjBjRl"
		$str6 = "VU0JGVlFCRmxRQ1IwY0ZW"
		$str7 = "QmxVUVJGVVFSSmtRRU5YUl"
		$str8 = "JsVVFSRlVRUkprUUVOWFJW"
		$str9 = "CbFVRUkZVUVJKa1FFTlhSV"
		$htm = "<html" ascii
		$eml = "Content-Transfer-Encoding:" ascii

	condition:
		filesize < 10MB and ( ( 1 of ( $sd* ) and $htm and not $eml ) or ( 1 of ( $st* ) and $eml ) )
}
rule SIGNATURE_BASE_SUSP_Email_Redirection_Spoofing_Feb25
{
	meta:
		description = "Detects redirect spoofing in embedded URLs. This technique is used by threat actors to obscure the actual destination of a link"
		author = "Jonathan Peters (cod3nym)"
		id = "bf3a2b06-4dc5-5f0f-bf1f-2bd6a1cc4a8d"
		date = "2025-02-20"
		modified = "2025-03-20"
		reference = "https://any.run/cybersecurity-blog/cyber-attacks-january-2025/#fake-youtube-links-redirect-users-to-phishing-pages-11298"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/susp_email_redirection_spoofing.yar#L1-L19"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "9b196220b369c199a7e4d57cb5db18b32eb2565a6f9190929c5c01ac4fa04ac8"
		hash = "c4eb35c1a1c10226bff9bb0c88ca516441208d193b4994eeb292a66e53a2cc04"
		hash = "e3b8ea03a472348814c6ac81088234836e627a1878ec36e46ce62526e1390935"
		logic_hash = "9a411317821751dc0873fe3163791115d1e19bc4d57119ed2ba513b444864032"
		score = 70
		quality = 85
		tags = ""

	strings:
		$sa1 = "Content-Transfer-Encoding:" ascii
		$sa2 = "Subject:" ascii
		$x = ".com%20%20%20%20%20%" ascii

	condition:
		all of them
}
rule SIGNATURE_BASE_SUSP_Vulndriver_HP_Hardware_Diagnostics_Etdsupp_May23 : FILE
{
	meta:
		description = "Detects vulnerable versions of the HP Hardware Diagnostics driver (etdsupp.sys) based on PE metadata info"
		author = "X__Junior (Nextron Systems)"
		id = "8f838e4f-3e3e-5131-9d67-e49f6848bb37"
		date = "2023-05-12"
		modified = "2023-12-05"
		reference = "https://github.com/alfarom256/HPHardwareDiagnostics-PoC/tree/main/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/susp_vulndriver_hp_hardware_diagnostics_etdsupp_may23.yar#L1-L16"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "f744abb99c97d98e4cd08072a897107829d6d8481aee96c22443f626d00f4145"
		logic_hash = "bb50f591e49b1b0b08ccbe4ca5cb3685d8f358e51e6d6f77677bc05701f6b301"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$s1 = {4f 00 72 00 69 00 67 00 69 00 6e 00 61 00 6c 00 46 00 69 00 6c 00 65 00 6e 00 61 00 6d 00 65 00 00 00 65 00 74 00 64 00 73 00 75 00 70 00 70 00 2e 00 73 00 79 00 73 00}
		$s2 = "etdsupp.pdb"
		$s3 = /V\x00S\x00_\x00V\x00E\x00R\x00S\x00I\x00O\x00N\x00_\x00I\x00N\x00F\x00O\x00\x00\x00{0,4}\xbd\x04\xef\xfe[\x00-\xff]{4}([\x00-\xff]{2}[\x00-\x11]\x00[\x00-\xff]{4}|\x00\x00\x12\x00\x00\x00\x00\x00)/

	condition:
		uint16( 0 ) == 0x5a4d and int16 ( uint32( 0x3C ) + 0x5c ) == 0x0001 and filesize < 100KB and all of them
}
rule SIGNATURE_BASE_EXPL_LOG_CVE_2021_27065_Exchange_Forensic_Artefacts_Mar21_1 : LOG CVE_2021_27065
{
	meta:
		description = "Detects forensic artefacts found in HAFNIUM intrusions exploiting CVE-2021-27065"
		author = "Florian Roth (Nextron Systems)"
		id = "dcc1f741-cab0-5a0b-a261-a6bd05989723"
		date = "2021-03-02"
		modified = "2023-12-05"
		reference = "https://www.volexity.com/blog/2021/03/02/active-exploitation-of-microsoft-exchange-zero-day-vulnerabilities/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium_log_sigs.yar#L2-L13"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9306cf177928266ea921461e9da80ad5bb37e1e0848559898a414956cfbc2b49"
		score = 75
		quality = 85
		tags = "LOG, CVE-2021-27065"

	strings:
		$s1 = "S:CMD=Set-OabVirtualDirectory.ExternalUrl='" ascii wide fullword

	condition:
		1 of them
}
rule SIGNATURE_BASE_EXPL_LOG_CVE_2021_26858_Exchange_Forensic_Artefacts_Mar21_1 : LOG CVE_2021_26858
{
	meta:
		description = "Detects forensic artefacts found in HAFNIUM intrusions exploiting CVE-2021-26858"
		author = "Florian Roth (Nextron Systems)"
		id = "f6fa90c7-c2c0-56db-bf7b-dc146761a995"
		date = "2021-03-02"
		modified = "2021-03-04"
		reference = "https://www.volexity.com/blog/2021/03/02/active-exploitation-of-microsoft-exchange-zero-day-vulnerabilities/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium_log_sigs.yar#L15-L28"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "0a8296b7e990e52330412288e9ff71e08a5258fc63c4754e6d0e6d64302f55e6"
		score = 65
		quality = 85
		tags = "LOG, CVE-2021-26858"

	strings:
		$xr1 = /POST (\/owa\/auth\/Current\/themes\/resources\/logon\.css|\/owa\/auth\/Current\/themes\/resources\/owafont_ja\.css|\/owa\/auth\/Current\/themes\/resources\/lgnbotl\.gif|\/owa\/auth\/Current\/themes\/resources\/owafont_ko\.css|\/owa\/auth\/Current\/themes\/resources\/SegoeUI-SemiBold\.eot|\/owa\/auth\/Current\/themes\/resources\/SegoeUI-SemiLight\.ttf|\/owa\/auth\/Current\/themes\/resources\/lgnbotl\.gif)/

	condition:
		$xr1
}
rule SIGNATURE_BASE_LOG_APT_HAFNIUM_Exchange_Log_Traces_Mar21_1 : LOG
{
	meta:
		description = "Detects suspicious log entries that indicate requests as described in reports on HAFNIUM activity"
		author = "Florian Roth (Nextron Systems)"
		id = "a51f0bd5-c6fd-5ee4-9d30-9a6001778013"
		date = "2021-03-04"
		modified = "2023-12-05"
		reference = "https://www.volexity.com/blog/2021/03/02/active-exploitation-of-microsoft-exchange-zero-day-vulnerabilities/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium_log_sigs.yar#L30-L46"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "03b90c121cc5169eef66e111648d5641acc785e60a20c658ba7f4d1cf032cd92"
		score = 65
		quality = 83
		tags = "LOG"

	strings:
		$xr1 = /POST \/(ecp\/y\.js|ecp\/main\.css|ecp\/default\.flt|ecp\/auth\/w\.js|owa\/auth\/w\.js)[^\n]{100,600} (200|301|302) /
		$xr3 = /POST \/owa\/auth\/Current\/[^\n]{100,600} (DuckDuckBot\/1\.0;\+\(\+http:\/\/duckduckgo\.com\/duckduckbot\.html\)|facebookexternalhit\/1\.1\+\(\+http:\/\/www\.facebook\.com\/externalhit_uatext\.php\)|Mozilla\/5\.0\+\(compatible;\+Baiduspider\/2\.0;\+\+http:\/\/www\.baidu\.com\/search\/spider\.html\)|Mozilla\/5\.0\+\(compatible;\+Bingbot\/2\.0;\+\+http:\/\/www\.bing\.com\/bingbot\.htm\)|Mozilla\/5\.0\+\(compatible;\+Googlebot\/2\.1;\+\+http:\/\/www\.google\.com\/bot\.html|Mozilla\/5\.0\+\(compatible;\+Konqueror\/3\.5;\+Linux\)\+KHTML\/3\.5\.5\+\(like\+Gecko\)\+\(Exabot-Thumbnails\)|Mozilla\/5\.0\+\(compatible;\+Yahoo!\+Slurp;\+http:\/\/help\.yahoo\.com\/help\/us\/ysearch\/slurp\)|Mozilla\/5\.0\+\(compatible;\+YandexBot\/3\.0;\+\+http:\/\/yandex\.com\/bots\)|Mozilla\/5\.0\+\(X11;\+Linux\+x86_64\)\+AppleWebKit\/537\.36\+\(KHTML,\+like\+Gecko\)\+Chrome\/51\.0\.2704\.103\+Safari\/537\.3)/
		$xr4 = /POST \/ecp\/[^\n]{100,600} (ExchangeServicesClient\/0\.0\.0\.0|python-requests\/2\.19\.1|python-requests\/2\.25\.1)[^\n]{200,600} (200|301|302) /
		$xr5 = /POST \/(aspnet_client|owa)\/[^\n]{100,600} (antSword\/v2\.1|Googlebot\/2\.1\+\(\+http:\/\/www\.googlebot\.com\/bot\.html\)|Mozilla\/5\.0\+\(compatible;\+Baiduspider\/2\.0;\+\+http:\/\/www\.baidu\.com\/search\/spider\.html\))[^\n]{200,600} (200|301|302) /

	condition:
		1 of them
}
rule SIGNATURE_BASE_LOG_Exchange_Forensic_Artefacts_Cleanup_Activity_Mar21_1 : LOG
{
	meta:
		description = "Detects forensic artefacts showing cleanup activity found in HAFNIUM intrusions exploiting"
		author = "Florian Roth (Nextron Systems)"
		id = "95b19544-147b-5496-b717-669cbc488179"
		date = "2021-03-08"
		modified = "2023-12-05"
		reference = "https://twitter.com/jdferrell3/status/1368626281970024448"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium_log_sigs.yar#L48-L65"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "12e5b76dafcae13f1eb21913ae0bde233152fd8b9d29f073893418ac9f742de3"
		score = 70
		quality = 85
		tags = "LOG"

	strings:
		$x1 = "cmd.exe /c cd /d C:/inetpub/wwwroot/aspnet_client" ascii wide
		$x2 = "cmd.exe /c cd /d C:\\inetpub\\wwwroot\\aspnet_client" ascii wide
		$s1 = "aspnet_client&del '"
		$s2 = "aspnet_client&attrib +h +s +r "
		$s3 = "&echo [S]"

	condition:
		1 of ( $x* ) or 2 of them
}
rule SIGNATURE_BASE_LOG_CVE_2021_27065_Exchange_Forensic_Artefacts_Mar21_2 : LOG
{
	meta:
		description = "Detects suspicious log entries that indicate requests as described in reports on HAFNIUM activity"
		author = "Florian Roth (Nextron Systems)"
		id = "37a26def-b360-518e-a4ab-9604a5b39afd"
		date = "2021-03-10"
		modified = "2023-12-05"
		reference = "https://www.praetorian.com/blog/reproducing-proxylogon-exploit/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_hafnium_log_sigs.yar#L92-L104"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "13e2e46689bc0e87c3cf13dc2ce213c384afe6c03c21e62a467974a0518c12da"
		score = 65
		quality = 85
		tags = "LOG"

	strings:
		$sr1 = /GET \/rpc\/ &CorrelationID=<empty>;&RequestId=[^\n]{40,600} (200|301|302)/

	condition:
		$sr1
}
rule SIGNATURE_BASE_APT_MAL_VEILEDSIGNAL_Backdoor_Apr23 : FILE
{
	meta:
		description = "Detects malicious VEILEDSIGNAL backdoor"
		author = "X__Junior"
		id = "74c403ea-3178-58e8-88b3-a51c1d475868"
		date = "2023-04-20"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/blog/3cx-software-supply-chain-compromise"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_tradingtech_apr23.yar#L2-L17"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "aa318070ad1bf90ed459ac34dc5254acc178baff3202d2ea7f49aaf5a055dd43"
		logic_hash = "4fe1a1b09344cd84f981b193b480d23807893b59ad781868d82089a7306c042f"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$op1 = {B8 AB AA AA AA F7 E1 8B C1 C1 EA 02 8D 14 52 03 D2 2B C2 8A 84 05 ?? ?? ?? ?? 30 84 0D ?? ?? ?? ??}
		$op2 = { 50 66 0F 13 85 ?? ?? ?? ?? 66 0F 13 85 ?? ?? ?? ?? 66 0F 13 85 ?? ?? ?? ?? 66 0F 13 85 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 3C 00 00 00 C7 85 ?? ?? ?? ?? 40 00 00 00 C7 85 ?? ?? ?? ?? 05 00 00 00 FF 15}
		$op3 = { 6A 00 8D 85 ?? ?? ?? ?? 50 6A 04 8D 85 ?? ?? ?? ?? 50 57 FF 15 }

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule SIGNATURE_BASE_SUSP_APT_MAL_VEILEDSIGNAL_Backdoor_Apr23
{
	meta:
		description = "Detects marker found in VEILEDSIGNAL backdoor"
		author = "X__Junior"
		id = "8f0d92b6-d9b0-55e3-b2ca-601d095f5279"
		date = "2023-04-20"
		modified = "2023-04-21"
		reference = "https://www.mandiant.com/resources/blog/3cx-software-supply-chain-compromise"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_tradingtech_apr23.yar#L19-L35"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "aa318070ad1bf90ed459ac34dc5254acc178baff3202d2ea7f49aaf5a055dd43"
		logic_hash = "ccb482a7634dc24fde03b5730bf28a9e028f8d5a9ad46ba9663d1b520264d8f4"
		score = 75
		quality = 85
		tags = ""

	strings:
		$opb1 = { 81 BD ?? ?? ?? ?? 5E DA F3 76}
		$opb2 = { C7 85 ?? ?? ?? ?? 74 F2 39 DA 66 C7 85 ?? ?? ?? ?? E5 CF}
		$opb3 = { C7 85 ?? ?? ?? ?? 74 F2 39 DA B9 00 04 00 00 66 C7 85 ?? ?? ?? ?? E5 CF }

	condition:
		2 of them
}
rule SIGNATURE_BASE_APT_NK_MAL_M_Hunting_VEILEDSIGNAL_1 : FILE
{
	meta:
		description = "Detects VEILEDSIGNAL malware"
		author = "Mandiant"
		id = "3e7c92fe-a7bd-5180-9935-4f98f2b64e2b"
		date = "2023-04-20"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/blog/3cx-software-supply-chain-compromise"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_tradingtech_apr23.yar#L37-L55"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "404b09def6054a281b41d309d809a428"
		hash = "c6441c961dcad0fe127514a918eaabd4"
		logic_hash = "439a201e6a44a00a31fd13efc83a1acf858a52201e3ab48d5cf095bae1e48cf7"
		score = 75
		quality = 85
		tags = "FILE"
		disclaimer = "This rule is meant for hunting and is not tested to run in a production environment"

	strings:
		$rh1 = { 68 5D 7A D2 2C 3C 14 81 2C 3C 14 81 2C 3C 14 81 77 54 10 80 26 3C 14 81 77 54 17 80 29 3C 14 81 77 54 11 80 AB 3C 14 81 D4 4C 11 80 33 3C 14 81 D4 4C 10 80 22 3C 14 81 D4 4C 17 80 25 3C 14 81 77 54 15 80 27 3C 14 81 2C 3C 15 81 4B 3C 14 81 94 4D 1D 80 28 3C 14 81 94 4D 14 80 2D 3C 14 81 94 4D 16 80 2D 3C 14 81 }
		$rh2 = { 00 E5 A0 2B 44 84 CE 78 44 84 CE 78 44 84 CE 78 1F EC CA 79 49 84 CE 78 1F EC CD 79 41 84 CE 78 1F EC CB 79 C8 84 CE 78 BC F4 CA 79 4A 84 CE 78 BC F4 CD 79 4D 84 CE 78 BC F4 CB 79 65 84 CE 78 1F EC CF 79 43 84 CE 78 44 84 CF 78 22 84 CE 78 FC F5 C7 79 42 84 CE 78 FC F5 CE 79 45 84 CE 78 FC F5 CC 79 45 84 CE 78}
		$rh3 = { DA D2 21 22 9E B3 4F 71 9E B3 4F 71 9E B3 4F 71 C5 DB 4C 70 94 B3 4F 71 C5 DB 4A 70 15 B3 4F 71 C5 DB 4B 70 8C B3 4F 71 66 C3 4B 70 8C B3 4F 71 66 C3 4C 70 8F B3 4F 71 C5 DB 49 70 9F B3 4F 71 66 C3 4A 70 B0 B3 4F 71 C5 DB 4E 70 97 B3 4F 71 9E B3 4E 71 F9 B3 4F 71 26 C2 46 70 9F B3 4F 71 26 C2 B0 71 9F B3 4F 71 9E B3 D8 71 9F B3 4F 71 26 C2 4D 70 9F B3 4F 71 }
		$rh4 = { CB 8A 35 66 8F EB 5B 35 8F EB 5B 35 8F EB 5B 35 D4 83 5F 34 85 EB 5B 35 D4 83 58 34 8A EB 5B 35 D4 83 5E 34 09 EB 5B 35 77 9B 5E 34 92 EB 5B 35 77 9B 5F 34 81 EB 5B 35 77 9B 58 34 86 EB 5B 35 D4 83 5A 34 8C EB 5B 35 8F EB 5A 35 D3 EB 5B 35 37 9A 52 34 8C EB 5B 35 37 9A 58 34 8E EB 5B 35 37 9A 5B 34 8E EB 5B 35 37 9A 59 34 8E EB 5B 35 }

	condition:
		uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 and 1 of ( $rh* )
}
rule SIGNATURE_BASE_APT_NK_MAL_M_Hunting_VEILEDSIGNAL_2 : FILE
{
	meta:
		description = "Detects VEILEDSIGNAL malware"
		author = "Mandiant"
		id = "1b96c2f0-1c57-593e-9630-a72d43eb857e"
		date = "2023-04-20"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/blog/3cx-software-supply-chain-compromise"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_tradingtech_apr23.yar#L57-L76"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "404b09def6054a281b41d309d809a428"
		logic_hash = "62f74faa8f136f4dc63a4b703cffcb97b438cc4f180d5d127d1fc4b86d3cd1d1"
		score = 75
		quality = 85
		tags = "FILE"
		disclaimer = "This rule is meant for hunting and is not tested to run in a production environment"

	strings:
		$sb1 = { C1 E0 05 4D 8? [2] 33 D0 45 69 C0 7D 50 BF 12 8B C2 41 FF C2 C1 E8 07 33 D0 8B C2 C1 E0 16 41 81 C0 87 D6 12 00 }
		$si1 = "CryptBinaryToStringA" fullword
		$si2 = "BCryptGenerateSymmetricKey" fullword
		$si3 = "CreateThread" fullword
		$ss1 = "ChainingModeGCM" wide
		$ss2 = "__tutma" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) and all of them
}
rule SIGNATURE_BASE_APT_NK_MAL_M_Hunting_VEILEDSIGNAL_3 : FILE
{
	meta:
		description = "Detects VEILEDSIGNAL malware"
		author = "Mandiant"
		id = "82790c65-1d93-509b-95df-841543943c30"
		date = "2023-04-20"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/blog/3cx-software-supply-chain-compromise"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_tradingtech_apr23.yar#L78-L96"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "c6441c961dcad0fe127514a918eaabd4"
		logic_hash = "2109340edfb1891baef5bd92ba3c9da77f891341de9e8094060a649de62fade2"
		score = 75
		quality = 85
		tags = "FILE"
		disclaimer = "This rule is meant for hunting and is not tested to run in a production environment"

	strings:
		$ss1 = { 61 70 70 6C 69 63 61 74 69 6F 6E 2F 6A 73 6F 6E 2C 20 74 65 78 74 2F 6A 61 76 61 73 63 72 69 70 74 2C 20 2A 2F 2A 3B 20 71 3D 30 2E 30 31 00 00 61 63 63 65 70 74 00 00 65 6E 2D 55 53 2C 65 6E 3B 71 3D 30 2E 39 00 00 61 63 63 65 70 74 2D 6C 61 6E 67 75 61 67 65 00 63 6F 6F 6B 69 65 00 00 }
		$si1 = "HttpSendRequestW" fullword
		$si2 = "CreateNamedPipeW" fullword
		$si3 = "CreateThread" fullword
		$se1 = "DllGetClassObject" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) and all of them
}
rule SIGNATURE_BASE_APT_NK_MAL_M_Hunting_VEILEDSIGNAL_4 : FILE
{
	meta:
		description = "Detects VEILEDSIGNAL malware"
		author = "Mandiant"
		id = "379e6471-3c4f-5c72-b8fd-17f481e89ac6"
		date = "2023-04-20"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/blog/3cx-software-supply-chain-compromise"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_tradingtech_apr23.yar#L98-L118"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "404b09def6054a281b41d309d809a428"
		hash = "c6441c961dcad0fe127514a918eaabd4"
		logic_hash = "2a875c39a43ff054ed5a6cf2fa1f17c2adc189452582763db8ceddfa652abfbf"
		score = 75
		quality = 85
		tags = "FILE"
		disclaimer = "This rule is meant for hunting and is not tested to run in a production environment"

	strings:
		$sb1 = { FF 15 FC 76 01 00 8B F0 85 C0 74 ?? 8D 50 01 [6-16] FF 15 [4] 48 8B D8 48 85 C0 74 ?? 89 ?? 24 28 44 8B CD 4C 8B C? 48 89 44 24 20 }
		$sb2 = { 33 D2 33 C9 FF 15 [4] 4C 8B CB 4C 89 74 24 28 4C 8D 05 [2] FF FF 44 89 74 24 20 33 D2 33 C9 FF 15 }
		$si1 = "CreateThread" fullword
		$si2 = "MultiByteToWideChar" fullword
		$si3 = "LocalAlloc" fullword
		$se1 = "DllGetClassObject" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) and all of them
}
rule SIGNATURE_BASE_APT_NK_MAL_M_Hunting_VEILEDSIGNAL_5 : FILE
{
	meta:
		description = "Detects VEILEDSIGNAL malware"
		author = "Mandiant"
		id = "7d0718fc-4f1c-5293-8dc4-81a5783fbfb2"
		date = "2023-04-20"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/blog/3cx-software-supply-chain-compromise"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_tradingtech_apr23.yar#L120-L143"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "6727284586ecf528240be21bb6e97f88"
		logic_hash = "5d43b8198ad224bee8d290dd7031d73f76a7d957a2e3b44d89e7aaf5f2c94c65"
		score = 75
		quality = 85
		tags = "FILE"
		disclaimer = "This rule is meant for hunting and is not tested to run in a production environment"

	strings:
		$sb1 = { 48 8D 15 [4] 48 8D 4C 24 4C E8 [4] 85 C0 74 ?? 48 8D 15 [4] 48 8D 4C 24 4C E8 [4] 85 C0 74 ?? 48 8D 15 [4] 48 8D 4C 24 4C E8 [4] 85 C0 74 ?? 48 8D [3] 48 8B CB FF 15 [4] EB }
		$ss1 = "chrome.exe" wide fullword
		$ss2 = "firefox.exe" wide fullword
		$ss3 = "msedge.exe" wide fullword
		$ss4 = "\\\\.\\pipe\\*" ascii fullword
		$ss5 = "FindFirstFileA" ascii fullword
		$ss6 = "Process32FirstW" ascii fullword
		$ss7 = "RtlAdjustPrivilege" ascii fullword
		$ss8 = "GetCurrentProcess" ascii fullword
		$ss9 = "NtWaitForSingleObject" ascii fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) and all of them
}
rule SIGNATURE_BASE_APT_NK_MAL_M_Hunting_VEILEDSIGNAL_6 : FILE
{
	meta:
		description = "Detects VEILEDSIGNAL malware"
		author = "Mandiant"
		id = "2cbedbc0-d465-5674-bf9c-9362003eb8d2"
		date = "2023-04-20"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/blog/3cx-software-supply-chain-compromise"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_tradingtech_apr23.yar#L145-L164"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "00a43d64f9b5187a1e1f922b99b09b77"
		logic_hash = "d3b1e5f7a6b73fc4cdc5abe19a412130cde33c2d52c0ad78256b865e018e3794"
		score = 75
		quality = 85
		tags = "FILE"
		disclaimer = "This rule is meant for hunting and is not tested to run in a production environment"

	strings:
		$ss1 = "C:\\Programdata\\" wide
		$ss2 = "devobj.dll" wide fullword
		$ss3 = "msvcr100.dll" wide fullword
		$ss4 = "TpmVscMgrSvr.exe" wide fullword
		$ss5 = "\\Microsoft\\Windows\\TPM" wide fullword
		$ss6 = "CreateFileW" ascii fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x010B ) and all of them
}
rule SIGNATURE_BASE_SUSP_NK_MAL_M_Hunting_POOLRAT
{
	meta:
		description = "Detects strings found in POOLRAT malware"
		author = "Mandiant"
		id = "70f5f3a0-0fd0-54dc-97cc-4f3c35f02fcd"
		date = "2023-04-20"
		modified = "2023-12-05"
		old_rule_name = "APT_NK_MAL_M_Hunting_POOLRAT"
		reference = "https://www.mandiant.com/resources/blog/3cx-software-supply-chain-compromise"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_tradingtech_apr23.yar#L166-L202"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "451c23709ecd5a8461ad060f6346930c"
		logic_hash = "ac8db844a9c4ed961930417809afb706ea948c4509a4be1eaeed77f09c86069d"
		score = 70
		quality = 83
		tags = ""
		disclaimer = "This rule is meant for hunting and is not tested to run in a production environment"

	strings:
		$s1 = "name=\"uid\"%s%s%u%s" ascii wide
		$s2 = "name=\"session\"%s%s%u%s" ascii wide
		$s3 = "name=\"action\"%s%s%s%s" ascii wide
		$s4 = "name=\"token\"%s%s%u%s" ascii wide
		$str1 = "--N9dLfqxHNUUw8qaUPqggVTpX-" wide ascii nocase

	condition:
		any of ( $s* ) or $str1
}

rule SIGNATURE_BASE_SUSP_TH_APT_UNC4736_Tradingtech_Cert_Apr23_1
{
	meta:
		description = "Threat hunting rule that detects samples signed with the compromised Trading Technologies certificate after May 2022"
		author = "Florian Roth"
		id = "9a05fba9-9466-5b69-9207-27ad01d6eb8b"
		date = "2023-04-20"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/blog/3cx-software-supply-chain-compromise"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_tradingtech_apr23.yar#L227-L242"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "47941828b3c18ed39eddacbc73e147651a9bd48e1a0f7b9847ff1d4c6fea6afd"
		score = 65
		quality = 85
		tags = ""

	strings:
		$s1 = { 00 85 38 A6 C5 01 8F 50 FC }
		$s2 = "Go Daddy Secure Certificate Authority - G2"
		$s3 = "Trading Technologies International, Inc"

	condition:
		pe.timestamp> 1651363200 and all of them
}
rule SIGNATURE_BASE_MAL_NPM_Supplychain_Attack_Mar26 : FILE
{
	meta:
		description = "Detects package.json which include the malicious plain-crypto-js package as dependency"
		author = "Marius Benthin"
		id = "88e7af97-f7c1-591e-960c-d5296da94066"
		date = "2026-03-31"
		modified = "2026-05-15"
		reference = "https://www.stepsecurity.io/blog/axios-compromised-on-npm-malicious-versions-drop-remote-access-trojan"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_npm_supply_chain_mar26.yar#L1-L17"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "5e3e89c7351f385e36bb70286866a62957cc1aaab195539edb8c7bb62968a137"
		logic_hash = "e0f0f5ca19f95b90d4483c6de8d4eb770e3ea8d6ee189e6c7c5bff4a74dedd57"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "\"dependencies\":"
		$s2 = { 22 70 6C 61 69 6E 2D 63 72 79 70 74 6F 2D 6A 73 22 3A [0-3] 22 [0-2] 34 2E 32 2E }

	condition:
		filesize < 10KB and all of them
}
rule SIGNATURE_BASE_SUSP_JS_Dropper_Mar26 : FILE
{
	meta:
		description = "Detects suspicious JavaScript dropper used in plain-crypto-js supply chain attacks"
		author = "Marius Benthin"
		id = "456a52c2-9cbf-572f-9a5b-b8d74183e3f4"
		date = "2026-03-31"
		modified = "2026-05-15"
		reference = "https://www.stepsecurity.io/blog/axios-compromised-on-npm-malicious-versions-drop-remote-access-trojan"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_npm_supply_chain_mar26.yar#L19-L41"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "e10b1fa84f1d6481625f741b69892780140d4e0e7769e7491e5f4d894c2e0e09"
		logic_hash = "9dad4bef8cf31a91240dbbc438eff2640389424db9f75be2d897d745133785ee"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$sa1 = "Buffer.from("
		$sa2 = "FileSync("
		$sa3 = ".replaceAll("
		$sb1 = ".arch()"
		$sb2 = ".platform()"
		$sb3 = ".release()"
		$sb4 = ".type()"

	condition:
		filesize < 10KB and all of ( $sa* ) and 2 of ( $sb* )
}
rule SIGNATURE_BASE_MAL_Katz_Stealer_May25 : FILE
{
	meta:
		description = "Detects Katz stealer"
		author = "MalGamy (Nextron Systems)"
		id = "ef84df99-3c1a-56b6-a0fd-39876982d0c3"
		date = "2025-05-16"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_katz_stealer.yar#L1-L22"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "fdc86a5b3d7df37a72c3272836f743747c47bfbc538f05af9ecf78547fa2e789"
		hash = "d92bb6e47cb0a0bdbb51403528ccfe643a9329476af53b5a729f04a4d2139647"
		logic_hash = "73364c2291dc792f46858dda057f08805db55fe1f1e54d6b0dee0a0c8a412259"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Motherboard Product: %s" ascii
		$s2 = "cmd.exe /c %s" ascii
		$s3 = "reg export \"%s\" \"%s\" /y" ascii
		$s4 = ").request({ hostname: '" ascii
		$s5 = "Type: Removable"
		$s6 = "%s\\Microsoft\\Windows Live Mail" ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 300KB and 4 of them
}
rule SIGNATURE_BASE_MAL_DLL_Chrome_App_Bound_Encryption_Decryption_May25 : FILE
{
	meta:
		description = "Detects a DLL used to decrypt App-Bound Encrypted (ABE) cookies, passwords and payment methods from Chromium-based browsers. Seen being used by Katz stealer"
		author = "MAlGamy"
		id = "ee1e2584-7104-506f-93a9-89e97cf39a93"
		date = "2025-05-19"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_katz_stealer.yar#L24-L43"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "6dc8e99da68b703e86fa90a8794add87614f254f804a8d5d65927e0676107a9d"
		logic_hash = "d5488728a3ee8f2f59ed9798b80d516f7f131e39b3d5099ad5168ffc8ff22718"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Failed to set proxy blanket." ascii
		$s2 = "Decryption failed. Last error:" ascii
		$s3 = "\\Google\\Chrome\\User Data\\Local State" ascii
		$op1 = {48 39 F3 74 ?? 4C 89 E2 48 89 E9 E8 ?? ?? ?? ?? 48 89 C1 48 8B 00 B2 ?? 48 8B 40 ?? 48 C7 44 01 ?? ?? ?? ?? ?? E8 ?? ?? ?? ?? 0F B6 13 48 89 C1 E8 ?? ?? ?? ?? 48 FF C3 EB ?? 48 8D 54 24 ?? 48 89 F9 E8 ?? ?? ?? ?? 48 89 E9 E8 ?? ?? ?? ?? 48 89 F8 48 81 C4}

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 2MB and $op1 and 1 of ( $s* )
}
rule SIGNATURE_BASE_SUSP_Katz_Log_May25 : FILE
{
	meta:
		description = "Detects log file that contains system reconnaissance data, seen being generated by Katz stealer"
		author = "MalGamy"
		id = "be56f0ae-e444-569e-95d7-edccf4c6dd2b"
		date = "2025-05-20"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_katz_stealer.yar#L45-L66"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "1ac196ac6393d786618c944a7ab77fb189a6b4ba00af5c0f987c3dc65876c060"
		hash = "ad76e2727469525dec7e56977589dd250ca57a29b8b0d42cd5c42e536c285241"
		hash = "e1a0d6929662bcbc9e5e0827cb8b6d7818088e996cf971d2a4a1c1ca4208e533"
		hash = "b10796c41e1cec7c84a3c68bfcaa7b20f49b620d1c94304a6b3ed73471fa9031"
		hash = "5a984e2e308fe84e4e2071dd877772361719ba0217c2c23da79dbb82dc15eac8"
		logic_hash = "847ab8f9a7abf260f4185d41ae9cb9af40c28726338ff2306a75d2160ae61f03"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Motherboard Manufacturer:" ascii
		$s2 = "===== System Information =====" ascii
		$s3 = "Volume Name:" ascii
		$s4 = "Desktop Hostname:" ascii

	condition:
		filesize < 50KB and 3 of them
}
rule SIGNATURE_BASE_MAL_NET_Katz_Stealer_Loader_May25
{
	meta:
		description = "Detects .NET based Katz stealer loader"
		author = "Jonathan Peters (cod3nym)"
		id = "c3d33818-66a1-51d9-9bcd-d8d255f96881"
		date = "2025-05-21"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_katz_stealer.yar#L68-L88"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0df13fd42fb4a4374981474ea87895a3830eddcc7f3bd494e76acd604c4004f7"
		logic_hash = "1922520d8c34660a0afff2f552ef0d1c6ec093fb10a00816e0216f574b686221"
		score = 80
		quality = 85
		tags = ""

	strings:
		$x = "ExecutarMetodoVAI" ascii
		$s1 = "VirtualMachineDetector" ascii
		$s2 = "Wow64SetThreadContext_API" ascii
		$s3 = "nomedoarquivo" ascii
		$s4 = { 65 78 74 65 6E C3 A7 61 6F 00 }
		$s5 = "payloadBuffer" ascii
		$s6 = "caminhovbs" ascii

	condition:
		3 of ( $s* ) or $x
}
rule SIGNATURE_BASE_MAL_NET_UAC_Bypass_May25 : FILE
{
	meta:
		description = "Detects .NET based tool abusing legitimate Windows utility cmstp.exe to bypass UAC (User-Admin-Controls)"
		author = "Jonathan Peters (cod3nym)"
		id = "bf14177f-be55-5bb1-8218-a4a734532ea4"
		date = "2025-05-21"
		modified = "2026-05-15"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_katz_stealer.yar#L90-L108"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "4f12c5dca2099492d0c0cd22edef841cbe8360af9be2d8e9b57c2f83d401c1a7"
		hash = "fcad234dc2ad5e2d8215bcf6caac29aef62666c34564e723fa6d2eee8b6468ed"
		logic_hash = "4a3f6e90af6f9a8a4dfa8e336eb8c714e5f02625ca2bf5bf8b1bca9cbda6a99e"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "CmstpBypass" ascii
		$x2 = { 52 00 45 00 50 00 4C 00 41 00 43 00 45 00 5F 00 43 00 4F 00 4D 00 4D 00 41 00 4E 00 44 00 5F 00 4C 00 49 00 4E 00 45 00 00 13 63 00 6D 00 73 00 74 00 70 00 2E 00 65 00 78 00 65 00 00 33 63 00 6D 00 73 00 74 00 70 00 2E 00 65 00 78 00 65 }
		$x3 = { 52 00 45 00 50 00 4C 00 41 00 43 00 45 00 5F 00 43 00 4F 00 4D 00 4D 00 41 00 4E 00 44 00 5F 00 4C 00 49 00 4E 00 45 00 0D 00 0A 00 74 00 61 00 73 00 6B 00 6B 00 69 00 6C 00 6C 00 20 00 2F 00 49 00 4D 00 20 00 63 00 6D 00 73 00 74 00 70 00 2E 00 65 00 78 00 65 }

	condition:
		uint16( 0 ) == 0x5a4d and $x1 or 1 of ( $x2 , $x3 )
}
rule SIGNATURE_BASE_MAL_Sharpshooter_Excel4 : FILE
{
	meta:
		description = "Detects Excel documents weaponized with Sharpshooter"
		author = "John Lambert, Florian Roth"
		id = "a79e3afe-e8f9-5e56-a131-bb1b346df471"
		date = "2020-03-27"
		modified = "2023-12-05"
		reference = "https://docs.microsoft.com/en-us/openspecs/office_file_formats/ms-xls/00b5dd7d-51ca-4938-b7b7-483fe0e5933b"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_Excel4Macro_Sharpshooter.yar#L1-L25"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "ccef64586d25ffcb2b28affc1f64319b936175c4911e7841a0e28ee6d6d4a02d"
		logic_hash = "4aec8bb7ec8ce7ebd8228416133ea7eec995864aeec78c11548387d832b5fa65"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$header_docf = { D0 CF 11 E0 }
		$s1 = "Excel 4.0 Macros"
		$f1 = "CreateThread" ascii fullword
		$f2 = "WriteProcessMemory" ascii fullword
		$f3 = "Kernel32" ascii fullword
		$concat = { 00 41 6f 00 08 1e ?? 00 41 6f 00 08 1e ?? 00 41 6f 00 08}

	condition:
		filesize < 1000KB and $header_docf at 0 and #concat > 10 and $s1 and 2 of ( $f* )
}
rule SIGNATURE_BASE_MAL_CRIME_Suspicious_Hex_String_Jun21_1 : CRIME PE FILE
{
	meta:
		description = "Triggers on parts of a big hex string available in lots of crime'ish PE files."
		author = "Nils Kuhnert"
		id = "2ad208fa-c7a5-5df9-96fe-4a84dc770f0f"
		date = "2021-06-04"
		modified = "2023-12-05"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_crime_unknown.yar#L1-L16"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "37d60eb2daea90a9ba275e16115848c95e6ad87d20e4a94ab21bd5c5875a0a34"
		hash = "3380c8c56d1216fe112cbc8f1d329b59e2cd2944575fe403df5e5108ca21fc69"
		hash = "cd283d89b1b5e9d2875987025009b5cf6b137e3441d06712f49e22e963e39888"
		hash = "404efa6fb5a24cd8f1e88e71a1d89da0aca395f82d8251e7fe7df625cd8e80aa"
		hash = "479bf3fb8cff50a5de3d3742ab4b485b563b8faf171583b1015f80522ff4853e"
		logic_hash = "73144b14f3aa1a1d82df7710fa47049426bfbddeef75e85c8a0a559ad6ed05a3"
		score = 65
		quality = 85
		tags = "CRIME, PE, FILE"

	strings:
		$a1 = "07032114130C0812141104170C0412147F6A6A0C041F321104130C0412141104030C0412141104130C0412141104130C0412141104130C0412141104130C0412141104130C0412141104130C0412141122130C0412146423272A711221112B1C042734170408622513143D20262B0F323038692B312003271C170B3A2F286623340610241F001729210579223202642200087C071C17742417020620141462060F12141104130C0412141214001C0412011100160C0C002D2412130C0412141104130C04121A11041324001F140122130C0134171" ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 10MB and all of them
}
rule SIGNATURE_BASE_MAL_CRIME_Unknown_LNK_Jun21_1 : LNK POWERSHELL FILE
{
	meta:
		description = "Triggers on malicious link files which calls powershell with an obfuscated payload and downloads an HTA file."
		author = "Nils Kuhnert"
		id = "d1aac420-fd91-5577-8efd-fcdd7f733981"
		date = "2021-06-04"
		modified = "2023-12-05"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_crime_unknown.yar#L18-L33"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "8fc7f25da954adcb8f91d5b0e1967e4a90ca132b280aa6ae73e150b55d301942"
		hash = "f5da192f4e4dfb6b728aee1821d10bec6d68fb21266ce32b688e8cae7898a522"
		hash = "183a9b3c04d16a1822c788d7a6e78943790ee2cdeea12a38e540281091316e45"
		hash = "a38c6aa3e1c429a27226519b38f39f03b0b1b9d75fd43cd7e067c5e542967afe"
		hash = "455f7b6b975fb8f7afc6295ec40dae5696f5063d1651f3b2477f10976a3b67b2"
		logic_hash = "460e764cbd9fbfa1a2156059d0042a0bea5a939d501050a733a789d236015d37"
		score = 75
		quality = 85
		tags = "LNK, POWERSHELL, FILE"

	strings:
		$uid = "S-1-5-21-1437133880-1006698037-385855442-1004" wide

	condition:
		uint16( 0 ) == 0x004c and all of them
}
rule SIGNATURE_BASE_MAL_CRIME_Unknown_ISO_Jun21_1 : ISO POWERSHELL LNK FILE
{
	meta:
		description = "Triggers on ISO files that mimick NOBELIUM TTPs, but uses LNK files that call powershell instead."
		author = "Nils Kuhnert"
		id = "73a1fc44-45c4-5253-b81d-fa6686dc0644"
		date = "2021-06-04"
		modified = "2023-12-05"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_crime_unknown.yar#L35-L50"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "425dbed047dd2ce760d0848ebf7ad04b1ca360f111d557fc7bf657ae89f86d36"
		hash = "f6944b6bca627e219d9c5065f214f95eb2226897a3b823b645d0fd78c281b149"
		hash = "14d70a8bdd64e9a936c2dc9caa6d4506794505e0e3870e3a25d9d59bcafb046e"
		hash = "9b2ca8eb6db34b07647a74171a5ff4c0a2ca8000da9876ed2db6361958c5c080"
		logic_hash = "49b61f498d3f4ee249d9687277e581a39e08ebb4e1a293170058fb5f770bde1f"
		score = 75
		quality = 85
		tags = "ISO, POWERSHELL, LNK, FILE"

	strings:
		$uid = "S-1-5-21-1437133880-1006698037-385855442-1004" wide
		$magic = "CD001" ascii

	condition:
		filesize < 5MB and all of them
}
rule SIGNATURE_BASE_MAL_Fake_Document_Software_Indicators_Nov23 : FILE
{
	meta:
		description = "Detects indicators of fake document/image utility software that acts as a downloader for additional malware"
		author = "Jonathan Peters"
		id = "231474cd-1ec9-5738-bf48-ef707689056d"
		date = "2023-11-13"
		modified = "2024-04-24"
		reference = "https://nochlab.blogspot.com/2023/09/net-in-javascript-fake-pdf-converter.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_fake_document_software.yar#L1-L20"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "ac5356ae011effb9d401bf428c92a48cf82c9b61f4c24a29a9718e3379f90f1d"
		hash = "d1c29c2243c511ca3264ad568a6be62f374e104b903eca93debce6691e1c5007"
		logic_hash = "5f0a088bf672559fbac90313768d41b79be7f1f56c6ddb36f0dcd265a07f98b2"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$ = "tweakscode.com" wide
		$ = "www.createmygif.com" wide
		$ = "www.videownload.com" wide
		$ = "www.pdfconverterz.com" wide
		$ = "www.pdfconvertercompare.com" wide

	condition:
		uint16( 0 ) == 0x5a4d and 1 of them
}
rule SIGNATURE_BASE_Crime_Win32_Ransom_Maze_Dll_1 : FILE
{
	meta:
		description = "Detects Maze ransomware payload dll unpacked"
		author = "@VK_Intel"
		id = "873aea2b-2dd4-5682-b979-35e73fbc189f"
		date = "2020-04-18"
		modified = "2023-12-05"
		reference = "https://twitter.com/VK_Intel/status/1251388507219726338"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_maze_ransomware.yar#L1-L17"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "5b76636c05141687fa5cc507ac67d6a5d1f6c89166fd302e94fe61b412451159"
		score = 75
		quality = 85
		tags = "FILE"
		tlp = "white"

	strings:
		$str1 = "Maze Ransomware" wide
		$str2 = "--logging" wide
		$str3 = "DECRYPT-FILES.txt" wide
		$tick_server_call = { ff ?? ?? 8b ?? ?? ?? ?? ?? ff d6 8b ?? 89 f9 50 ff ?? ?? ff d6 8d ?? ?? ?? 89 ?? ?? ?? 56 e8 ?? ?? ?? ?? 83 c4 04 b9 67 66 66 66 89 c5 f7 e9 89 d0 d1 fa c1 e8 1f 01 c2 8d ?? ?? 29 c5 56 e8 ?? ?? ?? ?? 83 c4 04 b9 56 55 55 55 89 c6 f7 e9 89 f9 89 d0 c1 e8 1f 01 d0 8d ?? ?? 29 c6 8b ?? 55 56 ff ?? ?? 85 c0 0f ?? ?? ?? ?? ?? 89 ?? ?? ?? 8b ?? ?? ?? ?? ?? 89 c5 50 ff d3 89 c6 ff ?? ?? ?? ff d3 8b ?? ?? ?? 01 f0 3d ff 03 00 00 0f ?? ?? ?? ?? ?? 55 ff ?? ?? ?? 68 a2 95 c3 00 53 ff ?? ?? ?? ?? ?? 83 c4 10 c6 ?? ?? ?? c6 ?? ?? ?? ?? }

	condition:
		( uint16( 0 ) == 0x5a4d and 3 of them ) or all of them
}
rule SIGNATURE_BASE_MAL_PHISH_Shellcode_Enc_Payload_Feb25 : FILE
{
	meta:
		description = "Detects unknown of phishing-delivered malware"
		author = "X__Junior"
		id = "8459c5ba-37ec-59bd-8d4a-5ab7b6bb4553"
		date = "2025-02-14"
		modified = "2025-03-20"
		reference = "https://x.com/dtcert/status/1890384162818802135"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_phish_feb25.yar#L1-L14"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "247e6a648bb22d35095ba02ef4af8cfe0a4cdfa25271117414ff2e3a21021886"
		logic_hash = "144323294a8353956adf7a9b2a316e1e7606e882f85b8187c016d5acdcc254cc"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$op1 = { 48 89 EA FF D0 48 89 E9 4C 8D 4C 24 ?? 41 B8 ?? ?? ?? ?? 48 89 C7 48 89 C3 48 89 EA F3 A4 48 89 C1 41 FF D4 31 C9 FF D3}

	condition:
		uint16( 0 ) == 0x5a4d and $op1
}
rule SIGNATURE_BASE_MAL_PHISH_Final_Payload_Feb25
{
	meta:
		description = "Detects possible final payload of phishing-delivered malware, where embedded shellcode is used to decrypt and execute the payload after user-supplied password input."
		author = "X__Junior"
		id = "9014e1f2-09c2-5ba0-8b7c-6ae8c069d1f7"
		date = "2025-02-14"
		modified = "2025-03-20"
		reference = "https://x.com/dtcert/status/1890384162818802135"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_phish_feb25.yar#L16-L35"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "de384aba6b0c6800095eb530954aa718d4ed96cccfc0b1e5e4d01404f3518a77"
		logic_hash = "3251d68a019d873987966d46c9e474e5a1ebbca4a33a8bf1e3c3ce119db8ab8c"
		score = 80
		quality = 85
		tags = ""

	strings:
		$s1 = "%lu: %s %s" wide
		$s2 = "(Direct Inbound)" wide
		$s3 = "(Primary Domain)" wide
		$s4 = "(Forest Tree Root" wide
		$s5 = "(Native Mode)" wide
		$s6 = "(In Forest)" wide
		$s7 = "(None)" wide

	condition:
		all of them
}
rule SIGNATURE_BASE_SUSP_Sysinternals_Desktops_Anomaly_Feb25 : FILE
{
	meta:
		description = "Detects anomalies in Sysinternals Desktops binaries"
		author = "Florian Roth"
		id = "5a586222-9263-5079-be48-9cfa464440d4"
		date = "2025-02-14"
		modified = "2025-03-20"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_phish_feb25.yar#L37-L60"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "5b8f64e090c7c9012e656c222682dfae7910669c7b7afaca35829cd1cc2eac17"
		hash = "d0f7f3f58e0dfcfd81235379bb5a236f40be490207d3bf45f190a264879090db"
		hash = "a83dc4d69a3de72aed4d1933db2ca120657f06adc6683346afbd267b8b7d27d0"
		hash = "9ebfe694914d337304edded8b6406bd3fbff1d4ee110ef3a8bf95c3fb5de7c38"
		hash = "9a5b9d89686de129a7b1970d5804f0f174156143ccfcd2cf669451c1ad4ab97e"
		hash = "ff82c4c679c5486aed2d66a802682245a1e9cd7d6ceb65fa0e7b222f902998e8"
		hash = "1da91d2570329f9e214f51bc633283f10bd55a145b7b3d254e03175fd86292d9"
		logic_hash = "e17b831c9644cfe6a4c82537a01cb937007308d94eb2b78f97f5fbad3546404a"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Software\\Sysinternals\\Desktops" wide fullword
		$s2 = "Sysinternals Desktops" wide fullword
		$s3 = "http://www.sysinternals.com" wide fullword

	condition:
		uint16( 0 ) == 0x5a4d and filesize > 350KB and all of them
}
rule SIGNATURE_BASE_EXPL_LNX_CUPS_CVE_2024_47177_Sep24 : CVE_2024_47177 FILE
{
	meta:
		description = "Detects exploit code for CUPS CVE-2024-47177"
		author = "Florian Roth"
		id = "a7b986ad-e943-5350-a6e0-34c40f07874c"
		date = "2024-09-27"
		modified = "2024-12-12"
		reference = "https://github.com/OpenPrinting/cups-browsed/security/advisories/GHSA-rj88-6mr5-rcw8"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cups_sep24.yar#L2-L15"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "633314dea5e3cbdf3cef6e4f18c2efca261dfc600bb9c11d0834fdae102ac9e6"
		score = 75
		quality = 85
		tags = "CVE-2024-47177, FILE"

	strings:
		$s1 = "FoomaticRIPCommandLine: " ascii
		$s2 = "cupsFilter2 : " ascii

	condition:
		filesize < 400KB and all of them
}
rule SIGNATURE_BASE_SUSP_EXPL_LNX_CUPS_CVE_2024_47177_Sep24 : CVE_2024_47177
{
	meta:
		description = "Detects suspicious FoomaticRIPCommandLine command in printer config, which could be used to exploit CUPS CVE-2024-47177"
		author = "Florian Roth"
		id = "cb76f1c7-6dc0-5fed-a970-2a4890db46d3"
		date = "2024-09-27"
		modified = "2024-12-12"
		reference = "https://github.com/OpenPrinting/cups-browsed/security/advisories/GHSA-rj88-6mr5-rcw8"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cups_sep24.yar#L17-L38"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "2158ca8a08cb7552e2a437de025e3aad63ddc5417245e6ede7283d3bd0fc159b"
		score = 65
		quality = 85
		tags = "CVE-2024-47177"

	strings:
		$ = "FoomaticRIPCommandLine: \"bash " ascii
		$ = "FoomaticRIPCommandLine: \"sh " ascii
		$ = "FoomaticRIPCommandLine: \"python " ascii
		$ = "FoomaticRIPCommandLine: \"perl " ascii
		$ = "FoomaticRIPCommandLine: \"echo " ascii
		$ = "FoomaticRIPCommandLine: \\\"bash " ascii
		$ = "FoomaticRIPCommandLine: \\\"sh " ascii
		$ = "FoomaticRIPCommandLine: \\\"python " ascii
		$ = "FoomaticRIPCommandLine: \\\"perl " ascii
		$ = "FoomaticRIPCommandLine: \\\"echo " ascii

	condition:
		1 of them
}
rule SIGNATURE_BASE_LOG_EXPL_Sharepoint_CVE_2023_29357_Sep23_1 : CVE_2023_29357
{
	meta:
		description = "Detects log entries that could indicate a successful exploitation of CVE-2023-29357 on Microsoft SharePoint servers with the published Python POC"
		author = "Florian Roth (with help from @LuemmelSec)"
		id = "9fa77216-c0d6-55e5-bbcc-adb9438ca456"
		date = "2023-09-28"
		modified = "2023-10-01"
		reference = "https://twitter.com/Gi7w0rm/status/1706764212704591953?s=20"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_sharepoint_cve_2023_29357.yar#L2-L20"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "03e3a4715c8683dc8d03ad6720c1c9b40482bd0bfa3020aa1152565ec9ec929f"
		score = 70
		quality = 85
		tags = "CVE-2023-29357"

	strings:
		$xr1 = /GET [a-z\.\/_]{0,40}\/web\/(siteusers|currentuser) - (80|443) .{10,200} (python-requests\/[0-9\.]{3,8}|-) [^ ]{1,160} [^4]0[0-9] /

	condition:
		$xr1
}
rule SIGNATURE_BASE_HKTL_EXPL_POC_PY_Sharepoint_CVE_2023_29357_Sep23_1 : CVE_2023_29357 FILE
{
	meta:
		description = "Detects a Python POC to exploit CVE-2023-29357 on Microsoft SharePoint servers"
		author = "Florian Roth"
		id = "2be524ab-f360-56b8-9ce3-e15036855c67"
		date = "2023-10-01"
		modified = "2023-10-01"
		reference = "https://github.com/Chocapikk/CVE-2023-29357"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_sharepoint_cve_2023_29357.yar#L22-L35"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "fec7762ab23ba5ee9e793000d080b1d64b93157c6ead9e6939ccfb3c168dd360"
		score = 80
		quality = 85
		tags = "CVE-2023-29357, FILE"

	strings:
		$x1 = "encoded_payload = base64.urlsafe_b64encode(json.dumps(payload).encode()).rstrip(b'=')"

	condition:
		filesize < 30KB and $x1
}
rule SIGNATURE_BASE_HKTL_EXPL_POC_NET_Sharepoint_CVE_2023_29357_Sep23_1 : CVE_2023_29357 FILE
{
	meta:
		description = "Detects a C# POC to exploit CVE-2023-29357 on Microsoft SharePoint servers"
		author = "Florian Roth"
		id = "aa6aeb00-b162-538c-a670-cbff525dd8f1"
		date = "2023-10-01"
		modified = "2023-12-05"
		reference = "https://github.com/LuemmelSec/CVE-2023-29357"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_sharepoint_cve_2023_29357.yar#L37-L62"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "cf621cc9c5074f531df61623b09db68478e94ae6a9a7acc26aa8d9dde79bd30c"
		score = 80
		quality = 85
		tags = "CVE-2023-29357, FILE"

	strings:
		$x1 = "{f22d2de0-606b-4d16-98d5-421f3f1ba8bc}" ascii wide
		$x2 = "{F22D2DE0-606B-4D16-98D5-421F3F1BA8BC}" ascii wide
		$s1 = "Bearer"
		$s2 = "hashedprooftoken"
		$s3 = "/_api/web/"
		$s4 = "X-PROOF_TOKEN"
		$s5 = "00000003-0000-0ff1-ce00-000000000000"
		$s6 = "IsSiteAdmin"

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 800KB and ( 1 of ( $x* ) or all of ( $s* ) )
}
rule SIGNATURE_BASE_LOG_EXPL_Ivanti_EPMM_Mobileiron_Core_CVE_2023_35078_Jul23_1 : CVE_2023_35078
{
	meta:
		description = "Detects the successful exploitation of Ivanti Endpoint Manager Mobile (EPMM) / MobileIron Core CVE-2023-35078"
		author = "Florian Roth"
		id = "44cca0b5-3851-5786-82fd-ce3ccb566453"
		date = "2023-07-25"
		modified = "2023-12-05"
		reference = "Ivanti Endpoint Manager Mobile (EPMM) CVE-2023-35078 - Analysis Guidance"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_ivanti_epmm_mobileiron_cve_2023_35078.yar#L2-L14"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ebc59032b7450aa438ca30170560c95550cda6ff7774b8ce1486309716da9e6c"
		score = 75
		quality = 85
		tags = "CVE-2023-35078"

	strings:
		$xr1 = /\/mifs\/aad\/api\/v2\/[^\n]{1,300} 200 [1-9][0-9]{0,60} /

	condition:
		$xr1
}
rule SIGNATURE_BASE_MAL_WAR_Ivanti_EPMM_Mobileiron_Mi_War_Aug23 : CVE_2023_35078 FILE
{
	meta:
		description = "Detects WAR file found in the Ivanti EPMM / MobileIron Core compromises exploiting CVE-2023-35078"
		author = "Florian Roth"
		id = "cd16cf29-a90d-5c3f-b66f-e9264dbf79fb"
		date = "2023-08-01"
		modified = "2023-12-05"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa23-213a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_ivanti_epmm_mobileiron_cve_2023_35078.yar#L16-L32"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "6255c75e2e52d779da39367e7a7d4b8d1b3c9c61321361952dcc05819251a127"
		logic_hash = "0083727e34118d628c8507459bfb7f949f11af8197e201066e29e263e2c3f944"
		score = 85
		quality = 85
		tags = "CVE-2023-35078, FILE"

	strings:
		$s1 = "logsPaths.txt" ascii fullword
		$s2 = "keywords.txtFirefox" ascii

	condition:
		uint16( 0 ) == 0x4b50 and filesize < 20KB and all of them
}
rule SIGNATURE_BASE_MAL_WAR_Ivanti_EPMM_Mobileiron_Logclear_JAVA_Aug23 : CVE_2023_35078 FILE
{
	meta:
		description = "Detects LogClear.class found in the Ivanti EPMM / MobileIron Core compromises exploiting CVE-2023-35078"
		author = "Florian Roth"
		id = "e1ef3bf3-0107-5ba6-a49f-71e079851a4f"
		date = "2023-08-01"
		modified = "2023-12-05"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa23-213a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_ivanti_epmm_mobileiron_cve_2023_35078.yar#L34-L53"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "deb381c25d7a511b9eb936129eeba2c0341cff7f4bd2168b05e40ab2ee89225e"
		logic_hash = "c42c2eca784d7089aab56addca11bad658a4a6c34a81ae823bd0c3dad41a1c99"
		score = 80
		quality = 85
		tags = "CVE-2023-35078, FILE"

	strings:
		$s1 = "logsPaths.txt" ascii fullword
		$s2 = "log file: %s, not read" ascii fullword
		$s3 = "/tmp/.time.tmp" ascii fullword
		$s4 = "readKeywords" ascii fullword
		$s5 = "\"----------------  ----------------" ascii fullword

	condition:
		uint16( 0 ) == 0xfeca and filesize < 20KB and 4 of them or all of them
}
rule SIGNATURE_BASE_APT_HKTL_Wiper_Whispergate_Jan22_1 : FILE
{
	meta:
		description = "Detects unknown wiper malware"
		author = "Florian Roth (Nextron Systems)"
		id = "f04b619e-1df2-5c51-9cab-4a0fffd1c042"
		date = "2022-01-16"
		modified = "2023-12-05"
		reference = "https://www.microsoft.com/security/blog/2022/01/15/destructive-malware-targeting-ukrainian-organizations/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ua_wiper_whispergate.yar#L2-L23"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "a196c6b8ffcb97ffb276d04f354696e2391311db3841ae16c8c9f56f36a38e92"
		logic_hash = "72eb50a70b3f2fbb232134ef4706dbb15bdb5893fe06d899bff3b7aacdfadd30"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$xc1 = { 41 41 41 41 41 00 59 6F 75 72 20 68 61 72 64 20
               64 72 69 76 65 20 68 61 73 20 62 65 65 6E 20 63
               6F 72 72 75 70 74 65 64 }
		$op1 = { 89 34 24 e8 3f ff ff ff 50 8d 65 f4 31 c0 59 5e 5f }
		$op2 = { 8d bd e8 df ff ff e8 04 de ff ff b9 00 08 00 00 f3 a5 c7 44 24 18 00 00 00 00 c7 44 24 14 00 00 00 00 c7 44 24 10 03 00 00 00 c7 44 24 0c 00 00 00 00 }
		$op3 = { c7 44 24 0c 00 00 00 00 c7 44 24 08 00 02 00 00 89 44 24 04 e8 aa fe ff ff 83 ec 14 89 34 24 e8 3f ff ff ff 50 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 100KB and ( 1 of ( $x* ) or 2 of them ) or all of them
}
rule SIGNATURE_BASE_APT_HKTL_Wiper_Whispergate_Jan22_2 : FILE
{
	meta:
		description = "Detects unknown wiper malware"
		author = "Florian Roth (Nextron Systems)"
		id = "822e5af5-9c51-5be3-94f1-7e0a714743e6"
		date = "2022-01-16"
		modified = "2023-12-05"
		reference = "https://www.microsoft.com/security/blog/2022/01/15/destructive-malware-targeting-ukrainian-organizations/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ua_wiper_whispergate.yar#L25-L57"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "dcbbae5a1c61dbbbb7dcd6dc5dd1eb1169f5329958d38b58c3fd9384081c9b78"
		logic_hash = "87a03e95bc1c33d1b3343ec7369c516bb15791943fbb122de11867ad4bddd565"
		score = 90
		quality = 85
		tags = "FILE"

	strings:
		$sc1 = { 70 00 6F 00 77 00 65 00 72 00 73 00 68 00 65 00
               6C 00 6C 00 00 27 2D 00 65 00 6E 00 63 00 20 00
               55 00 77 00 42 00 30 00 41 00 47 00 45 00 41 00
               63 00 67 00 42 00 30 00 41 00 43 }
		$sc2 = { 59 00 6C 00 66 00 77 00 64 00 77 00 67 00 6D 00
               70 00 69 00 6C 00 7A 00 79 00 61 00 70 00 68 }
		$s1 = "xownxloxadDxatxxax" wide
		$s2 = "0AUwBsAGUAZQBwACAALQBzACAAMQAwAA==" wide
		$s3 = "https://cdn.discordapp.com/attachments/" wide
		$s4 = "fffxfff.fff" ascii fullword
		$op1 = { 20 6b 85 b9 03 20 14 19 91 52 61 65 20 e1 ae f1 }
		$op2 = { aa ae 74 20 d9 7c 71 04 59 20 71 cc 13 91 61 20 97 3c 2a c0 }
		$op3 = { 38 9c f3 ff ff 20 f2 96 4d e9 20 5d ae d9 ce 58 20 4f 45 27 }
		$op4 = { d4 67 d4 61 80 1c 00 00 04 38 35 02 00 00 20 27 c0 db 56 65 20 3d eb 24 de 61 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 1000KB and 5 of them or 7 of them
}
rule SIGNATURE_BASE_APT_HKTL_Wiper_Whispergate_Stage3_Jan22 : FILE
{
	meta:
		description = "Detects reversed stage3 related to Ukrainian wiper malware"
		author = "Florian Roth (Nextron Systems)"
		id = "d5d562cd-03ef-5450-8044-3f538cea32d0"
		date = "2022-01-16"
		modified = "2023-12-05"
		reference = "https://twitter.com/juanandres_gs/status/1482827018404257792"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ua_wiper_whispergate.yar#L59-L74"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "9ef7dbd3da51332a78eff19146d21c82957821e464e8133e9594a07d716d892d"
		logic_hash = "b06536b6a6eebd5fb398ba2617bf68a5b2c4b0035766b3cd0fc03d95019891ec"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$xc1 = { 65 31 63 70 00 31 79 72 61 72 62 69 4c 73 73 61 6c 43 00 6e 69 61 4d }
		$s1 = "lld." wide

	condition:
		uint16( filesize -2 ) == 0x4d5a and filesize < 5000KB and all of them
}
rule SIGNATURE_BASE_MAL_OBFUSC_Unknown_Jan22_1 : FILE
{
	meta:
		description = "Detects samples similar to reversed stage3 found in Ukrainian wiper incident named WhisperGate"
		author = "Florian Roth (Nextron Systems)"
		id = "647c0092-b03d-5627-8568-ddaa982c73a1"
		date = "2022-01-16"
		modified = "2023-12-05"
		reference = "https://twitter.com/juanandres_gs/status/1482827018404257792"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ua_wiper_whispergate.yar#L76-L101"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "9ef7dbd3da51332a78eff19146d21c82957821e464e8133e9594a07d716d892d"
		logic_hash = "26a295d3b78c3a33d776a648aa0f410ac7cb5021ad9d3b294ff9629d6ba7132a"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$xc1 = { 37 00 63 00 38 00 63 00 62 00 35 00 35 00 39 00
               38 00 65 00 37 00 32 00 34 00 64 00 33 00 34 00
               33 00 38 00 34 00 63 00 63 00 65 00 37 00 34 00
               30 00 32 00 62 00 31 00 31 00 66 00 30 00 65 }
		$xc2 = { 4D 61 69 6E 00 43 6C 61 73 73 4C 69 62 72 61 72
               79 31 00 70 63 31 65 }
		$s1 = ".dll" wide
		$s2 = "%&%,%s%" ascii fullword
		$op1 = { a2 87 fa b1 44 a5 f5 12 da a7 49 11 5c 8c 26 d4 75 }
		$op2 = { d7 af 52 38 c7 47 95 c8 0e 88 f3 d5 0b }
		$op3 = { 6c 05 df d6 b8 ac 11 f2 67 16 cb b7 34 4d b6 91 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 1000KB and ( 1 of ( $x* ) or 3 of them )
}
rule SIGNATURE_BASE_MAL_Unknown_Discord_Characteristics_Jan22_1 : FILE
{
	meta:
		description = "Detects unknown malware with a few indicators also found in Wiper malware"
		author = "Florian Roth (Nextron Systems)"
		id = "23ee5319-6a72-517b-8ea0-55063b6b862c"
		date = "2022-01-16"
		modified = "2023-12-05"
		reference = "https://www.microsoft.com/security/blog/2022/01/15/destructive-malware-targeting-ukrainian-organizations/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ua_wiper_whispergate.yar#L103-L119"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "dcbbae5a1c61dbbbb7dcd6dc5dd1eb1169f5329958d38b58c3fd9384081c9b78"
		logic_hash = "f9cf4a15be0ab35a0d0f0c9b1a191f623f905c8fc9da651872de7c025a27a806"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "xownxloxadDxatxxax" wide
		$s2 = "https://cdn.discordapp.com/attachments/" wide

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 1000KB and all of them
}
rule SIGNATURE_BASE_APT_MAL_BKA_Goldenspy_Aug20_1 : FILE
{
	meta:
		description = "Detects variants of GoldenSpy Malware"
		author = "BKA"
		id = "4f47087e-6e68-53ff-9446-72a1751da359"
		date = "2020-08-21"
		modified = "2023-12-05"
		reference = "https://www.bka.de/SharedDocs/Kurzmeldungen/DE/Warnhinweise/200821_Cyberspionage.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_goldenspy.yar#L1-L19"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ba81a2b081842aaf06bbf623640a87946894df83fd0d7b7149c48afa8ed0a081"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$str01 = {c78510ffffff00000000 c78514ffffff0f000000 c68500ffffff00 c78528ffffff00000000 c7852cffffff0f000000 c68518ffffff00 c78540ffffff00000000 c78544ffffff0f000000 c68530ffffff00 c645fc14 80bd04feffff00}
		$str02 = "Ryeol HTTP Client Class" ascii
		$str03 = "----RYEOL-FB3B405B7EAE495aB0C0295C54D4E096-" ascii
		$str04 = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\fwkp.exe" ascii
		$str05 = "svmm" ascii
		$str06 = "PROTOCOL_" ascii
		$str07 = "softList" ascii
		$str08 = "excuteExe" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 5 of ( $str* )
}

rule SIGNATURE_BASE_SUSP_Hxd_Icon_Anomaly_May23_1 : FILE
{
	meta:
		description = "Detects suspicious use of the the free hex editor HxD's icon in PE files that don't seem to be a legitimate version of HxD"
		author = "Florian Roth"
		id = "3ac8cc92-6d76-5787-ada0-cfb6eabb4b20"
		date = "2023-05-29"
		modified = "2023-12-05"
		reference = "https://www.linkedin.com/feed/update/urn:li:activity:7068631930040188929/?utm_source=share&utm_medium=member_ios"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_file_anomalies.yar#L32-L84"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a328687ac8b868fb78a49188b286a8951c6043a7ff6ff0c7a23c3f9b3ef15eb2"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$ac1 = { 99 00 77 0D DD 09 99 80 99 00 77 0D DD 09 99 80
               99 00 77 0D DD 09 99 80 99 00 77 0D DD 09 99 80
               99 00 77 0D DD 09 99 80 99 00 77 0D DD 09 99 80
               99 00 77 0D DD 09 99 80 99 00 77 0D DD 09 99 80
               99 00 77 0D DD 09 99 80 99 00 77 0D D0 99 98 09
               99 99 00 0D D0 99 98 09 99 99 00 0D D0 99 98 09
               99 99 00 0D D0 99 98 0F F9 99 00 0D D0 99 98 09
               9F 99 00 0D D0 99 98 09 FF 99 00 0D D0 99 98 09
               FF 99 00 0D D0 99 98 09 99 99 00 0D D0 99 98 0F
               F9 99 00 0D D0 99 98 09 99 99 00 0D 09 99 80 9F
               F9 99 99 00 09 99 80 99 F9 99 99 00 09 99 80 FF }
		$ac2 = { FF FF FF FF FF FF FF FF FF FF FF FF FF FF B9 DE
               FA 68 B8 F4 39 A2 F1 39 A2 F1 39 A2 F1 39 A2 F1
               39 A2 F1 39 A2 F1 68 B8 F4 B9 DE FA FF FF FF FF
               FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF }
		$s1 = { 00 4D 00 61 00 EB 00 6C 00 20 00 48 00 F6 00 72 00 7A }
		$s2 = "mh-nexus.de" ascii wide
		$upx1 = "UPX0" ascii fullword
		$xs1 = "terminator" ascii wide fullword
		$xs2 = "Terminator" ascii wide fullword

	condition:
		uint16( 0 ) == 0x5a4d and 1 of ( $ac* ) and ( not 1 of ( $s* ) or filesize > 6930000 or ( pe.is_32bit ( ) and filesize < 1540000 and not $upx1 ) or ( pe.is_32bit ( ) and filesize < 590000 and $upx1 ) or ( pe.is_64bit ( ) and filesize < 6670000 and not $upx1 ) or ( pe.is_64bit ( ) and filesize < 1300000 and $upx1 ) or 1 of ( $xs* ) )
}
rule SIGNATURE_BASE_MAL_Prolock_Malware : FILE
{
	meta:
		description = "Detects Prolock malware in encrypted and decrypted mode"
		author = "Frank Boldewin (@r3c0nst)"
		id = "269bf0c5-8315-5405-8e44-e2cc5507a36a"
		date = "2020-05-17"
		modified = "2023-12-05"
		reference = "https://raw.githubusercontent.com/fboldewin/YARA-rules/master/Prolock.Malware.yar"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_ransom_prolock.yar#L1-L20"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "a6ded68af5a6e5cc8c1adee029347ec72da3b10a439d98f79f4b15801abd7af0"
		hash = "dfbd62a3d1b239601e17a5533e5cef53036647901f3fb72be76d92063e279178"
		logic_hash = "da8a0ec683475019daddd4acdd00d4c36eedacad3deef2be4220b86cbf5f9df0"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$DecryptionRoutine = {01 C2 31 DB B8 ?? ?? ?? ?? 31 04 1A 81 3C 1A}
		$DecryptedString1 = "support981723721@protonmail.com" nocase ascii
		$DecryptedString2 = "Your files have been encrypted by ProLock Ransomware" nocase ascii
		$DecryptedString3 = "msaoyrayohnp32tcgwcanhjouetb5k54aekgnwg7dcvtgtecpumrxpqd.onion" nocase ascii
		$CryptoCode = {B8 63 51 E1 B7 31 D2 8D BE ?? ?? ?? ?? B9 63 51 E1 B7 81 C1 B9 79 37 9E}

	condition:
		(( uint16( 0 ) == 0x5A4D ) or ( uint16( 0 ) == 0x4D42 ) ) and filesize < 100KB and ( ( $DecryptionRoutine ) or ( 1 of ( $DecryptedString* ) and $CryptoCode ) )
}
rule SIGNATURE_BASE_HKTL_Bruteratel_Badger_Indicators_Oct22_4 : FILE
{
	meta:
		description = "Detects Brute Ratel C4 badger indicators"
		author = "Matthew @embee_research, Florian Roth"
		id = "a62d08ae-0fb3-55e9-b6f8-7940f8032e4a"
		date = "2022-10-12"
		modified = "2023-12-05"
		reference = "https://twitter.com/embee_research/status/1580030310778953728"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/hktl_bruteratel_c4_badger.yar#L2-L19"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9af05225f462c8d4ec1fb14dc06bb789f76b0d818cb82c3dfcd5abc693727f33"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = { b? 89 4d 39 8c }
		$s2 = { b? bd ca 3b d3 }
		$s3 = { b? b2 c1 06 ae }
		$s4 = { b? 74 eb 1d 4d }

	condition:
		filesize < 8000KB and all of ( $s* ) and not uint8( 0 ) == 0x02
}
rule SIGNATURE_BASE_EXPL_SUSP_Outlook_CVE_2023_23397_Exfil_IP_Mar23 : CVE_2023_23397 FILE
{
	meta:
		description = "Detects suspicious .msg file with a PidLidReminderFileParameter property exploiting CVE-2023-23397 (modified delivr.to rule - more specific = less FPs but limited to exfil using IP addresses, not FQDNs)"
		author = "delivr.to, Florian Roth, Nils Kuhnert, Arnim Rupp, marcin@ulikowski.pl"
		id = "d85bf1d9-aebe-5f8c-9dd4-c509f64e221a"
		date = "2023-03-15"
		modified = "2023-03-18"
		reference = "https://www.mdsec.co.uk/2023/03/exploiting-cve-2023-23397-microsoft-outlook-elevation-of-privilege-vulnerability/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_outlook_cve_2023_23397.yar#L41-L81"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "47fee24586cd2858cfff2dd7a4e76dc95eb44c8506791ccc2d59c837786eafe3"
		hash = "582442ee950d546744f2fa078adb005853a453e9c7f48c6c770e6322a888c2cf"
		hash = "6c0087a5cbccb3c776a471774d1df10fe46b0f0eb11db6a32774eb716e1b7909"
		hash = "7fb7a2394e03cc4a9186237428a87b16f6bf1b66f2724aea1ec6a56904e5bfad"
		hash = "eedae202980c05697a21a5c995d43e1905c4b25f8ca2fff0c34036bc4fd321fa"
		hash = "e7a1391dd53f349094c1235760ed0642519fd87baf740839817d47488b9aef02"
		logic_hash = "a8e8326f5aaa29b449f9203623e03d3d3a1d176bb764171d860afc510a1732e6"
		score = 75
		quality = 85
		tags = "CVE-2023-23397, FILE"

	strings:
		$psetid_app = { 02 20 06 00 00 00 00 00 C0 00 00 00 00 00 00 46 }
		$psetid_meeting = { 90 DA D8 6E 0B 45 1B 10 98 DA 00 AA 00 3F 13 05 }
		$psetid_task = { 03 20 06 00 00 00 00 00 c0 00 00 00 00 00 00 46 }
		$rfp = { 1F 85 00 00 }
		$u1 = { 5C 00 5C 00 (3? 00 2E|3? 00 3? 00 2E|3? 00 3? 00 3? 00 2E) 00 (3? 00 2E|3? 00 3? 00 2E|3? 00 3? 00 3? 00 2E) 00 (3? 00 2E|3? 00 3? 00 2E|3? 00 3? 00 3? 00 2E) 00 (3? 00 3? 00 3? 00|3? 00 3? 00|3? 00) }
		$u2 = { 00 5C 5C (3? 2E|3? 3? 2E|3? 3? 3? 2E) (3? 2E|3? 3? 2E|3? 3? 3? 2E) (3? 2E|3? 3? 2E|3? 3? 3? 2E) (3? 3? 3?|3? 3?|3?) }
		$fp_msi1 = {84 10 0C 00 00 00 00 00 C0 00 00 00 00 00 00 46}

	condition:
		( uint16( 0 ) == 0xCFD0 and 1 of ( $psetid* ) or uint32be( 0 ) == 0x789F3E22 ) and any of ( $u* ) and $rfp and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_SUSP_BAT_OBFUSC_Jul24_1 : FILE
{
	meta:
		description = "Detects indicators of obfuscation in Windows Batch files"
		author = "Florian Roth"
		id = "801e7efc-2c31-5590-afcd-9e11072c9c65"
		date = "2024-07-12"
		modified = "2024-12-12"
		reference = "https://x.com/0xToxin/status/1811656147943752045"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/susp_bat_obfusc_jul24.yar#L2-L16"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "683f4651eb8c5b74eca16e7f97c5c44f0d70f045ea49f1f3726cb6975aba2ab9"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "&&set "

	condition:
		filesize < 300KB and uint32( 0 ) == 0x20746573 and $s1 in ( 0 .. 32 )
}
rule SIGNATURE_BASE_SUSP_BAT_OBFUSC_Jul24_2 : FILE
{
	meta:
		description = "Detects indicators of obfuscation in Windows Batch files"
		author = "Florian Roth"
		id = "999cd365-2862-5618-b0b6-ee45dea1e9cf"
		date = "2024-07-12"
		modified = "2024-12-12"
		reference = "https://x.com/0xToxin/status/1811656147943752045"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/susp_bat_obfusc_jul24.yar#L18-L35"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "729ec93d180bf39c146c3fd847655340428abc3231b556ca51d3ca68825e7c3e"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "&&set "

	condition:
		filesize < 300KB and #s1 > 30 and uint16( filesize -2 ) == 0x0a0d and uint8( filesize -3 ) == 0x25
}
rule SIGNATURE_BASE_SUSP_BAT_OBFUSC_Jul24_3 : FILE
{
	meta:
		description = "Detects indicators of obfuscation in Windows Batch files"
		author = "Florian Roth"
		id = "a484ed03-8588-55e7-9674-b1208e14eb3f"
		date = "2024-07-12"
		modified = "2024-12-12"
		reference = "https://x.com/0xToxin/status/1811656147943752045"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/susp_bat_obfusc_jul24.yar#L37-L54"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ecbe7850349f0368620ff4294e5d0ca277983799eed510f8bf8abe4d4c192197"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "% \\\\%"
		$s2 = { 3D ?? 26 26 73 65 74 20 }

	condition:
		filesize < 300KB and all of them
}
rule SIGNATURE_BASE_ATM_Malware_Loup : FILE
{
	meta:
		description = "Detects ATM Malware Loup"
		author = "Frank Boldewin (@r3c0nst)"
		id = "2215a93f-d854-5f9b-b5cd-53962c45db08"
		date = "2020-08-17"
		modified = "2023-12-05"
		reference = "https://twitter.com/r3c0nst/status/1295275546780327936"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_atm_loup.yar#L3-L19"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "6c9e9f78963ab3e7acb43826906af22571250dc025f9e7116e0201b805dc1196"
		logic_hash = "5068c3f27cf821f512fb9a473d2bd45066d550f30fbc26f0cbebbe103e6f4ccb"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$String1 = "C:\\Users\\muham\\source\\repos\\loup\\Debug\\loup.pdb" ascii
		$String2 = "CurrencyDispenser1" ascii
		$Code = {50 68 C0 D4 01 00 8D 4D E8 51 68 2E 01 00 00 0F B7 55 08 52 E8}

	condition:
		uint16( 0 ) == 0x5A4D and filesize < 100KB and all of ( $String* ) and $Code
}
rule SIGNATURE_BASE_MAL_Sophos_XG_Pygmy_Goat_Magic_Strings : FILE
{
	meta:
		description = "Detects Pygmy Goat - a native x86-32 ELF shared object that was discovered on Sophos XG firewall devices, providing backdoor access to the device. This detection rule is based on the magic byte sequences used in C2 communications."
		author = "NCSC"
		id = "7df6c228-d569-5f1c-8bbb-4194347f99d1"
		date = "2024-10-22"
		modified = "2024-12-12"
		reference = "https://www.ncsc.gov.uk/static-assets/documents/malware-analysis-reports/pygmy-goat/ncsc-mar-pygmy-goat.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_sophos_pygmy_nov24.yar#L26-L44"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "71f70d61af00542b2e9ad64abd2dda7e437536ff"
		logic_hash = "df40e818002a72ee649dd2bb79cb59938dc108690cce03c99a72fc036406c4b2"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$c2_magic_handshake = ",bEB3?=o"
		$fake_ssh_banner = "SSH-2.0-D8pjE"
		$fake_ed25519_key = { 29 cc f0 cc 16 c5 46 6e 52 19 82 8e 86
      65 42 8c 1f 1a d4 c3 a5 b1 cb fc c0 26 6c 31 3c 5c 90 3a 24 7d e4 d3 57
      6d da 8e cb f4 66 d1 cb 81 4f 63 fd 4a fa 06 e4 7e 4c a0 95 91 bd cb 97
      a4 b3 0f }

	condition:
		uint32( 0 ) == 0x464c457f and any of them
}
rule SIGNATURE_BASE_MAL_Earthworm_Socks_Proxy_ID_Generation : FILE
{
	meta:
		description = "Detects EarthWorm - a reverse socks proxy used by the threat group that deployed Pygmy Goat malware on Sophos XG firewall devices. The detection is based on the pool num generation x86 assembly."
		author = "NCSC"
		id = "242777e4-3abb-50d8-8c45-746cc4a8b1f8"
		date = "2024-10-22"
		modified = "2024-12-12"
		reference = "https://www.ncsc.gov.uk/static-assets/documents/malware-analysis-reports/pygmy-goat/ncsc-mar-pygmy-goat.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_sophos_pygmy_nov24.yar#L46-L71"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "71f70d61af00542b2e9ad64abd2dda7e437536ff"
		logic_hash = "6837cba2637ed02d1d620c037b200d528c09a39498c1e320873a3a244e67932c"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$chartoi = {
         8b 45 ?? // MOV EAX,dword ptr [EBP + ??]
         c1 e0 07 // SHL EAX,0x7
         89 c1 // MOV ECX,EAX
         8b 55 ?? // MOV EDX,dword ptr [EBP + ??]
         8b 45 ?? // MOV EAX,dword ptr [EBP + ??]
         01 d0 // ADD EAX,EDX
         0f b6 00 // MOVZX EAX,byte ptr [EAX]
         0f be c0 // MOVSX EAX,AL
         01 c8 // ADD EAX,ECX
         89 45 ?? // MOV dword ptr [EBP + ??],EAX
         83 6d ?? 01 // SUB dword ptr [EBP + ??],0x1
      }

	condition:
		uint32( 0 ) == 0x464c457f and all of them
}

rule SIGNATURE_BASE_Sliver_Implant_32Bit
{
	meta:
		description = "Sliver 32-bit implant (with and without --debug flag at compile)"
		author = "gssincla@google.com"
		id = "6bc4d7d1-64cf-5920-8f07-54a8a7a94f26"
		date = "2022-11-18"
		modified = "2025-03-21"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_gcti_sliver.yar#L26-L94"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "911f4106350871ddb1396410d36f2d2eadac1166397e28a553b28678543a9357"
		logic_hash = "3fec6fbba86a24b395e58f02fb35a60b1b9a4b941b4d85c060cc6159c6aa8265"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s_tcppivot = { 81 ?? 74 63 70 70 [2-20] 81 ?? 04 69 76 6F 74  }
		$s_wg = { 66 81 ?? 77 67 }
		$s_dns = { 66 81 ?? 64 6E [2-20] 80 ?? 02 73 }
		$s_http = { 81 ?? 68 74 74 70 }
		$s_https = { 81 ?? 68 74 74 70 [2-20] 80 ?? 04 73 }
		$s_mtls = { 81 ?? 6D 74 6C 73 }
		$fp1 = "cloudfoundry" ascii fullword
		$fp2 = "googleapi.Error" ascii

	condition:
		4 of ( $s* ) and not 1 of ( $fp* ) and not pe.number_of_signatures > 0
}

rule SIGNATURE_BASE_Sliver_Implant_64Bit
{
	meta:
		description = "Sliver 64-bit implant (with and without --debug flag at compile)"
		author = "gssincla@google.com"
		id = "b84db933-0e11-5871-821d-43697c015665"
		date = "2022-11-18"
		modified = "2025-03-21"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_gcti_sliver.yar#L112-L183"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "2d1c9de42942a16c88a042f307f0ace215cdc67241432e1152080870fe95ea87"
		logic_hash = "ccfd944a5bc6521c89d44572910e2998e2404d472a593f9d97224d606d247bcd"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s_tcppivot = { 48 ?? 74 63 70 70 69 76 6F 74 }
		$s_namedpipe = { 48 ?? 6E 61 6D 65 64 70 69 70 [2-32] 80 ?? 08 65 }
		$s_https = { 81 ?? 68 74 74 70 [2-32] 80 ?? 04 73 }
		$s_wg = {66 81 ?? 77 67}
		$s_dns = { 66 81 ?? 64 6E [2-20] 80 ?? 02 73 }
		$s_mtls = {  81 ?? 6D 74 6C 73  }
		$fp1 = "cloudfoundry" ascii fullword
		$fp2 = "googleapi.Error" ascii

	condition:
		5 of ( $s* ) and not 1 of ( $fp* ) and not pe.number_of_signatures > 0
}
rule SIGNATURE_BASE_HKTL_NET_Edge_Saved_Passwords_Dumper_May26
{
	meta:
		description = "Detects an .NET based tool used to dump saved passwords from Microsoft Edge browser processes"
		author = "Florian Roth"
		id = "9d09b27e-16a4-5396-af53-2a2c672bc985"
		date = "2026-05-05"
		modified = "2026-05-15"
		reference = "https://github.com/L1v1ng0ffTh3L4N/Proof-of-Concepts/tree/main/EdgeSavedPasswordsDumper"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/hktl_edge_pwd_dumper_may25.yar#L1-L17"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b0bfcb6fd5968ed8b7b025dc6fb0e2874eb49e00ffc4827e3cd334a8c48d2f12"
		score = 80
		quality = 85
		tags = ""

	strings:
		$x1 = "SELECT ProcessId, Name, ParentProcessId FROM Win32_Process WHERE Name='msedge.exe'" wide
		$x2 = "Scanning process PID: " wide
		$s1 = "NSC\\t1_" wide
		$s2 = "\\*\\(\\)_\\-\\+=\\{\\}\\[\\]:;<>\\?/~\\s]{6,40})\\x20\\x00" wide

	condition:
		2 of them
}
rule SIGNATURE_BASE_SUSP_EXPL_Commvault_CVE_2025_57791_Aug25_2 : FILE
{
	meta:
		description = "Detects potential exploit for WT-2025-0050, authentication bypass through QCommand argument injection"
		author = "X__Junior"
		id = "4a581a0d-bd1d-599d-a1b9-936dbcda75a8"
		date = "2025-08-21"
		modified = "2026-05-15"
		reference = "https://labs.watchtowr.com/guess-who-would-be-stupid-enough-to-rob-the-same-vault-twice-pre-auth-rce-chains-in-commvault/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_commvault_cve_2025_57791.yar#L17-L30"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "61e3ddc09157badb2a1abf30da2cc35cac1a723db1134a37cb667be78209b845"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$sa1 = "_localadmin__"
		$sa2 = "-localadmin" base64

	condition:
		filesize < 20MB and all of them
}
rule SIGNATURE_BASE_EXPL_JSP_Commvault_CVE_2025_57791_Aug25_1 : FILE
{
	meta:
		description = "Detects potential exploit for WT-2025-0049, Post-Auth RCE with QCommand Path Traversal"
		author = "X__Junior"
		id = "6fdfa207-6361-5dfb-b313-623d7cfa95f1"
		date = "2025-08-21"
		modified = "2026-05-15"
		reference = "https://labs.watchtowr.com/guess-who-would-be-stupid-enough-to-rob-the-same-vault-twice-pre-auth-rce-chains-in-commvault/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_commvault_cve_2025_57791.yar#L50-L63"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "359b35ced874244901f64bc09456cfec7079421ef6bab58ea95a3b1887ecc858"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "<App_GetUserPropertiesResponse>" ascii
		$s2 = "getMethod('getRuntime').invoke(null).exec(param.cmd)" ascii

	condition:
		filesize < 50KB and all of them
}
rule SIGNATURE_BASE_EXPL_JSP_Commvault_CVE_2025_57791_Aug25_2 : FILE
{
	meta:
		description = "Detects potential exploit for WT-2025-0049, Post-Auth RCE with QCommand Path Traversal"
		author = "X__Junior"
		id = "068e1598-bcde-579d-910a-449a7ad903d6"
		date = "2025-08-21"
		modified = "2026-05-15"
		reference = "https://labs.watchtowr.com/guess-who-would-be-stupid-enough-to-rob-the-same-vault-twice-pre-auth-rce-chains-in-commvault/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_commvault_cve_2025_57791.yar#L65-L79"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "3375a33556a9b479f0c170de6e06c80ab0277f1356e4ac44bfe51d6a65a578fe"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "<App_UpdateUserPropertiesRequest>" ascii
		$s2 = "<description>" ascii
		$s3 = "getMethod('getRuntime').invoke(null).exec(param.cmd)" ascii

	condition:
		filesize < 50KB and all of them
}
rule SIGNATURE_BASE_EXPL_LOG_Commvault_CVE_2025_57791_Indicator_Shell_Drop_Aug25
{
	meta:
		description = "Detects suspicious log lines that indicate web shell drops into the Apache root folder of a Commvault installation"
		author = "Florian Roth"
		id = "efc7bcbc-6a38-5832-a12a-b8f9bd9125c1"
		date = "2025-08-21"
		modified = "2026-05-15"
		reference = "https://labs.watchtowr.com/guess-who-would-be-stupid-enough-to-rob-the-same-vault-twice-pre-auth-rce-chains-in-commvault/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_commvault_cve_2025_57791.yar#L81-L93"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f0e9fedba803b0cd8b1469bad7a50bf4647f7e2f786520caf5a79ac626879125"
		score = 70
		quality = 85
		tags = ""

	strings:
		$xr1 = /Results written to \[[C-Z]:\\Program Files\\Commvault\\ContentStore\\Apache\\webapps\\ROOT\\[^\\]{1,20}\.jsp\]/

	condition:
		$xr1
}
rule SIGNATURE_BASE_APT_Builder_PY_REDFLARE_2
{
	meta:
		description = "No description has been set in the source file - Signature Base"
		author = "FireEye"
		id = "74c56ee1-734e-5fdb-beee-6345a5993f68"
		date = "2020-12-01"
		modified = "2020-12-01"
		reference = "https://www.fireeye.com/blog/products-and-services/2020/12/fireeye-shares-details-of-recent-cyber-attack-actions-to-protect-community.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_fireeye_redteam_tools.yar#L1376-L1391"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "4410e95de247d7f1ab649aa640ee86fb"
		logic_hash = "0f28fb23c0c1d589466c7c541c8dc588b038d02dded0c66c4a448d1f768c95c5"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "<510sxxII"
		$s2 = "0x43,0x00,0x3a,0x00,0x5c,0x00,0x57,0x00,0x69,0x00,0x6e,0x00,0x64,0x00,0x6f,0x00,"
		$s3 = "parsePluginOutput"

	condition:
		all of them and #s2 == 2
}

rule SIGNATURE_BASE_APT_Backdoor_Win_GORAT_4 : FILE
{
	meta:
		description = "Verifies that the sample is a Windows PE that is less than 10MB in size and exports numerous functions that are known to be exported by the Gorat implant. This is done in an effort to provide detection for packed samples that may not have other strings but will need to replicate exports to maintain functionality."
		author = "FireEye"
		id = "ae67445c-e7fd-5858-be8b-7ee84a16a031"
		date = "2020-12-08"
		modified = "2025-02-12"
		reference = "https://www.fireeye.com/blog/products-and-services/2020/12/fireeye-shares-details-of-recent-cyber-attack-actions-to-protect-community.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_fireeye_redteam_tools.yar#L1706-L1716"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "f59095f0ab15f26a1ead7eed8cdb4902"
		logic_hash = "fa76e994beb2ab1b7950cf9d6391adf4e1ba45586a14a6340fa8a25a904821e4"
		score = 75
		quality = 85
		tags = "FILE"

	condition:
		uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 and filesize < 10MB and pe.exports ( "MemoryCallEntryPoint" ) and pe.exports ( "MemoryDefaultAlloc" ) and pe.exports ( "MemoryDefaultFree" ) and pe.exports ( "MemoryDefaultFreeLibrary" ) and pe.exports ( "MemoryDefaultGetProcAddress" ) and pe.exports ( "MemoryDefaultLoadLibrary" ) and pe.exports ( "MemoryFindResource" ) and pe.exports ( "MemoryFindResourceEx" ) and pe.exports ( "MemoryFreeLibrary" ) and pe.exports ( "MemoryGetProcAddress" ) and pe.exports ( "MemoryLoadLibrary" ) and pe.exports ( "MemoryLoadLibraryEx" ) and pe.exports ( "MemoryLoadResource" ) and pe.exports ( "MemoryLoadString" ) and pe.exports ( "MemoryLoadStringEx" ) and pe.exports ( "MemorySizeofResource" ) and pe.exports ( "callback" ) and pe.exports ( "crosscall2" ) and pe.exports ( "crosscall_386" )
}
rule SIGNATURE_BASE_MAL_Backdoor_DLL_Nov23_1 : CVE_2023_4966 FILE
{
	meta:
		description = "Detects a backdoor DLL, that was seen being used by LockBit 3.0 affiliates exploiting CVE-2023-4966"
		author = "X__Junior"
		id = "3588d437-b561-5380-8dac-73a31f4cdb5a"
		date = "2023-11-23"
		modified = "2023-12-05"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa23-325a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ransom_lockbit_citrixbleed_nov23.yar#L1-L22"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "cc21c77e1ee7e916c9c48194fad083b2d4b2023df703e544ffb2d6a0bfc90a63"
		hash = "0eb66eebb9b4d671f759fb2e8b239e8a6ab193a732da8583e6e8721a2670a96d"
		logic_hash = "6788d37301bb82bd4d9584e192e2fb14d4f6c77801b70299097d8ba139219394"
		score = 80
		quality = 85
		tags = "CVE-2023-4966, FILE"

	strings:
		$s1 = "ERROR GET INTERVAL" ascii
		$s2 = "OFF HIDDEN MODE" ascii
		$s3 = "commandMod:" ascii
		$s4 = "RESULT:" ascii
		$op1 = { C7 44 24 ?? 01 00 00 00 C7 84 24 ?? ?? ?? ?? FF FF FF FF 83 7C 24 ?? 00 74 ?? 83 BC 24 ?? ?? ?? ?? 00 74 ?? 4C 8D 8C 24 ?? ?? ?? ?? 41 B8 00 04 00 00 48 8D 94 24 ?? ?? ?? ?? 48 8B 4C 24 ?? FF 15 }
		$op2 = { 48 C7 44 24 ?? 00 00 00 00 C7 44 24 ?? 00 00 00 00 C7 44 24 ?? 03 00 00 00 48 8D 0D ?? ?? ?? ?? 48 89 4C 24 ?? 4C 8D 0D ?? ?? ?? ?? 44 0F B7 05 ?? ?? ?? ?? 48 8B D0 48 8B 4C 24 ?? FF 15 }

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or all of ( $op* ) )
}
rule SIGNATURE_BASE_MAL_Trojan_DLL_Nov23 : CVE_2023_4966 FILE
{
	meta:
		description = "Detects a trojan DLL that installs other components - was seen being used by LockBit 3.0 affiliates exploiting CVE-2023-4966"
		author = "X__Junior"
		id = "1dd87d0a-2b8b-5386-8fdd-40d184c731a4"
		date = "2023-11-23"
		modified = "2023-12-05"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa23-325a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ransom_lockbit_citrixbleed_nov23.yar#L24-L39"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "e557e1440e394537cca71ed3d61372106c3c70eb6ef9f07521768f23a0974068"
		logic_hash = "9be42742711b4d0440244b507945e074b61c456588580b3263f899a7eb84d8aa"
		score = 80
		quality = 85
		tags = "CVE-2023-4966, FILE"

	strings:
		$op1 = { C7 84 24 ?? ?? ?? ?? 52 70 63 53 C7 84 24 ?? ?? ?? ?? 74 72 69 6E C7 84 24 ?? ?? ?? ?? 67 42 69 6E C7 84 24 ?? ?? ?? ?? 64 69 6E 67 C7 84 24 ?? ?? ?? ?? 43 6F 6D 70 C7 84 24 ?? ?? ?? ?? 6F 73 65 41 C7 84 24 ?? ?? ?? ?? 00 40 01 01 }
		$op2 = { C7 84 24 ?? ?? ?? ?? 6C 73 61 73 C7 84 24 ?? ?? ?? ?? 73 70 69 72 66 C7 84 24 ?? ?? 00 00 70 63 }
		$op3 = { C7 84 24 ?? ?? ?? ?? 4E 64 72 43 C7 84 24 ?? ?? ?? ?? 6C 69 65 6E C7 84 24 ?? ?? ?? ?? 74 43 61 6C C7 84 24 ?? ?? ?? ?? 6C 33 00 8D }

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule SIGNATURE_BASE_MAL_DLL_Stealer_Nov23 : CVE_2023_4966 FILE
{
	meta:
		description = "Detects a DLL that steals authentication credentials - was seen being used by LockBit 3.0 affiliates exploiting CVE-2023-4966"
		author = "X__Junior"
		id = "9cfed8ec-1d04-53d7-88ef-2576075cfc33"
		date = "2023-11-23"
		modified = "2023-12-05"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa23-325a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ransom_lockbit_citrixbleed_nov23.yar#L41-L54"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "17a27b1759f10d1f6f1f51a11c0efea550e2075c2c394259af4d3f855bbcc994"
		logic_hash = "7d0c46d855973cb2c0636aed9c67cfbe47ca260ab1bc842fef1d532725c26910"
		score = 80
		quality = 85
		tags = "CVE-2023-4966, FILE"

	strings:
		$op1 = { C7 45 ?? 4D 69 6E 69 C7 45 ?? 44 75 6D 70 C7 45 ?? 57 72 69 74 C7 45 ?? 65 44 75 6D C7 45 ?? 70 00 27 00 C7 45 ?? 44 00 62 00 C7 45 ?? 67 00 68 00 C7 45 ?? 65 00 6C 00 C7 45 ?? 70 00 2E 00 C7 45 ?? 64 00 6C 00 C7 45 ?? 6C 00 00 00}

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule SIGNATURE_BASE_MAL_Python_Backdoor_Script_Nov23 : CVE_2023_4966 FILE
{
	meta:
		description = "Detects a trojan (written in Python) that communicates with c2 - was seen being used by LockBit 3.0 affiliates exploiting CVE-2023-4966"
		author = "X__Junior"
		id = "861f9ce3-3c54-5c56-b50b-2b7536783f6e"
		date = "2023-11-23"
		modified = "2023-12-05"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa23-325a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ransom_lockbit_citrixbleed_nov23.yar#L56-L71"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "906602ea3c887af67bcb4531bbbb459d7c24a2efcb866bcb1e3b028a51f12ae6"
		logic_hash = "b336f6438a420af49b1b0144039f1051f12c0c54f77a94e2f947f71d1f6230b3"
		score = 80
		quality = 85
		tags = "CVE-2023-4966, FILE"

	strings:
		$s1 = "port = 443 if \"https\"" ascii
		$s2 = "winrm.Session basic error" ascii
		$s3 = "Windwoscmd.run_cmd(str(cmd))" ascii

	condition:
		filesize < 50KB and all of them
}
rule SIGNATURE_BASE_APT_RANSOM_Lockbit_Forensicartifacts_Nov23
{
	meta:
		description = "Detects patterns found in Lockbit TA attacks exploiting Citrixbleed vulnerability CVE 2023-4966"
		author = "Florian Roth"
		id = "04bde599-2a5b-5a33-a6f1-67d57a564946"
		date = "2023-11-22"
		modified = "2023-12-05"
		reference = "https://www.cisa.gov/news-events/cybersecurity-advisories/aa23-325a"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ransom_lockbit_citrixbleed_nov23.yar#L73-L86"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6ba1d47e2cac72143c4612c420777024f114afc007c7b15251a58819654aeff1"
		score = 75
		quality = 85
		tags = ""

	strings:
		$x1 = "taskkill /f /im sqlwriter.exe /im winmysqladmin.exe /im w3sqlmgr.exe"
		$x2 = " 1> \\\\127.0.0.1\\admin$\\__"

	condition:
		1 of ( $x* )
}

rule SIGNATURE_BASE_EXT_APT32_Goopdate_Installer
{
	meta:
		description = "Detects APT32 installer side-loaded with goopdate.dll"
		author = "Facebook"
		id = "08f3cbda-ccb7-517a-b205-5f71de26c735"
		date = "2021-02-25"
		modified = "2023-12-05"
		reference = "https://about.fb.com/news/2020/12/taking-action-against-hackers-in-bangladesh-and-vietnam/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt32.yar#L3-L20"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "69730f2c2bb9668a17f8dfa1f1523e0e1e997ba98f027ce98f5cbaa869347383"
		logic_hash = "1dcb3009c5c19ff4e54d82d3a4b99b3431e78664f1660522a781e815d96958c4"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s0 = { 68 ?? ?? ?? ?? 57 A3 ?? ?? ?? ?? FF D6 33 05 ?? ?? ?? ?? }
		$s1 = "GetProcAddress"
		$s2 = { 8B 4D FC ?? ?? 0F B6 51 0C ?? ?? 8B 4D F0 0F B6 1C 01 33 DA }
		$s3 = "FindNextFileW"
		$s4 = "Process32NextW"

	condition:
		(pe.is_64bit ( ) or pe.is_32bit ( ) ) and all of them
}
rule SIGNATURE_BASE_EXT_APT32_Osx_Backdoor_Loader : FILE
{
	meta:
		description = "Detects APT32 backdoor loader on OSX"
		author = "Facebook"
		id = "ac313bd8-bf15-5b72-b651-35015f71dd90"
		date = "2021-02-25"
		modified = "2023-12-05"
		reference = "https://about.fb.com/news/2020/12/taking-action-against-hackers-in-bangladesh-and-vietnam/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt32.yar#L22-L49"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "768510fa9eb807bba9c3dcb3c7f87b771e20fa3d81247539e9ea4349205e39eb"
		logic_hash = "26964f95a9298b838e06fb9d7f739c8b87a976d8da7fb08416e952d26e84b84e"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$a1 = { 00 D2 44 8A 04 0F 44 88 C0 C0 E8 07 08 D0 88 44 0F FF 48 FF C1 48 83 F9 10 44 88 C2 }
		$a2 = { 41 0F 10 04 07 0F 57 84 05 A0 FE FF FF 41 0F 11 04 07 48 83 C0 10 48 83 F8 10 75 }
		$e1 = { CA CF 3E F2 DA 43 E6 D1  D5 6C D4 23 3A AE F1 B2 }
		$e2 = "MlkHVdRbOkra9s+G65MAoLga340t3+zj/u8LPfP3hig="
		$e3 = { 5A 69 98 0E 6C 4B 5C 69  7E 19 34 3B C3 07 CA 13 }
		$e4 = "1Sib4HfPuRQjpxIpECnxxTPiu3FXOFAHMx/+9MEVv9M+h1ngV7T5WUP3b0zsg0Qd"
		$e5 = "_ArchaeologistCodeine"
		$e6 = "_PlayerAberadurtheIncomprehensible"

	condition:
		(( uint32( 0 ) == 0xfeedface or uint32be( 0 ) == 0xfeedface ) or ( uint32( 0 ) == 0xfeedfacf or uint32be( 0 ) == 0xfeedfacf ) ) and ( 2 of ( $e* ) or all of ( $a* ) )
}
rule SIGNATURE_BASE_APT_Backdoor_SUNBURST_1
{
	meta:
		description = "This rule is looking for portions of the SUNBURST backdoor that are vital to how it functions. The first signature fnv_xor matches a magic byte xor that the sample performs on process, service, and driver names/paths. SUNBURST is a backdoor that has the ability to spawn and kill processes, write and delete files, set and create registry keys, gather system information, and disable a set of forensic analysis tools and services."
		author = "FireEye"
		id = "74b44844-5575-53d7-819b-ab1b2327a144"
		date = "2020-12-14"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2020/12/evasive-attacker-leverages-solarwinds-supply-chain-compromises-with-sunburst-backdoor.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_solarwinds_sunburst.yar#L6-L27"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1fc006dead2fd540717e00e468bf30f37bdb1d061a805e33683e4a77db7f9156"
		score = 85
		quality = 77
		tags = ""

	strings:
		$cmd_regex_encoded = "U4qpjjbQtUzUTdONrTY2q42pVapRgooABYxQuIZmtUoA" wide
		$cmd_regex_plain = { 5C 7B 5B 30 2D 39 61 2D 66 2D 5D 7B 33 36 7D 5C 7D 22 7C 22 5B 30 2D 39 61 2D 66 5D 7B 33 32 7D 22 7C 22 5B 30 2D 39 61 2D 66 5D 7B 31 36 7D }
		$fake_orion_event_encoded = "U3ItS80rCaksSFWyUvIvyszPU9IBAA==" wide
		$fake_orion_event_plain = { 22 45 76 65 6E 74 54 79 70 65 22 3A 22 4F 72 69 6F 6E 22 2C }
		$fake_orion_eventmanager_encoded = "U3ItS80r8UvMTVWyUgKzfRPzEtNTi5R0AA==" wide
		$fake_orion_eventmanager_plain = { 22 45 76 65 6E 74 4E 61 6D 65 22 3A 22 45 76 65 6E 74 4D 61 6E 61 67 65 72 22 2C }
		$fake_orion_message_encoded = "U/JNLS5OTE9VslKqNqhVAgA=" wide
		$fake_orion_message_plain = { 22 4D 65 73 73 61 67 65 22 3A 22 7B 30 7D 22 }
		$fnv_xor = { 67 19 D8 A7 3B 90 AC 5B }

	condition:
		$fnv_xor and ( $cmd_regex_encoded or $cmd_regex_plain ) or ( ( $fake_orion_event_encoded or $fake_orion_event_plain ) and ( $fake_orion_eventmanager_encoded or $fake_orion_eventmanager_plain ) and ( $fake_orion_message_encoded and $fake_orion_message_plain ) )
}
rule SIGNATURE_BASE_APT_Backdoor_SUNBURST_2
{
	meta:
		description = "The SUNBURST backdoor uses a domain generation algorithm (DGA) as part of C2 communications. This rule is looking for each branch of the code that checks for which HTTP method is being used. This is in one large conjunction, and all branches are then tied together via disjunction. The grouping is intentionally designed so that if any part of the DGA is re-used in another sample, this signature should match that re-used portion. SUNBURST is a backdoor that has the ability to spawn and kill processes, write and delete files, set and create registry keys, gather system information, and disable a set of forensic analysis tools and services."
		author = "FireEye"
		id = "329071d5-c9c6-5ae1-a514-aea9f4037bac"
		date = "2020-12-14"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2020/12/evasive-attacker-leverages-solarwinds-supply-chain-compromises-with-sunburst-backdoor.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_solarwinds_sunburst.yar#L28-L79"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "2bf0697b110bca88f712cbccaf0d2ba614d6093d6d9595659aefe088848d3826"
		score = 85
		quality = 83
		tags = ""

	strings:
		$a = "0y3Kzy8BAA==" wide
		$aa = "S8vPKynWL89PS9OvNqjVrTYEYqNa3fLUpDSgTLVxrR5IzggA" wide
		$ab = "S8vPKynWL89PS9OvNqjVrTYEYqPaauNaPZCYEQA=" wide
		$ac = "C88sSs1JLS4GAA==" wide
		$ad = "C/UEAA==" wide
		$ae = "C89MSU8tKQYA" wide
		$af = "8wvwBQA=" wide
		$ag = "cyzIz8nJBwA=" wide
		$ah = "c87JL03xzc/LLMkvysxLBwA=" wide
		$ai = "88tPSS0GAA==" wide
		$aj = "C8vPKc1NLQYA" wide
		$ak = "88wrSS1KS0xOLQYA" wide
		$al = "c87PLcjPS80rKQYA" wide
		$am = "Ky7PLNAvLUjRBwA=" wide
		$an = "06vIzQEA" wide
		$b = "0y3NyyxLLSpOzIlPTgQA" wide
		$c = "001OBAA=" wide
		$d = "0y0oysxNLKqMT04EAA==" wide
		$e = "0y3JzE0tLknMLQAA" wide
		$f = "003PyU9KzAEA" wide
		$h = "0y1OTS4tSk1OBAA=" wide
		$i = "K8jO1E8uytGvNqitNqytNqrVA/IA" wide
		$j = "c8rPSQEA" wide
		$k = "c8rPSfEsSczJTAYA" wide
		$l = "c60oKUp0ys9JAQA=" wide
		$m = "c60oKUp0ys9J8SxJzMlMBgA=" wide
		$n = "8yxJzMlMBgA=" wide
		$o = "88lMzygBAA==" wide
		$p = "88lMzyjxLEnMyUwGAA==" wide
		$q = "C0pNL81JLAIA" wide
		$r = "C07NzXTKz0kBAA==" wide
		$s = "C07NzXTKz0nxLEnMyUwGAA==" wide
		$t = "yy9IzStOzCsGAA==" wide
		$u = "y8svyQcA" wide
		$v = "SytKTU3LzysBAA==" wide
		$w = "C84vLUpOdc5PSQ0oygcA" wide
		$x = "C84vLUpODU4tykwLKMoHAA==" wide
		$y = "C84vLUpO9UjMC07MKwYA" wide
		$z = "C84vLUpO9UjMC04tykwDAA==" wide

	condition:
		($a and $b and $c and $d and $e and $f and $h and $i ) or ( $j and $k and $l and $m and $n and $o and $p and $q and $r and $s and ( $aa or $ab ) ) or ( $t and $u and $v and $w and $x and $y and $z and ( $aa or $ab ) ) or ( $ac and $ad and $ae and $af and $ag and $ah and ( $am or $an ) ) or ( $ai and $aj and $ak and $al and ( $am or $an ) )
}

rule SIGNATURE_BASE_APT_Webshell_SUPERNOVA_1 : FILE
{
	meta:
		description = "SUPERNOVA is a .NET web shell backdoor masquerading as a legitimate SolarWinds web service handler. SUPERNOVA inspects and responds to HTTP requests with the appropriate HTTP query strings, Cookies, and/or HTML form values (e.g. named codes, class, method, and args). This rule is looking for specific strings and attributes related to SUPERNOVA."
		author = "FireEye"
		id = "73a27fa2-a846-5f4b-8182-064ac06c71a8"
		date = "2020-12-14"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2020/12/evasive-attacker-leverages-solarwinds-supply-chain-compromises-with-sunburst-backdoor.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_solarwinds_sunburst.yar#L80-L99"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8471e6b3675e7e9ccfe5b81ab4c599668f2de528f3b179a675f50aa1fd7814b2"
		score = 85
		quality = 81
		tags = "FILE"

	strings:
		$compile1 = "CompileAssemblyFromSource"
		$compile2 = "CreateCompiler"
		$context = "ProcessRequest"
		$httpmodule = "IHttpHandler" ascii
		$string1 = "clazz"
		$string2 = "//NetPerfMon//images//NoLogo.gif" wide
		$string3 = "SolarWinds" ascii nocase wide

	condition:
		uint16( 0 ) == 0x5a4d and uint32( uint32( 0x3C ) ) == 0x00004550 and filesize < 10KB and pe.imports ( "mscoree.dll" , "_CorDllMain" ) and $httpmodule and $context and all of ( $compile* ) and all of ( $string* )
}
rule SIGNATURE_BASE_APT_Webshell_SUPERNOVA_2 : FILE
{
	meta:
		description = "This rule is looking for specific strings related to SUPERNOVA. SUPERNOVA is a .NET web shell backdoor masquerading as a legitimate SolarWinds web service handler. SUPERNOVA inspects and responds to HTTP requests with the appropriate HTTP query strings, Cookies, and/or HTML form values (e.g. named codes, class, method, and args)."
		author = "FireEye"
		id = "c39bf9ba-fd62-5619-92b6-1633375ef197"
		date = "2020-12-14"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2020/12/evasive-attacker-leverages-solarwinds-supply-chain-compromises-with-sunburst-backdoor.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_solarwinds_sunburst.yar#L100-L118"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "96e344bd2ba3ee07784852db3e9935352762c2fa7b6be88f00cac10a90706ffc"
		score = 85
		quality = 83
		tags = "FILE"

	strings:
		$dynamic = "DynamicRun"
		$solar = "Solarwinds" nocase
		$string1 = "codes"
		$string2 = "clazz"
		$string3 = "method"
		$string4 = "args"

	condition:
		uint16( 0 ) == 0x5a4d and uint32( uint32( 0x3C ) ) == 0x00004550 and filesize < 10KB and 3 of ( $string* ) and $dynamic and $solar
}
rule SIGNATURE_BASE_APT_Dropper_Raw64_TEARDROP_1
{
	meta:
		description = "This rule looks for portions of the TEARDROP backdoor that are vital to how it functions. TEARDROP is a memory only dropper that can read files and registry keys, XOR decode an embedded payload, and load the payload into memory. TEARDROP persists as a Windows service and has been observed dropping Cobalt Strike BEACON into memory."
		author = "FireEye"
		id = "88adad58-ba16-5996-9ea8-ea356c3ed5b2"
		date = "2020-12-14"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2020/12/evasive-attacker-leverages-solarwinds-supply-chain-compromises-with-sunburst-backdoor.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_solarwinds_sunburst.yar#L141-L156"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6ab5197e7a1a123055b361a2ef79f8a77a7935606fccc8f163ea5914c94cd14d"
		score = 85
		quality = 85
		tags = ""

	strings:
		$sb1 = { C7 44 24 ?? 80 00 00 00 [0-64] BA 00 00 00 80 [0-32] 48 8D 0D [4-32] FF 15 [4] 48 83 F8 FF [2-64] 41 B8 40 00 00 00 [0-64] FF 15 [4-5] 85 C0 7? ?? 80 3D [4] FF }
		$sb2 = { 80 3D [4] D8 [2-32] 41 B8 04 00 00 00 [0-32] C7 44 24 ?? 4A 46 49 46 [0-32] E8 [4-5] 85 C0 [2-32] C6 05 [4] 6A C6 05 [4] 70 C6 05 [4] 65 C6 05 [4] 67 }
		$sb3 = { BA [4] 48 89 ?? E8 [4] 41 B8 [4] 48 89 ?? 48 89 ?? E8 [4] 85 C0 7? [1-32] 8B 44 24 ?? 48 8B ?? 24 [1-16] 48 01 C8 [0-32] FF D0 }

	condition:
		all of them
}
rule SIGNATURE_BASE_APT_Dropper_Win64_TEARDROP_1 : FILE
{
	meta:
		description = "This rule is intended match specific sequences of opcode found within TEARDROP, including those that decode the embedded payload. TEARDROP is a memory only dropper that can read files and registry keys, XOR decode an embedded payload, and load the payload into memory. TEARDROP persists as a Windows service and has been observed dropping Cobalt Strike BEACON into memory. (comment by Nextron: prone to False Positives)"
		author = "FireEye"
		id = "15dfdb74-5ca3-5bc6-be7a-730333b03ba5"
		date = "2020-12-14"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2020/12/evasive-attacker-leverages-solarwinds-supply-chain-compromises-with-sunburst-backdoor.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_solarwinds_sunburst.yar#L157-L174"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a1fa9b9c700601d10cb77ec714b972f04308de615dfc519f680fc956227cc11d"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$loc_4218FE24A5 = { 48 89 C8 45 0F B6 4C 0A 30 }
		$loc_4218FE36CA = { 48 C1 E0 04 83 C3 01 48 01 E8 8B 48 28 8B 50 30 44 8B 40 2C 48 01 F1 4C 01 FA }
		$loc_4218FE2747 = { C6 05 ?? ?? ?? ?? 6A C6 05 ?? ?? ?? ?? 70 C6 05 ?? ?? ?? ?? 65 C6 05 ?? ?? ?? ?? 67 }
		$loc_5551D725A0 = { 48 89 C8 45 0F B6 4C 0A 30 48 89 CE 44 89 CF 48 F7 E3 48 C1 EA 05 48 8D 04 92 48 8D 04 42 48 C1 E0 04 48 29 C6 }
		$loc_5551D726F6 = { 53 4F 46 54 57 41 52 45 ?? ?? ?? ?? 66 74 5C 43 ?? ?? ?? ?? 00 }

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule SIGNATURE_BASE_MAL_RANSOM_Revil_Oct20_1 : FILE
{
	meta:
		description = "Detects REvil ransomware"
		author = "Florian Roth (Nextron Systems)"
		id = "0c85a2cc-3487-577f-bd12-e3effd8fc811"
		date = "2020-10-13"
		modified = "2023-12-05"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_ransom_revil.yar#L2-L23"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "5966c25dc1abcec9d8603b97919db57aac019e5358ee413957927d3c1790b7f4"
		hash = "f66027faea8c9e0ff29a31641e186cbed7073b52b43933ba36d61e8f6bce1ab5"
		hash = "f6857748c050655fb3c2192b52a3b0915f3f3708cd0a59bbf641d7dd722a804d"
		hash = "fc26288df74aa8046b4761f8478c52819e0fca478c1ab674da7e1d24e1cfa501"
		logic_hash = "756e49362c01abbca3208967630f09ed957e5c51956e0e5210b0167590582a82"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$op1 = { 0f 8c 74 ff ff ff 33 c0 5f 5e 5b 8b e5 5d c3 8b }
		$op2 = { 8d 85 68 ff ff ff 50 e8 2a fe ff ff 8d 85 68 ff }
		$op3 = { 89 4d f4 8b 4e 0c 33 4e 34 33 4e 5c 33 8e 84 }
		$op4 = { 8d 85 68 ff ff ff 50 e8 05 06 00 00 8d 85 68 ff }
		$op5 = { 8d 85 68 ff ff ff 56 57 ff 75 0c 50 e8 2f }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 400KB and 2 of them or 4 of them
}
rule SIGNATURE_BASE_SUSP_PS1_JAB_Pattern_Jun22_1 : FILE
{
	meta:
		description = "Detects suspicious UTF16 and Base64 encoded PowerShell code that starts with a $ sign and a single char variable"
		author = "Florian Roth (Nextron Systems)"
		id = "9ecca7d9-3b63-5615-a223-5efa1c53510e"
		date = "2022-06-10"
		modified = "2023-12-05"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_susp_ps_jab.yar#L2-L29"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9ad61dca5c945ed87642668e3b834b12c813af244437903a5abb5c69459b9456"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$xc1 = { 4a 41 42 ?? 41 43 41 41 50 51 41 67 41 }
		$xc2 = { 4a 00 41 00 42 00 ?? 00 41 00 43 00 41 00 41 00 50 00 51 00 41 00 67 00 41 }
		$xc3 = { 4a 41 42 ?? 41 44 30 41 }
		$xc4 = { 4a 00 41 00 42 00 ?? 00 41 00 44 00 30 00 41 }

	condition:
		filesize < 30MB and 1 of them
}
rule SIGNATURE_BASE_EXPL_LOG_Proxynotshell_OWASSRF_Powershell_Proxy_Log_Dec22_1 : CVE_2022_41040 CVE_2022_41082
{
	meta:
		description = "Detects traces of exploitation activity in relation to ProxyNotShell MS Exchange vulnerabilities CVE-2022-41040 and CVE-2022-41082"
		author = "Florian Roth (Nextron Systems)"
		id = "a61f6582-474f-5b6f-b8f5-329c0bcc4017"
		date = "2022-12-22"
		modified = "2023-12-05"
		reference = "https://www.crowdstrike.com/blog/owassrf-exploit-analysis-and-recommendations/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_proxynotshell_owassrf_dec22.yar#L2-L22"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1e8f5a3440f8b4b1850fddbd19f63796ad0f28178c678e9f464b7e4ab5ca944f"
		score = 70
		quality = 85
		tags = "CVE-2022-41040, CVE-2022-41082"

	strings:
		$s1 = "/owa/mastermailbox%40outlook.com/powershell" ascii wide
		$sa1 = " 200 " ascii wide
		$sa2 = " POST " ascii wide
		$fp1 = "ClientInfo" ascii wide fullword
		$fp2 = "Microsoft WinRM Client" ascii wide fullword
		$fp3 = "Exchange BackEnd Probes" ascii wide fullword

	condition:
		all of ( $s* ) and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_EXPL_LOG_Proxynotshell_Powershell_Proxy_Log_Dec22_1 : CVE_2022_41040 CVE_2022_41082
{
	meta:
		description = "Detects traces of exploitation activity in relation to ProxyNotShell MS Exchange vulnerabilities CVE-2022-41040 and CVE-2022-41082"
		author = "Florian Roth (Nextron Systems)"
		id = "5af3ae70-8897-593f-a413-82ca1d1ba961"
		date = "2022-12-22"
		modified = "2023-01-26"
		reference = "https://www.crowdstrike.com/blog/owassrf-exploit-analysis-and-recommendations/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_proxynotshell_owassrf_dec22.yar#L68-L86"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f2aac61bc17f74901ec8d638d5cfaaa45bbd2a4e40e5d915bf2a946daed411d2"
		score = 70
		quality = 85
		tags = "CVE-2022-41040, CVE-2022-41082"

	strings:
		$re1 = /,\/[Pp][Oo][Ww][Ee][Rr][Ss][Hh][Ee][Ll][Ll][^\n]{0,50},Kerberos,true,[^\n]{0,50},200,0,,,,[^\n]{0,2000};OnEndRequest\.End\.ContentType=application\/soap\+xml charset UTF-8;S:ServiceCommonMetadata\.HttpMethod=POST;/ ascii wide
		$fp1 = "ClientInfo" ascii wide fullword
		$fp2 = "Microsoft WinRM Client" ascii wide fullword
		$fp3 = "Exchange BackEnd Probes" ascii wide fullword

	condition:
		$re1 and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_SUSP_ZIP_LNK_Phishattachment_Pattern_Jun22_1 : FILE
{
	meta:
		description = "Detects suspicious tiny ZIP files with phishing attachment characteristics"
		author = "Florian Roth (Nextron Systems)"
		id = "3537c4ea-a51d-5100-97d7-71a24da5ff43"
		date = "2022-06-23"
		modified = "2023-12-05"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_phish_attachments.yar#L2-L21"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "4edb41f4645924d8a73e7ac3e3f39f4db73e38f356bc994ad7d03728cd799a48"
		hash = "c4fec375b44efad2d45c49f30133efbf6921ce82dbb2d1a980f69ea6383b0ab4"
		hash = "9c70eeac97374213355ea8fa019a0e99e0e57c8efc43daa3509f9f98fa71c8e4"
		hash = "ddc20266e38a974a28af321ab82eedaaf51168fbcc63ac77883d8be5200dcaf9"
		hash = "b59788ae984d9e70b4f7f5a035b10e6537063f15a010652edd170fc6a7e1ea2f"
		logic_hash = "2ff398379e3d8112991eeacd99bf9d3bafbf3e9266f012d2539d6b2661d5969e"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$sl1 = ".lnk"

	condition:
		uint16( 0 ) == 0x4b50 and filesize < 2KB and $sl1 in ( filesize -256 .. filesize )
}
rule SIGNATURE_BASE_HKTL_EXPL_POC_Libssh_Auth_Bypass_CVE_2023_2283_Jun23_1 : CVE_2023_2283 FILE
{
	meta:
		description = "Detects POC code used in attacks against libssh vulnerability CVE-2023-2283"
		author = "Florian Roth"
		id = "e72eba33-686f-5fca-bca3-2b875d1ec224"
		date = "2023-06-08"
		modified = "2023-12-05"
		reference = "https://github.com/github/securitylab/tree/1786eaae7f90d87ce633c46bbaa0691d2f9bf449/SecurityExploits/libssh/pubkey-auth-bypass-CVE-2023-2283"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_libssh_cve_2023_2283_jun23.yar#L2-L15"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4c3d54d7f4902c1da664e41096b5931e6534aaaf63243f12e05b81af63d8b28f"
		score = 85
		quality = 85
		tags = "CVE-2023-2283, FILE"

	strings:
		$s1 = "nprocs = %d" ascii fullword
		$s2 = "fork failed: %s" ascii fullword

	condition:
		uint16( 0 ) == 0x457f and all of them
}
rule SIGNATURE_BASE_LOG_APT_WEBSHELL_Solarwinds_SUNBURST_Report_Webshell_Dec20_2
{
	meta:
		description = "Detects webshell access mentioned in FireEye's SUNBURST report"
		author = "Florian Roth (Nextron Systems)"
		id = "fb86164d-13de-5357-8f52-c597b51127ff"
		date = "2020-12-21"
		modified = "2023-12-05"
		reference = "https://www.guidepointsecurity.com/supernova-solarwinds-net-webshell-analysis/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_solarwinds_susp_sunburst.yar#L21-L32"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "ec52e244a483ace0f6932b553b159b23b767c00d1f64a4711e5f359832e846f5"
		score = 75
		quality = 85
		tags = ""

	strings:
		$xr1 = /logoimagehandler.ashx[^\n\s]{1,400}clazz=/ ascii wide

	condition:
		$xr1
}

rule SIGNATURE_BASE_MAL_Devilstongue_Hijackdll : FILE
{
	meta:
		description = "Detects SOURGUM's DevilsTongue hijack DLL"
		author = "Microsoft Threat Intelligence Center (MSTIC)"
		id = "390b8b73-6740-513d-8c70-c9002be0ce69"
		date = "2021-07-15"
		modified = "2023-12-05"
		reference = "https://www.microsoft.com/security/blog/2021/07/15/protecting-customers-from-a-private-sector-offensive-actor-using-0-day-exploits-and-devilstongue-malware/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_candiru.yar#L3-L47"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4ad58a77f9ab5fa078dc40f3ec1d0b0180f25ff3ea304a3c85889df29739e0f5"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$str1 = "windows.old\\windows" wide
		$str2 = "NtQueryInformationThread"
		$str3 = "dbgHelp.dll" wide
		$str4 = "StackWalk64"
		$str5 = "ConvertSidToStringSidW"
		$str6 = "S-1-5-18" wide
		$str7 = "SMNew.dll"
		$code1 = { B8 FF 15 00 00 66 39 41 FA 74 06 80 79 FB E8 }
		$code2 = { 44 8B C0 B8 B5 81 4E 1B 41 F7 E8 C1 FA 05 8B CA C1 E9 1F 03 D1 69 CA 2C 01 00 00 44 2B C1 45 85 C0 7E 19 }

	condition:
		filesize < 800KB and uint16( 0 ) == 0x5A4D and ( pe.characteristics & pe.DLL ) and ( 4 of them or ( $code1 and $code2 ) or pe.imphash ( ) == "9a964e810949704ff7b4a393d9adda60" )
}

rule SIGNATURE_BASE_APT_MAL_NK_3CX_Malicious_Samples_Mar23_1 : FILE
{
	meta:
		description = "Detects malicious DLLs related to 3CX compromise"
		author = "X__Junior, Florian Roth (Nextron Systems)"
		id = "a6ea3299-fde5-5206-b5db-eb3a3f5944d9"
		date = "2023-03-29"
		modified = "2023-04-20"
		reference = "https://www.reddit.com/r/crowdstrike/comments/125r3uu/20230329_situational_awareness_crowdstrike/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mal_3cx_compromise_mar23.yar#L3-L30"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "7986bbaee8940da11ce089383521ab420c443ab7b15ed42aed91fd31ce833896"
		hash = "c485674ee63ec8d4e8fde9800788175a8b02d3f9416d0e763360fff7f8eb4e02"
		hash = "cc4eedb7b1f77f02b962f4b05278fa7f8082708b5a12cacf928118520762b5e2"
		logic_hash = "68f4007791d365900c84e32e076aa3cac9f3a9ed46de297f1005306554ee13f5"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$opa1 = { 4C 89 F1 4C 89 EA 41 B8 40 00 00 00 FF 15 ?? ?? ?? ?? 85 C0 74 ?? 4C 89 F0 FF 15 ?? ?? ?? ?? 4C 8D 4C 24 ?? 45 8B 01 4C 89 F1 4C 89 EA FF 15 }
		$opa2 = { 48 C7 44 24 ?? 00 00 00 00 4C 8D 7C 24 ?? 48 89 F9 48 89 C2 41 89 E8 4D 89 F9 FF 15 ?? ?? ?? ?? 41 83 3F 00 0F 84 ?? ?? ?? ?? 0F B7 03 3D 4D 5A 00 00}
		$opa3 = { 41 80 7C 00 ?? FE 75 ?? 41 80 7C 00 ?? ED 75 ?? 41 80 7C 00 ?? FA 75 ?? 41 80 3C 00 CE}
		$opa4 = { 44 0F B6 CD 46 8A 8C 0C ?? ?? ?? ?? 45 30 0C 0E 48 FF C1}
		$opb1 = { 41 B8 40 00 00 00 49 8B D5 49 8B CC FF 15 ?? ?? ?? ?? 85 C0 74 ?? 41 FF D4 44 8B 45 ?? 4C 8D 4D ?? 49 8B D5 49 8B CC FF 15 }
		$opb2 = { 44 8B C3 48 89 44 24 ?? 48 8B 5C 24 ?? 4C 8D 4D ?? 48 8B CB 48 89 74 24 ?? 48 8B D0 4C 8B F8 FF 15 }
		$opb3 = { 80 78 ?? FE 75 ?? 80 78 ?? ED 75 ?? 80 38 FA 75 ?? 80 78 ?? CE }
		$opb4 = { 49 63 C1 44 0F B6 44 05 ?? 44 88 5C 05 ?? 44 88 02 0F B6 54 05 ?? 49 03 D0 0F B6 C2 0F B6 54 05 ?? 41 30 12}

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 5MB and pe.characteristics & pe.DLL and ( 2 of ( $opa* ) or 2 of ( $opb* ) )
}
rule SIGNATURE_BASE_APT_MAL_NK_3CX_Malicious_Samples_Mar23_3
{
	meta:
		description = "Detects malicious DLLs related to 3CX compromise (decrypted payload)"
		author = "Florian Roth , X__Junior (Nextron Systems)"
		id = "d2d361b6-8485-57eb-b6eb-88785f42e93e"
		date = "2023-03-29"
		modified = "2023-12-05"
		reference = "https://www.reddit.com/r/crowdstrike/comments/125r3uu/20230329_situational_awareness_crowdstrike/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mal_3cx_compromise_mar23.yar#L56-L79"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "aa4e398b3bd8645016d8090ffc77d15f926a8e69258642191deb4e68688ff973"
		logic_hash = "adfe04904d796690631e5841ee1ee10c767f9f4c340e5b9df78918e981359d4d"
		score = 80
		quality = 85
		tags = ""

	strings:
		$opa1 = { 41 81 C0 ?? ?? ?? ?? 02 C8 49 C1 E9 ?? 41 88 4B ?? 4D 03 D1 8B C8 45 8B CA C1 E1 ?? 33 C1 41 69 D0 ?? ?? ?? ?? 8B C8 C1 E9 ?? 33 C1 8B C8 C1 E1 ?? 81 C2 ?? ?? ?? ?? 33 C1 43 8D 0C 02 02 C8 49 C1 EA ?? 41 88 0B 8B C8 C1 E1 ?? 33 C1 44 69 C2 ?? ?? ?? ?? 8B C8 C1 E9 ?? 33 C1 8B C8 C1 E1 ?? 41 81 C0 }
		$opa2 = { 8B C8 41 69 D1 ?? ?? ?? ?? C1 E1 ?? 33 C1 45 8B CA 8B C8 C1 E9 ?? 33 C1 81 C2 ?? ?? ?? ?? 8B C8 C1 E1 ?? 33 C1 41 8B C8 4C 0F AF CF 44 69 C2 ?? ?? ?? ?? 4C 03 C9 45 8B D1 4C 0F AF D7}
		$opb1 = { 45 33 C9 48 89 6C 24 ?? 48 8D 44 24 ?? 48 89 6C 24 ?? 8B D3 48 89 B4 24 ?? ?? ?? ?? 48 89 44 24 ?? 45 8D 41 ?? FF 15 }
		$opb2 = { 44 8B 0F 45 8B C6 48 8B 4D ?? 49 8B D7 44 89 64 24 ?? 48 89 7C 24 ?? 44 89 4C 24 ?? 4C 8D 4D ?? 48 89 44 24 ?? 44 89 64 24 ?? 4C 89 64 24 ?? FF 15}
		$opb3 = { 48 FF C2 66 44 39 2C 56 75 ?? 4C 8D 4C 24 ?? 45 33 C0 48 8B CE FF 15 ?? ?? ?? ?? 85 C0 0F 84 ?? ?? ?? ?? 44 0F B7 44 24 ?? 33 F6 48 8B 54 24 ?? 45 33 C9 48 8B 0B 48 89 74 24 ?? 89 74 24 ?? C7 44 24 ?? ?? ?? ?? ?? 48 89 74 24 ?? FF 15 }
		$opb4 = { 33 C0 48 8D 6B ?? 4C 8D 4C 24 ?? 89 44 24 ?? BA ?? ?? ?? ?? 48 89 44 24 ?? 48 8B CD 89 44 24 ?? 44 8D 40 ?? 8B F8 FF 15}

	condition:
		( all of ( $opa* ) ) or ( 1 of ( $opa* ) and 1 of ( $opb* ) ) or ( 3 of ( $opb* ) )
}
rule SIGNATURE_BASE_SUSP_APT_MAL_NK_3CX_Malicious_Samples_Mar23_1
{
	meta:
		description = "Detects marker found in malicious DLLs related to 3CX compromise"
		author = "X__Junior, Florian Roth (Nextron Systems)"
		id = "9fc6eb94-d02f-5bcd-9f55-b6c6a8301b4f"
		date = "2023-03-29"
		modified = "2023-04-20"
		reference = "https://www.reddit.com/r/crowdstrike/comments/125r3uu/20230329_situational_awareness_crowdstrike/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mal_3cx_compromise_mar23.yar#L81-L98"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "7986bbaee8940da11ce089383521ab420c443ab7b15ed42aed91fd31ce833896"
		hash = "c485674ee63ec8d4e8fde9800788175a8b02d3f9416d0e763360fff7f8eb4e02"
		hash = "cc4eedb7b1f77f02b962f4b05278fa7f8082708b5a12cacf928118520762b5e2"
		logic_hash = "dcce1f5e769a2821d746a960cd333f8042fb71c8469aa41c29bbbd0dce79369c"
		score = 75
		quality = 85
		tags = ""

	strings:
		$opx1 = { 41 80 7C 00 FD FE 75 ?? 41 80 7C 00 FE ED 75 ?? 41 80 7C 00 FF FA 75 ?? 41 80 3C 00 CE }
		$opx2 = { 80 78 ?? FE 75 ?? 80 78 ?? ED 75 ?? 80 38 FA 75 ?? 80 78 ?? CE }

	condition:
		1 of them
}
rule SIGNATURE_BASE_APT_SUSP_NK_3CX_RC4_Key_Mar23_1 : FILE
{
	meta:
		description = "Detects RC4 key used in 3CX binaries known to be malicious"
		author = "Florian Roth (Nextron Systems)"
		id = "18ea2185-11a1-51ad-a51a-df9e6357bb58"
		date = "2023-03-29"
		modified = "2023-12-05"
		reference = "https://www.reddit.com/r/crowdstrike/comments/125r3uu/20230329_situational_awareness_crowdstrike/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mal_3cx_compromise_mar23.yar#L100-L117"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "7986bbaee8940da11ce089383521ab420c443ab7b15ed42aed91fd31ce833896"
		hash = "59e1edf4d82fae4978e97512b0331b7eb21dd4b838b850ba46794d9c7a2c0983"
		hash = "aa124a4b4df12b34e74ee7f6c683b2ebec4ce9a8edcf9be345823b4fdcf5d868"
		hash = "c485674ee63ec8d4e8fde9800788175a8b02d3f9416d0e763360fff7f8eb4e02"
		logic_hash = "8324b537b149ad3816b12ae0f887f66a284a8e1ef4fe7cf51eb21d59c0f055b9"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "3jB(2bsG#@c7"

	condition:
		( uint16( 0 ) == 0xcfd0 or uint16( 0 ) == 0x5a4d ) and $x1
}

rule SIGNATURE_BASE_SUSP_3CX_App_Signed_Binary_Mar23_1 : FILE
{
	meta:
		description = "Detects 3CX application binaries signed with a certificate and created in a time frame in which other known malicious binaries have been created"
		author = "Florian Roth (Nextron Systems)"
		id = "b6ce4c1d-1b7b-5e0c-af4c-05cb3ad0a4e0"
		date = "2023-03-29"
		modified = "2023-12-05"
		reference = "https://www.reddit.com/r/crowdstrike/comments/125r3uu/20230329_situational_awareness_crowdstrike/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mal_3cx_compromise_mar23.yar#L119-L139"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "fad482ded2e25ce9e1dd3d3ecc3227af714bdfbbde04347dbc1b21d6a3670405"
		hash = "dde03348075512796241389dfea5560c20a3d2a2eac95c894e7bbed5e85a0acc"
		logic_hash = "3834b5ebb5a0db27a452fda1c97c921b2c9c8702505738232b15a3ed4a47dc47"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$sa1 = "3CX Ltd1"
		$sa2 = "3CX Desktop App" wide
		$sc1 = { 1B 66 11 DF 9C 9A 4D 6E CC 8E D5 0C 9B 91 78 73 }

	condition:
		uint16( 0 ) == 0x5a4d and pe.timestamp > 1669680000 and pe.timestamp < 1680108505 and all of ( $sa* ) and $sc1
}
rule SIGNATURE_BASE_APT_MAL_Macos_NK_3CX_Malicious_Samples_Mar23_1 : FILE
{
	meta:
		description = "Detects malicious macOS application related to 3CX compromise (decrypted payload)"
		author = "Florian Roth (Nextron Systems)"
		id = "ff39e577-7063-5025-bead-68394a86c87c"
		date = "2023-03-30"
		modified = "2023-12-05"
		reference = "https://www.reddit.com/r/crowdstrike/comments/125r3uu/20230329_situational_awareness_crowdstrike/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mal_3cx_compromise_mar23.yar#L168-L184"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "b86c695822013483fa4e2dfdf712c5ee777d7b99cbad8c2fa2274b133481eadb"
		hash = "ac99602999bf9823f221372378f95baa4fc68929bac3a10e8d9a107ec8074eca"
		hash = "51079c7e549cbad25429ff98b6d6ca02dc9234e466dd9b75a5e05b9d7b95af72"
		logic_hash = "c2733c2f7dcca82e5a0b2301777fb54853d04dfa893bcf88ecbec34d37e1a38a"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "20230313064152Z0"
		$s2 = "Developer ID Application: 3CX (33CF4654HL)"

	condition:
		( uint16( 0 ) == 0xfeca or uint16( 0 ) == 0xfacf or uint32( 0 ) == 0xbebafeca ) and all of them
}
rule SIGNATURE_BASE_APT_MAL_Macos_NK_3CX_DYLIB_Mar23_1
{
	meta:
		description = "Detects malicious DYLIB files related to 3CX compromise"
		author = "Florian Roth (Nextron Systems)"
		id = "a19904d3-9b2d-561f-b734-20bf09584fa7"
		date = "2023-03-30"
		modified = "2023-12-05"
		reference = "https://www.sentinelone.com/blog/smoothoperator-ongoing-campaign-trojanizes-3cx-software-in-software-supply-chain-attack/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mal_3cx_compromise_mar23.yar#L188-L214"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "a64fa9f1c76457ecc58402142a8728ce34ccba378c17318b3340083eeb7acc67"
		hash = "fee4f9dabc094df24d83ec1a8c4e4ff573e5d9973caa676f58086c99561382d7"
		logic_hash = "e52c76de1e995cc7084ddb390b60f4bc66e5bdf89aaa28ef3fd70578ed3145a6"
		score = 80
		quality = 85
		tags = ""

	strings:
		$xc1 = { 37 15 00 13 16 16 1B 55 4F 54 4A 5A 52 2D 13 14 
               1E 15 0D 09 5A 34 2E 5A 4B 4A 54 4A 41 5A 2D 13
               14 4C 4E 41 5A 02 4C 4E 53 5A 3B 0A 0A 16 1F 2D
               1F 18 31 13 0E 55 4F 49 4D 54 49 4C 5A 52 31 32
               2E 37 36 56 5A 16 13 11 1F 5A 3D 1F 19 11 15 53
               5A 39 12 08 15 17 1F 55 4B 4A 42 54 4A 54 4F 49
               4F 43 54 4B 48 42 5A 29 1B 1C 1B 08 13 55 4F 49
               4D 54 49 4C 7A }
		$xc2 = { 41 49 19 02 25 1b 0f 0e 12 25 0e 15 11 1f 14 25 19 15 14 0e 1f 14 0e 47 5f 09 41 25 25 0e 0f 0e 17 1b 47 }
		$xc3 = { 55 29 03 09 0e 1f 17 55 36 13 18 08 1b 08 03 55 39 15 08 1f 29 1f 08 0c 13 19 1f 09 55 29 03 09 0e 1f 17 2c 1f 08 09 13 15 14 54 0a 16 13 09 0e }

	condition:
		1 of them
}
rule SIGNATURE_BASE_APT_SUSP_NK_3CX_Malicious_Samples_Mar23_1
{
	meta:
		description = "Detects indicator (event name) found in samples related to 3CX compromise"
		author = "Florian Roth (Nextron Systems)"
		id = "b233846a-19df-579b-a674-233d66824008"
		date = "2023-03-30"
		modified = "2023-12-05"
		reference = "https://www.sentinelone.com/blog/smoothoperator-ongoing-campaign-trojanizes-3cx-software-in-software-supply-chain-attack/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mal_3cx_compromise_mar23.yar#L216-L232"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "7986bbaee8940da11ce089383521ab420c443ab7b15ed42aed91fd31ce833896"
		hash = "59e1edf4d82fae4978e97512b0331b7eb21dd4b838b850ba46794d9c7a2c0983"
		hash = "aa124a4b4df12b34e74ee7f6c683b2ebec4ce9a8edcf9be345823b4fdcf5d868"
		hash = "c485674ee63ec8d4e8fde9800788175a8b02d3f9416d0e763360fff7f8eb4e02"
		logic_hash = "6ab8a4ac184eaba6eb56bfc49d6fa03f9b0877d75294aa9a242e9ac96482fab0"
		score = 70
		quality = 85
		tags = ""

	strings:
		$a1 = "AVMonitorRefreshEvent" wide fullword

	condition:
		1 of them
}
rule SIGNATURE_BASE_APT_MAL_NK_3CX_Malicious_Samples_Mar23_4
{
	meta:
		description = "Detects decrypted payload loaded inside 3CXDesktopApp.exe which downloads info stealer"
		author = "MalGamy (Nextron Systems)"
		id = "d11170df-570c-510c-80ec-39048acd0fbd"
		date = "2023-03-29"
		modified = "2023-12-05"
		reference = "https://twitter.com/WhichbufferArda/status/1641404343323688964?s=20"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mal_3cx_compromise_mar23.yar#L234-L249"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "851c2c99ebafd4e5e9e140cfe3f2d03533846ca16f8151ae8ee0e83c692884b7"
		logic_hash = "2fd56527a094b1f155cf33af402328835d4fb8aee9a058742d3e3763acef9e46"
		score = 80
		quality = 85
		tags = ""

	strings:
		$op1 = {41 69 D0 [4] 8B C8 C1 E9 ?? 33 C1 8B C8 C1 E1 ?? 81 C2 [4] 33 C1 43 8D 0C 02 02 C8 49 C1 EA ?? 41 88 0B 8B C8 C1 E1 ?? 33 C1 44 69 C2 [4] 8B C8 C1 E9 ?? 33 C1 8B C8 C1 E1 ?? 41 81 C0 [4] 33 C1 4C 0F AF CF 4D 03 CA 45 8B D1 4C 0F AF D7 41 8D 0C 11 49 C1 E9 ?? 02 C8}
		$op2 = {4D 0F AF CC 44 69 C2 [4] 4C 03 C9 45 8B D1 4D 0F AF D4 41 8D 0C 11 41 81 C0 [4] 02 C8 49 C1 E9 ?? 41 88 4B ?? 4D 03 D1 8B C8 45 8B CA C1 E1 ?? 33 C1}
		$op3 = {33 C1 4C 0F AF C7 8B C8 C1 E1 ?? 4D 03 C2 33 C1}

	condition:
		2 of them
}
rule SIGNATURE_BASE_MAL_3Cxdesktopapp_Macos_Backdoor_Mar23 : FILE
{
	meta:
		description = "Detects 3CXDesktopApp MacOS Backdoor component"
		author = "X__Junior (Nextron Systems)"
		id = "80046c8e-0c2a-5885-b140-a6084f48160d"
		date = "2023-03-30"
		modified = "2023-12-05"
		reference = "https://www.volexity.com/blog/2023/03/30/3cx-supply-chain-compromise-leads-to-iconic-incident/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mal_3cx_compromise_mar23.yar#L251-L275"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "a64fa9f1c76457ecc58402142a8728ce34ccba378c17318b3340083eeb7acc67"
		logic_hash = "777a0a29c376f3697021dd627e716c31bda7933c5f40a8fe79b80e3cea46ce43"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$sa1 = "%s/.main_storage" ascii fullword
		$sa2 = "%s/UpdateAgent" ascii fullword
		$op1 = { 31 C0 41 80 34 06 ?? 48 FF C0 48 83 F8 ?? 75 ?? BE ?? ?? ?? ?? BA ?? ?? ?? ?? 4C 89 F7 48 89 D9 E8 ?? ?? ?? ?? 48 89 DF E8 ?? ?? ?? ?? 48 89 DF E8 ?? ?? ?? ?? 4C 89 F7 5B 41 5E 41 5F E9 ?? ?? ?? ?? 5B 41 5E 41 5F C3}
		$op2 = { 0F 11 84 24 ?? ?? ?? ?? 0F 28 05 ?? ?? ?? ?? 0F 29 84 24 ?? ?? ?? ?? 0F 28 05 ?? ?? ?? ?? 0F 29 84 24 ?? ?? ?? ?? 31 C0 80 B4 04 ?? ?? ?? ?? ?? 48 FF C0}

	condition:
		(( uint16( 0 ) == 0xfeca or uint16( 0 ) == 0xfacf or uint32( 0 ) == 0xbebafeca ) and filesize < 6MB and ( ( 1 of ( $sa* ) and 1 of ( $op* ) ) or all of ( $sa* ) ) ) or ( all of ( $op* ) )
}
rule SIGNATURE_BASE_APT_MAL_NK_3CX_ICONIC_Stealer_Mar23_1 : FILE
{
	meta:
		description = "Detects ICONIC stealer payload used in the 3CX incident"
		author = "Florian Roth (Nextron Systems)"
		id = "e92b5b90-1146-5235-9711-a4d42689c49b"
		date = "2023-03-31"
		modified = "2023-12-05"
		reference = "https://github.com/volexity/threat-intel/blob/main/2023/2023-03-30%203CX/attachments/iconicstealer.7z"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mal_3cx_compromise_mar23.yar#L279-L304"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "8ab3a5eaaf8c296080fadf56b265194681d7da5da7c02562953a4cb60e147423"
		logic_hash = "1f57a2af4a5b9e71e2b72ddc3839400731d9d37eb4349c393b37b3f86c0c7f73"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "{\"HostName\": \"%s\", \"DomainName\": \"%s\", \"OsVersion\": \"%d.%d.%d\"}" wide fullword
		$s2 = "******************************** %s ******************************" wide fullword
		$s3 = "AppData\\Local\\BraveSoftware\\Brave-Browser\\User Data" wide fullword
		$s4 = "AppData\\Roaming\\Mozilla\\Firefox\\Profiles" wide fullword
		$s5 = "SELECT url, title FROM urls ORDER BY id DESC LIMIT 500" wide fullword
		$s6 = "TEXT value in %s.%s" ascii fullword
		$op1 = { 48 63 d1 48 63 ce 49 03 d1 49 03 cd 4c 63 c7 e8 87 1f 09 00 8b 45 d0 44 8d 04 37 }
		$op2 = { 48 8b c8 8b 56 f0 48 89 46 d8 e8 78 8f f8 ff e9 ec 13 00 00 c7 46 20 ff ff ff ff e9 e0 13 00 00 33 ff }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 4000KB and 4 of them or 6 of them
}
rule SIGNATURE_BASE_APT_MAL_NK_3CX_Macos_Elextron_App_Mar23_1 : FILE
{
	meta:
		description = "Detects macOS malware used in the 3CX incident"
		author = "Florian Roth (Nextron Systems)"
		id = "7a3755d4-37e5-5d3b-93aa-34edb557f2d5"
		date = "2023-03-31"
		modified = "2023-12-05"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mal_3cx_compromise_mar23.yar#L306-L328"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "51079c7e549cbad25429ff98b6d6ca02dc9234e466dd9b75a5e05b9d7b95af72"
		hash = "f7ba7f9bf608128894196cf7314f68b78d2a6df10718c8e0cd64dbe3b86bc730"
		logic_hash = "00dd28c3edd94e04e35ee9e3a43c30b5a0a1ad21ec8ecf2099bbeb9de2fca8d0"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "com.apple.security.cs.allow-unsigned-executable-memory" ascii
		$a2 = "com.electron.3cx-desktop-app" ascii fullword
		$s1 = "s8T/RXMlALbXfowom9qk15FgtdI=" ascii
		$s2 = "o8NQKPJE6voVZUIGtXihq7lp0cY=" ascii

	condition:
		uint16( 0 ) == 0xfacf and filesize < 400KB and ( all of ( $a* ) and 1 of ( $s* ) )
}
rule SIGNATURE_BASE_MAL_3Cxdesktopapp_Macos_Updateagent_Mar23 : FILE
{
	meta:
		description = "Detects 3CXDesktopApp MacOS UpdateAgent backdoor component"
		author = "Florian Roth (Nextron Systems)"
		id = "596eb6d0-f96f-5106-ae67-9372d238e4cf"
		date = "2023-03-30"
		modified = "2023-12-05"
		reference = "https://twitter.com/patrickwardle/status/1641692164303515653?s=20"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mal_3cx_compromise_mar23.yar#L330-L354"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "9e9a5f8d86356796162cee881c843cde9eaedfb3"
		logic_hash = "0818a8f0b59a9baaefaa0b505f8261e0e0df283e79da8e95dc71e9afdca224ab"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "/3CX Desktop App/.main_storage" ascii
		$x1 = ";3cx_auth_token_content=%s;__tutma=true"
		$s1 = "\"url\": \"https://"
		$s3 = "/dev/null"
		$s4 = "\"AccountName\": \""

	condition:
		uint16( 0 ) == 0xfeca and filesize < 6MB and ( 1 of ( $x* ) or ( $a1 and all of ( $s* ) ) ) or all of them
}
rule SIGNATURE_BASE_APT_MAL_VEILEDSIGNAL_Backdoor_Apr23_2
{
	meta:
		description = "Detects malicious VEILEDSIGNAL backdoor"
		author = "X__Junior"
		id = "ff1fa0bd-19b7-553a-9506-bc5aa5d29056"
		date = "2023-04-29"
		modified = "2023-12-05"
		reference = "https://symantec-enterprise-blogs.security.com/blogs/threat-intelligence/xtrader-3cx-supply-chain"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mal_3cx_compromise_mar23.yar#L373-L392"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "c4887a5cd6d98e273ba6e9ea3c1d8f770ef26239819ea24a1bfebd81d6870505"
		logic_hash = "a15f7f06be5e620baf33d595afc35246dae0307978984af832940a74ef2c84eb"
		score = 80
		quality = 85
		tags = ""

	strings:
		$sa1 = "\\.\\pipe\\gecko.nativeMessaging" ascii
		$sa2 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.54 Safari/537.36 Edg/95.0.1020.40" ascii
		$sa3 = "application/json, text/javascript, */*; q=0.01" ascii
		$op1 = { 89 7? 24 ?? 44 8B CD 4C 8B C? 48 89 44 24 ?? 33 D2 33 C9 FF 15}
		$op2 = { 4C 8B CB 4C 89 74 24 ?? 4C 8D 05 ?? ?? ?? ?? 44 89 74 24 ?? 33 D2 33 C9 FF 15}
		$op3 = { 48 89 74 24 ?? 45 33 C0 89 74 24 ?? 41 B9 ?? ?? ?? ?? 89 74 24 ?? 48 8B D8 48 C7 00 ?? ?? ?? ?? 48 8B 0F 41 8D 50 ?? 48 89 44 24 ?? 89 74 24 ?? FF 15}

	condition:
		all of ( $op* ) or all of ( $sa* )
}
rule SIGNATURE_BASE_APT_MAL_VEILEDSIGNAL_Backdoor_Apr23_3
{
	meta:
		description = "Detects malicious VEILEDSIGNAL backdoor"
		author = "X__Junior"
		id = "6b6f984e-242a-5b84-baa9-6311992cde9b"
		date = "2023-04-29"
		modified = "2023-12-05"
		reference = "https://symantec-enterprise-blogs.security.com/blogs/threat-intelligence/xtrader-3cx-supply-chain"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mal_3cx_compromise_mar23.yar#L394-L410"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "595392959b609caf088d027a23443cf2fefd043607ccdec3de19ad3bb43a74b1"
		logic_hash = "58f860926db4a7dfefbd39ee35efaa0081b7e31a361efce02f5144266ab652a6"
		score = 80
		quality = 85
		tags = ""

	strings:
		$op1 = { 4C 8B CB 4C 89 74 24 ?? 4C 8D 05 ?? ?? ?? ?? 44 89 74 24 ?? 33 D2 33 C9 FF 15}
		$op2 = { 89 7? 24 ?? 44 8B CD 4C 8B C? 48 89 44 24 ?? 33 D2 33 C9 FF 15}
		$op3 = { 8B 54 24 ?? 4C 8D 4C 24 ?? 45 8D 46 ?? 44 89 74 24 ?? 48 8B CB FF 15}
		$op4 = { 48 8D 44 24 ?? 45 33 C9 41 B8 01 00 00 40 48 89 44 24 ?? 41 8B D5 48 8B CF FF 15}

	condition:
		all of them
}
rule SIGNATURE_BASE_APT_MAL_VEILEDSIGNAL_Backdoor_Apr23_4
{
	meta:
		description = "Detects malicious VEILEDSIGNAL backdoor"
		author = "X__Junior"
		id = "77340ec0-36bb-5c47-995f-4e6f76b68fe1"
		date = "2023-04-29"
		modified = "2023-12-05"
		reference = "https://symantec-enterprise-blogs.security.com/blogs/threat-intelligence/xtrader-3cx-supply-chain"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mal_3cx_compromise_mar23.yar#L412-L428"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "9b0761f81afb102bb784b398b16faa965594e469a7fcfdfd553ced19cc17e70b"
		logic_hash = "ad22df404d948073428fc35b0c8fbfea25da3bc66e46ea6397ff751ae65d5939"
		score = 80
		quality = 85
		tags = ""

	strings:
		$op1 = { 48 8D 15 ?? ?? ?? ?? 48 8D 4C 24 ?? E8 ?? ?? ?? ?? 85 C0 74 ?? 48 8D 15 ?? ?? ?? ?? 48 8D 4C 24 ?? E8 ?? ?? ?? ?? 85 C0 74 ?? 48 8D 15 ?? ?? ?? ?? 48 8D 4C 24 ?? E8 ?? ?? ?? ?? 85 C0 }
		$op2 = { 48 8B C8 48 8D 15 ?? ?? ?? ?? FF 15 ?? ?? ?? ?? 45 33 C0 4C 8D 4D ?? B2 01 41 8D 48 ?? FF D0}
		$op3 = { 33 FF C7 44 24 ?? 38 02 00 00 33 D2 8D 4F ?? FF 15 ?? ?? ?? ?? 48 8B D8 48 83 F8 FF 74 ?? 48 8D 54 24 ?? 48 8B C8 FF 15 }
		$op4 = { 4C 8D 05 ?? ?? ?? ?? 48 89 4C 24 ?? 4C 8B C8 33 D2 89 4C 24 ?? FF 15 }

	condition:
		all of them
}
rule SIGNATURE_BASE_HKTL_Nim_Nimpackt : EXE FILE HKTL
{
	meta:
		description = "Detects binaries generated with NimPackt v1"
		author = "Cas van Cooten"
		id = "3399d937-133f-5701-840e-eaf68b2f1ec9"
		date = "2022-01-26"
		modified = "2023-12-05"
		reference = "https://github.com/chvancooten/NimPackt-v1"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_nimpackt.yar#L2-L23"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "2bda7acb440d1c72efeaddcb18b736343d658d59feccf6c9339b313cd35f32eb"
		score = 80
		quality = 79
		tags = "EXE, FILE, HKTL"

	strings:
		$nim1 = "fatal.nim" ascii fullword
		$nim2 = "winim" ascii
		$np1 = { 4E 69 6D 50 61 63 6B 74 }
		$sus1 = { 61 6D 73 69 00 00 00 00 B8 57 00 07 80 C3 }
		$sus2 = { 5B 2B 5D 20 49 6E 6A 65 63 74 65 64 }
		$sus3 = { 5C 2D 2D 20 62 79 74 65 73 20 77 72 69 74 74 65 6E 3A }

	condition:
		uint16( 0 ) == 0x5A4D and filesize < 750KB and 1 of ( $nim* ) and ( $np1 or 2 of ( $sus* ) )
}
rule SIGNATURE_BASE_EXPL_LNX_Copy_Fail_Artefacts_CVE_2026_31431_Apr26 : CVE_2026_31431
{
	meta:
		description = "Detects forensic artifacts related to public Copy Fail (CVE-2026-31431) exploit PoCs, including known tiny ELF shell payloads, Python exploit code fragments, AF_ALG/authencesn/splice usage patterns, public PoC URLs, and other indicators observed in online proof-of-concept material."
		author = "Florian Roth"
		id = "753c6116-16d0-5890-98ae-84a417345e94"
		date = "2026-04-30"
		modified = "2026-05-15"
		reference = "https://github.com/iss4cf0ng/CVE-2026-31431-Linux-Copy-Fail"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_copy_fail_cve_2026_31431.yar#L1-L57"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "cb392f5bd4d3c1cc1a841e3912d2d58047bcef601fa090581824259b11b59add"
		score = 75
		quality = 83
		tags = "CVE-2026-31431"

	strings:
		$xn1 = "curl https://copy.fail/exp" ascii
		$xs1 = "| python3 && su"
		$xs2 = "g.open(\"/usr/bin/su\",0);i=0;"
		$xs3 = "[-] page-cache mutation failed"
		$xs4 = "[+] /etc/passwd page cache mutated"
		$xs5 = "bind(AF_ALG: authencesn(hmac(sha256),cbc(aes)))"
		$xs6 = "/tmp/.cve_test"
		$sa1 = "authencesn(hmac(sha256),cbc(aes))" ascii
		$sb1 = { 08 00 01 00 00 00 00 10 }
		$sb2 = "0800010000000010" ascii
		$xe1 = "authencesn(hmac(sha256),cbc(aes))" base64
		$xc1 = { 7f 45 4c 46 02 01 01 00 00 00 00 00 00 00 00 00 02 00 3e 00 01 00 00 00 78 00 40 00 00 00 00 00 40 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 40 00 38 00 01 00 00 00 00 00 00 00 01 00 00 00 05 00 00 00 00 00 00 00 00 00 00 00 00 40 00 00 00 00 00 00 40 00 00 00 00 00 00 9e 00 00 00 00 00 00 00 9e 00 00 00 00 00 00 00 00 10 00 00 00 00 00 00 31 c0 31 ff b0 69 0f 05 48 8d 3d 0f 00 00 00 31 f6 6a 3b 58 99 0f 05 31 ff 6a 3c 58 0f 05 2f 62 69 6e 2f 73 68 00 00 00 }
		$xc2 = { 7f 45 4c 46 02 01 01 00 00 00 00 00 00 00 00 00 02 00 b7 00 01 00 00 00 78 00 40 00 00 00 00 00 40 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 40 00 38 00 01 00 00 00 00 00 00 00 01 00 00 00 05 00 00 00 00 00 00 00 00 00 00 00 00 40 00 00 00 00 00 00 00 40 00 00 00 00 00 00 ac 00 00 00 00 00 00 00 ac 00 00 00 00 00 00 00 00 10 00 00 00 00 00 00 00 00 00 80 d2 48 12 80 d2 01 00 00 d4 00 01 00 10 01 00 80 d2 02 00 80 d2 a8 1b 80 d2 01 00 00 d4 00 00 80 d2 a8 0b 80 d2 01 00 00 d4 2f 62 69 6e 2f 73 68 00 }
		$xg1 = "789cab77f57163626464800126063b0610af82c101cc7760c0040e0c160c301d209a154d16999e07e5c1680601086578c0f0ff864c7e568f5e5b7e10f75b9675c44c7e56c3ff593611fcacfa499979fac5190c00111d10d3"
		$xg2 = "789cab77f57163646464800126066606102fa48185c38401014c18141860aae0aa816a40b806c80461569098000383e101c3db1bae9e6d303c1090a1af5f9c91a19f9499d7f93820b8f361e7a10ddc4089db598c11671b0038b31858"
		$xg3 = "78daab77f5716362646480012686ed0c205e05830398efc080091c182c18603a40342b9a2c32bd06ca5b039787e96cb8e421d47009c8bb0214126004f29980788534540cc4e686b0f59332f3f48b3318003ff61578"
		$xg4 = "789cab77f57163626464800126063b0610af82c101cc7760c0040e0c160c301d209a154d16999e02e5c1680601086578c0f0ff864c7e568fee1a1501c36f59d61133f9590dff67d944f0b3020082b00eaf"
		$xg5 = "789cab77f57163646464800126066606102fa48185c38401014c18141860aae0aa816a40381fc80461569098000383e101c3db1bae9e6de88e51e1303c99c51d31f36c83e1ed2cc688b30d001bf41180"
		$xg6 = "789cab77f5716362646480012686ed0c205e05830398efc080091c182c18603a40342b9a2c32bd04ca5b029787e96cb8e421d47009c8bbf280dbe1272390cf04c42ba4216220f915dc103600d72b1509"
		$xge1 = { 78 9c ab 77 f5 71 63 62 64 64 80 01 26 06 3b 06 10 af 82 c1 01 cc 77 60 c0 04 0e 0c 16 0c 30 1d 20 9a 15 4d 16 99 9e 07 e5 c1 68 06 01 08 65 78 c0 f0 ff 86 4c 7e 56 8f 5e 5b 7e 10 f7 5b 96 75 c4 4c 7e 56 c3 ff 59 36 11 fc ac fa 49 99 79 fa c5 19 0c 00 11 1d 10 d3 }
		$xge2 = { 78 9c ab 77 f5 71 63 64 64 64 80 01 26 06 66 06 10 2f a4 81 85 c3 84 01 01 4c 18 14 18 60 aa e0 aa 81 6a 40 b8 06 c8 04 61 56 90 98 00 03 83 e1 01 c3 db 1b ae 9e 6d 30 3c 10 90 a1 af 5f 9c 91 a1 9f 94 99 d7 f9 38 20 b8 f3 61 e7 a1 0d dc 40 89 db 59 8c 11 67 1b 00 38 b3 18 58 }
		$xge3 = { 78 da ab 77 f5 71 63 62 64 64 80 01 26 86 ed 0c 20 5e 05 83 03 98 ef c0 80 09 1c 18 2c 18 60 3a 40 34 2b 9a 2c 32 bd 06 ca 5b 03 97 87 e9 6c b8 e4 21 d4 70 09 c8 bb 02 14 12 60 04 f2 99 80 78 85 34 54 0c c4 e6 86 b0 f5 93 32 f3 f4 8b 33 18 00 3f f6 15 78 }
		$xge4 = { 78 9c ab 77 f5 71 63 62 64 64 80 01 26 06 3b 06 10 af 82 c1 01 cc 77 60 c0 04 0e 0c 16 0c 30 1d 20 9a 15 4d 16 99 9e 02 e5 c1 68 06 01 08 65 78 c0 f0 ff 86 4c 7e 56 8f ee 1a 15 01 c3 6f 59 d6 11 33 f9 59 0d ff 67 d9 44 f0 b3 02 00 82 b0 0e af }
		$xge5 = { 78 9c ab 77 f5 71 63 64 64 64 80 01 26 06 66 06 10 2f a4 81 85 c3 84 01 01 4c 18 14 18 60 aa e0 aa 81 6a 40 38 1f c8 04 61 56 90 98 00 03 83 e1 01 c3 db 1b ae 9e 6d e8 8e 51 e1 30 3c 99 c5 1d 31 f3 6c 83 e1 ed 2c c6 88 b3 0d 00 1b f4 11 80 }
		$xge6 = { 78 9c ab 77 f5 71 63 62 64 64 80 01 26 86 ed 0c 20 5e 05 83 03 98 ef c0 80 09 1c 18 2c 18 60 3a 40 34 2b 9a 2c 32 bd 04 ca 5b 02 97 87 e9 6c b8 e4 21 d4 70 09 c8 bb f2 80 db e1 27 23 90 cf 04 c4 2b a4 21 62 20 f9 15 dc 10 36 00 d7 2b 15 09 }

	condition:
		1 of ( $x* ) or ( $sa1 and 1 of ( $sb* ) )
}
rule SIGNATURE_BASE_Mal_Lockbit4_Hashing_Alg_Win_Feb24 : FILE
{
	meta:
		description = "This rule detects the custom hashing algorithm of Lockbit4.0 unpacked"
		author = "0x0d4y"
		id = "e91aedba-6f70-4ca2-9217-2991cbbc6e8d"
		date = "2024-02-16"
		modified = "2026-05-15"
		reference = "https://0x0d4y.blog/lockbit4-0-evasion-tales/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_lockbit4_hashing_alg_win_feb24.yar#L1-L22"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "062311f136d83f64497fd81297360cd4"
		logic_hash = "41497ea30a4cfdd111726a5819ec404a1eeba1693f5d6b89ac38558eb1c6bde9"
		score = 100
		quality = 85
		tags = "FILE"
		license = "CC BY 4.0"
		rule_matching_tlp = "TLP:WHITE"
		rule_sharing_tlp = "TLP:WHITE"
		malpedia_family = "win.lockbit"

	strings:
		$hashing_alg = { 41 89 d0 46 0f be 04 00 45 09 c0 74 ?? 45 8d 48 ?? 45 8d 50 ?? 41 80 f9 ?? 45 0f 43 d0 44 31 d1 44 8d 04 3a 45 0f af c2 41 01 c8 89 d1 31 f9 09 d2 0f 44 ca 41 0f af c8 44 01 d1 ff c2 eb ?? 49 ff c6 }

	condition:
		uint16( 0 ) == 0x5a4d and $hashing_alg
}
rule SIGNATURE_BASE_HKTL_EDR_Freeze_Sep25_2 : FILE
{
	meta:
		description = "Detects EDR-Freeze hacktool"
		author = "Florian Roth"
		id = "e3fd5815-71c4-5510-bfb4-82203d81cc78"
		date = "2025-09-30"
		modified = "2026-05-15"
		reference = "https://github.com/TwoSevenOneT/EDR-Freeze"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/hktl_edr_freeze_sep25.yar#L1-L36"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "193ca17f574fa5e23866560170425f83696f78e83dabd7e831dd7827a69283fd"
		hash = "36a17919a97732f1ddc31b421c6ebb0c535924f895d7caaff04a5da908c42f76"
		hash = "394b768bfd3506a9ee6b7bbe6f87c40fb23c28f7919a2a9eb333b27db635eafe"
		hash = "a8ec07f006a9068ce5f068b3bb61b0649481b6b26203b8eb4308c53ff1d1bf8d"
		hash = "d485017fb20c5a8fe38a6dbf896d4cbce485ff53a6cfe0e1440a1818b2d303ee"
		hash = "d989ebd417e6fae60a544e43bfc0ee63f5d9352ce0059b95ed4e7e18efbc5d0b"
		hash = "e2b2dd0984e52112965392471f6a09020eb8380aa53d48d2fb4dd3aaa7edae9b"
		logic_hash = "735d56839f17ca98a0022e6044b8d0bc43201b48e3a64c7b671c417f62749643"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "EDR-Freeze.exe <TargetPID> <SleepTime>" wide fullword
		$x2 = "Successfully created PPL process with PID:" wide fullword
		$x3 = "\\EDR-Freeze.pdb" ascii
		$sa1 = "C:\\Windows\\System32\\WerFaultSecure.exe" wide fullword
		$sa2 = "Failed to create dump files: " wide fullword
		$sb1 = " /encfile" wide fullword
		$sb2 = " /pid" wide fullword
		$sb3 = " /tid" wide fullword
		$sb4 = " /cancel" wide fullword

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 1000KB and ( 1 of ( $x* ) or all of ( $sa* ) or all of ( $sb* ) ) or 6 of them
}
rule SIGNATURE_BASE_Crime_H2Miner_Kinsing : FILE
{
	meta:
		description = "Rule to find Kinsing malware"
		author = "Tony Lambert, Red Canary"
		id = "1cabca0d-7134-517e-b82e-f2b20b4d1c34"
		date = "2020-06-09"
		modified = "2023-12-05"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_h2miner_kinsing.yar#L1-L20"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8795f01f4ce85ca37a4e4667a4ee9756dae6af42884cf79830877a5c35a3bd3b"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "-iL $INPUT --rate $RATE -p$PORT -oL $OUTPUT"
		$s2 = "libpcap"
		$s3 = "main.backconnect"
		$s4 = "main.masscan"
		$s5 = "main.checkHealth"
		$s6 = "main.redisBrute"
		$s7 = "ActiveC2CUrl"
		$s8 = "main.RC4"
		$s9 = "main.runTask"

	condition:
		( uint32( 0 ) == 0x464C457F ) and filesize > 1MB and all of them
}
rule SIGNATURE_BASE_SUSP_BAT_Aux_Jan20_1 : FILE
{
	meta:
		description = "Detects BAT file often dropped to cleanup temp dirs during infection"
		author = "Florian Roth (Nextron Systems)"
		id = "c97f189e-a0c2-532e-b087-8669da72a2ad"
		date = "2020-01-29"
		modified = "2023-12-05"
		reference = "https://medium.com/@quoscient/the-chicken-keeps-laying-new-eggs-uncovering-new-gc-maas-tools-used-by-top-tier-threat-actors-531d80a6b4e9"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_susp_bat_aux.yar#L2-L19"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "f5d558ec505b635b1e37557350562ad6f79b3da5cf2cf74db6e6e648b7a47127"
		logic_hash = "6b8cd9b7683a18a02a81222d6819fe903500702c83f198f73ac428d1bc91fb9a"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "if exist \"C:\\Users\\" ascii
		$s2 = "\\AppData\\Local\\Temp\\" ascii
		$s3 = "del \"C:\\Users\\" ascii
		$s4 = ".bat\"" ascii
		$s5 = ".exe\" goto" ascii

	condition:
		uint8( 0 ) == 0x3a and filesize <= 1KB and all of them
}
rule SIGNATURE_BASE_MAL_Icedid_GZIP_LDR_202104 : FILE
{
	meta:
		description = "2021 initial Bokbot / Icedid loader for fake GZIP payloads"
		author = "Thomas Barabosch, Telekom Security"
		id = "fbf578e7-c318-5f67-82df-f93232362a23"
		date = "2021-04-12"
		modified = "2023-01-27"
		reference = "https://www.telekom.com/en/blog/group/article/let-s-set-ice-on-fire-hunting-and-detecting-icedid-infections-627240"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_icedid.yar#L14-L40"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7a7cc6c7dcbf43bace6a1f259af38560327c34386517e719ad81068b2d9b6659"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$internal_name = "loader_dll_64.dll" fullword
		$string0 = "_gat=" wide
		$string1 = "_ga=" wide
		$string2 = "_gid=" wide
		$string4 = "_io=" wide
		$string5 = "GetAdaptersInfo" fullword
		$string6 = "WINHTTP.dll" fullword
		$string7 = "DllRegisterServer" fullword
		$string8 = "PluginInit" fullword
		$string9 = "POST" wide fullword
		$string10 = "aws.amazon.com" wide fullword

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 5000KB and ( $internal_name or all of ( $s* ) ) or all of them
}
rule SIGNATURE_BASE_SUSP_Scheduledtasks_Nimbus_Manticore_Persistence_May26 : FILE
{
	meta:
		description = "Detects scheduled task used for persistence by Nimbus Manticore (UNC1549). The task is used to persistenly load a custom implant that features data exfiltration and remote control capabilities."
		author = "Jonathan Peters (Nextron Systems)"
		id = "a3be3756-7706-4894-9526-23f09db5fb06"
		date = "2026-05-27"
		modified = "2026-10-29"
		reference = "https://www.nextron-systems.com/2026/06/01/detecting-nimbus-manticore-and-their-sideloading-infection-chains/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt35_malware_may26.yar#L1-L17"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "dc4c82625db0dd8db2098387f227ade773d31747b259b3ffc2c366c47d9b0d20"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$a0 = "<Task version=" wide
		$a1 = "xmlns=\"http://schemas.microsoft.com/windows/" wide
		$x1 = "<Arguments>doit" wide

	condition:
		uint16( 0 ) == 0xfeff and all of them
}
rule SIGNATURE_BASE_MAL_APT_Nimbus_Manticore_Stager_May26 : FILE
{
	meta:
		description = "Detects .NET based stager using AppDomain Hijacking observed to be used by Nimbus Manticore (UNC1549). The stager drops another payload and establishes persistence via scheduled task."
		author = "Jonathan Peters (Nextron Systems)"
		id = "c8da4412-f709-4c92-8ef5-22c2e78c24a8"
		date = "2026-05-20"
		modified = "2026-10-29"
		reference = "https://www.nextron-systems.com/2026/06/01/detecting-nimbus-manticore-and-their-sideloading-infection-chains/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt35_malware_may26.yar#L19-L49"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "eee657ffdb2af8ed6412221e7d5fbf4f5742f2ac2c88f43f12db46af0697de71"
		logic_hash = "b6ea20370c929a61e628f078ed74c45bd3c7278d3e9c499dbcb9af3f33f23c78"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "MyCompany-Product-TOTP-Salt-2024!@#$" wide fullword
		$x2 = "TOTPGuardRunner" ascii fullword
		$x3 = "\\AppDomainInjection-metlifeScenario\\TOTP" ascii
		$sa1 = "EncData" ascii fullword
		$sa2 = "DecryptAndSaveToDesktop" ascii fullword
		$sa3 = "CopyHelloToDesktop" ascii fullword
		$sb1 = "doit" wide fullword
		$sb2 = "DailyTrigger" wide fullword
		$sb3 = "GetTypeFromCLSID" ascii
		$sb4 = "yyyy-MM-ddTHH:mm:ss" wide fullword

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $x* ) or all of ( $sa* ) or all of ( $sb* ) )
}
rule SIGNATURE_BASE_MAL_APT_Nimbus_Manticore_Agent_May26 : FILE
{
	meta:
		description = "Detects Nimbus Manticore (UNC1549) agent implant featuring data exfiltration and remote control."
		author = "Jonathan Peters (Nextron Systems)"
		id = "985c870e-7edb-4077-b6b0-fbe1bed136a0"
		date = "2026-05-28"
		modified = "2026-10-29"
		reference = "https://www.nextron-systems.com/2026/06/01/detecting-nimbus-manticore-and-their-sideloading-infection-chains/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt35_malware_may26.yar#L51-L72"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "dfa1e3137a032ee8561a1cd5e1a0f71a10bebb36aef7c336c878638a9c1239ee"
		logic_hash = "d4aef73f6fc9ad3e03a05e8ecda01bb7faf83ae40d7393b41a5f619c70a45136"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "Chrome/146.0.0.0 Safari/537.36" wide
		$a2 = ".azurewebsites.net" wide
		$s1 = "/agent/poll?token=" wide fullword
		$s2 = "/agent/init" wide fullword
		$s3 = "/agent/result" wide fullword

	condition:
		uint16( 0 ) == 0x5a4d and 1 of ( $a* ) and 1 of ( $s* ) or 3 of them
}
rule SIGNATURE_BASE_SUSP_Nimbus_Manticore_PDF_Indicators_May26
{
	meta:
		description = "Detects indicators found in PDF files created by Nimbus Manticore (UNC1549). The PDF files usually contain fake job offers or descriptions to lure victims into installing malware."
		author = "Jonathan Peters (Nextron Systems)"
		id = "5f755a33-4b72-4781-b597-bbeb1288f9e7"
		date = "2026-05-25"
		modified = "2026-10-29"
		reference = "https://www.nextron-systems.com/2026/06/01/detecting-nimbus-manticore-and-their-sideloading-infection-chains/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_apt35_malware_may26.yar#L74-L87"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "620c51f4376cb79f0109c21971c28661418ae50b119585e3ffdb8011189fcb7b"
		logic_hash = "4479c844cae60f0cabdb8b57e6de9961d4b9d5e9afdc43793fd936e0bed6899a"
		score = 70
		quality = 85
		tags = ""

	strings:
		$op = { 3C 3C 2F 41 75 74 68 6F 72 28 4A 65 72 72 79 29 20 2F 43 72 65 61 74 6F 72 28 FE FF 00 4D 00 69 00 63 00 72 00 6F 00 73 00 6F 00 66 00 74 00 AE 00 20 00 57 00 6F 00 72 00 64 00 20 00 4C 00 54 00 53 00 43 29 }

	condition:
		1 of them
}
rule SIGNATURE_BASE_EXPL_React_Server_CVE_2025_55182_POC_Dec25 : CVE_2025_55182
{
	meta:
		description = "Detects in-memory webshell indicators related to the proof-of-concept code for the React Server Remote Code Execution Vulnerability (CVE-2025-55182)"
		author = "Florian Roth"
		id = "1ad38541-1477-5c07-9975-318357bcb9b8"
		date = "2025-12-05"
		modified = "2026-05-15"
		reference = "https://x.com/pyn3rd/status/1996840827897954542/photo/1"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/react_pocs_indicators_dec25.yar#L1-L20"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a4f27fc85807e8f94e6947523a09d87ceed0658334756a9724322181c3eecd20"
		score = 70
		quality = 85
		tags = "CVE-2025-55182"

	strings:
		$xs1 = "{const cmd=p.query.cmd;if(!cmd)(s.writeHead(400);"
		$s1 = ";if(p.pathname=="
		$s2 = ".writeHead(400);"
		$s3 = ".writeHead(200,{'Content-Type':"
		$s4 = ".execSync("
		$s5 = ",stdio:'pipe'})"

	condition:
		1 of ( $x* ) or all of ( $s* )
}
rule SIGNATURE_BASE_EXPL_RCE_React_Server_CVE_2025_55182_POC_Dec25 : CVE_2025_55182 FILE
{
	meta:
		description = "Detects RCE indicators related to the proof-of-concept code for the React Server Remote Code Execution Vulnerability (CVE-2025-55182)"
		author = "Florian Roth"
		id = "fdd661a9-0532-5246-b744-0c1a9632d1cd"
		date = "2025-12-05"
		modified = "2026-05-15"
		reference = "https://www.youtube.com/watch?v=MmdwakT-Ve8"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/react_pocs_indicators_dec25.yar#L41-L56"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "54854f6cf3d1f4f30fb6de8312a5969bd5bc0d8c7a047a9f0ef195551c1dc2c6"
		score = 70
		quality = 85
		tags = "CVE-2025-55182, FILE"

	strings:
		$s1 = "process.mainModule.require('child_process').execSync("
		$s2 = "$1:constructor:constructor"

	condition:
		all of them and not uint16( 0 ) == 0x3c3f
}
rule SIGNATURE_BASE_EXPL_RCE_React_Server_Next_JS_CVE_2025_66478_Errors_Dec25 : CVE_2025_55182 CVE_2025_66478
{
	meta:
		description = "Detects error messages caused by the exploitation of the React Server Remote Code Execution Vulnerability (CVE-2025-55182) in Next.js applications (CVE-2025-66478). This can also be caused by vulnerability scanning."
		author = "Florian Roth"
		id = "6baeb522-6299-56a2-be27-21c6b668439b"
		date = "2025-12-05"
		modified = "2026-05-15"
		reference = "https://github.com/Malayke/Next.js-RSC-RCE-Scanner-CVE-2025-66478"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/react_pocs_indicators_dec25.yar#L74-L87"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "6e5d809cd436935324ad4cb657a66a1c257df13a8dd52ee5db1b803ad24560b3"
		score = 65
		quality = 85
		tags = "CVE-2025-55182, CVE-2025-66478"

	strings:
		$s1 = "[Error: NEXT_REDIRECT]"
		$s2 = "digest: 'uid=0(root) gid=0(root)"

	condition:
		all of them
}
rule SIGNATURE_BASE_EXPL_SUSP_JS_POC_Dec25 : CVE_2025_55182 FILE
{
	meta:
		description = "Detects RCE indicators related to the proof-of-concept code for the React Server Remote Code Execution Vulnerability (CVE-2025-55182) but could be used in other JavaScript based PoC code as well"
		author = "Florian Roth"
		id = "114c83f8-b798-5db9-a054-a6148dde7d5a"
		date = "2025-12-05"
		modified = "2025-12-06"
		reference = "https://github.com/msanft/CVE-2025-55182/blob/main/poc.py"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/react_pocs_indicators_dec25.yar#L89-L104"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "142749ac6538d80a9c713eb19b763063e4d788e622f4938ecd0c1edbf51b3c74"
		score = 70
		quality = 85
		tags = "CVE-2025-55182, FILE"

	strings:
		$xr1 = /process\.mainModule\.require\(["']child_process["']\).{5,40}\(["'](whoami|powershell|\/bin\/sh|\/bin\/bash|wget|curl|cat \/etc\/passwd|uname|id["'])/

	condition:
		1 of them and not uint16( 0 ) == 0x3c3f
}
rule SIGNATURE_BASE_EXPL_SUSP_JS_POC_RSC_Detector_Payloads_Dec25 : CVE_2025_55182
{
	meta:
		description = "Detects RCE indicators related to the proof-of-concept code for the React Server Remote Code Execution Vulnerability (CVE-2025-55182) as used in the RSC Detector browser extension but could be used in other JavaScript based PoC code as well"
		author = "Florian Roth"
		id = "98887e97-2dd4-5777-9fab-02805035de14"
		date = "2025-12-06"
		modified = "2026-05-15"
		reference = "https://github.com/mrknow001/RSC_Detector"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/react_pocs_indicators_dec25.yar#L106-L123"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "b51f4028662795ffcbf4c17c1b2cbad35a8fa64104aa5cfdaf24b13e9663eb09"
		score = 70
		quality = 85
		tags = "CVE-2025-55182"

	strings:
		$s1 = "process.mainModule.require('child_process').execSync("
		$s2 = ").toString('base64');"
		$f1 = "echo vulnerability_test"

	condition:
		all of ( $s* ) and not 1 of ( $f* )
}
rule SIGNATURE_BASE_EXPL_WSUS_Exploitation_Indicators_Oct25 : CVE_2025_59287
{
	meta:
		description = "Detects indicators related to the exploitation of the Windows Server Update Services (WSUS) Remote Code Execution Vulnerability (CVE-2025-59287)"
		author = "Florian Roth"
		id = "9a118d85-fbcd-5476-acd8-6bf66f660368"
		date = "2025-10-25"
		modified = "2026-05-15"
		reference = "https://www.huntress.com/blog/exploitation-of-windows-server-update-services-remote-code-execution-vulnerability"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_wsus_cve_2025_59287.yar#L1-L28"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "04487cca15f4151bfc31279fd58dc6898e59149cabb6dbef08c1df88418ab904"
		score = 75
		quality = 85
		tags = "CVE-2025-59287"

	strings:
		$sl1 = "at System.Data.DataSet.DeserializeDataSetSchema(SerializationInfo info, StreamingContext context" ascii wide
		$sl2 = "at System.Runtime.Serialization.ObjectManager.DoFixups()" ascii wide
		$sl3 = "at System.Runtime.Serialization.ObjectManager.CompleteISerializableObject" ascii wide
		$sl4 = "System.Reflection.TargetInvocationException: Exception has been thrown by the target of an invocation." ascii wide
		$sl5 = "ErrorWsusService.9HmtWebServices.CheckReportingWebServiceReporting WebService WebException:System.Net.WebException: Unable to connect to the remote server" ascii wide
		$se1 = "powershell -ec try{$r= (&{echo https://" ascii wide base64 base64wide
		$se2 = ":8531; net user /domain; ipconfig " ascii wide base64 base64wide
		$sa1 = "whoami;net user /domain" ascii wide base64 base64wide
		$sa2 = "net user /domain; ipconfig /all" ascii wide base64 base64wide

	condition:
		all of ( $sl* ) or 1 of ( $se* ) or all of ( $sa* )
}
rule SIGNATURE_BASE_APT_Virtualizor_Compromise_Forensicartifacts_Aug26 : FILE
{
	meta:
		description = "Detects forensic artifacts found in a campaign against compromised hosting providers using Virtualizor software"
		author = "Florian Roth"
		id = "3507b25a-1003-4825-bf65-fa977ca75bc3"
		date = "2026-08-31"
		modified = "2026-10-29"
		reference = "https://lowendtalk.com/discussion/220625/urgent-virtualizor-compromised-31st-aug/p1"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_virtualizor_compromise_aug26.yar#L1-L23"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "2a8821419395a11f1f86ef8324e881a4c8250832e65295dcdfe992b6cc33b363"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "AAAAC3NzaC1lZDI1NTE5AAAAIP13pPAm5jmInLQYD3XNb3HwrW4cAKDcphoT4kSKrnte"
		$x2 = "/tmp/.vz_svc_done"
		$x3 = "/tmp/widdow.jar"
		$x4 = "31.77.220.138:2025"
		$sa1 = "proxyuser"
		$sb1 = "193.32.127.248"

	condition:
		filesize < 5MB and ( 1 of ( $x* ) or all of ( $s* ) )
}
rule SIGNATURE_BASE_APT_Virtualizor_Compromise_Payload_Aug26 : FILE
{
	meta:
		description = "Detects java based payload used in a campaign against compromised hosting providers using Virtualizor software"
		author = "Jonathan Peters (cod3nym)"
		id = "2ba47313-3db9-48d2-94b6-b8441be5e080"
		date = "2026-08-31"
		modified = "2026-10-29"
		reference = "https://lowendtalk.com/discussion/220625/urgent-virtualizor-compromised-31st-aug/p1"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_virtualizor_compromise_aug26.yar#L25-L42"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "b81a4e1fab9fc4e404d57224fe71e2c143aa93942bd46998789bdc944a7870c7"
		logic_hash = "068e6ed5391205f4b98f227085fb2770952342166ea59cd20e7cd157d88b4df3"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "net/ikvm/clientvds/stresser/methods/impl/l4/minecraft/protocollib/" ascii
		$s2 = "oshi/util/VirtualizationDetector" ascii
		$s3 = "META-INF/proguard/base.proUT" ascii

	condition:
		uint16( 0 ) == 0x4b50 and filesize < 20MB and all of them
}
rule SIGNATURE_BASE_HKTL_Cobaltstrike_Sleepmask_Jul22
{
	meta:
		description = "Detects static bytes in Cobalt Strike 4.5 sleep mask function that are not obfuscated"
		author = "CodeX"
		id = "d396ab0e-b584-5a7c-8627-5f318a20f9dd"
		date = "2022-07-04"
		modified = "2023-12-05"
		reference = "https://codex-7.gitbook.io/codexs-terminal-window/blue-team/detecting-cobalt-strike/sleep-mask-kit-iocs"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_cobaltstrike.yar#L3-L15"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "233b3cb441f45f400c0261589aac31dd1fcd9c4e3a86a6aaa46c60849063b34b"
		score = 80
		quality = 85
		tags = ""

	strings:
		$sleep_mask = { 48 8B C4 48 89 58 08 48 89 68 10 48 89 70 18 48 89 78 20 45 33 DB 45 33 D2 33 FF 33 F6 48 8B E9 BB 03 00 00 00 85 D2 0F 84 81 00 00 00 0F B6 45 }

	condition:
		$sleep_mask
}
rule SIGNATURE_BASE_SUSP_Disable_ETW_Jun20_1
{
	meta:
		description = "Detects method to disable ETW in ENV vars before executing a program"
		author = "Florian Roth (Nextron Systems)"
		id = "ea5dee09-959e-5ef2-8f84-5497bdef0a05"
		date = "2020-06-06"
		modified = "2025-03-21"
		reference = "https://gist.github.com/Cyb3rWard0g/a4a115fd3ab518a0e593525a379adee3"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_suspicious_strings.yar#L395-L413"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "182ad2512bcfbcd92d13380113b32982eb367e458019f07038a12f494dfbebb6"
		score = 65
		quality = 85
		tags = ""

	strings:
		$x1 = "set COMPlus_ETWEnabled=0" ascii wide fullword
		$x2 = "$env:COMPlus_ETWEnabled=0" ascii wide fullword
		$s1 = "Software\\Microsoft.NETFramework" ascii wide
		$sa1 = "/v ETWEnabled" ascii wide fullword
		$sa2 = " /d 0" ascii wide
		$sb4 = "-Name ETWEnabled"
		$sb5 = " -Value 0 "

	condition:
		1 of ( $x* ) or 3 of them
}
rule SIGNATURE_BASE_SUSP_PE_Discord_Attachment_Oct21_1 : FILE
{
	meta:
		description = "Detects suspicious executable with reference to a Discord attachment (often used for malware hosting on a legitimate FQDN)"
		author = "Florian Roth (Nextron Systems)"
		id = "7c217350-4a35-505d-950d-1bc989c14bc2"
		date = "2021-10-12"
		modified = "2025-03-21"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_suspicious_strings.yar#L415-L429"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4d84ec50738f4c7aca8e77c3aabdcd77f3071733a2245a58283f070f2b220599"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "https://cdn.discordapp.com/attachments/" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 5000KB and 1 of them
}
rule SIGNATURE_BASE_SUSP_Encoded_Discord_Attachment_Oct21_1 : FILE
{
	meta:
		description = "Detects suspicious encoded URL to a Discord attachment (often used for malware hosting on a legitimate FQDN)"
		author = "Florian Roth (Nextron Systems)"
		id = "06c086f4-8b79-5506-9e3f-b5d099106157"
		date = "2021-10-12"
		modified = "2025-03-21"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_suspicious_strings.yar#L431-L456"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1ea5a83e91b5c5b4b8a1d507c365bc1583394c97a28b7d7a576f085854676769"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$enc_b01 = "Y2RuLmRpc2NvcmRhcHAuY29tL2F0dGFjaG1lbnRz" ascii wide
		$enc_b02 = "Nkbi5kaXNjb3JkYXBwLmNvbS9hdHRhY2htZW50c" ascii wide
		$enc_b03 = "jZG4uZGlzY29yZGFwcC5jb20vYXR0YWNobWVudH" ascii wide
		$enc_b04 = "AGMAZABuAC4AZABpAHMAYwBvAHIAZABhAHAAcAAuAGMAbwBtAC8AYQB0AHQAYQBjAGgAbQBlAG4AdABz" ascii wide
		$enc_b05 = "BjAGQAbgAuAGQAaQBzAGMAbwByAGQAYQBwAHAALgBjAG8AbQAvAGEAdAB0AGEAYwBoAG0AZQBuAHQAc" ascii wide
		$enc_b06 = "AYwBkAG4ALgBkAGkAcwBjAG8AcgBkAGEAcABwAC4AYwBvAG0ALwBhAHQAdABhAGMAaABtAGUAbgB0AH" ascii wide
		$enc_h01 = "63646E2E646973636F72646170702E636F6D2F6174746163686D656E7473" ascii wide
		$enc_h02 = "63646e2e646973636f72646170702e636f6d2f6174746163686d656e7473" ascii wide
		$enc_r01 = "stnemhcatta/moc.ppadrocsid.ndc" ascii wide

	condition:
		filesize < 5000KB and 1 of them
}
rule SIGNATURE_BASE_APT_MAL_NK_Lazarus_VHD_Ransomware_Oct20_1 : FILE
{
	meta:
		description = "Detects Lazarus VHD Ransomware"
		author = "Florian Roth (Nextron Systems)"
		id = "5cb3c136-ec5c-5596-8dcc-e4c6ef33050a"
		date = "2020-10-05"
		modified = "2023-12-05"
		reference = "https://securelist.com/lazarus-on-the-hunt-for-big-game/97757/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_lazarus_vhd_ransomware.yar#L2-L24"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "52888b5f881f4941ae7a8f4d84de27fc502413861f96ee58ee560c09c11880d6"
		hash = "5e78475d10418c6938723f6cfefb89d5e9de61e45ecf374bb435c1c99dd4a473"
		hash = "6cb9afff8166976bd62bb29b12ed617784d6e74b110afcf8955477573594f306"
		logic_hash = "95c56c5111bb227da8f8a3f8aa4f23e1348bc76ff76a05fc3cae89f9fad1bb52"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "HowToDecrypt.txt" wide fullword
		$s2 = "rsa.cpp" wide fullword
		$s3 = "sc stop \"Microsoft Exchange Compliance Service\"" ascii fullword
		$op1 = { 8b 8d bc fc ff ff 8b 94 bd 34 03 00 00 33 c0 50 }
		$op2 = { 8b 8d 98 f9 ff ff 8d 64 24 00 8b 39 3b bc 85 34 }
		$op3 = { 8b 94 85 34 03 00 00 89 11 40 83 c1 04 3b 06 7c }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 400KB and 2 of them
}
rule SIGNATURE_BASE_APT_MAL_NK_Lazarus_VHD_Ransomware_Oct20_2 : FILE
{
	meta:
		description = "Detects Lazarus VHD Ransomware"
		author = "Florian Roth (Nextron Systems)"
		id = "b75668de-93e6-57e7-90f0-fa335295be7c"
		date = "2020-10-05"
		modified = "2023-12-05"
		reference = "https://securelist.com/lazarus-on-the-hunt-for-big-game/97757/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_lazarus_vhd_ransomware.yar#L26-L43"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "097ca829e051a4877bca093cee340180ff5f13a9c266ad4141b0be82aae1a39b"
		hash = "73a10be31832c9f1cbbd798590411009da0881592a90feb472e80025dfb0ea79"
		logic_hash = "cf28771a854b3bacc911375c09f6c6bc6ddebff95612a509890c56a5a14e8921"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$op1 = { f9 36 88 08 8d ad fc ff ff ff 66 ff c1 e9 72 86 }
		$op2 = { c6 c4 58 0f a4 c8 12 8d ad ff ff ff ff 0f b6 44 }
		$op3 = { 88 02 66 c1 f0 54 8d bf fc ff ff ff 0f ba e0 19 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 9000KB and all of them
}
rule SIGNATURE_BASE_APT_FIN7_Msdoc_Sep21_1 : FILE
{
	meta:
		description = "Detects MalDocs used by FIN7 group"
		author = "Florian Roth (Nextron Systems)"
		id = "4fbde087-ec1e-5614-af1e-f342b1766fa2"
		date = "2021-09-07"
		modified = "2023-12-05"
		reference = "https://www.anomali.com/blog/cybercrime-group-fin7-using-windows-11-alpha-themed-docs-to-drop-javascript-backdoor"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_fin7.yar#L277-L301"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "d60b6a8310373c9b84e6760c24185535"
		logic_hash = "ffc91cdad91b8ab24840c6ef1a6c39aad081d986c21a88b3f2ea3ec1bcd3b52b"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$xc1 = { 00 4A 00 6F 00 68 00 6E 00 0B 00 57 00 31 00 30
               00 50 00 72 00 6F 00 4F 00 66 00 66 00 31 00 36 }
		$s1 = "word_data.bin" ascii fullword
		$s2 = "V:\\DOC\\For_JS" ascii
		$s3 = "HomeCompany" ascii
		$s4 = "W10ProOff16" ascii

	condition:
		uint16( 0 ) == 0xcfd0 and ( 1 of ( $x* ) or 3 of them )
}
rule SIGNATURE_BASE_SUSP_OBFUSC_JS_Sept21_2 : FILE
{
	meta:
		description = "Detects JavaScript obfuscation as used in MalDocs by FIN7 group"
		author = "Florian Roth (Nextron Systems)"
		id = "5ab9cd60-077c-5066-bd2f-8da261aae1e0"
		date = "2021-09-07"
		modified = "2023-12-05"
		reference = "https://www.anomali.com/blog/cybercrime-group-fin7-using-windows-11-alpha-themed-docs-to-drop-javascript-backdoor"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_fin7.yar#L303-L323"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "235ff8fe5c033fd90d77ecf9ce80b59be7bf6ae5a2863a1c9365d8b125a7ff3f"
		score = 65
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "=new RegExp(String.fromCharCode(" ascii
		$s2 = ".charCodeAt(" ascii
		$s3 = ".substr(0, " ascii
		$s4 = "var shell = new ActiveXObject(" ascii
		$s5 = "= new Date().getUTCMilliseconds();" ascii
		$s6 = ".deleteFile(WScript.ScriptFullName);" ascii

	condition:
		filesize < 6000KB and ( 4 of them )
}
rule SIGNATURE_BASE_APT_PY_Bluelight_Loader : INKYSQUID
{
	meta:
		description = "Python Loader used to execute the BLUELIGHT malware family."
		author = "threatintel@volexity.com"
		id = "f8da3e40-c3b0-5b7f-8ece-81874993d8cd"
		date = "2021-06-22"
		modified = "2023-12-05"
		reference = "https://www.volexity.com/blog/2021/08/24/north-korean-bluelight-special-inkysquid-deploys-rokrat/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_inkysquid.yar#L39-L58"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "80269413be6ad51b8b19631b2f5559c9572842e789bbce031babe6e879d2e120"
		logic_hash = "e7e18a6d648b1383706439ba923335ac4396f6b5d2a3dc8f30f63ded7df29eda"
		score = 75
		quality = 85
		tags = "INKYSQUID"
		license = "See license at https://github.com/volexity/threat-intel/LICENSE.txt"

	strings:
		$s1 = "\"\".join(chr(ord(" ascii
		$s2 = "import ctypes " ascii
		$s3 = "ctypes.CFUNCTYPE(ctypes.c_int)" ascii
		$s4 = "ctypes.memmove" ascii
		$s5 = "python ended" ascii

	condition:
		all of them
}
rule SIGNATURE_BASE_APT_MAL_Win_Decrok : INKYSQUID
{
	meta:
		description = "The DECROK malware family, which uses the victim's hostname to decrypt and execute an embedded payload."
		author = "threatintel@volexity.com"
		id = "dc83843d-fd2a-52f1-82e8-8e36b135a0c5"
		date = "2021-06-23"
		modified = "2023-12-05"
		reference = "https://www.volexity.com/blog/2021/08/24/north-korean-bluelight-special-inkysquid-deploys-rokrat/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_inkysquid.yar#L61-L82"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "6a452d088d60113f623b852f33f8f9acf0d4197af29781f889613fed38f57855"
		logic_hash = "47fa03e95ac17ba7195858cd63b1769e5d56ab8a5edf872b345989b767050b87"
		score = 75
		quality = 85
		tags = "INKYSQUID"
		license = "See license at https://github.com/volexity/threat-intel/LICENSE.txt"

	strings:
		$v1 = {C7 ?? ?? ?? 01 23 45 67 [2-20] C7 ?? ?? ?? 89 AB CD EF C7 ?? ?? ?? FE DC BA 98}
		$av1 = "Select * From AntiVirusProduct" wide
		$av2 = "root\\SecurityCenter2" wide
		$funcformat = { 25 30 32 78 [0-10] 43 72 65 61 74 65 54 68 72 65 61 64 }

	condition:
		all of them
}
rule SIGNATURE_BASE_APT_NK_Scarcruft_RUBY_Shellcode_XOR_Routine : APT
{
	meta:
		description = "Detects Ruby ShellCode XOR routine used by ScarCruft APT group"
		author = "S2WLAB_TALON_JACK2"
		id = "c393f2db-8ade-5083-9cec-f62f23056f8b"
		date = "2021-05-20"
		modified = "2023-12-05"
		reference = "https://medium.com/s2wlab/matryoshka-variant-of-rokrat-apt37-scarcruft-69774ea7bf48"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_inkysquid.yar#L104-L133"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a97041a06729d639c22a4ee272cc96555345b692fc0da8b62e898891d02b23ea"
		score = 75
		quality = 85
		tags = "APT"
		type = "APT"
		version = "0.1"

	strings:
		$hex1 = {C1 C7 0D 40 F6 C7 01 74 ?? 81 F7}
		$hex2 = {41 C1 C2 0D 41 8B C2 44 8B CA 41 8B CA 41 81 F2}

	condition:
		1 of them
}
rule SIGNATURE_BASE_APT_NK_Scarcruft_Evolved_ROKRAT : APT FILE
{
	meta:
		description = "Detects RokRAT malware used by ScarCruft APT group"
		author = "S2WLAB_TALON_JACK2"
		id = "53cabf41-0154-5372-b667-60d8a7cb9806"
		date = "2021-07-09"
		modified = "2023-12-05"
		reference = "https://medium.com/s2wlab/matryoshka-variant-of-rokrat-apt37-scarcruft-69774ea7bf48"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nk_inkysquid.yar#L135-L179"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "01a2f410687c943d6c6e421ffacfe42f9e7b6afb82e43ba03a8d525e075a3a3c"
		score = 75
		quality = 85
		tags = "APT, FILE"
		type = "APT"
		version = "0.1"

	strings:
		$AES_IV_KEY = {
        C7 44 24 ?? 32 31 12 23
        C7 44 24 ?? 34 45 56 67
        C7 44 24 ?? 78 89 9A AB
        C7 44 24 ?? 0C BD CE DF
        C7 45 ?? 2B 7E A5 16
        C7 45 ?? 28 AE D2 A6
        C7 45 ?? AB F7 15 88
        C7 45 ?? 09 CF 4F 3C
        }
		$url_deocde = {
               80 E9 0F
               80 F1 C8
               88 48 ??
               48 83 EA 01  }

	condition:
		uint16( 0 ) == 0x5A4D and any of them
}
rule SIGNATURE_BASE_APT_CN_Twistedpanda_Loader : FILE
{
	meta:
		description = "Detects loader used by TwistedPanda"
		author = "Check Point Research"
		id = "a10f6019-f069-579c-b112-18537a7d8fd8"
		date = "2022-04-14"
		modified = "2025-07-01"
		reference = "https://research.checkpoint.com/2022/twisted-panda-chinese-apt-espionage-operation-against-russians-state-owned-defense-institutes/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_twisted_panda.yar#L1-L44"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "5b558c5fcbed8544cb100bd3db3c04a70dca02eec6fedffd5e3dcecb0b04fba0"
		hash = "efa754450f199caae204ca387976e197d95cdc7e83641444c1a5a91b58ba6198"
		logic_hash = "b7f4f31a26b5f968b1d5c82d9165b4d45d75336993b113dda54fd37f628639ee"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$seq1 = { 6A 40 68 00 30 00 00 }
		$seq2 = { 6A 00 50 6A 14 8D ?? ?? ?? ?? ?? 50 53 FF }
		$seq3 = { 6A 00 6A 00 6A 03 6A 00 6A 03 68 00 00 00 80 }
		$decryption = { 8B C? [2-3] F6 D? 1A C? [4-6] 30 0? ?? 4? }

	condition:
		uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 and filesize < 3000KB and all of ( $seq* ) and $decryption
}
rule SIGNATURE_BASE_APT_CN_Twistedpanda_SPINNER_1 : FILE
{
	meta:
		description = "Detects the obfuscated variant of SPINNER payload used by TwistedPanda"
		author = "Check Point Research"
		id = "0b44013d-0caa-5ea2-ab08-e2a6a5732c03"
		date = "2022-04-14"
		modified = "2025-07-01"
		reference = "https://research.checkpoint.com/2022/twisted-panda-chinese-apt-espionage-operation-against-russians-state-owned-defense-institutes/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_twisted_panda.yar#L46-L80"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "a9fb7bb40de8508606a318866e0e5ff79b98f314e782f26c7044622939dfde81"
		logic_hash = "e7abe4b3f4225596131882a9175f9ac2e45ba00557950772a8e4d1eaeab97d05"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$config_init = { C7 ?? ?? ?? 00 00 00 C7 ?? ?? ?? 00 00 00 C6 }
		$c2_cmd_1 = { 01 00 03 10}
		$c2_cmd_2 = { 02 00 01 10}
		$c2_cmd_3 = { 01 00 01 10}
		$decryption = { 8D 83 [4] 80 B3 [5] 89 F1 6A 01 50 E8 [4] 80 B3 }

	condition:
		uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 and filesize < 3000KB and #config_init > 10 and 2 of ( $c2_cmd_* ) and $decryption
}
rule SIGNATURE_BASE_APT_CN_Twistedpanda_SPINNER_2 : FILE
{
	meta:
		description = "Detects an older variant of SPINNER payload used by TwistedPanda"
		author = "Check Point Research"
		id = "bbbf3af1-127f-5d32-967f-bdb94311d1d6"
		date = "2022-04-14"
		modified = "2025-07-01"
		reference = "https://research.checkpoint.com/2022/twisted-panda-chinese-apt-espionage-operation-against-russians-state-owned-defense-institutes/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_twisted_panda.yar#L82-L118"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "28ecd1127bac08759d018787484b1bd16213809a2cc414514dc1ea87eb4c5ab8"
		logic_hash = "d1e34903e58fb76671a076acbb9f26e10d511c8f00be90b4901d61b73b90a9a7"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$config_init = { C7 [3] 00 00 00 C7 [3] 00 00 00 C6 }
		$c2_cmd_1 = { 01 00 03 10 }
		$c2_cmd_2 = { 02 00 01 10 }
		$c2_cmd_3 = { 01 00 01 10 }
		$c2_cmd_4 = { 01 00 00 10 }
		$c2_cmd_5 = { 02 00 00 10 }
		$decryption = { 80 B3 [5] 8D BB [4] 8B 56 14 8B C2 8B 4E 10 2B C1 83 F8 01 }

	condition:
		uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 and filesize < 3000KB and #config_init > 10 and 2 of ( $c2_cmd_* ) and $decryption
}
rule SIGNATURE_BASE_APT_CN_Twistedpanda_64Bit_Loader : FILE
{
	meta:
		description = "Detects the 64bit Loader DLL used by TwistedPanda"
		author = "Check Point Research"
		id = "2172dd33-204b-5a05-ad26-534a0c1d7a17"
		date = "2022-04-14"
		modified = "2025-07-01"
		reference = "https://research.checkpoint.com/2022/twisted-panda-chinese-apt-espionage-operation-against-russians-state-owned-defense-institutes/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_twisted_panda.yar#L120-L155"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "e0d4ef7190ff50e6ad2a2403c87cc37254498e8cc5a3b2b8798983b1b3cdc94f"
		logic_hash = "644547f9fa6ca3f34ea32e06896f341e0c92f5c57dee3c478aed0cdf87b2f3de"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$path_check = { 48 8D [6] 48 8B ?? 48 81 [5] 72 }
		$shellcode_read = { 48 8B D0 41 B8 F0 16 00 00 48 8B CF 48 8B D8 FF}
		$shellcode_allocate = { BA F0 16 00 00 44 8D 4E 40 33 C9 41 B8 00 30 00 00 FF }

	condition:
		uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 and filesize < 3000KB and $path_check and $shellcode_allocate and $shellcode_read
}
rule SIGNATURE_BASE_APT_CN_Twistedpanda_Droppers : FILE
{
	meta:
		description = "Detects droppers used by TwistedPanda"
		author = "Check Point Research"
		id = "f61c8b97-5870-5837-942f-f1650870960a"
		date = "2022-04-14"
		modified = "2025-07-01"
		reference = "https://research.checkpoint.com/2022/twisted-panda-chinese-apt-espionage-operation-against-russians-state-owned-defense-institutes/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_cn_twisted_panda.yar#L157-L194"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "59dea38da6e515af45d6df68f8959601e2bbf0302e35b7989e741e9aba2f0291"
		hash = "8b04479fdf22892cdfebd6e6fbed180701e036806ed0ddbe79f0b29f73449248"
		hash = "f29a0cda6e56fc0e26efa3b6628c6bcaa0819a3275a10e9da2a8517778152d66"
		logic_hash = "820b4796511dcf98cdc8017a39cc2c65e44d8d9a20f55803aa1ddd36f649c83a"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$switch_control = { 81 FA [4] 75 ?? E8 [4] 48 89 05 [4] E? }
		$byte_manipulation = { 41 0F [2] 44 [2] 41 [2] 03 41 81 [5] 41 }
		$stack_strings_1 = { 25 00 70 00 }
		$stack_strings_2 = { 75 00 62 00 }
		$stack_strings_3 = { 6C 00 69 00 }
		$stack_strings_4 = { 63 00 25 00 }

	condition:
		uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 and filesize < 3000KB and #switch_control > 8 and all of ( $stack_strings_* ) and $byte_manipulation
}

rule SIGNATURE_BASE_SUSP_THOR_Unsigned_Oct23_1 : FILE
{
	meta:
		description = "Detects unsigned version of THOR scanner, which could be a backdoored / modified version of the scanner"
		author = "Florian Roth"
		id = "2ca6a192-675e-5f02-a7b1-40369eeb9904"
		date = "2023-10-28"
		modified = "2023-12-05"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_unsigned_thor.yar#L4-L22"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "12303e3549071dd6c8896f7a1222eb5905f6b4d3f320134416a5b6d53857adeb"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "THOR APT Scanner" wide fullword
		$s2 = "Nextron Systems GmbH" wide fullword
		$sc1 = { 00 4F 00 72 00 69 00 67 00 69 00 6E 00 61 00 6C 00 46 00 69 00 6C 00 65 00 6E 00 61 00 6D 00 65 00 00 00 74 00 68 00 6F 00 72 }

	condition:
		uint16( 0 ) == 0x5a4d and all of them and pe.number_of_signatures == 0
}
rule SIGNATURE_BASE_SUSP_LNX_ARCH_Install_Hook_Jun26 : FILE
{
	meta:
		description = "Detects suspicious pre and post hooks in Arch install files"
		author = "Marius Benthin"
		id = "fbe3599b-525b-432e-af8f-53779b02a171"
		date = "2026-06-15"
		modified = "2026-10-29"
		reference = "https://aur.archlinux.org/cgit/aur.git/commit/?h=python-django-js-asset&id=af09b1cf1b59"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/susp_aur_packages.yar#L45-L73"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "47c076099e6715ffb0bd357b6832175741e77b88972033cd1f9b55b6ff7e5519"
		hash = "ef735bca8cb2acafe70831e33ed468a3046a61147af694000761970415c7eef1"
		logic_hash = "b9850b02ef5df3834c072d267d3449617e28f71ec9120a9e64f24d46e57b9a0f"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$sa1 = "pre_install() {"
		$sa2 = "post_install() {"
		$sa3 = "pre_upgrade() {"
		$sa4 = "post_upgrade() {"
		$sa5 = "pre_remove() {"
		$sa6 = "post_remove() {"
		$sb1 = "npm install "
		$sb2 = "&& 'b''u''n'"
		$fp1 = "#!/bin/sh"

	condition:
		filesize < 5KB and 1 of ( $sa* ) and 1 of ( $sb* ) and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_SUSP_LNX_ARCH_ALPM_Hook_Jun26 : FILE
{
	meta:
		description = "Detects suspicious execution commands in Arch ALPM hooks"
		author = "Marius Benthin"
		id = "6598c5ca-8f2c-44f8-bf1f-54e82b06f59c"
		date = "2026-06-15"
		modified = "2026-10-29"
		reference = "https://aur.archlinux.org/cgit/aur.git/commit/?h=hearthstone-linux-gui-bin&id=ecf810ac853e7149abd4e0c793b2517e9737edb8"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/susp_aur_packages.yar#L75-L92"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "ba332432f87e68d7fa8c784c60c39ba0d3e2ac06fd8855e82ea49329e2684529"
		logic_hash = "b588d68867424799dcc7fd47d1fa3d3a89475290344a0b26e2ebca43e91076a7"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "[Action]"
		$s2 = "Exec = "
		$s3 = "npm install "
		$s4 = "2>/dev/null"

	condition:
		filesize < 5KB and all of them
}
rule SIGNATURE_BASE_WEBSHELL_JSP_Nov21_1 : FILE
{
	meta:
		description = "Detects JSP webshells"
		author = "Florian Roth (Nextron Systems)"
		id = "117eed28-c44e-5983-b4c7-b555fc06d923"
		date = "2021-11-23"
		modified = "2023-12-05"
		reference = "https://www.ic3.gov/Media/News/2021/211117-2.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_spring4shell.yar#L2-L17"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1dac7706421961c71ba6f8d7a223b80e4b77bf206bfb64ee18c7cc894b062a3c"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "request.getParameter(\"pwd\")" ascii
		$x2 = "excuteCmd(request.getParameter(" ascii
		$x3 = "getRuntime().exec (request.getParameter(" ascii
		$x4 = "private static final String PW = \"whoami\"" ascii

	condition:
		filesize < 400KB and 1 of them
}
rule SIGNATURE_BASE_EXPL_POC_Springcore_0Day_Indicators_Mar22_1
{
	meta:
		description = "Detects indicators found after SpringCore exploitation attempts and in the POC script"
		author = "Florian Roth (Nextron Systems)"
		id = "297e4b57-f831-56e0-a391-1ffbc9a4d438"
		date = "2022-03-30"
		modified = "2023-12-05"
		reference = "https://twitter.com/vxunderground/status/1509170582469943303"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_spring4shell.yar#L19-L34"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "39fb62ec7953dae0a88e39e73e3ff286fc19cb8f21f8feb869a1875f6ba70cfb"
		score = 70
		quality = 85
		tags = ""

	strings:
		$x1 = "java.io.InputStream%20in%20%3D%20%25%7Bc1%7Di"
		$x2 = "?pwd=j&cmd=whoami"
		$x3 = ".getParameter(%22pwd%22)"
		$x4 = "class.module.classLoader.resources.context.parent.pipeline.first.pattern=%25%7B"

	condition:
		1 of them
}
rule SIGNATURE_BASE_EXPL_POC_Springcore_0Day_Webshell_Mar22_1 : FILE
{
	meta:
		description = "Detects webshell found after SpringCore exploitation attempts POC script"
		author = "Florian Roth (Nextron Systems)"
		id = "e7047c98-3c60-5211-9ad5-2bfdfb35d493"
		date = "2022-03-30"
		modified = "2023-12-05"
		reference = "https://twitter.com/vxunderground/status/1509170582469943303"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_spring4shell.yar#L36-L50"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "17282b66899356a6051f0b47a7a3f02265737283d760f2256e03a2b934bb63b8"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$x1 = ".getInputStream(); int a = -1; byte[] b = new byte[2048];"
		$x2 = "if(\"j\".equals(request.getParameter(\"pwd\")"
		$x3 = ".getRuntime().exec(request.getParameter(\"cmd\")).getInputStream();"

	condition:
		filesize < 200KB and 1 of them
}
rule SIGNATURE_BASE_HKTL_Meterpreter_Inmemory
{
	meta:
		description = "Detects Meterpreter in-memory"
		author = "netbiosX, Florian Roth"
		id = "29c3bb7e-4da8-5924-ada7-2f28d9352009"
		date = "2020-06-29"
		modified = "2023-04-21"
		reference = "https://www.reddit.com/r/purpleteamsec/comments/hjux11/meterpreter_memory_indicators_detection_tooling/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_metasploit_payloads.yar#L341-L363"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4b39dbcb276842a1306205cf2e51ce86b6d2aa21353d277df15f4ea3b3d97678"
		score = 85
		quality = 85
		tags = ""

	strings:
		$sxc1 = { 6D 65 74 73 72 76 2E 64 6C 6C 00 00 52 65 66 6C 
               65 63 74 69 76 65 4C 6F 61 64 65 72 }
		$sxs1 = "metsrv.x64.dll" ascii fullword
		$ss1 = "WS2_32.dll" ascii fullword
		$ss2 = "ReflectiveLoader" ascii fullword
		$fp1 = "SentinelOne" ascii wide
		$fp2 = "fortiESNAC" ascii wide
		$fp3 = "PSNMVHookMS" ascii wide

	condition:
		(1 of ( $sx* ) or 2 of ( $s* ) ) and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_MAL_RANSOM_Darkside_May21_1 : FILE
{
	meta:
		description = "Detects Darkside Ransomware"
		author = "Florian Roth (Nextron Systems)"
		id = "e5592065-591e-597b-bebb-f20bc306fe52"
		date = "2021-05-10"
		modified = "2023-12-05"
		reference = "https://app.any.run/tasks/020c1740-717a-4191-8917-5819aa25f385/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_ransom_darkside.yar#L2-L23"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "ec368752c2cf3b23efbfa5705f9e582fc9d6766435a7b8eea8ef045082c6fbce"
		logic_hash = "84de92b0b36e373aa61e314a04597bd0578a04af34c501ae9071e5f4fa27c07a"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$op1 = { 85 c9 75 ed ff 75 10 ff b5 d8 fe ff ff ff b5 dc fe ff ff e8 7d fc ff ff ff 8d cc fe ff ff 8b 8d cc fe ff ff }
		$op2 = { 66 0f 6f 06 66 0f 7f 07 83 c6 10 83 c7 10 49 85 c9 75 ed 5f }
		$op3 = { 6a 00 ff 15 72 0d 41 00 ab 46 81 fe 80 00 00 00 75 2e 6a ff 6a 01 }
		$op4 = { 0f b7 0c 5d 88 0f 41 00 03 4c 24 04 89 4c 24 04 83 e1 3f 0f b7 14 4d 88 0f 41 00 03 54 24 08 89 54 24 08 83 e2 3f }
		$s1 = "http://darksid" ascii
		$s2 = "[ Welcome to DarkSide ]" ascii
		$s3 = ".onion/" ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 200KB and 3 of them or all of ( $op* ) or all of ( $s* )
}
rule SIGNATURE_BASE_MAL_Ransomware_Win_DARKSIDE_V1_1 : FILE
{
	meta:
		description = "Detection for early versions of DARKSIDE ransomware samples based on the encryption mode configuration values."
		author = "FireEye"
		id = "322a3de5-a7e5-52b9-8648-6019954e92d7"
		date = "2021-03-22"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2021/05/shining-a-light-on-darkside-ransomware-operations.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_ransom_darkside.yar#L25-L37"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "1a700f845849e573ab3148daef1a3b0b"
		logic_hash = "b3612510bd1f2ca7543e217e97037b02d312bcda2b2df16d9be3216749ea4beb"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$consts = { 80 3D [4] 01 [1-10] 03 00 00 00 [1-10] 03 00 00 00 [1-10] 00 00 04 00 [1-10] 00 00 00 00 [1-30] 80 3D [4] 02 [1-10] 03 00 00 00 [1-10] 03 00 00 00 [1-10] FF FF FF FF [1-10] FF FF FF FF [1-30] 03 00 00 00 [1-10] 03 00 00 00 }

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and $consts
}
rule SIGNATURE_BASE_MAL_Dropper_Win_Darkside_1 : FILE
{
	meta:
		description = "Detection for on the binary that was used as the dropper leading to DARKSIDE."
		author = "FireEye"
		id = "910a581c-25a4-5d5e-acdc-6d87cbedd3cf"
		date = "2021-05-10"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2021/05/shining-a-light-on-darkside-ransomware-operations.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_ransom_darkside.yar#L39-L56"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "131b3666ae444e0de043eafdf7cfd3324b927d18d8ad56d5004ea09b2da5610e"
		score = 75
		quality = 79
		tags = "FILE"
		date_created = "2021-05-11"

	strings:
		$CommonDLLs1 = "KERNEL32.dll" fullword
		$CommonDLLs2 = "USER32.dll" fullword
		$CommonDLLs3 = "ADVAPI32.dll" fullword
		$CommonDLLs4 = "ole32.dll" fullword
		$KeyString1 = { 74 79 70 65 3D 22 77 69 6E 33 32 22 20 6E 61 6D 65 3D 22 4D 69 63 72 6F 73 6F 66 74 2E 57 69 6E 64 6F 77 73 2E 43 6F 6D 6D 6F 6E 2D 43 6F 6E 74 72 6F 6C 73 22 20 76 65 72 73 69 6F 6E 3D 22 36 2E 30 2E 30 2E 30 22 20 70 72 6F 63 65 73 73 6F 72 41 72 63 68 69 74 65 63 74 75 72 65 3D 22 78 38 36 22 20 70 75 62 6C 69 63 4B 65 79 54 6F 6B 65 6E 3D 22 36 35 39 35 62 36 34 31 34 34 63 63 66 31 64 66 22 }
		$KeyString2 = { 74 79 70 65 3D 22 77 69 6E 33 32 22 20 6E 61 6D 65 3D 22 4D 69 63 72 6F 73 6F 66 74 2E 56 43 39 30 2E 4D 46 43 22 20 76 65 72 73 69 6F 6E 3D 22 39 2E 30 2E 32 31 30 32 32 2E 38 22 20 70 72 6F 63 65 73 73 6F 72 41 72 63 68 69 74 65 63 74 75 72 65 3D 22 78 38 36 22 20 70 75 62 6C 69 63 4B 65 79 54 6F 6B 65 6E 3D 22 31 66 63 38 62 33 62 39 61 31 65 31 38 65 33 62 22 }
		$Slashes = { 7C 7C 7C 7C 7C 7C 7C 7C 7C 7C 7C 7C 7C 7C 7C 7C 7C 7C 7C 7C }

	condition:
		filesize < 2MB and filesize > 500KB and uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 and ( all of ( $CommonDLLs* ) ) and ( all of ( $KeyString* ) ) and $Slashes
}
rule SIGNATURE_BASE_MAL_Backdoor_Win_C3_1 : FILE
{
	meta:
		description = "Detection to identify the Custom Command and Control (C3) binaries."
		author = "FireEye"
		id = "60eb022e-6f4e-5c7d-9ddf-b458a593071e"
		date = "2021-05-10"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2021/05/shining-a-light-on-darkside-ransomware-operations.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_ransom_darkside.yar#L58-L77"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "7cdac4b82a7573ae825e5edb48f80be5"
		logic_hash = "369c54b9426edb449004466d30e1010ecefe8cfbea106306eb8eb90b27610dbf"
		score = 75
		quality = 79
		tags = "FILE"
		date_created = "2021-05-11"

	strings:
		$dropboxAPI = "Dropbox-API-Arg"
		$knownDLLs1 = "WINHTTP.dll" fullword
		$knownDLLs2 = "SHLWAPI.dll" fullword
		$knownDLLs3 = "NETAPI32.dll" fullword
		$knownDLLs4 = "ODBC32.dll" fullword
		$tokenString1 = { 5B 78 5D 20 65 72 72 6F 72 20 73 65 74 74 69 6E 67 20 74 6F 6B 65 6E }
		$tokenString2 = { 5B 78 5D 20 65 72 72 6F 72 20 63 72 65 61 74 69 6E 67 20 54 6F 6B 65 6E }
		$tokenString3 = { 5B 78 5D 20 65 72 72 6F 72 20 64 75 70 6C 69 63 61 74 69 6E 67 20 74 6F 6B 65 6E }

	condition:
		filesize < 5MB and uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 and ( ( ( all of ( $knownDLLs* ) ) and ( $dropboxAPI or ( 1 of ( $tokenString* ) ) ) ) or ( all of ( $tokenString* ) ) )
}
rule SIGNATURE_BASE_APT_MAL_HP_Ilo_Firmware_Dec21_1 : FILE
{
	meta:
		description = "Detects suspicios ELF files with sections as described in malicious iLO Board analysis by AmnPardaz in December 2021"
		author = "Florian Roth (Nextron Systems)"
		id = "7f5fa905-07a3-55da-b644-c5ab882b4a9d"
		date = "2021-12-28"
		modified = "2023-12-05"
		reference = "https://threats.amnpardaz.com/en/2021/12/28/implant-arm-ilobleed-a/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_mal_ilo_board_elf.yar#L2-L18"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7e959d07d864a485b8cc7765f9e12869ff34747ab552e26244eb28f510d1051f"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = ".newelf.elf.text" ascii
		$s2 = ".newelf.elf.libc.so.data" ascii
		$s3 = ".newelf.elf.Initial.stack" ascii
		$s4 = ".newelf.elf.libevlog.so.data" ascii

	condition:
		filesize < 5MB and 2 of them or all of them
}
rule SIGNATURE_BASE_Mimikatz : FILE
{
	meta:
		description = "mimikatz"
		author = "Benjamin DELPY (gentilkiwi)"
		id = "840a5b8c-a311-50bc-a099-6b8ab1492e12"
		date = "2020-08-10"
		modified = "2022-11-16"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mimikatz.yar#L48-L74"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "bf972a2c0465c3bbdde6f03d91c6f479d0f66c6d3e9512355de5a973164b56a5"
		score = 75
		quality = 85
		tags = "FILE"
		tool_author = "Benjamin DELPY (gentilkiwi)"

	strings:
		$exe_x86_1 = { 89 71 04 89 [0-3] 30 8d 04 bd }
		$exe_x86_2 = { 8b 4d e? 8b 45 f4 89 75 e? 89 01 85 ff 74 }
		$exe_x64_1 = { 33 ff 4? 89 37 4? 8b f3 45 85 c? 74}
		$exe_x64_2 = { 4c 8b df 49 [0-3] c1 e3 04 48 [0-3] 8b cb 4c 03 [0-3] d8 }
		$sys_x86 = { a0 00 00 00 24 02 00 00 40 00 00 00 [0-4] b8 00 00 00 6c 02 00 00 40 00 00 00 }
		$sys_x64 = { 88 01 00 00 3c 04 00 00 40 00 00 00 [0-4] e8 02 00 00 f8 02 00 00 40 00 00 00 }

	condition:
		( all of ( $exe_x86_* ) ) or ( all of ( $exe_x64_* ) ) or ( any of ( $sys_* ) )
}
rule SIGNATURE_BASE_Wce
{
	meta:
		description = "wce"
		author = "Benjamin DELPY (gentilkiwi)"
		id = "857981ee-3f57-580b-8bfd-8d2109298e27"
		date = "2020-08-10"
		modified = "2023-12-05"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mimikatz.yar#L76-L89"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a16db99dcaaf1b6c33a738aab4f4d3812366258bc2f6dd32250ee1b1a0616f1c"
		score = 75
		quality = 85
		tags = ""
		tool_author = "Hernan Ochoa (hernano)"

	strings:
		$hex_legacy = { 8b ff 55 8b ec 6a 00 ff 75 0c ff 75 08 e8 [0-3] 5d c2 08 00 }
		$hex_x86 = { 8d 45 f0 50 8d 45 f8 50 8d 45 e8 50 6a 00 8d 45 fc 50 [0-8] 50 72 69 6d 61 72 79 00 }
		$hex_x64 = { ff f3 48 83 ec 30 48 8b d9 48 8d 15 [0-16] 50 72 69 6d 61 72 79 00 }

	condition:
		any of them
}
rule SIGNATURE_BASE_Power_Pe_Injection
{
	meta:
		description = "PowerShell with PE Reflective Injection"
		author = "Benjamin DELPY (gentilkiwi)"
		id = "a71fe9f2-9c2a-5650-a5c7-116b76f10db6"
		date = "2020-08-10"
		modified = "2023-12-05"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mimikatz.yar#L91-L101"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "64a7033d51e8933912f37ce68bffc216073a88cae1ea7492e71a812411ae6a9d"
		score = 75
		quality = 85
		tags = ""

	strings:
		$str_loadlib = "0x53, 0x48, 0x89, 0xe3, 0x48, 0x83, 0xec, 0x20, 0x66, 0x83, 0xe4, 0xc0, 0x48, 0xb9"

	condition:
		$str_loadlib
}
rule SIGNATURE_BASE_HKTL_Mimikatz_Skeletonkey_In_Memory_Aug20_1
{
	meta:
		description = "Detects Mimikatz SkeletonKey in Memory"
		author = "Florian Roth (Nextron Systems)"
		id = "e7c1c512-e944-5d87-ac57-cdc9ab7cf660"
		date = "2020-08-09"
		modified = "2023-12-05"
		reference = "https://twitter.com/sbousseaden/status/1292143504131600384?s=12"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mimikatz.yar#L178-L190"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "0cc9a4d3b63e07a695df342bd2c96a55570502d6fd0ab9a1b61d63e28e1c3e05"
		score = 75
		quality = 85
		tags = ""

	strings:
		$x1 = { 60 ba 4f ca c7 44 24 34 dc 46 6c 7a c7 44 24 38 
              03 3c 17 81 c7 44 24 3c 94 c0 3d f6 }

	condition:
		1 of them
}
rule SIGNATURE_BASE_HKTL_Mimikatz_Memssp_Hookfn
{
	meta:
		description = "Detects Default Mimikatz memssp module in-memory"
		author = "SBousseaden"
		id = "89940110-8a5e-5a28-bf64-3b568f8ef1f8"
		date = "2020-08-26"
		modified = "2023-12-05"
		reference = "https://github.com/sbousseaden/YaraHunts/blob/master/mimikatz_memssp_hookfn.yara"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_mimikatz.yar#L192-L216"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "27cf87f801111f17af76ab4c4f8329b73165f24f755d33edbb22d845bba6d3ff"
		score = 70
		quality = 85
		tags = ""

	strings:
		$xc1 = { 48 81 EC A8 00 00 00 C7 84 24 88 00 00 00 ?? ?? 
               ?? ?? C7 84 24 8C 00 00 00 ?? ?? ?? ?? C7 84 24 
               90 00 00 00 ?? ?? ?? 00 C7 84 24 80 00 00 00 61 
               00 00 00 C7 44 24 40 5B 00 25 00 C7 44 24 44 30 
               00 38 00 C7 44 24 48 78 00 3A 00 C7 44 24 4C 25 
               00 30 00 C7 44 24 50 38 00 78 00 C7 44 24 54 5D 
               00 20 00 C7 44 24 58 25 00 77 00 C7 44 24 5C 5A 
               00 5C 00 C7 44 24 60 25 00 77 00 C7 44 24 64 5A 
               00 09 00 C7 44 24 68 25 00 77 00 C7 44 24 6C 5A 
               00 0A 00 C7 44 24 70 00 00 00 00 48 8D 94 24 80 
               00 00 00 48 8D 8C 24 88 00 00 00 48 B8 A0 7D ?? 
               ?? ?? ?? 00 00 FF D0 }

	condition:
		$xc1
}
rule SIGNATURE_BASE_APT_Crywiper_Dec22
{
	meta:
		description = "Detects CryWiper malware samples"
		author = "Florian Roth (Nextron Systems)"
		id = "d56ccf4e-30ba-5308-ad68-ffc2ae5a1718"
		date = "2022-12-05"
		modified = "2023-12-05"
		reference = "https://securelist-ru.translate.goog/novyj-troyanec-crywiper/106114/?_x_tr_sl=auto&_x_tr_tl=en&_x_tr_hl=en"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_ru_crywiper.yar#L2-L19"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "7c22e02ed996cd820ed87a0c5d50e3264629cdd887aad4ea466cadeccaee2b2f"
		score = 75
		quality = 85
		tags = ""

	strings:
		$x1 = "Software\\Sysinternals\\BrowserUpdate"
		$sx1 = "taskkill.exe /f /im MSExchange*"
		$s1 = "SYSTEM\\CurrentControlSet\\Control\\Terminal Server" ascii
		$s2 = "fDenyTSConnections" ascii

	condition:
		1 of ( $x* ) or all of ( $s* )
}
rule SIGNATURE_BASE_FE_Webshell_PL_ATRIUM_1
{
	meta:
		description = "Detects samples mentioned in PulseSecure report"
		author = "Mandiant"
		id = "b2663343-0bae-5215-a443-866ab8626bff"
		date = "2021-04-16"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2021/04/suspected-apt-actors-leverage-bypass-techniques-pulse-secure-zero-day.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_pulsesecure.yar#L12-L27"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "ca0175d86049fa7c796ea06b413857a3"
		logic_hash = "869b397616495c644beb997602eac84ddcdbacce4c14755c555f5bda36663ca2"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "CGI::param("
		$s2 = "system("
		$s3 = /if[\x09\x20]{0,32}\(CGI::param\([\x22\x27]\w{1,64}[\x22\x27]\)\)\s{0,128}\{[\x09\x20]{0,32}print [\x22\x27]Cache-Control: no-cache\\n[\x22\x27][\x09\x20]{0,32};\s{0,128}print [\x22\x27]Content-type: text\/html\\n\\n[\x22\x27][\x09\x20]{0,32};\s{0,128}my \$\w{1,64}[\x09\x20]{0,32}=[\x09\x20]{0,32}CGI::param\([\x22\x27]\w{1,64}[\x22\x27]\)[\x09\x20]{0,32};\s{0,128}system\([\x22\x27]\$/

	condition:
		all of them
}
rule SIGNATURE_BASE_FE_APT_Webshell_PL_HARDPULSE
{
	meta:
		description = "Detects samples mentioned in PulseSecure report"
		author = "Mandiant"
		id = "f9a2922e-6b8e-5f92-a947-3215ee8883ac"
		date = "2021-04-16"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2021/04/suspected-apt-actors-leverage-bypass-techniques-pulse-secure-zero-day.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_pulsesecure.yar#L46-L65"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "980cba9e82faf194edb6f3cc20dc73ff"
		logic_hash = "37fc40fd998d3294edb05707170bc2deec524fc6451bff212901f9ac3e34bb35"
		score = 75
		quality = 83
		tags = ""

	strings:
		$r1 = /if[\x09\x20]{0,32}\(\$\w{1,64}[\x09\x20]{1,32}eq[\x09\x20]{1,32}[\x22\x27]\w{1,64}[\x22\x27]\)\s{0,128}\{\s{1,128}my[\x09\x20]{1,32}\$\w{1,64}[\x09\x20]{0,32}\x3b\s{1,128}unless[\x09\x20]{0,32}\(open\(\$\w{1,64},[\x09\x20]{0,32}\$\w{1,64}\)\)\s{0,128}\{\s{1,128}goto[\x09\x20]{1,32}\w{1,64}[\x09\x20]{0,32}\x3b\s{1,128}return[\x09\x20]{1,32}0[\x09\x20]{0,32}\x3b\s{0,128}\}/
		$r2 = /open[\x09\x20]{0,32}\(\*\w{1,64}[\x09\x20]{0,32},[\x09\x20]{0,32}[\x22\x27]>/
		$r3 = /if[\x09\x20]{0,32}\(\$\w{1,64}[\x09\x20]{1,32}eq[\x09\x20]{1,32}[\x22\x27]\w{1,64}[\x22\x27]\)\s{0,128}\{\s{1,128}print[\x09\x20]{0,32}[\x22\x27]Content-type/
		$s1 = "CGI::request_method()"
		$s2 = "CGI::param("
		$s3 = "syswrite("
		$s4 = "print $_"

	condition:
		all of them
}
rule SIGNATURE_BASE_FE_APT_Trojan_Linux32_LOCKPICK_1 : FILE
{
	meta:
		description = "Detects samples mentioned in PulseSecure report"
		author = "Mandiant"
		id = "00c09378-25a0-55f1-8d93-7b22d98bd8c2"
		date = "2021-04-16"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2021/04/suspected-apt-actors-leverage-bypass-techniques-pulse-secure-zero-day.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_pulsesecure.yar#L66-L80"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "e8bfd3f5a2806104316902bbe1195ee8"
		logic_hash = "1623c2dc63fe7d595069a024b715bbca267ec1c9400afcadc377ae58afb81a2a"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$sb1 = { 83 ?? 63 0F 84 [4] 8B 45 ?? 83 ?? 01 89 ?? 24 89 44 24 04 E8 [4] 85 C0 }
		$sb2 = { 83 [2] 63 74 ?? 89 ?? 24 04 89 ?? 24 E8 [4] 83 [2] 01 85 C0 0F [5] EB 00 8B ?? 04 83 F8 02 7? ?? 83 E8 01 C1 E0 02 83 C0 00 89 44 24 08 8D 83 [4] 89 44 24 04 8B ?? 89 04 24 E8 }

	condition:
		(( uint32( 0 ) == 0x464c457f ) and ( uint8( 4 ) == 1 ) ) and ( @sb1 [ 1 ] < @sb2 [ 1 ] )
}
rule SIGNATURE_BASE_FE_APT_Trojan_Linux32_PACEMAKER : FILE
{
	meta:
		description = "Detects samples mentioned in PulseSecure report"
		author = "Mandiant"
		id = "459e26f1-4ea9-56dd-ad71-0ed2c7499aea"
		date = "2021-04-16"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2021/04/suspected-apt-actors-leverage-bypass-techniques-pulse-secure-zero-day.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_pulsesecure.yar#L81-L98"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "d7881c4de4d57828f7e1cab15687274b"
		logic_hash = "f3f89744ce558179f36da3b412ba4afb3798684e6d976ef59de565b5a3323ad6"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "\x00/proc/%d/mem\x00"
		$s2 = "\x00/proc/%s/maps\x00"
		$s3 = "\x00/proc/%s/cmdline\x00"
		$sb1 = { C7 44 24 08 10 00 00 00 C7 44 24 04 00 00 00 00 8D 45 E0 89 04 24 E8 [4] 8B 45 F4 83 C0 0B C7 44 24 08 10 00 00 00 89 44 24 04 8D 45 E0 89 04 24 E8 [4] 8D 45 E0 89 04 24 E8 [4] 85 C0 74 ?? 8D 45 E0 89 04 24 E8 [4] 85 C0 74 ?? 8D 45 E0 89 04 24 E8 [4] EB }
		$sb2 = { 8B 95 [4] B8 [4] 8D 8D [4] 89 4C 24 10 8D 8D [4] 89 4C 24 0C 89 54 24 08 89 44 24 04 8D 85 [4] 89 04 24 E8 [4] C7 44 24 08 02 00 00 00 C7 44 24 04 00 00 00 00 8B 45 ?? 89 04 24 E8 [4] 89 45 ?? 8D 85 [4] 89 04 24 E8 [4] 89 44 24 08 8D 85 [4] 89 44 24 04 8B 45 ?? 89 04 24 E8 [4] 8B 45 ?? 89 45 ?? C7 45 ?? 00 00 00 00 [0-16] 83 45 ?? 01 8B 45 ?? 3B 45 0C }

	condition:
		(( uint32( 0 ) == 0x464c457f ) and ( uint8( 4 ) == 1 ) ) and all of them
}
rule SIGNATURE_BASE_FE_APT_Trojan_Linux_PACEMAKER : FILE
{
	meta:
		description = "Detects samples mentioned in PulseSecure report"
		author = "Mandiant"
		id = "5a20260a-5389-57da-956c-97063fed5015"
		date = "2021-04-16"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2021/04/suspected-apt-actors-leverage-bypass-techniques-pulse-secure-zero-day.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_pulsesecure.yar#L99-L115"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "d7881c4de4d57828f7e1cab15687274b"
		logic_hash = "cf83024cbbd500a301ac3c859b680cd79acabc232ea6f42c23fe9f8918a8d914"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "\x00Name:%s || Pwd:%s || AuthNum:%s\x0a\x00"
		$s2 = "\x00/proc/%d/mem\x00"
		$s3 = "\x00/proc/%s/maps\x00"
		$s4 = "\x00/proc/%s/cmdline\x00"

	condition:
		( uint32( 0 ) == 0x464c457f ) and all of them
}
rule SIGNATURE_BASE_FE_APT_Webshell_PL_PULSECHECK_1
{
	meta:
		description = "Detects samples mentioned in PulseSecure report"
		author = "Mandiant"
		id = "f375fdd8-567b-569b-85f4-af54a35d2a93"
		date = "2021-04-16"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2021/04/suspected-apt-actors-leverage-bypass-techniques-pulse-secure-zero-day.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_pulsesecure.yar#L116-L136"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "a1dcdf62aafc36dd8cf64774dea80d79fb4e24ba2a82adf4d944d9186acd1cc1"
		logic_hash = "aba457dd33232ef37ca145c5b7cd9c5fe809730339a55c5e90ac46b4a136f6cb"
		score = 75
		quality = 85
		tags = ""

	strings:
		$r1 = /while[\x09\x20]{0,32}\(<\w{1,64}>\)[\x09\x20]{0,32}\{\s{1,256}\$\w{1,64}[\x09\x20]{0,32}\.=[\x09\x20]{0,32}\$_;\s{0,256}\}/
		$s1 = "use Crypt::RC4;"
		$s2 = "use MIME::Base64"
		$s3 = "MIME::Base64::decode("
		$s4 = "popen("
		$s5 = " .= $_;"
		$s6 = "print MIME::Base64::encode(RC4("
		$s7 = "HTTP_X_"

	condition:
		$s1 and $s2 and ( @s3 [ 1 ] < @s4 [ 1 ] ) and ( @s4 [ 1 ] < @s5 [ 1 ] ) and ( @s5 [ 1 ] < @s6 [ 1 ] ) and ( #s7 > 2 ) and $r1
}
rule SIGNATURE_BASE_FE_APT_Trojan_PL_PULSEJUMP_1
{
	meta:
		description = "Detects samples mentioned in PulseSecure report"
		author = "Mandiant"
		id = "690cc347-e60f-5cac-b65d-367ecee69251"
		date = "2021-04-16"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2021/04/suspected-apt-actors-leverage-bypass-techniques-pulse-secure-zero-day.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_pulsesecure.yar#L137-L153"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "91ee23ee24e100ba4a943bb4c15adb4c"
		logic_hash = "c9aa2b9ef8aff14c20ed6597b1a71eafc3e3c181aabf9a3a68df18945207ff86"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "open("
		$s2 = ">>/tmp/"
		$s3 = "syswrite("
		$s4 = /\}[\x09\x20]{0,32}elsif[\x09\x20]{0,32}\([\x09\x20]{0,32}\$\w{1,64}[\x09\x20]{1,32}eq[\x09\x20]{1,32}[\x22\x27](Radius|Samba|AD)[\x22\x27][\x09\x20]{0,32}\)\s{0,128}\{\s{0,128}@\w{1,64}[\x09\x20]{0,32}=[\x09\x20]{0,32}&/

	condition:
		all of them
}
rule SIGNATURE_BASE_FE_APT_Trojan_PL_RADIALPULSE_1
{
	meta:
		description = "Detects samples mentioned in PulseSecure report"
		author = "Mandiant"
		id = "1fab6d2f-96e8-5def-a93e-2bddd04e7ec8"
		date = "2021-04-16"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2021/04/suspected-apt-actors-leverage-bypass-techniques-pulse-secure-zero-day.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_pulsesecure.yar#L173-L190"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "d72daafedf41d484f7f9816f7f076a9249a6808f1899649b7daa22c0447bb37b"
		logic_hash = "d65a466cc15214d8e26597588c039a6b9fb4637ef8f3b1ebea27f016fbd5cba8"
		score = 75
		quality = 83
		tags = ""

	strings:
		$s1 = "->getRealmInfo()->{name}"
		$s2 = /open\(\*fd,[\x09\x20]{0,32}[\x22\x27]>>/
		$s3 = /syswrite\(\*fd,[\x09\x20]{0,32}[\x22\x27]realm=\$/
		$s4 = /syswrite\(\*fd,[\x09\x20]{0,32}[\x22\x27]username=\$/
		$s5 = /syswrite\(\*fd,[\x09\x20]{0,32}[\x22\x27]password=\$/

	condition:
		(@s1 [ 1 ] < @s2 [ 1 ] ) and ( @s2 [ 1 ] < @s3 [ 1 ] ) and $s4 and $s5
}
rule SIGNATURE_BASE_FE_APT_Trojan_PL_RADIALPULSE_2
{
	meta:
		description = "Detects samples mentioned in PulseSecure report"
		author = "Mandiant"
		id = "dc941935-aec7-54b6-a278-f1453b9785df"
		date = "2021-04-16"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2021/04/suspected-apt-actors-leverage-bypass-techniques-pulse-secure-zero-day.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_pulsesecure.yar#L191-L208"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "4a2a7cbc1c8855199a27a7a7b51d0117"
		logic_hash = "4ade993176c918ec23e99fc585e9ab14d9f9e93a7eca00f2c3b0ebbd13d6ec5b"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "open(*fd,"
		$s2 = "syswrite(*fd,"
		$s3 = "close(*fd);"
		$s4 = /open\(\*fd,[\x09\x20]{0,32}[\x22\x27]>>\/tmp\/[\w.]{1,128}[\x22\x27]\);[\x09\x20]{0,32}syswrite\(\*fd,[\x09\x20]{0,32}/
		$s5 = /syswrite\(\*fd,[\x09\x20]{0,32}[\x22\x27][\w]{1,128}=\$\w{1,128} ?[\x22\x27],[\x09\x20]{0,32}5000\)/

	condition:
		all of them
}
rule SIGNATURE_BASE_FE_APT_Trojan_PL_RADIALPULSE_3
{
	meta:
		description = "Detects samples mentioned in PulseSecure report"
		author = "Mandiant"
		id = "8a597521-c873-5bcc-85e6-5a0a061fffb7"
		date = "2021-04-16"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2021/04/suspected-apt-actors-leverage-bypass-techniques-pulse-secure-zero-day.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_pulsesecure.yar#L209-L226"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "4a2a7cbc1c8855199a27a7a7b51d0117"
		logic_hash = "025308591e058de284f949fd4f788e4a4f46bb2f6c0e1161237f1f811d8179ba"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "open(*fd,"
		$s2 = "syswrite(*fd,"
		$s3 = "close(*fd);"
		$s4 = /open\(\*fd,[\x09\x20]{0,32}[\x22\x27]>>\/tmp\/dsstartssh\.statementcounters[\x22\x27]\);[\x09\x20]{0,32}syswrite\(\*fd,[\x09\x20]{0,32}/
		$s5 = /syswrite\(\*fd,[\x09\x20]{0,32}[\x22\x27][\w]{1,128}=\$username ?[\x22\x27],[\x09\x20]{0,32}\d{4}\)/

	condition:
		all of them
}
rule SIGNATURE_BASE_FE_APT_Backdoor_Linux32_SLOWPULSE_1 : FILE
{
	meta:
		description = "Detects samples mentioned in PulseSecure report"
		author = "Mandiant"
		id = "dd35257f-5b6f-55a6-a709-873ded1f4b72"
		date = "2021-04-16"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2021/04/suspected-apt-actors-leverage-bypass-techniques-pulse-secure-zero-day.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_pulsesecure.yar#L227-L244"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "cd09ec795a8f4b6ced003500a44d810f49943514e2f92c81ab96c33e1c0fbd68"
		logic_hash = "c1d92ea4ed8e5934c8356e1e52092935c53a138e454026737448f7f523ea06be"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$sb1 = {FC b9 [4] e8 00 00 00 00 5? 8d b? [4] 8b}
		$sb2 = {f3 a6 0f 85 [4] b8 03 00 00 00 5? 5? 5?}
		$sb3 = {9c 60 e8 00 00 00 00 5? 8d [5] 85 ?? 0f 8?}
		$sb4 = {89 13 8b 51 04 89 53 04 8b 51 08 89 53 08}
		$sb5 = {8d [5] b9 [4] f3 a6 0f 8?}

	condition:
		(( uint32( 0 ) == 0x464c457f ) and ( uint8( 4 ) == 1 ) ) and all of them
}
rule SIGNATURE_BASE_FE_APT_Webshell_PL_STEADYPULSE_1
{
	meta:
		description = "Detects samples mentioned in PulseSecure report"
		author = "Mandiant"
		id = "49457fbb-9288-565f-909d-e8228c21c1e4"
		date = "2021-04-16"
		modified = "2023-12-05"
		reference = "https://www.fireeye.com/blog/threat-research/2021/04/suspected-apt-actors-leverage-bypass-techniques-pulse-secure-zero-day.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_pulsesecure.yar#L265-L284"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "168976797d5af7071df257e91fcc31ce1d6e59c72ca9e2f50c8b5b3177ad83cc"
		logic_hash = "a0e3ebdd02ccf5cc8fc0a83c1d0224aed45dc5094eb85bd855e5b74b34e3aaaf"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = "parse_parameters"
		$s2 = "s/\\+/ /g"
		$s3 = "s/%(..)/pack("
		$s4 = "MIME::Base64::encode($"
		$s5 = "$|=1;"
		$s6 = "RC4("
		$s7 = "$FORM{'cmd'}"

	condition:
		all of them
}
rule SIGNATURE_BASE_SUSP_EXPL_LIBCUE_CVE_2023_43641_Oct23_1 : CVE_2023_43641 FILE
{
	meta:
		description = "Detects a suspicious .cue file that could be an exploitation attempt of libcue vulnerability CVE-2023-43641"
		author = "Florian Roth"
		id = "34fcf80c-adcd-55c0-9fb4-261d20f61fa6"
		date = "2023-10-27"
		modified = "2023-12-05"
		reference = "https://github.com/github/securitylab/blob/main/SecurityExploits/libcue/track_set_index_CVE-2023-43641/README.md"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_libcue_cve_2023_43641.yar#L2-L17"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a2cd3c1b0b3551ffb24bf7704c37c1be6c1a9655c74447d2f7f94540dd0ab188"
		score = 70
		quality = 85
		tags = "CVE-2023-43641, FILE"

	strings:
		$a1 = "TRACK "
		$a2 = "FILE "
		$s1 = "INDEX 4294"

	condition:
		filesize < 100KB and all of them
}
rule SIGNATURE_BASE_Gen_Excel_Auto_Open_Evasion : FILE
{
	meta:
		description = "Detects an obfuscated Auto_Open cell names in Excel files"
		author = "@JohnLaTwC"
		id = "e33b8d1d-4978-5747-8b5b-730e6c57dbf0"
		date = "2020-09-24"
		modified = "2023-12-05"
		reference = "https://malware.pizza/2020/05/12/evading-av-with-excel-macros-and-biff8-xls/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_excel_auto_open_evasion.yar#L1-L26"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "e23f9f55e10f3f31a2e76a12b174b6741a2fa1f51cf23dbd69cf169d92c56ed5"
		hash = "bb3c9739de8ffe2e0f375847d41a010463ec19f1d3f578ac053651a51ed69bbc"
		hash = "56ff65b7f6bf5936883f52b50ca66e768b2088158cc77af681ffab7122be7753"
		hash = "97243214ac3cad74d60b0648e39d6a9600860edba51c670b5226e058ba658957"
		hash = "9ebf085c05ae94c1b6c4e011001a6c11de3ca754a56ed380314ef501b777e593"
		hash = "b5a8bbf3c7d49bd208d8302f6867b5f6d3d7c09830b575967801893498cc92d9"
		logic_hash = "d7d81683b9abd7b89d6d6ee4d14ff37359acd353a6bd1d88bc793525c8f203d9"
		score = 70
		quality = 83
		tags = "FILE"

	strings:
		$auto_open = { 00 00 00 00 01 [0-2] (61 | 41) [0-5](75 | 55) [0-5](74 | 54) [0-5](6f | 4f) [0-5](5f | 5f) [0-5](6f | 4f) [0-5](70 | 50) [0-5](65 | 45) [0-5](6e | 4e)}
		$plain_auto_open = "auto_open" nocase wide ascii

	condition:
		filesize < 1MB and uint32be( 0 ) == 0xD0CF11E0 and $auto_open and #plain_auto_open == 0
}
rule SIGNATURE_BASE_WEBSHELL_ASPX_Sharepoint_Drop_CVE_2025_53770_Jul25 : CVE_2025_53770 FILE
{
	meta:
		description = "Detects ASPX web shell dropped during the exploitation of SharePoint RCE vulnerability CVE-2025-53770"
		author = "Florian Roth"
		id = "f1c8f671-a0d2-5aaf-93f4-025dace0dbe1"
		date = "2025-07-20"
		modified = "2026-05-15"
		reference = "https://research.eye.security/sharepoint-under-siege/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_sharepoint_jul25.yar#L1-L21"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "27c45b8ed7b8a7e5fff473b50c24028bd028a9fe8e25e5cea2bf5e676e531014"
		hash = "92bb4ddb98eeaf11fc15bb32e71d0a63256a0ed826a03ba293ce3a8bf057a514"
		hash = "b336f936be13b3d01a8544ea3906193608022b40c28dd8f1f281e361c9b64e93"
		logic_hash = "3c7bb848fc73418d5a3ecae6e9f637a7d07bf45a75b1bd0a278fdbfae428d619"
		score = 80
		quality = 85
		tags = "CVE-2025-53770, FILE"

	strings:
		$x1 = "var sy = System.Reflection.Assembly.Load(" ascii
		$x2 = "Response.Write(cg.ValidationKey+" ascii
		$s1 = "<script runat=\"server\" language=\"c#\" CODEPAGE=\"65001\">" ascii fullword

	condition:
		filesize < 4KB and 1 of ( $x* ) or all of them
}
rule SIGNATURE_BASE_WEBSHELL_ASPX_Compiled_Sharepoint_Drop_CVE_2025_53770_Jul25_2 : CVE_2025_53770 FILE
{
	meta:
		description = "Detects compiled ASPX web shell dropped during the exploitation of SharePoint RCE vulnerability CVE-2025-53770"
		author = "Florian Roth, Marius Benthin"
		id = "00a844ab-aede-53bf-820f-d43a5d96426d"
		date = "2025-07-20"
		modified = "2025-07-25"
		reference = "https://research.eye.security/sharepoint-under-siege/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_sharepoint_jul25.yar#L23-L53"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "8d3d3f3a17d233bc8562765e61f7314ca7a08130ac0fb153ffd091612920b0f2"
		hash = "d8ca5e5d6400ac34ac4cc138efa89d2ec4d5c0e968a78fa3ba5dbc04c7550649"
		hash = "7e9b77da1f51d03ee2f96bc976f6aeb781f801cf633862a4b8c356cbb555927d"
		logic_hash = "df11e5bd293cf094f3a147b54ecaafbe0804d7d575fcc22f38e77ab155c7ebdc"
		score = 75
		quality = 83
		tags = "CVE-2025-53770, FILE"

	strings:
		$x1 = /App_Web_spinstall\d{0,1}.aspx/ wide
		$x2 = /spinstall[\w]?[\._]aspx/ ascii
		$x3 = /\/_layouts\/1[0-9]\/spinstall/ wide
		$x4 = /\/_layouts\/1[0-9]\/ghostfile/ wide
		$s1 = "System.Web.Configuration.MachineKeySection" wide
		$s2 = "Page_load" ascii fullword
		$s3 = "GetApplicationConfig" wide fullword

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 20KB and ( 1 of ( $x* ) or all of ( $s* ) ) or 2 of ( $x* ) or 4 of them
}
rule SIGNATURE_BASE_APT_EXPL_Sharepoint_CVE_2025_53770_Forensicartefact_Jul25_1 : CVE_2025_53770
{
	meta:
		description = "Detects URIs accessed during the exploitation of SharePoint RCE vulnerability CVE-2025-53770"
		author = "Florian Roth"
		id = "06ad76ef-fc9c-5251-a7c0-cbbb66d79b0e"
		date = "2025-07-20"
		modified = "2025-07-23"
		reference = "https://research.eye.security/sharepoint-under-siege/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_sharepoint_jul25.yar#L55-L74"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "cca885bad087d1ed12f00ccad558bb474027f7cce058be76360df31c9499e771"
		score = 75
		quality = 81
		tags = "CVE-2025-53770"

	strings:
		$sa1 = /POST \/_layouts\/1[0-9]\/ToolPane\.aspx/ ascii wide nocase
		$sa2 = "DisplayMode=Edit&a=/ToolPane.aspx" ascii wide
		$sb1 = /GET \/_layouts\/1[0-9]\/spinstall/ ascii wide
		$sb2 = "/_layouts/SignOut.aspx 200" ascii wide nocase

	condition:
		(@sa2 - @sa1 ) < 700 or ( @sb2 - @sb1 ) < 700 or ( @sb2 - @sa1 ) < 700
}
rule SIGNATURE_BASE_APT_EXPL_Sharepoint_CVE_2025_53770_Forensicartefact_Jul25_2 : CVE_2025_53770
{
	meta:
		description = "Detects URIs accessed during the exploitation of SharePoint RCE vulnerability CVE-2025-53770"
		author = "Florian Roth"
		id = "c6f26461-04b8-5d69-bf28-e47411c38c82"
		date = "2025-07-20"
		modified = "2025-07-24"
		reference = "https://research.eye.security/sharepoint-under-siege/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_sharepoint_jul25.yar#L76-L106"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "30955794792a7ce045660bb1e1917eef36f1d5865891b8110bf982382b305b27"
		hash = "b336f936be13b3d01a8544ea3906193608022b40c28dd8f1f281e361c9b64e93"
		logic_hash = "5ae0620e7e1c1908ad54ac4e41c53240f738631c20577fd65fb29008945347a8"
		score = 70
		quality = 85
		tags = "CVE-2025-53770"

	strings:
		$x1 = "-EncodedCommand JABiAGEAcwBlADYANABTAHQAcgBpAG4AZwAgAD0" ascii wide
		$x2 = "TEMPLATE\\LAYOUTS\\spinstall" ascii wide
		$x3 = "TEMPLATE\\LAYOUTS\\ghostfile" ascii wide
		$x4 = "TEMPLATE\\LAYOUTS\\1.css" ascii wide
		$x5 = "Mozilla/5.0+(Windows+NT+10.0;+Win64;+x64;+rv:120.0)+Gecko/20100101+Firefox/120.0 /_layouts/SignOut.aspx" ascii wide
		$xe1 = "TQBJAEMAUgBPAFMAfgAxAFwAVwBFAEIAUwBFAFIAfgAxAFwAMQA2AFwAVABFAE0AUABMAEEAVABFAFwATABBAFkATwBVAFQAUwBcA"
		$xe2 = "0ASQBDAFIATwBTAH4AMQBcAFcARQBCAFMARQBSAH4AMQBcADEANgBcAFQARQBNAFAATABBAFQARQBcAEwAQQBZAE8AVQBUAFMAXA"
		$xe3 = "NAEkAQwBSAE8AUwB+ADEAXABXAEUAQgBTAEUAUgB+ADEAXAAxADYAXABUAEUATQBQAEwAQQBUAEUAXABMAEEAWQBPAFUAVABTAFwA"
		$xe4 = "TQBJAEMAUgBPAFMAfgAxAFwAVwBFAEIAUwBFAFIAfgAxAFwAMQA1AFwAVABFAE0AUABMAEEAVABFAFwATABBAFkATwBVAFQAUwBcA"
		$xe5 = "0ASQBDAFIATwBTAH4AMQBcAFcARQBCAFMARQBSAH4AMQBcADEANQBcAFQARQBNAFAATABBAFQARQBcAEwAQQBZAE8AVQBUAFMAXA"
		$xe6 = "NAEkAQwBSAE8AUwB+ADEAXABXAEUAQgBTAEUAUgB+ADEAXAAxADUAXABUAEUATQBQAEwAQQBUAEUAXABMAEEAWQBPAFUAVABTAFwA"

	condition:
		1 of them
}
rule SIGNATURE_BASE_EXPL_Exchange_Proxynotshell_Patterns_CVE_2022_41040_Oct22_1 : SCRIPT
{
	meta:
		description = "Detects successful ProxyNotShell exploitation attempts in log files (attempt to identify the attack before the official release of detailed information)"
		author = "Florian Roth (Nextron Systems)"
		id = "d2812fcd-0a20-5bbd-a9e1-9cca1ed58aa3"
		date = "2022-10-11"
		modified = "2023-03-15"
		old_rule_name = "EXPL_Exchange_ProxyNoShell_Patterns_CVE_2022_41040_Oct22_1"
		reference = "https://github.com/kljunowsky/CVE-2022-41040-POC"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_cve_2022_41040_proxynoshell.yar#L2-L26"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "81b0f0fea2762beb47826ff95545c87e960e098b9d5f45eacfe07b3ecf319ac5"
		score = 75
		quality = 85
		tags = "SCRIPT"

	strings:
		$sr1 = / \/autodiscover\/autodiscover\.json[^\n]{1,300}owershell/ nocase ascii
		$sa1 = " 200 "
		$fp1 = " 444 "
		$fp2 = " 404 "
		$fp2b = " 401 "
		$fp3 = "GET /owa/ &Email=autodiscover/autodiscover.json%3F@test.com&ClientId=" ascii
		$fp4 = "@test.com/owa/?&Email=autodiscover/autodiscover.json%3F@test.com" ascii

	condition:
		$sr1 and 1 of ( $sa* ) and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_APT_UTA028_Forensicartefacts_Paloalto_CVE_2024_3400_Apr24_1 : SCRIPT CVE_2024_3400
{
	meta:
		description = "Detects forensic artefacts of APT UTA028 as found in a campaign exploiting the Palo Alto CVE-2024-3400 vulnerability"
		author = "Florian Roth"
		id = "32cf18ff-784d-5849-87f8-14ede7315188"
		date = "2024-04-15"
		modified = "2024-04-18"
		reference = "https://www.volexity.com/blog/2024/04/12/zero-day-exploitation-of-unauthenticated-remote-code-execution-vulnerability-in-globalprotect-cve-2024-3400/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/vuln_paloalto_cve_2024_3400_apr24.yar#L2-L25"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "1261eecca520daa0619859a45d2289d2c23c73be55e1a3849d2032a38e137f4d"
		score = 70
		quality = 85
		tags = "SCRIPT, CVE-2024-3400"

	strings:
		$x1 = "cmd = base64.b64decode(rst.group"
		$x2 = "f.write(\"/*\"+output+\"*/\")"
		$x3 = "* * * * * root wget -qO- http://"
		$x4 = "rm -f /var/appweb/sslvpndocs/global-protect/*.css"
		$x5a = "failed to unmarshal session(../"
		$x5b = "failed to unmarshal session(./../"
		$x6 = "rm -rf /opt/panlogs/tmp/device_telemetry/minute/*" base64
		$x7 = "$(uname -a) > /var/" base64

	condition:
		1 of them
}
rule SIGNATURE_BASE_EXPL_Paloalto_CVE_2024_3400_Apr24_1 : CVE_2024_3400
{
	meta:
		description = "Detects characteristics of the exploit code used in attacks against Palo Alto GlobalProtect CVE-2024-3400"
		author = "Florian Roth"
		id = "1bcf0415-5351-5e09-ab93-496e8dc47c92"
		date = "2024-04-15"
		modified = "2025-03-21"
		reference = "https://www.volexity.com/blog/2024/04/12/zero-day-exploitation-of-unauthenticated-remote-code-execution-vulnerability-in-globalprotect-cve-2024-3400/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/vuln_paloalto_cve_2024_3400_apr24.yar#L27-L46"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9ebc94a07b189a2d2dd252b5079fa494162739678fd2ca742e6877189a140da9"
		score = 70
		quality = 85
		tags = "CVE-2024-3400"

	strings:
		$x1 = "SESSID=../../../../opt/panlogs/"
		$x2 = "SESSID=./../../../../opt/panlogs/"
		$sa1 = "SESSID=../../../../"
		$sa2 = "SESSID=./../../../../"
		$sb2 = "${IFS}"

	condition:
		1 of ( $x* ) or ( 1 of ( $sa* ) and $sb2 )
}
rule SIGNATURE_BASE_SUSP_LNX_Base64_Download_Exec_Apr24 : SCRIPT
{
	meta:
		description = "Detects suspicious base64 encoded shell commands used for downloading and executing further stages"
		author = "Paul Hager"
		id = "df8dddef-3c49-500c-abc8-7f7de5aa69ae"
		date = "2024-04-18"
		modified = "2025-03-21"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/vuln_paloalto_cve_2024_3400_apr24.yar#L48-L65"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "90b7781812b4078550b0d66ba020b3bb0a8217f2de03492af98db6c619f31929"
		score = 75
		quality = 85
		tags = "SCRIPT"

	strings:
		$sa1 = "curl http" base64
		$sa2 = "wget http" base64
		$sb1 = "chmod 777 " base64
		$sb2 = "/tmp/" base64

	condition:
		1 of ( $sa* ) and all of ( $sb* )
}
rule SIGNATURE_BASE_SUSP_PY_Import_Statement_Apr24_1
{
	meta:
		description = "Detects suspicious Python import statement and socket usage often found in Python reverse shells"
		author = "Florian Roth"
		id = "8e05f9a1-40a8-5d01-9e45-8779b0ff7a45"
		date = "2024-04-15"
		modified = "2025-03-21"
		reference = "https://www.volexity.com/blog/2024/04/12/zero-day-exploitation-of-unauthenticated-remote-code-execution-vulnerability-in-globalprotect-cve-2024-3400/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/vuln_paloalto_cve_2024_3400_apr24.yar#L67-L79"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d5c199d9c3e449ca282f0ca91c94ac783709299b3489f7cec38177a2f843b504"
		score = 65
		quality = 85
		tags = ""

	strings:
		$x1 = "import sys,socket,os,pty;s=socket.socket("

	condition:
		1 of them
}
rule SIGNATURE_BASE_SUSP_LNX_Base64_Exec_Apr24 : SCRIPT CVE_2024_3400 FILE
{
	meta:
		description = "Detects suspicious base64 encoded shell commands (as seen in Palo Alto CVE-2024-3400 exploitation)"
		author = "Christian Burkard"
		id = "2da3d050-86b0-5903-97eb-c5f39ce4f3a3"
		date = "2024-04-18"
		modified = "2025-03-21"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/vuln_paloalto_cve_2024_3400_apr24.yar#L81-L105"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "e96fb7c8faac12c1f0210689f2b3a7903b42a543b97ddff11298e5ae13cae80b"
		score = 75
		quality = 85
		tags = "SCRIPT, CVE-2024-3400, FILE"

	strings:
		$s1 = "curl http://" base64
		$s2 = "wget http://" base64
		$s3 = ";chmod 777 " base64
		$mirai = "country="
		$fp1 = "<html"
		$fp2 = "<?xml"

	condition:
		filesize < 800KB and 1 of ( $s* ) and not $mirai and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_M_APT_VIRTUALPITA_2 : FILE
{
	meta:
		description = "Finds opcodes to decode and parse the recieved data in the socket buffer in fe34b7c071d96dac498b72a4a07cb246.  Opcodes from 401a36 to 401adc"
		author = "Mandiant"
		id = "6a59cc54-e1a0-594f-9efb-af63d5c05259"
		date = "2022-10-01"
		modified = "2025-12-19"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_unc3886_virtualpita.yar#L15-L25"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "fe34b7c071d96dac498b72a4a07cb246"
		logic_hash = "56a3e1b13f0955a780f882e62003f721e409a1fdf61120dd295941605dbf21a4"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x = { 85 c0 74 ?? c7 05 ?? ?? ?? ?? fb ff ff ff c7 8? ?? ?? ?? ?? 00 00 00 00 e9 ?? ?? ?? ?? 4? 8b 05 ?? ?? ?? ?? 4? 83 c0 01 4? 89 05 ?? ?? ?? ?? c7 4? ?? 00 00 00 00 e9 ?? ?? ?? ?? 8b 4? ?? 4? 98 4? 8d 9? ?? ?? ?? ?? 4? 8d ?? e0 4? 8b 0? 4? 89 0? 4? 8b 4? ?? 4? 89 4? ?? 8b 4? ?? 4? 98 4? 8d b? ?? ?? ?? ?? b? ?? ?? ?? ?? e8 ?? ?? ?? ?? c7 4? ?? 00 00 00 00 eb ?? 8b 4? ?? 8b 4? ?? 01 c1 8b 4? ?? 03 4? ?? 4? 98 0f b6 9? ?? ?? ?? ?? 8b 4? ?? 4? 98 0f b6 8? ?? ?? ?? ?? 31 c2 4? 63 c1 88 9? ?? ?? ?? ?? 83 4? ?? 01 }

	condition:
		uint32( 0 ) == 0x464c457f and all of them
}
rule SIGNATURE_BASE_M_APT_VIRTUALPITA_3 : FILE
{
	meta:
		description = "Finds opcodes from 409dd8 to 409e46 in fe34b7c071d96dac498b72a4a07cb246 to set the HISTFILE environment variable to 'F' with a putenv() after loading each character individually."
		author = "Mandiant"
		id = "29ea2db0-4ab2-5e9c-8d42-7590ceabf99a"
		date = "2022-10-01"
		modified = "2025-12-19"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_unc3886_virtualpita.yar#L27-L37"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "fe34b7c071d96dac498b72a4a07cb246"
		logic_hash = "6f44d516b3cbe54542ae0991aad49274fc4728570e9498b319fc98840ceb7d7d"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x = { 4? 8b 4? ?? c6 00 48 4? 8b 4? ?? 4? 83 c0 05 c6 00 49 4? 8b 4? ?? 4? 83 c0 01 c6 00 49 4? 8b 4? ?? 4? 83 c0 06 c6 00 4c 4? 8b 4? ?? 4? 83 c0 02 c6 00 53 4? 8b 4? ?? 4? 83 c0 07 c6 00 45 4? 8b 4? ?? 4? 83 c0 03 c6 00 54 4? 8b 4? ?? 4? 83 c0 08 c6 00 3d 4? 8b 4? ?? 4? 83 c0 04 c6 00 46 4? 8b 4? ?? 4? 83 c0 09 c6 00 00 4? 8b 7? ?? e8 }

	condition:
		uint32( 0 ) == 0x464c457f and all of them
}
rule SIGNATURE_BASE_M_APT_VIRTUALPITA_4 : FILE
{
	meta:
		description = "Finds opcodes from 401f1c to 401f4f in fe34b7c071d96dac498b72a4a07cb246 to decode text with multiple XORs"
		author = "Mandiant"
		id = "58d4db75-fcd5-50c2-93ba-a8a4718ac0f6"
		date = "2022-10-01"
		modified = "2025-12-19"
		reference = "https://github.com/Neo23x0/signature-base"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_unc3886_virtualpita.yar#L39-L50"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "fe34b7c071d96dac498b72a4a07cb246"
		logic_hash = "aaf2ff682c619d2a254fe069d477654a161658db6315239f1b956141b6a72c01"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x = { 4? 8b 4? ?? 4? 83 c1 30 4? 8b 4? ?? 4? 8b 10 8b 4? ?? 4? 98 4? 8b 04 ?? ?? ?? ?? ?? 4? 31 c2 4? 8b 4? ?? 4? 83 c0 28 4? 8b 00 4? c1 e8 10 0f b6 c0 4? 98 4? 8b 04 }

	condition:
		uint32( 0 ) == 0x464c457f and all of them
}
rule SIGNATURE_BASE_MAL_RANSOM_Ragna_Locker_Apr20_1 : FILE
{
	meta:
		description = "Detects Ragna Locker Ransomware"
		author = "Florian Roth (Nextron Systems)"
		id = "67164cb4-73b7-5c4e-88f9-42379b88c641"
		date = "2020-04-27"
		modified = "2023-12-05"
		reference = "https://otx.alienvault.com/indicator/file/c2bd70495630ed8279de0713a010e5e55f3da29323b59ef71401b12942ba52f6"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_ransom_ragna_locker.yar#L3-L36"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "c2bd70495630ed8279de0713a010e5e55f3da29323b59ef71401b12942ba52f6"
		logic_hash = "05a18818f22c836c3e1f1fa9682d787bbe86e6d3bb026a80a7d4c33ad95c2cd3"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "---RAGNAR SECRET---" ascii
		$xc1 = { 0D 0A 25 73 0D 0A 0D 0A 25 73 0D 0A 25 73 0D 0A
               25 73 0D 0A 0D 0A 25 73 0D 0A 00 00 2E 00 72 00
               61 00 67 00 6E 00 61 00 72 00 5F }
		$xc2 = { 00 2D 00 66 00 6F 00 72 00 63 00 65 00 00 00 00
               00 57 00 69 00 6E 00 53 00 74 00 61 00 30 00 5C
               00 44 00 65 00 66 00 61 00 75 00 6C 00 74 00 00
               00 5C 00 6E 00 6F 00 74 00 65 00 70 00 61 00 64
               00 2E 00 65 00 78 00 65 00 }
		$s1 = "bootfont.bin" wide fullword
		$sc2 = { 00 57 00 69 00 6E 00 64 00 6F 00 77 00 73 00 00
               00 57 00 69 00 6E 00 64 00 6F 00 77 00 73 00 2E
               00 6F 00 6C 00 64 00 00 00 54 00 6F 00 72 00 20
               00 62 00 72 00 6F 00 77 00 73 00 65 00 72 00 }
		$op1 = { c7 85 58 ff ff ff 55 00 6b 00 c7 85 5c ff ff ff }
		$op2 = { 50 c7 85 7a ff ff ff 5c }
		$op3 = { 8b 75 08 8a 84 0d 20 ff ff ff ff 45 08 32 06 8b }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 200KB and 1 of ( $x* ) or 4 of them
}

rule SIGNATURE_BASE_MAL_Ransom_Ragnarlocker_July_2020_1 : FILE
{
	meta:
		description = "Detects Ragnarlocker by strings (July 2020)"
		author = "Arkbird_SOLG"
		id = "60e09057-d9f8-5e89-8f47-c5dda32806c6"
		date = "2020-07-30"
		modified = "2023-12-05"
		reference = "https://twitter.com/JAMESWT_MHT/status/1288797666688851969"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/crime_ransom_ragna_locker.yar#L38-L70"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "04c9cc0d1577d5ee54a4e2d4dd12f17011d13703cdd0e6efd46718d14fd9aa87"
		logic_hash = "dc44da2f9023e0702afa8081e85ba817ebfde15f449261fae9de729d51262b04"
		score = 75
		quality = 83
		tags = "FILE"

	strings:
		$f1 = "bootfont.bin" fullword wide
		$f2 = "bootmgr.efi" fullword wide
		$f3 = "bootsect.bak" fullword wide
		$r1 = "$!.txt" fullword wide
		$r2 = "---BEGIN KEY R_R---" fullword ascii
		$r3 = "!$R4GN4R_" wide
		$r4 = "RAGNRPW" fullword ascii
		$r5 = "---END KEY R_R---" fullword ascii
		$a1 = "+RhRR!-uD8'O&Wjq1_P#Rw<9Oy?n^qSP6N{BngxNK!:TG*}\\|W]o?/]H*8z;26X0" fullword ascii
		$a2 = "\\\\.\\PHYSICALDRIVE%d" fullword wide
		$a3 = "WinSta0\\Default" fullword wide
		$a4 = "%s-%s-%s-%s-%s" fullword wide
		$a5 = "SOFTWARE\\Microsoft\\Cryptography" fullword wide
		$c1 = "-backup" fullword wide
		$c2 = "-force" fullword wide
		$c3 = "-vmback" fullword wide
		$c4 = "-list" fullword wide
		$s1 = ".ragn@r_" wide
		$s2 = "\\notepad.exe" wide
		$s3 = "Opera Software" fullword wide
		$s4 = "Tor browser" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 30KB and ( pe.imphash ( ) == "2c2aab89a4cba444cf2729e2ed61ed4f" and ( ( 2 of ( $f* ) ) and ( 3 of ( $r* ) ) and ( 4 of ( $a* ) ) and ( 2 of ( $c* ) ) and ( 2 of ( $s* ) ) ) )
}
rule SIGNATURE_BASE_MAL_RANSOM_LNX_Macos_Lockbit_Apr23_1 : FILE
{
	meta:
		description = "Detects LockBit ransomware samples for Linux and macOS"
		author = "Florian Roth"
		id = "c01cb907-7d30-5487-b908-51f69ddb914c"
		date = "2023-04-15"
		modified = "2023-12-05"
		reference = "https://twitter.com/malwrhunterteam/status/1647384505550876675?s=20"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_lockbit_lnx_macos_apr23.yar#L2-L41"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0a2bffa0a30ec609d80591eef1d0994d8b37ab1f6a6bad7260d9d435067fb48e"
		hash = "9ebcbaf3c9e2bbce6b2331238ab584f95f7ced326ca4aba2ddcc8aa8ee964f66"
		hash = "a405d034c01a357a89c9988ffe8a46a165915df18fd297469b2bcaaf97578442"
		hash = "c9cac06c9093e9026c169adc3650b018d29c8b209e3ec511bbe34cbe1638a0d8"
		hash = "dc3d08480f5e18062a0643f9c4319e5c3f55a2e7e93cd8eddd5e0c02634df7cf"
		hash = "e77124c2e9b691dbe41d83672d3636411aaebc0aff9a300111a90017420ff096"
		hash = "0be6f1e927f973df35dad6fc661048236d46879ad59f824233d757ec6e722bde"
		hash = "3e4bbd21756ae30c24ff7d6942656be024139f8180b7bddd4e5c62a9dfbd8c79"
		logic_hash = "6d838e8b207b97d7c335dc4066de2c6dc87f7adc9cac31742677edbe85386cf7"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "restore-my-files.txt" ascii fullword
		$s1 = "ntuser.dat.log" ascii fullword
		$s2 = "bootsect.bak" ascii fullword
		$s3 = "autorun.inf" ascii fullword
		$s4 = "lockbit" ascii fullword
		$xc1 = { 33 38 36 00 63 6D 64 00 61 6E 69 00 61 64 76 00 6D 73 69 00 6D 73 70 00 63 6F 6D 00 6E 6C 73 }
		$xc2 = { 6E 74 6C 64 72 00 6E 74 75 73 65 72 2E 64 61 74 2E 6C 6F 67 00 62 6F 6F 74 73 65 63 74 2E 62 61 6B }
		$xc3 = { 76 6D 2E 73 74 61 74 73 2E 76 6D 2E 76 5F 66 72 65 65 5F 63 6F 75 6E 74 00 61 2B 00 2F 2A }
		$op1 = { 84 e5 f0 00 f0 e7 10 40 2d e9 2e 10 a0 e3 00 40 a0 e1 ?? fe ff }
		$op2 = { 00 90 a0 e3 40 20 58 e2 3f 80 08 e2 3f 30 c2 e3 09 20 98 e1 08 20 9d }
		$op3 = { 2d e9 01 70 43 e2 07 00 13 e1 01 60 a0 e1 08 d0 4d e2 02 40 }

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16( 0 ) == 0xfeca or uint16( 0 ) == 0xfacf or uint32( 0 ) == 0xbebafeca ) and ( 1 of ( $x* ) or 3 of them ) or 2 of ( $x* ) or 5 of them
}
rule SIGNATURE_BASE_MAL_RANSOM_Lockbit_Apr23_1
{
	meta:
		description = "Detects indicators found in LockBit ransomware"
		author = "Florian Roth"
		id = "75dc8b95-16f0-5170-a7d6-fc10bb778348"
		date = "2023-04-17"
		modified = "2023-12-05"
		reference = "https://objective-see.org/blog/blog_0x75.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_lockbit_lnx_macos_apr23.yar#L43-L67"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "cd5bffa5571abfd1446b065d26c8c23f00fe1376d505af539c6f37356014a86f"
		score = 75
		quality = 85
		tags = ""

	strings:
		$xe1 = "-i '/path/to/crypt'" xor
		$xe2 = "http://lockbit" xor
		$s1 = "idelayinmin" ascii
		$s2 = "bVMDKmode" ascii
		$s3 = "bSelfRemove" ascii
		$s4 = "iSpotMaximum" ascii
		$fp1 = "<html"

	condition:
		(1 of ( $x* ) or 4 of them ) and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_MAL_RANSOM_Lockbit_Locker_LOG_Apr23_1
{
	meta:
		description = "Detects indicators found in LockBit ransomware log files"
		author = "Florian Roth"
		id = "aa0a2393-e5a2-5151-8afb-91a9bb922179"
		date = "2023-04-17"
		modified = "2023-12-05"
		reference = "https://objective-see.org/blog/blog_0x75.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_lockbit_lnx_macos_apr23.yar#L69-L84"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d5f96e601150209382d3f6458863bc79768beb99b587aa8d9ba37cb2c11ef634"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = " is encrypted. Checksum after encryption "
		$s2 = "~~~~~Hardware~~~~"
		$s3 = "[+] Add directory to encrypt:"
		$s4 = "][+] Launch parameters: "

	condition:
		2 of them
}
rule SIGNATURE_BASE_MAL_RANSOM_Lockbit_Forensicartifacts_Apr23_1
{
	meta:
		description = "Detects forensic artifacts found in LockBit intrusions"
		author = "Florian Roth"
		id = "e716030c-ee78-51dc-919c-cf59e93da976"
		date = "2023-04-17"
		modified = "2023-12-05"
		reference = "https://objective-see.org/blog/blog_0x75.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_lockbit_lnx_macos_apr23.yar#L86-L101"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "81021f8c9aed17c007d7329a598c644a706fa9750818c8974984eefcba8d06c2"
		score = 75
		quality = 85
		tags = ""

	strings:
		$x1 = "/tmp/locker.log" ascii fullword
		$x2 = "Executable=LockBit/locker_" ascii
		$xc1 = { 54 6F 72 20 42 72 6F 77 73 65 72 20 4C 69 6E 6B 73 3A 0D 0A 68 74 74 70 3A 2F 2F 6C 6F 63 6B 62 69 74 }

	condition:
		1 of ( $x* )
}
rule SIGNATURE_BASE_APT_Sandworm_Keywords_May20_1 : CVE_2019_10149 FILE
{
	meta:
		description = "Detects commands used by Sandworm group to exploit critical vulernability CVE-2019-10149 in Exim"
		author = "Florian Roth (Nextron Systems)"
		id = "e0d4e90e-5547-5487-8d0c-a141d88fff7c"
		date = "2020-05-28"
		modified = "2023-12-05"
		reference = "https://media.defense.gov/2020/May/28/2002306626/-1/-1/0/CSA%20Sandworm%20Actors%20Exploiting%20Vulnerability%20in%20Exim%20Transfer%20Agent%2020200528.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_exim_expl.yar#L2-L15"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "9f9a81ff0c576f05ac063eaca7a5882dbdb09c9a0778610cca2864636a00efce"
		score = 75
		quality = 85
		tags = "CVE-2019-10149, FILE"

	strings:
		$x1 = "MAIL FROM:<$(run("
		$x2 = "exec\\x20\\x2Fusr\\x2Fbin\\x2Fwget\\x20\\x2DO\\x20\\x2D\\x20http"

	condition:
		filesize < 8000KB and 1 of them
}
rule SIGNATURE_BASE_APT_Sandworm_SSH_Key_May20_1 : FILE
{
	meta:
		description = "Detects SSH key used by Sandworm on exploited machines"
		author = "Florian Roth (Nextron Systems)"
		id = "ea2968b8-7ae4-56b8-9547-816c5e37c50a"
		date = "2020-05-28"
		modified = "2023-12-05"
		reference = "https://media.defense.gov/2020/May/28/2002306626/-1/-1/0/CSA%20Sandworm%20Actors%20Exploiting%20Vulnerability%20in%20Exim%20Transfer%20Agent%2020200528.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_exim_expl.yar#L17-L31"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "dc074464e50502459038ac127b50b8c68ed52817a61c2f97f0add33447c8f730"
		hash = "538d713cb47a6b5ec6a3416404e0fc1ebcbc219a127315529f519f936420c80e"
		logic_hash = "23a43849dfaa80bad2ca4f46b53181b3a4855ee89673ae9b658c854069b9aaa9"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC2q/NGN/brzNfJiIp2zswtL33tr74pIAjMeWtXN1p5Hqp5fTp058U1EN4NmgmjX0KzNjjV"

	condition:
		filesize < 1000KB and 1 of them
}
rule SIGNATURE_BASE_APT_Sandworm_SSHD_Config_Modification_May20_1 : FILE
{
	meta:
		description = "Detects ssh config entry inserted by Sandworm on compromised machines"
		author = "Florian Roth (Nextron Systems)"
		id = "dd60eeb7-3d4b-5a6a-8054-50c617ee8c73"
		date = "2020-05-28"
		modified = "2023-12-05"
		reference = "https://media.defense.gov/2020/May/28/2002306626/-1/-1/0/CSA%20Sandworm%20Actors%20Exploiting%20Vulnerability%20in%20Exim%20Transfer%20Agent%2020200528.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_exim_expl.yar#L33-L49"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "dc074464e50502459038ac127b50b8c68ed52817a61c2f97f0add33447c8f730"
		hash = "538d713cb47a6b5ec6a3416404e0fc1ebcbc219a127315529f519f936420c80e"
		logic_hash = "5775588b3a9d44e9eb2c8ef0f50351d7e3b06f1005f669775fae7187900d5999"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "AllowUsers mysql_db" ascii
		$a1 = "ListenAddress" ascii fullword

	condition:
		filesize < 10KB and all of them
}
rule SIGNATURE_BASE_APT_Sandworm_Initfile_May20_1 : FILE
{
	meta:
		description = "Detects mysql init script used by Sandworm on compromised machines"
		author = "Florian Roth (Nextron Systems)"
		id = "0bd613e3-6bd4-5cec-bc0d-2bdb83caf142"
		date = "2020-05-28"
		modified = "2023-12-05"
		reference = "https://media.defense.gov/2020/May/28/2002306626/-1/-1/0/CSA%20Sandworm%20Actors%20Exploiting%20Vulnerability%20in%20Exim%20Transfer%20Agent%2020200528.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_exim_expl.yar#L51-L66"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "dc074464e50502459038ac127b50b8c68ed52817a61c2f97f0add33447c8f730"
		hash = "538d713cb47a6b5ec6a3416404e0fc1ebcbc219a127315529f519f936420c80e"
		logic_hash = "989f37069820d9ecf67dc71e4761a7cde2c1adf8db40b5f8a47e9c610ddec2e6"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "GRANT ALL PRIVILEGES ON * . * TO 'mysqldb'@'localhost';" ascii
		$s2 = "CREATE USER 'mysqldb'@'localhost' IDENTIFIED BY '" ascii fullword

	condition:
		filesize < 10KB and all of them
}
rule SIGNATURE_BASE_APT_Sandworm_User_May20_1 : FILE
{
	meta:
		description = "Detects user added by Sandworm on compromised machines"
		author = "Florian Roth (Nextron Systems)"
		id = "ada549a4-abcc-5c0a-9601-75631e78c835"
		date = "2020-05-28"
		modified = "2023-12-05"
		reference = "https://media.defense.gov/2020/May/28/2002306626/-1/-1/0/CSA%20Sandworm%20Actors%20Exploiting%20Vulnerability%20in%20Exim%20Transfer%20Agent%2020200528.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_exim_expl.yar#L68-L84"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "dc074464e50502459038ac127b50b8c68ed52817a61c2f97f0add33447c8f730"
		hash = "538d713cb47a6b5ec6a3416404e0fc1ebcbc219a127315529f519f936420c80e"
		logic_hash = "d052792a674dfa2d93a048b550ea085c3b9225662fdb09bf4a602093b0527e38"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "mysql_db:x:" ascii
		$a1 = "root:x:"
		$a2 = "daemon:x:"

	condition:
		filesize < 4KB and all of them
}
rule SIGNATURE_BASE_APT_WEBSHELL_PHP_Sandworm_May20_1 : FILE
{
	meta:
		description = "Detects GIF header PHP webshell used by Sandworm on compromised machines"
		author = "Florian Roth (Nextron Systems)"
		id = "b9ec02c2-fa83-5f21-95cf-3528047b2d01"
		date = "2020-05-28"
		modified = "2023-12-05"
		reference = "https://media.defense.gov/2020/May/28/2002306626/-1/-1/0/CSA%20Sandworm%20Actors%20Exploiting%20Vulnerability%20in%20Exim%20Transfer%20Agent%2020200528.pdf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_exim_expl.yar#L86-L101"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "dc074464e50502459038ac127b50b8c68ed52817a61c2f97f0add33447c8f730"
		hash = "538d713cb47a6b5ec6a3416404e0fc1ebcbc219a127315529f519f936420c80e"
		logic_hash = "0d10f618c7b465c7691d6054e994a76f56c12eb0a36d2d98b5accd2c1e2c1da7"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$h1 = "GIF89a <?php $" ascii
		$s1 = "str_replace(" ascii

	condition:
		filesize < 10KB and $h1 at 0 and $s1
}
rule SIGNATURE_BASE_APT_RU_Sandworm_PY_May20_1 : FILE
{
	meta:
		description = "Detects Sandworm Python loader"
		author = "Florian Roth (Nextron Systems)"
		id = "a392d800-1fe8-5ae9-b813-e1dfcedecda6"
		date = "2020-05-28"
		modified = "2023-12-05"
		reference = "https://twitter.com/billyleonard/status/1266054881225236482"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_exim_expl.yar#L131-L148"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "c025008463fdbf44b2f845f2d82702805d931771aea4b506573b83c8f58bccca"
		logic_hash = "2ccc4c7fc75c04cbcab34904de2e7ab055a15c1017ec0f8d01b06454f4395047"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "o.addheaders=[('User-Agent','Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko')]" ascii fullword
		$s1 = "exec(o.open('http://" ascii
		$s2 = "__import__({2:'urllib2',3:'urllib.request'}"

	condition:
		uint16( 0 ) == 0x6d69 and filesize < 1KB and 1 of ( $x* ) or 2 of them
}
rule SIGNATURE_BASE_APT_RU_Sandworm_PY_May20_2 : FILE
{
	meta:
		description = "Detects Sandworm Python loader"
		author = "Florian Roth (Nextron Systems)"
		id = "5b32ad64-d959-5632-a03c-17aa055b213f"
		date = "2020-05-28"
		modified = "2023-12-05"
		reference = "https://twitter.com/billyleonard/status/1266054881225236482"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_sandworm_exim_expl.yar#L150-L167"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "abfa83cf54db8fa548942acd845b4f34acc94c46d4e1fb5ce7e97cc0c6596676"
		logic_hash = "5fb61a9cef64ecf97adc78bf67db667cfd9e5e6f3e03f1bba8f3cdbf6c257520"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "import sys;import re, subprocess;cmd" ascii fullword
		$x2 = "UA='Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko';server='http"
		$x3 = "';t='/admin/get.php';req" ascii
		$x4 = "ps -ef | grep Little\\ Snitch | grep " ascii fullword

	condition:
		uint16( 0 ) == 0x6d69 and filesize < 2KB and 1 of them
}
rule SIGNATURE_BASE_MAL_Driver_Microsoftcorporation_Windbgsys_Microsoftwindowsoperatingsystem_6994
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - windbg.sys"
		author = "Florian Roth"
		id = "05060e37-3c01-5b86-a3ee-6e141399164a"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L2-L38"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "6994b32e3f3357f4a1d0abe81e8b62dd54e36b17816f2f1a80018584200a1b77"
		hash = "5b932eab6c67f62f097a3249477ac46d80ddccdc52654f8674060b4ddf638e5d"
		hash = "ea50f22daade04d3ca06dedb497b905215cba31aae7b4cab4b533fda0c5be620"
		hash = "f936ec4c8164cbd31add659b61c16cb3a717eac90e74d89c47afb96b60120280"
		hash = "32882949ea084434a376451ff8364243a50485a3b4af2f2240bb5f20c164543d"
		hash = "6661320f779337b95bbbe1943ee64afb2101c92f92f3d1571c1bf4201c38c724"
		hash = "86047bb1969d1db455493955fd450d18c62a3f36294d0a6c3732c88dfbcc4f62"
		hash = "06c5ebd0371342d18bc81a96f5e5ce28de64101e3c2fd0161d0b54d8368d2f1f"
		hash = "4734a0a5d88f44a4939b8d812364cab6ca5f611b9b8ceebe27df6c1ed3a6d8a4"
		hash = "770f33259d6fb10f4a32d8a57d0d12953e8455c72bb7b60cb39ce505c507013a"
		hash = "50819a1add4c81c0d53203592d6803f022443440935ff8260ff3b6d5253c0c76"
		hash = "f9f2091fccb289bcf6a945f6b38676ec71dedb32f3674262928ccaf840ca131a"
		hash = "fa9abb3e7e06f857be191a1e049dd37642ec41fb2520c105df2227fcac3de5d5"
		hash = "139f8412a7c6fdc43dcfbbcdba256ee55654eb36a40f338249d5162a1f69b988"
		hash = "e1cb86386757b947b39086cc8639da988f6e8018ca9995dd669bdc03c8d39d7d"
		hash = "e6f764c3b5580cd1675cbf184938ad5a201a8c096607857869bd7c3399df0d12"
		hash = "bb2422e96ea993007f25c71d55b2eddfa1e940c89e895abb50dd07d7c17ca1df"
		logic_hash = "161f83c85ad516f3f06f3719a1d8ae0c841e818e50f985403133c2f77b7be894"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]00570069006e0064006f007700730020004700550049002000730079006d0062006f006c00690063002000640065006200750067006700650072 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]004d006900630072006f0073006f0066007400200043006f00720070006f0072006100740069006f006e }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]00310030002e0030002e00310039003000340031002e0036003800350020002800570069006e004200750069006c0064002e003100360030003100300031002e00300038003000300029 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]00310030002e0030002e00310039003000340031002e003600380035 }
		$ = { 0049006e007400650072006e0061006c004e0061006d0065[1-8]00770069006e006400620067002e007300790073 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]004d006900630072006f0073006f00660074003f002000570069006e0064006f00770073003f0020004f007000650072006100740069006e0067002000530079007300740065006d }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]00770069006e006400620067002e007300790073 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]003f0020004d006900630072006f0073006f0066007400200043006f00720070006f0072006100740069006f006e002e00200041006c006c0020007200690067006800740073002000720065007300650072007600650064002e }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Gentilkiwibenjamindelpy_Mimidrv_Mimidrvmimikatz_AAF0
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - mimidrv.sys"
		author = "Florian Roth"
		id = "57e5655e-1313-585f-931c-d892e8952d0e"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L41-L100"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "aaf04d89fd15bc61265e545f8e1da80e20f59f90058ed343c62ee24358e3af9e"
		hash = "4b97d63ebdeda6941bb8cef5e94741c6cca75237ca830561f2262034805f0919"
		hash = "c42c1e5c3c04163bf61c3b86b04a5ec7d302af7e254990cef359ac80474299da"
		hash = "f03f0fb3a26bb83e8f8fa426744cf06f2e6e29f5220663b1d64265952b8de1a1"
		hash = "0f98492c92e35042b09032e3d9aedc357e4df94fc840217fa1091046f9248a06"
		hash = "d032001eab6cad4fbef19aab418650ded00152143bd14507e17d62748297c23f"
		hash = "2456a7921fa8ab7b9779e5665e6b42fccc019feb9e49a9a28a33ec0a4bb323c4"
		hash = "f9b01406864ab081aa77eef4ad15cb2dd2f830d1ef54f52622a59ff1aeb05ba5"
		hash = "19dfacea1b9f19c0379f89b2424ceb028f2ce59b0db991ba83ae460027584987"
		hash = "3ca5d47d076e99c312578ef6499e1fa7b9db88551cfc0f138da11105aca7c5e1"
		hash = "cf9451c9ccc5509b9912965f79c2b95eb89d805b2a186d7521d3a262cf5a7a37"
		hash = "a0931e16cf7b18d15579e36e0a69edad1717b07527b5407f2c105a2f554224b2"
		hash = "492113a223d6a3fc110059fe46a180d82bb8e002ef2cd76cbf0c1d1eb8243263"
		hash = "85b9d7344bf847349b5d58ebe4d44fd63679a36164505271593ef1076aa163b2"
		hash = "efa56907b9d0ec4430a5d581f490b6b9052b1e979da4dab6a110ab92e17d4576"
		hash = "12b0000698b79ea3c8178b9e87801cc34bad096a151a8779559519deafd4e3f0"
		hash = "4136f1eb11cc463a858393ea733d5f1c220a3187537626f7f5d63eccf7c5a03f"
		hash = "ee525b90053bb30908b5d7bf4c5e9b8b9d6b7b5c9091a26fa25d30d3ad8ef5d0"
		hash = "10ad50fcb360dcab8539ea322aaf2270565dc835b7535790937348523d723d6b"
		hash = "4d42678df3917c37f44a1506307f1677b9a689efcf350b1acce7e6f64b514905"
		hash = "d37996abc8efb29f1ccbb4335ce9ba9158bec86cc4775f0177112e87e4e3be5c"
		hash = "569fe70bedd0df8585689b0e88ad8bd0544fdf88b9dbfc2076f4bdbcf89c28aa"
		hash = "80e4c83cfa9d675a6746ab846fa5da76d79e87a9297e94e595a2d781e02673b3"
		hash = "1a5c08d40a5e73b9fe63ea5761eaec8f41d916ca3da2acbc4e6e799b06af5524"
		hash = "ee7b8eb150df2788bb9d5fe468327899d9f60d6731c379fd75143730a83b1c55"
		hash = "a1e6b431534258954db07039117b3159e889c6b9e757329bbd4126383c60c778"
		hash = "e99580e25f419b5ad90669e0c274cf63d30efa08065d064a863e655bdf77fb59"
		hash = "b0b80a11802b4a8ca69c818a03e76e7ef57c2e293de456439401e8e6073f8719"
		hash = "4c89c907b7525b39409af1ad11cc7d2400263601edafc41c935715ef5bd145de"
		hash = "083f821d90e607ed93221e71d4742673e74f573d0755a96ad17d1403f65a2254"
		hash = "e8ec06b1fa780f577ff0e8c713e0fd9688a48e0329c8188320f9eb62dfc0667f"
		hash = "ac5fb90e88d8870cd5569e661bea98cf6b001d83ab7c65a5196ea3743146939a"
		hash = "7b846b0a717665e4d9fb313f25d1f6a5b782e495387aea45cf87ad3c049ac0db"
		hash = "93aa3066ae831cdf81505e1bc5035227dc0e8f06ebbbb777832a17920c6a02fe"
		hash = "082a79311da64b6adc3655e79aa090a9262acaac3b917a363b9571f520a17f6a"
		hash = "bc49cb96f3136c3e552bf29f808883abb9e651040415484c1736261b52756908"
		hash = "95e5b5500e63c31c6561161a82f7f9373f99b5b1f54b018c4866df4f2a879167"
		hash = "d43520128871c83b904f3136542ea46644ac81a62d51ae9d3c3a3f32405aad96"
		hash = "94c71954ac0b1fd9fa2bd5c506a16302100ba75d9f84f39ee9b333546c714601"
		hash = "793b78e70b3ae3bb400c5a8bc4d2d89183f1d7fc70954aed43df7287248b6875"
		logic_hash = "9566444b1d3adb2a8a5f48b45bbbdb5c9be3ce399ec091e3ffd13780a90227f1"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]006d0069006d006900640072007600200066006f0072002000570069006e0064006f0077007300200028006d0069006d0069006b00610074007a0029 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]00670065006e00740069006c006b0069007700690020002800420065006e006a0061006d0069006e002000440045004c005000590029 }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0032002e0032002e0030002e0030 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0032002e0032002e0030002e0030 }
		$ = { 0049006e007400650072006e0061006c004e0061006d0065[1-8]006d0069006d0069006400720076 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]006d0069006d006900640072007600200028006d0069006d0069006b00610074007a0029 }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]006d0069006d0069006400720076002e007300790073 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]0043006f00700079007200690067006800740020002800630029002000320030003000370020002d00200032003000320030002000670065006e00740069006c006b0069007700690020002800420065006e006a0061006d0069006e002000440045004c005000590029 }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Gentilkiwibenjamindelpy_Mimidrv_Mimidrvmimikatz_DDF4
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - mimidrv.sys"
		author = "Florian Roth"
		id = "0b38be06-60df-5b49-a748-eb175e1db33f"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L103-L137"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "ddf427ce55b36db522f638ba38e34cd7b96a04cb3c47849b91e7554bfd09a69a"
		hash = "bcb774b6f6ff504d2db58096601bc5cb419c169bfbeaa3af852417e87d9b2aa0"
		hash = "af4f42197f5ce2d11993434725c81ecb6f54025110dedf56be8ffc0e775d9895"
		hash = "9dc7beb60a0a6e7238fc8589b6c2665331be1e807b4d2b3ddd1c258dbbd3e2f7"
		hash = "2da2b883e48e929f5365480d487590957d9e6582cc6da2c0b42699ba85e54fe2"
		hash = "29348ebe12d872c5f40e316a0043f7e5babe583374487345a79bad0ba93fbdfe"
		hash = "e4b2c0aa28aac5e197312a061b05363e2e0387338b28b23272b5b6659d29b1d8"
		hash = "897f2bbe81fc3b1ae488114b93f3eb0133a85678d061c7a6f718507971f33736"
		hash = "0f7bfa10075bf5c193345866333d415509433dbfe5a7d45664b88d72216ff7c3"
		hash = "469713c76c7a887826611b8c7180209a8bb6250f91d0f1eb84ac4d450ef15870"
		hash = "818787057fc60ac8b957aa37d750aa4bace8e6a07d3d28b070022ee6dcd603ab"
		hash = "4af8192870afe18c77381dfaf8478f8914fa32906812bb53073da284a49ae4c7"
		hash = "0740359baef32cbb0b14a9d1bd3499ea2e770ff9b1c85898cfac8fd9aca4fa39"
		hash = "62764ddc2dce74f2620cd2efd97a2950f50c8ac5a1f2c1af00dc5912d52f6920"
		hash = "3b2cd65a4fbdd784a6466e5196bc614c17d1dbaed3fd991d242e3be3e9249da6"
		logic_hash = "d20bfd9f05a7cdb031f3ada2801ee3b978a9d27407b4425c7aa7eb41b4549b18"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]006d0069006d006900640072007600200066006f0072002000570069006e0064006f0077007300200028006d0069006d0069006b00610074007a0029 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]00670065006e00740069006c006b0069007700690020002800420065006e006a0061006d0069006e002000440045004c005000590029 }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0032002e0031002e0030002e0030 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0032002e0031002e0030002e0030 }
		$ = { 0049006e007400650072006e0061006c004e0061006d0065[1-8]006d0069006d0069006400720076 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]006d0069006d006900640072007600200028006d0069006d0069006b00610074007a0029 }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]006d0069006d0069006400720076002e007300790073 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]0043006f00700079007200690067006800740020002800630029002000320030003000370020002d00200032003000310036002000670065006e00740069006c006b0069007700690020002800420065006e006a0061006d0069006e002000440045004c005000590029 }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Gentilkiwibenjamindelpy_Mimidrv_Mimidrvmimikatz_0F58
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - mimidrv.sys"
		author = "Florian Roth"
		id = "0531a88d-cb21-5055-b365-a80b6e99a6e9"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L140-L173"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0f58e09651d48d2b1bcec7b9f7bb85a2d1a7b65f7a51db281fe0c4f058a48597"
		hash = "087270d57f1626f29ba9c25750ca19838a869b73a1f71af50bdf37d6ff776212"
		hash = "0d676baac43d9e2d05b577d5e0c516fba250391ab0cb11232a4b17fd97a51e35"
		hash = "06ddf49ac8e06e6b83fccba1141c90ea01b65b7db592c54ffe8aa6d30a75c0b8"
		hash = "eab9b5b7e5fab1c2d7d44cd28f13ae8bb083d9362d2b930d43354a3dfd38e05a"
		hash = "627e13da6a45006fff4711b14754f9ccfac9a5854d275da798a22f3a68dd1eaa"
		hash = "b169a5f643524d59330fafe6e3e328e2179fc5116ee6fae5d39581467d53ac03"
		hash = "dfc80e0d468a2c115a902aa332a97e3d279b1fc3d32083e8cf9a4aadf3f54ad1"
		hash = "a74e8f94d2c140646a8bb12e3e322c49a97bd1b8a2e4327863d3623f43d65c66"
		hash = "94ba4bcbdb55d6faf9f33642d0072109510f5c57e8c963d1a3eb4f9111f30112"
		hash = "07759750fbb93c77b5c3957c642a9498fcff3946a5c69317db8d6be24098a4a0"
		hash = "4dc24fd07f8fb854e685bc540359c59f177de5b91231cc44d6231e33c9e932b1"
		hash = "baf7fbc4743a81eb5e4511023692b2dfdc32ba670ba3e4ed8c09db7a19bd82d3"
		hash = "bcca03ce1dd040e67eb71a7be0b75576316f0b6587b2058786fda8b6f0a5adfd"
		logic_hash = "ffa3eaf9032aa673119558217d212ff819ce91e99ab6c046f8801990d5826689"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]006d0069006d006900640072007600200066006f0072002000570069006e0064006f0077007300200028006d0069006d0069006b00610074007a0029 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]00670065006e00740069006c006b0069007700690020002800420065006e006a0061006d0069006e002000440045004c005000590029 }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0032002e0030002e0030002e0030 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0032002e0030002e0030002e0030 }
		$ = { 0049006e007400650072006e0061006c004e0061006d0065[1-8]006d0069006d0069006400720076 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]006d0069006d006900640072007600200028006d0069006d0069006b00610074007a0029 }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]006d0069006d0069006400720076002e007300790073 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]0043006f00700079007200690067006800740020002800630029002000320030003000370020002d00200032003000310034002000670065006e00740069006c006b0069007700690020002800420065006e006a0061006d0069006e002000440045004c005000590029 }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Gentilkiwibenjamindelpy_Mimidrv_Mimidrvmimikatz_7662
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - mimidrv.sys"
		author = "Florian Roth"
		id = "2bb58484-03d2-5ccc-b165-cfe405f60f03"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L176-L218"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "7662187c236003308a7951c2f49c0768636c492f8935292d02f69e59b01d236d"
		hash = "a85d3fd59bb492a290552e5124bfe3f9e26a3086d69d42ccc44737b5a66673ec"
		hash = "60ee78a2b070c830fabb54c6bde0d095dff8fad7f72aa719758b3c41c72c2aa9"
		hash = "b2486f9359c94d7473ad8331b87a9c17ca9ba6e4109fd26ce92dff01969eaa09"
		hash = "d41e39215c2c1286e4cd3b1dc0948adefb161f22bc3a78756a027d41614ee4ff"
		hash = "008fa89822b7a1f91e5843169083202ea580f7b06eb6d5cae091ba844d035f25"
		hash = "8206ce9c42582ac980ff5d64f8e3e310bc2baa42d1a206dd831c6ab397fbd8fe"
		hash = "aafa642ca3d906138150059eeddb6f6b4fe9ad90c6174386cfe13a13e8be47d9"
		hash = "fefc070a5f6a9c0415e1c6f44512a33e8d163024174b30a61423d00d1e8f9bf2"
		hash = "6964a5d85639baee288555797992861232e75817f93028b50b8c6d34aa38b05b"
		hash = "443c0ba980d4db9213b654a45248fd855855c1cc81d18812cae9d16729ff9a85"
		hash = "e8743094f002239a8a9d6d7852c7852e0bb63cd411b007bd8c194bcba159ef15"
		hash = "ec96b15ce218f97ec1d8f07f13b052d274c4c8438f31daf246ccfaaee5e1bebd"
		hash = "beef40f1b4ce0ff2ee5c264955e6b2a0de6fe4089307510378adc83fad77228b"
		hash = "e858de280bd72d7538386a73e579580a6d5edba87b66b3671dc180229368be19"
		hash = "21617210249d2a35016e8ca6bd7a1edda25a12702a2294d56010ee8148637f5a"
		hash = "02ebf848fa618eba27065db366b15ee6629d98f551d20612ac38b9f655f37715"
		hash = "40556dd9b79b755cc0b48d3d024ceb15bd2c0e04960062ab2a85cd7d4d1b724a"
		hash = "8b30b2dc36d5e8f1ffc7281352923773fb821cdf66eb6516f82c697a524b599b"
		hash = "2ce4f8089b02017cbe86a5f25d6bc69dd8b6f5060c918a64a4123a5f3be1e878"
		hash = "d7aa8abdda8a68b8418e86bef50c19ef2f34bc66e7b139e43c2a99ab48c933be"
		hash = "82ac05fefaa8c7ee622d11d1a378f1d255b647ab2f3200fd323cc374818a83f2"
		hash = "c7cd14c71bcac5420872c3d825ff6d4be6a86f3d6a8a584f1a756541efff858e"
		logic_hash = "089f046e94a9cb4f576896e90375d6dbcaef61aa302af07f80230a74bc33ed18"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]006d0069006d006900640072007600200066006f0072002000570069006e0064006f0077007300200028006d0069006d0069006b00610074007a0029 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]00670065006e00740069006c006b0069007700690020002800420065006e006a0061006d0069006e002000440045004c005000590029 }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0032002e0031002e0031002e0030 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0032002e0031002e0031002e0030 }
		$ = { 0049006e007400650072006e0061006c004e0061006d0065[1-8]006d0069006d0069006400720076 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]006d0069006d006900640072007600200028006d0069006d0069006b00610074007a0029 }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]006d0069006d0069006400720076002e007300790073 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]0043006f00700079007200690067006800740020002800630029002000320030003000370020002d00200032003000310037002000670065006e00740069006c006b0069007700690020002800420065006e006a0061006d0069006e002000440045004c005000590029 }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Gentilkiwibenjamindelpy_Mimidrv_Mimidrvmimikatz_14B8
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - mimidrv.sys"
		author = "Florian Roth"
		id = "a9965f8f-4969-52ae-953f-a06d8fabe951"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L221-L271"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "14b89298134696f2fd1b1df0961d36fa6354721ea92498a349dc421e79447925"
		hash = "36c65aeb255c06898ffe32e301030e0b74c8bca6fe7be593584b8fdaacd4e475"
		hash = "673bbc7fa4154f7d99af333014e888599c27ead02710f7bc7199184b30b38653"
		hash = "5295080de37d4838e15dec4e3682545033d479d3d9ac28d74747c086559fb968"
		hash = "8684aec77b4c3cafc1a6594de7e95695fa698625d4206a6c4b201875f76a5b38"
		hash = "69866557566c59772f203c11f5fba30271448e231b65806a66e48f41e3804d7f"
		hash = "a42f4ae69b8755a957256b57eb3d319678eab81705f0ffea0d649ace7321108f"
		hash = "62036cdf3663097534adf3252b921eed06b73c2562655eae36b126c7d3d83266"
		hash = "1ef7afea0cf2ef246ade6606ef8b7195de9cd7a3cd7570bff90ba1e2422276f6"
		hash = "b34e2d9f3d4ef59cf7af18e17133a6a06509373e69e33c8eecb2e30501d0d9e4"
		hash = "0aab2deae90717a8876d46d257401d265cf90a5db4c57706e4003c19eee33550"
		hash = "15cf366f7b3ee526db7ce2b5253ffebcbfaa4f33a82b459237c049f854a97c0c"
		hash = "c4c9c84b211899ceb0d18a839afa497537a7c7c01ab481965a09788a9e16590c"
		hash = "618b15970671700188f4102e5d0638184e2723e8f57f7e917fa49792daebdadb"
		hash = "4bca0a401b364a5cc1581a184116c5bafa224e13782df13272bc1b748173d1be"
		hash = "c7bccc6f38403def4690e00a0b31eda05973d82be8953a3379e331658c51b231"
		hash = "822982c568b6f44b610f8dc4ab5d94795c33ae08a6a608050941264975c1ecdb"
		hash = "b8c71e1844e987cd6f9c2baf28d9520d4ccdd8593ce7051bb1b3c9bf1d97076a"
		hash = "26bea3b3ab2001d91202f289b7e41499d810474607db7a0893ceab74f5532f47"
		hash = "c8ae217860f793fce3ad0239d7b357dba562824dd7177c9d723ca4d4a7f99a12"
		hash = "a78c9871da09fab21aec9b88a4e880f81ecb1ed0fa941f31cc2f041067e8e972"
		hash = "82b7fa34ad07dbf9afa63b2f6ed37973a1b4fe35dee90b3cf5c788c15c9f08f7"
		hash = "6d68d8a71a11458ddf0cbb73c0f145bee46ef29ce03ad7ece6bd6aa9d31db9b7"
		hash = "52f3905bbd97dcd2dbd22890e5e8413b9487088f1ee2fa828030a6a45b3975fd"
		hash = "64d4370843a07e25d4ceb68816015efcaeca9429bb5bb692a88e615b48c7da96"
		hash = "f3ec3f22639d45b3c865bb1ed7622db32e04e1dbc456298be02bf1f3875c3aac"
		hash = "51805bb537befaac8ce28f2221624cb4d9cefdc0260bc1afd5e0bc97bf1f9f93"
		hash = "c4fb31e3f24e40742a1b9855a2d67048fe64b26d8d2dbcec77d2d5deeded2bcc"
		hash = "d50cb5f4b28c6c26f17b9d44211e515c3c0cc2c0c4bf24cd8f9ed073238053ad"
		hash = "4999541c47abd4a7f2a002c180ae8d31c19804ce538b85870b8db53d3652862b"
		hash = "a32dc2218fb1f538fba33701dfd9ca34267fda3181e82eb58b971ae8b78f0852"
		logic_hash = "e4d4b0da09beff889931b8d90365c3a04ff4b5b410004fb820cb2551365cf63c"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]006d0069006d006900640072007600200066006f0072002000570069006e0064006f0077007300200028006d0069006d0069006b00610074007a0029 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]00670065006e00740069006c006b0069007700690020002800420065006e006a0061006d0069006e002000440045004c005000590029 }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0032002e0031002e0030002e0030 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0032002e0031002e0030002e0030 }
		$ = { 0049006e007400650072006e0061006c004e0061006d0065[1-8]006d0069006d0069006400720076 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]006d0069006d006900640072007600200028006d0069006d0069006b00610074007a0029 }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]006d0069006d0069006400720076002e007300790073 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]0043006f00700079007200690067006800740020002800630029002000320030003000370020002d00200032003000310037002000670065006e00740069006c006b0069007700690020002800420065006e006a0061006d0069006e002000440045004c005000590029 }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Gentilkiwibenjamindelpy_Mimidrv_Mimidrvmimikatz_41AD
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - mimidrv.sys"
		author = "Florian Roth"
		id = "8a8887dd-0f3d-5ab4-a945-b47966789b99"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L274-L309"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "41ad660820c41fc8b1860b13dc1fea8bc8cb2faceb36ed3e29d40d28079d2b1f"
		hash = "a7a665a695ec3c0f862a0d762ad55aff6ce6014359647e7c7f7e3c4dc3be81b7"
		hash = "9a42fa1870472c38a56c0a70f62e57a3cdc0f5bc142f3a400d897b85d65800ac"
		hash = "f6157e033a12520c73dcedf8e49cd42d103e5874c34d6527bb9de25a5d26e5ad"
		hash = "31b66a57fae0cc28a6a236d72a35c8b6244f997e700f9464f9cbf800dbf8bee6"
		hash = "1d23ab46ad547e7eef409b40756aae9246fbdf545d13946f770643f19c715e80"
		hash = "704c6ffe786bc83a73fbdcd2edd50f47c3b5053da7da6aa4c10324d389a31db4"
		hash = "200f98655d1f46d2599c2c8605ebb7e335fee3883a32135ca1a81e09819bc64a"
		hash = "4bd4715d2a7af627da11513e32fab925c872babebdb7ff5675a75815fbf95021"
		hash = "9e56e96df36237e65b3d7dbc490afdc826215158f6278cd579c576c4b455b392"
		hash = "8b32fc8b15363915605c127ccbf5cbe71778f8dfbf821a25455496e969a01434"
		hash = "b0a27ac1a8173413de13860d2b2e34cb6bc4d1149f94b62d319042e11d8b004c"
		hash = "07beac65e28ee124f1da354293a3d6ad7250ed1ce29b8342acfd22252548a5af"
		hash = "c4f041de66ec8cc5ab4a03bbc46f99e073157a4e915a9ab4069162de834ffc5c"
		hash = "26ef7b27d1afb685e0c136205a92d29b1091e3dcf6b7b39a4ec03fbbdb57cb55"
		hash = "406b844f4b5c82caf26056c67f9815ad8ecf1e6e5b07d446b456e5ff4a1476f9"
		logic_hash = "a51e3e4c17122bf15b70b47693c3d24792cc7c7cbead1b26e501cb2907113968"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]006d0069006d006900640072007600200066006f0072002000570069006e0064006f0077007300200028006d0069006d0069006b00610074007a0029 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]00670065006e00740069006c006b0069007700690020002800420065006e006a0061006d0069006e002000440045004c005000590029 }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0032002e0032002e0030002e0030 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0032002e0032002e0030002e0030 }
		$ = { 0049006e007400650072006e0061006c004e0061006d0065[1-8]006d0069006d0069006400720076 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]006d0069006d006900640072007600200028006d0069006d0069006b00610074007a0029 }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]006d0069006d0069006400720076002e007300790073 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]0043006f00700079007200690067006800740020002800630029002000320030003000370020002d00200032003000310039002000670065006e00740069006c006b0069007700690020002800420065006e006a0061006d0069006e002000440045004c005000590029 }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Sensecorp_42B2
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - Sense5Ext.sys"
		author = "Florian Roth"
		id = "6b64ff77-866b-5d77-b2cf-5e507acc6cb9"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L312-L329"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "42b22faa489b5de936db33f12184f6233198bdf851a18264d31210207827ba25"
		logic_hash = "72e213913bf4317fa0751775e6a1a82ba2706e79c52fcd3e2c8ca69050e3a9d7"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]00530065006e0073006500350020004400720069007600650072 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]00530065006e00730065003500200043004f00520050 }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0032002e0035002e0030002e0030 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0032002e0035002e0030002e0030 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]0043006f0070007900720069006700680074002000280043002900200032003000320032 }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Legalcorp_Pciexpressvideocapture_FD22
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - PcieCubed.sys"
		author = "Florian Roth"
		id = "c9b28922-d4c7-5c09-9df8-b7b8d8ffc2e8"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L332-L351"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "fd223833abffa9cd6cc1848d77599673643585925a7ee51259d67c44d361cce8"
		logic_hash = "4c47a159595f420c520e6924238bd260f49ccf163208713c72c62638b13756d9"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]005000430049006500200056006900640065006f00200043006100700074007500720065 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]004c006500670061006c00200043006f00720070002e }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0031002e0030002e0030002e00310035 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0031002e0030002e0030002e00310035 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]0050004300490020004500780070007200650073007300200056006900640065006f00200043006100700074007500720065 }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]005000630069006500430075006200650064002e007300790073 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]00320030003100360020004c006500670061006c }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Gmer_Gmersys_Gmer_0052
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - gmer64.sys, superman.sys"
		author = "Florian Roth"
		id = "a2197304-4455-52bb-ac73-9218b310bb99"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L354-L375"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "0052aa88e42055a2eed5ddd17c3499c692360155e5e031a211edfcef577acce3"
		hash = "18c909a2b8c5e16821d6ef908f56881aa0ecceeaccb5fa1e54995935fcfd12f7"
		logic_hash = "1644a972cb9bde33e5e8ec078b0ee67b34b6a298504895f364260b96a453a3ba"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]0047004d00450052002000440072006900760065007200200068007400740070003a002f002f007700770077002e0067006d00650072002e006e00650074 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]0047004d00450052 }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0032002c00200030002c002000360039003800330020006200750069006c0074002000620079003a002000570069006e00440044004b }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0032002c00200030002c00200036003900380033 }
		$ = { 0049006e007400650072006e0061006c004e0061006d0065[1-8]0067006d0065007200360034002e007300790073 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]0047004d00450052 }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]0067006d0065007200360034002e007300790073 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]0043006f0070007900720069006700680074002000280043002900200047004d0045005200200032003000300033002d0032003000310033 }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Mimidrv_Mimidrvmimikatz_2FAF
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - mimidrv.sys"
		author = "Florian Roth"
		id = "0160f2aa-f60f-5590-be0a-6751487eab92"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L378-L395"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "2faf95a3405578d0e613c8d88d534aa7233da0a6217ce8475890140ab8fb33c8"
		logic_hash = "e7b3f0a8f5a91896f7d487a39c622b12fc7488f9f80c80b6b551e7e5f6a67f18"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0032002e0030002e0030002e0030 }
		$ = { 0049006e007400650072006e0061006c004e0061006d0065[1-8]006d0069006d0069006400720076 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]006d0069006d006900640072007600200028006d0069006d0069006b00610074007a0029 }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]006d0069006d0069006400720076002e007300790073 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]0043006f00700079007200690067006800740020002800630029002000320030003000370020002d00200032003000310035002000670065006e00740069006c006b0069007700690020002800420065006e006a0061006d0069006e002000440045004c005000590029 }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Gentilkiwibenjamindelpy_Mimidrv_Mimidrvmimikatz_2FD4
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - mimidrv.sys"
		author = "Florian Roth"
		id = "e77f1fc7-4700-5afe-908f-b0d206757365"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L398-L420"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "2fd43a749b5040ebfafd7cdbd088e27ef44341d121f313515ebde460bf3aaa21"
		hash = "7824931e55249a501074a258b4f65cd66157ee35672ba17d1c0209f5b0384a28"
		hash = "28f5aa194a384680a08c0467e94a8fc40f8b0f3f2ac5deb42e0f51a80d27b553"
		logic_hash = "e24fab351505faf86bd12d6dd97662542c8cf5fca09d916b716af1478f3c9ddf"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]006d0069006d006900640072007600200066006f0072002000570069006e0064006f0077007300200028006d0069006d0069006b00610074007a0029 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]00670065006e00740069006c006b0069007700690020002800420065006e006a0061006d0069006e002000440045004c005000590029 }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0032002e0030002e0030002e0030 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0032002e0030002e0030002e0030 }
		$ = { 0049006e007400650072006e0061006c004e0061006d0065[1-8]006d0069006d0069006400720076 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]006d0069006d006900640072007600200028006d0069006d0069006b00610074007a0029 }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]006d0069006d0069006400720076002e007300790073 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]0043006f00700079007200690067006800740020002800630029002000320030003000370020002d00200032003000310035002000670065006e00740069006c006b0069007700690020002800420065006e006a0061006d0069006e002000440045004c005000590029 }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Microsoftcorporation_Ntbiosys_Microsoftrwindowsrntoperatingsystem_C0D8
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - ntbios_2.sys"
		author = "Florian Roth"
		id = "f16b4b22-985a-5d39-ae51-709aa9a69d8d"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L423-L444"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "c0d88db11d0f529754d290ed5f4c34b4dba8c4f2e5c4148866daabeab0d25f9c"
		hash = "96bf3ee7c6673b69c6aa173bb44e21fa636b1c2c73f4356a7599c121284a51cc"
		logic_hash = "74ad0b57644d82a77bc902786250156f5e3700671bdf9765055b5908dc345a67"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]006e007400620069006f00730020006400720069007600650072 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]004d006900630072006f0073006f0066007400200043006f00720070006f0072006100740069006f006e }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0035002c00200030002c00200032002c00200031 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0035002c00200030002c00200032002c00200031 }
		$ = { 0049006e007400650072006e0061006c004e0061006d0065[1-8]006e007400620069006f002e007300790073 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]0020004d006900630072006f0073006f00660074002800520029002000570069006e0064006f0077007300200028005200290020004e00540020004f007000650072006100740069006e0067002000530079007300740065006d }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]006e007400620069006f0073002e007300790073 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]7248674362406709002000280043002900200032003000300033 }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Microsoftcorporation_Wintapixsys_Microsoftwindowsoperatingsystem_8578
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - WinTapix.sys, SRVNET2.SYS"
		author = "Florian Roth"
		id = "0bb182e8-e64b-5b01-9ca5-105212ebeb51"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L447-L468"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "8578bff36e3b02cc71495b647db88c67c3c5ca710b5a2bd539148550595d0330"
		hash = "1485c0ed3e875cbdfc6786a5bd26d18ea9d31727deb8df290a1c00c780419a4e"
		logic_hash = "dd85f0dc471425fe692e5a51580a97facdaea45505c48b5e01dd6dbc975f2ffe"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]00570069006e0064006f007700730020004b00650072006e0065006c00200045007800650063007500740069007600650020004d006f00640075006c0065 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]004d006900630072006f0073006f0066007400200043006f00720070006f0072006100740069006f006e }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0036002e0033002e0039003600300030002e003100360033003800340020002800770069006e0062006c00750065005f00720074006d002e003100330030003800320031002d00310036003200330029 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0036002e0033002e0039003600300030002e00310036003300380034 }
		$ = { 0049006e007400650072006e0061006c004e0061006d0065[1-8]00570069006e00540061007000690078002e007300790073 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]004d006900630072006f0073006f0066007400ae002000570069006e0064006f0077007300ae0020004f007000650072006100740069006e0067002000530079007300740065006d }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]00570069006e00540061007000690078002e007300790073 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]00a90020004d006900630072006f0073006f0066007400200043006f00720070006f0072006100740069006f006e002e00200041006c006c0020007200690067006800740073002000720065007300650072007600650064002e }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Microsoftcorporation_Wantdsys_Microsoftwindowsoperatingsystem_E7AF
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - wantd_6.sys"
		author = "Florian Roth"
		id = "5f883209-6887-5cb4-96bb-988898d47c09"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L471-L494"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "e7af7bcb86bd6bab1835f610671c3921441965a839673ac34444cf0ce7b2164e"
		hash = "b9dad0131c51e2645e761b74a71ebad2bf175645fa9f42a4ab0e6921b83306e3"
		hash = "8d9a2363b757d3f127b9c6ed8f7b8b018e652369bc070aa3500b3a978feaa6ce"
		hash = "06a0ec9a316eb89cb041b1907918e3ad3b03842ec65f004f6fa74d57955573a4"
		logic_hash = "b4d12069a9a3a8d8d9bde9a4ed3f80f21f2654b6f96943d201933198678d01d9"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]00570041004e0020005400720061006e00730070006f007200740020004400720069007600650072 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]004d006900630072006f0073006f0066007400200043006f00720070006f0072006100740069006f006e }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0036002e0031002e0037003600300030002e0031003100370032 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0036002e0031002e0037003600300030002e0031003100370032 }
		$ = { 0049006e007400650072006e0061006c004e0061006d0065[1-8]00770061006e00740064002e007300790073 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]004d006900630072006f0073006f00660074002000570069006e0064006f007700730020004f007000650072006100740069006e0067002000530079007300740065006d }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]00770061006e00740064002e007300790073 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]004d006900630072006f0073006f0066007400200043006f00720070006f0072006100740069006f006e002e00200041006c006c0020007200690067006800740073002000720065007300650072007600650064002e }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Gentilkiwibenjamindelpy_Mimidrv_Mimidrvmimikatz_30E0
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - mimidrv.sys"
		author = "Florian Roth"
		id = "888de0dc-5643-5e55-8272-9363cc55bfcf"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L497-L518"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "30e083cd7616b1b969a92fd18cf03097735596cce7fcf3254b2ca344e526acc2"
		hash = "a906251667a103a484a6888dca3e9c8c81f513b8f037b98dfc11440802b0d640"
		logic_hash = "e2c964f7e30da210778e8a2e5bb96d53485a0736cf3ff28bccbefacb6b46765a"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]006d0069006d006900640072007600200066006f0072002000570069006e0064006f0077007300200028006d0069006d0069006b00610074007a0029 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]00670065006e00740069006c006b0069007700690020002800420065006e006a0061006d0069006e002000440045004c005000590029 }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0032002e0030002e0030002e0030 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0032002e0030002e0030002e0030 }
		$ = { 0049006e007400650072006e0061006c004e0061006d0065[1-8]006d0069006d0069006400720076 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]006d0069006d006900640072007600200028006d0069006d0069006b00610074007a0029 }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]006d0069006d0069006400720076002e007300790073 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]0043006f00700079007200690067006800740020002800630029002000320030003000370020002d00200032003000310033002000670065006e00740069006c006b0069007700690020002800420065006e006a0061006d0069006e002000440045004c005000590029 }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Microsoftcorporation_Wantdsys_Microsoftwindowsoperatingsystem_6908
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - wantd_2.sys"
		author = "Florian Roth"
		id = "3bd8b888-8170-5da6-ba1c-f13c1ca27e6f"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L521-L541"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "6908ebf52eb19c6719a0b508d1e2128f198d10441551cbfb9f4031d382f5229f"
		logic_hash = "9cde0a399b852038979993375be2a6d0f9f9f760381e94df0190256e8810949f"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]00570041004e0020005400720061006e00730070006f007200740020004400720069007600650072 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]004d006900630072006f0073006f0066007400200043006f00720070006f0072006100740069006f006e }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0036002e0031002e0037003600300030002e003900330038 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0036002e0031002e0037003600300030002e003900330038 }
		$ = { 0049006e007400650072006e0061006c004e0061006d0065[1-8]00770061006e00740064002e007300790073 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]004d006900630072006f0073006f00660074002000570069006e0064006f007700730020004f007000650072006100740069006e0067002000530079007300740065006d }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]00770061006e00740064002e007300790073 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]004d006900630072006f0073006f0066007400200043006f00720070006f0072006100740069006f006e002e00200041006c006c0020007200690067006800740073002000720065007300650072007600650064002e }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Microsoftcorporation_Srvnetsys_Microsoftwindowsoperatingsystem_F6C3
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - WinTapix.sys, SRVNET2.SYS"
		author = "Florian Roth"
		id = "3559718f-59d7-5bff-860c-6a073f4c05d9"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L544-L564"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "f6c316e2385f2694d47e936b0ac4bc9b55e279d530dd5e805f0d963cb47c3c0d"
		logic_hash = "ab1aea5cec71668c0e35ea149b9e537c8468738c3b3e70382ebedf51bb8729d0"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]0053006500720076006500720020004e006500740077006f0072006b0020006400720069007600650072 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]004d006900630072006f0073006f0066007400200043006f00720070006f0072006100740069006f006e }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]00310030002e0030002e00310038003300360032002e0036003900330020002800570069006e004200750069006c0064002e003100360030003100300031002e00300038003000300029 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]00310030002e0030002e00310038003300360032002e003600390033 }
		$ = { 0049006e007400650072006e0061006c004e0061006d0065[1-8]005300520056004e004500540032002e005300590053 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]004d006900630072006f0073006f0066007400ae002000570069006e0064006f0077007300ae0020004f007000650072006100740069006e0067002000530079007300740065006d }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]005300520056004e004500540032002e005300590053 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]00a90020004d006900630072006f0073006f0066007400200043006f00720070006f0072006100740069006f006e002e00200041006c006c0020007200690067006800740073002000720065007300650072007600650064002e }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Microsoftcorporation_Wantdsys_Microsoftwindowsoperatingsystem_81C7
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - wantd_3.sys"
		author = "Florian Roth"
		id = "43ae822a-c4c4-5525-bfd3-a05d1ec50bd0"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L567-L587"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "81c7bb39100d358f8286da5e9aa838606c98dfcc263e9a82ed91cd438cb130d1"
		logic_hash = "ec9e321bbc89bffb6243e3edde45e60dc06513e88dfb9a262768ef081db60c5b"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]00570041004e0020005400720061006e00730070006f007200740020004400720069007600650072 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]004d006900630072006f0073006f0066007400200043006f00720070006f0072006100740069006f006e }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0035002e0032002e0033003700390030002e003900330038 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0035002e0032002e0033003700390030002e003900330038 }
		$ = { 0049006e007400650072006e0061006c004e0061006d0065[1-8]00770061006e00740064002e007300790073 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]004d006900630072006f0073006f00660074002000570069006e0064006f007700730020004f007000650072006100740069006e0067002000530079007300740065006d }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]00770061006e00740064002e007300790073 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]004d006900630072006f0073006f0066007400200043006f00720070006f0072006100740069006f006e002e00200041006c006c0020007200690067006800740073002000720065007300650072007600650064002e }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_773B
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - mimidrv.sys"
		author = "Florian Roth"
		id = "f47ab2f1-86f6-5550-939e-4477ec1c367c"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L590-L605"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "773b4a1efb9932dd5116c93d06681990759343dfe13c0858d09245bc610d5894"
		logic_hash = "5e01850384ac0dc0e9f33e3e217e0e824cfe3c2bb46feff94dffa070f2f7c9a0"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0032002e0031002e0031002e0030 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0032002e0031002e0031002e0030 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]0043006f00700079007200690067006800740020002800630029002000320030003000370020002d002000320030003100370020 }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Sensecorp_7F45
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - Sense5Ext.sys"
		author = "Florian Roth"
		id = "6c1f5ba4-fd14-5069-9d99-e3072b2dbbc2"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L608-L625"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "7f4555a940ce1156c9bcea9a2a0b801f9a5e44ec9400b61b14a7b1a6404ffdf6"
		logic_hash = "dbef723d7e44da110675402fc13708c5b077eeb6a66c1772885f5879d795ec4e"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]00530065006e0073006500350020004400720069007600650072 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]00530065006e00730065003500200043004f00520050 }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0032002e0036002e0030002e0030 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0032002e0036002e0030002e0030 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]0043006f0070007900720069006700680074002000280043002900200032003000320032 }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_Driver_Microsoftcorporation_Ndislansys_Microsoftwindowsoperatingsystem_B0EB
{
	meta:
		description = "Detects malicious driver mentioned in LOLDrivers project using VersionInfo values from the PE header - ndislan.sys"
		author = "Florian Roth"
		id = "c94adcf3-2ea6-5856-9327-2e5ed1c49b22"
		date = "2024-08-07"
		modified = "2024-12-12"
		reference = "https://github.com/magicsword-io/LOLDrivers"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/yara-rules_mal_drivers.yar#L628-L648"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "b0eb4d999e4e0e7c2e33ff081e847c87b49940eb24a9e0794c6aa9516832c427"
		logic_hash = "4b92b69636dea19a23172def47e9a1bbd4507075ec118b48db30fec377b8fbff"
		score = 70
		quality = 85
		tags = ""

	strings:
		$ = { 00460069006c0065004400650073006300720069007000740069006f006e[1-8]004d00530020004c0041004e0020004400720069007600650072 }
		$ = { 0043006f006d00700061006e0079004e0061006d0065[1-8]004d006900630072006f0073006f0066007400200043006f00720070006f0072006100740069006f006e }
		$ = { 00460069006c006500560065007200730069006f006e[1-8]0036002e0031002e0037003600300030002e0031003400320031 }
		$ = { 00500072006f006400750063007400560065007200730069006f006e[1-8]0036002e0031002e0037003600300030002e0031003400320031 }
		$ = { 0049006e007400650072006e0061006c004e0061006d0065[1-8]006e006400690073006c0061006e002e007300790073 }
		$ = { 00500072006f0064007500630074004e0061006d0065[1-8]004d006900630072006f0073006f0066007400ae002000570069006e0064006f0077007300ae0020004f007000650072006100740069006e0067002000530079007300740065006d }
		$ = { 004f0072006900670069006e0061006c00460069006c0065006e0061006d0065[1-8]006e006400690073006c0061006e002e007300790073 }
		$ = { 004c006500670061006c0043006f0070007900720069006700680074[1-8]00a90020004d006900630072006f0073006f0066007400200043006f00720070006f0072006100740069006f006e002e00200041006c006c0020007200690067006800740073002000720065007300650072007600650064002e }

	condition:
		all of them
}
rule SIGNATURE_BASE_MAL_JS_NPM_Supplychain_Attack_Nov25 : FILE
{
	meta:
		description = "Detects malicious JavaScript worm bun_environment.js"
		author = "Marius Benthin"
		id = "11726cbe-48a7-577a-9694-8f38ffa746e1"
		date = "2025-11-24"
		modified = "2025-12-15"
		reference = "https://www.aikido.dev/blog/shai-hulud-strikes-again-hitting-zapier-ensdomains"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_npm_supply_chain_nov25.yar#L1-L23"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "62ee164b9b306250c1172583f138c9614139264f889fa99614903c12755468d0"
		logic_hash = "b5a8da01ecb31dfa7a3921847a0fe26021b7618b1ee7a115a366b0854a4fa0a8"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$sa1 = "npm publish"
		$sa2 = "NPM_TOKEN"
		$sa3 = "NPM_CONFIG_TOKEN"
		$sb1 = "GITHUB_"
		$sb2 = "GITLAB_"
		$sb3 = "TEAMCITY_"

	condition:
		filesize < 20MB and all of ( $sa* ) and 2 of ( $sb* )
}
rule SIGNATURE_BASE_SUSP_JS_NPM_Sha1_Hulud_Nov25 : FILE
{
	meta:
		description = "Detects suspicious indicators for Sha1 Hulud worm"
		author = "Marius Benthin"
		id = "511fa6ca-25fe-57d4-a910-277c92d65e4a"
		date = "2025-11-24"
		modified = "2025-12-15"
		reference = "https://www.aikido.dev/blog/shai-hulud-strikes-again-hitting-zapier-ensdomains"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_npm_supply_chain_nov25.yar#L25-L41"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "62ee164b9b306250c1172583f138c9614139264f889fa99614903c12755468d0"
		logic_hash = "95f7e657108bc63825f969baa28211c5c63746f525db5e71a486d76aaf98ba32"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "Sha1-Hulud:\\x"
		$x2 = "SHA1HULUD\"`"

	condition:
		filesize < 20MB and 1 of them
}
rule SIGNATURE_BASE_SUSP_JS_NPM_Setupscript_Nov25 : FILE
{
	meta:
		description = "Detects suspicious JavaScript which exits silently and checks operating system"
		author = "Marius Benthin"
		id = "2d102efd-681a-5af1-b4fe-3489e5e7f8f2"
		date = "2025-11-24"
		modified = "2025-12-15"
		reference = "https://www.aikido.dev/blog/shai-hulud-strikes-again-hitting-zapier-ensdomains"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_npm_supply_chain_nov25.yar#L43-L64"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "a3894003ad1d293ba96d77881ccd2071446dc3f65f434669b49b3da92421901a"
		logic_hash = "b685f642d1d62200da973aad7fd7a2d606a098b92524aaebe5e2bb45c63f3155"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$sa1 = "require('child_process')"
		$sa2 = "process.platform ==="
		$sb1 = "().catch((e"
		$sb2 = "process.exit(0)"

	condition:
		filesize < 100KB and all of ( $sa* ) and $sb1 in ( filesize - 50 .. filesize ) and $sb2 in ( filesize - 30 .. filesize )
}
rule SIGNATURE_BASE_MAL_NPM_Supplychain_Attack_Preinstallscript_Nov25 : FILE
{
	meta:
		description = "Detects known malicious preinstall script in package.json"
		author = "Marius Benthin"
		id = "eebcf73d-ee26-59c6-aacb-b76232829ea6"
		date = "2025-11-24"
		modified = "2026-05-15"
		reference = "https://www.aikido.dev/blog/shai-hulud-strikes-again-hitting-zapier-ensdomains"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_npm_supply_chain_nov25.yar#L66-L80"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "c4bc2afd133916f064f2fb7d1e2e067ea65db33463eeae2fa54a9860a6303865"
		logic_hash = "7472fc4759bbf03abd05a0eade1144c7ca3ab31af26ed4eab4028056027b2e47"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "\"preinstall\": \"node setup_bun.js\""

	condition:
		filesize < 10KB and all of them
}
rule SIGNATURE_BASE_Mal_Lockbit4_Packed_Feb24 : FILE
{
	meta:
		description = "Detect the packer used by Lockbit4.0"
		author = "0x0d4y"
		id = "3c2b2806-9dce-4dce-a7ca-89ebc9005695"
		date = "2024-02-16"
		modified = "2026-05-15"
		reference = "https://0x0d4y.blog/lockbit4-0-evasion-tales/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_lockbit4_packed_win_feb24.yar#L1-L25"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "15796971d60f9d71ad162060f0f76a02"
		logic_hash = "07281fd86efbb7167ba1cc0c6f6897418751df1a3697869e51f806c26641e365"
		score = 100
		quality = 85
		tags = "FILE"
		license = "CC BY 4.0"
		rule_matching_tlp = "TLP:WHITE"
		rule_sharing_tlp = "TLP:WHITE"
		malpedia_family = "win.lockbit"

	strings:
		$unpacking_loop_64b = { 8b 1e 48 83 ee fc 11 db 8a 16 72 e5 8d 41 01 41 ff d3 11 c0 01 db 75 0a }
		$jump_to_unpacked_code_64b = { 48 8b 2d 16 0f ?? ?? 48 8d be 00 f0 ?? ?? bb 00 ?? ?? ?? 50 49 89 e1 41 b8 04 ?? ?? ?? 53 5a 90 57 59 90 48 83 ec ?? ff d5 48 8d 87 ?? ?? ?? ?? 80 20 ?? 80 60 ?? ?? 4c 8d 4c 24 ?? 4d 8b 01 53 90 5a 90 57 59 ff d5 48 83 c4 ?? 5d 5f 5e 5b 48 8d 44 24 ?? 6a ?? 48 39 c4 75 f9 48 83 ec ?? e9 }
		$unpacking_loop_32b = { 8A 06 46 88 07 47 01 DB 75 ?? 8B 1E 83 EE ?? 11 DB 72 ?? 9C 29 C0 40 9D 01 DB 75 ?? 8B 1E 83 EE ?? 11 DB 11 C0 01 DB 73 ?? 75 ?? 8B 1E 83 EE ?? 11 DB 73 }
		$jump_to_unpacked_code_32b = { 8b ae ?? ?? ?? ?? 8d be 00 f0 ?? ?? bb 00 ?? ?? ?? 50 54 6a 04 53 57 ff d5 8d 87 ?? ?? ?? ?? 80 20 ?? 80 60 ?? ?? 58 50 54 50 53 57 ff d5 58 8d 9e 00 f0 ?? ?? 8d bb ?? ?? ?? ?? 57 31 c0 aa 59 49 50 6a 01 53 ff d1 61 8d 44 24 ?? 6a ?? 39 c4 75 fa 83 ec ?? e9 }

	condition:
		uint16( 0 ) == 0x5a4d and 1 of ( $jump_to_unpacked_code_* ) and 1 of ( $unpacking_loop_* )
}
rule SIGNATURE_BASE_EXPL_Exchange_Proxyshell_Successful_Aug21_1 : SCRIPT
{
	meta:
		description = "Detects successful ProxyShell exploitation attempts in log files"
		author = "Florian Roth (Nextron Systems)"
		id = "8c11cd1a-6d3f-5f29-af61-17179b01ca8b"
		date = "2021-08-08"
		modified = "2025-03-21"
		reference = "https://blog.orange.tw/2021/08/proxylogon-a-new-attack-surface-on-ms-exchange-part-1.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_proxyshell.yar#L17-L33"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "06ab609a8efe3b36b6356a9cf7b7b11b2fc2a556ec1df6995008a9df86b3fcee"
		score = 65
		quality = 83
		tags = "SCRIPT"

	strings:
		$xr1a = / \/autodiscover\/autodiscover\.json[^\n]{1,300}\/(powershell|X-Rps-CAT)/ nocase ascii
		$xr1b = / \/autodiscover\/autodiscover\.json[^\n]{1,300}\/(mapi\/nspi|EWS\/)[^\n]{1,400}(200|302) 0 0/
		$xr2 = /autodiscover\/autodiscover\.json[^\n]{1,60}&X-Rps-CAT=/ nocase ascii
		$xr3 = /Email=autodiscover\/autodiscover\.json[^\n]{1,400}200 0 0/ nocase ascii

	condition:
		1 of them
}
rule SIGNATURE_BASE_WEBSHELL_ASPX_Proxyshell_Aug21_2 : FILE
{
	meta:
		description = "Detects webshells dropped by ProxyShell exploitation based on their file header (must be PST), size and content"
		author = "Florian Roth (Nextron Systems)"
		id = "a351a466-695e-570e-8c7f-9c6c0534839c"
		date = "2021-08-13"
		modified = "2025-11-03"
		reference = "https://www.bleepingcomputer.com/news/microsoft/microsoft-exchange-servers-are-getting-hacked-via-proxyshell-exploits/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_proxyshell.yar#L35-L48"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "4ede197d482f0a9e553ba857b5049e7b7405e3df92460e19418fa0653c844982"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Page Language=" ascii nocase

	condition:
		uint32( 0 ) == 0x4e444221 and filesize < 2MB and $s1
}
rule SIGNATURE_BASE_WEBSHELL_ASPX_Proxyshell_Aug21_3 : FILE
{
	meta:
		description = "Detects webshells dropped by ProxyShell exploitation based on their file header (must be DER), size and content"
		author = "Max Altgelt"
		id = "a7bca62b-c8f1-5a38-81df-f3d4582a590b"
		date = "2021-08-23"
		modified = "2025-11-03"
		reference = "https://twitter.com/gossithedog/status/1429175908905127938?s=12"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_proxyshell.yar#L50-L64"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f071aaa8918b359f786f2ac7447eeaedb5a6fca9e0a0c0e8820e011244424503"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "Page Language=" ascii nocase

	condition:
		uint16( 0 ) == 0x8230 and filesize < 10KB and $s1
}
rule SIGNATURE_BASE_WEBSHELL_ASPX_Proxyshell_Sep21_1 : FILE
{
	meta:
		description = "Detects webshells dropped by ProxyShell exploitation based on their file header (must be PST) and base64 decoded request"
		author = "Tobias Michalski"
		id = "d0d23e17-6b6a-51d1-afd9-59cc2404bcd8"
		date = "2021-09-17"
		modified = "2025-11-03"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_proxyshell.yar#L66-L80"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "219468c10d2b9d61a8ae70dc8b6d2824ca8fbe4e53bbd925eeca270fef0fd640"
		logic_hash = "233ec15dff8da5f2beaa931eb06849aa37e548947c1068d688a1695d977605d8"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s = ".FromBase64String(Request["

	condition:
		uint32( 0 ) == 0x4e444221 and any of them
}
rule SIGNATURE_BASE_APT_IIS_Config_Proxyshell_Artifacts : FILE
{
	meta:
		description = "Detects virtual directory configured in IIS pointing to a ProgramData folder (as found in attacks against Exchange servers in August 2021)"
		author = "Florian Roth (Nextron Systems)"
		id = "21888fc0-82c6-555a-9320-9cbb8332a843"
		date = "2021-08-25"
		modified = "2025-11-03"
		reference = "https://www.huntress.com/blog/rapid-response-microsoft-exchange-servers-still-vulnerable-to-proxyshell-exploit"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_proxyshell.yar#L82-L105"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "a4557694629448d258b8b2fefc278e059217560e7a0ec3279863a16fb9b3989c"
		score = 90
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "<site name=" ascii
		$a2 = "<sectionGroup name=\"system.webServer\">" ascii
		$sa1 = " physicalPath=\"C:\\ProgramData\\COM" ascii
		$sa2 = " physicalPath=\"C:\\ProgramData\\WHO" ascii
		$sa3 = " physicalPath=\"C:\\ProgramData\\ZING" ascii
		$sa4 = " physicalPath=\"C:\\ProgramData\\ZOO" ascii
		$sa5 = " physicalPath=\"C:\\ProgramData\\XYZ" ascii
		$sa6 = " physicalPath=\"C:\\ProgramData\\AUX" ascii
		$sa7 = " physicalPath=\"C:\\ProgramData\\CON\\" ascii
		$sb1 = " physicalPath=\"C:\\Users\\All Users\\" ascii

	condition:
		filesize < 500KB and all of ( $a* ) and 1 of ( $s* )
}
rule SIGNATURE_BASE_WEBSHELL_ASPX_Proxyshell_Exploitation_Aug21_1 : FILE
{
	meta:
		description = "Detects unknown malicious loaders noticed in August 2021"
		author = "Florian Roth (Nextron Systems)"
		id = "1fa563fc-c91c-5f4e-98f1-b895e1acb4f4"
		date = "2021-08-25"
		modified = "2025-11-03"
		reference = "https://twitter.com/VirITeXplorer/status/1430206853733097473"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_proxyshell.yar#L107-L119"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8a2417bb85c7f91d98143d2f4c26d30416b3a01ba8abc1445ccfae5609825b4d"
		score = 90
		quality = 85
		tags = "FILE"

	strings:
		$x1 = ");eval/*asf" ascii

	condition:
		filesize < 600KB and 1 of them
}
rule SIGNATURE_BASE_WEBSHELL_ASPX_Proxyshell_Aug15 : FILE
{
	meta:
		description = "Webshells iisstart.aspx and Logout.aspx"
		author = "Moritz Oettle"
		id = "b1e6c0f3-787f-59b8-8123-4045522047ca"
		date = "2021-09-04"
		modified = "2025-11-03"
		reference = "https://github.com/hvs-consulting/ioc_signatures/tree/main/Proxyshell"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_proxyshell.yar#L121-L152"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "46c37f1d80c777acafa6ee64d7df18a6b94768f4463d9196027111a84a63a24f"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$g1 = "language=\"JScript\"" ascii
		$g2 = "function getErrorWord" ascii
		$g3 = "errorWord" ascii
		$g4 = "Response.Redirect" ascii
		$g5 = "function Page_Load" ascii
		$g6 = "runat=\"server\"" ascii
		$g7 = "Request[" ascii
		$g8 = "eval/*" ascii
		$s1 = "AppcacheVer" ascii
		$s3 = "LaTkWfI64XeDAXZS6pU1KrsvLAcGH7AZOQXjrFkT816RnFYJQR" ascii
		$fp1 = "<input type=\"submit\" Value=\"Refresh This Page\""

	condition:
		filesize < 1KB and ( 1 of ( $s* ) or 4 of ( $g* ) ) and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_WEBSHELL_Mailbox_Export_PST_Proxyshell_Aug26 : FILE
{
	meta:
		description = "Webshells generated by an Mailbox export to PST and stored as aspx: 570221043.aspx 689193944.aspx luifdecggoqmansn.aspx"
		author = "Moritz Oettle"
		id = "6aea414f-d27c-5202-84f8-b8620782fc90"
		date = "2021-09-04"
		modified = "2025-11-03"
		reference = "https://github.com/hvs-consulting/ioc_signatures/tree/main/Proxyshell"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_proxyshell.yar#L154-L180"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "07acbf74a4bf169fc128cd085759f33e89917e217703b3c6557ba5f954822fd4"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "!BDN"
		$g1 = "Page language=" ascii
		$g2 = "<%@ Page" ascii
		$g3 = "Request.Item[" ascii
		$g4 = "\"unsafe\");" ascii
		$g5 = "<%eval(" ascii
		$g6 = "script language=" ascii
		$g7 = "Request[" ascii
		$s1 = "gold8899" ascii
		$s2 = "exec_code" ascii
		$s3 = "orangenb" ascii

	condition:
		filesize < 500KB and $x1 at 0 and ( 1 of ( $s* ) or 3 of ( $g* ) )
}
rule SIGNATURE_BASE_SUSP_IIS_Config_Proxyshell_Artifacts : FILE
{
	meta:
		description = "Detects suspicious virtual directory configured in IIS pointing to a ProgramData folder (as found in attacks against Exchange servers in August 2021)"
		author = "Florian Roth (Nextron Systems)"
		id = "bde65d9e-b17d-5746-8d29-8419363d0511"
		date = "2021-08-25"
		modified = "2025-11-03"
		reference = "https://www.huntress.com/blog/rapid-response-microsoft-exchange-servers-still-vulnerable-to-proxyshell-exploit"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_proxyshell.yar#L186-L201"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f2822a2b762c8e683c5e3a3f4a8232faa187b9a36182ea71e5286158b0e8115c"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "<site name=" ascii
		$a2 = "<sectionGroup name=\"system.webServer\">" ascii
		$s1 = " physicalPath=\"C:\\ProgramData\\" ascii

	condition:
		filesize < 500KB and all of ( $a* ) and 1 of ( $s* )
}
rule SIGNATURE_BASE_WEBSHELL_Proxyshell_Exploitation_Nov21_1
{
	meta:
		description = "Detects webshells dropped by DropHell malware"
		author = "Florian Roth (Nextron Systems)"
		id = "300eaadf-db0c-5591-84fc-abdf7cdd90c1"
		date = "2021-11-01"
		modified = "2025-11-03"
		reference = "https://www.deepinstinct.com/blog/do-not-exchange-it-has-a-shell-inside"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/expl_proxyshell.yar#L257-L271"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "d9812d3f53c346c4e318609e0c7de66811b27ffa7528a6ddeb6ac8436da59ef5"
		score = 85
		quality = 85
		tags = ""

	strings:
		$s01 = ".LoadXml(System.Text.Encoding.UTF8.GetString(System.Convert.FromBase64String(Request[" ascii wide
		$s02 = "new System.IO.MemoryStream()" ascii wide
		$s03 = "Transform(" ascii wide

	condition:
		all of ( $s* )
}
rule SIGNATURE_BASE_MAL_Litellm_Supplychain_Mar26 : FILE
{
	meta:
		description = "Detects malicious indicators used in LiteLLM supply chain attack"
		author = "Marius Benthin"
		id = "a6ea2621-af92-591c-89e1-5be6efe9f6b8"
		date = "2026-03-28"
		modified = "2026-05-15"
		reference = "https://github.com/BerriAI/litellm/issues/24512"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_teampcp_mar26.yar#L1-L17"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "71e35aef03099cd1f2d6446734273025a163597de93912df321ef118bf135238"
		logic_hash = "4bf25020a0daebda3731a23e6a4191e0d83ff746a2482b6e0394d4c6a8f5c4b0"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "exec(base64.b64decode("
		$s2 = "litellm." base64
		$s3 = "subprocess.DEVNULL"

	condition:
		filesize < 500KB and all of them
}
rule SIGNATURE_BASE_MAL_Telnyx_Supplychain_Mar26 : FILE
{
	meta:
		description = "Detects malicious indicators used in Telnyx supply chain attack"
		author = "Marius Benthin"
		id = "73d9c3d4-7274-5278-aea3-7e921bf5d0b2"
		date = "2026-03-28"
		modified = "2026-05-15"
		reference = "https://www.aikido.dev/blog/telnyx-pypi-compromised-teampcp-canisterworm"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_teampcp_mar26.yar#L19-L36"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "ab4c4aebb52027bf3d2f6b2dcef593a1a2cff415774ea4711f7d6e0aa1451d4e"
		logic_hash = "fac4c1a120bd8b046b2cfee677eff47fec6a9347a5a90648b07918337accc9cc"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "bXNidWlsZC5leGU="
		$s2 = "TW96aWxsY"
		$s3 = ".getnframes("
		$s4 = "exec(base64.b64decode("

	condition:
		filesize < 500KB and 3 of them
}
rule SIGNATURE_BASE_SUSP_OBFUSC_Powershell_True_Jun20_1 : FILE
{
	meta:
		description = "Detects indicators often found in obfuscated PowerShell scripts. Note: This detection is based on common characteristics typically associated with the mentioned threats, must be considered a clue and does not conclusively prove maliciousness."
		author = "Florian Roth (Nextron Systems)"
		id = "e9bb870b-ad72-57d3-beff-2f84a81490eb"
		date = "2020-06-27"
		modified = "2025-02-12"
		reference = "https://github.com/corneacristian/mimikatz-bypass/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_powershell_obfuscation.yar#L57-L75"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "8f33762e6e93fcf6b423b34eb1abefae2ae91b51048303947f7c1601823630d7"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$ = "${t`rue}" ascii nocase
		$ = "${tr`ue}" ascii nocase
		$ = "${tru`e}" ascii nocase
		$ = "${t`ru`e}" ascii nocase
		$ = "${tr`u`e}" ascii nocase
		$ = "${t`r`ue}" ascii nocase
		$ = "${t`r`u`e}" ascii nocase

	condition:
		filesize < 6000KB and 1 of them
}

rule SIGNATURE_BASE_MAL_CRIME_RAT_WIN_PE_Godrat_Aug25 : GODRAT RAT WINDOWS GH0ST_RAT GETGOD FILE
{
	meta:
		description = "Detects GodRAT malware targeting Windows systems"
		author = "Arda Buyukkaya"
		id = "e6ec0af5-71d3-520a-a671-8634ac2f926f"
		date = "2025-08-23"
		modified = "2026-05-15"
		reference = "https://securelist.com/godrat/117119/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_crime_win_pe_godrat_aug25.yar#L4-L80"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "154e800ed1719dbdcb188c00d5822444717c2a89017f2d12b8511eeeda0c2f41"
		logic_hash = "eda3175277bbf9f6408f5d2dd25d6780552aad4104fe62bb92125c734f9fdd98"
		score = 75
		quality = 83
		tags = "GODRAT, RAT, WINDOWS, GH0ST RAT, GETGOD, FILE"
		family = "GodRAT"
		victims = "Financial services"

	strings:
		$winrt_txt = "C++/WinRT version" ascii wide nocase
		$api_blob = {
         4E 74 43 72 65 61 74 65 53 65 63 74 69 6F 6E 00                          // NtCreateSection
         4E 74 4D 61 70 56 69 65 77 4F 66 53 65 63 74 69 6F 6E 00 00              // NtMapViewOfSection
         4E 74 55 6E 6D 61 70 56 69 65 77 4F 66 53 65 63 74 69 6F 6E 00 00 00 00  // NtUnmapViewOfSection
      }
		$ld_movups = { 0F 10 05 ?? ?? ?? ?? }
		$ld_movq = { F3 0F 7E 05 ?? ?? ?? ?? }
		$st_movups = { 0F 11 85 ?? ?? ?? ?? }
		$st_movq = { 66 0F D6 85 ?? ?? ?? ?? }
		$scan_loop = { 8A 01 41 84 C0 75 F9 }
		$cmp_len_770 = { 81 FF 70 07 00 00 0F 82 ?? ?? ?? ?? }
		$cmp_len_76C = { 81 FF 6C 07 00 00 0F 82 ?? ?? ?? ?? }

	condition:
		pe.is_pe and filesize <= 10MB and ( ( $winrt_txt and ( pe.imphash ( ) == "0f4b0270c84616ce594b6a84c47a7717" ) ) or ( ( $ld_movups or $ld_movq ) and ( ( #st_movups >= 2 ) or ( #st_movq >= 2 ) or ( #st_movups >= 1 and #st_movq >= 1 ) ) and $scan_loop and $api_blob and ( $cmp_len_770 or $cmp_len_76C ) ) or pe.imphash ( ) == "ee5ea868d8233000216e7b29bc8cb4e2" )
}
rule SIGNATURE_BASE_SUSP_NET_Msil_Suspicious_Use_Strreverse : FILE
{
	meta:
		description = "Detects mixed use of Microsoft.CSharp and VisualBasic to use StrReverse"
		author = "dr4k0nia, modified by Florian Roth"
		id = "830dec40-4412-59c1-8b4d-a237f14acd30"
		date = "2023-01-31"
		modified = "2023-02-22"
		reference = "https://github.com/dr4k0nia/yara-rules"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_susp_net_msil.yar#L2-L31"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "02ce0980427dea835fc9d9eed025dd26672bf2c15f0b10486ff8107ce3950701"
		logic_hash = "a7440600ee4826568d465d204e0a602f61752e4ffcfa3b4f29e5bc81c4d67b46"
		score = 70
		quality = 85
		tags = "FILE"
		version = "1.1"

	strings:
		$a1 = ", PublicKeyToken="
		$a2 = ".NETFramework,Version="
		$csharp = "Microsoft.CSharp"
		$vbnet = "Microsoft.VisualBasic"
		$strreverse = "StrReverse"

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 50MB and all of ( $a* ) and $csharp and $vbnet and $strreverse
}
rule SIGNATURE_BASE_APT_Nazar_Svchost_Commands
{
	meta:
		description = "Detects Nazar's svchost based on supported commands"
		author = "Itay Cohen"
		id = "3e02381d-de03-50c8-8bde-2974ee96b7c1"
		date = "2020-04-26"
		modified = "2023-12-05"
		reference = "https://www.epicturla.com/blog/the-lost-nazar"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_nazar.yar#L1-L18"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "2fe9b76496a9480273357b6d35c012809bfa3ae8976813a7f5f4959402e3fbb6"
		hash = "be624acab7dfe6282bbb32b41b10a98b6189ab3a8d9520e7447214a7e5c27728"
		logic_hash = "c71e8a3b2d69c51ed3f822f62b90906fc0a21d32f1f1850cdef71c335964f9b1"
		score = 75
		quality = 85
		tags = ""

	strings:
		$str1 = { 33 31 34 00 36 36 36 00 33 31 33 00 }
		$str2 = { 33 31 32 00 33 31 35 00 35 35 35 00 }
		$str3 = { 39 39 39 00 35 39 39 00 34 39 39 00 }
		$str4 = { 32 30 39 00 32 30 31 00 32 30 30 00 }
		$str5 = { 31 39 39 00 31 31 39 00 31 38 39 00 31 33 39 00 33 31 31 00 }

	condition:
		4 of them
}
rule SIGNATURE_BASE_APT_MAL_LNX_Turla_Apr20_1 : FILE
{
	meta:
		description = "Detects Turla Linux malware"
		author = "Florian Roth (Nextron Systems)"
		id = "f21e7793-a7dd-5195-805d-963827b35808"
		date = "2020-04-05"
		modified = "2023-12-05"
		reference = "https://twitter.com/Int2e_/status/1246115636331319309"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_turla.yar#L252-L272"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "67d9556c695ef6c51abf6fbab17acb3466e3149cf4d20cb64d6d34dc969b6502"
		hash = "8ccc081d4940c5d8aa6b782c16ed82528c0885bbb08210a8d0a8c519c54215bc"
		logic_hash = "d463f5a151bb0c3440d719b4c7c0d1ca34de1e0bed7fb9167ecf396607abd3ff"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "/root/.hsperfdata" ascii fullword
		$s2 = "Desc|     Filename     |  size  |state|" ascii fullword
		$s3 = "IPv6 address %s not supported" ascii fullword
		$s4 = "File already exist on remote filesystem !" ascii fullword
		$s5 = "/tmp/.sync.pid" ascii fullword
		$s6 = "'gateway' supported only on ethernet/FDDI/token ring/802.11/ATM LANE/Fibre Channel" ascii fullword

	condition:
		uint16( 0 ) == 0x457f and filesize < 5000KB and 4 of them
}
rule SIGNATURE_BASE_APT_MAL_Tinyturla_Sep21_1 : FILE
{
	meta:
		description = "Detects Tiny Turla backdoor DLL"
		author = "Cisco Talos"
		id = "19659ac7-310a-52dd-a94c-022c7add752b"
		date = "2021-09-21"
		modified = "2023-12-05"
		reference = "https://blog.talosintelligence.com/2021/09/tinyturla.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/apt_turla.yar#L275-L295"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "030cbd1a51f8583ccfc3fa38a28a5550dc1c84c05d6c0f5eb887d13dedf1da01"
		logic_hash = "ede598374bc4a8a870aa29498be4200b4a3d7b289dfcb680fb3f91108d212bca"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$a = "Title: " fullword wide
		$b = "Hosts" fullword wide
		$c = "Security" fullword wide
		$d = "TimeLong" fullword wide
		$e = "TimeShort" fullword wide
		$f = "MachineGuid" fullword wide
		$g = "POST" fullword wide
		$h = "WinHttpSetOption" fullword ascii
		$i = "WinHttpQueryDataAvailable" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 25KB and all of them
}
rule SIGNATURE_BASE_MAL_Win_Amadey_Jun25 : FILE
{
	meta:
		description = "This rule detects intrinsic patterns of Amadey version 5.34"
		author = "0x0d4y"
		id = "853111b8-e548-46a9-8f5a-ec8621343e0d"
		date = "2025-06-18"
		modified = "2026-05-15"
		reference = "https://0x0d4y.blog/amadey-targeted-analysis/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/mal_win_amadey_jun25.yar#L1-L23"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "08dc17aa8f7e83bc349339a9a1b48184b094d8c66273d7199a15b206c6416946"
		score = 80
		quality = 85
		tags = "FILE"
		yarahub_reference_md5 = "1db72c5832fb71b29863ccc3125137a0"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"
		malpedia_family = "win.amadey"

	strings:
		$rc4_algorithm = { 8a 96 ?? ?? ?? ?? 0f b6 86 ?? ?? ?? ?? 03 f8 0f b6 ca 03 f9 81 e7 ff 00 00 80 79 ?? 4f 81 cf 00 ff ff ff 47 8a 87 ?? ?? ?? ?? 88 86 ?? ?? ?? ?? 46 88 97 ?? ?? ?? ?? 81 fe 00 01 00 00 7c }
		$s_MZ_PE_validation = { b8 4d 5a ?? ?? 66 39 06 0f 85 a8 01 ?? ?? 8b 7e 3c 03 fe 81 3f 50 45 00 00  }
		$s_loop_through_pe_section = { 8b 4c 24 0c 03 ce 03 4e 3c 6a ?? ff b1 08 01 ?? ?? 8b 81 0c 01 00 00 03 c6 50 8b 81 04 01 ?? ?? 03 44 24 20 50 ff 74 24 30 ff 15 f4 f0 44 00 8b 4c 24 10 0f b7 47 06 41 83 44 24 0c 28 89 4c 24 10 3b c8 }
		$s_str_decryption_algorithm = { 8b cb 0f 43 35 ?? ?? ?? ?? 2b c8 8d 04 0a 33 d2 f7 f3 }

	condition:
		uint16( 0 ) == 0x5a4d and $rc4_algorithm and 2 of ( $s* )
}
rule SIGNATURE_BASE_SUSP_Gobfuscate_May21 : FILE
{
	meta:
		description = "Identifies binaries obfuscated with gobfuscate"
		author = "James Quinn, Paul Hager (merged with new similar pattern)"
		id = "ae518296-b1c3-568c-bae0-3e0a6f7600ba"
		date = "2021-05-14"
		modified = "2024-04-02"
		reference = "https://github.com/unixpickle/gobfuscate"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/gen_gobfuscate.yar#L2-L18"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		logic_hash = "f71078dd6354a482a2ead2f0d25f4172cd40e62440a70c2da7916b68f26909a3"
		score = 70
		quality = 85
		tags = "FILE"

	strings:
		$s1 = { 0F B6 ?? ?? ?? 0F B6 ?? ?? ?? 31 D? [0-1] 88 ?? ?? ?? 48 FF C? 48 83 F? ?? 7C E6 48 }
		$s2 = { 0F B6 ?? ?? ?? 31 DA 88 ?? ?? ?? 40 83 ?? ?? 7D 09 0F B6 }

	condition:
		filesize < 50MB and any of them
}
rule SIGNATURE_BASE_REGEORG_Tuneller_Generic : FILE
{
	meta:
		description = "No description has been set in the source file - Signature Base"
		author = "Mandiant"
		id = "a87979b7-2732-5a32-b3f3-a815a58b6589"
		date = "2021-12-20"
		modified = "2023-12-05"
		reference = "https://www.mandiant.com/resources/unc3524-eye-spy-email"
		source_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/yara/webshell_regeorg.yar#L1-L20"
		license_url = "https://github.com/Neo23x0/signature-base/blob/78d979eef87786a613659ee82e55abdd45572a78/LICENSE"
		hash = "ba22992ce835dadcd06bff4ab7b162f9"
		logic_hash = "1657928875c3cd2d5bf774929b0497d78f0211b321f8a4138cc9b8c80b9f99d6"
		score = 75
		quality = 85
		tags = "FILE"
		date_modified = "2021-12-20"

	strings:
		$s1 = "System.Net.IPEndPoint"
		$s2 = "Response.AddHeader"
		$s3 = "Request.InputStream.Read"
		$s4 = "Request.Headers.Get"
		$s5 = "Response.Write"
		$s6 = "System.Buffer.BlockCopy"
		$s7 = "Response.BinaryWrite"
		$s8 = "SocketException soex"

	condition:
		filesize < 1MB and 7 of them
}
