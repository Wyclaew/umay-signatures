/*
    Umay heuristics: Windows batch files, Windows Script Host (JScript,
    VBScript), HTA, and shortcut files that carry a command line.
*/

rule Windows_LolbinDownload
{
    meta:
        umay_name = "Heur.Windows.LolbinDownload"
        umay_weight = 40
        description = "Uses a built-in Windows tool to download or decode a file, avoiding a visible downloader"
    strings:
        $certutil = /certutil(\.exe)?\s+[^\r\n]{0,60}-(urlcache|decode|decodehex)\b/ nocase ascii wide
        $bits = /bitsadmin(\.exe)?\s+[^\r\n]{0,40}\/transfer\b/ nocase ascii wide
        $curl = /\bcurl(\.exe)?\s+[^\r\n]{0,200}-o\s+[^\r\n]{0,80}(%temp%|%appdata%|\\AppData\\|\\Temp\\)/ nocase ascii wide
    condition:
        (umay_kind == "script" or umay_kind == "lnk" or umay_derived) and filesize < 5MB and any of them
}

rule Windows_ProxyExecution
{
    meta:
        umay_name = "Heur.Windows.ProxyExecution"
        umay_weight = 55
        description = "Runs remote or inline script through a trusted Windows program to slip past controls"
    strings:
        $mshta = /mshta(\.exe)?\s+["']?(https?:|javascript:|vbscript:)/ nocase ascii wide
        $regsvr = /regsvr32(\.exe)?\s+[^\r\n]{0,80}\/i:https?:/ nocase ascii wide
        $rundll = /rundll32(\.exe)?\s+[^\r\n]{0,40}(javascript:|vbscript:)/ nocase ascii wide
        $wmic = /wmic(\.exe)?\s+[^\r\n]{0,80}\/format:\s*["']?https?:/ nocase ascii wide
    condition:
        (umay_kind == "script" or umay_kind == "lnk" or umay_derived) and filesize < 5MB and any of them
}

rule Windows_DisableRecoveryAndLogs
{
    meta:
        umay_name = "Heur.Windows.DisableRecoveryAndLogs"
        umay_weight = 60
        description = "Deletes backups, disables recovery or wipes event logs, as ransomware does before encrypting"
    strings:
        $vss = /vssadmin(\.exe)?\s+delete\s+shadows/ nocase ascii wide
        $wmic = /wmic(\.exe)?\s+shadowcopy\s+delete/ nocase ascii wide
        $wbadmin = /wbadmin(\.exe)?\s+delete\s+(catalog|systemstatebackup)/ nocase ascii wide
        $bcd1 = /bcdedit(\.exe)?\s+[^\r\n]{0,60}recoveryenabled\s+no/ nocase ascii wide
        $bcd2 = /bcdedit(\.exe)?\s+[^\r\n]{0,60}bootstatuspolicy\s+ignoreallfailures/ nocase ascii wide
        $logs = /wevtutil(\.exe)?\s+cl\s+/ nocase ascii wide
    condition:
        (umay_kind == "script" or umay_kind == "lnk" or umay_derived) and filesize < 5MB and any of them
}

rule Windows_FirewallOrDefenderOff
{
    meta:
        umay_name = "Heur.Windows.SecurityControlsOff"
        umay_weight = 45
        description = "Turns off the Windows firewall or Defender from a script"
    strings:
        $fw = /netsh(\.exe)?\s+advfirewall\s+set\s+[a-z]+\s+state\s+off/ nocase ascii wide
        $reg = /reg(\.exe)?\s+add\s+[^\r\n]{0,120}Windows Defender[^\r\n]{0,120}Disable(AntiSpyware|RealtimeMonitoring|BehaviorMonitoring)/ nocase ascii wide
        $svc = /sc(\.exe)?\s+(stop|config)\s+WinDefend/ nocase ascii wide
    condition:
        (umay_kind == "script" or umay_derived) and filesize < 5MB and any of them
}

rule Windows_AutorunPersistence
{
    meta:
        umay_name = "Heur.Windows.AutorunPersistence"
        umay_weight = 30
        description = "Registers a script or a file in a user-writable folder to start with Windows"
    strings:
        $run = /reg(\.exe)?\s+add\s+[^\r\n]{0,80}\\CurrentVersion\\Run(Once)?\b[^\r\n]{0,300}(powershell|mshta|wscript|cscript|\\AppData\\|\\Temp\\|%temp%|%appdata%)/ nocase ascii wide
        $task = /schtasks(\.exe)?\s+\/create\b[^\r\n]{0,300}(powershell|mshta|wscript|cscript|\\AppData\\|\\Temp\\|%temp%|%appdata%)/ nocase ascii wide
    condition:
        (umay_kind == "script" or umay_derived) and filesize < 5MB and any of them
}

rule WSH_DownloaderDropper
{
    meta:
        umay_name = "Heur.WSH.Dropper"
        umay_weight = 50
        description = "Script that downloads a file with COM objects, writes it to disk and runs it"
    strings:
        $shell = "WScript.Shell" nocase ascii wide
        $http1 = "MSXML2.XMLHTTP" nocase ascii wide
        $http2 = "Microsoft.XMLHTTP" nocase ascii wide
        $http3 = "WinHttp.WinHttpRequest" nocase ascii wide
        $http4 = "MSXML2.ServerXMLHTTP" nocase ascii wide
        $save = "ADODB.Stream" nocase ascii wide
        $run1 = /\.Run\s*\(?/ nocase ascii wide
        $run2 = "ShellExecute" nocase ascii wide
        $run3 = /\.Exec\s*\(/ nocase ascii wide
    condition:
        (umay_kind == "script" or umay_kind == "html" or umay_derived) and filesize < 5MB
        and any of ($http*) and ($save or $shell) and any of ($run*)
}

rule WSH_CharCodeObfuscation
{
    meta:
        umay_name = "Heur.WSH.CharCodeObfuscation"
        umay_weight = 25
        description = "Builds its code character by character at run time and then evaluates it"
    strings:
        $eval = /\b(eval|execute|executeglobal)\s*\(/ nocase ascii wide
        $js = "String.fromCharCode" nocase ascii wide
        $vbs = /chrw?\s*\(\s*[0-9]{1,5}\s*\)\s*&\s*chrw?\s*\(/ nocase ascii wide
    condition:
        (umay_kind == "script" or umay_kind == "html" or umay_derived) and filesize < 5MB
        and $eval and (#js > 8 or #vbs > 8)
}

rule Shortcut_RunsInterpreter
{
    meta:
        umay_name = "Heur.Shortcut.RunsInterpreter"
        umay_weight = 45
        description = "Shortcut that launches a script interpreter with a download or hidden-window command line"
    strings:
        $i1 = "powershell" nocase ascii wide
        $i2 = "cmd.exe" nocase ascii wide
        $i3 = "mshta" nocase ascii wide
        $i4 = "wscript" nocase ascii wide
        $i5 = "cscript" nocase ascii wide
        $i6 = "rundll32" nocase ascii wide
        $a1 = "http://" nocase ascii wide
        $a2 = "https://" nocase ascii wide
        $a3 = "-enc" nocase ascii wide
        $a4 = "hidden" nocase ascii wide
        $a5 = "bypass" nocase ascii wide
        $a6 = "FromBase64String" nocase ascii wide
        $a7 = "DownloadString" nocase ascii wide
    condition:
        umay_kind == "lnk" and filesize < 1MB and any of ($i*) and any of ($a*)
}
