import "dotnet"
import "hash"
import "pe"

rule GCTI_Cobaltstrike_Resources_Covertvpn_Dll_V2_1_To_V4_X
{
	meta:
		description = "Cobalt Strike's resources/covertvpn.dll signature for version v2.2 to v4.4"
		author = "gssincla@google.com"
		id = "a65b855c-5703-5b9f-bb57-da8ebf898f9b"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Covertvpn_Dll_v2_1_to_v4_x.yara#L17-L120"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "0a452a94d53e54b1df6ba02bc2f02e06d57153aad111171a94ec65c910d22dcf"
		logic_hash = "1f6e4254fdfd4f9b13c2000333aabbb7da90d2df7ee1b12faa6ea3c066351468"
		score = 75
		quality = 85
		tags = ""

	strings:
		$dropComponentsAndActivateDriver_prologue = {
			5? 
			68 [4]
			68 [4]
			C7 [3-5] 00 00 00 00 
			FF 15 [4]
			50
			FF 15 [4]
			8B ?? 
			85 ?? 
			74 ??
			8D [3-5]
			5? 
			FF 15 [4]
			50
		}
		$dropFile = {
			6A 00
			5? 
			E8 [4]
			83 C4 08
			83 F8 FF
			74 ?? 
			5? 
			[0-5]
			E8 [4]
			83 C4 ??
			[0-2]
			6A 00
			68 80 01 00 00
			6A 02
			6A 00
			6A 05
			68 00 00 00 40
			5? 
			FF 15 [4]
			8B ?? 
			83 ?? FF 
			75 ?? 
			FF 15 [4]
			5? 
		}
		$nfp = "npf.sys" nocase
		$wpcap = "wpcap.dll" nocase

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Browserpivot_X64_Bin_V1_48_To_V3_14_And_Sleeve_Browserpivot_X64_Dll_V4_0_To_V4_X
{
	meta:
		description = "Cobalt Strike's resources/browserpivot.x64.bin from v1.48 to v3.14 and sleeve/browserpivot.x64.dll from v4.0 to at least v4.4"
		author = "gssincla@google.com"
		id = "a5dfae85-ff9c-5ca5-9ac0-041c6108a6ed"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Browserpivot_x64_Bin_v1_48_to_v3_14_and_Sleeve_Browserpivot_x64_Dll_v4_0_to_v4_x.yara#L17-L64"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "0ad32bc4fbf3189e897805cec0acd68326d9c6f714c543bafb9bc40f7ac63f55"
		logic_hash = "a59f19b6e258b724ed88b4255717d066319ba5fb0838d6c6ed11355e9d9b1c22"
		score = 75
		quality = 85
		tags = ""

	strings:
		$socket_recv = {
			FF 15 [4]
			83 ?? FF
			74 ??
			85 ??
			74 ??
			03 ??
			83 ?? 02
			72 ??
			8D ?? FF
			80 [2] 0A
			75 ??
			8D ?? FE
			80 [2] 0D
		}
		$fmt = "%1024[^ ] %8[^:]://%1016[^/]%7168[^ ] %1024[^ ]"

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Bind_Bin_V2_5_Through_V4_X
{
	meta:
		description = "Cobalt Strike's resources/bind.bin signature for versions 2.5 to 4.x"
		author = "gssincla@google.com"
		id = "32f129c1-9845-5843-9e16-7d9af217b8e2"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Bind_Bin_v2_5_through_v4_x.yara#L17-L111"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "3727542c0e3c2bf35cacc9e023d1b2d4a1e9e86ee5c62ee5b66184f46ca126d1"
		logic_hash = "cf04e257590cf0673059348f5c15926918eb8aee40e864ae65979360aca80013"
		score = 75
		quality = 85
		tags = ""

	strings:
		$apiLocator = {
			31 ?? 
			AC
			C1 ?? 0D 
			01 ?? 
			38 ?? 
			75 ?? 
			03 [2]
			3B [2]
			75 ?? 
			5? 
			8B ?? 24 
			01 ?? 
			66 8B [2]
			8B ?? 1C 
			01 ?? 
			8B ?? 8B 
			01 ?? 
			89 [3]
			5? 
			5? 
		}
		$ws2_32 = {
			5D
			68 33 32 00 00
			68 77 73 32 5F
		}
		$listenaccept = {
			5? 
			5? 
			68 B7 E9 38 FF
			FF ?? 
			5? 
			5? 
			5? 
			68 74 EC 3B E1
		}

	condition:
		$apiLocator and $ws2_32 and $listenaccept
}
rule GCTI_Cobaltstrike_Resources_Template__X32_X64_Ps1_V1_45_To_V2_5_And_V3_11_To_V3_14
{
	meta:
		description = "Cobalt Strike's resources/template.x64.ps1, resources/template.x32 from v3.11 to v3.14 and resources/template.ps1 from v1.45 to v2.5 "
		author = "gssincla@google.com"
		id = "c9fa6a39-0098-5dde-9762-94bc6b2df299"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Template__x32_x64_Ps1_v1_45_to_v2_5_and_v3_11_to_v3_14.yara#L17-L43"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "ff743027a6bcc0fee02107236c1f5c96362eeb91f3a5a2e520a85294741ded87"
		logic_hash = "5196f111f257239d2e7e4ca342e7fc8bac1687743bc8c7ff23addf1f094b2e93"
		score = 75
		quality = 85
		tags = ""

	strings:
		$importVA = "[DllImport(\"kernel32.dll\")] public static extern IntPtr VirtualAlloc" nocase
		$importCT = "[DllImport(\"kernel32.dll\")] public static extern IntPtr CreateThread" nocase
		$importWFSO = "[DllImport(\"kernel32.dll\")] public static extern int WaitForSingleObject" nocase
		$compiler = "New-Object Microsoft.CSharp.CSharpCodeProvider" nocase
		$params = "New-Object System.CodeDom.Compiler.CompilerParameters" nocase
		$paramsSys32 = ".ReferencedAssemblies.AddRange(@(\"System.dll\", [PsObject].Assembly.Location))" nocase
		$paramsGIM = ".GenerateInMemory = $True" nocase
		$result = "$compiler.CompileAssemblyFromSource($params, $assembly)" nocase

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Template_Sct_V3_3_To_V4_X
{
	meta:
		description = "Cobalt Strike's resources/template.sct signature for versions v3.3 to v4.x"
		author = "gssincla@google.com"
		id = "9d2b1dfa-5f76-503f-9198-6ed0d039e0cb"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Template_Sct_v3_3_to_v4_x.yara#L17-L38"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "fc66cb120e7bc9209882620f5df7fdf45394c44ca71701a8662210cf3a40e142"
		logic_hash = "8868445ced4945c469764b7f311d6cb11c99cf0f2d770113e5e617e0187a962c"
		score = 75
		quality = 85
		tags = ""

	strings:
		$scriptletstart = "<scriptlet>" nocase
		$registration = "<registration progid=" nocase
		$classid = "classid=" nocase
		$scriptlang = "<script language=\"vbscript\">" nocase
		$cdata = "<![CDATA["
		$scriptend = "</script>" nocase
		$antiregistration = "</registration>" nocase
		$scriptletend = "</scriptlet>"

	condition:
		all of them and @scriptletstart [ 1 ] < @registration [ 1 ] and @registration [ 1 ] < @classid [ 1 ] and @classid [ 1 ] < @scriptlang [ 1 ] and @scriptlang [ 1 ] < @cdata [ 1 ]
}
rule GCTI_Cobaltstrike_Resources_Httpstager64_Bin_V3_2_Through_V4_X
{
	meta:
		description = "Cobalt Strike's resources/httpstager64.bin signature for versions v3.2 to v4.x"
		author = "gssincla@google.com"
		id = "5530dce8-e5a1-5133-9b05-464e3397084a"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Httpstager64_Bin_v3_2_through_v4_x.yara#L17-L85"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "ad93d1ee561bc25be4a96652942f698eac9b133d8b35ab7e7d3489a25f1d1e76"
		logic_hash = "23666169565c6b3e5fa71767dc31096e7a25be049eeab16b074053d76c97c70b"
		score = 75
		quality = 85
		tags = ""

	strings:
		$apiLocator = {
			48 [2]
			AC
			41 [2] 0D
			41 [2]
			38 ??
			75 ??
			4C [4]
			45 [2]
			75 ??
			5?
			44 [2] 24
			49 [2]
			66 [4]
			44 [2] 1C
			49 [2]
			41 [3]
			48 
		}
		$postInternetOpenJmp = {
			41 ?? 3A 56 79 A7
			FF ??
			EB 
		}

	condition:
		$apiLocator and $postInternetOpenJmp
}
rule GCTI_Cobaltstrike_Resources_Elevate_X64_Dll_V3_0_To_V3_14_And_Sleeve_Elevate_X64_Dll_V4_X
{
	meta:
		description = "Cobalt Strike's resources/elevate.x64.dll signature for v3.0 to v3.14 and sleeve/elevate.x64.dll for v4.x"
		author = "gssincla@google.com"
		id = "91d5c343-1084-5cfc-9dfa-46f530eb9625"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Elevate_X64_Dll_v3_0_to_v3_14_and_Sleeve_Elevate_X64_Dll_v4_x.yara#L17-L71"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "c3ee8a9181fed39cec3bd645b32b611ce98d2e84c5a9eff31a8acfd9c26410ec"
		logic_hash = "6f23bcf6a0c360d2f83140ce633440b13d8b691e75c5560c65656cf8a6114224"
		score = 75
		quality = 85
		tags = ""

	strings:
		$wnd_proc = {
			81 ?? 21 01 00 00
			75 ??
			83 [5] 00
			75 ??
			45 33 ??
			8D [2]
			C7 [5] 01 00 00 00
			45 [2] 28
			FF 15 [4]
			45 33 ??
			8D [2]
			45 [2] 27
			48 [2]
			FF 15 [4]
			45 33 ??
			45 33 ??
			BA 01 02 00 00
			48 
		}

	condition:
		$wnd_proc
}
rule GCTI_Cobaltstrike_Resources_Httpstager_Bin_V2_5_Through_V4_X
{
	meta:
		description = "Cobalt Strike's resources/httpstager.bin signature for versions 2.5 to 4.x"
		author = "gssincla@google.com"
		id = "86109485-c26c-5c51-8d04-dd1add9a8c57"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Httpstager_Bin_v2_5_through_v4_x.yara#L17-L93"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "a47569af239af092880751d5e7b68d0d8636d9f678f749056e702c9b063df256"
		logic_hash = "3baab08b0118e00432f1869ba5daa4fc6383bfc020119bfbb3047a008c33fe72"
		score = 75
		quality = 85
		tags = ""

	strings:
		$apiLocator = {
			31 ?? 
			AC
			C1 ?? 0D 
			01 ?? 
			38 ?? 
			75 ?? 
			03 [2]
			3B [2]
			75 ?? 
			5? 
			8B ?? 24 
			01 ?? 
			66 8B [2]
			8B ?? 1C 
			01 ?? 
			8B ?? 8B 
			01 ?? 
			89 [3]
			5? 
			5? 
		}
		$downloaderLoop = {
			B? 00 2F 00 00 
			39 ?? 
			74 ?? 
			31 ?? 
			( E9 | EB )
		}

	condition:
		$apiLocator and $downloaderLoop
}
rule GCTI_Cobaltstrike__Resources_Browserpivot_Bin_V1_48_To_V3_14_And_Sleeve_Browserpivot_Dll_V4_0_To_V4_X
{
	meta:
		description = "Cobalt Strike's resources/browserpivot.bin from v1.48 to v3.14 and sleeve/browserpivot.dll from v4.0 to at least v4.4"
		author = "gssincla@google.com"
		id = "55086544-6684-526b-914f-505a562be458"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Browserpivot_Bin_v1_48_to_v3_14_and_Sleeve_Browserpivot_Dll_v4_0_to_v4_x.yara#L17-L60"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "12af9f5a7e9bfc49c82a33d38437e2f3f601639afbcdc9be264d3a8d84fd5539"
		logic_hash = "416554d31c105fd96aeaef508847efe2889590909c8d0025e3862e5b24078131"
		score = 75
		quality = 85
		tags = ""

	strings:
		$socket_recv = {
			FF [1-5]
			83 ?? FF 
			74 ?? 
			85 C0
			(74 | 76) ?? 
			03 ?? 
			83 ?? 02 
			72 ?? 
			80 ?? 3E FF 0A 
			75 ?? 
			80 ?? 3E FE 0D 
		}
		$fmt = "%1024[^ ] %8[^:]://%1016[^/]%7168[^ ] %1024[^ ]"

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Artifact32_And_Resources_Dropper_V1_49_To_V3_14
{
	meta:
		description = "Cobalt Strike's resources/artifact32{.exe,.dll,big.exe,big.dll} and resources/dropper.exe signature for versions 1.49 to 3.14"
		author = "gssincla@google.com"
		id = "243e3761-cbea-561c-97da-f6ba12ebc7ee"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Artifact32_and_Resources_Dropper_v1_45_to_v4_x.yara#L17-L32"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "40fc605a8b95bbd79a3bd7d9af73fbeebe3fada577c99e7a111f6168f6a0d37a"
		logic_hash = "437706c808bca28384a6e8e24fa3ae120a4ebe4166fa4ca3564c58b881fb23a8"
		score = 75
		quality = 85
		tags = ""

	strings:
		$payloadDecoder = { 8B [2] 89 ?? 03 [2] 8B [2] 03 [2] 0F B6 18 8B [2] 89 ?? C1 ?? 1F C1 ?? 1E 01 ?? 83 ?? 03 29 ?? 03 [2] 0F B6 00 31 ?? 88 ?? 8B [2] 89 ?? 03 [2] 8B [2] 03 [2] 0F B6 12 }

	condition:
		any of them
}
rule GCTI_Cobaltstrike_Resources_Artifact32_V3_1_And_V3_2
{
	meta:
		description = "Cobalt Strike's resources/artifact32{.dll,.exe,svc.exe,big.exe,big.dll,bigsvc.exe} and resources/artifact32uac(alt).dll signature for versions 3.1 and 3.2"
		author = "gssincla@google.com"
		id = "4fff7f42-9f50-5945-8ec0-2438ac5c7000"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Artifact32_and_Resources_Dropper_v1_45_to_v4_x.yara#L34-L60"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "4f14bcd7803a8e22e81e74d6061d0df9e8bac7f96f1213d062a29a8523ae4624"
		logic_hash = "7a0d33d0260c762b4aa67e4084d7474338c60aa684fd3e622614745d90350da8"
		score = 75
		quality = 85
		tags = ""

	strings:
		$decoderFunc = { 89 ?? B? 04 00 00 00 99 F7 FF 8B [2] 8A [2] 30 ?? 8A ?? 4? 88 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Artifact32_V3_14_To_V4_X
{
	meta:
		description = "Cobalt Strike's resources/artifact32{.dll,.exe,big.exe,big.dll,bigsvc.exe} signature for versions 3.14 to 4.x and resources/artifact32svc.exe for 3.14 to 4.x and resources/artifact32uac.dll for v3.14 and v4.0"
		author = "gssincla@google.com"
		id = "8a010305-dce5-55f4-b2dd-a736721efe22"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Artifact32_and_Resources_Dropper_v1_45_to_v4_x.yara#L62-L89"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "888bae8d89c03c1d529b04f9e4a051140ce3d7b39bc9ea021ad9fc7c9f467719"
		logic_hash = "fc5c353c568e33df80fa5bab14d11112ca211e269043b83dba8b7d1a6a008a7b"
		score = 75
		quality = 85
		tags = ""

	strings:
		$pushFmtStr = {	C7 [3] 5C 00 00 00 C7 [3] 65 00 00 00 C7 [3] 70 00 00 00 C7 [3] 69 00 00 00 C7 [3] 70 00 00 00 F7 F1 C7 [3] 5C 00 00 00  C7 [3] 2E 00 00 00 C7 [3] 5C 00 00 00 }
		$fmtStr = "%c%c%c%c%c%c%c%c%cMSSE-%d-server"

	condition:
		all of them
}
/*
 * YARA Rule Set
 * Repository Name: Malpedia
 * Repository: https://github.com/malpedia/signator-rules/
 * Retrieval Date: 2026-11-15
 * Git Commit: eddaf26a30c6daff1b2350f52d0b5c11767f7552
 * Number of Rules: 1621
 * Skipped: 0 (age), 64 (quality), 2 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * NO LICENSE SET
 */
rule MALPEDIA_Win_Sync_Scheduler_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "b30b8c8f-f672-5968-8f1a-63219fb7abb6"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.sync_scheduler"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.sync_scheduler_auto.yar#L1-L121"
		license_url = "N/A"
		logic_hash = "fb6f41e9a400a83f359d5c8334b0729f1d39ebfcdf00b5ffd406198f548f114a"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 4889742420 4533c9 4c8d05b9970000 488d15d2970000 498bcd ff15???????? }
		$sequence_1 = { 0f1185e0000000 0f57c9 f30f7f8df0000000 41b856000000 488d150c910000 488d8de0000000 e8???????? }
		$sequence_2 = { 4d3bdf 0f877e000000 498bc7 492bc3 4d85db 0f84a9000000 }
		$sequence_3 = { 488d542444 488bcb e8???????? 488bd7 488d4d88 ffd0 }
		$sequence_4 = { 0fb645ab 8bd6 0fb64415ab 8b4da7 32c8 }
		$sequence_5 = { 488d4827 483bc8 0f86d0000000 eb0e 48b90000000000000080 }
		$sequence_6 = { 33d2 b900130000 ff15???????? 488b4c2440 ff15???????? 498bcf }
		$sequence_7 = { 4883c0f8 4883f81f 0f8780000000 e8???????? 4c897df0 48c745f80f000000 c645e000 }
		$sequence_8 = { ebad ff15???????? cc 4885c9 }
		$sequence_9 = { 02ca 32c8 884c15ac 48ffc2 4883fa10 }

	condition:
		7 of them and filesize < 156672
}
rule MALPEDIA_Win_Tinytyphon_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "8401d1c7-7a44-566c-a403-1edcf7c9f03c"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.tinytyphon"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.tinytyphon_auto.yar#L1-L128"
		license_url = "N/A"
		logic_hash = "fcd0fad7aefc3a2ebd626ef8e532007ac6782fdf59d1c8aa064467c747f920b8"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 7410 8b4508 0fbe08 0fbe550c 3bca }
		$sequence_1 = { 8d8c08d9026f67 894ddc 8b55dc c1e20e 8b45dc c1e812 0bd0 }
		$sequence_2 = { 8945b0 837db000 7406 837db0ff }
		$sequence_3 = { 6800040000 ff15???????? ebee 6a00 ff15???????? 33c0 8be5 }
		$sequence_4 = { 83c101 898ddcfeffff 8b95ecfeffff 0395dcfeffff 0fb602 3d9a000000 }
		$sequence_5 = { 8b4de4 c1e909 0bc1 8945e4 8b55e4 0355dc 8955e4 }
		$sequence_6 = { 034de4 894df8 8b55f4 0fb64204 8b4df4 0fb65105 c1e208 }
		$sequence_7 = { c1e814 0bd0 8955e0 8b4de0 034df8 894de0 8b55f4 }
		$sequence_8 = { 8945dc 8b55dc 0355e0 8955dc 8b45dc 3345e0 2345f8 }
		$sequence_9 = { e8???????? 83c408 8d4db8 51 ff15???????? 8945b0 837db000 }

	condition:
		7 of them and filesize < 90112
}
rule MALPEDIA_Win_Teleport_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "41bca2b5-f89e-527a-a49f-5320a5804b93"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.teleport"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.teleport_auto.yar#L1-L125"
		license_url = "N/A"
		logic_hash = "163a58bc77652a91f892ae9a827fdf895f7bedcf69dfe5ef2accb885a20e6632"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 83c408 c7466800000000 33c0 c7466c07000000 66894658 8b4644 53 }
		$sequence_1 = { 894824 c6401c01 894dfc 8d85d0feffff b912000000 eb50 }
		$sequence_2 = { 8945c8 8d45cc 50 56 e8???????? }
		$sequence_3 = { 8986bc000000 83fa08 7241 8b8dd8f7ffff 8d145502000000 8bc1 }
		$sequence_4 = { 83f301 3345f8 83f001 8b97a4000000 8945ec 33d3 8bc3 }
		$sequence_5 = { 53 e8???????? c645fc02 8b95bcf7ffff 83fa10 722f 8b8da8f7ffff }
		$sequence_6 = { 8d85e8fdffff 6808020000 c745fc00000000 6a00 50 }
		$sequence_7 = { eb1a 8d45fc 50 8b04bde83e4300 ff743018 }
		$sequence_8 = { 8bf8 89565c 8b4640 897e58 89bd78f7ffff 8b7e40 8b4850 }
		$sequence_9 = { c1eb08 330c85a0f64200 334fd8 8b45f0 c1e810 0fb6c0 }

	condition:
		7 of them and filesize < 458752
}
rule MALPEDIA_Win_Mikoponi_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "191cc0a1-4e26-57f5-9a19-0f1d92e18f76"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.mikoponi"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.mikoponi_auto.yar#L1-L104"
		license_url = "N/A"
		logic_hash = "ab9b563b08639c6105c595652098abc7798bef9bb0cf43c1e3f9c3fc6a9fa527"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 881d???????? 881d???????? eb54 6683f863 }
		$sequence_1 = { e8???????? 83c40c 84c0 7508 83c6ff }
		$sequence_2 = { 8d742448 e8???????? 8bce ba02000000 83c408 }
		$sequence_3 = { a3???????? 33c0 8945e4 83f805 7d10 668b4c4310 66890c45e0674200 }
		$sequence_4 = { 53 89442440 894c2444 ff15???????? 837c243c00 c744241800000000 0f862c010000 }
		$sequence_5 = { 5e 8b8c2428060000 5f 5d 5b 33cc e8???????? }
		$sequence_6 = { 8d442424 50 ff15???????? 8d4c2444 }
		$sequence_7 = { 33c0 e9???????? 8975e4 33c0 39b8f85a4200 0f8491000000 ff45e4 }

	condition:
		7 of them and filesize < 330752
}
rule MALPEDIA_Win_Dnschanger_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "45f29de4-2d1c-5c37-9cf6-22d1c28e83d4"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.dnschanger"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.dnschanger_auto.yar#L1-L124"
		license_url = "N/A"
		logic_hash = "9218af3e8ca56b296e365b6469b21919f84a3326ebd732009fb32dd14ff42f4c"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 6a00 6a00 56 ff15???????? 85c0 751a ff15???????? }
		$sequence_1 = { 8b35???????? 50 ffd6 8b5c2418 8bf8 }
		$sequence_2 = { 68???????? 68???????? 68???????? 68???????? 51 ffd5 }
		$sequence_3 = { ff15???????? 50 ff15???????? 8d8500ffffff 50 e8???????? 8b35???????? }
		$sequence_4 = { ab 33c0 8d7de1 885de0 ab ab ab }
		$sequence_5 = { 8d4c2414 50 68???????? 68???????? 68???????? }
		$sequence_6 = { 8bf8 8d442410 8b8b9c010000 50 57 }
		$sequence_7 = { 57 57 56 57 ff75fc ff15???????? }
		$sequence_8 = { 85ff 740c 57 6a00 ffd5 }
		$sequence_9 = { 83c41c c3 8a44242c 84c0 742d 6a00 6a00 }

	condition:
		7 of them and filesize < 49152
}
rule MALPEDIA_Win_Bluenoroff_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "155ae36c-d23a-5a6c-a45a-2c34e5fd3df8"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.bluenoroff"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.bluenoroff_auto.yar#L1-L120"
		license_url = "N/A"
		logic_hash = "0fb4b472429844bcede7df6655aa3a371ed916e685b543a8880e6ada597e3e4b"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 56 e8???????? 83c420 8b4dfc 33cd }
		$sequence_1 = { 7429 8b4508 8b5510 8b4d0c 8906 52 }
		$sequence_2 = { e8???????? 8b5508 8d4d0c 51 52 8d85fcfffeff }
		$sequence_3 = { 8bec 51 8b4508 53 6a00 }
		$sequence_4 = { 56 8d95f8feffff 56 52 e8???????? 8b4dfc 83c428 }
		$sequence_5 = { 8b55fc 320c3a 880f b901000000 }
		$sequence_6 = { 881430 81f900010000 7ccb 5f 5e 5b }
		$sequence_7 = { e8???????? b912010000 8bf3 f3a5 a1???????? 8b5004 83c410 }
		$sequence_8 = { 8b7d10 66898e00010000 32db 8bc1 }
		$sequence_9 = { 83feff 7433 8d4e01 51 6a40 }

	condition:
		7 of them and filesize < 303104
}
rule MALPEDIA_Win_Flawedgrace_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "156b4494-98bf-5a30-8267-0e6580ac81fc"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.flawedgrace"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.flawedgrace_auto.yar#L1-L132"
		license_url = "N/A"
		logic_hash = "85227542d7e5b0ffd9cceda36113fab969031f93ab780938100652b28bb31f08"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8d867c010000 50 ffb678010000 e8???????? a1???????? 8b30 56 }
		$sequence_1 = { c685c4e9ffff00 c685c5e9ffff00 c685c6e9ffff00 c685c7e9ffff00 c685c8e9ffff00 c685c9e9ffff00 c685cae9ffff00 }
		$sequence_2 = { 64a300000000 8bf1 c745fc00000000 8b4608 c706???????? 85c0 7407 }
		$sequence_3 = { c685b3e6ffffd4 c685b4e6ffff00 c685b5e6ffff00 c685b6e6ffff00 c685b7e6ffff00 c685b8e6ffff00 c685b9e6ffff00 }
		$sequence_4 = { c68582fdffff00 c68583fdffff00 c68584fdffff00 c68585fdffff00 c68586fdffff00 c68587fdffff00 c68588fdffff00 }
		$sequence_5 = { c685faddffff00 c685fbddffff00 c685fcddffff00 c685fdddffff00 c685feddffff00 c685ffddffff00 c68500deffff00 }
		$sequence_6 = { c68585d3ffff24 c68586d3ffff00 c68587d3ffff00 c68588d3ffff48 c68589d3ffff83 c6858ad3ffffc4 }
		$sequence_7 = { 0fb6c3 8b5df8 33da 8955f4 895df8 333c85e0d34500 }
		$sequence_8 = { e8???????? eb26 ff760a ff7610 e8???????? eb19 ff760a }
		$sequence_9 = { 8d45c8 895db0 8945a0 8d7dd8 0f1f4000 8b4590 2bc6 }

	condition:
		7 of them and filesize < 966656
}
rule MALPEDIA_Win_Solaris_Loader_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "40dd4373-645a-5b8e-b489-8244da347e40"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.solaris_loader"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.solaris_loader_auto.yar#L1-L124"
		license_url = "N/A"
		logic_hash = "74ee0babe415ce4a6591fb0799bb4b560b16a1d0fe53892dc1830d175d1b44ae"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 4c0f45cd ff15???????? 4533c9 c744242000000000 4533c0 }
		$sequence_1 = { ff15???????? 498bcc ff15???????? 8b15???????? 488d0dbb440000 e8???????? 4533c9 }
		$sequence_2 = { 48c744242800000000 4c8d05c4290000 4533c9 c744242000000000 }
		$sequence_3 = { 48c7851808000000000000 8bfa c7851008000000000000 4533ff e8???????? 448bf0 85c0 }
		$sequence_4 = { 4c8d05766d0000 488d1547750000 498bcf e8???????? 448b0d???????? 4c8d05996f0000 488d1532750000 }
		$sequence_5 = { 448b842490000000 ba01000000 488bcf ff15???????? 4885f6 7414 }
		$sequence_6 = { 4183c9ff 44897c2428 4d8bc6 33d2 }
		$sequence_7 = { b9e9fd0000 488bf8 ff15???????? 83eb01 0f84d0050000 83eb01 }
		$sequence_8 = { 4889442430 e8???????? 8b15???????? 488d0d61780000 4889442438 e8???????? 8b15???????? }
		$sequence_9 = { 488bd0 33c9 4c8bf0 ff15???????? 4883f820 7e28 4c8d442460 }

	condition:
		7 of them and filesize < 100352
}
rule MALPEDIA_Win_Neteagle_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "efc56159-7e67-543c-ade8-a9fa14dcc44a"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.neteagle"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.neteagle_auto.yar#L1-L129"
		license_url = "N/A"
		logic_hash = "b50473a2a68fa05d52fac10f62110008f4b41bd3e4956aba264f1d69b7102f73"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8d4c2420 889c2434020000 e8???????? 8b442414 85c0 7406 8b08 }
		$sequence_1 = { e8???????? 33c0 8b4c2428 64890d00000000 5f 5e 5d }
		$sequence_2 = { 8d4c2434 c644247402 e8???????? 8d4c2418 8bf8 c644246c01 e8???????? }
		$sequence_3 = { 8bfc 50 f3a5 e8???????? 8b8c24b4000000 8b9424a8000000 03d1 }
		$sequence_4 = { 8b442420 8d542424 51 8b4c241c 52 53 }
		$sequence_5 = { 53 ffd5 8b15???????? 8b0d???????? c644041c00 51 8b8284000000 }
		$sequence_6 = { 8bc6 8b7d10 8907 8345fc04 }
		$sequence_7 = { 8d4c2430 85c0 0f94c3 e8???????? 84db 0f8414010000 }
		$sequence_8 = { 66c745a00200 ff15???????? 8b4de0 8d55a0 6a10 668945a2 52 }
		$sequence_9 = { 8d4c2420 c78424300c0000ffffffff e8???????? 8b8c24280c0000 5e 5d 64890d00000000 }

	condition:
		7 of them and filesize < 262144
}
rule MALPEDIA_Win_Lockfile_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f6086bc8-9a7e-5405-b4a4-5242346258f4"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.lockfile"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.lockfile_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "39cca89558f1bc73f31956304c38bc3748d44d64cc53c9ffe605049f8514601c"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 488d0d293d0700 8b440104 8b4c243c 33c8 8bc1 8944243c 8b442440 }
		$sequence_1 = { 410fb6d2 ff5060 488b8c2480000000 4833cc e8???????? 4881c498000000 c3 }
		$sequence_2 = { 4133c5 03d0 488d05d7270300 031488 4103d0 03d6 8b75bb }
		$sequence_3 = { 4889842480000000 488d1510da0400 488d4c2420 e8???????? 90 488d542420 488d4c2440 }
		$sequence_4 = { 041c 346b 88442460 8b442440 041d 3465 88442461 }
		$sequence_5 = { 4d2bc1 7415 0f1f4000 48836b2001 7504 4c897b18 4983e801 }
		$sequence_6 = { 4c2bc3 420fb60411 3201 488d4901 440ac8 4983e801 75ec }
		$sequence_7 = { 3468 8845e2 8b45d0 040f 3465 8845e3 8b45d0 }
		$sequence_8 = { 488d0d03350700 8b440101 8b4c243c 33c8 8bc1 8944243c 8b44244c }
		$sequence_9 = { 4833c4 48898590010000 4c8bad08020000 0f57c0 0f1185b0000000 0f1185c0000000 0f1185d0000000 }

	condition:
		7 of them and filesize < 1163264
}
rule MALPEDIA_Win_Hyperssl_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "d9f2e81d-55e0-5710-8b35-060488cc5dc9"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.hyperssl"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.hyperssl_auto.yar#L1-L215"
		license_url = "N/A"
		logic_hash = "4077455c65d13428bc93ec2b34c3b47ea22888b797cb023594bc39f540abba51"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 0108 894810 8b4830 3308 }
		$sequence_1 = { 0105???????? 8d558c 89458c 894590 }
		$sequence_2 = { 8b4028 03c1 7423 56 57 }
		$sequence_3 = { 7436 8b413c 03c1 742a 8b4028 }
		$sequence_4 = { 0105???????? 8d8d5cffffff 89855cffffff 898560ffffff }
		$sequence_5 = { 0108 3310 c1c607 c1c210 }
		$sequence_6 = { 0101 014514 2bf3 8b5d0c c7472400000000 }
		$sequence_7 = { ff15???????? 8bc8 85c9 7436 }
		$sequence_8 = { 0108 8b4830 3308 56 }
		$sequence_9 = { 33c9 50 66890c06 8985ecfdffff e8???????? 83c40c }
		$sequence_10 = { 8a10 301406 40 4f 75f2 }
		$sequence_11 = { 8a10 301401 8a10 301406 }
		$sequence_12 = { 33c0 40 5d c20c00 6a08 68???????? e8???????? }
		$sequence_13 = { 75f2 5f 5e e9???????? c3 55 8bec }
		$sequence_14 = { 2bc8 2bf0 5f 8a10 }
		$sequence_15 = { 0108 3908 1bc9 f7d9 }
		$sequence_16 = { 011d???????? 5f 8935???????? 5e }
		$sequence_17 = { 017e08 8bc3 e8???????? c20400 }
		$sequence_18 = { 01442428 8b442428 884500 45 }
		$sequence_19 = { 017e0c 5f 8bc6 5e c20800 }
		$sequence_20 = { 017e0c 395e10 740f ff7610 }
		$sequence_21 = { 017e08 50 e8???????? ff0d???????? }
		$sequence_22 = { 016b08 897b04 5f 5e }
		$sequence_23 = { 017e0c 8d4d08 e8???????? 5f }

	condition:
		7 of them and filesize < 835584
}
rule MALPEDIA_Win_Cerbu_Miner_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "77652d6a-745f-5552-8901-83bf555706f4"
		date = "2023-12-06"
		modified = "2023-12-08"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.cerbu_miner"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.cerbu_miner_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "e4927a587588bc11053fcbade5bb9500364c9a656d383eb318cc8486464f3cce"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20231130"
		malpedia_hash = "fc8a0e9f343f6d6ded9e7df1a64dac0cc68d7351"
		malpedia_version = "20230808"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 88b42480000000 eb3f 83e902 7433 83e904 7413 83e909 }
		$sequence_1 = { 7412 48 8d0d0b360500 48 83c428 48 ff25???????? }
		$sequence_2 = { 8d4601 c643012e 48 63c8 41 8d4602 48 }
		$sequence_3 = { 85d2 7427 85c9 b800040000 41 b800080000 44 }
		$sequence_4 = { f6473801 7402 eb18 48 8bcf ff15???????? f6473801 }
		$sequence_5 = { e9???????? 45 8bfd 44 89ad50010000 e9???????? 44 }
		$sequence_6 = { 48 89442420 e8???????? 48 8bd7 48 8bcb }
		$sequence_7 = { 89b42418010000 8b74242c 83feff 7515 837f0c00 7c0f 48 }
		$sequence_8 = { 8d057b52f9ff 48 894518 c745b0e6070000 48 c745c000000200 48 }
		$sequence_9 = { 44 2bc0 44 8903 33c0 48 8b5c2438 }

	condition:
		7 of them and filesize < 1040384
}
rule MALPEDIA_Win_Dharma_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "1339d1c3-b5d0-5666-95ff-e850d8b88e32"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.dharma"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.dharma_auto.yar#L1-L127"
		license_url = "N/A"
		logic_hash = "c916babeca2562506eac26f8df96906792b8a5aeb74234697d4eb706681f567d"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 68???????? e8???????? 83c410 8945e8 8b45e8 50 e8???????? }
		$sequence_1 = { 880a 8b55f4 83c201 8955f4 837d1000 744a 8b45fc }
		$sequence_2 = { 6a02 6880000000 68???????? 68???????? e8???????? 83c410 8945dc }
		$sequence_3 = { 51 e8???????? 85c0 0f8477010000 837de400 }
		$sequence_4 = { c1e002 50 6a00 8b4dec 8b510c 52 e8???????? }
		$sequence_5 = { 0fb645f9 8b4de4 8a55ef 881401 0fb645fa }
		$sequence_6 = { e9???????? 8b5508 8a45fd 8802 8b4d08 }
		$sequence_7 = { 8b4508 8b4dfc 894804 8b5508 8b45f8 8902 8be5 }
		$sequence_8 = { 8b4da8 51 e8???????? 83c40c 8b55a8 52 }
		$sequence_9 = { 894de0 8b55f0 52 68???????? 8b45f4 50 6a03 }

	condition:
		7 of them and filesize < 204800
}
rule MALPEDIA_Win_Bouncer_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "bbee767a-0e22-57ba-9f52-4d9f85122434"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.bouncer"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.bouncer_auto.yar#L1-L120"
		license_url = "N/A"
		logic_hash = "39b37e493efe2469eb26371e5b3ea0d6d9f8914acd8cee091db44cfd373382c3"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 56 50 e8???????? 8d85a0fbffff c645d02d 50 }
		$sequence_1 = { 7408 50 ff15???????? 59 33c0 5f }
		$sequence_2 = { 7444 81ffea000000 743c 39750c 751a 57 }
		$sequence_3 = { 8d859cfaffff 50 ff15???????? 3bc6 8945fc }
		$sequence_4 = { 8945c0 0f846f110000 8935???????? 395dc4 0f8460110000 }
		$sequence_5 = { 7431 39750c 68???????? 750e }
		$sequence_6 = { 53 8d45e0 57 50 a1???????? 6a04 ff750c }
		$sequence_7 = { 3b8db4feffff 72f0 eb7a 8b85b4feffff 48 3bc8 }
		$sequence_8 = { 8d85a4faffff c645c82e 50 e8???????? 8945dc 8d45c8 50 }
		$sequence_9 = { 48 7417 48 752f }

	condition:
		7 of them and filesize < 335872
}
rule MALPEDIA_Win_Netsupportmanager_Rat_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "e1315d11-1bbf-5ce7-af09-381e2dc5fc5e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.netsupportmanager_rat"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.netsupportmanager_rat_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "6d6d971d594b3b628555a3e238b8b15b6e0e06f0af7b29dee7f83ecef9a11e20"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 83ff01 8d4660 0f94c2 50 8d4dd8 c745fc00000000 }
		$sequence_1 = { e8???????? 8b8bb8000000 51 8bce e8???????? 8b4df4 5f }
		$sequence_2 = { ff15???????? 85c0 7429 8b4b0c 8b5510 8b06 51 }
		$sequence_3 = { ff15???????? 6a02 56 ff15???????? 8bf0 85f6 75e0 }
		$sequence_4 = { e8???????? 8b4df8 83c418 51 ff15???????? 8b5514 8b4dfc }
		$sequence_5 = { ff9254010000 8b839c000000 85c0 757f 8b4b0c 83e10f 80f905 }
		$sequence_6 = { ff15???????? 8bd8 8a4510 4b 83cb01 a801 7426 }
		$sequence_7 = { ff90c8000000 85c0 740f ff15???????? 48 0c01 89864c020000 }
		$sequence_8 = { f7d1 49 7434 bf???????? 83c9ff f2ae f7d1 }
		$sequence_9 = { e8???????? 8b9684000000 8bce 52 6877040000 e8???????? 8b8688000000 }

	condition:
		7 of them and filesize < 4734976
}
rule MALPEDIA_Win_Hive_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "ec03263a-517a-52e0-b404-6a2cc41f0dec"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.hive"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.hive_auto.yar#L1-L195"
		license_url = "N/A"
		logic_hash = "36732587abf3a9862aaa43b0fccbf86b1d02df15fc40efb698497a5ed1480241"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 31c0 b91d000000 31d2 31db }
		$sequence_1 = { 7f1e 0fbae000 73ed 90 }
		$sequence_2 = { 7f07 ba01000000 eb19 83fa02 7307 }
		$sequence_3 = { 89c2 e8???????? b801000000 e8???????? 90 }
		$sequence_4 = { 31c0 31c9 31d2 bb08000000 be20000000 31ff }
		$sequence_5 = { 89d1 e8???????? b802000000 e8???????? }
		$sequence_6 = { 31d3 8d1c18 8d5b3a 0f1f00 }
		$sequence_7 = { 81c4b0000000 c3 e8???????? 90 }
		$sequence_8 = { 31c0 31c9 31d2 bb07000000 be65000000 31ff eb0e }
		$sequence_9 = { 31c9 31d2 bb04000000 beb8000000 }
		$sequence_10 = { 89d1 e8???????? b901000000 e8???????? }
		$sequence_11 = { 31c9 31d2 bb01000000 beae000000 }
		$sequence_12 = { 01c1 83c101 83f90c 0f820fffffff }
		$sequence_13 = { 01c1 c1e106 400fb6d6 01ca }
		$sequence_14 = { 89bc2480000000 8b7918 8b491c 894c247c }
		$sequence_15 = { 01c8 89c1 c1e91f ffc9 }
		$sequence_16 = { 01c2 b8ffffff03 21c5 21c3 }
		$sequence_17 = { 89bc2480000000 8d05c0eb5800 890424 89542404 }
		$sequence_18 = { 01c0 4000f8 0fb6c0 48898424b0000000 }
		$sequence_19 = { 01ca c1e206 0fb6c3 01d0 }
		$sequence_20 = { 01c1 c1e106 0fb6c2 01c8 }
		$sequence_21 = { 01c8 c1e006 400fb6cf 01c1 }

	condition:
		7 of them and filesize < 7946240
}
rule MALPEDIA_Win_Apple_Chris_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "6b565737-c752-5885-bc55-ad95c5b1fabd"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.apple_chris"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.apple_chris_auto.yar#L1-L132"
		license_url = "N/A"
		logic_hash = "d8f41f94b3712b4512a9615c37c4be47163a5e24d20441f8b3e3ff38ec2bed7b"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 488d0504a30900 488903 488d7320 4889742448 410fb600 8806 498b4008 }
		$sequence_1 = { 0f2845e7 488d15d0370900 488d4de7 660f7f45e7 e8???????? 488d55e7 488d4dd7 }
		$sequence_2 = { eb12 8b442474 8b4c244c 03c8 8bc1 8944244c eb8e }
		$sequence_3 = { 488d156a720600 488d4c2428 e8???????? 90 33c0 4889442458 4889442460 }
		$sequence_4 = { 488d05f8d20c00 4889442420 4c8d4c2454 4c8d8424a0010000 ba00040000 488d8c24c0060000 e8???????? }
		$sequence_5 = { 90 33c0 4889442458 4889442460 488d05fcbd0400 4889442450 c744246800000000 }
		$sequence_6 = { 488b11 4c8b45e7 498bf8 33c0 488bca f348ab 498bc8 }
		$sequence_7 = { 418d5602 488d4de0 e8???????? 90 41be03000000 4489b590000000 488d55e0 }
		$sequence_8 = { eb3b 8b442444 8b8c24f8000000 2bc8 8bc1 8b4c2444 }
		$sequence_9 = { 33c9 ff15???????? 85c0 7427 488b4c2438 488d157e2b0700 }

	condition:
		7 of them and filesize < 1968128
}
rule MALPEDIA_Win_Mimikatz_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "e2f75106-0b4a-5615-8424-3e947df162e4"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.mimikatz"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.mimikatz_auto.yar#L1-L204"
		license_url = "N/A"
		logic_hash = "0c5b4c81c99ff47fa93c02cb439897a7a3c1db7a5013361ed58d69e7887a0438"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 83f8ff 750e ff15???????? c7002a000000 }
		$sequence_1 = { f7f1 85d2 7406 2bca }
		$sequence_2 = { 83f812 72f1 33c0 c3 }
		$sequence_3 = { c3 81f998000000 7410 81f996000000 7408 81f99b000000 }
		$sequence_4 = { f6c320 740f 83f809 7c05 }
		$sequence_5 = { f6c320 7413 6683f809 7206 }
		$sequence_6 = { 66894108 33c0 39410c 740b }
		$sequence_7 = { 6683f83f 7607 32c0 e9???????? }
		$sequence_8 = { e9???????? bd64000000 83ff2d 0f853c040000 c644245c01 }
		$sequence_9 = { ff15???????? be00000400 8bc8 8bd6 }
		$sequence_10 = { ff5048 8bd8 85c0 7837 }
		$sequence_11 = { 2bc1 85c9 7403 83c008 }
		$sequence_12 = { 3c02 7207 e8???????? eb10 }
		$sequence_13 = { ff15???????? bd6f000000 3bc3 7405 }
		$sequence_14 = { 8d4d08 8d0437 51 50 e8???????? 83c40c }
		$sequence_15 = { 33c9 3b04cd08d04600 7413 41 83f92d }
		$sequence_16 = { 40 8945f4 83fb04 7561 33db 90 }
		$sequence_17 = { e8???????? 8bc8 8b4508 ba???????? 2aca }
		$sequence_18 = { 8d04453cdb4600 8bc8 2bce 6a03 d1f9 68???????? }
		$sequence_19 = { 99 83ec0c 53 83e203 }
		$sequence_20 = { c1e80d 8d4dd8 83e001 51 894614 c7461ce0164000 }
		$sequence_21 = { 8b5dd0 ebab c745e424714000 817de428714000 7311 8b45e4 8b00 }

	condition:
		7 of them and filesize < 1642496
}
rule MALPEDIA_Win_Makadocs_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "29d9f3e8-82ff-58b5-bd25-01707c344eaf"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.makadocs"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.makadocs_auto.yar#L1-L125"
		license_url = "N/A"
		logic_hash = "f4b9617782c2adb0554599b3bf38d51ebfa7bca549731357f468917871e39e04"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8d5c2410 c644243018 e8???????? c644243001 }
		$sequence_1 = { 3be8 7ccb 33db 83ff03 0f8d8d000000 b803000000 }
		$sequence_2 = { c644242c07 8b442434 51 83c0f0 89642420 8bf4 e8???????? }
		$sequence_3 = { 8bc6 e8???????? 833e00 7543 }
		$sequence_4 = { 8b11 50 8b4204 ffd0 c644246800 8b442420 eb33 }
		$sequence_5 = { c1e108 0bca c1e108 8bd1 c1ea1a 0fb692a0114200 8816 }
		$sequence_6 = { 6805400080 e8???????? 8b4b0c 50 51 }
		$sequence_7 = { 8bc5 e8???????? c64424682a 8b08 8b41f4 51 8d4c242c }
		$sequence_8 = { 8b73fc 83ed04 83eb04 8d41f0 83ee10 3bc6 7444 }
		$sequence_9 = { 8d4804 52 51 e8???????? c745fcffffffff 8b450c 83c0f0 }

	condition:
		7 of them and filesize < 344064
}
rule MALPEDIA_Win_Downeks_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f08adf24-7d9a-54e5-8d03-c58fd555516d"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.downeks"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.downeks_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "170fa96c5d3c7cbd84ecc1103da63f4c042fa1d403115ae89a2c37431b68b692"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 89860c010000 85c0 7444 c7865886000001000000 eb72 8b860c010000 85c0 }
		$sequence_1 = { b8502c0804 5d c3 b8182c0804 5d c3 b8042c0804 }
		$sequence_2 = { c7868c00000003000000 e9???????? c7868c00000002000000 e9???????? 8b4668 6a0e 50 }
		$sequence_3 = { a1???????? 33c5 8945fc 8b06 8b80c0860000 803800 7523 }
		$sequence_4 = { 8d770c e8???????? 8b5f0c 83c404 85db 0f8411020000 8bc3 }
		$sequence_5 = { dd18 e9???????? c745d803000000 c745dc38990804 e9???????? 81c118fcffff 83f90c }
		$sequence_6 = { 0f8c990a0000 8d41e0 6683f858 770f 0fb7c1 0fbe8010970804 83e00f }
		$sequence_7 = { b9b8270904 2bc1 50 51 8d45bc 50 8bc6 }
		$sequence_8 = { d1f8 50 8d85d8f9ffff 50 8d8dbcf9ffff 51 e8???????? }
		$sequence_9 = { c1cf06 33cf 038d48ffffff 8b7df0 337dec 23fa 337df0 }

	condition:
		7 of them and filesize < 1318912
}
rule MALPEDIA_Win_Gazer_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "dc1d25e7-54a7-537f-9434-b6534f33e904"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.gazer"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.gazer_auto.yar#L1-L120"
		license_url = "N/A"
		logic_hash = "bf177d2906d78417b2eb2cc726923a44432cce5f3bdcbe117d6d7673f2f81e9d"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff15???????? 85c0 7511 e8???????? 84c0 7508 }
		$sequence_1 = { 85c0 7511 e8???????? 84c0 7508 83c8ff e9???????? }
		$sequence_2 = { 85c0 7511 e8???????? 84c0 7508 83c8ff }
		$sequence_3 = { 85c0 7511 e8???????? 84c0 7508 }
		$sequence_4 = { ff15???????? 85c0 7511 e8???????? 84c0 }
		$sequence_5 = { 85c0 7511 e8???????? 84c0 }
		$sequence_6 = { 7511 e8???????? 84c0 7508 83c8ff }
		$sequence_7 = { ff15???????? 85c0 7511 e8???????? 84c0 7508 83c8ff }
		$sequence_8 = { 7511 e8???????? 84c0 7508 83c8ff e9???????? }
		$sequence_9 = { 448b442478 468d9400870dd5f4 41c1c20e 4403d2 8bc2 }

	condition:
		7 of them and filesize < 950272
}
rule MALPEDIA_Win_Icedid_Downloader_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "fc526a9c-b559-5dbf-9e99-5aba24f92464"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.icedid_downloader"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.icedid_downloader_auto.yar#L1-L125"
		license_url = "N/A"
		logic_hash = "1d4f5daeeffa8f34957b579146191df50d8af84cb1f7f284ea36f87bf8541cf1"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 50 8d45f0 50 8d45d0 50 ff15???????? }
		$sequence_1 = { 85f6 0f85fb000000 8d442440 50 68???????? e8???????? 59 }
		$sequence_2 = { 55 8d6c2494 81ecb8000000 a1???????? 56 }
		$sequence_3 = { 64a118000000 59 59 6804010000 8b4030 8945fc 8d85a8fdffff }
		$sequence_4 = { 895dfc ff15???????? 8d45fc 50 68???????? 6a01 53 }
		$sequence_5 = { ff7510 8b45ec ff750c ff7010 ff75f4 e8???????? }
		$sequence_6 = { 7575 0fb74004 663b4204 756b ff74241c ff15???????? }
		$sequence_7 = { e8???????? 59 59 8d442440 50 ffd3 }
		$sequence_8 = { 7821 395df8 741c 6a04 8d45f8 }
		$sequence_9 = { 55 57 51 ff520c 8b2d???????? 8bf0 }

	condition:
		7 of them and filesize < 40960
}
rule MALPEDIA_Win_Kegotip_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "95c51e5c-7ec5-5feb-8c55-f9e96d73189a"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.kegotip"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.kegotip_auto.yar#L1-L118"
		license_url = "N/A"
		logic_hash = "2729d5ae309160c80d97f25d84f4a42a6599204c8714daa653ad13c1b4a67192"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c745f800000000 8b45f4 0345f8 0fbe08 }
		$sequence_1 = { 52 e8???????? 83c408 8b4df4 c1e902 }
		$sequence_2 = { 8b550c 2b55f0 83fa03 720b 8b450c 2b45f0 }
		$sequence_3 = { 8b55f0 52 e8???????? 8945ec 6a00 }
		$sequence_4 = { 32c0 e9???????? e8???????? 6a04 }
		$sequence_5 = { 8b9538f9ffff 83c201 899538f9ffff 83bd38f9ffff10 7d54 8b8540f9ffff 038538f9ffff }
		$sequence_6 = { 51 e8???????? 83c408 8d95f8feffff 52 8b4508 50 }
		$sequence_7 = { 8b8dd4feffff 0fbe940dd6feffff 83fa5c 750e 8b85d4feffff }
		$sequence_8 = { 50 8d4df4 51 6a00 68???????? 8b55f8 }
		$sequence_9 = { 32c0 e9???????? 8d95a8fdffff 52 ff15???????? }

	condition:
		7 of them and filesize < 278528
}
rule MALPEDIA_Win_Chrysalis_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "8ac86fbe-4a38-5c59-b680-53231dc68de9"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.chrysalis"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.chrysalis_auto.yar#L1-L128"
		license_url = "N/A"
		logic_hash = "219bde91370648ac418481323d54d122c8b647698590cc959d3053294b10c98d"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 39bd00fdffff 0f8331fcffff e9???????? c645fc08 }
		$sequence_1 = { 7ce2 8b5de0 8b45f0 0175fc 8b55f4 8b4d08 42 }
		$sequence_2 = { 0f4385c8fdffff 8d3c10 57 e8???????? 8b8524fdffff 83c40c }
		$sequence_3 = { 83f81f 0f8727010000 52 51 e8???????? 83c408 8b5588 }
		$sequence_4 = { e8???????? 8b45fc 83c418 c6040700 8b45f0 5f }
		$sequence_5 = { 85c9 7521 b99339e177 e8???????? 8b0d???????? 85c0 }
		$sequence_6 = { 2bc1 83c0fc 83f81f 0f878d050000 52 51 e8???????? }
		$sequence_7 = { 33c9 e8???????? 668b0d???????? ba06000000 668985b2f7ffff e8???????? 668b0d???????? }
		$sequence_8 = { 0f8376020000 88840df0feffff 8b0d???????? 85c9 751b b941346ca0 e8???????? }
		$sequence_9 = { 85c0 757e c7471c01000000 8bce 50 8906 894610 }

	condition:
		7 of them and filesize < 2514944
}
rule MALPEDIA_Win_Doublepulsar_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "d0d21c15-bd87-5aec-aa41-886f38fa0464"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.doublepulsar"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.doublepulsar_auto.yar#L1-L125"
		license_url = "N/A"
		logic_hash = "ee6de5d8565c19fc27076df6925dccec4136d751d3ff350532e06ab13aa4cd2c"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c3 8b442404 8b8880000000 6a00 6a03 51 33c0 }
		$sequence_1 = { 0fb6c8 f7d9 1bc9 83e103 83c110 }
		$sequence_2 = { 894530 8b4620 8b7d65 83c703 8907 8b4628 a902000000 }
		$sequence_3 = { 8bf8 83c418 85ff 0f85c0010000 85db 747d 8d7c2410 }
		$sequence_4 = { e9???????? c746541c000000 015e54 e9???????? 8b8768010000 68???????? }
		$sequence_5 = { 83f810 7446 83f820 742d 83f830 7414 68???????? }
		$sequence_6 = { 31c0 f3aa 8d8500fbffff 8985cff6ffff }
		$sequence_7 = { 40 ebdd 41 39c8 }
		$sequence_8 = { 0f84f8010000 39442450 0f84ee010000 57 8b7c2448 83ff23 740d }
		$sequence_9 = { 6a40 6800300000 50 6a00 ff5608 85c0 744b }

	condition:
		7 of them and filesize < 122880
}
rule MALPEDIA_Win_Hunter_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "26b403a1-5e6c-528b-85fb-6cac21f617fb"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.hunter"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.hunter_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "c616dc1b5345ff392120adcce7502bab4a6a26ecae8b93d32bfcd3cbb1537767"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8bf2 8bd9 85f6 7430 57 8b7e04 8bce }
		$sequence_1 = { 8bd0 e8???????? 8b55e4 85c0 0f85e7010000 8b4dc0 8365c400 }
		$sequence_2 = { c78424f800000000010000 f20f11842408010000 89842494000000 8b442410 80781e00 0f85d52e0000 8b7e14 }
		$sequence_3 = { e8???????? 8b442410 33d2 59 33c9 41 395658 }
		$sequence_4 = { e9???????? 8d8d1cffffff e9???????? 8d8d1cffffff e9???????? 8d8d6cfeffff e9???????? }
		$sequence_5 = { e8???????? 85c0 7415 8b45cc 46 8b55f8 83c008 }
		$sequence_6 = { 8bce e8???????? 0fb65514 b9feff0000 66014e12 2bda 8b4d08 }
		$sequence_7 = { 8d8d6cfeffff e8???????? 8d8dacfdffff e8???????? 8d8da0feffff e8???????? 8d8dccfdffff }
		$sequence_8 = { 8d87c2000000 898510ffffff 8d4764 8985acfeffff 8d4729 898550ffffff 8d4733 }
		$sequence_9 = { 8d5660 898568feffff 8d4e64 8b45fc 03857cffffff 3bca 8d4e1e }

	condition:
		7 of them and filesize < 1056768
}
rule MALPEDIA_Win_Taurus_Stealer_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "0c3f3f99-a357-5cb7-84a7-ab8d100107ea"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.taurus_stealer"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.taurus_stealer_auto.yar#L1-L130"
		license_url = "N/A"
		logic_hash = "9c3369f4d6511cf2e218e13aec24f5f9f4d70d01a02b1be5af240e39b44a3fbd"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8945e0 7205 8b00 8945e0 83791410 8bc1 7202 }
		$sequence_1 = { 47 3bfe 75ea 8b4df4 8b75f0 8bc1 2bc6 }
		$sequence_2 = { 8bca c745f867747500 0fbec0 250f000080 7905 48 }
		$sequence_3 = { 83fb03 750f ff7510 8bce ff750c e8???????? eb10 }
		$sequence_4 = { e8???????? 8d4dc8 b301 e8???????? 8b5744 }
		$sequence_5 = { 7402 8910 8b4618 b900000200 33f6 85d2 }
		$sequence_6 = { 8b4dd8 8b55ec 83fa10 8d45d8 0f43c1 803c182d 741e }
		$sequence_7 = { d1c0 8945c4 8bc7 33c3 894dfc 33c2 c1c105 }
		$sequence_8 = { 8d450d 885d0f 50 8bce e8???????? 8d4dd8 e8???????? }
		$sequence_9 = { 8b7508 57 8bf9 8b4f10 3bce 0f8237010000 8b550c }

	condition:
		7 of them and filesize < 524288
}
rule MALPEDIA_Win_Pikabot_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "36cf52bd-f556-576f-b374-dd360712a60a"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.pikabot"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.pikabot_auto.yar#L1-L269"
		license_url = "N/A"
		logic_hash = "e1c2e4569e0f171b247949cf8866c66e7c41bce5bdbf32ba38208b5a06af5acf"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ebd3 8b4508 c9 c3 }
		$sequence_1 = { 40 8945fc 8b45f8 40 8945f8 ebd3 }
		$sequence_2 = { 48 894510 837df400 741a }
		$sequence_3 = { 8945f8 8b4510 8945f4 8b4510 }
		$sequence_4 = { 8b4df8 8a09 8808 8b45fc }
		$sequence_5 = { 837df400 741a 8b45fc 8b4df8 }
		$sequence_6 = { 83ec0c 8b4508 8945fc 8b450c 8945f8 8b4510 }
		$sequence_7 = { 7ce9 8b4214 2b420c 5f }
		$sequence_8 = { e8???????? ffd0 c9 c3 55 8bec }
		$sequence_9 = { 8a1c08 8d4320 0fb6c8 8d53bf }
		$sequence_10 = { b84d5a0000 57 8955fc 663906 }
		$sequence_11 = { 8b0cba 03ce e8???????? 8bd0 e8???????? }
		$sequence_12 = { 8bfa 85c9 7436 85ff }
		$sequence_13 = { 53 56 8b35???????? b84d5a0000 }
		$sequence_14 = { 3bc7 72d5 5b 5f 8bc6 }
		$sequence_15 = { 0fabd0 83fa20 6a08 0f43c8 33c1 }
		$sequence_16 = { c60100 8bc6 5e c3 }
		$sequence_17 = { 0fb6d1 03c2 0fb6c0 8945f8 }
		$sequence_18 = { 40 3d00010000 72f1 8bf2 }
		$sequence_19 = { 3d00010000 72f1 8b35???????? 8bf9 }
		$sequence_20 = { 0345f8 03c8 0fb6c9 894df8 }
		$sequence_21 = { 81f900010000 72f0 8bf0 33d2 }
		$sequence_22 = { 0345f8 03c8 0fb6c1 8945f8 }
		$sequence_23 = { 8b01 0d20202020 3d6e74646c 750f }
		$sequence_24 = { 89d3 0fb633 8d4ed0 80f909 }
		$sequence_25 = { a3???????? 8b45e0 890424 a1???????? }
		$sequence_26 = { 8d45b4 890424 e8???????? 85c0 7513 }
		$sequence_27 = { a1???????? 8b0d???????? f725???????? 0faf0d???????? 01ca 0facd018 8945f4 }
		$sequence_28 = { 8d4590 8944240c 31c0 c744240800000200 89442404 8b45e4 890424 }
		$sequence_29 = { b90b000000 89e5 57 53 8d7ded 8d5ded }
		$sequence_30 = { 898264010000 891c24 e8???????? 8b15???????? }

	condition:
		7 of them and filesize < 1717248
}
rule MALPEDIA_Win_Andardoor_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "bab5033b-00f4-585d-b892-c18080639ca2"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.andardoor"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.andardoor_auto.yar#L1-L116"
		license_url = "N/A"
		logic_hash = "535332b030443175d1ad47fb77392059dab729f34118637f9553fd041c37d10e"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { f20f59d7 f20f59d7 f20f59d7 66490f7ed0 }
		$sequence_1 = { 0f1f4000 40383d???????? 7517 b9c8000000 ff15???????? 488b1d???????? }
		$sequence_2 = { 488bc3 488bbc2410040000 488b8dc0020000 4833cc e8???????? }
		$sequence_3 = { 4c896c2420 ff5018 85c0 7434 488b4d88 }
		$sequence_4 = { 48899c2480400000 4889bc2498400000 4c89bc2460400000 4983cfff }
		$sequence_5 = { ff15???????? 488b0d???????? ff15???????? 33c0 eb47 488b442468 }
		$sequence_6 = { 4803d6 4533c9 ff15???????? 85c0 7e25 b905000000 03d8 }
		$sequence_7 = { 40887dc8 488945c9 8bdf 488945d1 668945d9 }
		$sequence_8 = { 7507 33c0 e9???????? 4889bc24600d0000 ba00040000 4c89bc24680d0000 }
		$sequence_9 = { 0f85c5000000 0fb74c4202 66413b4c4002 0f85b4000000 }

	condition:
		7 of them and filesize < 339968
}
rule MALPEDIA_Win_Vohuk_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "e7b652e3-6405-5f1b-8c1b-2e3e664b48af"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.vohuk"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.vohuk_auto.yar#L1-L129"
		license_url = "N/A"
		logic_hash = "ca7fd19588b15e34c9bac8dd8617f00cf04b54f626eb477163c3bbdde5387a20"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c1e81f 03c2 69c0cc000000 2bc8 81c1e1000000 66314c7596 46 }
		$sequence_1 = { c745eab7008d00 c745ee87009500 c745f28d00d300 c745f6ca00ce00 c745fa80009e00 668945fe b815024d21 }
		$sequence_2 = { ffb5bcfeffff e8???????? 6a00 6841db0100 ffb5c8feffff 898554ffffff ffb5c4feffff }
		$sequence_3 = { c4e37d468500ffffff31 c5fdef87a0000000 c5fe7f80a0000000 c5fe6f85a0feffff c4e37d4645c031 c5fdef87c0000000 }
		$sequence_4 = { 33ff eb28 8b45f4 ba7d2225c4 8b0d???????? 8b75f0 }
		$sequence_5 = { c745c698008c00 c745cad900b500 c745ce8b009900 c745d29300de00 c745d6b9006901 c745da6d016701 c745de39012401 }
		$sequence_6 = { b8fc000000 c745b8d900a700 c745bcb900ad00 33f6 }
		$sequence_7 = { 2bc8 81c1e1000000 66310c77 46 83fe33 72d5 57 }
		$sequence_8 = { 56 ffd0 85c0 0f8442030000 c745e090009100 33f6 c745e4eb00a300 }
		$sequence_9 = { 8bec 81ec1c020000 8b0d???????? baf47a81b9 6884000000 c745f400000000 c745e800010000 }

	condition:
		7 of them and filesize < 260096
}
rule MALPEDIA_Win_Babylon_Rat_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "af8ed0b4-ac1c-5950-ac75-6efc223bd2e3"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.babylon_rat"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.babylon_rat_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "b09694ea4ee83d83534d40b622bbd20b62d4719417ecee8e1d2ac3e6b52c4fd3"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 83ec10 57 8b7d08 ff37 e8???????? 59 85c0 }
		$sequence_1 = { ff7518 ff7514 ff7510 ff30 ff15???????? eb32 57 }
		$sequence_2 = { ff75b4 53 e8???????? 83c43c eb20 ff75c8 85c9 }
		$sequence_3 = { eb0f 8d4508 50 53 e8???????? 8b7508 59 }
		$sequence_4 = { e8???????? 68???????? ebc9 55 8bec 53 8b5d10 }
		$sequence_5 = { ff75fc ff7020 56 e8???????? 83c41c 8bd8 eb08 }
		$sequence_6 = { ff15???????? 53 894508 ff15???????? 8bf8 59 59 }
		$sequence_7 = { 8d85f0fbffff 50 e8???????? bf???????? 57 e8???????? 59 }
		$sequence_8 = { ff4df0 7598 8b7508 8b45e4 83f801 7549 85c9 }
		$sequence_9 = { 894da8 8b79fc 85ff 7507 bf???????? eb16 80fa07 }

	condition:
		7 of them and filesize < 1604608
}
rule MALPEDIA_Win_Entryshell_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f0db3beb-957b-5b6d-806e-d9901188ce2f"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.entryshell"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.entryshell_auto.yar#L1-L128"
		license_url = "N/A"
		logic_hash = "86032ec83a26772aa261167e2c0d8de512e9bb257a9ccd956d30fb660f51f569"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b4df0 8b048578512501 807c012800 7d5b 8d45dc 50 ff75e8 }
		$sequence_1 = { 41 84c0 75f9 8b4314 2bca 8b95f0feffff 8b0410 }
		$sequence_2 = { 50 6a00 eb3b 83fb03 7541 68???????? 68???????? }
		$sequence_3 = { 8be5 5d c3 6a44 8d4590 }
		$sequence_4 = { 75f9 2bc2 83f840 760c 46 8935???????? e9???????? }
		$sequence_5 = { 8d8424d8000000 6a40 6a00 50 e8???????? 83c40c 8d842458190000 }
		$sequence_6 = { 8b4f1c 8b75f0 8b4718 0f1185ccfeffff 8995d0feffff 894dd4 8d8d74fcffff }
		$sequence_7 = { 660f282d???????? 660f59f5 660f28aa00e12401 660f54e5 660f58fe }
		$sequence_8 = { e8???????? 660f6ec0 f30fe6c0 f20f5e05???????? f20f5905???????? f20f2cc0 884435f0 }
		$sequence_9 = { 8a442417 83c408 8b54241c 894c2410 880419 }

	condition:
		7 of them and filesize < 663552
}
rule MALPEDIA_Win_Domino_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "58d4f966-f70d-5910-a74e-9fd0e022bde9"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.domino"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.domino_auto.yar#L1-L117"
		license_url = "N/A"
		logic_hash = "ced218901c00543d1d44cc6387f45a0b2c2233c09ab3dd84a141257d6ab29077"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 84c0 750f 66c7030101 b802000000 e9???????? 488d942450010000 }
		$sequence_1 = { 7d07 ffc8 83c8f0 ffc0 48ffc2 }
		$sequence_2 = { 488b1a 488bfa 488bf1 8b13 488bce }
		$sequence_3 = { ff15???????? b806000000 eb2c 488bcf ff15???????? 488d4c2440 e8???????? }
		$sequence_4 = { 741a 488b4c2458 ff15???????? 488b4c2450 ff15???????? }
		$sequence_5 = { 66c7030101 b802000000 e9???????? 488d942450010000 b904010000 }
		$sequence_6 = { 48896810 48897018 48897820 4156 4881ec90000000 8bf2 }
		$sequence_7 = { e9???????? 8b442470 488b9c2488000000 4883c440 }
		$sequence_8 = { 85c0 7509 488b5b08 483b1f 75e9 }
		$sequence_9 = { f7d9 451af6 4180c602 498bcf }

	condition:
		7 of them and filesize < 50176
}
rule MALPEDIA_Win_Brutpos_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "bb6abccd-59b3-5a30-9e67-ccbe498737a5"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.brutpos"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.brutpos_auto.yar#L1-L117"
		license_url = "N/A"
		logic_hash = "89d0bc6a7e52ba9f63dface96ebbf483b03be0cbf8144ed32f3b88bf360b4eda"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 59 58 83c004 83e904 8808 }
		$sequence_1 = { 03c2 034508 2938 83e902 75e8 ebd9 5e }
		$sequence_2 = { 8d5b18 8b5b60 03d8 52 8b35???????? }
		$sequence_3 = { 6681f9df77 7412 0f31 8bd8 }
		$sequence_4 = { 8bd0 ad 8bc8 83e908 66ad 6685c0 740c }
		$sequence_5 = { 8d7c38fc baffffffff 83c704 57 }
		$sequence_6 = { 66ad 6685c0 740c 25ff0f0000 03c2 034508 }
		$sequence_7 = { 52 e8???????? 59 8b09 8bd1 }
		$sequence_8 = { c1e202 03d3 8b12 03d0 }
		$sequence_9 = { 8b5508 8b4204 0fb70a 50 51 807401ff97 }

	condition:
		7 of them and filesize < 65536
}
rule MALPEDIA_Win_Mykings_Spreader_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "96a12e80-b15f-580e-920d-d6c0d35464b0"
		date = "2023-12-06"
		modified = "2023-12-08"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.mykings_spreader"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.mykings_spreader_auto.yar#L1-L132"
		license_url = "N/A"
		logic_hash = "1bcd674173fea4b83a2f4219e8f61306a972490f94a89cfaf5e1f466fdec8eff"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20231130"
		malpedia_hash = "fc8a0e9f343f6d6ded9e7df1a64dac0cc68d7351"
		malpedia_version = "20230808"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 7519 51 55 8bce e8???????? 6a00 6a00 }
		$sequence_1 = { 8b1e ff938c000000 8b0424 8b5014 85d2 7507 bf00000000 }
		$sequence_2 = { e8???????? 837e1800 7439 8b4620 c1e003 89c7 8b4618 }
		$sequence_3 = { 89c1 c745f401000000 3b4df4 723d ff4df4 8d7600 ff45f4 }
		$sequence_4 = { 68???????? 50 ff15???????? a3???????? 83c0fe 40 40 }
		$sequence_5 = { 8942fc 89d8 c1f81f 8b1424 8b7208 8b4a0c 29de }
		$sequence_6 = { eb02 b300 e8???????? 8d45cc e8???????? c745cc00000000 58 }
		$sequence_7 = { 33d2 b9???????? 8bc2 8bf2 c1f805 83e61f 8b0485a02e4100 }
		$sequence_8 = { 89d8 29f0 85c0 7e39 8b55f4 85d2 7505 }
		$sequence_9 = { 8b7508 8b36 8975c8 8b7d08 8b7f04 }

	condition:
		7 of them and filesize < 1581056
}
rule MALPEDIA_Win_Foalshell_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "7f1bb76a-f83f-5420-8106-dd71ad9e786c"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.foalshell"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.foalshell_auto.yar#L1-L118"
		license_url = "N/A"
		logic_hash = "af03f5397958424f9e3ccb79bceaff33fe952f45789c500604243e86111db979"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 488d156de00000 33c9 ff15???????? 488b4c2448 }
		$sequence_1 = { 488d153a9b0000 e8???????? 85c0 7430 448bc3 }
		$sequence_2 = { 488d1506aa0000 488d0ddfa90000 e8???????? 488d1503aa0000 488d0df4a90000 }
		$sequence_3 = { 7350 488bca 4c8d0565230100 83e13f 488bc2 48c1f806 }
		$sequence_4 = { 4c8bfe 49c1ff06 488d0d251a0100 83e03f 4c8d24c0 4a8b04f9 42f644e03801 }
		$sequence_5 = { 488d4c2420 e8???????? 90 4883c460 5f }
		$sequence_6 = { e9???????? 4c8d05d0170100 498bcd 498bc5 }
		$sequence_7 = { e8???????? 488b442430 488d0dc7f90000 488908 488b442430 }
		$sequence_8 = { 7519 48c744242000000000 4533c9 4533c0 33d2 33c9 }
		$sequence_9 = { 488bcb e8???????? 837b1000 75dd 488d0573340100 483bd8 74d1 }

	condition:
		7 of them and filesize < 520192
}
rule MALPEDIA_Win_Nagini_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "341306df-54fc-5875-a25f-0434cd971b1d"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.nagini"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.nagini_auto.yar#L1-L118"
		license_url = "N/A"
		logic_hash = "75f7a8a7e7fb7712bd5dc7eb18beeb4ed263e045230849b3af36552a0f364b37"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c1f805 8945e4 8bdf 83e31f c1e306 8b0485c0914200 }
		$sequence_1 = { 2c25 16 2f 27 1a30 291a 322b }
		$sequence_2 = { 06 0505050505 0504040404 0404 }
		$sequence_3 = { 090a 1109 0a0d???????? 06 0d05060c06 07 }
		$sequence_4 = { 2b7b08 037b04 8b0495c0914200 8b95f4efffff }
		$sequence_5 = { 68???????? e8???????? 83c404 6a64 ffd6 68dc050000 }
		$sequence_6 = { 0405 0a04050a04050a 0405 07 }
		$sequence_7 = { c745e40c9a4200 a1???????? eb1a c745e4089a4200 a1???????? eb0c }
		$sequence_8 = { 8b4d08 c7410801000000 8b5108 8b04958c8b4200 }
		$sequence_9 = { 6a64 6a0a 6800000050 68???????? 68???????? 6a00 ffd6 }

	condition:
		7 of them and filesize < 12820480
}
rule MALPEDIA_Win_Strelastealer_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "921fcbf6-e842-51af-94d2-f3bfd40afc24"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.strelastealer"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.strelastealer_auto.yar#L1-L233"
		license_url = "N/A"
		logic_hash = "0930c105250497c88e9d36fcc54f6a132e09d231b5d3bf0fd47c55fd6130b80d"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8bf0 89742418 83feff 0f8476020000 8d542428 52 }
		$sequence_1 = { 50 8bc7 8bcb c744240c00000000 }
		$sequence_2 = { 8b4c2428 89442440 89442444 89442434 }
		$sequence_3 = { 01c7 897d14 8d1401 81c200040000 }
		$sequence_4 = { 03c7 751f 488b85a0010000 488b8888000000 488d0505540100 }
		$sequence_5 = { 08c1 20ca 80f101 89c8 }
		$sequence_6 = { 015304 eb55 4d85c0 7e27 488bd7 4c8b4dc7 4b8b8ccbc0120600 }
		$sequence_7 = { 895c2420 4533c0 33d2 498bce ff15???????? 85c0 0f848a000000 }
		$sequence_8 = { 08c1 08d3 89ca 80e201 }
		$sequence_9 = { ff15???????? ff15???????? 3db7000000 740a e8???????? e8???????? }
		$sequence_10 = { 08c1 08da 80f201 89c8 }
		$sequence_11 = { 0f8f78020000 488bcf 4a8d14fd3e000000 4b0394cb70b00100 8a02 88440dff }
		$sequence_12 = { 4c897c2420 ff15???????? 85c0 0f85fb000000 488d15be640100 }
		$sequence_13 = { 48898190000000 488d058c180000 498b0b 4889458f 488b454f }
		$sequence_14 = { 01c1 b8dc8856d3 29c8 b9dd8856d3 }
		$sequence_15 = { 8a06 88458f 897d93 41bc01000000 4c8d1dbe37ffff 81f9e9fd0000 }
		$sequence_16 = { 6a1a 6a00 ff15???????? 68???????? ff15???????? 6a17 }
		$sequence_17 = { 48897c2438 448d4750 897c2430 488d15e8680100 c744242803000000 4533c9 }
		$sequence_18 = { 8b35???????? 51 8d8c246c010000 51 ffd6 6804010000 }
		$sequence_19 = { 8d442410 50 6800040000 56 53 896c2420 ffd7 }
		$sequence_20 = { 08c1 0f1f440000 b810000000 e8???????? }
		$sequence_21 = { 51 8d94247c030000 52 e8???????? 8be8 8d442420 }
		$sequence_22 = { 83c8ff f00fc101 83f801 751f 488b0d???????? 488d1d99350100 483bcb }
		$sequence_23 = { 8b8c2488000000 85c9 0f8483000000 03f1 }

	condition:
		7 of them and filesize < 872448
}
rule MALPEDIA_Win_Jlorat_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "1818e503-5585-5b9d-b93e-ecaa04acd4d5"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.jlorat"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.jlorat_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "e12467dbc3f47356946e998a5eda43dd4b360637d2159da034da77f0470d851a"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c7862701000000000000 c7862401000000000000 c7862001000000000000 c7868401000000000000 89e0 8908 c740041f000000 }
		$sequence_1 = { f20f108e40020000 f20f118e50020000 f20f118648020000 c786f809000009000000 89e0 8d9648020000 895004 }
		$sequence_2 = { eb2a 8b442430 89842448030000 eb1d 89e0 c74008???????? c7400421000000 }
		$sequence_3 = { f20f1145d0 89e0 8d55d0 895004 8908 e8???????? eb00 }
		$sequence_4 = { f7e1 b9d8ffffff 89c6 8b442444 8d3c82 89d8 f7e1 }
		$sequence_5 = { eb51 8b4c2408 8b44240c 8b5004 89542414 8b4008 89442418 }
		$sequence_6 = { f20f59442440 f20f11442440 f20f10442440 f20f110424 e8???????? 8844241f 8a44241f }
		$sequence_7 = { f20f118ec8000000 f20f1186c0000000 89e0 8908 e8???????? 83ec04 eb00 }
		$sequence_8 = { eb0a c644246300 e9???????? 8d4c2468 8d842440030000 890c24 89442404 }
		$sequence_9 = { eb16 8b8d00ffffff 89e0 8908 e8???????? eb00 e9???????? }

	condition:
		7 of them and filesize < 10952704
}
rule MALPEDIA_Win_Vshell_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "7c1b1e6a-f88b-5cef-a09b-5423d8db973b"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.vshell"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.vshell_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "55e453a3ab47aa7288620485d7b2a0dcfd178491d646d87065f1165a0c35d6a7"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? c700b4230000 e8???????? 4889c1 4889df 488d059f3b4f00 488b5c2430 }
		$sequence_1 = { e9???????? 488b842498000000 0fb65c2436 e8???????? 0fb6442435 488b4c2440 e9???????? }
		$sequence_2 = { e9???????? 4983f803 755b 4c8d4303 4c39c6 733d 4c898424e0000000 }
		$sequence_3 = { e8???????? 4889c1 4889df 488d05c1aa4f00 488b5c2430 e8???????? c700d9220000 }
		$sequence_4 = { e8???????? 66480f7ec0 0f1f440000 e8???????? 4889c3 488d05b1463500 eb29 }
		$sequence_5 = { eb17 440fb64c3c19 4131f1 44884c1419 4488443c19 4883c002 483d90000000 }
		$sequence_6 = { c644242f5a 48bad793ed84f6cb493c 488954241e c64424263d 31c0 6690 eb14 }
		$sequence_7 = { e9???????? 4983f804 7545 4c8d4301 4c39c6 7331 488d0565834400 }
		$sequence_8 = { e8???????? 90 89442408 48895c2410 0f1f440000 e8???????? 8b442408 }
		$sequence_9 = { e8???????? 84c0 0f84b7000000 e8???????? 48898424d8000000 48899c2488000000 488d0550f69800 }

	condition:
		7 of them and filesize < 39452672
}
rule MALPEDIA_Win_Unidentified_100_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "4fba1a10-07d9-50c8-bff6-098cca045403"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.unidentified_100"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.unidentified_100_auto.yar#L1-L121"
		license_url = "N/A"
		logic_hash = "8bba77822dea79f24a01c3a5e92fcfb7e441249bfff6b45c8a024f1cb27be617"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? c644242000 eb0b 0fb6442420 fec0 88442420 }
		$sequence_1 = { 488b4c2478 c604014a eb1c 48630424 }
		$sequence_2 = { 8d4408ff 4898 488b4c2420 0fb6542403 881401 0fb6442402 fec0 }
		$sequence_3 = { 8b442404 390424 7d1e 48630424 488b4c2430 }
		$sequence_4 = { 488b4c2428 e8???????? c644242000 eb0b }
		$sequence_5 = { 4898 0fb78444f0010000 25ff000000 8b4c2430 8d4c0901 }
		$sequence_6 = { 4883f870 0f869d010000 488b842490030000 4889442478 48c7442440ffffffff }
		$sequence_7 = { eb09 0fb60424 fec0 880424 0fb60424 83f808 7d5b }
		$sequence_8 = { 488d942400150000 33c9 e8???????? 4533c9 4c8d8424a0270000 488d942400170000 33c9 }
		$sequence_9 = { 8b9424c0200000 488d8c2400060000 ff15???????? 4889442448 83bc249020000000 0f8501010000 83bc249820000000 }

	condition:
		7 of them and filesize < 372736
}
rule MALPEDIA_Win_Tofsee_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "7201c526-7329-5f49-88fd-1dbaa4e5ee3f"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.tofsee"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.tofsee_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "0d0c90abd3529fa3edd8756a1eaf00c8a6d29244a0261ffc28afab4ff7cc5785"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff75fc ffd7 85c0 0f84f2000000 0fb7859cfeffff 8b4dbc 56 }
		$sequence_1 = { 50 ff7570 e8???????? 59 59 ff7568 ff756c }
		$sequence_2 = { 8bce ff5004 8bf0 ff7608 ff15???????? 85c0 750d }
		$sequence_3 = { 53 50 ff7514 c60702 e8???????? 83c410 85c0 }
		$sequence_4 = { 57 6a07 33c9 8bc2 }
		$sequence_5 = { 6a00 6a00 ff7564 8d852cffffff 6880000000 50 e8???????? }
		$sequence_6 = { 7443 8b5dfc 85db 7433 837d0c00 742d 57 }
		$sequence_7 = { 8bf7 741c 8b1e 53 ff742418 55 e8???????? }
		$sequence_8 = { 50 ff15???????? 8d4564 50 8d4550 50 ff15???????? }
		$sequence_9 = { e8???????? 80781000 75d4 56 8bcb e8???????? 837d0c03 }

	condition:
		7 of them and filesize < 147456
}
rule MALPEDIA_Win_Aveo_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "58fed8b1-4a4c-5644-af15-f834ce14a282"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.aveo"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.aveo_auto.yar#L1-L121"
		license_url = "N/A"
		logic_hash = "50253623bc7141d72df42bdf99f9bb3131c73cf858d2c7872df300d67b84cd17"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 894804 894808 89480c b9???????? 8d7901 8a11 41 }
		$sequence_1 = { 68???????? e8???????? 83c404 899df4fdffff eb06 89b5f4fdffff 68???????? }
		$sequence_2 = { 52 50 8d9df8feffff e8???????? }
		$sequence_3 = { 8d8dfcefffff 51 8bf8 e8???????? 33ff 39bdf4efffff }
		$sequence_4 = { e8???????? 83c40c 8d842418010000 50 8d8c241c030000 }
		$sequence_5 = { b9???????? 8d7901 8a11 41 84d2 75f9 2bcf }
		$sequence_6 = { 8db590fdffff 898574fdffff e8???????? be00100000 }
		$sequence_7 = { 50 e8???????? 8d8df4f9ffff 51 8d95f4feffff 52 }
		$sequence_8 = { 6803800000 50 ff15???????? 8b4de8 6a00 6a05 }
		$sequence_9 = { 51 e8???????? 8b4df8 83c404 5f }

	condition:
		7 of them and filesize < 180224
}
rule MALPEDIA_Win_Abaddon_Pos_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a37088aa-d217-5877-b1fd-7a9dc5473093"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.abaddon_pos"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.abaddon_pos_auto.yar#L1-L162"
		license_url = "N/A"
		logic_hash = "7a484363d105e19011bfbb655395d654a3cc7c0b2102535e37ccd9d134019faa"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 750a 83fb3c 7605 e9???????? }
		$sequence_1 = { 0f8455010000 8b85c8feffff 3905???????? 7502 ebd8 31db }
		$sequence_2 = { eb27 8b8600010000 03860c010000 89867c010000 }
		$sequence_3 = { ff45f4 eb06 43 e9???????? 68c8000000 ff15???????? }
		$sequence_4 = { 8b8ec0050000 48 c7c200000000 ff15???????? 48 }
		$sequence_5 = { ebe4 50 ff15???????? 6a00 6a00 }
		$sequence_6 = { 7524 8b869c010000 b400 b202 f6f2 80fc00 7507 }
		$sequence_7 = { 49 c7c0???????? 49 c7c100000000 }
		$sequence_8 = { ff15???????? 48 83c420 48 83ec20 48 8b8ed0050000 }
		$sequence_9 = { ff15???????? 48 83c430 48 8986c0050000 48 }
		$sequence_10 = { 48 8b8ed0050000 48 c7c200d00700 ff15???????? 48 83c420 }
		$sequence_11 = { 7205 e9???????? eb91 81be0c01000080cf0700 7607 }
		$sequence_12 = { ff15???????? 48 83c420 c7437800000000 48 83ec20 }
		$sequence_13 = { 0396a0010000 01da 80beb001000001 7502 }
		$sequence_14 = { 6800300000 6800100000 6a00 ff15???????? 83f800 7502 ebe5 }

	condition:
		7 of them and filesize < 40960
}
rule MALPEDIA_Win_Tropidoor_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "0f05d11c-257c-5def-b1df-653842e5970f"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.tropidoor"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.tropidoor_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "ef1794416efc92c8280fc54c570b04a4cffce78679d89da156d0aa3e4ae53ff1"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff5210 85ff 7930 448bc7 488d151f9d0900 488d8db0010000 ff15???????? }
		$sequence_1 = { c3 b001 ebe7 4c8b02 4c8d1dde7af8ff 4c8bd1 4c8bca }
		$sequence_2 = { 41c1ea02 416bca07 443bc9 0f8527010000 b8abaaaaaa 41f7e2 c1ea04 }
		$sequence_3 = { 48c744242010000000 4c8d4d00 ba10000000 488d4db8 e8???????? 488d4510 48837d2810 }
		$sequence_4 = { ff5010 ff15???????? b802000000 e9???????? 4c897558 488b4d50 488b01 }
		$sequence_5 = { c745141ca61aa6 c7451807a604a6 c7451c52a648a6 c7452005a609a6 c7452410a645a6 c7452809a60fa6 c7452c0da655a6 }
		$sequence_6 = { 668945e4 8bc1 663305???????? 668945e6 8bc1 663305???????? 668945e8 }
		$sequence_7 = { 83f806 7713 488d1548dafdff 8b8c82c0280200 4803ca ffe1 4183fc01 }
		$sequence_8 = { 488b4f20 ffd6 85c0 0f844a100000 b90da30000 c74424600da34ca3 c74424646ea36ea3 }
		$sequence_9 = { 4d8d4001 6685c9 75ed 4c8d85d0090000 498bd7 4d2bc7 0fb70a }

	condition:
		7 of them and filesize < 1826816
}
rule MALPEDIA_Win_Unidentified_121_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "5d129fa0-afdf-5a7d-92c7-d7063a2a7a94"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.unidentified_121"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.unidentified_121_auto.yar#L1-L160"
		license_url = "N/A"
		logic_hash = "d591e8aab9443eafe5d03fcad252235880705fde306fd8a63c156f931fe6cbc3"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b55fc 8b4518 89420c 8b4dfc 8b551c }
		$sequence_1 = { 807b0c5a 0f8578fdffff 4883c30d 31d2 }
		$sequence_2 = { 8b55fc 8b4514 8a08 884a2d }
		$sequence_3 = { 8b55fc 8b4518 894208 837dd401 }
		$sequence_4 = { 31c0 b90a000000 488d35779e0000 f3a5 488d7c2448 b943000000 }
		$sequence_5 = { 4e8d3c01 b920000000 f348ab c70700000000 0f8550010000 418b4114 }
		$sequence_6 = { 750c 48837c242801 0f8675fbffff 85ff 0f89c1fbffff e8???????? }
		$sequence_7 = { 8b55fc 8b451c 89422c 8b4dfc }
		$sequence_8 = { 8b55fc 8b4518 668b08 66894a32 }
		$sequence_9 = { 74ae 8b4338 3b433c 7da6 488b5330 }
		$sequence_10 = { 488d9424f0000000 4889d9 ff15???????? 31c9 ff15???????? 4531c9 4531c0 }
		$sequence_11 = { 8b55fc 8b4518 894268 6a08 }
		$sequence_12 = { 8b55fc 8b4520 894260 8b4dfc }
		$sequence_13 = { 8b55fc 8b4514 8b4d18 894204 }
		$sequence_14 = { 4889d7 4183fe01 4889d6 4519ed 4183e5fd 4183c51e 4183fe01 }
		$sequence_15 = { 80fa09 0f8757ffffff 0fb65002 488d4802 }

	condition:
		7 of them and filesize < 2419712
}
rule MALPEDIA_Win_Glooxmail_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f334a45a-a5a6-571d-bfc7-019a2c6bf945"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.glooxmail"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.glooxmail_auto.yar#L1-L133"
		license_url = "N/A"
		logic_hash = "8d415c887bc53e9c2aa2f7c01cded957b95432d27de8828a9d0edc2e084c1e33"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 81cb00080000 57 8d8d98feffff 895dec e8???????? 8d8d28feffff 51 }
		$sequence_1 = { e8???????? 33f6 c645fc01 46 68???????? 8d8d7cffffff 8975f0 }
		$sequence_2 = { 8d742424 e8???????? 8b4c241c e9???????? 8ac3 eb02 }
		$sequence_3 = { e8???????? c78424600800005e000000 8b07 8bcf ff506c 8b16 058c000000 }
		$sequence_4 = { 8d4dd8 e8???????? 8b7d54 395f54 7452 56 e8???????? }
		$sequence_5 = { 33c5 89853c020000 6a20 b8???????? e8???????? 8b8548020000 8bf1 }
		$sequence_6 = { ff7020 8b4c2414 ff7508 ff17 eb46 8b450c 83e800 }
		$sequence_7 = { 8b8544a30100 898518830000 8d4588 89851c830000 8d4584 898528830000 33c0 }
		$sequence_8 = { ff502c 8bcb e8???????? 84c0 7504 b301 eb02 }
		$sequence_9 = { 84c0 7437 68ec000000 e8???????? 59 8945d0 c645fc03 }

	condition:
		7 of them and filesize < 761856
}
rule MALPEDIA_Win_Hancitor_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "5d89f70f-c12d-53fd-9a67-c652085b4524"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.hancitor"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.hancitor_auto.yar#L1-L262"
		license_url = "N/A"
		logic_hash = "2a7d6a173b43ba095492c692a96409f69534de8c7803f299fd1a393ceae4879f"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 6824040000 6a00 6a00 6a00 }
		$sequence_1 = { 6a00 6a00 6824040000 6a00 }
		$sequence_2 = { 6800010000 6a40 68???????? e8???????? }
		$sequence_3 = { 750d e8???????? 83c010 a3???????? }
		$sequence_4 = { 6a20 68???????? 68???????? e8???????? 83c410 83f801 }
		$sequence_5 = { 55 8bec 81ec58010000 6a44 }
		$sequence_6 = { 8b4508 8945e4 8b4de4 8b5508 03513c 8955e0 }
		$sequence_7 = { 894508 ebc8 c745fc00000000 b901000000 85c9 }
		$sequence_8 = { 8b450c 53 56 57 8b483c 33f6 03c8 }
		$sequence_9 = { 55 8bec 8b4d08 6a00 6a01 }
		$sequence_10 = { 8b4508 eb23 8b4d0c 034dfc 8b5508 8a02 }
		$sequence_11 = { 8955d4 8b45f4 83c008 8945f8 c745ec00000000 eb09 }
		$sequence_12 = { 8bd8 83fbff 7509 6a00 57 ff15???????? }
		$sequence_13 = { e9???????? 837de800 0f849a000000 8b4df4 8b5104 83ea08 d1ea }
		$sequence_14 = { 6a00 6a01 51 8b413c 8b440828 03c1 }
		$sequence_15 = { 8b4514 8b4dfc 85c0 7402 8908 8b5518 }
		$sequence_16 = { 83c410 83f801 750e 57 ff15???????? }
		$sequence_17 = { eb9d 8b45f4 8b4de8 2b4804 894de8 8b55f8 8955f4 }
		$sequence_18 = { 57 ff7508 ff15???????? 5f 8bc6 }
		$sequence_19 = { c705????????053f0f00 c745c007000000 c745dcc8954000 a1???????? 8945ec 8b45d8 2345e4 }
		$sequence_20 = { 8b45d8 2345e4 8945d8 c645f300 c645fc65 }
		$sequence_21 = { a3???????? b9382baa99 c7458ce4f25701 ff15???????? 894da0 a1???????? }
		$sequence_22 = { 8b69e8 1540003708 088f65497d4d 89ec 7973 }
		$sequence_23 = { a1???????? a3???????? b9382baa99 8d45fc 50 6a00 6a00 }
		$sequence_24 = { 83c05b a3???????? a1???????? 0345cc }
		$sequence_25 = { 83c044 a3???????? 8b45b4 83e803 }
		$sequence_26 = { a3???????? ebc5 8365d400 c745d0049d4000 a1???????? 8945d8 }

	condition:
		7 of them and filesize < 106496
}
rule MALPEDIA_Win_Pandabanker_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "045fe7c2-3f16-58d1-86a5-2b3aa95f734d"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.pandabanker"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.pandabanker_auto.yar#L1-L118"
		license_url = "N/A"
		logic_hash = "f5cf32100b5897de97369181ca8ee8de88e76b042f975bd4a901e6828babc30d"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8d5b03 8b0487 c1e808 0fb6c0 }
		$sequence_1 = { 7406 3919 7402 b301 8bcf }
		$sequence_2 = { 52 51 33c9 32d2 }
		$sequence_3 = { c60600 33d2 8bcb 42 }
		$sequence_4 = { e8???????? 8a442416 8acb 885c2417 84c0 }
		$sequence_5 = { 663bf9 668902 1bc0 83e007 83c030 6603c1 }
		$sequence_6 = { 395d00 7422 8b542414 8d442420 50 8d442420 8bcd }
		$sequence_7 = { ff742418 8bc8 8bfd f3a4 8b742418 8d3c28 }
		$sequence_8 = { 8bc2 33ed 89442410 894c240c 8a9f00010000 8abf01010000 }
		$sequence_9 = { 75f9 2bce 5e 8d040a c3 33c0 c3 }

	condition:
		7 of them and filesize < 417792
}
rule MALPEDIA_Win_Nachocheese_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "bac1febc-60a8-5f8d-a92e-61f6bdb3f9e2"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.nachocheese"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.nachocheese_auto.yar#L1-L160"
		license_url = "N/A"
		logic_hash = "ccbc3b1239f3df4418ae22c6f467129e07ceebe0ce5c42cbd92c079146e97df6"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 6a01 688d000000 56 e8???????? 50 }
		$sequence_1 = { 3d2bc00000 7d1b 3d9c000000 7c07 }
		$sequence_2 = { c3 8d85ecfaffff 68???????? 50 e8???????? 83c408 85c0 }
		$sequence_3 = { 81fb00000100 7305 83c304 eb0f }
		$sequence_4 = { 85c0 741c 8b8de8faffff 68???????? }
		$sequence_5 = { 33c8 894710 8b4708 33c1 }
		$sequence_6 = { 7f05 83e830 eb03 83e837 }
		$sequence_7 = { 3d9f000000 7e0d 33c0 c3 }
		$sequence_8 = { 33c0 c3 05d13fffff 83f801 }
		$sequence_9 = { 3d2cc00000 7f18 3d2bc00000 7d1b }
		$sequence_10 = { 52 66894b02 ff15???????? 8bf0 }
		$sequence_11 = { 8895f0fcffff 8d95f1fcffff 6a00 52 e8???????? 6a3a 68???????? }
		$sequence_12 = { 3d9c000000 7c07 3d9f000000 7e0d }
		$sequence_13 = { 2bfa 8d47fd 3901 8901 }
		$sequence_14 = { 33f6 6a03 8bf9 8975f8 e8???????? 83c404 8975fc }
		$sequence_15 = { 8b55fc 880c3e 8a540205 32d1 8b4df8 88143e 8a4c0105 }

	condition:
		7 of them and filesize < 1064960
}
rule MALPEDIA_Win_Doublefantasy_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "52523c3b-8064-5ba1-97b3-2b80295cc37c"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.doublefantasy"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.doublefantasy_auto.yar#L1-L174"
		license_url = "N/A"
		logic_hash = "7f3304301cf710af29f5367fe39be351c100c3b66b41462b204e02911ddd2dc6"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c1e204 0bd6 837c241001 8a92908c2700 }
		$sequence_1 = { c9 c3 8b442404 0fb608 c1e902 8a91908c2700 8b4c2408 }
		$sequence_2 = { 7509 c745e4fdffffff eb7d ff7518 56 50 e8???????? }
		$sequence_3 = { 8bec 83ec0c a1???????? 85c0 7522 68???????? }
		$sequence_4 = { c1e202 0bd6 8a92908c2700 eb02 b23d 837c241002 }
		$sequence_5 = { 8a91908c2700 8b4c2408 8811 33d2 8a10 }
		$sequence_6 = { 51 56 57 8b7d14 33f6 813f00280000 8975fc }
		$sequence_7 = { 0fb64002 83e03f 8a80908c2700 eb02 }
		$sequence_8 = { 3c7a 770b 0fb6c0 8a80ad8c2700 }
		$sequence_9 = { e8???????? 8b4605 c68094a3270000 ff35???????? ff35???????? }
		$sequence_10 = { 7456 be01020000 56 ff15???????? 8bf8 897dd8 }
		$sequence_11 = { 8a80ad8c2700 eb02 32c0 84c0 }
		$sequence_12 = { 8b35???????? 8d85ccfeffff 50 68???????? ffd6 85c0 }
		$sequence_13 = { 56 8d45c0 50 ff750c ff7508 e8???????? 83c414 }
		$sequence_14 = { e9???????? 8b7510 6a00 8d45fc 50 68ff270000 46 }
		$sequence_15 = { 3bc6 0f850a010000 8d45c8 50 8d45d4 50 56 }

	condition:
		7 of them and filesize < 172032
}
rule MALPEDIA_Win_Arik_Keylogger_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "78dac55d-2771-594f-84ba-83bcaef9e2d0"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.arik_keylogger"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.arik_keylogger_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "ab859cdc545d056c4c933703da2ba37ed498d6da4fbd73a4220250907f1d87ba"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8d907cffffff 8b45f8 8b40f8 8b4008 e8???????? 8b45f8 8b807cffffff }
		$sequence_1 = { 8b55bc 29d0 89459c 48 89c7 c745c000000000 3b7dc0 }
		$sequence_2 = { db7dc0 8d55c0 8955ec c745e803000000 dd4508 db7db0 8d55b0 }
		$sequence_3 = { b803000000 234210 83f802 751f 8b45fc 8b400c 85c0 }
		$sequence_4 = { 8d956cfeffff b801000000 e8???????? e8???????? 50 85c0 0f85e9030000 }
		$sequence_5 = { 8d7dc4 fc a5 8d45bc e8???????? c745bc00000000 8d55bc }
		$sequence_6 = { 8b45f8 8b88a8010000 8b45f8 8b900c010000 8b45f8 8b8070010000 8b5df8 }
		$sequence_7 = { 8b80fc000000 e8???????? 84c0 744e 8b45f4 8b80fc000000 8b80c4020000 }
		$sequence_8 = { eb41 ff864c010000 8b864c010000 48 8986f8000000 8b96dc000000 8b86e0000000 }
		$sequence_9 = { e8???????? c7458400000000 8b55e8 4a 8d4d84 8b45fc e8???????? }

	condition:
		7 of them and filesize < 4947968
}
rule MALPEDIA_Win_Rhttpctrl_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "0c1f067f-4c03-5217-84ef-e2056be8411e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.rhttpctrl"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.rhttpctrl_auto.yar#L1-L126"
		license_url = "N/A"
		logic_hash = "e08ad966d09dce27a6d8e5d5ac2bacf3849e80bd61e38dcdd72f40d98e9b8f3d"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { d1fe 6a55 ff34f5c0d54100 ff7508 e8???????? 83c40c 85c0 }
		$sequence_1 = { ffd7 8b4c241c ff742410 8b35???????? 894114 ffd6 }
		$sequence_2 = { 6a00 8d442418 50 8d4714 50 56 }
		$sequence_3 = { 2bc3 39460c 0f8660ffffff 50 53 6aff ff7608 }
		$sequence_4 = { 83c408 895f08 837f1400 c7471001000000 }
		$sequence_5 = { 8b01 52 8d95f0d7ffff 52 ff5004 }
		$sequence_6 = { 8d8424e4010000 6a00 50 e8???????? 83c40c c68424c001000000 }
		$sequence_7 = { c705????????090400c0 c705????????01000000 c705????????01000000 6a04 58 6bc000 c780f43b420002000000 }
		$sequence_8 = { 3bc1 7410 50 e8???????? 83c404 0f1085c0feffff 8b4508 }
		$sequence_9 = { 8b7d0c 8bd9 85ff 7417 803e52 750c 807e0145 }

	condition:
		7 of them and filesize < 339968
}
rule MALPEDIA_Win_Sslmm_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "35206317-b8ae-51c9-8dc1-60e9fd9a5ece"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.sslmm"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.sslmm_auto.yar#L1-L117"
		license_url = "N/A"
		logic_hash = "665c7c985c284d0e4d4a81214a36643d9d808d985449a5ad816bd5436786cfaa"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 50 896c2460 c744245c07000000 895c246c }
		$sequence_1 = { 85c0 742c 8b442414 8d4e0c 50 51 e8???????? }
		$sequence_2 = { 0f84a1000000 33c9 57 894c240c 50 894c2414 894c2418 }
		$sequence_3 = { 7527 8b442438 8bc8 2bf8 }
		$sequence_4 = { 89ac2484000000 89ac2490000000 896c2448 c744244c04000000 ff9358010000 3d18030980 89442428 }
		$sequence_5 = { 52 8b54246c 50 8b44246c 57 }
		$sequence_6 = { f3a4 8b8b6c010000 8bbb68010000 8bd1 8d3428 }
		$sequence_7 = { 51 89869c000000 e8???????? 8b9790000000 83c408 899690000000 }
		$sequence_8 = { 8b8370010000 83c404 3bc5 894c2410 }
		$sequence_9 = { 0f8455010000 8b460c 50 6a00 }

	condition:
		7 of them and filesize < 188416
}
rule MALPEDIA_Win_Newcore_Rat_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "fedf223b-da0b-5727-9ef7-6128647534b3"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.newcore_rat"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.newcore_rat_auto.yar#L1-L126"
		license_url = "N/A"
		logic_hash = "d71f8e1a8473706d9e4452e9526830c2efe656eb1c76ea39316f54300468a7f5"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8bc6 e8???????? eb0c c7035a1b0000 }
		$sequence_1 = { 6a04 8d4c2418 51 52 895c2424 ffd7 }
		$sequence_2 = { 014c242c b81f85eb51 f7eb c1fa04 8bca c1e91f }
		$sequence_3 = { 6a00 8d7c2413 bd01000000 55 8bc7 50 53 }
		$sequence_4 = { ffd0 8d8c2484040000 6800010000 51 e8???????? 83c408 }
		$sequence_5 = { 8b8510100000 3bc3 7409 50 ffd6 899d10100000 8b850c100000 }
		$sequence_6 = { 8b7508 8b8688300000 50 ff15???????? 5f 5e }
		$sequence_7 = { 50 52 51 83c004 50 e8???????? 8b8e70300000 }
		$sequence_8 = { 740d 50 ffd7 c7869440000000000000 8b8690400000 85c0 740d }
		$sequence_9 = { 50 8b4204 ffd0 57 8d8c2470040000 51 }

	condition:
		7 of them and filesize < 581632
}
rule MALPEDIA_Win_Locky_Decryptor_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "97c9e398-954a-57b1-8304-2c293a37f81e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.locky_decryptor"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.locky_decryptor_auto.yar#L1-L126"
		license_url = "N/A"
		logic_hash = "9ba56fcb8ed60b5aa7e41ba2ff138a912720b829911f6d9398627614975ad4e3"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 3b45d8 0f8417ffffff 8b45dc 89855cffffff 8b45e0 8945d0 }
		$sequence_1 = { c605????????01 e8???????? 6a07 58 33db 33c9 }
		$sequence_2 = { 8bc6 c9 c21000 ff15???????? 50 }
		$sequence_3 = { 8b4508 eb29 ff75e8 8b7508 8d8405ccfaffff 50 }
		$sequence_4 = { 89450c 57 8d4510 7203 8d450c 8b38 8d75d8 }
		$sequence_5 = { c20c00 55 8bec 8b00 83ec10 6a00 8d4d0c }
		$sequence_6 = { 7418 56 56 56 8d85a8f7ffff 50 }
		$sequence_7 = { 83c058 0fb691106b4100 660f6fc8 660f73f904 660fefc1 660f6fc8 }
		$sequence_8 = { 7209 83ffff 0f879c000000 8d742424 e8???????? c644244c01 85db }
		$sequence_9 = { ff75f4 ff55f8 85c0 743f be???????? 8d4590 }

	condition:
		7 of them and filesize < 278528
}
rule MALPEDIA_Win_Unidentified_098_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "71065072-1e56-58d6-b667-6020f0f73abc"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.unidentified_098"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.unidentified_098_auto.yar#L1-L133"
		license_url = "N/A"
		logic_hash = "6ecdccbb3e7d2c06f31587b6f07f8b495d651b83694b03afada84b1e8c8b2d12"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 488b4310 488b5318 c644247e01 4839d0 0f83db000000 4883c002 }
		$sequence_1 = { b80f000000 4989c3 4c8b8c2400010000 488b8c2408010000 4c8b8424c8000000 4939f9 4c0f459c2410010000 }
		$sequence_2 = { ff15???????? 0fb606 6683f808 0f85affeffff 48837e0800 0f85a4feffff 41b847490000 }
		$sequence_3 = { a980800000 0f44c1 488d4b02 89c7 480f44d9 4000c7 4883db03 }
		$sequence_4 = { 7407 3b4220 480f4cd6 8b4224 41894008 4c8bb424c0000000 e8???????? }
		$sequence_5 = { 498d88f0010000 498d9000020000 c4e1f96ee1 c4c3d922c001 c4e1f96eea c5f8118360010000 c4e3d122c001 }
		$sequence_6 = { 488b5230 f6044208 0f84cc010000 83ed38 4080fd01 0f86bf010000 4c8b83d0000000 }
		$sequence_7 = { bf10000000 b80a000000 0f45f8 66837c243cff 410f94c6 4d85e4 410f95c5 }
		$sequence_8 = { 3c20 7407 88842f39010000 488b8ba0000000 e8???????? 4885c0 0f84a6020000 }
		$sequence_9 = { 4c89e1 e8???????? 488b8b30010000 e8???????? 48c7833001000000000000 48c7833801000000000000 e8???????? }

	condition:
		7 of them and filesize < 3345408
}
rule MALPEDIA_Win_Vsingle_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f29a9955-bdf2-5350-b654-461a5688ac59"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.vsingle"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.vsingle_auto.yar#L1-L171"
		license_url = "N/A"
		logic_hash = "e1707c9c5107ad6d6f94fd229e0a7dbd8ccf2b18bf7c7347a4931985ce6478a7"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8945fc 56 57 c6850cffffff00 68ef000000 6a00 8d850dffffff }
		$sequence_1 = { 8955c5 8955c9 668955cd 8855cf c645d000 33c0 }
		$sequence_2 = { 51 ff15???????? 8b5508 52 ff15???????? 83c001 }
		$sequence_3 = { 33c0 668985d4f6ffff 68fe070000 6a00 }
		$sequence_4 = { 8945fc 64a130000000 8945f8 8b45f8 8b4dfc 33cd e8???????? }
		$sequence_5 = { 51 ff15???????? 898564fdffff 83bd64fdffff00 7428 8b9564fdffff }
		$sequence_6 = { 33c0 668985ccb6ffff 6800200000 6a00 8d8dceb6ffff }
		$sequence_7 = { 51 ff15???????? 8d94057cfeffff 52 }
		$sequence_8 = { 81f2feed50fa 81eafe544f3b 81eabaac6ad1 8b042a eb0b 8b142b 5b }
		$sequence_9 = { 8b042b 5b 53 bb8fbc7c14 81c30cf1050f e9???????? }
		$sequence_10 = { eb3c 59 eb16 ba334d6d4b 81c279cf504e }
		$sequence_11 = { 81ebe35ad2f1 81c37daa580d 895c2404 5b e9???????? }
		$sequence_12 = { 81f1073623a7 81c16ea9e414 e9???????? eb15 81f0f63bb4b4 81f0556c2d03 }
		$sequence_13 = { b8e64d1443 81e8dc1e5dbe eb0a bf3d4243d4 e9???????? }
		$sequence_14 = { be11c85cd5 81f61f666769 81c6bc95fea7 e9???????? 897c2404 5f }
		$sequence_15 = { 8bec 83ec14 50 b8733628ff }

	condition:
		7 of them and filesize < 940032
}
rule MALPEDIA_Win_Nvisospit_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "77deed29-b32a-549a-bfda-820369eb3448"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.nvisospit"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.nvisospit_auto.yar#L1-L118"
		license_url = "N/A"
		logic_hash = "f13acc45e62cc5f3d016af61714a58d8d05e9674ab9128ac6ed4c63fb21a59ff"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 0f8e16010000 85d2 0f8493010000 b9???????? 81f9???????? 7384 }
		$sequence_1 = { 8d95a2f9ffff 89542420 8d95a4f9ffff 8954241c 8d95acfbffff 89542418 }
		$sequence_2 = { 8d1c76 c1e302 01d8 897808 c70000000000 }
		$sequence_3 = { 8b8000004000 83fb10 8db900004000 8945c4 0f849d000000 83fb20 }
		$sequence_4 = { 8b7104 85f6 0f85dffeffff 8b4108 }
		$sequence_5 = { 8d9da4f9ffff 81c307010000 895c2414 8d9da4f9ffff }
		$sequence_6 = { 8b55d4 8954240c c7442408???????? c744240400000000 890424 }
		$sequence_7 = { c78594f9ffff01000000 66c78592f9ffff0000 c6857df9ffff4d c6857ef9ffff4d c6857ff9ffff4b 8b45dc }
		$sequence_8 = { 81c307010000 895c2414 8d9da4f9ffff 83c306 895c2410 894c240c 89542408 }
		$sequence_9 = { ffd0 83ec04 c70424???????? e8???????? 8b4304 }

	condition:
		7 of them and filesize < 66560
}
rule MALPEDIA_Win_Akdoortea_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "273d2f0d-acc7-5ac9-9a11-3e8564a6c5a7"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.akdoortea"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.akdoortea_auto.yar#L1-L127"
		license_url = "N/A"
		logic_hash = "2fa5ad11741a8504cc8c2573ed395ff2e4f2dd319c182aa1bdba253b5a1bde31"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 006118 40 007019 40 00411a }
		$sequence_1 = { 7641 8d85f0feffff 8d5001 0f1f8000000000 8a08 }
		$sequence_2 = { 8d8df0f9ffff 8d5002 e8???????? 8bf0 83c420 85f6 }
		$sequence_3 = { 8bec 83ec0c 53 8bda 56 8bf1 57 }
		$sequence_4 = { 50 8b04bdf8204200 ff741818 ff15???????? 85c0 0f95c0 eb02 }
		$sequence_5 = { 7439 8d56ff 8a4201 8d5201 84c0 75f6 }
		$sequence_6 = { 90 85f6 740b 83feff 0f859a000000 eb6c 8b1c8d10a24100 }
		$sequence_7 = { e8???????? 83c414 ebe1 8b55ec 8b4de8 8b0495f8204200 807c082800 }
		$sequence_8 = { 83c418 c745f803010000 8d45f8 50 8d4304 50 ff15???????? }
		$sequence_9 = { ffd6 68f4010000 8bf0 ff15???????? 85ff 740e }

	condition:
		7 of them and filesize < 305152
}
rule MALPEDIA_Win_Inc_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "ab39db06-beb6-58cc-8875-f7a85d9b8f22"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.inc"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.inc_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "f296500550ebb5cc2810a6dfdf5f1dc3a2b4639eb0b4753856974fbde3aed5c9"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { eb12 4c89e8 48d1e8 49ffc5 49d1ed 4d89ee 4989c5 }
		$sequence_1 = { 84c0 0f856f040000 48c70600000000 885e08 e9???????? 4889f1 89ea }
		$sequence_2 = { 89c7 66c1c708 4c89f1 e8???????? 0f1000 0f29442440 4c89f1 }
		$sequence_3 = { e8???????? 41b801001100 84c0 7415 4189f5 eb28 41bd6e000000 }
		$sequence_4 = { 84c0 488b9c2428010000 0f8527020000 488d8c24a0000000 488d742450 4889f2 e8???????? }
		$sequence_5 = { 75ca 4c89f1 4889c2 e8???????? 498b4610 ebb9 31db }
		$sequence_6 = { 4989f0 e8???????? 488d8c24a8030000 4889ea 4989f8 488bbc2478040000 e8???????? }
		$sequence_7 = { f30f6f4b03 660f740d???????? 660f7405???????? 660fdbc1 660fd7c0 3dffff0000 0f852bfdffff }
		$sequence_8 = { 884c2420 243f 0c80 88442421 41bc02000000 eb27 89ca }
		$sequence_9 = { ba1b000000 e9???????? 488d0df08b0600 ba1e000000 e9???????? 488d0dbf8b0600 ba20000000 }

	condition:
		7 of them and filesize < 4471808
}
rule MALPEDIA_Win_No_Justice_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "aca47e83-84a2-5108-a369-f472d0d5843a"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.no_justice"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.no_justice_auto.yar#L1-L116"
		license_url = "N/A"
		logic_hash = "3a31a46c0abcc6bf9e50fa2b25fe13a39c2c8607e75eadf0d2c2ccf83361fbaf"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 50 e8???????? 83a670be410000 59 83c604 81fe00020000 72dd }
		$sequence_1 = { 8bd7 c1fa06 8934b8 8bc7 83e03f 6bc838 8b049570be4100 }
		$sequence_2 = { 833d????????00 0f84da190000 83ec08 0fae5c2404 }
		$sequence_3 = { 53 56 8d1c8538c24100 8b13 }
		$sequence_4 = { 3b0cc5d84e4100 7427 40 83f82d 72f1 }
		$sequence_5 = { 8b45b8 0fb600 0fbe8060b74100 40 8945c8 }
		$sequence_6 = { 83c414 ebe1 8b55ec 8b4de8 8b049570be4100 807c082800 7d55 }
		$sequence_7 = { 6bde38 8b04bd70be4100 807c182800 7d46 8b750c }
		$sequence_8 = { 8b5d08 8b048570be4100 56 57 }
		$sequence_9 = { 8b55ec 8b4de8 8b049570be4100 807c082800 }

	condition:
		7 of them and filesize < 253952
}
rule MALPEDIA_Win_Funksec_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "7c285211-c246-5030-8d4c-dff59d7be703"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.funksec"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.funksec_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "d304fb4d8aa09af7e3d7eb327d347a7b234ba32713e85808173d159cf5c6e5b4"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 664689bc766c010000 4589f7 41c1e705 4a8d143e 89f9 c1e105 }
		$sequence_1 = { e9???????? 488d150bd81300 41b81c000000 4889c1 4883c438 e9???????? 4883c108 }
		$sequence_2 = { e9???????? 488d8db8000000 e8???????? 488b85b8000000 4885c0 0f8423feffff f048ff08 }
		$sequence_3 = { c3 488d442424 4889442428 488d0593070000 4889442430 488d051fea1e00 4889442438 }
		$sequence_4 = { e8???????? 4c8d050c732f00 4889c2 e8???????? 4c8d05fd722f00 b902000000 ba02000000 }
		$sequence_5 = { ff5020 eb4f 488b4108 4885c0 7413 f048ff08 750d }
		$sequence_6 = { 80e301 41d0e9 4180e101 48be0000000000000080 48897108 44894120 44895124 }
		$sequence_7 = { e9???????? 488d1515313500 488d8d80000000 41b815000000 e9???????? 488d85b8000000 48894558 }
		$sequence_8 = { f30f6f8570020000 0f108d80020000 488b8de8010000 0f114938 f30f7f4128 4c894110 48895118 }
		$sequence_9 = { e8???????? 84c0 0f84b40b0000 488b8590020000 0fb68d98020000 4c8d8530020000 410f104070 }

	condition:
		7 of them and filesize < 10986496
}
rule MALPEDIA_Win_Shylock_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "1fc409e6-5d73-58d6-a99f-d630656df3b1"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.shylock"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.shylock_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "a84c40560b9eede4e90ef1c0e15d7b94468ef7a0f31b029442360399456b33c2"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 50 e8???????? 59 59 89433c 3bc6 }
		$sequence_1 = { ff7508 33db e8???????? 59 85c0 0f840d010000 8d8d70fdffff }
		$sequence_2 = { e8???????? 8b750c 83c604 8d5de4 e8???????? 8bf3 e9???????? }
		$sequence_3 = { e8???????? c745f001000000 5e 5f ff75fc e8???????? ff75f4 }
		$sequence_4 = { ff7630 e8???????? 894630 83c40c 57 ff36 ff7508 }
		$sequence_5 = { 8d45cc 50 b8???????? e8???????? 59 8d45cc 50 }
		$sequence_6 = { 8bec 51 53 8b5f2c 56 8b773c 2b7774 }
		$sequence_7 = { e8???????? 8d7dec e8???????? 8b4508 5f 5e 5b }
		$sequence_8 = { 8d7d10 e8???????? 8b4d10 c645ff01 85c9 741b e8???????? }
		$sequence_9 = { e8???????? ff37 8bfe e8???????? ff75fc 8b7d08 e8???????? }

	condition:
		7 of them and filesize < 630784
}
rule MALPEDIA_Win_Arefty_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "8b122cad-9a6a-560d-9a50-c40df82ee2c0"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.arefty"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.arefty_auto.yar#L1-L125"
		license_url = "N/A"
		logic_hash = "bcb754197ff84bb238d0264806e14e837240f5a52ca3a07dd6f850d6cb2088ac"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 7409 57 e8???????? 83c404 83fbff 7407 53 }
		$sequence_1 = { 50 53 ff15???????? 680000a000 e8???????? 8bf8 }
		$sequence_2 = { 8b07 68???????? 6a03 8d04b0 50 }
		$sequence_3 = { ff15???????? 85ff 7409 57 e8???????? 83c404 83fbff }
		$sequence_4 = { 8b07 68???????? 6a03 8d04b0 }
		$sequence_5 = { 50 53 ff15???????? 680000a000 e8???????? 8bf8 83c404 }
		$sequence_6 = { 0fb6041e 50 8b07 68???????? 6a03 8d04b0 50 }
		$sequence_7 = { 50 8b07 68???????? 6a03 8d04b0 50 e8???????? }
		$sequence_8 = { 8b07 68???????? 6a03 8d04b0 50 e8???????? }
		$sequence_9 = { 50 8b07 68???????? 6a03 8d04b0 }

	condition:
		7 of them and filesize < 237568
}
rule MALPEDIA_Win_Coronavirus_Ransomware_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "5b92420e-f422-5cb6-a012-b1b84474cae8"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.coronavirus_ransomware"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.coronavirus_ransomware_auto.yar#L1-L120"
		license_url = "N/A"
		logic_hash = "e248a3195ee48c66a6558c94873decfec30628a6ec70e98b3e927d9a4d0e85a0"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 52 ff15???????? a3???????? e8???????? 8b0d???????? 8b15???????? }
		$sequence_1 = { 8b15???????? 83c408 8d4f01 51 6a08 52 ff15???????? }
		$sequence_2 = { 389ffd010000 0f857b040000 8b7c2418 0faf7c2428 0faf7c2424 57 }
		$sequence_3 = { 884602 0fb691d83b4100 885603 8b06 8906 0fb64e04 }
		$sequence_4 = { 85c0 0f84fd040000 8b44242c 3d00020000 }
		$sequence_5 = { 8b15???????? 6a11 52 ffd7 }
		$sequence_6 = { 8d4de0 51 ff15???????? 50 ff15???????? 8945d0 c68578ffffff00 }
		$sequence_7 = { 7536 ff15???????? 68???????? 8bf8 e8???????? }
		$sequence_8 = { 8d45e4 50 6a07 ff15???????? 50 ff15???????? }
		$sequence_9 = { 807d0c01 56 7510 8b75e8 8b7dcc }

	condition:
		7 of them and filesize < 235520
}
rule MALPEDIA_Win_Victorygate_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "6298295d-e429-5bb9-94d7-f3433215fbd0"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.victorygate"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.victorygate_auto.yar#L1-L126"
		license_url = "N/A"
		logic_hash = "6e9d7831fcf509057c37e195ace77cb26c25b657cc9c25abb62cb644d96a9d0f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b95e0fcffff 8d8d0cfdffff 8d7102 f6c210 0f84f9010000 0f1f8000000000 668b01 }
		$sequence_1 = { 64a12c000000 8b3488 80be6411000000 750b 8d8e00100000 e8???????? }
		$sequence_2 = { c1f906 56 57 6bf838 8b048d98d64700 894df0 }
		$sequence_3 = { 03c0 03c0 03c0 660f2898e09e4600 660f2835???????? 660f59cf 660f58d1 }
		$sequence_4 = { 7438 8d5e0c 53 e8???????? 83c404 }
		$sequence_5 = { 6a00 6a00 50 ffb424a8000000 6a00 ff15???????? 85c0 }
		$sequence_6 = { 8d044501000000 56 03c3 50 ff7508 e8???????? 8b5dec }
		$sequence_7 = { 8d4dd0 0f57c0 c645d000 660fd645d8 8b12 e8???????? c645fc14 }
		$sequence_8 = { 8b5708 894708 894f0c 8955d8 8975dc c645fc13 }
		$sequence_9 = { 6a00 6a02 68162b0000 ba???????? }

	condition:
		7 of them and filesize < 1209344
}
rule MALPEDIA_Win_Qaccel_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "9c9c4471-e3b9-508a-8f2d-e53c0dc8299e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.qaccel"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.qaccel_auto.yar#L1-L123"
		license_url = "N/A"
		logic_hash = "8a6c1a9fdb2b0d9a211090d7b270427d7e64335587872c1259ad6fd94c917b0f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b55f8 8b4508 c1e204 03d0 8b4508 85c0 7433 }
		$sequence_1 = { 668b8d2cfbffff 663b0d???????? 7538 8b952efbffff 8b35???????? 52 }
		$sequence_2 = { 8b4620 50 ff15???????? 85c0 0f8488000000 53 57 }
		$sequence_3 = { 55 8bec 0f880a000000 0f8904000000 5f 5f }
		$sequence_4 = { e8???????? 0f8818000000 0f8912000000 5f 5f }
		$sequence_5 = { f3ab 66ab aa 0f8813000000 0f890d000000 }
		$sequence_6 = { 5d c20400 8b4d08 8b5620 51 52 ff15???????? }
		$sequence_7 = { 83c9ff 33c0 8d95fcfeffff f2ae f7d1 }
		$sequence_8 = { 8986e8000000 0f880a000000 0f8904000000 5f 5f 5f 5f }
		$sequence_9 = { 8b9b0c010000 85db 744b 8b55f8 }

	condition:
		7 of them and filesize < 106496
}
rule MALPEDIA_Win_Lotuslite_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "d50d9a27-7b8d-5353-8d23-3e2752dbd654"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.lotuslite"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.lotuslite_auto.yar#L1-L127"
		license_url = "N/A"
		logic_hash = "fd7e3d38ebc3cb7c4f273e9c52efe3d2e00e868642e145af0f5361bc769e92e4"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? e9???????? 2bce 8d55e0 81f900000100 }
		$sequence_1 = { 833d????????00 0f85c1510000 c3 55 8bec 33c0 50 }
		$sequence_2 = { 8d45f4 64a300000000 8bf9 807f7400 }
		$sequence_3 = { 0f8723fcffff 8bc8 51 e8???????? 83c404 }
		$sequence_4 = { 57 8d1c85102f0510 8b03 8b15???????? 83cfff 8bca 8bf2 }
		$sequence_5 = { c78558ffffff00000000 c645fc03 8b45ec 83f810 723e 8b4dd8 40 }
		$sequence_6 = { ba0b000000 b9???????? 0f431d???????? e8???????? 8bf0 ba12000000 8d85e8feffff }
		$sequence_7 = { c78564feffff0f000000 c78560feffff00000000 c68550feffff00 83f810 7241 8b8d38feffff 40 }
		$sequence_8 = { 53 ffd0 85c0 7425 ba???????? b9???????? e8???????? }
		$sequence_9 = { 83e13f c1f806 6bc930 8b0485982f0510 f644082801 7406 8b440818 }

	condition:
		7 of them and filesize < 744448
}
rule MALPEDIA_Win_Bid_Ransomware_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "5750cb2b-9362-57bc-8109-bb596de06ceb"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.bid_ransomware"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.bid_ransomware_auto.yar#L1-L122"
		license_url = "N/A"
		logic_hash = "32e2122749c89fa66ed966c48978fa59af1fd12a841710ff6c3f10fd922797ff"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 6a00 e8???????? ff75a8 e8???????? }
		$sequence_1 = { 6800400000 6a40 e8???????? 0bc0 750c 68c8000000 }
		$sequence_2 = { e8???????? c745942c000000 8d4594 50 ff75a8 6a00 6a08 }
		$sequence_3 = { 757b ff05???????? c705????????20202020 68???????? ff35???????? e8???????? }
		$sequence_4 = { ff75b0 e8???????? 6a04 ff75a8 6a04 6a00 }
		$sequence_5 = { 68dc050000 ff75a8 68???????? e8???????? 6a00 }
		$sequence_6 = { ff75a8 6a03 6a00 ff7590 ff75b0 e8???????? ff75b0 }
		$sequence_7 = { d1e0 83e806 c6043000 8d85d8fdffff }
		$sequence_8 = { c1e005 0345e8 83780c01 740c 6a00 8d00 }
		$sequence_9 = { ff75f0 6a40 e8???????? 0bc0 750c 68c8000000 e8???????? }

	condition:
		7 of them and filesize < 57344
}
rule MALPEDIA_Win_Htprat_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "ef0e0d39-365e-5553-8783-734aec3524ee"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.htprat"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.htprat_auto.yar#L1-L130"
		license_url = "N/A"
		logic_hash = "e91e2f5d4f2e91c51db42baca1246934c16ca7f823ff9b4ae5f1f136399ba2d4"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 837de810 8b5dd4 898578ffffff 7303 8d5dd4 33d2 8bc7 }
		$sequence_1 = { 8b5d08 8b13 66833a22 7561 8365e400 33c0 c745e807000000 }
		$sequence_2 = { 3b08 751a 8d410c 8bcb e8???????? 84c0 0f84d2000000 }
		$sequence_3 = { 33c9 66890c78 b001 ebc5 55 8bec }
		$sequence_4 = { c9 c3 55 8bec 8b4d08 e8???????? ff7508 }
		$sequence_5 = { ff15???????? 85c0 750c ff15???????? 89831c010000 39bbd0000000 766c }
		$sequence_6 = { eb85 8365fc00 b8???????? c3 33db e9???????? 55 }
		$sequence_7 = { 8365fc00 8bce 8bd7 e8???????? 8b75cc 50 }
		$sequence_8 = { 83f966 7f3d 7434 83f922 7428 }
		$sequence_9 = { 8d7dcc e8???????? 8b5dcc 6a01 33ff 8d75d0 e8???????? }

	condition:
		7 of them and filesize < 278528
}
rule MALPEDIA_Win_Medusa_Http_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "d20a8f8a-0c40-56df-b905-5b8d6ebe61b2"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.medusa_http"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.medusa_http_auto.yar#L1-L120"
		license_url = "N/A"
		logic_hash = "bf22f346b79f830cfb557e80bea02849fba4fc00ac522de893ed484b5992cd17"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e1fb 1cc9 3ca5 2c8e a1???????? d528 }
		$sequence_1 = { ff7100 52 ff7200 53 ff7300 54 }
		$sequence_2 = { 6a00 4b ff6b00 4c ff6c004d ff6d00 4e }
		$sequence_3 = { 0050ff 7000 51 ff7100 }
		$sequence_4 = { 53 ff7300 54 ff740055 ff7500 56 }
		$sequence_5 = { 8b4c6386 8608 5f e1fb 1cc9 3ca5 2c8e }
		$sequence_6 = { 0c48 b5f9 43 324dd5 1ddf859f31 }
		$sequence_7 = { 0000 aa 05854cffab 004893 }
		$sequence_8 = { 05854cffab 004893 3eb35b 813bf80937dc 8b4c6386 }
		$sequence_9 = { 1cc9 3ca5 2c8e a1???????? d528 32f4 }

	condition:
		7 of them and filesize < 1720320
}
rule MALPEDIA_Win_Boxcaon_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a730ae2b-b623-5088-86a7-4d1a4eb89ea5"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.boxcaon"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.boxcaon_auto.yar#L1-L120"
		license_url = "N/A"
		logic_hash = "5b71da83cc61472fd3b6239fea0178674ab4b3cf9a9678dbeeda07cdd88e683a"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 897e14 897e70 c686c800000043 c6864b01000043 c7466890b54000 6a0d e8???????? }
		$sequence_1 = { 8bd3 66899424e0000000 5a 6a50 66899424e2000000 8bd1 66899424e4000000 }
		$sequence_2 = { 8888b8b84000 40 ebe6 ff35???????? }
		$sequence_3 = { 8bec 33c0 8b4d08 3b0cc5408a4000 740a }
		$sequence_4 = { c78424980000003c000000 ff15???????? 56 33ff }
		$sequence_5 = { e8???????? 84c0 741a 8d4c2410 8d8424d8020000 2bc1 }
		$sequence_6 = { 89bc24ac000000 89b424b4000000 c78424980000003c000000 ff15???????? }
		$sequence_7 = { 33c9 66890c06 68???????? 8d442414 50 e8???????? }
		$sequence_8 = { 0020 1f 40 00441f40 0023 d18a0688078a 46 }
		$sequence_9 = { 33c0 c7461407000000 668906 8b4508 8b5810 57 }

	condition:
		7 of them and filesize < 256000
}
rule MALPEDIA_Win_Retefe_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "8943c596-164a-59a3-922e-166e4ea54d32"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.retefe"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.retefe_auto.yar#L1-L271"
		license_url = "N/A"
		logic_hash = "29c3620b419efdd0ebc0c3f8535252420e659f4c61c038e09456063a02ea7751"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 68f5000000 50 ff15???????? b801000000 }
		$sequence_1 = { 51 8bf8 ffd6 85c0 }
		$sequence_2 = { 52 e8???????? 8b4e04 8901 8b4e04 33c0 }
		$sequence_3 = { e8???????? 6a08 e8???????? 894604 83c404 8bc6 }
		$sequence_4 = { 6adb 6a1c 6ad8 6a2f }
		$sequence_5 = { 6a4f 6a82 6a74 6a87 6a50 }
		$sequence_6 = { 6a21 6ac0 6a2c 6ab1 }
		$sequence_7 = { 880c10 8b4e04 40 3b4104 }
		$sequence_8 = { 6a14 6aea 6abe 6a2b }
		$sequence_9 = { 6af2 6a82 6a8f 6a0b e8???????? 83c430 }
		$sequence_10 = { 6ae5 6a45 6a5b 6acf }
		$sequence_11 = { 8b4e04 33c0 83c404 394104 }
		$sequence_12 = { 8d85f4feffff 8bce e8???????? 8b4614 }
		$sequence_13 = { 50 e8???????? 88043e 46 83c404 3bf3 75ec }
		$sequence_14 = { 668908 8d85c4efffff bf???????? 50 }
		$sequence_15 = { 8364240400 56 57 8b7c2418 57 }
		$sequence_16 = { 6bf030 03348da0bf4200 837e18ff 740c 837e18fe 7406 }
		$sequence_17 = { e8???????? 83a6a0bf420000 59 83c604 81fe00020000 72dd b001 }
		$sequence_18 = { 83c001 89442414 0f8429010000 55 }
		$sequence_19 = { 83e03f c1ff06 6bd830 8b04bda0bf4200 }
		$sequence_20 = { 894c243c 8d48fd 83e10f 8d7007 }
		$sequence_21 = { c70021000000 e9???????? 894ddc c745e008344100 e9???????? c745e004344100 }
		$sequence_22 = { 40 83f81d 7cf1 eb07 8b0cc5fc3c4100 }
		$sequence_23 = { 8d442410 50 ffd3 8b450c 2dd0070000 }
		$sequence_24 = { f2c3 f2e953070000 53 56 57 6a00 68a00f0000 }
		$sequence_25 = { 56 e8???????? 85c0 0f8425ffffff 56 }
		$sequence_26 = { 8bfe e9???????? 33db 33c0 }
		$sequence_27 = { 0f87ed010000 ff24855c664000 ff36 68???????? 6a00 }
		$sequence_28 = { 756e 85d2 756a 8b3d???????? 8db7ff1f0000 }
		$sequence_29 = { c745fcffffffff 8935???????? 8b06 51 8bfc }

	condition:
		7 of them and filesize < 843776
}
rule MALPEDIA_Win_Snowflake_Stealer_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f63bfd00-592b-5322-ad50-ae01b507a9f0"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.snowflake_stealer"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.snowflake_stealer_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "f5e692ed799ff64111db6940224ea102c0128f450a3b00989cabd81c6b467310"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff7004 e8???????? 58 59 eb19 8d5c2424 89f2 }
		$sequence_1 = { ff7510 50 e8???????? 8b450c 83c40c 8906 8b442414 }
		$sequence_2 = { ebe6 0fb6c0 8971fc 8941f8 5e 5f 5b }
		$sequence_3 = { ff742404 e8???????? 59 e9???????? 83ec20 53 55 }
		$sequence_4 = { f20f100d???????? 89c7 89d3 f20f115008 f20f1100 f20f11480e 6a0c }
		$sequence_5 = { ff742450 e8???????? 6af7 57 8b7c245c 8bf0 57 }
		$sequence_6 = { ebf3 31c0 39c7 740d 803c0100 784f 40 }
		$sequence_7 = { ff500c 83c40c 8d742408 89e2 893e 884608 83660400 }
		$sequence_8 = { ffb42498000000 e8???????? 58 8d442418 8b6c2414 837c241001 f20f1000 }
		$sequence_9 = { ff2485aa2a5500 8a4601 8bca 89542428 84c0 741b 3c3a }

	condition:
		7 of them and filesize < 6196224
}
rule MALPEDIA_Win_Rikamanu_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "9dcff730-310e-5186-98f3-bee34b9e5963"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.rikamanu"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.rikamanu_auto.yar#L1-L297"
		license_url = "N/A"
		logic_hash = "1b49f039baef92853d49a4f7de0c3ea999a13f48ed3b16d09bb633700fd76f0b"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 6a14 ff15???????? a801 }
		$sequence_1 = { 50 ff15???????? 8b35???????? 3d80969800 }
		$sequence_2 = { 51 c7442410e0704000 e8???????? 8b54240c }
		$sequence_3 = { 33c0 c3 8bc8 83e01f c1f905 8b0c8de0b84000 8a44c104 }
		$sequence_4 = { 83c40c 33c0 6808020000 8d95f4fdffff }
		$sequence_5 = { 0f841f020000 83c9ff bf???????? 33c0 68???????? f2ae f7d1 }
		$sequence_6 = { 8dbc2430010000 83c9ff f2ae f7d1 2bf9 8bf7 8bfa }
		$sequence_7 = { 3b04cd00992400 7413 41 83f92d }
		$sequence_8 = { f3a5 8bca 83e103 f3a4 6a14 }
		$sequence_9 = { c6864b01000043 c74668e0932400 6a0d e8???????? 59 }
		$sequence_10 = { 52 8b15???????? 50 51 81e2ffff0000 52 68???????? }
		$sequence_11 = { 6880000000 83e103 6a04 f3a4 }
		$sequence_12 = { 8b048560af4000 8d04c8 8b0b 8908 8a4d00 884804 }
		$sequence_13 = { 898518e5ffff 8b8528e5ffff 8b0485383f4100 89853ce5ffff 397c0138 741c }
		$sequence_14 = { 68???????? 52 891d???????? c705????????01000000 ffd6 8b4dfc 5e }
		$sequence_15 = { e8???????? 8db604a64000 bf???????? a5 a5 59 }
		$sequence_16 = { 8d85ecfbffff 68???????? 50 e8???????? 83c410 8d85ecfbffff }
		$sequence_17 = { ff15???????? a1???????? 8b0d???????? 83c40c 3bc1 7417 668b7616 }
		$sequence_18 = { 56 8b74240c 668b4616 663d1000 7512 }
		$sequence_19 = { 8365fc00 8b049d383f4100 f644380401 740b 56 e8???????? 59 }
		$sequence_20 = { ff35???????? ffd7 56 e8???????? 59 5e }
		$sequence_21 = { 7219 83f85a 7714 8088????????10 8ac8 80c120 8888a0a64000 }
		$sequence_22 = { 6a00 6a00 55 ffd7 bf???????? 83c9ff }
		$sequence_23 = { 53 50 e8???????? 68ff000000 8d85e9f9ffff }
		$sequence_24 = { 8b95f0fdffff 53 50 6830040000 53 53 }
		$sequence_25 = { e8???????? 59 8bcf 83e71f c1f905 c1e706 8b0c8d383f4100 }
		$sequence_26 = { 2bf9 8bf7 8bd1 83c9ff bf???????? }
		$sequence_27 = { 33c0 39b810982400 0f8491000000 ff45e4 83c030 3df0000000 }
		$sequence_28 = { 84c0 7429 0fb63e 0fb6c0 eb12 8b45e0 8a800c982400 }
		$sequence_29 = { 8d95f8feffff 6a5c 52 889c05f4feffff e8???????? 83c408 }

	condition:
		7 of them and filesize < 212992
}
rule MALPEDIA_Win_Curlback_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "3f061324-6649-5218-92a6-eeb9d3b6b244"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.curlback"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.curlback_auto.yar#L1-L133"
		license_url = "N/A"
		logic_hash = "140f79c277ad1e5cda0108f22afc3ae12cef31b20912cecbfec110437d4d06b6"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 83f801 750d 488d542468 488bce e8???????? 4c8b742468 4d85f6 }
		$sequence_1 = { 90 488d4c2430 e8???????? 488b4d38 488b01 ff5010 }
		$sequence_2 = { ba2d270000 488b09 e8???????? 488b4f18 baac000000 41b801000000 488b09 }
		$sequence_3 = { 7410 4883f802 7411 bb2b000000 e9???????? 488d3d2e9b0900 493bd1 }
		$sequence_4 = { e8???????? b823000000 eb14 488d152db00b00 488bce e8???????? b84d000000 }
		$sequence_5 = { 791b ff15???????? 488d1579470d00 448bc8 4c8bc7 488bce e8???????? }
		$sequence_6 = { 4863f8 4c8d35f5170f00 488bcb 48c1ff06 e8???????? 83e03f 488d14c0 }
		$sequence_7 = { 742f 80bb1f13000000 7526 488d542420 0f1f840000000000 0fb60a 488d5201 }
		$sequence_8 = { e8???????? 90 488d4de8 e8???????? 90 bb00100000 488b55c0 }
		$sequence_9 = { 7505 49893e eb03 48893e ff8d00020000 488b4b28 ff15???????? }

	condition:
		7 of them and filesize < 4027392
}
rule MALPEDIA_Win_Chthonic_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "bf4613a2-8c62-5d59-a160-2e28cbd0a475"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.chthonic"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.chthonic_auto.yar#L1-L119"
		license_url = "N/A"
		logic_hash = "ce64b67a67ad57663a24fc0c67ab32c8ac8e25bd7f810ed6b509e25af0105e69"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8d4df0 51 ff7028 ff5618 84c0 }
		$sequence_1 = { 83fe02 0f850d010000 8b4df0 eb00 894df8 }
		$sequence_2 = { 0f84d4010000 4f 8bf0 8bcf d3ee }
		$sequence_3 = { c1c108 81e1ff00ff00 0bc1 89470c 5f 5e 5b }
		$sequence_4 = { 83c410 f60680 7408 8a06 32c3 }
		$sequence_5 = { 2500ff00ff c1c108 81e1ff00ff00 0bc1 89470c 5f 5e }
		$sequence_6 = { 83c304 83c602 ff45fc 8b45fc 3b45f8 72e1 33c0 }
		$sequence_7 = { 8b36 83c410 f60680 7408 8a06 }
		$sequence_8 = { 47 8a01 8845ff 8d84bdfcfbffff 8b10 }
		$sequence_9 = { 85ff 0f84bd000000 4f 8bf0 }

	condition:
		7 of them and filesize < 425984
}
rule MALPEDIA_Win_Lazardoor_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "2192f689-2d36-518d-a4b5-53629fb5b282"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.lazardoor"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.lazardoor_auto.yar#L1-L125"
		license_url = "N/A"
		logic_hash = "8d9ef4e58a08bba9943a01949f481cece73e15fda3adb3789be28974655728af"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 57 4154 4883ec60 488b05???????? 4833c4 4889442430 }
		$sequence_1 = { 488b8b20010000 e8???????? 488db328010000 bd06000000 488d7b38 488d05b6370100 483947f0 }
		$sequence_2 = { 85c0 7474 4533f6 0f1f00 }
		$sequence_3 = { e9???????? 488d05e51d0200 c3 4883ec28 e8???????? 48830824 e8???????? }
		$sequence_4 = { 41b800100000 488bd0 4c8bf8 ff15???????? 4885c0 0f8425010000 8b0b }
		$sequence_5 = { 750d 488d0db2aa0100 e8???????? 90 488b03 833800 7513 }
		$sequence_6 = { eb02 33db 4c8d356100ffff 4885db 750d 488bc7 }
		$sequence_7 = { 48894230 33c0 488b0e 448bf0 }
		$sequence_8 = { ff15???????? 488bf0 4883f8ff 0f8474010000 448d4b02 4533c0 }
		$sequence_9 = { 0f1f4000 660f1f840000000000 458b5304 498d5308 448bc8 458bc7 4c03cf }

	condition:
		7 of them and filesize < 405504
}
rule MALPEDIA_Win_Boldmove_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "363fdb7a-c8e0-58c7-bc58-cd71a1f83d60"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.boldmove"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.boldmove_auto.yar#L1-L132"
		license_url = "N/A"
		logic_hash = "d2e3181c4860f04b53e3d7210ae63816af4edb467b3466ada7082fd0eb33fdb1"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 83ec28 e8???????? 8d65f4 31c0 59 5b 5f }
		$sequence_1 = { c7442404ffff0000 891c24 ffd6 8d45d0 c745d001000000 83ec14 c744241004000000 }
		$sequence_2 = { 89f7 8d7594 899558ffffff f3ab 8b8560ffffff 8d7b08 b904000000 }
		$sequence_3 = { 7504 c6040120 40 ebef 5d c3 55 }
		$sequence_4 = { e8???????? 89c7 8b442460 897c2458 85c0 0f8547080000 }
		$sequence_5 = { 81e700080000 0f842cfdffff c60630 83c601 3b75c8 0f851dfdffff 8b55c0 }
		$sequence_6 = { 89cb c1c207 8955d8 8b55e4 31ca 8b4dd4 c1c210 }
		$sequence_7 = { c7042414000000 e8???????? b905000000 89c2 31c0 89d7 f3ab }
		$sequence_8 = { 8b742470 dd442420 0344242c dc0cf5e0694100 83f835 8b742464 0f9ec0 }
		$sequence_9 = { 85ff 7439 8b45e4 897c2410 8944240c 8b4304 }

	condition:
		7 of them and filesize < 242688
}
rule MALPEDIA_Win_Sparrow_Door_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "3f6fcbc6-5509-5bcf-86ca-224397277463"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.sparrow_door"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.sparrow_door_auto.yar#L1-L122"
		license_url = "N/A"
		logic_hash = "ac98330db74878935395e0f80b599c6c6548bfca24b236f68ed05302ff699eb7"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8dbc2498000000 83c250 f3a5 6a40 89542430 }
		$sequence_1 = { 7610 33c9 39b0e8002a00 0f95c1 894de4 eb03 8975e4 }
		$sequence_2 = { 53 6a01 52 ffd7 6a40 8d442438 53 }
		$sequence_3 = { 83c250 f3a5 6a40 89542430 33f6 8d542458 56 }
		$sequence_4 = { 6a00 6a00 8d8424d8050000 50 }
		$sequence_5 = { c644241400 e8???????? 6882050000 8d4c2458 6a00 51 e8???????? }
		$sequence_6 = { 8d8c2400010000 51 56 52 ffd5 }
		$sequence_7 = { ffd7 53 8d442418 50 8d4c2418 51 68???????? }
		$sequence_8 = { 89842438060000 55 56 57 33c0 }
		$sequence_9 = { 8b8c2404100000 5f 5e 5d }

	condition:
		7 of them and filesize < 155648
}
rule MALPEDIA_Win_Ghostemperor_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "9b258f9a-1be7-5046-9f9b-7c3cc2a0e970"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.ghostemperor"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.ghostemperor_auto.yar#L1-L220"
		license_url = "N/A"
		logic_hash = "a905f9ed8b1f61bc929a5095f2299666771607d4a4bfbef4b69ebc16f7ea5453"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 4885c0 7450 4989c4 448b4650 44034648 49c1e003 }
		$sequence_1 = { 740d e8???????? 48c7464000000000 48895e40 8b4648 }
		$sequence_2 = { 8b4e50 29c2 8d1c09 39da 7c5f }
		$sequence_3 = { 488b5640 448b4648 49c1e003 4c89e1 e8???????? }
		$sequence_4 = { 4889c1 4889ea 4989d8 e8???????? eb07 }
		$sequence_5 = { 4883c2e0 4883c604 39f1 75ce }
		$sequence_6 = { 0f104cfa10 0f1014f9 0f57d0 0f1044f910 }
		$sequence_7 = { 49c1e003 488d5108 e8???????? 8b4648 85c0 746e 8b564c }
		$sequence_8 = { 48897c2448 448bc5 89442440 498bd6 }
		$sequence_9 = { 00c2 488b8568020000 8854080c 488b85b0020000 }
		$sequence_10 = { 052797fa04 351337a665 8945f4 488b4510 }
		$sequence_11 = { 0fb78316010000 c1e208 0bd1 0fb6c8 }
		$sequence_12 = { 05f226dac9 35bcfe1eea 894534 488b4550 }
		$sequence_13 = { 00c1 488b8568020000 488b95b0020000 884c100c }
		$sequence_14 = { 7567 8b542450 33c9 ff15???????? 488bf8 }
		$sequence_15 = { 01c1 89ca c1ea1f c1f904 }
		$sequence_16 = { 4983f90f 72bf 66895df5 c745f701000000 488bcb 0fb7440dd7 6689440d17 }
		$sequence_17 = { 01c3 69cbe8030000 81c130750000 4883ec20 }
		$sequence_18 = { 8bf0 85c0 792e 4c8d442470 }
		$sequence_19 = { ffc0 4881c200010000 413bc0 72ed eb1b }
		$sequence_20 = { c7858c000000bf00d200 0f108580000000 c78590000000f0000000 8b8590000000 }
		$sequence_21 = { 4885c0 7405 493bc0 7538 0f31 48c1e220 488d0db130ffff }
		$sequence_22 = { 01d1 89ca c1e205 89cb }
		$sequence_23 = { 0552f0384d 358e257f87 894530 488b4570 }

	condition:
		7 of them and filesize < 1115136
}
rule MALPEDIA_Win_Photoloader_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "48338d97-c563-58fc-bead-39750aafca2e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.photoloader"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.photoloader_auto.yar#L1-L177"
		license_url = "N/A"
		logic_hash = "65b8deb5a0816e3e9bcfe9c77b2fe6d65dd8ba990c07ed57caf4f081f7c82a1f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff15???????? 25ffffff00 0d00000005 e9???????? 8bd7 397b1c }
		$sequence_1 = { 0fa2 894704 33c9 b800000040 }
		$sequence_2 = { f7411400000020 7407 8b41f8 3901 }
		$sequence_3 = { 33c9 b800000040 0fa2 895f0c }
		$sequence_4 = { c0c003 0fb6c8 8bc1 83e10f }
		$sequence_5 = { 8bf7 8d6f10 ff15???????? 0f31 }
		$sequence_6 = { b90b010000 66394a18 8d41ed 448d59fd 440f44d8 4533c9 }
		$sequence_7 = { 4883ec28 ff15???????? 488bc8 48b877be9f1a2fdd2406 48f7e1 482bca }
		$sequence_8 = { 85c0 7512 ff15???????? 25ffffff00 0d00000003 }
		$sequence_9 = { e8???????? 488d97c6020000 4c8bc5 4803d6 488bcb 488b5c2430 }
		$sequence_10 = { 7511 ff15???????? 25ffffff00 0fbae819 }
		$sequence_11 = { 8bf9 33f6 33c9 0fa2 894500 }
		$sequence_12 = { 03f8 8d0c7b e8???????? 03f8 }
		$sequence_13 = { 7461 8d4c2410 51 8d4c2424 51 53 }
		$sequence_14 = { 89742414 eb1b 8d4101 89742414 89442410 8d4601 }
		$sequence_15 = { 55 33ed c744241804000000 56 }
		$sequence_16 = { 759a 50 51 53 55 }
		$sequence_17 = { 7504 8907 8bf0 8d6c2410 33c9 b801000080 }

	condition:
		7 of them and filesize < 107520
}
rule MALPEDIA_Win_Miniasp_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f4dc99fc-a375-5593-a87c-371415384f2c"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.miniasp"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.miniasp_auto.yar#L1-L124"
		license_url = "N/A"
		logic_hash = "ded97ae7c3edbeb6db8d036ab6cf1e1ca4d0a8ef66829d2a2a5fce5701ebe5f9"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b4de4 e8???????? 83f801 7d12 }
		$sequence_1 = { 740e 837db401 7417 837db402 }
		$sequence_2 = { 7430 ffb5f0fbffff 6a00 ff15???????? 50 ff15???????? c785d8fbffff40d64000 }
		$sequence_3 = { ff703c 6a00 6a00 ff15???????? 8d85d8fbffff 50 8b85d4fbffff }
		$sequence_4 = { c745d015000000 6a00 6800000008 6a01 ff7514 ff7510 ff75d0 }
		$sequence_5 = { 8b85d4fbffff 8b4004 ff7044 68???????? 8d85f0feffff 50 e8???????? }
		$sequence_6 = { 8845ef 8b4508 0345f0 0fbe4002 83f839 7f26 }
		$sequence_7 = { 83c261 8b45fc 0345f8 8810 ebd9 8b45fc 034508 }
		$sequence_8 = { e8???????? 83c40c eb0f 68???????? ff75fc e8???????? 59 }
		$sequence_9 = { 6a00 8b45f4 8b8880000000 e8???????? }

	condition:
		7 of them and filesize < 139264
}
rule MALPEDIA_Win_Ketrican_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "db7bbc89-26c3-5964-9bfe-88bd4b2a2b3e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.ketrican"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.ketrican_auto.yar#L1-L237"
		license_url = "N/A"
		logic_hash = "691cbe8c978e14d1bc08c4a6610d2f7675c8d88a9cfe750537172ecaa7e41fa9"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8965f0 33db 895dfc 33c0 }
		$sequence_1 = { 7417 6a0a 6a1f 68???????? }
		$sequence_2 = { e8???????? 8b06 5d c20400 55 8bec 8b4508 }
		$sequence_3 = { c3 55 8bec 8b4508 85c0 742c 83f80c }
		$sequence_4 = { c20800 680e000780 e8???????? cc 8b06 83e810 8b08 }
		$sequence_5 = { 8901 5b 5d c20800 680e000780 e8???????? }
		$sequence_6 = { e8???????? 83c010 8906 c3 56 8bf1 }
		$sequence_7 = { 5f 5e c3 55 8bec 837d0800 7d0a }
		$sequence_8 = { c1e802 83e03f c1e308 e8???????? 8345fc03 0fbec0 }
		$sequence_9 = { eb0d 8b85d8fbffff 40 8985d8fbffff }
		$sequence_10 = { 8bf0 e8???????? 0fafc6 99 b910270000 }
		$sequence_11 = { 884603 83c604 8345f804 8b45f8 5f c60600 5e }
		$sequence_12 = { 57 ff7508 53 53 ffd6 5f 5e }
		$sequence_13 = { 0bc1 e8???????? 0fbed8 8bc7 c1e810 83e03f }
		$sequence_14 = { 0fbec0 c1e008 0bd8 8bc7 }
		$sequence_15 = { 8b542408 8d420c 8b8a54ffffff 33c8 e8???????? 8b8adc090000 }
		$sequence_16 = { e8???????? 8b8ae8060000 33c8 e8???????? b8???????? }
		$sequence_17 = { e9???????? c705????????ac824100 c3 b9???????? }
		$sequence_18 = { e8???????? b8???????? e9???????? 8b4508 e9???????? 8b45ec 83e001 }
		$sequence_19 = { ff15???????? 68???????? c705????????98824100 a3???????? c605????????00 e8???????? 59 }
		$sequence_20 = { 8b8a78ffffff 33c8 e8???????? 8b8a8c2f0000 33c8 e8???????? }
		$sequence_21 = { 8b8a24ffffff 33c8 e8???????? 8b8ae8080000 33c8 e8???????? b8???????? }
		$sequence_22 = { 8d45d0 e9???????? 8d4dd0 e9???????? 8d4de0 }

	condition:
		7 of them and filesize < 1449984
}
rule MALPEDIA_Win_Atlas_Agent_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "bd4db519-0df6-53d1-9fb7-b1d34480a7d9"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.atlas_agent"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.atlas_agent_auto.yar#L1-L141"
		license_url = "N/A"
		logic_hash = "36ac6402ee5cdb05929965c114c4ef40d88046c36ee043041b9f395cfdec3109"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 0fb60c0a 83e13c c1f902 03c1 }
		$sequence_1 = { 8bc1 99 b903000000 f7f9 c1e002 }
		$sequence_2 = { 740d c74424640f000000 e9???????? 488d8424a0000000 }
		$sequence_3 = { 740d c74424640c000000 e9???????? 8b442474 488b8c24a0000000 482bc8 }
		$sequence_4 = { 8b00 8945bc 8d4d88 e8???????? }
		$sequence_5 = { 740e 488d050f390400 4889442420 eb0e }
		$sequence_6 = { 8a95a4f8ffff 8895c3f8ffff c645fc01 8d8db8f9ffff e8???????? c645fc00 8d8da0f9ffff }
		$sequence_7 = { 8b00 8945ec 8d4dd0 51 }
		$sequence_8 = { 8b00 8945f0 8d4dff 51 }
		$sequence_9 = { 740d c74424640c000000 e9???????? b808000000 486bc000 488d8404a0010000 }
		$sequence_10 = { 8a95e8fdffff 8895fffdffff c645fc02 8d8db8feffff }
		$sequence_11 = { 740e 483bdf 0f84ac000000 e9???????? 4d8bb4f6808d0400 }
		$sequence_12 = { 8b00 8945bc 8b4d28 e8???????? }
		$sequence_13 = { 740d c74424640d000000 e9???????? 488d842400010000 }

	condition:
		7 of them and filesize < 857088
}
rule MALPEDIA_Win_Soraya_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "14bbde5d-15cc-5025-8b24-26e133addab2"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.soraya"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.soraya_auto.yar#L1-L226"
		license_url = "N/A"
		logic_hash = "b2e9247a6dd1093d6971a6ef5da72b47d313966f90239a9370fea94dbcd381d2"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff15???????? 8d48bf 80f919 77f2 }
		$sequence_1 = { 0301 8b4c2410 3901 0f87a1fdffff }
		$sequence_2 = { e8???????? 8b45fc 33c6 2bc3 50 }
		$sequence_3 = { ff15???????? 037df8 3975f8 75db 8b4514 33c9 }
		$sequence_4 = { ff4d3c 7580 8b451c 8b4d24 014dfc c745d03223f000 }
		$sequence_5 = { 8bec 51 51 837d1800 747b }
		$sequence_6 = { ff75ec e8???????? 8b4df0 8b45f4 8d440801 8945fc 8d45d8 }
		$sequence_7 = { 8b4508 8a08 884d0b 8a4d0b 8b55f8 0fb6c9 }
		$sequence_8 = { 8d85ecfdffff 50 ffd6 a1???????? 0540010000 50 8d85ecfdffff }
		$sequence_9 = { 8b4d0c 8b5520 33ce 8b8c118e40f2ff 8b10 8b18 }
		$sequence_10 = { 59 68???????? 53 ffd7 5b 85c0 }
		$sequence_11 = { ff15???????? 488b0d???????? 488364242000 488d5150 4c8d45d0 448bc8 }
		$sequence_12 = { 8b5254 48 f7d0 23d0 8b45f4 }
		$sequence_13 = { 488bcb ff15???????? 488d1563f0ffff 488bcf }
		$sequence_14 = { 744f ba0c000000 4c8d8c24b0020000 488bce 448d4234 }
		$sequence_15 = { 33c0 66390f 0f8515010000 8b4f3c 03cf 813950450000 }
		$sequence_16 = { 4533c0 488bd5 498bcf ff15???????? 498bce }
		$sequence_17 = { 488bd0 488bd8 ff15???????? 488d15d9f0ffff 488bcf ff15???????? }
		$sequence_18 = { 0fb6c0 2bcb 3bc1 0f8462010000 }
		$sequence_19 = { 8b4804 83e908 f7c1feffffff 763b 8b4dfc }
		$sequence_20 = { 8d740650 8b02 0306 8b742418 }
		$sequence_21 = { 4d2bc6 0fb701 6641398408a0010000 7530 ffc2 48ffc1 }
		$sequence_22 = { 4533c0 418d5064 ff15???????? 4883c430 5b }

	condition:
		7 of them and filesize < 188416
}
rule MALPEDIA_Win_Makop_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "355bae35-0501-5b9b-b621-4d2cb8587b27"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.makop"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.makop_auto.yar#L1-L125"
		license_url = "N/A"
		logic_hash = "38ff3547a5d28c0690a45faac7b2f71dd4de01fc2110e124e3dabc4d0018847f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 56 e8???????? a1???????? 8b3d???????? 83c40c }
		$sequence_1 = { e9???????? 8b0d???????? 8b09 85c9 8bd1 743b 8b4204 }
		$sequence_2 = { 8d4c2414 51 8d54241c 52 ffd6 85c0 0f841c010000 }
		$sequence_3 = { 53 66891f 895f10 895f14 894718 c7471c04000000 ff15???????? }
		$sequence_4 = { 8b542418 8b44241c 33c9 899648080000 8b542420 }
		$sequence_5 = { 33c0 8d4c2414 51 a3???????? a1???????? 6a02 e8???????? }
		$sequence_6 = { 51 6a10 52 53 ffd6 85c0 }
		$sequence_7 = { 740f 85db 740b 837c242000 7404 85c0 }
		$sequence_8 = { 66c74424423200 6689542444 66894c2448 66c744244a7300 }
		$sequence_9 = { 6a08 8d4cf808 51 8d542418 52 e8???????? 0fb744241c }

	condition:
		7 of them and filesize < 107520
}
rule MALPEDIA_Win_Graphican_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "5327553d-9f34-5db7-9251-850b9bed2022"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.graphican"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.graphican_auto.yar#L1-L123"
		license_url = "N/A"
		logic_hash = "9566c2b4f0576ec3e930c58775078ba557dfbb904324fe09d2d5ba20942a47e1"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c1e105 034e08 3bd9 7411 8b4508 e8???????? 84c0 }
		$sequence_1 = { 83c104 4a 75d7 33db 895dfc 85ff }
		$sequence_2 = { e8???????? 83c40c 53 e8???????? 83c404 83c710 }
		$sequence_3 = { 8d04c2 894c8608 8b86d0030000 2b45ec 8d0cc2 }
		$sequence_4 = { 8d55c8 52 68???????? 57 ffd0 85c0 7837 }
		$sequence_5 = { 3c45 0f8570010000 47 807def00 }
		$sequence_6 = { 50 68???????? 6a00 e8???????? 8bc8 83c418 }
		$sequence_7 = { 6876060000 68???????? 68???????? e8???????? 83c40c 833e00 }
		$sequence_8 = { e8???????? 395f18 0f85cd000000 8bff 8b0e 8b5604 43 }
		$sequence_9 = { 8bcb 8bd6 e8???????? 83c404 8bf0 }

	condition:
		7 of them and filesize < 362496
}
rule MALPEDIA_Win_Rockloader_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "c6c44d33-5846-51ca-8f54-23ba343d4527"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.rockloader"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.rockloader_auto.yar#L1-L122"
		license_url = "N/A"
		logic_hash = "1272cbe4a9f674f11a8769fcce9bc03deb2e733c4d2f3c7b3104b6fff19bd35a"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { d9ee 53 56 dd55ec d9e8 }
		$sequence_1 = { 7442 49 743a 49 49 7431 }
		$sequence_2 = { eb07 50 ff15???????? 8bf0 85f6 7507 33c0 }
		$sequence_3 = { 66c7005d00 8b36 0375fc e9???????? }
		$sequence_4 = { 47 8a07 3c22 0f85a9feffff 5b c60600 803f22 }
		$sequence_5 = { 0f8eb0000000 8b5dfc 8b4508 2bc3 8945f4 837d1000 }
		$sequence_6 = { dc5df8 dfe0 f6c441 7a34 6a15 }
		$sequence_7 = { 03c8 8d5c0b02 eb07 c745fc01000000 8b3f }
		$sequence_8 = { 8b5508 5f 5e 895114 c7410c03000000 5b }
		$sequence_9 = { e8???????? 8bd8 83c704 81fb00dc0000 720c 81fbffdf0000 0f86dc000000 }

	condition:
		7 of them and filesize < 98304
}
rule MALPEDIA_Win_Matrix_Banker_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "e1fe110d-2557-58e9-8b0d-c02481abc12f"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.matrix_banker"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.matrix_banker_auto.yar#L1-L117"
		license_url = "N/A"
		logic_hash = "ac91e864e52e154b2f07f424c81211df5c5c895be70c931b7918481f98a2997e"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { eb0b 8d4abf 80f905 7703 80c2c9 }
		$sequence_1 = { 8d489f 80f905 7704 04a9 eb0a }
		$sequence_2 = { eb0a 8d48bf 80f905 7702 04c9 8d4ad0 80f909 }
		$sequence_3 = { eb16 8d489f 80f905 7704 }
		$sequence_4 = { ff15???????? e8???????? 85c0 740a e8???????? 83f8ff }
		$sequence_5 = { 721e 8125????????fffdffff 8125????????fffdffff 8125????????fffdffff }
		$sequence_6 = { 7702 04c9 8d4ad0 80f909 }
		$sequence_7 = { 8d489f 80f905 7704 04a9 eb0a 8d48bf 80f905 }
		$sequence_8 = { 7704 04a9 eb0a 8d48bf 80f905 7702 04c9 }
		$sequence_9 = { 8d48bf 80f905 7702 04c9 }

	condition:
		7 of them and filesize < 422912
}
rule MALPEDIA_Win_Nestegg_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "91ee1088-5bf8-5931-aa22-3ae01311c81d"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.nestegg"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.nestegg_auto.yar#L1-L127"
		license_url = "N/A"
		logic_hash = "bdea5aa8ae38268c26fcd2615283d181d25bf9017925dd1922fb06ba934650b2"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { aa 8d442414 8bce 50 c744241000000000 e8???????? 8d4c240c }
		$sequence_1 = { 8bcf e8???????? 85c0 740c 8b4f08 }
		$sequence_2 = { 8d44241c 6a08 50 8bce e8???????? 8d4c2424 6a08 }
		$sequence_3 = { 50 57 c784245803000000000000 896c2414 }
		$sequence_4 = { a0???????? b943000000 88842494010000 33c0 8dbc2495010000 8b542474 }
		$sequence_5 = { c20c00 8b4c240c 51 ff15???????? 5f 5e 33c0 }
		$sequence_6 = { ffd6 a3???????? 8b842494000000 3bc3 740d 68???????? 50 }
		$sequence_7 = { 0bf0 8d442420 6800040000 50 e8???????? 8bd6 81f6429a0101 }
		$sequence_8 = { 0f8485020000 8b0d???????? 389910030000 0f8573020000 e9???????? 83f803 7518 }
		$sequence_9 = { 8bb42414010000 8d442404 57 8d4c2410 50 51 }

	condition:
		7 of them and filesize < 221184
}
rule MALPEDIA_Win_Zeoticus_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "12bd207a-d071-5533-a687-45a6e493cb04"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.zeoticus"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.zeoticus_auto.yar#L1-L132"
		license_url = "N/A"
		logic_hash = "e1755e61caa0c781b2418da428673bedb16ee65aa45c2473cd1910259a63dbb6"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 660f62ca 660f62f8 660f6e84243c010000 660f62f9 660f6e8c2414010000 660fd4fe 660fd4fc }
		$sequence_1 = { 8b8424b4000000 0384248c000000 898424b4000000 8b8424b8000000 03842490000000 898424b8000000 8b8424bc000000 }
		$sequence_2 = { e9???????? 80be7111100000 743f 51 8d86c8101000 50 8d96b0101000 }
		$sequence_3 = { b9495c66d3 e8???????? 83c408 a3???????? 8d0c24 6a00 6a00 }
		$sequence_4 = { 660fefc8 0f28c5 660ffec3 0f28f0 660f72d013 660f72f60d 660fefb530ffffff }
		$sequence_5 = { 0f28c1 660fd4442470 0f28ce 660fd4cc 0f29442460 660fefc5 0f294c2420 }
		$sequence_6 = { 8bf9 687122cb4d 6a15 ba???????? b91dc1b04b e8???????? 83c408 }
		$sequence_7 = { 85d2 7407 ffd2 a1???????? 8b4010 8d8d58ffffff 6a20 }
		$sequence_8 = { 5b 85c0 7514 c705????????80f44200 e8???????? a1???????? }
		$sequence_9 = { 5e 8b442428 8b4c240c 8b401c 8d0488 8b0438 }

	condition:
		7 of them and filesize < 468992
}
rule MALPEDIA_Win_Adkoob_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "021a09b0-3054-5dbf-8800-eabf56fe257b"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.adkoob"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.adkoob_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "5b0bdb502a1cf5b0075c8e6de23eaff5623f0fd99cf23b8e8a4b6079780365c3"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff75d0 6a68 5a e8???????? 83c414 8bd6 8b75d4 }
		$sequence_1 = { 8b45f8 53 ff75fc 50 6a7e 5a 8bcf }
		$sequence_2 = { e8???????? 5f 5e 8be5 5d c20400 6a2c }
		$sequence_3 = { 50 56 ff7308 894514 6a60 5a e8???????? }
		$sequence_4 = { 8bd6 8bc8 e8???????? 8bd7 8bc8 e8???????? 8bd6 }
		$sequence_5 = { ff5268 8b442408 c1ee10 56 50 8b08 ff5170 }
		$sequence_6 = { 0f84dd000000 803a98 0f85d4000000 8b522c 85d2 0f84c9000000 f6422c10 }
		$sequence_7 = { 8b462c 8945ec 6a00 6a00 50 6a58 5a }
		$sequence_8 = { 8b4df8 baeca60000 e8???????? 57 e8???????? 59 8bc6 }
		$sequence_9 = { 8945d4 33c0 895dd0 6a08 59 8d7dd8 f3ab }

	condition:
		7 of them and filesize < 1867776
}
rule MALPEDIA_Win_Badaudio_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "8d9bdd19-f708-560d-b786-fe14af0e9e80"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.badaudio"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.badaudio_auto.yar#L1-L127"
		license_url = "N/A"
		logic_hash = "1b6a09532e7c8a3c4465ce56fffae8aa5f483eb895595eb4c92fecb690f8160c"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 51 50 e8???????? 83c40c 31db 85c0 0f94c3 }
		$sequence_1 = { 80f136 884c2440 345c 880424 }
		$sequence_2 = { e8???????? 8b7d08 c6470c00 807de000 0f8447ffffff 8b45dc }
		$sequence_3 = { 8d7110 83c0f0 8b1a 8b5204 8945cc 8975c8 894db8 }
		$sequence_4 = { 89c1 c1c11e 89c6 c1c613 31ce c1c00a 31f0 }
		$sequence_5 = { 7226 83f83f 7714 90 8d4801 894e28 c644062c00 }
		$sequence_6 = { 51 50 e8???????? 83c40c 8b4614 2b4610 034604 }
		$sequence_7 = { 3a540803 7540 83c104 83f920 75ce }
		$sequence_8 = { 328fe7000000 884e07 8a442402 3287e8000000 884608 8a442405 3287e9000000 }
		$sequence_9 = { e8???????? 83c404 50 89e2 8b0e c70600000000 }

	condition:
		7 of them and filesize < 1420288
}
rule MALPEDIA_Win_Olympic_Destroyer_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "e2dcc72e-ca7d-5e18-b603-aec0089d8583"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.olympic_destroyer"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.olympic_destroyer_auto.yar#L1-L226"
		license_url = "N/A"
		logic_hash = "5402288d9f4e79588931b4923763458bd5a4554bb6126ded33e9b8357ae3fe47"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 56 33c0 89542414 57 }
		$sequence_1 = { 89442418 85c0 7419 56 8d542414 }
		$sequence_2 = { 3b0cc5686a4000 740a 40 83f816 72ee }
		$sequence_3 = { 51 8bcf 89442454 e8???????? }
		$sequence_4 = { ff15???????? 83c420 6810040000 8d85dcf7ffff 50 }
		$sequence_5 = { 76cb 83c614 6a04 57 }
		$sequence_6 = { 51 8bce 8944244c 89bc2480000000 e8???????? }
		$sequence_7 = { 8d7e10 85ff 7476 8bcf e8???????? 85c0 746b }
		$sequence_8 = { 51 8bce 8b4004 894510 e8???????? 8b4d10 }
		$sequence_9 = { ff15???????? 57 ff15???????? 81bd7cf9ffff40420f00 760e ffb590f9ffff }
		$sequence_10 = { 51 8bce 8d52ff e8???????? 83c408 85c0 0f851f040000 }
		$sequence_11 = { 51 8bce e8???????? 6a00 68???????? }
		$sequence_12 = { 898c24b0000000 898424b4000000 c7460400000000 85c9 7435 0fb74602 }
		$sequence_13 = { 51 8bcf 8b141a e8???????? }
		$sequence_14 = { 50 6a03 683f010000 ff75e0 }
		$sequence_15 = { c3 8b742420 51 ff15???????? 8bc6 5f 5e }
		$sequence_16 = { 8975e8 ff15???????? 8d45dc 50 68???????? }
		$sequence_17 = { 85db 0f84f6000000 8b4308 8b5304 89442414 8d44242c 51 }
		$sequence_18 = { 8d442424 89442414 c7442418d0f25500 8b0f }
		$sequence_19 = { 50 68???????? 56 ff15???????? 8b45dc 8945f0 }
		$sequence_20 = { 770e 8b8de8efffff 398df0efffff 7690 53 ff15???????? }
		$sequence_21 = { 51 8bcf 89442424 e8???????? 8b542424 }
		$sequence_22 = { 89442414 e8???????? 33c9 83c404 85c0 0f45f9 }

	condition:
		7 of them and filesize < 1392640
}
rule MALPEDIA_Win_Wscspl_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "7d78cbcb-c636-58e3-9d8d-70bd821838ca"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.wscspl"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.wscspl_auto.yar#L1-L115"
		license_url = "N/A"
		logic_hash = "a06a73900ca2c0d42b899a919a39813227fe95be2c044a4b97a03a121cdc8aa6"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 0f8464020000 8b3d???????? f644243810 8a442464 0f8481000000 3c2e }
		$sequence_1 = { 885c342c ffd5 a3???????? a3???????? b8???????? }
		$sequence_2 = { 33d2 33c9 8d5c2418 e8???????? 8b8c2494230000 83c414 5b }
		$sequence_3 = { c705????????01000000 e8???????? 891d???????? eb25 }
		$sequence_4 = { 51 50 ff15???????? 2935???????? 83c40c }
		$sequence_5 = { 5f 8935???????? 5e 5d 8b8c2488230000 }
		$sequence_6 = { 6a01 50 ff15???????? 687c230000 68c10b0000 }
		$sequence_7 = { 8d443410 68???????? 50 e8???????? 668b0d???????? }
		$sequence_8 = { 68ba0b0000 33d2 33c9 8d9c24a4050000 }
		$sequence_9 = { 2bc1 8b4c2448 03f0 8b442444 ba3f3a0000 }

	condition:
		7 of them and filesize < 901120
}
rule MALPEDIA_Win_Scavenger_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "4d0fe2fd-e25f-5559-a329-346e0540b714"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.scavenger"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.scavenger_auto.yar#L1-L119"
		license_url = "N/A"
		logic_hash = "81f782c28ed8b56f170fb419a770b25697c5a4b0d6a6a131402f1ff1a837a90c"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 4833c4 4889842400010000 488b842430010000 4889442428 488b442428 488b4010 4889442430 }
		$sequence_1 = { 48898424e8000000 488b8424e8000000 48ffc0 48898424e8000000 48c744245000000000 }
		$sequence_2 = { 48ffc0 48898424f0000000 48c744244000000000 488b9424f0000000 488b8c2488000000 e8???????? }
		$sequence_3 = { 4883c020 4889442428 488b442440 4839442428 }
		$sequence_4 = { 730c 488b442428 4889442430 eb61 33d2 }
		$sequence_5 = { 488b442448 4889442450 488b442450 4c8bc0 }
		$sequence_6 = { 4839442420 743a 488b442420 4889442438 }
		$sequence_7 = { 488b442438 488b542478 488bc8 e8???????? 4889442440 488b442440 4889442428 }
		$sequence_8 = { eb08 c744240400000000 0fb6442404 880424 0fb60424 0fb6c0 85c0 }
		$sequence_9 = { 0fb6c0 85c0 7421 488b442430 488b00 4889442410 }

	condition:
		7 of them and filesize < 2992128
}
rule MALPEDIA_Win_Mole_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f4675281-1c27-589e-9c74-7ddeefc0bdef"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.mole"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.mole_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "44af167042295f11247abf2257f521989211d24592efa54abaa895c2392af2c3"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c745ec00000000 c745fc00000000 c745f400000000 8d45fc 50 6a08 ff15???????? }
		$sequence_1 = { 8d8dc8f9ffff 51 8d95ecfbffff 52 ff15???????? 8b4514 50 }
		$sequence_2 = { 81bdf0fdffffcde5d405 0f8458400000 81bdf0fdffff41e6d405 0f849e440000 81bdf0fdffff44e6d405 0f84742c0000 e9???????? }
		$sequence_3 = { 6a00 ff15???????? 8d85b0f9ffff 50 68???????? 8d8dc0fdffff 51 }
		$sequence_4 = { 55 8bec b8d81d0000 e8???????? a1???????? 33c5 8945fc }
		$sequence_5 = { 81bdf0fdffffd164d205 0f84cd630000 e9???????? 81bdf0fdffff4b67d205 0f84226b0000 e9???????? 81bdf0fdffff4668d205 }
		$sequence_6 = { 81bdf0fdffffd220d505 0f84f34a0000 81bdf0fdffffb318d505 7735 81bdf0fdffffb318d505 }
		$sequence_7 = { 7810 3de4000000 7309 8b04c548834100 5d c3 33c0 }
		$sequence_8 = { e8???????? 68ff000000 e8???????? 59 59 8b7d08 833cfd48cc410000 }
		$sequence_9 = { 6a00 6a00 8d95b0f9ffff 52 6a00 ff15???????? }

	condition:
		7 of them and filesize < 297984
}
rule MALPEDIA_Win_Colony_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "5199daf2-df66-5161-b62a-b4c3b801c48b"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.colony"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.colony_auto.yar#L1-L227"
		license_url = "N/A"
		logic_hash = "03be236720c4641cc692857768269fa6c05b66d69f41584003e2316425d86e1c"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b421c 2b4218 660f6ec0 f30fe6c0 }
		$sequence_1 = { 8b420c 2b4208 660f6ec0 f30fe6c0 }
		$sequence_2 = { 69d200008f04 2bc8 c1e910 69c161a4f778 }
		$sequence_3 = { 0f84d4000000 8b450c 89460c 8b4510 894610 8b4508 894608 }
		$sequence_4 = { 0fbed9 83eb57 eb03 83cbff }
		$sequence_5 = { 03c0 8985bcfbffff 8d85bcfbffff 6a00 50 8d45dc 50 }
		$sequence_6 = { 1bf6 f7de 4e ff15???????? 8bc6 5e }
		$sequence_7 = { 8b4224 2b4220 660f6ec0 f30fe6c0 }
		$sequence_8 = { 7407 b901000000 eb0a 33c9 803f01 0f95c1 33c0 }
		$sequence_9 = { 334f14 8b4510 894dfc 8bca c1e910 }
		$sequence_10 = { 2bc1 894328 eb07 c7432800000000 8b4a14 }
		$sequence_11 = { 740f 0301 eb0b a801 }
		$sequence_12 = { 33c0 837d0802 0f95c0 83c004 }
		$sequence_13 = { 8d4201 894704 0fb74108 a808 }
		$sequence_14 = { 8b4214 2b4210 660f6ec0 f30fe6c0 }
		$sequence_15 = { 0fbed9 83eb30 eb13 8ac1 }
		$sequence_16 = { 4885db 741b f0ff0b 7516 488d0558fc0000 488b4c2430 483bc8 }
		$sequence_17 = { 488b4c2438 488d155ca90000 ff15???????? 4885c0 7404 }
		$sequence_18 = { 488bcb 488905???????? ff15???????? 488d157f980000 483305???????? }
		$sequence_19 = { 483305???????? 488905???????? ff15???????? 488d1501990000 483305???????? 488bcb }
		$sequence_20 = { ba0d000000 4c8d0da0d20000 412bc6 413bc7 }
		$sequence_21 = { 7349 33c0 e9???????? 8a07 4c8b7c2448 4c8d2506d40000 }
		$sequence_22 = { e8???????? 90 488bd7 488d0d51c50000 }
		$sequence_23 = { 33c9 4c8d7108 4d8b3e eb20 4c8d35e90b0100 488b0d???????? bf01000000 }

	condition:
		7 of them and filesize < 7599104
}
rule MALPEDIA_Win_Emdivi_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f3bfd962-ffa0-58b8-9bdd-3cf5bc9abcc6"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.emdivi"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.emdivi_auto.yar#L1-L122"
		license_url = "N/A"
		logic_hash = "baba13dfdec0ab594d4b878f67466bb12eae487064f07853484a2575458e76b7"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 3bd1 7cf5 6a1e 58 5f c9 c3 }
		$sequence_1 = { 33d2 f7f7 8bf8 0fb606 c1e802 }
		$sequence_2 = { ff45fc e8???????? 3945fc 0f8e75ffffff e9???????? 8b45fc }
		$sequence_3 = { 295d08 41 8801 0fb64601 }
		$sequence_4 = { 8b4508 ff45f8 85c0 7405 }
		$sequence_5 = { 8955ec 83c006 69c0b979379e 8945fc 8b55f0 c1e802 83e003 }
		$sequence_6 = { 8945f4 8b45e0 83c40c 40 8945f8 8b45dc 8945fc }
		$sequence_7 = { eb04 2bc8 03ca 880c32 42 3bd0 72e5 }
		$sequence_8 = { c1ef03 33fb 8b5d08 03c7 8bfa 83e703 }
		$sequence_9 = { 2bca 03c8 eb04 2bc8 03ca }

	condition:
		7 of them and filesize < 581632
}
rule MALPEDIA_Win_Starsypound_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "70e37162-3a73-596a-8d7d-42b9d85b78f7"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.starsypound"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.starsypound_auto.yar#L1-L119"
		license_url = "N/A"
		logic_hash = "abf4ae91c4287e1227ba24bd55f61dc3c1250c1b8b21f760166157e29806933f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff15???????? 8dbc2458010000 83c9ff 33c0 }
		$sequence_1 = { 68???????? 52 e8???????? 83c420 85c0 7444 8b5304 }
		$sequence_2 = { 53 56 57 6a18 e8???????? 8bb42424040000 }
		$sequence_3 = { 8d4c2428 68???????? 51 e8???????? 56 8d542434 }
		$sequence_4 = { 8bfd 8d44240c f3a5 8b5500 8b3d???????? 6a00 }
		$sequence_5 = { 885c3438 c744241804010000 ff15???????? 8dbc2458010000 83c9ff 33c0 }
		$sequence_6 = { 50 8d4c2424 56 51 52 }
		$sequence_7 = { f3a4 885c0444 bf???????? 83c9ff 33c0 33f6 }
		$sequence_8 = { 83c40c 85c0 7e2b eb08 }
		$sequence_9 = { e8???????? 68c0270900 ff15???????? e8???????? 5f }

	condition:
		7 of them and filesize < 40960
}
rule MALPEDIA_Win_Spybot_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f487b739-5a23-52d3-8b27-57437fc4fe82"
		date = "2026-01-05"
		modified = "2026-01-06"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.spybot"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.spybot_auto.yar#L1-L132"
		license_url = "N/A"
		logic_hash = "086db381edc017239cf316ebb3a9419f50149c95f9ac3a29e8ecb7d10b4a280d"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260105"
		malpedia_hash = "19b79e7cab4eaf532122e5b45a77dd8f6bb5cc79"
		malpedia_version = "20251219"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8975f8 8975f0 68???????? ff750c ff7508 e8???????? 83c418 }
		$sequence_1 = { 6a03 8b5c2414 99 59 33ff f7f9 8bf2 }
		$sequence_2 = { 59 e9???????? 57 68???????? e8???????? 59 85c0 }
		$sequence_3 = { 33f6 ff7508 56 ff15???????? 85c0 7429 }
		$sequence_4 = { 33f6 ffb56cffffff 57 e8???????? 59 85c0 59 }
		$sequence_5 = { 8945f0 8945f4 8945f8 8945fc a1???????? 85c0 7411 }
		$sequence_6 = { 8bb43570ffffff 3bf3 897508 0f8469a4ffff 399d54ffffff 0f855da4ffff 68???????? }
		$sequence_7 = { ff7020 8d85fcfdffff 68???????? 50 e8???????? 6a01 }
		$sequence_8 = { ff7514 8975fc e8???????? 56 8945ec ff7510 897514 }
		$sequence_9 = { e9???????? ffb570ffffff 68???????? e8???????? 59 85c0 59 }

	condition:
		7 of them and filesize < 2367488
}
rule MALPEDIA_Win_Colibri_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "4087b9fc-1e99-559d-bc59-bc0ead8d5030"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.colibri"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.colibri_auto.yar#L1-L122"
		license_url = "N/A"
		logic_hash = "69042c794b7b04a73fccadff8eb54a2f609e7a127591e0c5759db62a0429a075"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8d0c4502000000 e8???????? 89442440 be???????? 8bfc 8bc8 }
		$sequence_1 = { ff75f4 6a02 59 e8???????? ba49f6fd69 8bc8 }
		$sequence_2 = { 8b4df0 e8???????? 8bf8 8bcf e8???????? }
		$sequence_3 = { 8902 83c204 8955f8 8b01 85c0 }
		$sequence_4 = { 8b4df8 8d144502000000 e8???????? a1???????? 8b4df4 }
		$sequence_5 = { 8b75f8 85c0 745c 57 8d85ecfdffff }
		$sequence_6 = { 8bd8 56 895c2444 53 6a02 59 }
		$sequence_7 = { e8???????? 83c410 b8???????? 68???????? 50 53 8b5dfc }
		$sequence_8 = { 8365f800 50 e8???????? 59 85c0 7413 8b4dfc }
		$sequence_9 = { ba5986c991 8bc8 e8???????? ffd0 89442444 eb43 }

	condition:
		7 of them and filesize < 51200
}
rule MALPEDIA_Win_Grey_Energy_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "0c6fb3ff-e30c-5ea5-9151-89579fca9cdc"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.grey_energy"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.grey_energy_auto.yar#L1-L161"
		license_url = "N/A"
		logic_hash = "286e1b200d2301a687d8371ef64eb05eaa70a2be3f5d273f29e2f82631353157"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8945d4 e8???????? 68???????? 8945d0 }
		$sequence_1 = { e8???????? 68???????? 8945cc e8???????? 68???????? 8945d4 }
		$sequence_2 = { 53 53 6800000008 57 }
		$sequence_3 = { 6800000008 57 53 53 }
		$sequence_4 = { 81e1ff000000 8b45ec 8b55f8 66890c42 }
		$sequence_5 = { 8945f8 837df800 7507 33c0 e9???????? c745f004000000 }
		$sequence_6 = { 8b55f8 66890c42 eb14 8b45ec 8b4df8 8b55f0 8b7508 }
		$sequence_7 = { 8b45f8 0345ec 8808 eb10 }
		$sequence_8 = { 8b4d08 0fb70c41 8b45f0 33d2 }
		$sequence_9 = { 53 ff15???????? 8b75f8 85f6 }
		$sequence_10 = { 50 6a40 ff15???????? 8945f8 837df800 7507 }
		$sequence_11 = { 8b4508 0345f0 0fbe08 8b45f0 33d2 }
		$sequence_12 = { 8b55f0 8b7508 668b1456 66891441 }
		$sequence_13 = { c60100 41 48 75f9 ff75f8 }
		$sequence_14 = { 8b9d78ffffff 85db 7417 53 ffd6 03c0 }
		$sequence_15 = { ffd7 eb06 8b3d???????? 8b5d88 85db 7413 }

	condition:
		7 of them and filesize < 303104
}
rule MALPEDIA_Win_Stabuniq_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a634ea5c-ec9c-5083-a532-5c81be45dad5"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.stabuniq"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.stabuniq_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "088358b560fc62390905f45864d9b9bfa97da285fa34e5d77b30f12909697494"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 6a00 8b4d10 ff91d4000000 8b5510 52 8b85e4feffff 50 }
		$sequence_1 = { 51 8b5508 52 8b450c ff90a0010000 837df401 7707 }
		$sequence_2 = { 8b4d08 8b91e4010000 52 8b4508 ff90e0000000 8b4d08 8b91ec010000 }
		$sequence_3 = { e9???????? b801000000 8be5 5d c20400 55 8bec }
		$sequence_4 = { 8b82f0010000 50 8b4d14 ff91b8000000 8be5 5d c21400 }
		$sequence_5 = { 8b450c 50 8b4d20 ff514c 50 8b550c 52 }
		$sequence_6 = { c745f800000000 8a4d0c 51 8b55fc 52 8b4514 ff907c010000 }
		$sequence_7 = { 51 8b5508 ff9268010000 8b45a8 50 8b4d08 ff9150010000 }
		$sequence_8 = { 8b55f8 ff92d0000000 8b4dec 8901 8b55ec 83c204 8955ec }
		$sequence_9 = { 8d95bcf7ffff 52 8d85f0fbffff 50 8b4d10 ff5130 8b5510 }

	condition:
		7 of them and filesize < 57344
}
rule MALPEDIA_Win_Manjusaka_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "fd672986-dcc9-5077-ab95-179c50bf9535"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.manjusaka"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.manjusaka_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "f465b6f796f2faacced7c6a3779dc53dac39931e0c3e5efed82661459367d9cb"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { f348a5 488b5068 488b4070 4889442458 488dbc24b0000000 b90d000000 4c89c6 }
		$sequence_1 = { b8b4000000 8902 418bc1 e9???????? c70235000000 498bc0 8079013d }
		$sequence_2 = { 8b942434010000 894e19 89561c b902000000 4c8dac2488030000 49894d00 410f117508 }
		$sequence_3 = { e8???????? 8b06 83f804 0f85a1000000 41807f6800 742a 4d8b4f50 }
		$sequence_4 = { ba3a000000 41ffd7 84c0 0f85f5000000 4c896dd0 488d05c6050000 488945d8 }
		$sequence_5 = { e8???????? c646f80e 0f10442460 0f104c2470 0f298424b0000000 0f298c24c0000000 410f114f10 }
		$sequence_6 = { 4d85ff 751f 4c8bef 83cbff 488b4dd8 44394908 0f8587000000 }
		$sequence_7 = { e8???????? 0f1005???????? 0f1100 8b0d???????? 89480f 49c7042410000000 4989442408 }
		$sequence_8 = { eb2b 4c8d05dc2f1900 ba20010000 4889c1 eb1a 4c8d05e32f1900 ba11000000 }
		$sequence_9 = { e8???????? 488bce 488be8 e8???????? 4c8be8 4885db 0f845b010000 }

	condition:
		7 of them and filesize < 4772864
}
rule MALPEDIA_Win_Longwatch_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "31b3bdf1-5efd-52df-8568-c43407f28589"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.longwatch"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.longwatch_auto.yar#L1-L116"
		license_url = "N/A"
		logic_hash = "25b32489c287dd9f7f717d9c716cb65b1db98b534f383de71de0ff48be5f1aa7"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c705????????dc334200 e8???????? 68???????? e8???????? 59 }
		$sequence_1 = { 59 eb15 85db 7507 c74634d46e4200 }
		$sequence_2 = { 8b0485a00b4300 33db 8b7508 57 }
		$sequence_3 = { 57 8bb0a0714200 8bce ff15???????? ffd6 }
		$sequence_4 = { 8b0485a00b4300 88540828 8b0b 8bc1 83e13f }
		$sequence_5 = { e9???????? c745dc03000000 c745e010954200 e9???????? 83e80f 7451 }
		$sequence_6 = { 6a31 e9???????? 6a32 e9???????? 6a33 }
		$sequence_7 = { 8bff 55 8bec 8b4d08 33c0 663b8850934200 }
		$sequence_8 = { ff15???????? 663bc6 0f850f030000 ff15???????? 8bf8 }
		$sequence_9 = { 8b048da00b4300 f644382848 58 743a 668b55fc 663bd0 }

	condition:
		7 of them and filesize < 647168
}
rule MALPEDIA_Win_Aytoke_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "88d98d1f-b83a-5fc0-a5e0-714d64fa719a"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.aytoke"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.aytoke_auto.yar#L1-L122"
		license_url = "N/A"
		logic_hash = "9413864ca5c523e49626db7503a50bc87e28db758b1817fe328d7d470902d673"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 40 84c9 75f9 2bc2 03f0 33ff 0fbe0e }
		$sequence_1 = { 1e 1f 2021 2223 244d 4d 4d }
		$sequence_2 = { 8d85ecfcffff 8d5001 8a08 40 84c9 }
		$sequence_3 = { 68???????? e8???????? be01000000 83c404 }
		$sequence_4 = { e9???????? 33c0 8bff 0fb78884384100 }
		$sequence_5 = { 33f6 a1???????? 8b0d???????? 8b15???????? 8985a8f9ffff 8d85bcf9ffff }
		$sequence_6 = { 881438 46 47 ebd7 8b8dd8fbffff }
		$sequence_7 = { 8d55ec 52 b902000000 56 8945f0 66894dec ff15???????? }
		$sequence_8 = { 40 83f816 72ee 33c0 5d c3 8b04c54c494100 }
		$sequence_9 = { 83e61f 8d3c8d00c44100 8b0f c1e606 833c0eff 7535 }

	condition:
		7 of them and filesize < 425984
}
rule MALPEDIA_Win_Cargobay_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "64711143-52ad-5b40-8305-bc0c76111b40"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.cargobay"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.cargobay_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "5169310c4524392f5f42f838eff42cc6352804ce00d6ba1c197bb768cac36a1a"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 4883bc240001000000 0f8497000000 488db42408010000 488dbc2450020000 41b8d8000000 4889f9 }
		$sequence_1 = { f30f7f00 49ffc7 4883c6d0 e9???????? 488b4c2450 482b4c2428 488b442430 }
		$sequence_2 = { e8???????? 488d5c2420 4889d9 4c89fa 4989f8 e8???????? 0f1003 }
		$sequence_3 = { e8???????? 488b4618 4885c0 741e 486bd038 488b4e10 41b808000000 }
		$sequence_4 = { eb1c 80fb5b 7517 c6462800 ebaa 83f82c 750c }
		$sequence_5 = { e8???????? 3c14 759e 488b842488000000 483b842480000000 758c eb12 }
		$sequence_6 = { 488d4d70 e8???????? 488d8d88000000 e8???????? 488d4dc0 e8???????? 0f28742420 }
		$sequence_7 = { 56 57 53 4883ec50 4889ce 4c8b9c24a0000000 488b8210020000 }
		$sequence_8 = { 4889f1 4889fa e8???????? 488b06 4885c0 7479 488b4c2438 }
		$sequence_9 = { 488d1d703c0d00 e8???????? 0f57f6 410f11b424c8000000 410f11b424b8000000 410f11b424a8000000 410f11b42498000000 }

	condition:
		7 of them and filesize < 3432448
}
rule MALPEDIA_Win_Strikesuit_Gift_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "07a5f9ca-40c1-5bef-81cd-9b2edfb79941"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.strikesuit_gift"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.strikesuit_gift_auto.yar#L1-L118"
		license_url = "N/A"
		logic_hash = "38158a27b97c948ddd0e7a00ce8b9fd84a0eeadae064b8c5755cc04130a6bdf7"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 06 2000100000 1f40 2801000006 }
		$sequence_1 = { 7245000070 7e1b00000a 6f2500000a 1305 1105 7249000070 }
		$sequence_2 = { 2d3f 08 8e 69 05 59 }
		$sequence_3 = { 2801000006 0b 16 0c 2b0e 07 08 }
		$sequence_4 = { 7503000002 0d 09 7e1e00000a 6f0c000006 }
		$sequence_5 = { a2 1105 17 58 1305 1105 08 }
		$sequence_6 = { 07 d003000002 282000000a 282100000a }
		$sequence_7 = { 1107 7e01000004 1b 6f1800000a }
		$sequence_8 = { 731500000a 0b 16 0c }
		$sequence_9 = { 03 282c00000a 0a 16 0b 2b19 02 }

	condition:
		7 of them and filesize < 50176
}
rule MALPEDIA_Elf_Bashlite_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "ca662bd7-b46f-5db0-8222-879c9f4f162a"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/elf.bashlite"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/elf.bashlite_auto.yar#L1-L117"
		license_url = "N/A"
		logic_hash = "b9513210d709e6ff8c12fa38bb0a87c23e98fcda87d36e226fdbd0a2c7bb34d8"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { eb0a c785ecefffff00000000 8b85ecefffff c9 c3 }
		$sequence_1 = { 750c c785ecefffff01000000 eb0a c785ecefffff00000000 8b85ecefffff c9 c3 }
		$sequence_2 = { 31c0 eb19 e8???????? c70016000000 e8???????? c70016000000 83c8ff }
		$sequence_3 = { e8???????? 89c2 89d0 c1e81f 01d0 d1f8 }
		$sequence_4 = { c785ecefffff01000000 eb0a c785ecefffff00000000 8b85ecefffff }
		$sequence_5 = { 750c c785ecefffff01000000 eb0a c785ecefffff00000000 8b85ecefffff }
		$sequence_6 = { 89c2 89d0 c1e81f 01d0 }
		$sequence_7 = { 750c c785ecefffff01000000 eb0a c785ecefffff00000000 }
		$sequence_8 = { 83f8ff 750c e8???????? 8b00 83f873 }
		$sequence_9 = { eb19 e8???????? c70016000000 e8???????? c70016000000 83c8ff }

	condition:
		7 of them and filesize < 2310144
}
rule MALPEDIA_Win_Ceeloader_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "018449e6-4e13-5121-9b45-18470c26f526"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.ceeloader"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.ceeloader_auto.yar#L1-L133"
		license_url = "N/A"
		logic_hash = "5a4ba04d35296e8df4afef78af12c8e22af967c4db212d6a03bf1f2ca99ef386"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 898424380b0000 8b8424e40a0000 0b8424080a0000 8984243c0a0000 8b8424f0050000 0b842470080000 89842430070000 }
		$sequence_1 = { 0fbe05???????? 83f042 88c1 888c241d010000 0fbe05???????? 83f069 88c1 }
		$sequence_2 = { 33f5 0bda 8bde 0bd3 3bce 8bf5 }
		$sequence_3 = { c784249002000075380000 c784248c020000c5360000 c78424880200005a380000 c7842484020000ff6f0000 c7842480020000123e0000 c784247c02000043360000 c78424780200001f220000 }
		$sequence_4 = { 668b9c2406120000 6681f3ffff 66899c2404120000 6623bc2404120000 6689bc2402120000 668bbc2402120000 6689d3 }
		$sequence_5 = { 2500feffff 898424b80b0000 8b8424b80b0000 05ffffffff 898424b40b0000 8b8424b40b0000 83e000 }
		$sequence_6 = { 6b94242801000005 89942424010000 8b942424010000 83e280 89942420010000 8b942420010000 3b15???????? }
		$sequence_7 = { 48c784242802000000000000 4c8b842428020000 668b942430020000 668b8c2432020000 ff15???????? 89842424020000 8b8424600c0000 }
		$sequence_8 = { 488981f0000000 488b05???????? 488b80f0000000 4c8b442448 8b542444 488b4c2438 ffd0 }
		$sequence_9 = { 8b8424c00c0000 c1e808 898424bc0c0000 8b8424bc0c0000 c1e002 898424b80c0000 8b8424b80c0000 }

	condition:
		7 of them and filesize < 2321408
}
rule MALPEDIA_Win_Phoenix_Locker_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "4dfa7ef0-4875-564b-b865-e6f102f3af31"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.phoenix_locker"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.phoenix_locker_auto.yar#L1-L128"
		license_url = "N/A"
		logic_hash = "b1d5a233dad93ad87e8e6ab53dd93151b79c7e64341cdca8448cd67b7ab7a537"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 418d4238 fece 66450fb3f8 418d5278 66440fb6c0 c1e903 }
		$sequence_1 = { 0f8774000000 0f8530000000 488b542428 480fb7cd 488d4b14 e9???????? ff15???????? }
		$sequence_2 = { e9???????? c3 683065706f 9c 48c1a4240800000041 6827366401 }
		$sequence_3 = { 41d3c5 488b6c2468 4080d718 80fb82 488b742478 490fbbd5 8bc3 }
		$sequence_4 = { 7f52 b760 00504f d1c0 0c86 32fb }
		$sequence_5 = { 0855dd 43f6d1 11d7 43b7b1 743d bc15d6512a bc112e45ce }
		$sequence_6 = { e9???????? 41ffc6 49ffc4 413aed 4489b424a0000000 4080fc80 664585dd }
		$sequence_7 = { 3bc6 e9???????? 0f84e8fdffff 488b5c2430 48d3c7 488b742438 }
		$sequence_8 = { e8???????? 4881842418000000aa78f72a 488b7c2428 48c74424281256ce88 68d72a8642 48c1a42400000000ef 689b25ad02 }
		$sequence_9 = { 415b 415e 415f 415f 415e }

	condition:
		7 of them and filesize < 3702784
}
rule MALPEDIA_Win_Payloadbin_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "b297e9b6-48f7-5354-b5ea-42bf5667a3a7"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.payloadbin"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.payloadbin_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "cfc448e2b3d41ed418d3f2b553407a12491f48f47835bf9343d7e99469296789"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 6641f7c3503b 3bc7 e9???????? 0f8578000000 488b4c2430 660fca 4d0fb7cb }
		$sequence_1 = { 488bb42480000000 81ff41628163 e9???????? 483bf7 0f8408010000 488bee }
		$sequence_2 = { 68eb3a8171 55 68396f8656 6819276b5f 682109a155 4c8b6c2438 48c7442438404fa1db }
		$sequence_3 = { e9???????? bb03000000 4533e4 413bdc e9???????? 0f85a3060000 488b4c2430 }
		$sequence_4 = { 4c3be5 e9???????? 0f85acffffff 85f6 e9???????? 0f841e000000 }
		$sequence_5 = { 4d8b01 66c1e218 66418b10 f9 40fec7 493bc4 4981c106000000 }
		$sequence_6 = { 80bc24100000003d 4155 488184241000000033139340 4c8bac2418000000 688071f060 66c1b42400000000d9 0f8588950100 }
		$sequence_7 = { 8d56d4 fa 158935079e 9e 4657 250543b1d9 f661fd }
		$sequence_8 = { 440fb7c1 4080fca3 6683f819 e9???????? 0f8703000000 4503c5 0fb703 }
		$sequence_9 = { 4881842408000000dbb6ecff 5d c3 8084241000000078 e8???????? 68bc6baf1f }

	condition:
		7 of them and filesize < 3761152
}
rule MALPEDIA_Win_Warezov_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "2063feb9-0318-5d9e-9d7d-c40a08b7d06d"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.warezov"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.warezov_auto.yar#L1-L132"
		license_url = "N/A"
		logic_hash = "afa10838cc11d7f352c667dc9a1fe466d591577a16711e2962f92e47c5081c4d"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c644246108 c6442462ca c644246326 c644246406 c644246578 33c0 8a5c0c58 }
		$sequence_1 = { 8ac1 b238 f6ea 0fb6c0 33c8 894c2410 }
		$sequence_2 = { c68424e9020000ec c68424ea0200000d c68424eb02000003 c68424ec02000003 c68424ed0200007d c684248401000060 c68424850100000c }
		$sequence_3 = { c6454f45 c645507a c6455178 c6455255 c6455363 c645540c c64555a4 }
		$sequence_4 = { 8b4500 50 ff15???????? 5f 5e b143 2acb }
		$sequence_5 = { 889424e0000000 8a9424ea000000 888c24e1000000 8a8c24eb000000 80f26d 80f1fe 889424e2000000 }
		$sequence_6 = { 32ca 888c049c020000 40 83f809 7ce3 8d8424a8020000 50 }
		$sequence_7 = { 6a00 e8???????? 83c40c 8d542460 52 ffd6 83f8ff }
		$sequence_8 = { 88442417 51 8d4c2414 b810000000 c644243c30 c644243d8f c644243e59 }
		$sequence_9 = { c684247e0100007c c684247f01000085 c684248001000088 33c0 8bff 8a9404a0010000 }

	condition:
		7 of them and filesize < 827392
}
rule MALPEDIA_Win_Grillmark_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "ca264ac1-a99e-5b8d-8f11-6fdf9887e5ee"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.grillmark"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.grillmark_auto.yar#L1-L119"
		license_url = "N/A"
		logic_hash = "52ca6090aeca7158abcfd786b43959e2c73a805ccde7d94ddcf13b2732a8df6f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff15???????? 8d8568fcffff 50 6802020000 e8???????? 85c0 7408 }
		$sequence_1 = { 7413 80f922 7506 8065ff00 }
		$sequence_2 = { 53 53 57 68???????? ebaa }
		$sequence_3 = { 83c004 83c104 8d1406 3b5510 72d6 5e 5d }
		$sequence_4 = { 33c0 e9???????? 50 e8???????? 59 8945fc }
		$sequence_5 = { 8b35???????? 83c40c 85c0 7410 }
		$sequence_6 = { 50 8d85bcf8ffff 50 e8???????? 83c430 }
		$sequence_7 = { 895df4 f3ab 66ab aa 895df8 c745fc20000000 }
		$sequence_8 = { 56 8d8590deffff 53 50 }
		$sequence_9 = { 55 8bec 51 53 57 33ff 68???????? }

	condition:
		7 of them and filesize < 212992
}
rule MALPEDIA_Win_Mailto_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "de545c06-2fc0-5aa2-ab3b-4bb12369f5b0"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.mailto"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.mailto_auto.yar#L1-L128"
		license_url = "N/A"
		logic_hash = "3bf6fed8557918eaeb5425aebc2921bf16000813d1edc92db828b5792d00c6da"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 89742418 6689442416 e8???????? 6a01 8d4c2418 51 8b4058 }
		$sequence_1 = { 51 ff742434 8d4c2434 51 }
		$sequence_2 = { 885c2412 85ed 0f847d000000 8d4e32 0f1f440000 }
		$sequence_3 = { e8???????? 83c404 5d 53 e8???????? 83c404 5b }
		$sequence_4 = { 33c0 5b 83c410 c3 8b442410 8b4c241c 8b5078 }
		$sequence_5 = { 33c0 5e c3 8d46ff 5e c3 8d44240c }
		$sequence_6 = { 55 56 57 e8???????? 83c40c 85c0 741a }
		$sequence_7 = { 83c40c c7400c01000000 8d4704 5f 5e 5b c3 }
		$sequence_8 = { 75d1 8b6c2414 55 e8???????? 8b6c242c 83c404 }
		$sequence_9 = { 89842484000000 8944246c 8b442420 03c5 c1c707 33d0 897c2410 }

	condition:
		7 of them and filesize < 180224
}
rule MALPEDIA_Win_Curator_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "bac97418-ffb7-5dea-aba4-29d026257f9d"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.curator"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.curator_auto.yar#L1-L128"
		license_url = "N/A"
		logic_hash = "c17806abc26c970dba840398da71d2c4310ebd76bb366ba3db04b9360a7d4953"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 4433d0 69c907536554 c1c107 4489542444 8b442448 89874c010000 }
		$sequence_1 = { 0fbaea08 eb04 0fbaea09 8bc2 4883c428 c3 48895c2408 }
		$sequence_2 = { c3 3c20 755c 410fb609 418b5048 83e10f 4a0fbe8419d0590600 }
		$sequence_3 = { 488b9108010000 488bb910010000 483bc2 480f42d0 488bc1 48f7d8 83e00f }
		$sequence_4 = { e8???????? 4c8bc3 488bc8 e9???????? 488d05c6fb0300 }
		$sequence_5 = { 4883ec20 488bd9 488bc2 488d0d954f0100 0f57c0 }
		$sequence_6 = { 4885f6 75bf 488b4528 48894530 33c9 48894830 48894828 }
		$sequence_7 = { 4a8904c2 488b4608 ff00 41ffc6 4983c730 443b75e8 0f8cecfeffff }
		$sequence_8 = { 90 8bc8 e8???????? 90 e8???????? 90 b902000000 }
		$sequence_9 = { f30f7f4560 c7452002000000 f0ff05???????? 488d0521110300 48894560 488d0506110300 }

	condition:
		7 of them and filesize < 1265664
}
rule MALPEDIA_Win_Warlock_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "cb4f4908-4b57-5bfe-b70a-19112ad6cad5"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.warlock"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.warlock_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "ecb1d20086d0dfb8f8afd5c335e0ec3d82e101b9788cf2c669084c08416a6191"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b44241c 11542418 f7e0 03f0 8b442420 11542418 f7e1 }
		$sequence_1 = { 897ddc 8a08 80f940 750c 40 898680000000 e9???????? }
		$sequence_2 = { 57 50 e8???????? 83c40c 6b45e430 8945dc 8d8000ba4900 }
		$sequence_3 = { 13d7 8b4014 03da f76104 8bc8 8b442418 03ce }
		$sequence_4 = { 66c1e108 660bc8 8b4598 8808 8d043e 50 ff759c }
		$sequence_5 = { 8b8424f4000000 03842494000000 898424d4010000 8b84248c010000 03842498000000 898424d8010000 8b442434 }
		$sequence_6 = { e8???????? 80bd2fffffff00 7455 8bcb e8???????? 8b07 8d4d90 }
		$sequence_7 = { ff15???????? 8b4dfc ffd6 c60000 eb03 c60700 8a07 }
		$sequence_8 = { 8b442410 13fa f7642454 03e8 8b842484000000 13fa f7e0 }
		$sequence_9 = { c640043e eb02 33c0 50 8d4df0 e8???????? 8b7df0 }

	condition:
		7 of them and filesize < 1395712
}
rule MALPEDIA_Win_Pony_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f8b88673-29e7-5494-bb9e-c2e2b336cc84"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.pony"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.pony_auto.yar#L1-L120"
		license_url = "N/A"
		logic_hash = "cbc969955a7dabb8d9afebcf1f00c5ba391f47ee205cc15ba3ced2c3d8fe3633"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 55 8bec 837d0c00 7416 ff7510 ff750c ff7508 }
		$sequence_1 = { c745f400000000 8d45f8 50 ff7508 6a00 ff15???????? }
		$sequence_2 = { 6a01 ff7508 e8???????? ff750c ff7508 e8???????? 8b5510 }
		$sequence_3 = { 83c4fc 6a00 6a45 ff7508 }
		$sequence_4 = { 8f45d8 c745d000000000 8d45cc 50 }
		$sequence_5 = { 85c0 785e 0fb645ff 50 0fb645fe 50 0fb645fd }
		$sequence_6 = { ff750c ff75fc 50 ff7508 }
		$sequence_7 = { 8bec 83c4e4 53 833d????????00 7412 }
		$sequence_8 = { 0bfb 33f9 8d8407c3595b65 034630 c1c006 03c3 }
		$sequence_9 = { 0f853a020000 c745f800000000 c745f4ff070000 6a00 6a00 6a00 }

	condition:
		7 of them and filesize < 262144
}
rule MALPEDIA_Win_Danderspritz_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "071d3400-7427-5973-92c9-462797bffc42"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.danderspritz"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.danderspritz_auto.yar#L1-L132"
		license_url = "N/A"
		logic_hash = "9c78716856792446b7d2a13b09989a5f83880b621cf32db43f50f9ee18dfc411"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 3939 740f ffc0 4883c158 3dff000000 736c }
		$sequence_1 = { 0f84b7000000 4c8b4008 498bd0 4d3bc6 742c 493bf6 7527 }
		$sequence_2 = { 3bc5 0f8547020000 8b542448 0fb74c2434 e8???????? 8bf8 e9???????? }
		$sequence_3 = { 89442420 e8???????? 488d4c2438 4533e4 4c89642438 c744243004000000 }
		$sequence_4 = { 410fb60409 894328 3bfa 7224 85d2 7507 c74328ffffffff }
		$sequence_5 = { 83611800 488d4c2450 e8???????? 488bf8 4885c0 747f 488b742450 }
		$sequence_6 = { 4881c120010000 e8???????? 488bcb e8???????? 85c0 7512 8bbb34010000 }
		$sequence_7 = { 4883ec20 803d????????01 7545 eb13 488b18 488bd0 e8???????? }
		$sequence_8 = { 57 4883ec20 8bf9 488d0d69ce0200 33db e8???????? 488b0d???????? }
		$sequence_9 = { 898ba8000000 eb0a 488bcb e8???????? 8bc6 488b5c2440 488b6c2448 }

	condition:
		7 of them and filesize < 750592
}
rule MALPEDIA_Win_Nymaim_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a7f28cdd-8769-582a-a986-5bc8c1c9dbe4"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.nymaim"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.nymaim_auto.yar#L1-L278"
		license_url = "N/A"
		logic_hash = "d61e4c50186fd9784b72287b6756f8aca4aac6245f680092c334904655462a72"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 89d8 01c8 31d2 f7f7 }
		$sequence_1 = { 92 31d2 bf64000000 f7f7 }
		$sequence_2 = { 09c0 0f94c1 09c8 6bc064 09c0 }
		$sequence_3 = { 31d2 f7f7 92 31d2 }
		$sequence_4 = { c1eb13 331d???????? 31c3 c1e808 }
		$sequence_5 = { c1e105 01c8 c1c307 30c3 }
		$sequence_6 = { 31c9 38f0 83d100 38d0 83d900 c1e105 01c8 }
		$sequence_7 = { 00d3 8a16 301e 46 01fb }
		$sequence_8 = { c1e808 31c3 895e0c 89d8 }
		$sequence_9 = { 8b5514 8b12 8b4d0c 8b5d18 }
		$sequence_10 = { f7e0 0fc8 01d0 894704 }
		$sequence_11 = { 8b5604 0116 8b4e08 014e04 }
		$sequence_12 = { 8b5d18 8b1b 4f 31c0 fec2 }
		$sequence_13 = { 0f854fe70000 448835???????? 015308 395320 0f845a13fdff f6461c20 c705????????8a50d8e8 }
		$sequence_14 = { 55 89e5 83ec10 8b4508 8d0d3430d201 }
		$sequence_15 = { 890424 894c2404 e8???????? 8d0d3430d201 }
		$sequence_16 = { 4189c6 892d???????? 4189f9 4189d8 4489f1 8b8424c8000000 89ea }
		$sequence_17 = { 5b 5d c3 8b45f0 8b0c850440d201 }
		$sequence_18 = { 448b4d30 4189c3 4531d3 66813d????????65cb 0f8484920200 41f7d1 4531c8 }
		$sequence_19 = { 48833d????????00 7417 488d4df0 e8???????? 488b9500050000 448b95e0040000 31db }
		$sequence_20 = { 48813d????????00000050 0f84b243ffff 48c705????????00000000 31ff 4883bba800000000 742b ba20000000 }
		$sequence_21 = { 56 83ec28 8b450c 8b4d08 8d154e30d201 }
		$sequence_22 = { 31c9 8b55f4 8b75ec 89723c c7424003000000 }
		$sequence_23 = { 4421db 89c2 4409d2 4431ca 4c8d4d40 48ff05???????? 89d1 }
		$sequence_24 = { 31d2 890c24 c744240400000000 8945f4 8955f0 e8???????? 8d0d8630d201 }
		$sequence_25 = { 83ec44 8b4508 8d0d2030d201 31d2 890c24 c744240400000000 }
		$sequence_26 = { 53 56 57 83ec44 8b4508 8d0d2030d201 }
		$sequence_27 = { 0f876f59feff 488d4c2440 e8???????? e9???????? 4989e3 53 ff0d???????? }
		$sequence_28 = { 4189c0 895c2420 4189f9 48890d???????? 89f2 89e9 e8???????? }

	condition:
		1 of them and filesize < 2375680
}
rule MALPEDIA_Win_Anchor_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "191b195e-b43a-597d-b741-27078b9a6575"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.anchor"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.anchor_auto.yar#L1-L201"
		license_url = "N/A"
		logic_hash = "bc998e77a73ec4614efe874bf91e6dad502378931e8d0fbe1f33c31ba7ed92af"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c6400365 eb0a 66c74001646c c640036c }
		$sequence_1 = { 740c 66c740016578 c6400365 eb0a }
		$sequence_2 = { 51 e8???????? 8b0d???????? c1e102 51 }
		$sequence_3 = { ff750c 51 8bce e8???????? 83c414 }
		$sequence_4 = { 66895008 8b4608 6689580a 8b4608 }
		$sequence_5 = { b101 e8???????? e8???????? 84c0 }
		$sequence_6 = { 750c ff35???????? ff15???????? 6aff ff35???????? ff15???????? ff35???????? }
		$sequence_7 = { 48 3d80ee3600 890d???????? 0f97c0 84c0 }
		$sequence_8 = { 8b4638 5f 66894812 33c9 }
		$sequence_9 = { 7e49 488d0db84c0200 e8???????? 3935???????? 7535 4488642430 }
		$sequence_10 = { 0000 83bd641a0000ff 0f85fc040000 c6859412000000 }
		$sequence_11 = { 03c2 c1f802 6bc003 894504 }
		$sequence_12 = { 05e0930400 894544 8b5544 488b4508 }
		$sequence_13 = { 488d3dccc90100 488bcf e8???????? 4c8bc0 488bd7 488bcb }
		$sequence_14 = { 0bc1 488b4d48 8801 488b4548 }
		$sequence_15 = { 034524 3b8520010000 760c c785f400000001000000 }
		$sequence_16 = { 0bc1 4898 488d0d12920200 488b5528 }
		$sequence_17 = { 03c8 8bc1 8985a4000000 488d8da8010000 }
		$sequence_18 = { 33ff c705????????61006e00 488d15dcfeffff 66893d???????? }
		$sequence_19 = { e8???????? 488bf8 488d5802 488bcb }
		$sequence_20 = { 4833cc e8???????? 4c8d9c2430010000 498b5b10 498b7b20 498be3 5d }
		$sequence_21 = { 00040f 830905 0000 83bd641a0000ff }

	condition:
		7 of them and filesize < 778240
}
rule MALPEDIA_Win_Mewsei_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "acd36f0e-95d2-55f3-849f-3f4ef2fcdbb5"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.mewsei"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.mewsei_auto.yar#L1-L120"
		license_url = "N/A"
		logic_hash = "83eaae0b2425f53d585e3367f9c1d9f9d33bfdceedced28b3f3f21165da8e384"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 57 8bf0 43 8d642400 53 e8???????? 8bf8 }
		$sequence_1 = { 8bc8 8d86c39e2600 894508 c1e810 2bf9 25ff7f0000 33d2 }
		$sequence_2 = { 337dfc 037de8 8dbc1f019546fd c1cf0a 037df8 0fb65822 }
		$sequence_3 = { 8b5d08 56 57 8bf0 43 8d642400 }
		$sequence_4 = { 83c404 57 894dfc e8???????? }
		$sequence_5 = { 0bfb 0fb65818 c1e708 0bfb 8b5df8 897970 897dc8 }
		$sequence_6 = { ebe6 56 8b35???????? 57 }
		$sequence_7 = { c1cf0b 03fe f7d2 0bd7 }
		$sequence_8 = { 83c410 6a06 53 ff15???????? }
		$sequence_9 = { c1ea10 884708 8b4610 884f05 885706 8bc8 8bd0 }

	condition:
		7 of them and filesize < 504832
}
rule MALPEDIA_Win_Darkloader_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "66d7864b-6b8b-59a3-bf42-10c3f203996d"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.darkloader"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.darkloader_auto.yar#L1-L118"
		license_url = "N/A"
		logic_hash = "c6a0feca633006ba737e5d6e39640d80017f5e7d7305993c6a682da952eb973f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff15???????? 8bd8 8d442428 50 6800020000 8d442440 }
		$sequence_1 = { 3bd1 72e3 8b35???????? 6a3a 57 }
		$sequence_2 = { 2b4a0c 034d14 3b4d10 1bc0 }
		$sequence_3 = { 8931 e8???????? 83c410 33c0 40 ebaf 83ec18 }
		$sequence_4 = { ffd5 a1???????? 40 85c0 7e5e 8bfe 8d8f10610010 }
		$sequence_5 = { ffd6 68???????? ffb7dc010000 8987bc010000 ffd6 68???????? }
		$sequence_6 = { 84c0 740b 80f90d 7519 }
		$sequence_7 = { 85c0 741f 8b04b1 03c7 }
		$sequence_8 = { 6a08 8bf8 be???????? 59 8d442414 f3a5 }
		$sequence_9 = { ff15???????? 6a3b 8d7003 56 ff15???????? }

	condition:
		7 of them and filesize < 124928
}
rule MALPEDIA_Win_Ehdevel_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "19424beb-adc6-5d0a-ad17-237b1eb977db"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.ehdevel"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.ehdevel_auto.yar#L1-L123"
		license_url = "N/A"
		logic_hash = "fea261a706fd4aecdfcc680ba9e080fcea9d64a6768f96b3fd04aa7217c33873"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 52 8d1448 68???????? 52 e8???????? 83c40c 837e1408 }
		$sequence_1 = { 50 e8???????? 6a22 8d8c24c8000000 8d542424 c78424dc04000000000000 e8???????? }
		$sequence_2 = { e8???????? 8bd8 83c404 53 56 }
		$sequence_3 = { 8bce c745fc0d000000 e8???????? c745fcffffffff 837de808 720c }
		$sequence_4 = { 8b85e48bffff 50 ffd6 68???????? }
		$sequence_5 = { 33ff 57 8985b4f7ffff ff15???????? 33d2 8d85f0f7ffff 668995d4f7ffff }
		$sequence_6 = { 83ec08 8b4d10 8b5514 8b450c 52 8b5508 }
		$sequence_7 = { 53 ff15???????? 85c0 7533 83fe05 7345 }
		$sequence_8 = { c745fc13000000 e8???????? 837dcc08 720c 8b45b8 }
		$sequence_9 = { 83c404 51 e8???????? 83c404 8d95d88bffff 52 }

	condition:
		7 of them and filesize < 524288
}
rule MALPEDIA_Win_Snifula_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "7bbbf6bc-70f6-50a6-99b1-7e29bdab7eb4"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.snifula"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.snifula_auto.yar#L1-L133"
		license_url = "N/A"
		logic_hash = "f05be77d056199290810b751a733076013f75876916d8edfae5ed22845cffa0b"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 0fb74da2 03c1 3945f8 7512 8b5d08 8d45e0 50 }
		$sequence_1 = { 8d45e8 50 e8???????? 85c0 74d3 ff75e8 ff7508 }
		$sequence_2 = { eb0b 8b0e 57 ff7508 e8???????? 85c0 7503 }
		$sequence_3 = { 68???????? ff742424 ff15???????? ff742420 89442414 ffd6 50 }
		$sequence_4 = { eb05 68???????? ff75fc ff75f8 e8???????? 8d45f4 }
		$sequence_5 = { ff15???????? 83fbff 7508 ff15???????? 8bd8 a1???????? 3bc5 }
		$sequence_6 = { 8bf0 3bf7 7505 6a02 5b eb40 6a5c }
		$sequence_7 = { ff7510 ff750c 56 e8???????? 8bd8 56 ff15???????? }
		$sequence_8 = { 6a40 ffd7 8bd8 85db 75cc 85db 7445 }
		$sequence_9 = { ff5010 897320 eb06 8b7c2410 33f6 8b17 56 }

	condition:
		7 of them and filesize < 188416
}
rule MALPEDIA_Win_Httpdropper_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "9ff3d173-51a5-5129-a28c-6c1dc03c2346"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.httpdropper"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.httpdropper_auto.yar#L1-L157"
		license_url = "N/A"
		logic_hash = "9e0fd99950b930c59fe8900d1aa67c88d807665c16be8d137d328cf0a232faa4"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 014b18 c7437c00000000 897b70 85c0 0f85b4010000 }
		$sequence_1 = { 018614400000 8b8614400000 c68430142000000d ff8614400000 }
		$sequence_2 = { 018610200000 8d5e10 8d9b00000000 8b9610200000 }
		$sequence_3 = { 8985a4f0ffff 8985a8f0ffff 8985acf0ffff 8985b0f0ffff 8985b4f0ffff e8???????? }
		$sequence_4 = { 014614 bb40000000 2bd9 3bfb 7254 }
		$sequence_5 = { 017df8 83f93d 7471 83f920 7505 b92b000000 0fbf0c4d20a80310 }
		$sequence_6 = { 0110 80aa0110a4aa01 1023 d18a0688078a 46 }
		$sequence_7 = { 015dfc 83c204 81fa???????? 7cb7 3d00010000 740a c786a4af060078420310 }
		$sequence_8 = { 03c9 2bd9 81ff94010000 7519 }
		$sequence_9 = { 018b70af0100 8b9370af0100 488d0d8e6f0100 e8???????? }
		$sequence_10 = { 03742478 488d442478 4533c9 4533c0 }
		$sequence_11 = { 03cb 69c960ea0000 ff15???????? e9???????? }
		$sequence_12 = { 039c2488000000 488d842488000000 c744243080000000 4533c9 }
		$sequence_13 = { 014e28 48c786a800000000000000 899698000000 85c0 }
		$sequence_14 = { 018b18400000 8b8318400000 488d8b20400000 c68418182000000d }
		$sequence_15 = { 03c8 85db 740e 3bd9 }

	condition:
		7 of them and filesize < 524288
}
rule MALPEDIA_Win_Batel_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "c91d0b1c-2fe0-51d7-a49d-7d6cffcd2786"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.batel"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.batel_auto.yar#L1-L231"
		license_url = "N/A"
		logic_hash = "a9cd956e2178bd46c61a7442a0a8fdeafc2cb5e9b8c9fa3dfaa648b03338c845"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 33c0 5b c21000 3b0d???????? 7502 }
		$sequence_1 = { 68ee020000 ff15???????? 689d020000 8d8561fdffff 6a00 50 }
		$sequence_2 = { 6868212300 e8???????? 33db 895de4 }
		$sequence_3 = { 83c003 41 3d???????? 7cec 56 57 }
		$sequence_4 = { 56 ffd3 68005c2605 ffd5 47 }
		$sequence_5 = { 8b4508 2d00002300 50 6800002300 e8???????? 83c408 85c0 }
		$sequence_6 = { ff750c ff7508 6862102300 6800302300 e8???????? }
		$sequence_7 = { 83c40c 33c9 b8???????? 8a10 88940d60fdffff 83c003 }
		$sequence_8 = { ff15???????? 8bf0 85f6 7429 68f4202300 }
		$sequence_9 = { ff15???????? 85c0 7412 ffd0 56 ffd3 }
		$sequence_10 = { 85f6 7422 68???????? 56 ff15???????? 85c0 7412 }
		$sequence_11 = { 6a00 50 c68560fdffff00 e8???????? 83c40c 33c9 }
		$sequence_12 = { ffd5 47 83ff5a 7ccd }
		$sequence_13 = { 8db560fdffff f3a5 66a5 ffd0 5f 5e }
		$sequence_14 = { 56 57 68a00f0000 ffd5 8b1d???????? }
		$sequence_15 = { 7505 e8???????? 33c0 5d c20400 685f142300 ff15???????? }
		$sequence_16 = { a1???????? 85c0 752c 8935???????? 68d0202300 }
		$sequence_17 = { 8b1d???????? bf01000000 8d642400 68???????? ff15???????? 8bf0 }
		$sequence_18 = { ff15???????? 8b1d???????? bf01000000 8da42400000000 68e0202300 ff15???????? }
		$sequence_19 = { 8bec 81eca0020000 68ee020000 ff15???????? }
		$sequence_20 = { 7cec 56 57 6a40 6800100000 689e020000 }
		$sequence_21 = { 83ff5a 7ccd 5f 5e 5d 33c0 5b }
		$sequence_22 = { 8bf8 b9a7000000 8db560fdffff f3a5 }

	condition:
		7 of them and filesize < 49152
}
rule MALPEDIA_Win_Govrat_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a0adde9e-3e51-5961-9fff-4f2bba43e7c1"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.govrat"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.govrat_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "ed9b437491d58e3740ad17651b9e90a61309b97a9b0eedc74e010f01d57ad8ac"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 41 bb00000001 8b45f4 03c9 0fb71401 3bf3 7320 }
		$sequence_1 = { 214328 8b5b24 83650800 8b03 8d4d08 51 68???????? }
		$sequence_2 = { 8dbc1fbc060000 8b0a 03c8 3b4fe4 7312 8367ec00 894fe4 }
		$sequence_3 = { 5e c3 56 8bf0 837e3800 7510 8b460c }
		$sequence_4 = { 5e 5b c9 c22400 55 8bec 33d2 }
		$sequence_5 = { 0fb67203 0bc6 0fb67202 c1e008 0bc6 0fb67201 8a12 }
		$sequence_6 = { c3 e9???????? ff30 ff15???????? 85c0 7403 33c0 }
		$sequence_7 = { 53 6a01 8d75bc e8???????? e8???????? c20400 }
		$sequence_8 = { 75e9 5b ff4110 ff01 5f 5e c3 }
		$sequence_9 = { 51 6a00 6a00 8d4e10 51 }

	condition:
		7 of them and filesize < 761856
}
rule MALPEDIA_Win_Arkei_Stealer_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "1ff4580b-8b19-5e53-b269-6e75c511dc86"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.arkei_stealer"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.arkei_stealer_auto.yar#L1-L121"
		license_url = "N/A"
		logic_hash = "4c709e182d89d5128b6d6587e034cdc74f917fae7660ce44151555584b04874f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b4e20 8b16 8d448a0e 6a00 8d4de4 51 6a0e }
		$sequence_1 = { 8bf0 c70628000000 8b4dc8 894e04 8b55cc 895608 }
		$sequence_2 = { 6800000080 56 894590 ff15???????? 8bf8 }
		$sequence_3 = { 51 6a00 ffd6 8b55e8 52 }
		$sequence_4 = { ff15???????? 8bf8 83ffff 0f849ffeffff ba424d0000 }
		$sequence_5 = { ffd3 6a0a 57 8bf0 ffd3 8bd8 }
		$sequence_6 = { 895608 668b45d4 6689460c 668b4dd6 66894e0e }
		$sequence_7 = { 5d c3 50 8b45e8 50 ff15???????? }
		$sequence_8 = { 6a0a 57 8bf0 ffd3 8bd8 53 56 }
		$sequence_9 = { 770a bb10000000 e9???????? 83f818 0f8783010000 }

	condition:
		7 of them and filesize < 1744896
}
rule MALPEDIA_Win_Slave_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "4df4605b-07a1-5fbc-9b50-4342e1e7d61f"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.slave"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.slave_auto.yar#L1-L133"
		license_url = "N/A"
		logic_hash = "aefe114bb85055235d088c2678b6138d63a7e1c41d697f85bcafaf9d4603d12f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 03d1 8bc7 0355fc 8bcf c1c007 c1c90b 33c8 }
		$sequence_1 = { 57 ff15???????? 85c0 7456 8b5dd4 8d642400 ff15???????? }
		$sequence_2 = { 6a00 50 660f134580 e8???????? 83c40c 8d4580 8bcf }
		$sequence_3 = { 722f 80f9ff 7319 0fb6c1 ba00010000 2bd0 0fb78610030000 }
		$sequence_4 = { 50 ff15???????? 83c40c 008608010000 85db 743b 8a9608010000 }
		$sequence_5 = { c1c20f 33d0 8bc3 8b5d9c 8bcb c1e80a 33d0 }
		$sequence_6 = { 8b5dd8 03d1 8bc7 0355a8 8bcf c1c007 c1c90b }
		$sequence_7 = { 56 57 6aff ff35???????? 8bfa 8bd9 ff15???????? }
		$sequence_8 = { 895de8 ff15???????? 85c0 0f84df010000 53 ff15???????? }
		$sequence_9 = { 83f801 7562 8b7df0 8d9b00000000 6a01 6a00 6a00 }

	condition:
		7 of them and filesize < 532480
}
rule MALPEDIA_Win_Cheesetray_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "cab41cc9-9428-5388-bc73-0880c66d591c"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.cheesetray"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.cheesetray_auto.yar#L1-L130"
		license_url = "N/A"
		logic_hash = "819f85e057844bd58437c79b7e79de2057daf73c3727fba32535e1f6b3a50eca"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 40 84c9 75f9 2bc2 8bf8 8d5f01 53 }
		$sequence_1 = { 85c0 7442 6a0a 8d8500ffffff 6a00 50 e8???????? }
		$sequence_2 = { 83c41c f7d8 1bc0 f7d8 8be5 }
		$sequence_3 = { 66833c4200 75f8 8d0c00 8b4508 52 }
		$sequence_4 = { 5f 5e 8bc3 5b 5d c20c00 8bc3 }
		$sequence_5 = { 55 8bec 83ec10 33c0 c645f000 8945f1 8945f5 }
		$sequence_6 = { 7408 8bc6 5e 5b 8be5 5d c3 }
		$sequence_7 = { e8???????? 83c408 894608 85c0 7403 ff4604 5f }
		$sequence_8 = { e8???????? 8b5508 6a02 52 68???????? ba1f000000 8d75c0 }
		$sequence_9 = { 8b80008b4400 3bf0 7e44 83ee07 eb3f 2503000080 7905 }

	condition:
		7 of them and filesize < 8626176
}
rule MALPEDIA_Win_Unidentified_091_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "3ffd4855-aa49-5cd4-880a-1fffb5facf57"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.unidentified_091"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.unidentified_091_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "4b1635ec30557499ad9102c2fd105acd53be0d253d9fbc0c6144a000cea6f524"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 488d4101 480f43c1 498b4e28 4803f8 448bc9 483bf8 490f43db }
		$sequence_1 = { c3 41b89d000000 488d1598910c00 488bcf e8???????? 488b7c2440 b801000000 }
		$sequence_2 = { 4c8bc6 e8???????? 41bcc0000000 0f1f00 4c8b842488000000 488d5310 488bcb }
		$sequence_3 = { e8???????? 488b4b18 e8???????? 488b4b30 488d15788f1100 41b86b000000 e8???????? }
		$sequence_4 = { d3e8 49895708 41894718 0fb60a 83e10f 4a0fbe840108841d00 428a8c0118841d00 }
		$sequence_5 = { 7433 498b54cd18 4d8bc6 488b4d18 e8???????? 4c8d05ab311200 85c0 }
		$sequence_6 = { c1e017 0bc1 89442404 8bca c1e916 8bc2 83e11f }
		$sequence_7 = { 85c0 0f845f010000 4533c0 488d542440 488bce e8???????? 85c0 }
		$sequence_8 = { 8d0c03 488b442448 803c0100 0f854b020000 c6040101 8b0c8f 3bce }
		$sequence_9 = { 8b94b3b07b2500 448b848bb0772500 428b8c93b07f2500 42338c8bb0832500 4133c8 33ca 334c2420 }

	condition:
		7 of them and filesize < 5777408
}
rule MALPEDIA_Win_Socks5_Systemz_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f8c71c14-518a-57b0-8d96-0e25677180ee"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.socks5_systemz"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.socks5_systemz_auto.yar#L1-L114"
		license_url = "N/A"
		logic_hash = "5a9f5cce284860f412a611f9992dbf35fdb362e7145a24d4a2b1bf3424617984"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 50 8d4c2440 e8???????? c744244824000000 8974244c c74424640f000000 c744246000000000 }
		$sequence_1 = { 53 ff15???????? 8b0e e8???????? 83c608 3bf7 7593 }
		$sequence_2 = { 59 59 5d c3 a1???????? c3 6a08 }
		$sequence_3 = { 53 e8???????? 8b5c241c 8bd0 83c408 8bca 33c0 }
		$sequence_4 = { 8d4c2414 e8???????? c744241c01000000 89742420 c74424380f000000 c744243400000000 c644242400 }
		$sequence_5 = { 50 ff7314 ff7310 e8???????? 8b4310 83c410 8b3d???????? }
		$sequence_6 = { 33c4 50 8d442424 64a300000000 a1???????? 83f8ff 7508 }
		$sequence_7 = { 0f8393000000 8b07 89442404 8d442404 50 e8???????? f744240400000080 }

	condition:
		7 of them and filesize < 1417216
}
rule MALPEDIA_Win_Tonerjam_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f9f596e2-9aa3-585e-9f1c-95f6fb27fc56"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.tonerjam"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.tonerjam_auto.yar#L1-L116"
		license_url = "N/A"
		logic_hash = "3477ce7df2407b1c4cb33af4e4af4edb9bdb2201b4d9af85217ccddaf77262ab"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 48d3cf 4933fa 4b87bcfe601d0200 33c0 488b5c2450 488b6c2458 }
		$sequence_1 = { 4883ec28 488d0ded900100 e8???????? 488d0df9900100 e8???????? b001 }
		$sequence_2 = { 498784f6c01c0200 eb1e 488bc3 498784f6c01c0200 4885c0 }
		$sequence_3 = { 33c9 ff15???????? 488d0da09a0100 eb0c 83f901 }
		$sequence_4 = { 4883ec20 33db 488d1561600100 4533c0 }
		$sequence_5 = { 895c2428 488d0dd39c0000 4533c9 4489442420 }
		$sequence_6 = { 83b97004000002 0f848c010000 4c8d356f0c0100 897350 }
		$sequence_7 = { 4885c0 7429 48833d????????00 741f 48833d????????00 7415 }
		$sequence_8 = { 0f1f8000000000 488d15d1c50100 488d4c244c e8???????? 85c0 7460 }
		$sequence_9 = { 2bc8 48d3cf 4933fa 4b87bcfe601d0200 33c0 488b5c2450 }

	condition:
		7 of them and filesize < 315392
}
rule MALPEDIA_Win_Simda_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "2ca6fcb2-3ba2-5953-ac31-83fead484ce2"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.simda"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.simda_auto.yar#L1-L115"
		license_url = "N/A"
		logic_hash = "20f714d7b602fcb6eb2667d8fabfc9d0c5ec1a5bd6989c685d4904bc7267afbf"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 40 3b4604 72f1 894e04 }
		$sequence_1 = { c1e310 03d3 c1e110 0b4df8 83cbff }
		$sequence_2 = { 51 c685f8feffff00 e8???????? 8b35???????? }
		$sequence_3 = { 2bd7 f7c20000ffff 7404 48 034d10 8b5508 }
		$sequence_4 = { 83f906 7519 8b85e8feffff 85c0 7505 8d41ff eb0f }
		$sequence_5 = { 52 ffd7 85c0 740c 68???????? }
		$sequence_6 = { 8bf8 0faf7dfc c1e210 0b55f8 3bfa }
		$sequence_7 = { ffd7 83c408 85c0 74e4 6a0a 6a00 }
		$sequence_8 = { 8bd1 c1ea10 8955ec 8bf8 }
		$sequence_9 = { 85c0 75dd 8b4d0c 8bc3 2bc2 }

	condition:
		7 of them and filesize < 1581056
}
rule MALPEDIA_Win_Formbook_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "fe324cee-b5cc-559e-b30b-9b1c20d9f63c"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.formbook"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.formbook_auto.yar#L1-L129"
		license_url = "N/A"
		logic_hash = "057b0984502243358a5777bfa3678e3ea44342983822929c2023018fe04c4573"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 5b 03f1 5f c6040600 }
		$sequence_1 = { 8b10 8d4d0c 51 52 50 e8???????? 83c418 }
		$sequence_2 = { 85c0 7458 56 33f6 803b00 7413 46 }
		$sequence_3 = { e8???????? 53 8d55ec 52 8b16 8d85d8fcffff 50 }
		$sequence_4 = { e8???????? 8b45fc 50 57 e8???????? 8d8d50ffffff 8bd1 }
		$sequence_5 = { 7439 8b4514 8d4814 51 8d908c020000 52 8d8820020000 }
		$sequence_6 = { 894df8 e8???????? 830702 83c40c 830603 8b06 8a4c1801 }
		$sequence_7 = { 83c404 3bfe 72ef 8b45fc 8b7d10 8b8f40020000 8b5514 }
		$sequence_8 = { 813b50450000 7408 5f 33c0 5b }
		$sequence_9 = { 89948db8feffff 0fb65007 c1e208 0bd7 0fb67809 c1e208 0bd7 }

	condition:
		7 of them and filesize < 371712
}
rule MALPEDIA_Win_Albaniiutas_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "13440687-8c21-5f4b-b6bc-446a9f1ec941"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.albaniiutas"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.albaniiutas_auto.yar#L1-L122"
		license_url = "N/A"
		logic_hash = "edd484627bb954fa8e202e25a56243ca3a624b8df8d8b884d5066e7ae7a8a385"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 50 8b04bd90df0210 ff743018 ff15???????? 85c0 }
		$sequence_1 = { 85c0 0f85b7000000 0f1f4000 8b430c 85c0 }
		$sequence_2 = { f7c200e00000 7416 8b4508 c74018201b0110 c74104513f0000 e9???????? 8b7124 }
		$sequence_3 = { 85c0 741f 56 57 6a00 6a01 6a00 }
		$sequence_4 = { c745dc03000000 c745e0f07c0110 e9???????? 83e80f }
		$sequence_5 = { 240f 3c08 7416 8b4508 c74018f01a0110 c74104513f0000 e9???????? }
		$sequence_6 = { 85db 7409 53 e8???????? 83c404 8b0d???????? 85c9 }
		$sequence_7 = { 7512 8b04bd90df0210 807c302900 7504 32c0 eb1a }
		$sequence_8 = { 8bcb e8???????? 8945c8 8945dc 85c0 751c }
		$sequence_9 = { 8b048d64700010 ffe0 f7c703000000 7413 }

	condition:
		7 of them and filesize < 566272
}
rule MALPEDIA_Win_Phandoor_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a25deddd-a427-5430-8cb0-81f3739a68b5"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.phandoor"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.phandoor_auto.yar#L1-L168"
		license_url = "N/A"
		logic_hash = "05b226d22b12d0028a23b074e4b71bb6809a51921e7a27eae3ade9f0024843f3"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { a3???????? 7404 85c0 7507 c745f001000000 }
		$sequence_1 = { 731d 8d4702 56 0fb7f9 }
		$sequence_2 = { 2255ff 32d9 c1e818 8d0c3f 33cf 32d3 }
		$sequence_3 = { 68???????? 6a08 b834343434 b912121212 }
		$sequence_4 = { 8d55fc 8bf0 52 56 8975f4 ff15???????? 3bf3 }
		$sequence_5 = { 3bfe 8b35???????? 0f8491050000 b9???????? e8???????? }
		$sequence_6 = { 881c16 8bd8 c1eb08 8bd1 895df8 8bd9 c1ea08 }
		$sequence_7 = { 57 ffd6 833d????????00 a3???????? 0f8482000000 833d????????00 7479 }
		$sequence_8 = { 741c 8b0d???????? 68???????? 51 c705????????04000000 }
		$sequence_9 = { 6a03 d1ea 8d85e8efffff e8???????? }
		$sequence_10 = { 57 68???????? 50 c705????????03000000 ffd6 8b0d???????? 33ff }
		$sequence_11 = { 6a03 d1ea 8bc3 e8???????? 8bc8 85c9 }
		$sequence_12 = { 83c404 8bf7 85ff 75e6 5f c7430800000000 }
		$sequence_13 = { 3acb 740e 50 ffd6 }
		$sequence_14 = { 43 84c0 7409 8803 }
		$sequence_15 = { 741c 56 8b35???????? 3acb 740e }

	condition:
		7 of them and filesize < 2124800
}
rule MALPEDIA_Win_Astarion_Rat_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "2f8674f7-b06d-58e7-9205-785a249b18e0"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.astarion_rat"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.astarion_rat_auto.yar#L1-L129"
		license_url = "N/A"
		logic_hash = "782a7e9d4aa78e73dce71afa657f71df324ce9b2324a728751bd3e9d9daa0e2a"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 488d542430 0fb605???????? 4533c9 4533c0 f20f11442430 }
		$sequence_1 = { 48894610 e8???????? 488b5e10 eb07 488bf3 488b5b10 4885db }
		$sequence_2 = { 48898424a0040000 8b09 48c744243000000000 e8???????? 8bd8 e8???????? }
		$sequence_3 = { 742f 4885c0 7521 4c8d0d2f120100 33c9 4c8d0522120100 488d1523120100 }
		$sequence_4 = { 85c0 0f8497000000 e8???????? 85c0 757a 8b4c2460 ba01000000 }
		$sequence_5 = { eb09 b005 eb05 0fb6442435 8074243410 3410 }
		$sequence_6 = { c605????????01 b001 4883c428 c3 4883ec28 e8???????? 488d15bca00100 }
		$sequence_7 = { 4889742440 33f6 4c89742438 4c897c2430 0f1f4000 6666660f1f840000000000 8b0d???????? }
		$sequence_8 = { 4157 488dac2480f8ffff 4881ec80080000 488b05???????? 4833c4 48898570070000 4c89442468 }
		$sequence_9 = { 0f298520010000 0f2805???????? 0f298d00010000 0f280d???????? 88851a010000 0fb705???????? }

	condition:
		7 of them and filesize < 462848
}
rule MALPEDIA_Win_Globeimposter_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "2c5cad15-db9b-5f23-a86c-5399ac01bea2"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.globeimposter"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.globeimposter_auto.yar#L1-L117"
		license_url = "N/A"
		logic_hash = "55ecbf6785f9da06ab241732740101081e6715da1f8d3fa598798e2a4d194e11"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c1e810 8bca c1e908 23c7 23cf }
		$sequence_1 = { 1bdb 45 83c104 f7db 75d7 }
		$sequence_2 = { 6af2 58 eb03 33c0 }
		$sequence_3 = { 0f6e670c 0fd4fc 0f7e0f 0f6e5610 0ff4d0 }
		$sequence_4 = { ff7514 85c0 750b ff15???????? 6ac4 58 }
		$sequence_5 = { ff15???????? 85c0 7405 3975fc 7405 6afe 58 }
		$sequence_6 = { 7426 8bc5 c1e002 50 ff7608 53 }
		$sequence_7 = { 50 ffb63c010000 ff9638010000 85c0 }
		$sequence_8 = { 8d4e7c 8b41fc 3b01 8d4914 1bc0 f7d0 23d8 }
		$sequence_9 = { c745f401000000 2bc2 8945fc 33c0 }

	condition:
		7 of them and filesize < 327680
}
rule MALPEDIA_Win_Flagpro_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "afe8df45-559d-54b4-806a-4f267d595c3c"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.flagpro"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.flagpro_auto.yar#L1-L124"
		license_url = "N/A"
		logic_hash = "6f06ce5e2fe94561a4a2c6a137520be8086d07b3acfbcce30d5f314c040b013e"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b03 eb02 8bc3 55 8d2c3f 55 }
		$sequence_1 = { 8b44241c 8b08 8b5108 50 ffd2 8d442420 }
		$sequence_2 = { 8b442418 8b4c244c 8901 8d44241c }
		$sequence_3 = { 52 e8???????? 83c404 33f6 895c2474 }
		$sequence_4 = { 8bff 55 8bec 8b4508 56 8d34c550d84100 }
		$sequence_5 = { 3b5c2414 0f8274feffff 8b542410 52 ff15???????? }
		$sequence_6 = { 8b4148 ffd0 8b442434 3bc3 7425 8d542448 52 }
		$sequence_7 = { 3de8030000 0f8ee3010000 8d9017fcffff b8d34d6210 f7e2 c1ea06 42 }
		$sequence_8 = { 8b06 3b78f8 7f11 8978f4 8b0e 33d2 66891479 }
		$sequence_9 = { 52 ff15???????? 8b8c24841c0000 5f 5e 5d 5b }

	condition:
		7 of them and filesize < 1411072
}
rule MALPEDIA_Win_Ksl0T_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "77dceb90-4d35-58a2-bd3f-d65cdc7cdbc8"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.ksl0t"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.ksl0t_auto.yar#L1-L171"
		license_url = "N/A"
		logic_hash = "af8e3524b9f1201042fe38971276f985a5d34e17af754d500fc821e8e23146dd"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 66898424d0040000 488dbc24d2040000 33c0 b906020000 f3aa }
		$sequence_1 = { 894dd8 3bce 732b b81f85eb51 f7e3 c1ea05 6bd264 }
		$sequence_2 = { 49d1e0 488d9424b0100000 488d0d2eec0000 ff15???????? }
		$sequence_3 = { 55 8dac2494f7ffff 81ec6c080000 6afe }
		$sequence_4 = { 8d8500080000 50 ff15???????? 897dcc 8d4dcc 51 53 }
		$sequence_5 = { c684249e02000027 c684249f02000032 c68424a002000023 c68424a102000002 }
		$sequence_6 = { 68???????? 68???????? ff15???????? 8935???????? 83c40c 393d???????? }
		$sequence_7 = { 41b800020000 33d2 488d8c24b0100000 ff15???????? 448b8424b4140000 488d155ac90000 }
		$sequence_8 = { 488b842420040000 4c899870010000 488d9424e8010000 488b8c24e0000000 ff942418040000 4c8bd8 488b842420040000 }
		$sequence_9 = { c68424e100000027 888424e2000000 c68424e300000034 889c24e4000000 888424e5000000 c68424e600000018 }
		$sequence_10 = { 83f819 72f3 33c0 90 308c0400010000 }
		$sequence_11 = { 2bc1 56 57 89442418 }
		$sequence_12 = { 6a04 68???????? 68???????? ff15???????? 83c40c e9???????? 6a07 }
		$sequence_13 = { 488d1505c40000 4881c296000000 41b801000000 488d0db1e60000 }
		$sequence_14 = { 83c00c 898424f4080000 0fb705???????? 85c0 7475 488d152adc0000 4883c20c }
		$sequence_15 = { 4889442458 48837c245800 756e ff15???????? 898424b4140000 41b800020000 }

	condition:
		7 of them and filesize < 196608
}
rule MALPEDIA_Win_Buer_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "49e85813-f004-5b51-ab07-ecc4991b1659"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.buer"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.buer_auto.yar#L1-L163"
		license_url = "N/A"
		logic_hash = "43890e06ef95ed35c56a939cb233e158115330f727a35e88cce512744b7e77a1"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { eb05 e8???????? 46 83fe20 7cd1 }
		$sequence_1 = { 8b4b44 8b5348 8b734c 8b7b50 8b4340 0345f8 }
		$sequence_2 = { 85ff 7504 8bc2 eb19 33c0 85d2 }
		$sequence_3 = { 8b45f4 03c1 8bcb 894144 8b45f0 }
		$sequence_4 = { 7cf1 eb02 33c0 5f 5e }
		$sequence_5 = { 8b55d8 894148 8b45dc 03c6 }
		$sequence_6 = { 03c2 8b55e8 015158 8b55d8 894148 }
		$sequence_7 = { 8a0c46 880c18 40 3bc2 7cf1 eb02 }
		$sequence_8 = { 01cf 0f92c1 08f9 751d }
		$sequence_9 = { 01fe 68???????? e8???????? a1???????? }
		$sequence_10 = { 017708 b803000000 31d2 83c418 5e 5f }
		$sequence_11 = { 0fb617 47 89f9 83e23f eb11 }
		$sequence_12 = { 0facd313 884e04 8b74247c 8bc6 8b4c2440 }
		$sequence_13 = { 0f82d1000000 83f8fe 0f83d1000000 89d6 }
		$sequence_14 = { 0facd30d 8b542464 0facc108 885e14 8bc2 8b5c2418 884e16 }
		$sequence_15 = { 01de 39c1 0f47c1 89c1 }

	condition:
		7 of them and filesize < 3031040
}
rule MALPEDIA_Win_Ahtapot_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "30983b3b-d2d6-5541-9384-47b5921b3fc8"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.ahtapot"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.ahtapot_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "7f340dfa857e7f52e8c2b134f735bba10e8c0df571d4ec73a1af949780ad4400"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c1fa05 8bc2 c1e81f 03d0 b814000000 2bc2 0fb7542410 }
		$sequence_1 = { 51 8d9580fbffff 52 8d8570f7ffff 68???????? 50 ffd7 }
		$sequence_2 = { 8d842494000000 6683383f 7508 ba20000000 668910 41 66399c4c94000000 }
		$sequence_3 = { bf00000800 7413 893d???????? 833b02 7422 }
		$sequence_4 = { 69c9e8030000 51 ff15???????? 80bec412000000 0f8504fbffff 33c0 8b8c24d8120000 }
		$sequence_5 = { 7cb7 3d00010000 740a c786a4af060028a74200 8a55fc 8894303c1b0000 8d8eb41e0000 }
		$sequence_6 = { 0f8494000000 8d85bcf7ffff 8d5002 8d642400 668b08 83c002 6685c9 }
		$sequence_7 = { 889d65cbffff 89954ccbffff 898550cbffff 899d28cbffff 899d38cbffff 899d48cbffff }
		$sequence_8 = { 75df 8d85d0fdffff 50 ffd3 8b4dfc 5f 5e }
		$sequence_9 = { 899d70cbffff 899568cbffff 899d60cbffff 3bf3 7533 8b8518cbffff 8b4804 }

	condition:
		7 of them and filesize < 430080
}
rule MALPEDIA_Win_Bitsran_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "e49d8b03-d509-5c97-ad65-7be772b4fe45"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.bitsran"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.bitsran_auto.yar#L1-L119"
		license_url = "N/A"
		logic_hash = "acbdd588e6e72884d207c16f0de3f45c455431dd7827a6173dda5ee438f3c91f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 030495a01f4200 eb05 b8???????? f6400420 7414 6a02 53 }
		$sequence_1 = { 8b4508 33c9 3b04cda8034200 7413 41 83f92d }
		$sequence_2 = { 8bc7 c1f805 c1e606 033485a01f4200 8b45f8 }
		$sequence_3 = { 8bd1 c1fa05 c1e006 030495a01f4200 eb05 }
		$sequence_4 = { 83ec54 56 8b7508 85f6 7508 83c8ff }
		$sequence_5 = { 57 8d45ec 50 8d8decfbffff }
		$sequence_6 = { 75e6 c6460401 830eff 2b34bda01f4200 }
		$sequence_7 = { ff15???????? 6803010000 8d85f1fcffff 6a00 50 c685f0fcffff00 }
		$sequence_8 = { 8a85eefcffff 8a8deffcffff c7830c02000000000000 84c9 740a }
		$sequence_9 = { 3bfa 7553 8bc7 2bc3 c1f802 3dfeffff3f 775c }

	condition:
		7 of them and filesize < 344064
}
rule MALPEDIA_Win_Exaramel_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "2ddd7b86-9895-5b18-9ae3-94445f241da0"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.exaramel"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.exaramel_auto.yar#L1-L128"
		license_url = "N/A"
		logic_hash = "6793ec2343fa0e7eb525f328d2b906b2dc0c3b077f52cb511420363af1826e17"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 660fd60f 8d7f08 8b048d74404100 ffe0 f7c703000000 7413 8a06 }
		$sequence_1 = { e8???????? 8bc7 83c404 8b4dfc 5f 33cd }
		$sequence_2 = { ff15???????? 85c0 746d 53 57 ff75fc 8b3d???????? }
		$sequence_3 = { ff15???????? 68???????? 8d852cf8ffff 50 ffb528f8ffff e8???????? }
		$sequence_4 = { 68???????? 68???????? 68???????? 8d45fc 50 8d45b8 }
		$sequence_5 = { e8???????? 83c408 8bf0 ff7704 ff15???????? 85f6 7414 }
		$sequence_6 = { c1f806 6bc930 8b048560dd4100 f644082801 7406 8b440818 5d }
		$sequence_7 = { 83c410 ba03010000 85c0 0f44ca 8bc1 }
		$sequence_8 = { 56 e8???????? 83c408 85c0 7429 ffb5f0fdffff e8???????? }
		$sequence_9 = { 6a03 68???????? e8???????? 8145e800403d7f 8d45e8 8155ec5b020000 }

	condition:
		7 of them and filesize < 294912
}
rule MALPEDIA_Win_Geckostealer_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "52d91e40-1417-5248-bcd8-937fdaf076b9"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.geckostealer"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.geckostealer_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "967875101e440228581931aac3b2586b63b4acc327fd0af5c454f78824313111"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? e9???????? 48c1ef20 897d08 488b0e 488b4608 488d15cc6b4200 }
		$sequence_1 = { c3 83c804 bd01000000 894630 4885d2 753a 480fbf4636 }
		$sequence_2 = { 897c2428 488b5108 488b09 4c89642420 e8???????? 8bd8 83fb01 }
		$sequence_3 = { e9???????? 4c8d249d01000000 4901ec e9???????? 4c8d249d02000000 4901ec e9???????? }
		$sequence_4 = { e9???????? 41bc01000000 eb06 41bc02000000 4901f4 488b6c2410 e9???????? }
		$sequence_5 = { ebe6 4d85e4 488b7c2440 745d 488d05a4e23f00 4889442420 488d4c2468 }
		$sequence_6 = { e8???????? cc 56 57 4881ec000a0000 4889ca 31c0 }
		$sequence_7 = { eb55 c644242001 4889d9 4889fa 4989f0 4c8b4c2430 e8???????? }
		$sequence_8 = { eb23 4c8d05362d4600 eb35 4c8d05152d4600 eb1d 4801dd 4839ee }
		$sequence_9 = { eb46 243f 8bcf c1e90c 0480 81ff00000100 7314 }

	condition:
		7 of them and filesize < 12747776
}
rule MALPEDIA_Win_Rustock_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "9a8b0fe4-50b0-59df-be38-58cf8d212755"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.rustock"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.rustock_auto.yar#L1-L121"
		license_url = "N/A"
		logic_hash = "34f90c25c94dd0e21a7528269430b21667dbe875070ad68127009457b3c8376b"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 0f848b000000 8365fc00 83c003 83e0fc }
		$sequence_1 = { 8b0d???????? 09fe f7d1 b9???????? 29d1 }
		$sequence_2 = { 29c3 051c3367d0 29d8 29cb 83c1ff ebb5 }
		$sequence_3 = { ff15???????? 85c0 7471 8b7de0 8d45b8 50 ff15???????? }
		$sequence_4 = { 7404 802700 47 ff06 8b5d0c }
		$sequence_5 = { da81e53a558c b9157556b8 af 44 42 }
		$sequence_6 = { 8067ff00 8365fc00 803800 0f84d6000000 8a08 80f920 7405 }
		$sequence_7 = { 57 ff15???????? 3bc6 7407 50 ff15???????? }
		$sequence_8 = { 7409 ff75d0 e8???????? 59 395de0 7409 }
		$sequence_9 = { 8d6424fc c70424bc070100 5e 8d6424fc 891c24 5b }

	condition:
		7 of them and filesize < 565248
}
rule MALPEDIA_Win_Hazy_Load_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a350eaad-9bcb-5f5e-81a1-787050135b96"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.hazy_load"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.hazy_load_auto.yar#L1-L116"
		license_url = "N/A"
		logic_hash = "6dd70fa7df72f7c4ea5416ccf00a68d1eab60e78bafa0a38a25801f23d6cb5fb"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 33c0 f04d0fb1bcf130100200 488bd8 740e }
		$sequence_1 = { 488945f0 488d1594c40000 b805000000 894520 894528 }
		$sequence_2 = { f00fc103 83f801 7516 488d05b5330100 488b4c2430 483bc8 7405 }
		$sequence_3 = { 488b442448 4883f8ff 74c8 488bd3 4c8d05ceed0000 83e23f }
		$sequence_4 = { 488d0d12c9ffff 4933f8 4a87bcf150100200 33c0 488b5c2450 488b6c2458 488b742460 }
		$sequence_5 = { 8d41ff 8b8482f89e0100 85c0 0f8489000000 }
		$sequence_6 = { 488d0d5beffeff 48c1e602 0fb784b9609e0100 488d9150950100 }
		$sequence_7 = { 448bc7 4863c3 488d5504 442bc3 }
		$sequence_8 = { 442bc3 4803d0 4533c9 488bce ff15???????? 85c0 0f8eacfeffff }
		$sequence_9 = { eb75 4c8bf3 488d3513be0100 488d2df4bd0100 }

	condition:
		7 of them and filesize < 315392
}
rule MALPEDIA_Win_Akira_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "da65bf5f-e218-5921-beb7-d51a5c1091f4"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.akira"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.akira_auto.yar#L1-L133"
		license_url = "N/A"
		logic_hash = "5ec24d07b0c37b1c6d042a07e49b3802365cb03b91b6abe761d60246817dfba5"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { b990030000 e8???????? 89ac24f8030000 488d8c2410040000 48894c2430 4889742428 48895c2420 }
		$sequence_1 = { 6690 488d42fe 0fb708 6683f95c 740e 6683f92f 7408 }
		$sequence_2 = { 4032f6 4084f6 7409 488bcf ff15???????? 488b5c2440 488b6c2448 }
		$sequence_3 = { 90 66837f0a00 7410 ba90030000 488bcf e8???????? }
		$sequence_4 = { 4889457f 4885db 743c 660f1f840000000000 488d45bf 4889442420 4c8d4d7f }
		$sequence_5 = { 8bd8 83f8ff 756f 48897c2440 ff15???????? 65488b0c2558000000 8bf8 }
		$sequence_6 = { 0f57c0 0f118550020000 0f57c9 660f7f8d60020000 488d458d 4c8bc3 0f1f00 }
		$sequence_7 = { e8???????? 498d4601 803800 4c0f4ff0 410fb60e 80f97f 0f8553ffffff }
		$sequence_8 = { 75b4 eb4e 897567 4889757f 4889756f 8b4740 89442420 }
		$sequence_9 = { 75e8 4983c002 4d3bc3 7429 410fb700 6683f85c 7406 }

	condition:
		7 of them and filesize < 1286144
}
rule MALPEDIA_Win_Beepservice_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "6b417a9f-fd95-5a47-97c0-f469b7fab01f"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.beepservice"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.beepservice_auto.yar#L1-L262"
		license_url = "N/A"
		logic_hash = "a2d8f921056e28fb28290e4aca45f2b2d403b3c54371d19763d373456a4b67e1"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b0d???????? 68???????? ffd6 8bc8 ff15???????? 50 }
		$sequence_1 = { e8???????? 83c408 e9???????? 68???????? e8???????? 83c404 6a00 }
		$sequence_2 = { e8???????? 83f801 7505 e8???????? 68???????? 68???????? }
		$sequence_3 = { 7512 6888130000 68???????? e8???????? }
		$sequence_4 = { 683f000f00 6a00 68???????? ff15???????? }
		$sequence_5 = { ff15???????? 50 68???????? e8???????? 83c408 68f4010000 }
		$sequence_6 = { ff760c ff15???????? 33ff 6a14 57 }
		$sequence_7 = { e8???????? 50 ff7608 68???????? e8???????? 83c444 }
		$sequence_8 = { 57 55 e8???????? 6a28 bb???????? 57 }
		$sequence_9 = { 68???????? e8???????? 59 6a01 58 eb15 }
		$sequence_10 = { 8d442410 6a02 50 55 e8???????? }
		$sequence_11 = { 59 ff7604 e8???????? 83f814 }
		$sequence_12 = { ff15???????? 59 33c0 eb03 6a01 }
		$sequence_13 = { 83e103 f3a4 668915???????? 8b7310 8bfe 83c9ff }
		$sequence_14 = { 8b1d???????? 55 33ed 68f4010000 }
		$sequence_15 = { 740f 837c241804 741e 45 83fd0a }
		$sequence_16 = { 8b450c 8b4818 51 e8???????? 83c404 83f820 7314 }
		$sequence_17 = { 8b4d08 51 8b0d???????? ff15???????? }
		$sequence_18 = { 83c40c 6a20 6a00 68???????? e8???????? 83c40c }
		$sequence_19 = { 6a03 e8???????? 83c414 e9???????? a1???????? 85c0 }
		$sequence_20 = { 668b0d???????? 51 ff15???????? 668bf0 }
		$sequence_21 = { 89442414 8b442434 51 52 }
		$sequence_22 = { c3 6888130000 6a03 6a00 6a00 }
		$sequence_23 = { 6a00 56 57 ff15???????? 8b45e4 85c0 }
		$sequence_24 = { ff15???????? 85c0 a3???????? 7510 ff15???????? 50 e8???????? }
		$sequence_25 = { c744240010000000 89442404 83e802 f7d8 1bc0 83e007 89442408 }
		$sequence_26 = { eb08 c744240c2a040000 8b54242c 8d4c2400 89542414 8b15???????? }

	condition:
		7 of them and filesize < 253952
}
rule MALPEDIA_Win_Vx_Rat_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a3075f85-765c-5b0d-a920-d6e051a97f62"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.vx_rat"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.vx_rat_auto.yar#L1-L125"
		license_url = "N/A"
		logic_hash = "8ad715c145f2f59d408077b55064628099f175154f782f5c3281b40416cc653d"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b4508 8bc8 83e03f c1f906 6bd038 8b0c8d10df4300 }
		$sequence_1 = { 47 83ff05 7c95 68???????? e8???????? 83c404 8b4df4 }
		$sequence_2 = { 68???????? eb05 68???????? 6a32 68???????? e8???????? }
		$sequence_3 = { 7ce8 ebd7 8b45b4 8a0a 884c382e 8b45bc 8b048510df4300 }
		$sequence_4 = { 8b048510df4300 8b4ddc f644082801 7515 e8???????? c70009000000 }
		$sequence_5 = { e8???????? 8b0b 8bc1 83e13f c1f806 6bc938 8b048510df4300 }
		$sequence_6 = { 7515 8b4310 81784840c54300 7409 }
		$sequence_7 = { 8d8d1cffffff e8???????? 68???????? 8bd0 c645fc09 8d8d34ffffff e8???????? }
		$sequence_8 = { ffd6 ffb574f7ffff ffd6 e9???????? }
		$sequence_9 = { e9???????? c745e478064300 e9???????? 894de0 c745e478064300 e9???????? c745e003000000 }

	condition:
		7 of them and filesize < 550912
}
rule MALPEDIA_Win_Outlook_Backdoor_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "79a04fd7-122c-5dda-92fd-6cc5e8d2af6b"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.outlook_backdoor"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.outlook_backdoor_auto.yar#L1-L128"
		license_url = "N/A"
		logic_hash = "090e386abf9ec7d615e9e49e2da38202ae3f58cc13693185362f71bcba54d173"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b4d0c 832100 57 8d3c06 8975f8 3bf7 }
		$sequence_1 = { e8???????? 51 51 56 57 33ff 57 }
		$sequence_2 = { 7d04 b12d eb07 8a4e08 eb02 32c9 }
		$sequence_3 = { e8???????? 8b4308 8bc8 2b4b04 740e 8b5b04 }
		$sequence_4 = { 8d45fc 50 ff36 ffd3 6a01 6a00 }
		$sequence_5 = { ff45fc 807e1000 7422 837dfc4c 7c1c }
		$sequence_6 = { 8d45f4 ff30 53 52 e8???????? 83c40c 85c0 }
		$sequence_7 = { 0f84f5000000 837c244410 8b7c2430 7304 8d7c2430 8b5c240c 8b442410 }
		$sequence_8 = { 0f824cffffff 8bc7 2b45f8 5f 5e c9 c20800 }
		$sequence_9 = { c645ec32 c645ed26 c645ee09 c645ef0f c645f03a c645f13b c645f230 }

	condition:
		7 of them and filesize < 2912256
}
rule MALPEDIA_Win_Zebrocy_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "5b5b0241-42ef-59f6-805b-3177b3f03378"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.zebrocy"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.zebrocy_auto.yar#L1-L157"
		license_url = "N/A"
		logic_hash = "f1036f0f027769b11fb1846c7b186cf9c34c3472f30744cf00e209f2a861d490"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 014158 11515c e8???????? dc6360 }
		$sequence_1 = { 8b4a04 8b55ec 03cb 85d2 7420 8b410c }
		$sequence_2 = { 8bf3 e8???????? c645fc00 837dd410 720c 8b4dc0 51 }
		$sequence_3 = { 8bf3 c745fc01000000 e8???????? 837db010 0f8291020000 8b459c }
		$sequence_4 = { 66891478 8bc6 5f c3 8bff }
		$sequence_5 = { 0110 8b7dd4 ba???????? 89470c }
		$sequence_6 = { 0103 31d2 85ff 8b03 }
		$sequence_7 = { 0103 8b0e ba???????? e8???????? }
		$sequence_8 = { 897e10 897e14 837dd410 720c }
		$sequence_9 = { 0102 8b45d4 89500c 89c1 }
		$sequence_10 = { 8d8508f7ffff 8a1c38 8db598f6ffff e8???????? }
		$sequence_11 = { 014150 8b550c 115154 014158 }
		$sequence_12 = { 83e71f c1e706 8b0485c0a84200 8d44380c 50 ff15???????? 8b45e4 }
		$sequence_13 = { 0103 83c41c 5b 5e }
		$sequence_14 = { 8b55ec 33ff 897c1820 897c1824 }
		$sequence_15 = { 0110 5e 5f 5d }

	condition:
		7 of them and filesize < 393216
}
rule MALPEDIA_Win_Reedbed_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "0c798121-3909-5e78-9fb9-7f8283704712"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.reedbed"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.reedbed_auto.yar#L1-L141"
		license_url = "N/A"
		logic_hash = "7449bc7e27691c5bd3a322b3e8a0b595cc3d4d3d58e54aa8c495acb5d2eaea18"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 33c9 e8???????? 488b0d???????? 488981c2140000 }
		$sequence_1 = { 33c9 ff15???????? 85c0 751e }
		$sequence_2 = { 453b03 7519 41833b40 7313 }
		$sequence_3 = { eb55 8b9d90020000 4c8d8d90020000 895e26 4533c0 66897e2a }
		$sequence_4 = { 4885c0 75e9 8d4f01 4803c9 e8???????? 488bf8 }
		$sequence_5 = { 40f6c520 7412 418a01 4181482104020000 }
		$sequence_6 = { 4885c0 7425 c60000 488d742440 eb13 }
		$sequence_7 = { 4181ba9814000000000200 7347 4533c0 443b06 7316 418b490e }
		$sequence_8 = { 89442450 488b442428 0fb700 488d0d10da0500 }
		$sequence_9 = { 8944244c 837c244c0f 0f875e010000 8b44244c 488d0d1ba4eaff }
		$sequence_10 = { 8944244c 837c244c00 753a 488d05dc8e0400 }
		$sequence_11 = { 89442454 837c245400 753a 488d05341c0500 }
		$sequence_12 = { 89442450 817c245000ca9a3b 723a 488d0514070600 }
		$sequence_13 = { 89442450 837c245000 753a 488d053d0e0500 }

	condition:
		7 of them and filesize < 3760128
}
rule MALPEDIA_Win_Maktub_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f2896108-9666-5673-9f8f-a5430d5a4720"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.maktub"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.maktub_auto.yar#L1-L205"
		license_url = "N/A"
		logic_hash = "3a9fbb3201b804ea6908a5af3c2bfecbc4e63349614e19344d3cf9929df9c1be"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ffd0 f7d8 1bc0 f7d8 8be5 }
		$sequence_1 = { ff15???????? eb02 33db 8b4df4 }
		$sequence_2 = { ff15???????? eb0a 57 6a08 }
		$sequence_3 = { ff15???????? f6c301 0f8414010000 8d46fc }
		$sequence_4 = { ff15???????? ff75f8 ff15???????? 5f 5e b801000000 }
		$sequence_5 = { ff15???????? eb02 33c0 46 03f0 3b75e0 }
		$sequence_6 = { ff15???????? f6c301 7432 8b75b8 }
		$sequence_7 = { ff7508 ffd7 50 ffd6 53 }
		$sequence_8 = { ff30 e8???????? 8bc7 5f 5e 5b }
		$sequence_9 = { 8d55e4 8d4dc4 e8???????? 8bc8 }
		$sequence_10 = { 8d55e4 8d4dec e8???????? 8bce e8???????? 8b4df4 }
		$sequence_11 = { 8d4383 d1f1 10149d891be6fc ae }
		$sequence_12 = { 8d55dc 8d8d5cffffff e8???????? 8bd0 }
		$sequence_13 = { 8d433f e4f2 90 2ab432f35979e3 }
		$sequence_14 = { 8d4310 50 e8???????? 8b7d10 }
		$sequence_15 = { 8d55e8 8bc8 e8???????? 8b4dfc }
		$sequence_16 = { 8d4320 57 50 e8???????? 83c40c c786f800000001000000 }
		$sequence_17 = { 8d55e0 8d4d9c e8???????? 8bd0 8d4dcc e8???????? }
		$sequence_18 = { 8d4320 50 ff7360 51 ff74242c }
		$sequence_19 = { 8d55e4 8bc8 e8???????? 8b4df4 }
		$sequence_20 = { 8d55ac 8d4d9c e8???????? 8bd0 8d8d74ffffff e8???????? }
		$sequence_21 = { 8d43eb 83f804 0f8732030000 ff24850cd94300 }

	condition:
		7 of them and filesize < 3063808
}
rule MALPEDIA_Win_Feodo_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "1c2826e3-aa28-5bff-9c0c-1243b513e9c2"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.feodo"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.feodo_auto.yar#L1-L124"
		license_url = "N/A"
		logic_hash = "b073e2199e76d55ab7377600e114dec126452f8e3f4fe8ce24d7d8d5a6d3fdbc"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 83fa09 7704 8bca eb10 8d519f 83fa05 7717 }
		$sequence_1 = { 6a00 6a02 6a04 68???????? }
		$sequence_2 = { 0fafc7 83c601 03c1 0fbe0e 85c9 }
		$sequence_3 = { ff15???????? 8bf0 85f6 7507 53 ff15???????? 81c3f4010000 }
		$sequence_4 = { 52 6a00 50 ff15???????? 8b0c24 }
		$sequence_5 = { 6a00 68???????? 56 ff15???????? f7d8 1bc0 f7d8 }
		$sequence_6 = { 6a00 50 ff15???????? 8b0c24 51 ff15???????? }
		$sequence_7 = { 6a06 6a01 6a02 ff15???????? 8bf0 83feff 741b }
		$sequence_8 = { 7436 3d00010000 752f be04000000 eb28 3d00030000 }
		$sequence_9 = { 83e800 7440 83e801 7422 83e801 7404 }

	condition:
		7 of them and filesize < 270336
}
rule MALPEDIA_Win_Tapaoux_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "c4aa9ee9-13a0-5e6d-a6ee-9666b285ff5a"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.tapaoux"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.tapaoux_auto.yar#L1-L128"
		license_url = "N/A"
		logic_hash = "67674707448ad7ea16a74f0cce459fc02e903817beb84a76d57ccf6ea78bff31"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8945d0 0f879a060000 ff24850e580010 834df0ff 8955cc 8955d8 8955e0 }
		$sequence_1 = { f3ab aa 8d44240c 8d8c2418080000 50 51 c744241400040000 }
		$sequence_2 = { 2bc8 83c0fd 50 8d2c39 8d8c2494000000 }
		$sequence_3 = { 8d9424d0020000 51 50 52 57 e8???????? }
		$sequence_4 = { 83c40c 85c0 0f8c4fffffff 8b942418010000 5f 8902 }
		$sequence_5 = { 81ec1c020000 53 56 8bb42428020000 57 85f6 0f8410010000 }
		$sequence_6 = { 8d7c2411 f3ab 8b8c2414010000 66ab 3bcb aa 750e }
		$sequence_7 = { 894c2418 83c9ff f2ae f7d1 49 55 }
		$sequence_8 = { 8d34bd50bb0110 7529 55 bd???????? 55 ffd3 }
		$sequence_9 = { 85c0 0f84c6000000 be???????? 8d442410 8a10 8aca 3a16 }

	condition:
		7 of them and filesize < 292864
}
rule MALPEDIA_Win_Kimsuky_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "fbd21594-24b3-55bd-a51c-b1a6382b7d00"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.kimsuky"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.kimsuky_auto.yar#L1-L290"
		license_url = "N/A"
		logic_hash = "a29058b10440281d2800e78994f8943bcc00e56769aa5c9ddf21e31df2a04ba3"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 83c430 8d95f0fcffff b9???????? e8???????? }
		$sequence_1 = { ffd6 8bd8 85db 7510 }
		$sequence_2 = { 53 e8???????? 83c404 8bf0 6a00 }
		$sequence_3 = { 8d85f8feffff 6a00 50 ff15???????? 8d85ecfbffff 50 }
		$sequence_4 = { ff15???????? 85c0 7516 ff15???????? 8bd8 e8???????? }
		$sequence_5 = { 8bca 83e103 f3a4 8d8de4fbffff 49 }
		$sequence_6 = { 8945fc 833d????????00 7413 b801000000 8b4dfc }
		$sequence_7 = { 7423 6a00 8d85f0feffff 50 68???????? ff15???????? }
		$sequence_8 = { 8d8de8fdffff e8???????? 8b4dfc 33cd e8???????? }
		$sequence_9 = { 4d03fa 664403df 4983c004 4983c102 664585db 75af 4c897c2468 }
		$sequence_10 = { 4883c514 85c0 0f857affffff 4c8b7c2460 4c8b6c2420 4c8b642428 }
		$sequence_11 = { 48897c2430 48896c2460 488b4818 41bb01000000 4c8b7120 }
		$sequence_12 = { 0f8569ffffff 418b5f28 4533c0 33d2 4883c9ff 4903de ff542468 }
		$sequence_13 = { 4c8b642428 488b7c2430 488b742438 488b6c2470 4d8bc6 4d2b4730 4183bfb400000000 }
		$sequence_14 = { 4d03d9 666666660f1f840000000000 418b0a 4903c9 4533c0 }
		$sequence_15 = { 4d85f6 0f8540feffff 488b6c2460 4c637d3c }
		$sequence_16 = { 8b442468 6683f809 7508 83f809 }
		$sequence_17 = { 8bd7 3bd8 0f94c2 85d2 7419 }
		$sequence_18 = { 894d90 8bc1 81fb00000001 0f97c0 }
		$sequence_19 = { 85c0 0f94c1 85c9 0f8494020000 89bda0000000 897d30 }
		$sequence_20 = { 83f809 8d7340 7405 be20000000 c68424a000000000 33d2 }
		$sequence_21 = { 488d8a38000000 e9???????? 488d8a28010000 e9???????? }
		$sequence_22 = { 8b7590 660f1f440000 837df000 0f841b020000 }
		$sequence_23 = { 898521010000 66898525010000 888527010000 8b742450 }
		$sequence_24 = { 4c89642430 c744242880000000 c744242002000000 4533c9 4533c0 }
		$sequence_25 = { 48c1e105 4c03c1 488d542470 488d4dc0 }
		$sequence_26 = { 48bfffffffffffffff7f 483bf7 0f87ea000000 488bce 4c89742468 }
		$sequence_27 = { 48c1e105 4c03c1 488d542438 488d8dc0000000 }
		$sequence_28 = { 48c1e302 4c8bc3 8d040e 488d8d94080000 898590080000 e8???????? 488d0df984fcff }
		$sequence_29 = { 48c1e302 4c8bc3 8d040e 488d8d24030000 898520030000 e8???????? 488d0d3354fbff }
		$sequence_30 = { 48b9ffffffffffffff7f 488bc1 492bc6 4883f814 0f82520d0000 4c8d7d48 }

	condition:
		7 of them and filesize < 1021952
}
rule MALPEDIA_Win_Bottomloader_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "46f34a43-3db5-5ef1-9958-b6c9596ba25b"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.bottomloader"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.bottomloader_auto.yar#L1-L132"
		license_url = "N/A"
		logic_hash = "b0d59c0f9fc58fd278ab5fcc06a80a7243ece9019c1e96be659c478b7b007c4d"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 488b5708 488b07 48898500ffffff 48899508ffffff 4c8d8d00ffffff 448b4520 498b542408 }
		$sequence_1 = { 4c8b8d58fcffff 450fbe2431 488d0d6e3b0800 4883ec20 e8???????? 4883c420 4989c6 }
		$sequence_2 = { 4883ec30 498bf9 8b0a e8???????? 90 488d1dfa5b0400 488d35bb140200 }
		$sequence_3 = { 488b02 488b5208 488945e0 488955e8 4c8d4de0 4c8b4520 488d0d06500a00 }
		$sequence_4 = { 4989f8 ba47050000 488d0de8710800 e8???????? 488bc6 482bc7 488945f0 }
		$sequence_5 = { 488d056a1e0400 488945d8 48c745d00f000000 488d55d0 b903000000 }
		$sequence_6 = { 488985f0feffff 488995f8feffff 488d8df0feffff 488b9570feffff 4883ec20 e8???????? 4883c420 }
		$sequence_7 = { 654c8b142558000000 4f8b24ca bac00a0000 498b3c14 4c8b8788000000 4983c008 4c8945e0 }
		$sequence_8 = { 4531c9 4d89c8 ba9f090000 488d0d4a190b00 e8???????? 4c8b9508ffffff 410fb632 }
		$sequence_9 = { 48894590 41b901000000 4531c0 bafe060000 488d0d10e80500 e8???????? 488b5e08 }

	condition:
		7 of them and filesize < 1955840
}
rule MALPEDIA_Win_Anchormtea_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "e6f364b0-529f-5483-91b7-b96ac416b43a"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.anchormtea"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.anchormtea_auto.yar#L1-L154"
		license_url = "N/A"
		logic_hash = "0e8392362e39e1f8b65105a47aebb3cfad623bade23b8e6d116c099dfd8c8173"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e9???????? f7d8 1bc0 83e002 }
		$sequence_1 = { 4c8bc3 488bd7 488908 488bc8 }
		$sequence_2 = { c745ec68006f00 c745f061006d00 c745f469002e00 668945f8 668b01 83c102 }
		$sequence_3 = { 6bc938 8b048540a20210 f644082801 7406 8b440818 5d }
		$sequence_4 = { 0fb63485df210210 8bf9 8985b0f8ffff c1e702 57 8d0431 }
		$sequence_5 = { 488d15ed1a0200 488d4c2420 ff15???????? 488d542420 48c7c100000080 ff15???????? }
		$sequence_6 = { 8bc6 c1e81f 8d0448 8b0c852c510210 8d45f8 50 }
		$sequence_7 = { ff75c4 51 8bce e8???????? 8bcb 8d5102 }
		$sequence_8 = { 0f85c0150000 8d0d40430210 ba1b000000 e8???????? }
		$sequence_9 = { 0f84db040000 ff33 ff15???????? 85c0 0f84cb040000 }
		$sequence_10 = { e8???????? 4c8d05b0970200 ba00040000 488d4c2440 }
		$sequence_11 = { 7419 33d2 41b804010000 498bce e8???????? }
		$sequence_12 = { 4898 4803c0 418b84c7605f0200 eb02 }
		$sequence_13 = { 89442420 ff15???????? 488b4c2478 ff15???????? }
		$sequence_14 = { ff15???????? 4c8be0 4889442460 4885c0 740e }

	condition:
		7 of them and filesize < 839680
}
rule MALPEDIA_Win_Lucidpawn_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a4686d3d-9b50-56d9-8719-2e7e5e04b6b2"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.lucidpawn"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.lucidpawn_auto.yar#L1-L90"
		license_url = "N/A"
		logic_hash = "1bfe797dae2564d386f3a8f078d522ca6f0812fbbf535d1cbf58085a023a7849"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 00c9 0fb6c9 84c0 0f45ca }
		$sequence_1 = { 00c0 89c7 eb64 488b4e20 }
		$sequence_2 = { 01c2 488b3e 488b5e08 4189d7 }
		$sequence_3 = { 01c0 428944b414 4d89e6 488d2dc7c30e00 }
		$sequence_4 = { 00c0 fec0 88842490000000 4c898c2498000000 }
		$sequence_5 = { 01c1 49ffc7 89cf ebb6 }
		$sequence_6 = { 01542440 40b70f e9???????? 48c7c2ffffffff }
		$sequence_7 = { 0154243c 40b716 e9???????? 48c7c2ffffffff }

	condition:
		7 of them and filesize < 2131968
}
rule MALPEDIA_Win_Echo_Gather_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "3be3f023-8faa-5f1d-9380-1729c1c89462"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.echo_gather"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.echo_gather_auto.yar#L1-L128"
		license_url = "N/A"
		logic_hash = "f3bd866a440e368a1d5e5076b350bdb7b4f0614ef9e34fbb97a66b3dae9d2fed"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 4889c1 488b4510 4989d8 4889c2 e8???????? 8945ec }
		$sequence_1 = { 89442454 e9???????? 8b842498000000 4489742468 89442448 e9???????? 660fefc9 }
		$sequence_2 = { 488b8424c8050000 4889c1 488b05???????? ffd0 4883bc24d005000000 }
		$sequence_3 = { 48894d10 48895518 4c894520 488d05372c0000 4889442420 488d05322c0000 4889442428 }
		$sequence_4 = { 8b4e08 8b462c 4889f2 894610 89c8 83e120 0dc0010000 }
		$sequence_5 = { 488945d0 48837dd000 750e 488b45e0 4889c1 e8???????? }
		$sequence_6 = { 4889ef 4183c001 4c89ed 458802 e9???????? 448b4c2448 }
		$sequence_7 = { 4881faffffff7f 7744 4c8d942490000000 4c894c2420 4989c1 4c89542448 }
		$sequence_8 = { 4885db 0f84e1fdffff e9???????? 4c09c6 41bc57000780 0f850cfeffff 4d85c9 }
		$sequence_9 = { e8???????? 488b542430 4889c1 4889c6 e8???????? 4c8b4c2430 448b442438 }

	condition:
		7 of them and filesize < 246784
}
rule MALPEDIA_Win_Fuwuqidrama_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "b6e98477-1a65-52bc-a03e-5c8491a64101"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.fuwuqidrama"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.fuwuqidrama_auto.yar#L1-L129"
		license_url = "N/A"
		logic_hash = "1a41a872e30f222b40a433029a09689fd76a34b031a9f95479c376419d4d8835"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 899e00040000 899ef8030000 899ef0030000 899ee8030000 899ee0030000 899ed8030000 }
		$sequence_1 = { 8db594020000 89442430 8d542430 8d442420 8d7e0c 52 50 }
		$sequence_2 = { 8b4e0c 2bcd 57 f7e9 c1fa06 8bc2 }
		$sequence_3 = { 75da 8b4604 50 89442420 e8???????? 8b442424 }
		$sequence_4 = { 03d0 3bd5 0f8351010000 8b7704 85f6 741b 8bcb }
		$sequence_5 = { 8b8bcc030000 8b93c8030000 8bc1 3bc1 741e }
		$sequence_6 = { 744f 8b4c2410 6a00 56 8b11 ff5220 55 }
		$sequence_7 = { 896b1c 8b98c0000000 0bf1 895c241c 8b5c2424 23f3 8b5c2414 }
		$sequence_8 = { 8d543818 898f04140000 899708140000 ffd3 8b5654 55 89971c140000 }
		$sequence_9 = { 8bce 8bd0 8b01 3bc5 7406 8b00 3bc5 }

	condition:
		7 of them and filesize < 245760
}
rule MALPEDIA_Win_Backconfig_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "18fd149c-ad9b-5433-8651-ac1dcd92de05"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.backconfig"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.backconfig_auto.yar#L1-L127"
		license_url = "N/A"
		logic_hash = "dc29e43fa81d60d5f53e6f4d5e158937c417e8f12650929b20d71338a8cb5ead"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { a1???????? 8b0d???????? 8b15???????? 8985f0feffff a1???????? 6a51 8985fcfeffff }
		$sequence_1 = { e8???????? 8b4de4 83c40c 6bc930 8975e0 8db1682a4100 }
		$sequence_2 = { 8a15???????? 8d8569ffffff 6a00 50 898d64ffffff 889568ffffff }
		$sequence_3 = { c1f805 8d1485c0504100 8b0a 83e61f c1e606 03ce }
		$sequence_4 = { 8bc3 c1f805 8d3c85c0504100 8bf3 83e61f c1e606 8b07 }
		$sequence_5 = { 8b0d???????? 8b15???????? 8985f0feffff a1???????? 6a51 8985fcfeffff 898df4feffff }
		$sequence_6 = { 8d8d2cfdffff 68???????? 51 e8???????? 83c414 68401f0000 }
		$sequence_7 = { 6a00 50 898d64ffffff 889568ffffff e8???????? }
		$sequence_8 = { 8bf1 83e61f 8d3c85c0504100 8b07 c1e606 f644300401 7436 }
		$sequence_9 = { 8bec 8b4508 56 8d34c550224100 833e00 7513 }

	condition:
		7 of them and filesize < 217088
}
rule MALPEDIA_Win_Sality_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "d0b3eea9-823e-59a4-b774-6c73640d5f00"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.sality"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.sality_auto.yar#L1-L236"
		license_url = "N/A"
		logic_hash = "9c5e2942f44eabc3c40d8bfc443effbbaf5f507fa6d9dbd1f910545773937fc4"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 52 68ff011f00 8d45f4 50 }
		$sequence_1 = { 0f8411010000 8b55dc 33c0 668b4212 }
		$sequence_2 = { 7207 b801040000 eb54 8b55fc 2b55f4 8b450c 8910 }
		$sequence_3 = { 52 68a3000000 e8???????? 83c414 8b4dfc 03c8 894dfc }
		$sequence_4 = { 721b 817d08d5000000 7712 8b4510 0345fc c6000f 8b4dfc }
		$sequence_5 = { 0f8410010000 e8???????? 25ffff0000 99 b967000000 f7f9 }
		$sequence_6 = { 0f8410020000 c785ccfdffff28010000 b949000000 33c0 }
		$sequence_7 = { 833c8a00 7402 eb10 8b450c 8b4d0c 83e901 }
		$sequence_8 = { 64ff30 8d8586134000 8920 896804 8d9dba114000 895808 }
		$sequence_9 = { b996000000 32c0 f2ae 8bcf 2b4c2410 8b5678 0354240c }
		$sequence_10 = { bb04000000 8bc1 f7e3 0344240c }
		$sequence_11 = { 0354240c 8b5a20 035c240c 33c0 8b3b }
		$sequence_12 = { 50 ff95bc154000 85c0 7403 eb0c 58 }
		$sequence_13 = { 8bc8 48 c6857b27400000 8d8527164000 6a00 6a00 50 }
		$sequence_14 = { 6a00 ff9585144000 50 ff95e7144000 85c0 }
		$sequence_15 = { 0f858c000000 03763c 813e50450000 0f857d000000 8b7c2410 b996000000 32c0 }
		$sequence_16 = { 833c85ebc3400000 7519 0fbec3 ff3485e3c34000 e8???????? }
		$sequence_17 = { 750f 8b4508 8b14857d504100 e9???????? }
		$sequence_18 = { 49 7432 8bd1 8b7c2414 8bdf 83c9ff }
		$sequence_19 = { 888831004100 46 ebd5 8935???????? }
		$sequence_20 = { 03f2 8bfe 83c604 fc }
		$sequence_21 = { ff30 e8???????? eb22 40 }
		$sequence_22 = { c1c004 50 240f 0430 3c39 }
		$sequence_23 = { 3c0d 741f 3c0e 7431 b002 83c410 }

	condition:
		7 of them and filesize < 1523712
}
rule MALPEDIA_Win_Matanbuchus_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "6535cac4-0b82-5f0b-af5b-c3b10601dcda"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.matanbuchus"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.matanbuchus_auto.yar#L1-L122"
		license_url = "N/A"
		logic_hash = "b3be1f5045332e76ddfb93fb228179b4e37ad6a7ac20b46399a52e966a0fcddf"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b4508 8b483c 034d08 894dec }
		$sequence_1 = { e9???????? 8b45ec 0fb74814 83f960 7c09 }
		$sequence_2 = { 85d2 7502 ebb4 0fb745fc 83f803 7523 0fb74df8 }
		$sequence_3 = { 03481c 894dcc c745f000000000 eb09 8b55f0 }
		$sequence_4 = { 33c0 e9???????? b808000000 6bc800 8b55ec 8b440a78 }
		$sequence_5 = { 8b1481 035508 8955ec 0fb745fc 8b4dd8 668b1441 668955f8 }
		$sequence_6 = { 8b4224 034508 8945d8 8b4df0 8b511c 035508 }
		$sequence_7 = { 49 81c900f0ffff 41 66894df8 0fb755fc 85d2 }
		$sequence_8 = { 8b4508 8b483c 034d08 894dec 8b55ec 8b4234 8945e8 }
		$sequence_9 = { 760b 8b45f0 8b4818 894de8 eb09 }

	condition:
		7 of them and filesize < 13077504
}
rule MALPEDIA_Win_Bleachgap_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f98646f8-22ce-5c49-90d5-53eaf546d3de"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.bleachgap"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.bleachgap_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "b3eefc9d3887de0aa87c80688ff547f0443e7c3b0f87814a16239814ea4facf5"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 83c40c 85c0 0f8431020000 837e2000 8bbe74040000 8daf4c010000 }
		$sequence_1 = { c685affeffff27 c685b0feffff2e c685b1feffff2a c685b2feffff3b c685b3feffff3a c685b4feffff7f c685b5feffff7f }
		$sequence_2 = { 8b407c 8b8860020000 ebd7 8b742410 83be7404000000 0f84e7f9ffff 8b467c }
		$sequence_3 = { 8b4d0c 74c6 8b45f8 807f0d00 7407 8b30 83c604 }
		$sequence_4 = { 8b4c2440 3bce 0f8cbd050000 8d046d02000000 3bc8 0f8cae050000 2bcd }
		$sequence_5 = { 238798000000 33c8 894d18 8b8f9c000000 8b451c 23ce 57 }
		$sequence_6 = { 8bd6 03d1 33c0 89542414 8bfe 2bd6 7411 }
		$sequence_7 = { 5e c3 68b6040000 68???????? 6a44 686b020000 6a50 }
		$sequence_8 = { e8???????? 8b6c2428 83c410 894500 85c0 0f8411010000 8b4604 }
		$sequence_9 = { c645fc02 8b8d68ffffff 83f910 722f 8b9554ffffff 41 8bc2 }

	condition:
		7 of them and filesize < 4538368
}
rule MALPEDIA_Win_Linseningsvr_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "68c65b63-e40e-59ed-9f87-895cfc0dec94"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.linseningsvr"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.linseningsvr_auto.yar#L1-L117"
		license_url = "N/A"
		logic_hash = "e8f369f7ec61592e2a3b3fecf4bc420063f67a74461c185ad8f3d77705dffe45"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 33c0 8dbc24dd090000 c644241000 f3ab 66ab aa }
		$sequence_1 = { 8d542464 6a01 52 89442464 894c2468 e8???????? }
		$sequence_2 = { 8dbc24dd090000 c644241000 f3ab 66ab }
		$sequence_3 = { 8b0485c08d4000 03c6 8a5004 f6c201 }
		$sequence_4 = { e8???????? 57 e8???????? 83c418 8d44244c }
		$sequence_5 = { 742e 85f6 7419 0fb6da f683818c400004 }
		$sequence_6 = { c705????????01000000 50 a3???????? e8???????? 8db6bc884000 }
		$sequence_7 = { e8???????? 83c40c c3 53 56 be???????? 57 }
		$sequence_8 = { 8a4c3c4c 51 68???????? e8???????? 83c408 }
		$sequence_9 = { e8???????? 83c404 ebc2 8b0d???????? 68???????? 51 }

	condition:
		7 of them and filesize < 81360
}
rule MALPEDIA_Win_Moonwalk_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "517b48e1-487c-570f-9804-31dddd3e8bc7"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.moonwalk"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.moonwalk_auto.yar#L1-L133"
		license_url = "N/A"
		logic_hash = "6f0d957a41e3d0a2c7779768e0ca5881d8b28920bf878ea40e3b93a95ecb44f6"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c1e808 c1ee08 45338c8c00020100 0fb6c8 410fb6c0 45338c8c00fa0000 45338c84301e0100 }
		$sequence_1 = { 49f7f0 488955d8 420fb6040a 33d2 304317 b818000000 49f7f0 }
		$sequence_2 = { 8bc3 e9???????? 418bd9 8bc3 e9???????? 4c8b6c2438 33f6 }
		$sequence_3 = { 4903fe 0fb62b 48ffc3 8bf5 448bf5 48c1ee04 }
		$sequence_4 = { 884706 418bc7 c1e810 0fb6c8 418bc6 48c1e818 418b948d00060100 }
		$sequence_5 = { 4889b42420010000 488d742430 490f45f0 4889bc2428010000 0f11442430 4c89a424f0000000 41bc20000000 }
		$sequence_6 = { e8???????? 488bf0 4885c0 0f849b000000 488b0d???????? 4533c9 48895c2450 }
		$sequence_7 = { 41884101 8bc3 c1f810 41884102 8bc1 c1f808 41884104 }
		$sequence_8 = { 48ffc1 4133c0 4469c093010001 483bca 72eb 4e8d0c36 bac59d1c81 }
		$sequence_9 = { c1e918 884354 884b53 8b4b04 8bc1 c1e808 884355 }

	condition:
		7 of them and filesize < 179200
}
rule MALPEDIA_Win_Broler_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "0b15f3bf-2d24-50a2-a777-97dab9158dc4"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.broler"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.broler_auto.yar#L1-L123"
		license_url = "N/A"
		logic_hash = "a90c91f8f3ec6f4797ea0e3747acb90b924531ab30fdd5bdd87afba9b05dc0c0"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 33db e8???????? 8d8d78dffcff e8???????? 83c41c c645fc02 83bd8cdffcff10 }
		$sequence_1 = { 40 3acb 75f1 6a11 8d4dc8 51 }
		$sequence_2 = { 68???????? 8d4df0 51 c745f05c324100 e8???????? 8be5 }
		$sequence_3 = { 50 8d8dacfeffff 51 895dfc }
		$sequence_4 = { 899d0cdffcff c78504dffcff04000000 395d18 7553 }
		$sequence_5 = { 8945f0 8d04c2 894c8608 8b86d0030000 2b45f0 8d0cc2 8b4508 }
		$sequence_6 = { 8b8d48ffffff 33ff 3bcf 7564 }
		$sequence_7 = { 51 53 57 8bc6 e8???????? 8bc3 c745940f000000 }
		$sequence_8 = { 33c0 40 e9???????? 8365d800 c745dc0d094100 a1???????? 8d4dd8 }
		$sequence_9 = { ffd7 8d8d70fdffff 51 ff15???????? 83f8ff 7415 a802 }

	condition:
		7 of them and filesize < 275456
}
rule MALPEDIA_Win_Boryptgrab_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "51fa6c19-18b8-52eb-ad6e-427bf60738be"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.boryptgrab"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.boryptgrab_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "3bcbd8f5c2623d9bffd720fb19b68816d9903466f0f9355b26b89d1401cf6f20"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 90 488d8df8010000 e8???????? 90 488d8d50030000 e8???????? 90 }
		$sequence_1 = { eb0a b905000000 cd29 488bc8 e8???????? 48895c2478 4c896d80 }
		$sequence_2 = { e8???????? 48897b78 e9???????? 4863c5 486bf038 8b4320 89443e18 }
		$sequence_3 = { eb67 408ab598000000 41bb01000000 453bd1 7d10 488b442468 4963ca }
		$sequence_4 = { ba80000000 488bce e8???????? 41807f1900 74bc 498b0e ba80000000 }
		$sequence_5 = { e8???????? 488b4b18 488bd3 e8???????? 488bce e8???????? 8bc7 }
		$sequence_6 = { 90 488d4d48 e8???????? 90 488d4de8 e8???????? 90 }
		$sequence_7 = { e8???????? 8b7c2444 41b903000000 448b442468 488bcd 897c2420 418d515e }
		$sequence_8 = { 755e 41b848510000 498bd5 488d0d5b2d0e00 e8???????? 8a55e0 80fa03 }
		$sequence_9 = { e8???????? c6474100 85f6 750a 4439ac24a0000000 7503 448bf6 }

	condition:
		7 of them and filesize < 5648384
}
rule MALPEDIA_Win_Unidentified_092_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "42bc5e0c-88fc-5588-9b9a-a3b0af61780c"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.unidentified_092"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.unidentified_092_auto.yar#L1-L126"
		license_url = "N/A"
		logic_hash = "005f523ddaddfe8eb4f47c402b8619c772450cb5e5909dee547618689cbd7022"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 33c0 3b0cc5509d0210 7427 40 83f82d 72f1 }
		$sequence_1 = { 57 50 8d45f4 64a300000000 6a00 68???????? ff15???????? }
		$sequence_2 = { 83c410 ebe6 8b45e4 8b0c85b0660310 8b45e8 f644012880 }
		$sequence_3 = { 2bfb 2bc2 d1ff 57 53 51 d1f8 }
		$sequence_4 = { 8bb598f5ffff e9???????? 8d8de4f5ffff e8???????? 68e0930400 ff15???????? 57 }
		$sequence_5 = { 015508 8bd7 c1c107 f7d2 2355f4 c1ce0b 33f1 }
		$sequence_6 = { 8b86b0660310 85c0 740e 50 }
		$sequence_7 = { 23c8 8b45fc 0bc1 03c2 8945fc 8b45d8 }
		$sequence_8 = { 33d1 8bc8 0b4de4 03d6 234df8 8bf7 894df4 }
		$sequence_9 = { 68???????? 66894598 ff15???????? 8945a0 85c0 }

	condition:
		7 of them and filesize < 10202112
}
rule MALPEDIA_Win_Venon_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "434ace3b-0ca7-5495-b288-0a7f1630327e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.venon"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.venon_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "52d7eb816e86305ae653454e8a4a7ee8947d3bcd03eb622218f0ced8f6a974e8"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { f30f100d???????? f30fc2c801 f30f2cd0 f30fc205????????01 0f54c1 660f7ec0 4883c428 }
		$sequence_1 = { fe0406 4d89e8 4929c8 0f8242010000 4801f1 b230 e8???????? }
		$sequence_2 = { ffc5 71da 488d0dbd133100 e8???????? 83f82e 7442 83f845 }
		$sequence_3 = { ebe2 c685d703000000 e8???????? 4885c0 0f84af010000 4883a55001000000 488d15e0e67000 }
		$sequence_4 = { f30f113c10 0fb7ce 488b8328400000 66412bcc 664103cb 6641890c00 4103f3 }
		$sequence_5 = { eb17 488b06 488b08 41b801000000 4c89f2 e8???????? 4889c1 }
		$sequence_6 = { e8???????? eb8c 498b4608 4889453f 410f1046f9 0f294530 488d4537 }
		$sequence_7 = { f2440f2cf5 440f4af0 f20f5ec4 f20f2ae3 f20f59e0 660f2ee4 f20f5fe2 }
		$sequence_8 = { ffc7 0f28f8 f20f58fe 83ff07 7c96 ffc3 83fb07 }
		$sequence_9 = { ff5008 488b442450 8b4c2420 89885c010000 488b442438 488b4c2428 488908 }

	condition:
		7 of them and filesize < 19539968
}
rule MALPEDIA_Win_Comlook_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "05ed2bab-55d2-57dc-8e46-f55cccf4c811"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.comlook"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.comlook_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "b5af4cb7d4e037ddd3491c605b55fe5a2eb2417d86668da4967caa736c6b60b8"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { eb05 e9???????? 8b45ec 5f 83c438 3bec e8???????? }
		$sequence_1 = { ff15???????? 83c404 3bf4 e8???????? 8b4508 c7400800000000 33c9 }
		$sequence_2 = { e9???????? 6865070000 68???????? 6a41 688d000000 6a14 e8???????? }
		$sequence_3 = { 85c0 7416 8b55f8 8b4204 8b4d0c 0fbe1408 85d2 }
		$sequence_4 = { b80c000000 66894154 b001 c3 3c6e 750c ba0a000000 }
		$sequence_5 = { e8???????? c645fc01 8b7d08 e8???????? 8b4e04 8bc7 894804 }
		$sequence_6 = { ebd4 837df400 7513 6a00 6a00 8b45fc 83c014 }
		$sequence_7 = { e9???????? 8bf4 6801400000 ff15???????? 83c404 3bf4 e8???????? }
		$sequence_8 = { ffd3 83c408 85c0 0f84f1000000 8b4c2410 8b4614 83781800 }
		$sequence_9 = { e9???????? 668b9500f6ffff 668995f8f5ffff c785f4f5ffff00000000 e9???????? 81bd18f6ffff40270000 7450 }

	condition:
		7 of them and filesize < 4553728
}
rule MALPEDIA_Win_Rokku_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "7d23f599-9010-5696-a02d-1607d07e8e35"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.rokku"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.rokku_auto.yar#L1-L125"
		license_url = "N/A"
		logic_hash = "57dc9cf073c9846849be2fef3fe0d810835ec95619f4baf007ace4760f669cc5"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 33c0 40 c3 8b442404 8b4c2408 c744880c02000000 33c0 }
		$sequence_1 = { 8bc1 11542410 f76c2438 01442414 8b44246c 11542410 f76c2440 }
		$sequence_2 = { 33c0 40 c3 8b442404 8b4c2408 c744880403000000 33c0 }
		$sequence_3 = { 8b0d???????? 88542439 8d542422 e8???????? }
		$sequence_4 = { 889dd8fdffff 0f2805???????? 0f11855cfdffff 0f2805???????? 0f11856cfdffff 0f2805???????? 0f11857cfdffff }
		$sequence_5 = { 03f8 13ca 8b542444 8d0412 f76c2464 03f8 }
		$sequence_6 = { 0f2805???????? 0f1185fcfcffff c645fd12 0f2805???????? 0f11850cfdffff 885dff 0f2805???????? }
		$sequence_7 = { 894218 8b442430 894208 8b442424 894228 8b442420 89421c }
		$sequence_8 = { 8bfa 85db 7504 33c0 eb24 }
		$sequence_9 = { 51 6a00 6a00 8bf2 }

	condition:
		7 of them and filesize < 548864
}
rule MALPEDIA_Win_Zxxz_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "d9eb3f1f-ebae-5e2a-a481-441f696b828e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.zxxz"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.zxxz_auto.yar#L1-L174"
		license_url = "N/A"
		logic_hash = "65572d79e5990af47836e788f5829e7ffd3cb87c450ab3af8c0b48c5e790a501"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b35???????? 83c404 68???????? 681c020000 }
		$sequence_1 = { 8b2d???????? 85c0 741a 8d442410 50 }
		$sequence_2 = { 85f6 0f844a010000 8b0d???????? 8b07 }
		$sequence_3 = { 6a00 50 e8???????? 8dbc2464020000 83c40c 4f }
		$sequence_4 = { 83e103 f3a4 83f810 722b 8d4801 8bc3 81f900100000 }
		$sequence_5 = { 50 6802020000 ff15???????? 85c0 0f8556010000 68???????? }
		$sequence_6 = { 83c404 68fa000000 8bcf 6a00 51 e8???????? 8b0d???????? }
		$sequence_7 = { bf???????? e8???????? 83c404 57 ff15???????? 8b35???????? }
		$sequence_8 = { 8b45c4 8945e4 ff774c ff15???????? 83c410 8945c4 83f8ff }
		$sequence_9 = { e8???????? 8b1d???????? 83c404 803d????????00 7415 }
		$sequence_10 = { 0f4315???????? 8b3d???????? 8b8de0feffff 2bc1 57 }
		$sequence_11 = { 84c0 75f6 a0???????? 68f4010000 8807 ff15???????? 6a00 }
		$sequence_12 = { 83c40c 8d4c2404 51 8d542414 52 6a00 68ffff0000 }
		$sequence_13 = { 68???????? ffd6 83c40c c605????????01 5f }
		$sequence_14 = { ff75e4 50 6aff 56 6a00 }
		$sequence_15 = { 7414 0f1f440000 3c20 7403 8801 41 }

	condition:
		7 of them and filesize < 4142080
}
rule MALPEDIA_Win_Scanline_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "2e23d428-ddfd-5d68-8a68-4fbd4bc58b28"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.scanline"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.scanline_auto.yar#L1-L123"
		license_url = "N/A"
		logic_hash = "4aa0ddfc4b8da3bbcf44328c72b8fa822d9f74ba5891bc16eb1a71f637ca965f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 7e2f 8d43ff 56 8bf7 894508 }
		$sequence_1 = { 6a04 53 c745f401000000 ff75fc }
		$sequence_2 = { 6a04 53 c745f401000000 ff75fc ffd7 668b8622050000 66c745e40200 }
		$sequence_3 = { 8bf1 33ff 397e04 c706???????? 7e63 }
		$sequence_4 = { 77e4 eb13 84db 740f 8819 41 }
		$sequence_5 = { 57 e8???????? ff742410 8b4e0c e8???????? 5f 5e }
		$sequence_6 = { 897508 e8???????? 8d85c8feffff 56 }
		$sequence_7 = { 83fb40 7cb6 5f 5e 5d 5b c3 }
		$sequence_8 = { ff15???????? 8b4d0c 6a01 8901 58 5f 5e }
		$sequence_9 = { 83ec18 56 8bf1 8b4608 85c0 0f84fe000000 53 }

	condition:
		7 of them and filesize < 151552
}
rule MALPEDIA_Win_Skynet_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "bc682073-0208-53d3-9265-4d8279a35851"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.skynet"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.skynet_auto.yar#L1-L127"
		license_url = "N/A"
		logic_hash = "526162d5775f83fdbac67b05d1762e571e5a8416b236805d78fd150531fae2e2"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 488d1517ba8c00 4889f1 e8???????? 85c0 74de 488d7b10 }
		$sequence_1 = { 488903 0f16442450 0f114308 4885c9 0f845f010000 48894c2440 }
		$sequence_2 = { 4989c1 4883ff01 0f84a1010000 4c89d2 4c89c9 4989f8 }
		$sequence_3 = { 668983f8000000 0fb687e2000000 8883fa000000 488d054dc28d00 48c7460800000000 488d7028 }
		$sequence_4 = { 488b8424f0000000 488dbc2400010000 488b8c2490000000 48897c2430 4c8b8424f8000000 }
		$sequence_5 = { 29c2 89c8 c1e008 8d8402c0fdffff 8944240c 8b44240c 3d41010000 }
		$sequence_6 = { 482b4508 4c39c0 0f8296000000 4889e9 e8???????? e9???????? 488bbc2418010000 }
		$sequence_7 = { 4889842470010000 488d842460010000 48898c2468010000 488b4c2448 4889c2 4889442468 e8???????? }
		$sequence_8 = { 4881ecf8040000 4889ce 4885c9 0f84d9000000 488d3dba3c9500 4889f9 }
		$sequence_9 = { 83f808 731c a804 755f 85c0 740b 0fb65310 }

	condition:
		7 of them and filesize < 20419584
}
rule MALPEDIA_Win_Rarog_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "237c1c30-c085-56c1-9fd0-1188696e4fac"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.rarog"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.rarog_auto.yar#L1-L132"
		license_url = "N/A"
		logic_hash = "1b9cb796b30aa6461fc922d9a57471561c969c25d5ebc0a5305d445a25377321"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 6a00 6a01 8d8d64ffffff e8???????? 6a00 6a01 8d4dd4 }
		$sequence_1 = { 8d4dd4 c745e80f000000 895de4 885dd4 e8???????? c645fc07 8bbd50ffffff }
		$sequence_2 = { 6802000080 ff15???????? 85c0 7521 8d85f8fbffff 50 }
		$sequence_3 = { 895910 68???????? 8819 e8???????? e8???????? 53 53 }
		$sequence_4 = { 8d8d48ffffff e8???????? 8d759c e8???????? 83ec1c 8bcc 89a544ffffff }
		$sequence_5 = { 833cf5541d430001 751d 8d04f5501d4300 8938 68a00f0000 ff30 }
		$sequence_6 = { c3 8bff 55 8bec 33c0 668b4d08 663b8848ad4200 }
		$sequence_7 = { c645fc1b e8???????? 59 53 6a01 8bcf 888573fbffff }
		$sequence_8 = { ff7518 8845bc ff7514 8d45b0 ff75bc ff75d0 50 }
		$sequence_9 = { 53 56 8d8d2cfdffff e8???????? 53 56 8d8df4fcffff }

	condition:
		7 of them and filesize < 598016
}
rule MALPEDIA_Win_Acehash_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "d206c9d8-3b85-5ed2-8e65-3b1e48068c2b"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.acehash"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.acehash_auto.yar#L1-L126"
		license_url = "N/A"
		logic_hash = "ecf084f804e95e98d806730d8fbe5718cfd150ffc745ec88ffa0b007507a574b"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 48894348 884350 48894358 884360 4885ff 7539 488d05b8460300 }
		$sequence_1 = { 440bd8 0fb64109 4c8d3da7110300 0bd8 0fb6410a 4c8d0dfa3cffff c1e308 }
		$sequence_2 = { 48d1e8 c0e103 4c33c2 480bc8 410fb6c3 4c03c3 }
		$sequence_3 = { 33d2 4c8d05d8080300 498bc1 3b08 7411 4883c008 ffc2 }
		$sequence_4 = { 85c0 0f85b5000000 4c8d4587 488d55bf 488d4d87 }
		$sequence_5 = { 488b742420 488b6c2418 418919 488b5c2410 }
		$sequence_6 = { 418bfd 6690 e8???????? 488903 4885c0 0f8404040000 }
		$sequence_7 = { 483305???????? 488bcb 488905???????? ff15???????? 483305???????? 488d152e3b0300 }
		$sequence_8 = { 488d0d4a520e00 eb02 33c9 e8???????? 4883c438 c3 4883ec38 }
		$sequence_9 = { 4889bc2420020000 4585d2 745c 4c8d9c24f0000000 6666660f1f840000000000 410fb601 c1e208 }

	condition:
		7 of them and filesize < 2318336
}
rule MALPEDIA_Win_Getmypass_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "43e07883-9436-5127-bff0-b4844120de44"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.getmypass"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.getmypass_auto.yar#L1-L126"
		license_url = "N/A"
		logic_hash = "1514c3628fbfee491bf6737b96c8cd49f88ce7d269aed90821e72c7b8e7a9228"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 55 8bec a1???????? 50 8b0d???????? 51 8b15???????? }
		$sequence_1 = { 8b11 8b4508 50 8b4a10 ffd1 68280a0000 8d95d8f5ffff }
		$sequence_2 = { 8b45f4 8b4d08 0fb71441 83fa2c 7538 33c0 }
		$sequence_3 = { 83c404 0fb6c8 85c9 0f8430010000 8b5508 52 e8???????? }
		$sequence_4 = { c785ccfdffff00000000 83bdbcfdffff00 0f86d6000000 83bdccfdffff00 7414 8b8dccfdffff 81c100400600 }
		$sequence_5 = { 8a45ff eb26 8b450c 50 8b4d08 }
		$sequence_6 = { 898dccfdffff eb0c 8b95b0fdffff 8995ccfdffff c7859cfdffff00000000 }
		$sequence_7 = { 8d95d8f5ffff 52 e8???????? 83c408 68280a0000 8d85d8f5ffff }
		$sequence_8 = { 7505 e9???????? c785acfdffff00000000 6a0a ff15???????? }
		$sequence_9 = { 8b550c 2b55a4 89550c eb19 8b45a4 8b4d08 8d1441 }

	condition:
		7 of them and filesize < 49152
}
rule MALPEDIA_Win_Hellokitty_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "6827c89b-357c-5bd8-9a39-3d2ef32873c5"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.hellokitty"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.hellokitty_auto.yar#L1-L128"
		license_url = "N/A"
		logic_hash = "5db7ea6201813ecab1ab3262e0a73bd533405130d0a89d9cc846e01318cb3cb2"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8a817cd34100 88460a 8a8174d34100 8bca 88460b 83e207 c1e903 }
		$sequence_1 = { 8b75fc 894df8 c1c105 8b4024 8945ac 8bc2 034dac }
		$sequence_2 = { 895d08 33fe 895810 8bdf 897014 33da }
		$sequence_3 = { 8955ec 0fb6d1 8b4dfc c1e908 0fb6c9 8b149560454200 }
		$sequence_4 = { 03f7 c1ca0d 8b7df0 33d0 0175fc 8bcb 0bcf }
		$sequence_5 = { 8975f4 3306 83c604 8945dc 8945fc }
		$sequence_6 = { 52 56 8bc8 e8???????? 50 8d4c242c e8???????? }
		$sequence_7 = { f3ab 8d460c 50 51 8d55d8 e8???????? }
		$sequence_8 = { 0bf9 8b4dd8 33d0 8bc3 03fe 8b759c c1c802 }
		$sequence_9 = { 13c2 03cf 894de0 8b4df4 13c3 8945dc }

	condition:
		7 of them and filesize < 319488
}
rule MALPEDIA_Win_Minitypeframe_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "7639fa74-57e7-5768-8893-b7a0e5df4b50"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.minitypeframe"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.minitypeframe_auto.yar#L1-L130"
		license_url = "N/A"
		logic_hash = "00aed69ec5a172711db25de606b9727a1c27a244b320e2f514120ecc5ff81e22"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 56 50 55 e8???????? 83c410 85c0 0f84bcfeffff }
		$sequence_1 = { 83c414 03f8 39aea0000000 742c 8d8424b8000000 85c0 7421 }
		$sequence_2 = { 89742430 8a4601 8bd6 8a26 83c602 }
		$sequence_3 = { 8bca 55 83e103 f3a4 8b8304010000 8bcb 50 }
		$sequence_4 = { 33db 83c40c 3bf3 751d 6a74 68???????? 6a41 }
		$sequence_5 = { 7425 a9000000ff 740f c1e818 0fbe8058070810 83c018 eb2a }
		$sequence_6 = { 8be8 c744241c00000000 83fd30 0f8c59020000 8d8c24ac000000 }
		$sequence_7 = { 41 3d???????? 72f1 56 8bf1 c1e603 3b9670ba0910 }
		$sequence_8 = { 7e11 03f0 3bf7 7402 7ce2 8bc6 5f }
		$sequence_9 = { c744243844000000 c744246401000000 6689742468 e8???????? 8b442420 83c404 83f805 }

	condition:
		7 of them and filesize < 1589248
}
rule MALPEDIA_Win_Stowaway_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "649c6810-b2c0-5010-8fd0-46b99ba5110c"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.stowaway"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.stowaway_auto.yar#L1-L191"
		license_url = "N/A"
		logic_hash = "f83a84f9270ef0b3ba54516289856ffa69c30373d58e069bd72b64ac061226e7"
		score = 75
		quality = 71
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 76e8 77e8 78e8 79e8 }
		$sequence_1 = { 8a7cbe46 a3???????? 4e fb }
		$sequence_2 = { 4e fb b501 2a37 }
		$sequence_3 = { 78e8 79e8 7ae8 ce }
		$sequence_4 = { ce f67be8 7ce8 7de8 7ee8 }
		$sequence_5 = { 0f11c1 7875 52 43 6b8ad456ed7902 a2???????? 6b89130a83d644 }
		$sequence_6 = { 7770 7771 7772 7773 }
		$sequence_7 = { 8a5631 1f 52 2021 8406 37 }
		$sequence_8 = { f60904 9c 26b696 7a19 }
		$sequence_9 = { 8b5f04 8d843000a03b00 01f3 50 83c708 ff9628a03b00 95 }
		$sequence_10 = { 7072 72c8 0dc7707171 27 }
		$sequence_11 = { 2cc6 ec 6e e695 8e01 5d }
		$sequence_12 = { 9c 5c 4d 79c7 4d e081 025c51c9 }
		$sequence_13 = { 89f7 b99eb40000 8a07 47 2ce8 3c01 }
		$sequence_14 = { b082 17 16 40 9d }
		$sequence_15 = { 776a 776d 776e 776f 7770 }
		$sequence_16 = { 68b890e66c 195039 d0f1 1e }
		$sequence_17 = { 30c2 01420f 9f d8682a 1f d204c6 06 }
		$sequence_18 = { 0535bc767f 111c0d16130d3c fc a4 0d00d7a01f 825b85a0 1e }

	condition:
		7 of them and filesize < 8003584
}
rule MALPEDIA_Win_Warmcookie_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "6f8635cd-716c-5d67-9210-dd1146ef5eab"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.warmcookie"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.warmcookie_auto.yar#L1-L223"
		license_url = "N/A"
		logic_hash = "5014529780c51bb2bc5171a2fdba43775647c3983c5888205349646632719d38"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c744242880000000 c744242003000000 41b900000000 41b807000000 ba00000080 }
		$sequence_1 = { 41b902000000 41b800000000 ba00000000 4889c1 }
		$sequence_2 = { 899c2498000000 488d5e02 48896c2470 8944242c 48b8fffffffffdffffff 4889842480000000 31c0 }
		$sequence_3 = { 83e830 6683f809 0f8709060000 4183fe03 }
		$sequence_4 = { 415c c3 55 4157 4156 4155 }
		$sequence_5 = { 4181f80080ffff 7470 8b4c2448 4889c2 }
		$sequence_6 = { 0f8e1bffffff 01d0 89430c e9???????? 4157 4156 }
		$sequence_7 = { e8???????? 3dff2f0000 0f97c0 0fb6c0 }
		$sequence_8 = { ba19000000 488b4c2438 ff15???????? 85c0 }
		$sequence_9 = { ff5010 b9e8030000 ff15???????? 83ef01 }
		$sequence_10 = { 85c0 7409 488b442428 48c1e814 }
		$sequence_11 = { 488d4c0301 4801c9 e8???????? 4889c3 4885c0 }
		$sequence_12 = { ff15???????? 25ff0f0000 8d88b80b0000 ff15???????? }
		$sequence_13 = { ba18000000 4889c1 ffd3 85c0 }
		$sequence_14 = { 488b01 ff9080000000 85c0 7815 }
		$sequence_15 = { 6642837c40fe00 75f3 4b8d1c00 4889d9 e8???????? 4989d8 }
		$sequence_16 = { 4889e8 f0480fb13b 4885c0 75e2 488b3d???????? 31ed }
		$sequence_17 = { 488d542470 b901010000 ff15???????? 85c0 }
		$sequence_18 = { 488b5c2460 8d4801 e8???????? 4c8bf8 }
		$sequence_19 = { ff15???????? 488be8 4883f8ff 7444 4533c9 }
		$sequence_20 = { 4b8d040b 4688441102 483d00010000 72c8 488b5c2408 488b742410 }
		$sequence_21 = { 83f805 7c34 e8???????? 83f804 720c e8???????? 3d000f0000 }
		$sequence_22 = { ff15???????? 85c0 75c2 85f6 740f }
		$sequence_23 = { 8bcf 498bd6 4803ce e8???????? 897e20 }

	condition:
		7 of them and filesize < 331776
}
rule MALPEDIA_Win_Dyepack_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "683dd0a4-1702-5659-be70-3e25df3300ad"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.dyepack"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.dyepack_auto.yar#L1-L121"
		license_url = "N/A"
		logic_hash = "77b620e58d98a67901c16be7ff806f12a042200f452aa93ad8a74706bd6215b0"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 2bcd 1bc7 7815 7f08 81f900100000 760b }
		$sequence_1 = { 6a03 53 aa 8b842434100000 }
		$sequence_2 = { 33db b9ff030000 33c0 8d7c2421 885c2420 f3ab }
		$sequence_3 = { 52 8d44242c 51 50 56 ff15???????? }
		$sequence_4 = { 8b3d???????? 55 6a02 53 6aff 56 ffd7 }
		$sequence_5 = { 56 ffd7 8d4c2418 53 51 8d54242c }
		$sequence_6 = { b814100000 e8???????? 53 56 57 33db }
		$sequence_7 = { ff15???????? 53 53 53 56 ffd7 }
		$sequence_8 = { ff15???????? 56 ff15???????? 8d442410 895c2410 }
		$sequence_9 = { 8d542418 53 52 8d44242c 51 }

	condition:
		7 of them and filesize < 212992
}
rule MALPEDIA_Win_Animate_Clipper_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "b2f9719e-cace-5295-9b02-54cdb38fc0c1"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.animate_clipper"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.animate_clipper_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "7a80e583f965bef40bb4cb285051019e03865533c16a0b10a8c6a90fc0874083"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 33c9 e8???????? eb9e 488bc6 4c8bfe 49c1ff06 488d0ded970100 }
		$sequence_1 = { 48ffc0 48894748 c6475c11 0fb6475c 83e03f 49630487 }
		$sequence_2 = { 448a4c1f1a 488d4d70 488d15cc290200 6a3a 4158 e8???????? 48ffc3 }
		$sequence_3 = { 66c746082100 e9???????? 55 4889e5 31c0 5d c3 }
		$sequence_4 = { 80e1f0 80f9e0 7509 488d0d7dbc0100 eb18 80e2f8 80faf0 }
		$sequence_5 = { 72e9 488b5c2430 4883c420 5f c3 488d050d7c0100 c3 }
		$sequence_6 = { ebd7 0f57c0 0f1106 eb39 4584f6 7409 49f7df }
		$sequence_7 = { 751f 488b85a0010000 488b8888000000 488d0561fe0100 483bc8 7405 e8???????? }
		$sequence_8 = { 7329 4c89c3 89d1 48d3eb 4883fa40 }
		$sequence_9 = { 4d89d9 4d29d1 4c895a30 807a5e01 751f 41f6c001 7432 }

	condition:
		7 of them and filesize < 513024
}
rule MALPEDIA_Win_Powerpool_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "3c7d76ce-9e3c-56d9-89ec-0d2030e3a28b"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.powerpool"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.powerpool_auto.yar#L1-L156"
		license_url = "N/A"
		logic_hash = "5ad739e00ae07674257230c37a8aadb4bbbc2bef01a0c5156f9388e143d8c522"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8965f0 85c9 7504 33ff eb16 }
		$sequence_1 = { 7412 8b4d08 833c8800 7409 }
		$sequence_2 = { 7412 8b4904 80e103 80f901 }
		$sequence_3 = { 7412 8b45a4 83c01f 3945b0 }
		$sequence_4 = { 7443 8bbd68feffff 3bf7 742a 837e1410 720b 8b06 }
		$sequence_5 = { 005311 40 005d11 40 006711 }
		$sequence_6 = { 7412 8b5dac 83eb08 f7db }
		$sequence_7 = { 895e64 ff15???????? 8b4c2418 51 }
		$sequence_8 = { 7412 8b45d0 2403 3c01 }
		$sequence_9 = { 896c2414 3bef 7416 57 }
		$sequence_10 = { 7412 8d9b00000000 8338ff 7407 }
		$sequence_11 = { 7412 8b04b0 50 e8???????? 8b8590faffff 83c404 }
		$sequence_12 = { 895e64 ff15???????? 8b442414 50 }
		$sequence_13 = { 006711 40 0000 0303 }
		$sequence_14 = { 8b6d00 50 ffd6 83c404 85ed }
		$sequence_15 = { 895e64 e9???????? 53 57 ff15???????? 8bd8 }

	condition:
		7 of them and filesize < 819200
}
rule MALPEDIA_Win_Milkmaid_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "ce0fca63-9d7f-5748-8fde-4eabad1d8018"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.milkmaid"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.milkmaid_auto.yar#L1-L104"
		license_url = "N/A"
		logic_hash = "28b4330fab0cadcfa505d7c87bf54d54bd752dc7733e8dc60bb7108ee0d8d7d4"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff15???????? 8b74241c 8d4c2404 51 }
		$sequence_1 = { c68424e428010003 e8???????? b911000000 33c0 8d7c2434 33d2 }
		$sequence_2 = { eb05 8b5708 2bd1 8b5c2428 8b6c242c 8d4c0201 894704 }
		$sequence_3 = { 8b442410 8b4c240c 50 51 8d8c2480000000 c68424e428010003 }
		$sequence_4 = { 53 8d4c2434 89542454 c784248400000001000000 }
		$sequence_5 = { 896c2420 8a8528280100 84c0 7528 8b4d04 8d450c 51 }
		$sequence_6 = { 8d4c2410 c68424dc28010001 e8???????? 8d4c2414 889c24dc280100 }
		$sequence_7 = { 5e 5b 64890d00000000 81c4d4280100 c3 57 56 }

	condition:
		7 of them and filesize < 65536
}
rule MALPEDIA_Win_Unidentified_076_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "7e8740a2-f3a9-562f-89ea-00ceaadd5eb2"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.unidentified_076"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.unidentified_076_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "317011653466b8f4083026a9fa7292b8a716eb4c592fd9cdc8450fd34ed269e2"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 33d2 4489a530150000 4488642460 e8???????? 488d542460 448bc3 33c9 }
		$sequence_1 = { 8b4718 894118 488b4e18 8b4714 394114 0f8566feffff 488b4778 }
		$sequence_2 = { 7527 488b8fc8000000 8bd8 ff9150010000 41b8ff1a0000 33d2 448bc8 }
		$sequence_3 = { 488d97c0000000 4c63c0 85c0 7e1f 4c635738 488bcb 493bca }
		$sequence_4 = { 8b12 488bf9 488d4df0 33db c745f07220633a c745f425642c6c c745f83a25640a }
		$sequence_5 = { 488b87c8000000 498bcc ff9000060000 488b87c8000000 488bcb ff9000060000 488b87c8000000 }
		$sequence_6 = { 448bcb 4889442420 ff542448 8bd8 33c0 85db }
		$sequence_7 = { 4c8bc3 488bd7 ff9040070000 488b85c8000000 488d4f01 }
		$sequence_8 = { 488bce 4903d5 48895c2430 48897c2420 e8???????? 85c0 7416 }
		$sequence_9 = { 488b86c8000000 498bcd ff90d0030000 eb35 488b9ec8000000 488dbe84060000 ff9350010000 }

	condition:
		7 of them and filesize < 114688
}
rule MALPEDIA_Win_W32Times_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "d9dd9da8-4963-579a-8592-2197709db9b0"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.w32times"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.w32times_auto.yar#L1-L121"
		license_url = "N/A"
		logic_hash = "e358e138b2bb62002f5bbb45aafa23c6614d2de1063398e9b4a37b0b2eaf6205"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 52 8d842404080000 68???????? 50 }
		$sequence_1 = { 8dbc2418010000 f3ab 8b7d00 8bcb 8bd1 }
		$sequence_2 = { 33db b900400000 33c0 8d7c2414 f3ab 8d442414 50 }
		$sequence_3 = { 8d8c2424040000 52 68f6010000 50 51 }
		$sequence_4 = { b941000000 8dbc241c020000 8bac2438060000 f3ab }
		$sequence_5 = { 83c41c c3 57 ffd5 56 ffd5 5f }
		$sequence_6 = { 2bca 8db424e8000000 8bd1 8dbc24f4040000 c1e902 f3a5 }
		$sequence_7 = { 50 56 ff15???????? 8bf8 85ff 751c ff15???????? }
		$sequence_8 = { 683f000f00 6a00 56 ff15???????? 8bf8 }
		$sequence_9 = { 8d4c2420 895c2418 51 68???????? ff15???????? 83c408 eb02 }

	condition:
		7 of them and filesize < 122880
}
rule MALPEDIA_Win_Andromeda_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "118e5e4d-ba01-561a-8bf0-d18e24090541"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.andromeda"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.andromeda_auto.yar#L1-L292"
		license_url = "N/A"
		logic_hash = "201d502ff198ec609e2274ca25aa32a553a8b4e99a640aa66c46187121cd53c3"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { b8fcfdfeff fd ab 2d04040404 }
		$sequence_1 = { 33c9 33d2 8b7d10 fec0 368a942800ffffff }
		$sequence_2 = { 81e2ff000000 368a942a00ffffff 301439 41 3b4d14 }
		$sequence_3 = { 8b7508 33db 368a942900ffffff 02c2 020433 368ab42800ffffff }
		$sequence_4 = { ebcf 33c0 33db 33c9 }
		$sequence_5 = { 368ab42800ffffff 3688b42900ffffff 3688942800ffffff fec1 7408 }
		$sequence_6 = { 60 b940000000 8d7dfc b8fcfdfeff fd }
		$sequence_7 = { 3688942b00ffffff 02d6 81e2ff000000 368a942a00ffffff }
		$sequence_8 = { 60 e8???????? 5d 81ed???????? 33c9 }
		$sequence_9 = { 50 e8???????? 83c40c 6800000100 e8???????? }
		$sequence_10 = { 85ca 7404 0420 8806 }
		$sequence_11 = { 0fb64601 84c0 7905 0d00ffffff }
		$sequence_12 = { 6a00 6a30 8d45d0 50 6a01 ff7508 }
		$sequence_13 = { 33d2 3c41 0f9dc2 85ca 7404 }
		$sequence_14 = { 8a06 33c9 3c5a 0f9ec1 }
		$sequence_15 = { 85c0 741c ff7508 6a04 ff750c ff15???????? 85c0 }
		$sequence_16 = { 6a00 6a06 6a01 6a02 e8???????? 8945f0 83f8ff }
		$sequence_17 = { 0f8476010000 6804010000 6a00 ff35???????? e8???????? 8945f8 }
		$sequence_18 = { 8945d8 8945dc 66c745cc0000 c745c801010000 8d458c }
		$sequence_19 = { 6a00 6a00 68???????? 6a00 e8???????? eba9 6a00 }
		$sequence_20 = { 83f800 0f8458010000 6804010000 ff75f8 68???????? e8???????? }
		$sequence_21 = { 6a10 8d45e0 50 ff75f0 e8???????? }
		$sequence_22 = { c745e400000000 6a00 6a00 6a00 6a06 }
		$sequence_23 = { e8???????? 6804010000 ff75fc 6a00 }
		$sequence_24 = { 81f71b1ccc93 81f3db50ed3e 8945ec 81ff7185baee }
		$sequence_25 = { 894574 81e736087c03 8d45e0 69ffcd16011d }
		$sequence_26 = { 8b4d08 8bd8 8b413c 81f3466f8be1 81c7462448a5 }
		$sequence_27 = { ff560c 0fafc7 89450c 8b45f0 }
		$sequence_28 = { 8d4de0 51 ff75d4 35ebb0598f 50 ff75cc e8???????? }
		$sequence_29 = { 81fffc199d56 0f848efbffff 8b4564 2b4550 83e805 }
		$sequence_30 = { 81f1ceda243f 81eace7c3816 8b5d08 8a1c1f 84db }
		$sequence_31 = { 8d45dc 50 ff75f4 c745dc5c002a00 ff5644 }

	condition:
		7 of them and filesize < 204800
}
rule MALPEDIA_Win_Gspy_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "c051d768-929f-59cb-911a-de5e39ebc337"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.gspy"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.gspy_auto.yar#L1-L133"
		license_url = "N/A"
		logic_hash = "83d2af2b2663b63f44c1711b788df5e86d56bf6b584af4a62d205c89805237a3"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 895030 83c204 895034 8b5028 5f 8d541201 41 }
		$sequence_1 = { 68782f0000 ff15???????? 8bc6 c744241000000000 e8???????? 8b442410 5e }
		$sequence_2 = { 3bc8 72f1 33c9 66894c4410 8d542410 52 8d84241c020000 }
		$sequence_3 = { 8d942420020000 52 6a00 6a00 50 6a00 ffd7 }
		$sequence_4 = { 85c0 750f be05000000 8bc6 5e 81c41c010000 c3 }
		$sequence_5 = { 756d f60720 7415 8b442410 50 ff15???????? }
		$sequence_6 = { 56 33c0 6a44 50 8d4c2434 51 668944241c }
		$sequence_7 = { 8d4c2420 51 ffd7 85c0 75d8 8b542430 68ff040000 }
		$sequence_8 = { 6a20 6a00 6a08 6a00 46 56 e8???????? }
		$sequence_9 = { e8???????? 89442418 8b4714 8d5004 395710 7216 8b4f18 }

	condition:
		7 of them and filesize < 421888
}
rule MALPEDIA_Win_Nitol_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "5ca44639-2819-597b-a97e-e0e3a2cec9d4"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.nitol"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.nitol_auto.yar#L1-L128"
		license_url = "N/A"
		logic_hash = "3b569abf6365e89a37af426b046e75380672573d6ee9ba1d6fae88be61b55baa"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 83bdf0feffff01 7560 8b4df4 8b45f8 }
		$sequence_1 = { 83c418 8d45a4 6a10 50 53 8d8540ffffff 6a28 }
		$sequence_2 = { ffd6 8d85e8feffff 50 8d8568feffff 50 }
		$sequence_3 = { ff742428 ffd7 8d442430 55 50 53 }
		$sequence_4 = { 6a02 66ab ff15???????? 83f8ff 8945c8 7509 5f }
		$sequence_5 = { 668945ee 8d45bc 50 c645ec80 c645ed11 ff15???????? 8945f0 }
		$sequence_6 = { 0f86d5030000 6a4b 50 e8???????? 8d8588f4ffff 50 e8???????? }
		$sequence_7 = { 57 ffd3 8b8688000000 45 83c014 3be8 7ce6 }
		$sequence_8 = { 8d85b0feffff 50 e8???????? 8945fc c7042460ea0000 e8???????? 59 }
		$sequence_9 = { ff15???????? 4e 75e4 6a0a ff15???????? ebce 53 }

	condition:
		7 of them and filesize < 139264
}
rule MALPEDIA_Win_Pebbledash_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "01a7e382-631e-5b3c-a9b2-27e1cc578b22"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.pebbledash"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.pebbledash_auto.yar#L1-L167"
		license_url = "N/A"
		logic_hash = "37855a7181d904f3da423520164c6f7050574e6be406af04c69d8f3efaf3548f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 5e c3 55 8b6c2408 56 33f6 8b4d00 }
		$sequence_1 = { 832000 a1???????? a3???????? c3 8b442404 a3???????? }
		$sequence_2 = { 6829080000 68???????? 68???????? e8???????? 83c40c 68???????? }
		$sequence_3 = { 5e c3 55 8bec 833d????????00 750f }
		$sequence_4 = { e8???????? 33d2 b90e000000 f7f1 }
		$sequence_5 = { 6888130000 ff15???????? b9???????? e8???????? 68???????? e8???????? 83c404 }
		$sequence_6 = { 8bc1 5b 5e 5f c9 c3 6a01 }
		$sequence_7 = { 50 b9???????? e8???????? 85c0 7514 }
		$sequence_8 = { 41894e04 0fb64209 0fb64a08 c1e108 0bc8 }
		$sequence_9 = { e8???????? 498bcc 85c0 7512 }
		$sequence_10 = { 33d2 41b800040000 4d8be1 e8???????? }
		$sequence_11 = { 415d 415c 5d c3 498bcc e8???????? }
		$sequence_12 = { 0fb63a 4c8d258fdaffff 440fb65a04 4d8be8 }
		$sequence_13 = { 488bd3 e8???????? 0f100b 4883c310 }
		$sequence_14 = { 0f44c5 41c1e008 8905???????? 0fb64201 440bc0 }
		$sequence_15 = { e8???????? 488d542440 488bce ffd0 85c0 }

	condition:
		7 of them and filesize < 677888
}
rule MALPEDIA_Win_Suncrypt_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "62d8711a-746c-5025-843f-b0f5437dad4e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.suncrypt"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.suncrypt_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "8e9126cfa348b05c9f2ac93dbacc5c6b4062b9054d9a6dc02dba738c2b1d37f5"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 0f28d3 660ffe9530ffffff 660feff2 660f380035???????? 0f28de 660ffe5d90 0f28c3 }
		$sequence_1 = { 33c0 803d????????01 56 0f95c0 c745d000000000 6800040000 8945cc }
		$sequence_2 = { 8b9514feffff 8b8560feffff 8b540204 8bca 8d7902 660f1f440000 }
		$sequence_3 = { 0f1108 83423001 897df8 7506 ff4234 897df8 8b7da0 }
		$sequence_4 = { 8b8574ffffff 040b 83f061 884583 8b8574ffffff 040c 83f074 }
		$sequence_5 = { 56 51 e8???????? 83c408 84c0 0f84c2000000 0fb74612 }
		$sequence_6 = { c6853cffffff37 33c9 c6853dffffff2d c6853effffff64 c6853fffffff7c c68540ffffff7f }
		$sequence_7 = { ff7510 8b7508 ff750c c6451700 56 e8???????? 83c40c }
		$sequence_8 = { ff15???????? 5e 5b 57 6a00 ff15???????? 50 }
		$sequence_9 = { 57 50 e8???????? 83c40c 83473001 7503 }

	condition:
		7 of them and filesize < 172032
}
rule MALPEDIA_Win_Bunitu_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "47a8bab9-0337-5500-b3d2-8d25b98fe84e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.bunitu"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.bunitu_auto.yar#L1-L120"
		license_url = "N/A"
		logic_hash = "40ee51f25f9b21d55b09c5a850194af329ae29935d512c092962b1854a595336"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8bf7 03d8 ebdf 8bb544feffff }
		$sequence_1 = { 57 8d859cf7ffff 50 e8???????? 8d8d9cf7ffff 51 }
		$sequence_2 = { ffb544feffff 51 6800040000 6a00 ff15???????? }
		$sequence_3 = { 60 8b7d08 8b9774130000 8955e0 8b9778130000 8955dc }
		$sequence_4 = { b970170000 f2ae 2bfa 87fa 5f 8bc2 }
		$sequence_5 = { 81c498f7ffff 57 8dbd9cf7ffff 2bc0 b968080000 f3aa 5f }
		$sequence_6 = { 87fa 5f 8bc2 48 40 8d443825 668b00 }
		$sequence_7 = { 50 8f06 33db 83c301 d1e3 d1e3 03fb }
		$sequence_8 = { 6800100000 50 ff75fc e8???????? }
		$sequence_9 = { 59 8bd0 8bdf b82f000000 }

	condition:
		7 of them and filesize < 221184
}
rule MALPEDIA_Win_Catchamas_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "578ff9b8-0ef3-5c15-b969-f4338f4c888c"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.catchamas"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.catchamas_auto.yar#L1-L123"
		license_url = "N/A"
		logic_hash = "88e027225015fa9823da897f5deded620e729eacaa9b630e86e1881a16d53b8e"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff15???????? 83c42c e9???????? ffd6 8b0d???????? }
		$sequence_1 = { 43 3b5c2410 7c86 5e 5d 57 ff15???????? }
		$sequence_2 = { 7722 0fb68878124000 ff248d68124000 680e000780 e8???????? 6857000780 }
		$sequence_3 = { ff15???????? 56 8be8 55 53 57 ff15???????? }
		$sequence_4 = { 53 8b1d???????? 56 57 683f000f00 }
		$sequence_5 = { 5b 8b8c241c010000 33cc e8???????? 81c42c010000 c3 }
		$sequence_6 = { a4 894c2420 ff15???????? 837c241000 751e 53 }
		$sequence_7 = { 8b10 8bc8 8b420c ffd0 8bc8 8b442418 }
		$sequence_8 = { 6808080000 8d54246c 52 51 ffd7 }
		$sequence_9 = { e8???????? 8b45dc 6a00 8d4de8 51 57 }

	condition:
		7 of them and filesize < 368640
}
rule MALPEDIA_Win_Seduploader_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "334d2171-7082-5ae6-be03-b82763d4d1c1"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.seduploader"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.seduploader_auto.yar#L1-L114"
		license_url = "N/A"
		logic_hash = "32ae9c561f6ff5327f9545800e8e7fd05e54400e76395ddf84cfb6f68c9d30a4"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 50 e8???????? 8b4510 83c6fe 8930 8d4601 }
		$sequence_1 = { 8b4510 83c6fe 8930 8d4601 50 e8???????? }
		$sequence_2 = { 8b4510 83c6fe 8930 8d4601 50 }
		$sequence_3 = { 8b4510 83c6fe 8930 8d4601 }
		$sequence_4 = { e8???????? 8b4510 83c6fe 8930 8d4601 50 e8???????? }
		$sequence_5 = { c3 56 6a3e 8bf1 }
		$sequence_6 = { ff7630 e8???????? 83c40c 3b4508 }
		$sequence_7 = { 89b5ecfeffff 89b5f0feffff 89b5f4feffff e8???????? 83c40c }
		$sequence_8 = { 83c6fe 8930 8d4601 50 }
		$sequence_9 = { e8???????? 8b4510 83c6fe 8930 8d4601 }

	condition:
		7 of them and filesize < 401408
}
rule MALPEDIA_Win_Bh_A006_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "9ea6449e-2cab-53f0-876e-246076bf8c48"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.bh_a006"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.bh_a006_auto.yar#L1-L101"
		license_url = "N/A"
		logic_hash = "c931858e1ac88b2f7bec999eaa8066ef6a995c994cf3ed14b102febcebf4eb01"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 03de eb09 8bde 2bda 2bd8 83eb05 85c9 }
		$sequence_1 = { 8d4f01 030e 3b0e 7e72 }
		$sequence_2 = { 8bd8 663938 75de 8b7d08 2bf7 d1fe 8bc6 }
		$sequence_3 = { 6689b5dcf9ffff 50 8d85def9ffff 680b020000 50 }
		$sequence_4 = { 6a01 68050000c0 ff15???????? 8b7b08 85ff 7417 }
		$sequence_5 = { 50 ff7514 8b450c ff7510 83c0f2 }
		$sequence_6 = { 7d71 8b5514 81ff00000001 7318 3b5d0c }
		$sequence_7 = { 59 59 85c0 0f859c040000 }

	condition:
		7 of them and filesize < 430080
}
rule MALPEDIA_Win_Crat_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "945aab68-4a90-593a-927b-9db88149c40f"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.crat"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.crat_auto.yar#L1-L174"
		license_url = "N/A"
		logic_hash = "36438ee610e83182a296234b58b0b081e18b1fd8f2febe15041f4ead3c7ecfc6"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 7406 e8???????? 90 488b542420 }
		$sequence_1 = { 7523 0fb7fa 8bcf e8???????? 4885c0 7427 448bc7 }
		$sequence_2 = { e8???????? 488bc8 4885c0 7433 }
		$sequence_3 = { e8???????? 488bd0 488d8d28010000 e8???????? 90 }
		$sequence_4 = { e8???????? 488bd0 488d4d90 e8???????? 90 488bd0 }
		$sequence_5 = { e8???????? 488bd0 488d8da8010000 e8???????? 90 }
		$sequence_6 = { e8???????? 488bd0 488d8d78010000 e8???????? }
		$sequence_7 = { 498bc4 48833d????????10 480f4305???????? 482bc8 }
		$sequence_8 = { 33d2 c1e902 f7f1 eb02 }
		$sequence_9 = { ffd0 85c0 750f ff15???????? 83f87a }
		$sequence_10 = { c745fcffffffff 8b750c 83c6f0 8d460c }
		$sequence_11 = { 8b4dd4 41 e9???????? 8b45e4 }
		$sequence_12 = { e8???????? ffd0 8bf0 eb02 }
		$sequence_13 = { 8bec 8b4128 2b4124 56 8d7118 83f810 }
		$sequence_14 = { e9???????? 8b5708 3bca 754e }
		$sequence_15 = { 8b4dd4 41 837f1800 0f8517ffffff 294b0c }
		$sequence_16 = { 8d45f4 64a300000000 c745fc00000000 c745f000000000 8b7508 c70600000000 e8???????? }
		$sequence_17 = { c745fcffffffff 8b5608 83ea10 8d420c }

	condition:
		7 of them and filesize < 4161536
}
rule MALPEDIA_Win_Crypmic_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "05c599ca-d509-5905-b047-28357a338600"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.crypmic"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.crypmic_auto.yar#L1-L116"
		license_url = "N/A"
		logic_hash = "70efec04e66b26aace16425303a93c30c4ff2e83724b0d3f9a2083affb7f52a0"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 395818 764a 8b7820 03f9 }
		$sequence_1 = { 83ec08 53 56 33f6 57 8955fc 8bd9 }
		$sequence_2 = { 5e b805400080 5b 8be5 5d c3 8d45d4 }
		$sequence_3 = { 8bcf 66894302 e8???????? ff75f8 8b470c 6a00 }
		$sequence_4 = { 0fb70c08 8b421c 8d0488 8b4df8 8b0408 }
		$sequence_5 = { ba5c000000 66891448 8d1c48 8d8d94fdffff }
		$sequence_6 = { 8b4de4 894f04 8b4de8 894f08 668b4df0 66894f0c }
		$sequence_7 = { 3b75fc 770b 8b55f8 8b4df4 }
		$sequence_8 = { ffd0 0fb717 33f6 33c9 8945f8 }
		$sequence_9 = { 56 57 894df4 83f828 }

	condition:
		7 of them and filesize < 81920
}
rule MALPEDIA_Win_Solarbot_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f4c538e0-673b-5f94-8956-bdd82b4cfb9b"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.solarbot"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.solarbot_auto.yar#L1-L124"
		license_url = "N/A"
		logic_hash = "0f3217a050f5fd5e1d6f6f71b351dacf88ad2c4cb5555c46e6cf400230a9d80c"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 7e71 8b8524f8ffff 40 0fb600 83f804 7d62 }
		$sequence_1 = { 8b5514 c745c800000000 c745e400000000 c745e000000000 c745f000000000 c745f400000000 8d4df0 }
		$sequence_2 = { 8945f8 8b450c 8945f0 8b5d10 c745f400000000 b800000000 }
		$sequence_3 = { 85c0 7626 8b45f4 83f801 751e }
		$sequence_4 = { 0f8690010000 8975fc c745e800000000 c745ec00000000 }
		$sequence_5 = { 81ec14040000 899decfbffff 89b5f0fbffff 89bdf4fbffff 8b5d08 }
		$sequence_6 = { 8b7510 8b4514 8945f0 8b4d18 b800000000 c745f800000000 c745f400000000 }
		$sequence_7 = { 8955f0 c745f400000000 c745f800000000 8945fc ff75fc e8???????? 89c3 }
		$sequence_8 = { 50 e8???????? 8945e8 85c0 0f847c020000 6a00 }
		$sequence_9 = { 85c0 0f8475000000 6a00 ff75f8 ff7508 ff75fc 6aff }

	condition:
		7 of them and filesize < 204800
}
rule MALPEDIA_Win_Agfspy_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "1eec54e3-5a60-5063-a302-f4ee2b2e5427"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.agfspy"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.agfspy_auto.yar#L1-L133"
		license_url = "N/A"
		logic_hash = "151ad8e549a2817e519b8100d06952225f056be2ea34f6afc0cf5370414565cd"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? c645fc02 8b06 2b459c 8b7f18 d1f8 894594 }
		$sequence_1 = { 8955fc 8b4614 8b4e18 2500300000 894dc8 39561c 7f1b }
		$sequence_2 = { 85ff 7403 4f eb08 bf1f000000 83ee04 85db }
		$sequence_3 = { 8d45c0 0f4345c0 881408 c644080100 e9???????? b8ffffff7f 2bc1 }
		$sequence_4 = { 5b 8be5 5d c20800 83ec08 c6432801 }
		$sequence_5 = { 7424 83f808 741f 83f80d 741a 83f802 75a8 }
		$sequence_6 = { 6a20 e8???????? 8b4d08 0f57c0 83c404 89450c 0f1100 }
		$sequence_7 = { 837e4c5d 0f85a1000000 f7462c00010000 bb5d000000 740f 8b4630 53 }
		$sequence_8 = { 8be5 5d c20400 8b0e 85c9 7430 8b4608 }
		$sequence_9 = { 894a18 66a1???????? 6689421c a0???????? 88421e c6421f00 8b4dc8 }

	condition:
		7 of them and filesize < 1482752
}
rule MALPEDIA_Win_Turian_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "dbe0b5ee-481b-5ba0-92bc-4c335448b06a"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.turian"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.turian_auto.yar#L1-L117"
		license_url = "N/A"
		logic_hash = "7f1046cfbf0a4943bf8a4b93bd6c3449de13dd1c2876c35e06b0c716c9955f96"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { eb04 8d74241c 68???????? 56 ffd7 }
		$sequence_1 = { 8b2d???????? 33c0 8d5c2414 83c404 89442410 c1eb04 8d740704 }
		$sequence_2 = { 85c0 752f ffd5 0305???????? }
		$sequence_3 = { ff15???????? 8bd6 33c9 8bbc2488000000 89442410 890a }
		$sequence_4 = { 5b 81c420040000 c3 8d4c2410 6a10 51 }
		$sequence_5 = { 33c0 83e103 8d542456 f3a4 }
		$sequence_6 = { ff15???????? 33c0 c3 8bc8 }
		$sequence_7 = { 754a 6809380000 56 8d4c2418 e8???????? 83f810 }
		$sequence_8 = { c1e105 03c8 68???????? 8d1448 b921000000 }
		$sequence_9 = { 5d 5b 83c474 c3 68fc1b0000 ffd3 }

	condition:
		7 of them and filesize < 645120
}
rule MALPEDIA_Win_Geminiduke_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "9136649c-80d3-5479-b1f0-342bb9508141"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.geminiduke"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.geminiduke_auto.yar#L1-L149"
		license_url = "N/A"
		logic_hash = "06b8937fd5c26acf33b78b295734b9b6af2a2847548e3dc03c001461c730fc8b"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b7c2410 8b442414 8b4c2418 f3aa 5f 59 }
		$sequence_1 = { 50 51 57 8b7c2410 }
		$sequence_2 = { 83c404 50 6801000080 ff15???????? 85c0 7407 33c0 }
		$sequence_3 = { 6819000200 6a00 68???????? e8???????? 83c404 }
		$sequence_4 = { 034590 03c8 894dd0 8b45f8 }
		$sequence_5 = { 03459c 03c8 894ddc 8b45fc }
		$sequence_6 = { 034590 8b8d70ffffff c1e907 8b9570ffffff }
		$sequence_7 = { 034584 8b8d64ffffff c1e907 8b9564ffffff c1e219 0bca 8b9564ffffff }
		$sequence_8 = { 337704 33e8 8b442410 c1ee12 }
		$sequence_9 = { 6a00 6a00 8bcf e8???????? 8bcf e8???????? 8bd6 }
		$sequence_10 = { f7f3 66894702 8bc2 c1e010 668b06 }
		$sequence_11 = { 6a1e 6a00 6a09 57 }
		$sequence_12 = { 33db 8b7c2418 8b74241c 668b5c2420 33d2 }
		$sequence_13 = { 33d2 f7f3 668907 8bc2 5a 5b 59 }

	condition:
		7 of them and filesize < 327680
}
rule MALPEDIA_Win_Allaple_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "ac087b1d-e31e-50b4-a6ec-b95f6d6d0f1a"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.allaple"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.allaple_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "67592cd04a5463d683feae2742bfa6861abad2bdbe05c92a231403fb7cee96f7"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 57 ff15???????? 8bf0 3bc7 7447 baa7010000 57 }
		$sequence_1 = { 8b55f8 894a04 8b45fc 8b4808 334df4 8b55f8 894a08 }
		$sequence_2 = { c645f60a c645f73d c745f800000000 eb09 8b45f8 83c001 8945f8 }
		$sequence_3 = { 0345d8 50 e8???????? 83c408 a3???????? 6a03 ff35???????? }
		$sequence_4 = { 83c71b ff7510 ff750c 57 e8???????? 037d10 6a0a }
		$sequence_5 = { 8b0cb8 8b0478 d3c0 8b4d10 0fb65104 0fb64903 83fa01 }
		$sequence_6 = { ffb5b4fdffff e8???????? e9???????? 8b95b4fdffff 8d8a8a010000 c785b8fdffff00000000 80790a30 }
		$sequence_7 = { 6802000080 e8???????? 3bc7 7524 6804010000 8d8500feffff 50 }
		$sequence_8 = { e8???????? 0bc0 0f8537ffffff 53 e8???????? 56 e8???????? }
		$sequence_9 = { c785c8fdffff00000000 eb0f 8b85c8fdffff 83c002 8985c8fdffff 81bdc8fdffff00010000 0f8d93000000 }

	condition:
		7 of them and filesize < 253952
}
rule MALPEDIA_Win_Wastedloader_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "77a2ade8-76ac-5489-9bb2-292337810980"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.wastedloader"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.wastedloader_auto.yar#L1-L125"
		license_url = "N/A"
		logic_hash = "9f8caca5f314d306a16416a35fd4a4839e75a98e2820acfdeaabd9b8b5446868"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b4df8 0fb75156 83ea54 8b45f8 66895056 b9b8000000 }
		$sequence_1 = { e74d b980344b51 7385 20e1 }
		$sequence_2 = { 1008 a6 660f1b09 0000 a7 7280 011cfd80edc199 }
		$sequence_3 = { 04ee 1dd1704c64 0ffda4e83d005d04 008b4c81d274 }
		$sequence_4 = { 98 fc b54c 90 b182 7c80 }
		$sequence_5 = { 6a3b 11c2 855cb412 8bb8181480c8 1808 007056 8b4c00f9 }
		$sequence_6 = { 037fc1 00e4 1ac7 7240 ad 58 2448 }
		$sequence_7 = { 6ac1 8b700b 2c85 a5 5b df8bd2687320 ef }
		$sequence_8 = { 2430 8b1c24 a1???????? b6f6 ff4565 f9 }
		$sequence_9 = { 1c34 83f4f0 0d844de3fd ff959ef9ff7b f34a 24f0 801abd }

	condition:
		7 of them and filesize < 2677760
}
rule MALPEDIA_Win_Fakeword_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "90c74c22-0d6b-5f76-aedb-fce0e85239a6"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.fakeword"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.fakeword_auto.yar#L1-L129"
		license_url = "N/A"
		logic_hash = "ed34df27959a023203db11f52ee356a7355bc91d6d76fb3ef9f0879408b946e7"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 4f 89442430 3bc7 0f8654ffffff 5f 8bc3 }
		$sequence_1 = { 6880000000 50 ff15???????? f644242810 }
		$sequence_2 = { 8d8d48eeffff 8d9548deffff 51 52 e8???????? 83c408 a1???????? }
		$sequence_3 = { 81c484000000 c3 6800000002 6a00 6a01 ff15???????? 8bf0 }
		$sequence_4 = { 8bf1 81e200000020 81e600000040 81e100000080 85d2 7408 808c045401000001 }
		$sequence_5 = { 6a02 6a00 6800f005ff 57 ffd6 6a02 6a00 }
		$sequence_6 = { ff15???????? 8b4c2410 8d44242c 50 51 ff15???????? 85c0 }
		$sequence_7 = { 50 55 8d7704 6a51 68???????? 56 }
		$sequence_8 = { 83c43c 3bfb 7606 5f 5e 33c0 5b }
		$sequence_9 = { 8a0c0f 81e1ff000000 c1e104 33c1 33c9 8a4c3a02 c1e004 }

	condition:
		7 of them and filesize < 98304
}
rule MALPEDIA_Win_Murofet_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "ec132e82-8744-5353-84ec-9ace2fc4af13"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.murofet"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.murofet_auto.yar#L1-L117"
		license_url = "N/A"
		logic_hash = "7d6e8e47c257eed43a7caeeac40f0c0966f562e4d9fbf86731fd8a394605d44e"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { fec2 8816 e8???????? 0fb6c0 99 f7ff }
		$sequence_1 = { 3c04 73ce b002 a2???????? }
		$sequence_2 = { e8???????? e8???????? 3c02 72e5 e8???????? a2???????? 84c0 }
		$sequence_3 = { e8???????? 3c04 73ce b002 a2???????? }
		$sequence_4 = { fec2 8816 e8???????? 0fb6c0 }
		$sequence_5 = { e8???????? 3c04 73ce b002 }
		$sequence_6 = { 50 53 57 56 ff15???????? c6443eff00 }
		$sequence_7 = { 3c02 72e5 e8???????? a2???????? 84c0 7510 }
		$sequence_8 = { e8???????? 33c0 c20400 55 8bec 83ec68 53 }
		$sequence_9 = { a2???????? 84c0 7510 e8???????? }

	condition:
		7 of them and filesize < 622592
}
rule MALPEDIA_Win_Hoplight_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "0781bebe-9320-517d-8930-e555b0f3b60f"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.hoplight"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.hoplight_auto.yar#L1-L90"
		license_url = "N/A"
		logic_hash = "8341596faf0ec7a57689762d42cf5a43685079663a18bc4bbcdf934c9e856b6a"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 488b442448 4805a0000000 4889442420 48837c242000 }
		$sequence_1 = { 488d15433c0200 488b4c2420 e8???????? 85c0 }
		$sequence_2 = { 750a 83bc24800400000e 7469 837c242c33 }
		$sequence_3 = { 48ffc0 48890424 837c241402 7e16 }
		$sequence_4 = { 488b8c2470010000 e8???????? 488b842470050000 4883783800 }
		$sequence_5 = { 488d8c2452080000 4533f6 33d2 41b8fe070000 }
		$sequence_6 = { 488b842468010000 8b00 25ff000000 8bc0 }
		$sequence_7 = { 7511 8b442430 ffc8 89442430 }

	condition:
		7 of them and filesize < 765952
}
rule MALPEDIA_Win_Acr_Stealer_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "24c9a38a-fce0-53f4-9a4e-552dd9de2e8f"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.acr_stealer"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.acr_stealer_auto.yar#L1-L175"
		license_url = "N/A"
		logic_hash = "6eae0550935a54eae3cb006a0c6d7d0d852fb86f602f974285286d04e5e2a654"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 51 8b4530 50 8d4d08 51 e8???????? 8b55f8 }
		$sequence_1 = { 83c404 83c001 50 8b553c 52 8b45e4 }
		$sequence_2 = { 837df800 7630 8b45f8 33d2 b90a000000 }
		$sequence_3 = { 83c408 85c0 7507 33c0 e9???????? 8b55fc 8b02 }
		$sequence_4 = { 8b4d0c 83c101 894d0c 8b5510 83ea01 895510 eb94 }
		$sequence_5 = { f7f1 8945f8 ebca 837d0800 7d09 }
		$sequence_6 = { 64a1c0000000 8945fc 837dfc00 7409 c745f801000000 eb07 c745f800000000 }
		$sequence_7 = { 8b4508 0fb708 83c102 8b5508 66894a02 8b4508 8b4d0c }
		$sequence_8 = { 50 e8???????? 83c410 83f801 740e }
		$sequence_9 = { 0f8405010000 837f2800 0f84fb000000 8b772c }
		$sequence_10 = { 5d c3 c7471c18000000 8b4dfc 33c0 5f 5e }
		$sequence_11 = { 33c9 03ff 3bc8 72f8 }
		$sequence_12 = { 50 8d0c76 c1e104 03cf }
		$sequence_13 = { 5b 8be5 5d c3 85f6 747e }
		$sequence_14 = { 53 8b5d08 56 8bf1 894df4 }
		$sequence_15 = { 6a0a 68???????? 8b07 8b7004 8bce ff15???????? 8bcf }

	condition:
		7 of them and filesize < 2160640
}
rule MALPEDIA_Win_Carbanak_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "87afcd86-b092-5982-9a49-b0f86e137b04"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.carbanak"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.carbanak_auto.yar#L1-L123"
		license_url = "N/A"
		logic_hash = "a9782bee770cd7a549efc54b72e4d02e58c890c817db39e9a939f3dfa02868ed"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 7c0d e8???????? 84c0 7504 }
		$sequence_1 = { 85c0 7509 e8???????? b001 }
		$sequence_2 = { 3d2c5c0700 750a e8???????? e9???????? }
		$sequence_3 = { 7907 32c0 e9???????? 7507 b001 }
		$sequence_4 = { e8???????? 488bf8 4885c0 742e 488b0d???????? }
		$sequence_5 = { 488b8df0010000 e8???????? 488d4c2448 33d2 }
		$sequence_6 = { 488bcb 488bf8 e8???????? 4533c0 4c8bcf 488d15ba140000 }
		$sequence_7 = { 8bec 51 51 56 8d45f8 68???????? 50 }
		$sequence_8 = { be00010000 56 8d85d0fcffff 50 8d8dc0fcffff }
		$sequence_9 = { 50 57 6a1e 56 897d08 }
		$sequence_10 = { 8bec 8d4524 50 ff7520 ff751c ff7518 ff7514 }

	condition:
		7 of them and filesize < 658432
}
rule MALPEDIA_Win_Comebacker_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "e119fe80-e931-59b2-a0df-ba4655d3059b"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.comebacker"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.comebacker_auto.yar#L1-L159"
		license_url = "N/A"
		logic_hash = "7ac28f4f8982baed8af383f3eb16ca161cba1a05edc53e16ecdd7cc29838d498"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 6683f809 7f04 0430 eb02 }
		$sequence_1 = { e8???????? e8???????? 8bf8 b867666666 }
		$sequence_2 = { 4889742440 e8???????? 488bf0 4885c0 0f84a3010000 488b4b08 }
		$sequence_3 = { 4c8d054fb70300 41b93b020000 8d4aeb e8???????? b801000000 }
		$sequence_4 = { 448bc6 442bc0 488b442450 488d0d57be0600 488b0cc1 44897c2444 }
		$sequence_5 = { 498d4e07 448d4210 e8???????? 448be0 }
		$sequence_6 = { 48894370 4885c0 7529 4c8d0ddce80300 8d507b 8d4806 }
		$sequence_7 = { 486bd258 490394c140480a00 f6423880 742b e8???????? }
		$sequence_8 = { e8???????? 83c40c 8d8d8cf6ffff 51 8d55e8 52 }
		$sequence_9 = { 6aff 68???????? 6800020000 53 ff15???????? e8???????? 3bc3 }
		$sequence_10 = { 6a00 6a00 8bf0 8d8570ffffff 6a00 50 e8???????? }
		$sequence_11 = { 8944242c 8b1c9538500410 8b542414 c1ea18 }
		$sequence_12 = { 83c43c 8903 5f 8bc6 33cd 5e }
		$sequence_13 = { 03c0 8d9dc8f8ffff 8985c8f8ffff e8???????? 8bbdc8f8ffff 6802200300 }
		$sequence_14 = { 8b0485e01f0910 c644080401 57 e8???????? }

	condition:
		7 of them and filesize < 1429504
}
rule MALPEDIA_Win_C2Looper_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "60936376-e962-5170-8290-ff2ed44998bb"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.c2looper"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.c2looper_auto.yar#L1-L133"
		license_url = "N/A"
		logic_hash = "f07ab9165079f12138712a1a7cef116b365503e12dfc9fdfb611f9f901651717"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 4889f0 4c29f0 4e8d3c37 4c897c2448 4889442450 48c744245800000000 4889442460 }
		$sequence_1 = { be00100000 90 41803c30bf 0f8f74ffffff 41807c30ffbf 0f8f2d010000 41807c30febf }
		$sequence_2 = { b802000000 488985d0030000 31ff 31f6 31db 4981f801020000 7322 }
		$sequence_3 = { 4885c0 0f84d5100000 440f1108 c7401072696162 66c740146c65 c6401657 48c78424e001000017000000 }
		$sequence_4 = { 0fb6d2 83c2d0 83fa0a 0f8387000000 48ffc1 6601d0 73d3 }
		$sequence_5 = { 4d39fe 0f84c0fdffff 4c01d7 66662e0f1f840000000000 f30f6f13 f30f6f5b10 660f6fe2 }
		$sequence_6 = { 4d89f8 4531c9 ffd0 4889442470 4883bc24f000000000 7414 ff15???????? }
		$sequence_7 = { 41b802000000 488d1589eb0000 ff5018 49ffc7 b101 4939ff 0f85f7fcffff }
		$sequence_8 = { 0f8cc1070000 48ffc7 49ffce 4d89f5 4889fb 4d85f6 7441 }
		$sequence_9 = { 4889442420 4c89f1 4c89fa e8???????? 0f0b 55 }

	condition:
		7 of them and filesize < 271360
}
rule MALPEDIA_Win_Agendacrypt_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a3424fca-e455-5f67-b7fd-2f16981bd154"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.agendacrypt"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.agendacrypt_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "e28b889cd4b5713bec99e5dcfa78e867a4bac2a36cabae5d62175c1b0287c17e"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 5e 5f 5b 5d c3 6a04 }
		$sequence_1 = { c745dc00000000 c745f000000000 e9???????? 0fb64103 8b5dd8 3c2f 0f45f0 }
		$sequence_2 = { eb24 83c202 39d9 be02000000 0f45ca 662e0f1f840000000000 90 }
		$sequence_3 = { 8d4e24 e8???????? 83feff 7415 f0ff4e04 750f a1???????? }
		$sequence_4 = { b8???????? e9???????? 31f6 31db 837c240404 77a2 83042408 }
		$sequence_5 = { eb06 8b75e4 8b4dd0 f20f1045c0 89d0 42 894dd0 }
		$sequence_6 = { e9???????? 8b7508 83e3fc baabaaaaaa 897dc8 894de8 8d041e }
		$sequence_7 = { c1c110 018d24ffffff 894dec 8b8d28ffffff 3145a0 8b45e0 c145a010 }
		$sequence_8 = { 8d542468 8d8c24f0030000 6a00 e8???????? 83c404 8b8424f0030000 83f802 }
		$sequence_9 = { ff742454 e8???????? 83c408 85c0 7408 39d6 7204 }

	condition:
		7 of them and filesize < 3340288
}
rule MALPEDIA_Win_Sword_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "e56fc473-b1b6-501b-aeb7-ef5ae56ac83d"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.sword"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.sword_auto.yar#L1-L124"
		license_url = "N/A"
		logic_hash = "30f0c4e367cd7d968dab2e3cd6db1e620abc706992eec1c72c2add2debae898b"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 49 807c29ff22 7510 8bfd 83c9ff 33c0 f2ae }
		$sequence_1 = { eb05 1bc0 83d8ff 3bc3 0f8403010000 8bfd 83c9ff }
		$sequence_2 = { 0f8480020000 8d4c2428 6a5c 51 e8???????? 8d542430 }
		$sequence_3 = { 83ff03 7d22 8d4c2410 6a10 51 56 ffd3 }
		$sequence_4 = { 52 e8???????? 83c40c 85c0 0f856f050000 8a8c2496060000 }
		$sequence_5 = { 89842478010000 ff15???????? 8dbc2484020000 83c9ff }
		$sequence_6 = { 83e103 f3a4 8d442428 6a5c 50 }
		$sequence_7 = { 8bf0 e8???????? 83c410 3bf0 7431 68???????? e8???????? }
		$sequence_8 = { 8dbc2494060000 83c9ff 33c0 f2ae f7d1 49 }
		$sequence_9 = { 49 885c0c27 807c242822 7525 8d7c2429 }

	condition:
		7 of them and filesize < 106496
}
rule MALPEDIA_Win_Zeroaccess_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "dde43315-86ba-57e2-b565-b42a078b12ac"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.zeroaccess"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.zeroaccess_auto.yar#L1-L153"
		license_url = "N/A"
		logic_hash = "eb004d741ba51d9054aea3525ab8d73915db7383c7ad2509d9118d5c6f8f74f8"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 85c0 7408 ff15???????? eb02 }
		$sequence_1 = { ff7308 ff15???????? 85c0 7408 }
		$sequence_2 = { 6a04 68???????? 6a10 68???????? 68060000c8 ff7708 ff15???????? }
		$sequence_3 = { 50 6a01 8d45f4 50 ff7308 }
		$sequence_4 = { 56 68???????? 50 8d460c 50 ff15???????? 85c0 }
		$sequence_5 = { 33c0 48 83c9ff c744242804000000 48 }
		$sequence_6 = { 6a01 8d45f8 50 57 ff15???????? 84c0 }
		$sequence_7 = { 56 8d45f8 50 ff15???????? 6a01 8d45f8 50 }
		$sequence_8 = { 740c bf03000040 eb05 bf010000c0 85ff }
		$sequence_9 = { 3bc1 7604 83c8ff c3 }
		$sequence_10 = { ff15???????? 85c0 7407 b8e3030000 }
		$sequence_11 = { 49 8b8080000000 49 8941f4 41 }
		$sequence_12 = { 6548 891c25???????? 8bf0 ff15???????? 48 8d542470 48 }
		$sequence_13 = { 44 0fb61d???????? 0fb61d???????? 0fb63d???????? 0fb635???????? 0fb72d???????? 44 }

	condition:
		7 of them and filesize < 464896
}
rule MALPEDIA_Win_Ariabody_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "90708696-a5a3-5095-887b-3befe0130e6a"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.ariabody"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.ariabody_auto.yar#L1-L161"
		license_url = "N/A"
		logic_hash = "7c9d5898e6a842245df8daf244559b5fcc5f5d7e5b548cc9b061539eb9d266df"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 83ec50 53 57 8bd9 e8???????? }
		$sequence_1 = { 2bd1 8a01 84c0 7406 }
		$sequence_2 = { 8901 33c0 40 5b 5e }
		$sequence_3 = { 8bcf 0fb6c0 50 ff75fc e8???????? }
		$sequence_4 = { 8bf2 56 8d55fc 03f9 e8???????? 59 }
		$sequence_5 = { 84c0 7406 3ac3 7402 32c3 }
		$sequence_6 = { eb13 8b16 8bcf e8???????? }
		$sequence_7 = { 03c7 50 ff5204 8b1e 8bd0 }
		$sequence_8 = { 4889f9 488d141e 440f46c5 4533c9 }
		$sequence_9 = { 4889ce 4d89c4 33d2 41b800010000 }
		$sequence_10 = { 8bc3 483bd0 0f871a050000 4c8d151d8bffff }
		$sequence_11 = { 41b800100000 41b904000000 41ff5710 4989c5 33c9 }
		$sequence_12 = { 4889e0 4889f1 450fb64d00 4889f2 450fb66d01 }
		$sequence_13 = { 4c8d35acd20000 49833cde00 7407 b801000000 eb5c b928000000 }
		$sequence_14 = { 8bd9 7418 488d0daf130100 e8???????? 85c0 7408 8bcb }
		$sequence_15 = { 4c89e9 33d2 41b800800000 41ff5718 4c89e1 }

	condition:
		7 of them and filesize < 253952
}
rule MALPEDIA_Win_Zeus_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "b5309aef-9a51-54ca-a505-adbb97bdea7f"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.zeus"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.zeus_auto.yar#L1-L223"
		license_url = "N/A"
		logic_hash = "bb879aaaa33ec63ba64775e7090d47440d3c7ed35fc000533916956fa887541b"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { eb58 833f00 7651 8b5f08 }
		$sequence_1 = { 8b4804 81e1000000e0 394c240c 740d }
		$sequence_2 = { c6451700 8b5d10 3bde 7503 8d5d10 39750c }
		$sequence_3 = { 8d7708 8975fc e8???????? 8d4720 }
		$sequence_4 = { eb21 ff7514 8bc6 57 }
		$sequence_5 = { 84c0 7467 8b5d10 83e301 33ff 3bdf }
		$sequence_6 = { 8d7708 83c720 57 8d45f4 50 8d45f8 50 }
		$sequence_7 = { e8???????? 8b4808 8b32 8d4c3110 81f90000a000 7715 8918 }
		$sequence_8 = { 891d???????? 891d???????? ffd6 68???????? }
		$sequence_9 = { e8???????? 84c0 7442 6a10 }
		$sequence_10 = { 8bf3 6810270000 ff35???????? ff15???????? }
		$sequence_11 = { 8d8db0fdffff e8???????? 8ad8 84db }
		$sequence_12 = { c20400 55 8bec f6451802 }
		$sequence_13 = { 56 ff15???????? 5e 8ac3 5b c20800 55 }
		$sequence_14 = { 8d75a8 b8d5000000 e8???????? 68e6010000 68???????? 6809080002 }
		$sequence_15 = { b9???????? 56 57 33f6 56 50 68???????? }
		$sequence_16 = { 6809080002 8bc6 50 8d45fc 50 e8???????? }
		$sequence_17 = { eb18 81fb5a5c4156 740c 81fb45415356 }
		$sequence_18 = { 894736 8d470c 50 c707000e0000 c7470809080002 e8???????? 83674200 }
		$sequence_19 = { 3d59495351 0f85ca000000 807b0420 0f85c0000000 33c0 83c6fb }
		$sequence_20 = { 83fe06 0f86e3000000 8b03 3509080002 3d5c5b4550 }
		$sequence_21 = { 84c0 0f84ac000000 b809080002 3945f4 7713 807d0801 }
		$sequence_22 = { 83fe04 0f82ec000000 8b1b 81f309080002 }

	condition:
		7 of them and filesize < 319488
}
rule MALPEDIA_Win_Unidentified_061_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "59888b60-a3e6-5e9f-a441-429646fe0731"
		date = "2023-07-11"
		modified = "2023-07-15"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.unidentified_061"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.unidentified_061_auto.yar#L1-L123"
		license_url = "N/A"
		logic_hash = "ee3ce5b6c77f09c690f7a934c26be09c58c4fcdee70275b61c00e527d8aa097d"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20230705"
		malpedia_hash = "42d0574f4405bd7d2b154d321d345acb18834a41"
		malpedia_version = "20230715"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8d85d4fdffff 50 e8???????? c9 }
		$sequence_1 = { 89b5f0fdffff 899decfdffff 89b5f4feffff 899df0feffff ff15???????? 8945fc }
		$sequence_2 = { 51 8365fc00 8d45fc 50 68???????? 6801000080 ff15???????? }
		$sequence_3 = { 8945f0 0fb705???????? 50 ff15???????? 668945ee }
		$sequence_4 = { 68???????? 56 ff15???????? 83c41c 8d4601 5e eb09 }
		$sequence_5 = { 7417 03f3 3bf7 7ccb eb2f 7d29 }
		$sequence_6 = { 83cfff c6457300 3b7566 7cb5 3b7566 }
		$sequence_7 = { 53 57 6a04 33ff 33db }
		$sequence_8 = { 5b c9 c20800 81ec00040000 68???????? 68???????? ff15???????? }
		$sequence_9 = { eb04 c645fb3d 6a05 8d45f8 50 ff750c c645fc00 }

	condition:
		7 of them and filesize < 360448
}
rule MALPEDIA_Win_Nighthawk_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "6072f6bd-7d96-524f-911f-546009db5a42"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.nighthawk"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.nighthawk_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "8473d340e4cb6ede2ba7e07ffb3d9a38744cba7adf1223dfb1fb21f4629f4fe4"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 83780803 0f85a9070000 4889742460 48897c2478 48897c2470 448bc7 488d1538600500 }
		$sequence_1 = { bf02000000 488365b800 488365c800 488365d000 41b820000000 488bd3 488d4db8 }
		$sequence_2 = { e8???????? 90 488b4d6f ff15???????? bf04000000 8bc7 4c8d9c2490000000 }
		$sequence_3 = { 85c0 0f8495000000 4c8b5750 4c03d0 410fb652ff 413a12 0f8580000000 }
		$sequence_4 = { 7405 e8???????? 48899fc0000000 48c787c800000007000000 66899fb0000000 488d0525fc0900 488907 }
		$sequence_5 = { 48c7c6fcffffff eb19 488d340a 493bf6 731d 498bf6 48c1e602 }
		$sequence_6 = { 7406 e8???????? 90 498bd7 488d4d30 e8???????? e8???????? }
		$sequence_7 = { ff15???????? 8bd8 488b442470 498906 4c8d9c2430010000 8bc3 498b5b28 }
		$sequence_8 = { 7421 4183e4fb 4489a5f0000000 48837da010 720f 488b4d88 4885c9 }
		$sequence_9 = { 4c8d4d50 41b804000000 48895c2420 488d5558 ff15???????? 85c0 74b8 }

	condition:
		7 of them and filesize < 1949696
}
rule MALPEDIA_Win_Graftor_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "6a0f832c-5261-57bc-9f0c-035c8570ef5a"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.graftor"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.graftor_auto.yar#L1-L129"
		license_url = "N/A"
		logic_hash = "c4a0b7d07029d23c004a098aa94257750f7dcb182db2623766a0c0472ed9b024"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff15???????? 85c0 0f8446020000 ffb574d7ffff 8d85f0d7ffff 50 8db548d7ffff }
		$sequence_1 = { 8db4246c010000 c684245803000075 e8???????? e8???????? 399c2424010000 }
		$sequence_2 = { 897c2414 895c2410 395e14 7511 687ce14c00 e8???????? 8bc7 }
		$sequence_3 = { e8???????? 393d???????? 7513 83ec1c 8bf4 89642444 }
		$sequence_4 = { 8d8578ffffff 50 8d85d4feffff 68c8aa4d00 50 c645fc0a e8???????? }
		$sequence_5 = { ff15???????? ff75fc 8b35???????? ffd6 8d45fc 50 ff75ec }
		$sequence_6 = { 50 51 c645fc03 e8???????? 8b0d???????? 83c40c e8???????? }
		$sequence_7 = { 85c0 7c23 8b7dec 240f c0e304 0ac3 0fb6c0 }
		$sequence_8 = { ff5144 85c0 0f8cd5f8ffff 8b857cffffff 8d956cffffff 52 }
		$sequence_9 = { a1???????? 33c5 8945fc 8b4508 83a5f4dfffff00 83781808 }

	condition:
		7 of them and filesize < 294912
}
rule MALPEDIA_Win_Powershellrunner_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "2aa19212-d931-5213-873b-9012d2904211"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.powershellrunner"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.powershellrunner_auto.yar#L1-L129"
		license_url = "N/A"
		logic_hash = "ee277fc6278090f9f5b2e5892dd816d06bf63130d46572da2e87ef48775f9eb1"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 4c8d0527b30000 e8???????? 488bcb 4885c0 740a }
		$sequence_1 = { 0fb6c0 85c0 7532 488b442420 4883e804 4c8bc0 }
		$sequence_2 = { eb67 488b442428 4889442438 eb0a 488b442438 4889442428 488b442438 }
		$sequence_3 = { c684248900000065 c684248a00000074 c684248b00000053 c684248c00000065 c684248d00000063 c684248e00000075 c684248f00000072 }
		$sequence_4 = { 8d7010 eb20 41b807000000 488d1531c70000 488bcf }
		$sequence_5 = { 488b442430 4889442428 488b4c2430 e8???????? 8b00 89442420 4c8b442450 }
		$sequence_6 = { 488d0581db0000 488945bf 448d59ff 488945c7 488d0572db0000 488945cf 488945d7 }
		$sequence_7 = { 6689842402010000 b83b000000 6689842404010000 b84e000000 6689842406010000 b857000000 6689842408010000 }
		$sequence_8 = { e8???????? 488b442450 eb2b 488d442420 488bf8 33c0 b901000000 }
		$sequence_9 = { ff942428030000 488b8c2430030000 48894130 488d542448 488b4c2428 ff942428030000 488b8c2430030000 }

	condition:
		7 of them and filesize < 458752
}
rule MALPEDIA_Win_Shujin_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "39445a8c-8766-5eb7-a5db-45f2f874e8dd"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.shujin"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.shujin_auto.yar#L1-L123"
		license_url = "N/A"
		logic_hash = "c1835af96b80cdd5266c74b8df5c5e78806b51d50fa8c84e26364a84d9b80fcd"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 83c444 33c0 c9 c3 55 }
		$sequence_1 = { 8144241404210000 8b50e8 3350fc 8b68ec 33ea 896804 8910 }
		$sequence_2 = { c3 2d00100000 8500 ebe9 55 8bec 6a10 }
		$sequence_3 = { 75c4 8b45fc 8b4df8 8918 }
		$sequence_4 = { 0101 8b31 8975e4 115104 8b4104 83615000 83615400 }
		$sequence_5 = { 59 56 8bd8 ff15???????? 3bdf }
		$sequence_6 = { e8???????? 6a05 8d8e74040000 e8???????? 8b45f8 8145f822010000 }
		$sequence_7 = { 8b7df8 c1ef08 c1eb10 23f8 8b3cbde89d4000 23d8 333c9de8994000 }
		$sequence_8 = { 68c5000000 ffb714040000 ffd3 8db7f4030000 e8???????? 8d85fcfeffff 50 }
		$sequence_9 = { 8d45a4 894558 8d850cffffff 83c418 }

	condition:
		7 of them and filesize < 172032
}
rule MALPEDIA_Win_Rusty_Claw_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "e2450fb6-696c-599e-951e-32c9ca3ad113"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.rusty_claw"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.rusty_claw_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "0044c74914ed6358d74e6d6895c22c966231737c9d0ca00240dbb97ba8e95245"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 31c9 89f2 c645e301 c745f001000000 e8???????? 0f0b }
		$sequence_1 = { 8d742410 8d442430 8930 c74004???????? 894808 c7400c29a64000 8d742408 }
		$sequence_2 = { e8???????? 83c40c 8b4dd4 8b55c8 e8???????? 8b4da4 8b55a8 }
		$sequence_3 = { c3 55 83ec0c 8db524fbffff 8baec8040000 8b4e20 8b5624 }
		$sequence_4 = { 0f84e6020000 85d2 8915???????? 0f84d8020000 ffd2 8b15???????? 89c6 }
		$sequence_5 = { 894808 89700c 8b4a14 8b5218 50 eb2a 8b4500 }
		$sequence_6 = { 58 59 8b4304 833b00 7406 8b742414 }
		$sequence_7 = { 8945e0 c6411001 83c01c 8365f000 89c1 e8???????? }
		$sequence_8 = { 6a1f 8975e0 56 e8???????? 6a00 6a00 6a00 }
		$sequence_9 = { 89e2 56 50 8d742428 56 e8???????? }

	condition:
		7 of them and filesize < 518144
}
rule MALPEDIA_Win_Hermes_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "75b421e1-da62-5c57-b2d2-788db7fdba84"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.hermes"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.hermes_auto.yar#L1-L110"
		license_url = "N/A"
		logic_hash = "7ff10d8c8cb6d516c953cedfa368fa6be2a141161ae17f8b79a55213e4e93d6c"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 6a04 6800100000 6888130000 6a00 }
		$sequence_1 = { 83c801 50 6a01 ff75fc }
		$sequence_2 = { ff15???????? 6a07 59 be???????? }
		$sequence_3 = { 33d2 6a79 59 f7f1 }
		$sequence_4 = { 8b4508 83c801 50 6a01 ff75fc ff15???????? }
		$sequence_5 = { 7508 6a01 ff15???????? 8be5 5d }
		$sequence_6 = { 6a04 6800100000 6888130000 6a00 ff15???????? }
		$sequence_7 = { 50 8d45fc 50 ff15???????? 6a20 }
		$sequence_8 = { 6a01 6810660000 ff75fc ff15???????? 85c0 }
		$sequence_9 = { ff15???????? 33d2 6a79 59 }

	condition:
		7 of them and filesize < 7192576
}
rule MALPEDIA_Win_Unidentified_031_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "550525ad-6505-5cc9-bce3-e9adeee670a2"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.unidentified_031"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.unidentified_031_auto.yar#L1-L133"
		license_url = "N/A"
		logic_hash = "820e0e2616702766d04ff2348ab4bfeaf71d6d6e6b09ea29735d04fe4c058924"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff750c 8d8d08ffffff ff7508 e8???????? 85c0 754c 8d4de0 }
		$sequence_1 = { 8902 8b8554ffffff 898d58ffffff 83ec10 894204 8b8558ffffff 8b3d???????? }
		$sequence_2 = { 8bcb e8???????? 8bf0 85f6 0f8c46010000 85ff 7439 }
		$sequence_3 = { ff75ec 50 e8???????? 85c0 740f 83667800 }
		$sequence_4 = { 898500020000 53 8d8508020000 50 c7850402000010d01800 ffd6 6a70 }
		$sequence_5 = { 8b7de4 8b5114 8b4110 83c706 0f802f090000 2bfa 3bf8 }
		$sequence_6 = { c21000 ff742410 ff742410 ff742410 6800000200 ff742414 e8???????? }
		$sequence_7 = { 689c030000 68???????? 51 50 ff15???????? 8d4de8 ff15???????? }
		$sequence_8 = { 8bf8 33db e9???????? 8b5508 8d8d30ffffff 51 8d8d20ffffff }
		$sequence_9 = { 50 8d8dd0feffff 51 8d95f0feffff 52 8d8500ffffff 50 }

	condition:
		7 of them and filesize < 1998848
}
rule MALPEDIA_Win_Usbferry_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a98fcb7e-1f5d-5f51-b761-4fed3b28ae1f"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.usbferry"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.usbferry_auto.yar#L1-L162"
		license_url = "N/A"
		logic_hash = "767ca9e538e8e2a21380cdf20fea94320ecaba1eb7edfad8a59063fbcd5c80af"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 68ff030000 6a00 8d8da5f5ffff 51 }
		$sequence_1 = { 84c0 75f9 8d45e9 2bf8 }
		$sequence_2 = { 6a03 ba???????? 8938 e8???????? 59 85c0 752e }
		$sequence_3 = { 77f5 897dfc 660f2fca 720e f20f59cd 47 }
		$sequence_4 = { 8d85f8fbffff 50 a1???????? ff5024 }
		$sequence_5 = { c685a9faffff61 c685aafaffff73 c685abfaffff6b c685acfaffff6b c685adfaffff69 c685aefaffff6c }
		$sequence_6 = { 89857cf5ffff 899578f5ffff 8d8da8faffff 83c1ff }
		$sequence_7 = { 80bda3f5ffff00 75e2 8b859cf5ffff 2b858cf5ffff }
		$sequence_8 = { 89467c 85ff 742a 3807 7426 }
		$sequence_9 = { 837d1404 7547 6a04 8d4d1c 51 }
		$sequence_10 = { 57 e8???????? 8b54241c 83c40c 03fe 33f6 }
		$sequence_11 = { c645b872 c645b96f c645ba73 c645bb6f }
		$sequence_12 = { c645f664 c645f720 c645f82f c645f963 c645fa20 c645fb00 }
		$sequence_13 = { ff7110 8b9188000000 898184000000 8b09 }
		$sequence_14 = { 7413 83f910 7505 83ef02 eb06 }
		$sequence_15 = { 8b4de0 51 ff15???????? c745c000000000 6afe 8d55f0 }

	condition:
		7 of them and filesize < 638976
}
rule MALPEDIA_Win_Hemigate_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "5d2fdcf5-3d02-5d15-85ef-ecbf1b82bae7"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.hemigate"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.hemigate_auto.yar#L1-L133"
		license_url = "N/A"
		logic_hash = "a18de920c0b3e8a84f609a787bdb9ee34bf9faaa3678ac0121c8613dba57f64c"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 83c404 33f6 eb55 8b07 803801 7534 }
		$sequence_1 = { 50 e8???????? 83c408 8bcf 85c0 0f44f9 8bdf }
		$sequence_2 = { 85c0 7454 8b5dd4 8d7e01 4b 3bdf 7c3a }
		$sequence_3 = { 8b550c 8d45d4 50 8d8fa8000000 e8???????? 8b55cc 8d8fb8110100 }
		$sequence_4 = { c685c4efffff00 8d95c4efffff 6a01 eb1a 8b85a4efffff 50 ffd3 }
		$sequence_5 = { c1e910 885014 c1ea18 884816 885017 8b5588 8bca }
		$sequence_6 = { 833d????????00 0f841f010000 6a00 8d4618 c70600000000 50 8d4e14 }
		$sequence_7 = { 99 81e2ff000000 03c2 c1f808 88440b01 8b8d94efffff }
		$sequence_8 = { 66c745d00000 8d55d0 c645d200 8bcf 6a03 e8???????? 83c404 }
		$sequence_9 = { c3 ff75f8 ff15???????? 83c404 5f 5e b80d000000 }

	condition:
		7 of them and filesize < 991232
}
rule MALPEDIA_Win_Casper_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "dece789a-a5ee-5716-a2d0-f66c2a3118e3"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.casper"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.casper_auto.yar#L1-L130"
		license_url = "N/A"
		logic_hash = "f57a2d8fa3206fe2385bcec6a2b09dd8bfb1a16c461b69fab1a21615e575c7ce"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b36 85f6 0f84b3000000 6a28 c6431001 e8???????? }
		$sequence_1 = { 84c0 75f1 8b4d08 52 ff7510 ff750c e8???????? }
		$sequence_2 = { 8a11 83600400 832000 84d2 7428 80fa3c }
		$sequence_3 = { 53 33db 57 895dfc 895df4 895df8 395d08 }
		$sequence_4 = { 741b 3c2f 741b e8???????? 85c0 7445 ff7508 }
		$sequence_5 = { ff700c 8d8560fbffff 68???????? 50 e8???????? 8b430c }
		$sequence_6 = { 7414 8d8d60cbffff 8bf8 51 8d8564ffffff e8???????? 8b8568ffffff }
		$sequence_7 = { 8dbc2480020000 f3a5 8b8c2490020000 038c24cc010000 8bb368010000 33d2 8bc1 }
		$sequence_8 = { 85db 7433 56 8bfb 8bc1 e8???????? }
		$sequence_9 = { 68???????? 8bf8 e8???????? 59 8d4dfc 51 6a01 }

	condition:
		7 of them and filesize < 434176
}
rule MALPEDIA_Win_Royalcli_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "6a2fcc32-4a7e-5866-808e-a6977e876823"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.royalcli"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.royalcli_auto.yar#L1-L124"
		license_url = "N/A"
		logic_hash = "e1b962bcc6905e27d26d9bbc6c0bb3030ed968429d5292684e4f49ce134a6b92"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 85c0 0f84cf000000 8b3d???????? 50 ffd7 6a00 6880000000 }
		$sequence_1 = { ffd6 8d8df4f6ffff 51 ffd6 }
		$sequence_2 = { 55 8bec 81ec30090000 a1???????? 33c5 8945f8 8b4508 }
		$sequence_3 = { 8d459c 50 c644759c00 68???????? 8d959cf7ffff c644759d00 }
		$sequence_4 = { 83c404 8d95ccfeffff 52 6a14 8985b0f9ffff }
		$sequence_5 = { 356699aa55 03c2 8db078563412 81f66699aa55 33ff 03f1 }
		$sequence_6 = { 721a 8b3c06 3b38 7508 83e904 83c004 }
		$sequence_7 = { 6a00 57 e8???????? 83c40c 8d85a4feffff }
		$sequence_8 = { 741d 50 ff15???????? b801000000 5f 5e 5b }
		$sequence_9 = { 8b4508 8bc8 83e01f c1f905 8b0c8dc04b4100 c1e006 8d44010c }

	condition:
		7 of them and filesize < 204800
}
rule MALPEDIA_Win_Socelars_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "ddd41191-aad6-5360-8adf-f9defb66345a"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.socelars"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.socelars_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "d4918e07f86ed792d4b6e54dfae955b9b6ada5253b95b2c93eee2ce5aba7ce77"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e9???????? 8b542424 8d4601 898388000000 8d0cb6 8b4358 42 }
		$sequence_1 = { ff742458 6a00 e8???????? 83c410 8b5c2438 33c0 8b54240c }
		$sequence_2 = { ff15???????? 8b4dfc 8981a4000000 68???????? 8b55e8 52 ff15???????? }
		$sequence_3 = { ff742414 e8???????? 83c408 85c0 7411 50 8bd3 }
		$sequence_4 = { e9???????? 8bcf e8???????? 8bf0 e9???????? 83bd14feffff00 0f849e000000 }
		$sequence_5 = { e8???????? 8bf8 83c408 897c2414 85ff 0f842e020000 33f6 }
		$sequence_6 = { ff742460 ba6c000000 8bcf e8???????? 83c40c 89842498000000 eb32 }
		$sequence_7 = { ff7004 e8???????? 8b7dd4 8bf0 8b4dbc 56 ff7704 }
		$sequence_8 = { ff7508 e8???????? 83c408 85c0 7426 8b442410 ff442418 }
		$sequence_9 = { ff742424 6aff e8???????? 83c410 89442414 3b472c 7e03 }

	condition:
		7 of them and filesize < 2151424
}
rule MALPEDIA_Win_Mltbackdoor_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "459cb97b-c73f-5d3f-aee9-950ab01992c7"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.mltbackdoor"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.mltbackdoor_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "29af63dc09bb6d2e75d8e5364c466f9a411952c1d70eceeb089524caf717213b"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c1e104 8d0489 29c2 416bc0af 8d0c02 83c1af 01c2 }
		$sequence_1 = { e9???????? 488b4c2458 4889f2 e8???????? c744243400000000 8b0d???????? 89ca }
		$sequence_2 = { ffc8 446bd047 f7d0 6bc046 4401d0 4101c0 4181c0ab000000 }
		$sequence_3 = { c1e607 8d34be 89d7 21cf 41f7d3 4569db83000000 4101f3 }
		$sequence_4 = { bad50c2236 e8???????? 4c8b542468 4c89a42418010000 66490f6ec4 4c89ac2468010000 66490f6ecd }
		$sequence_5 = { f7d2 6bca38 6bc039 01c8 0527deffff f7d0 05c6921e9f }
		$sequence_6 = { f7d0 6bc088 456bc189 4401c0 0522ddffff 6bc9e2 4189d0 }
		$sequence_7 = { f7d0 6bc07c 01c8 83c07b 6bc863 f7d0 6bc062 }
		$sequence_8 = { f7d1 89ca 81e2f97eaf02 81e10681507d 4189c0 4181e0f97eaf82 8d14d2 }
		$sequence_9 = { f7d1 89c7 09cf 4589d9 4121d1 4589d8 4121c8 }

	condition:
		7 of them and filesize < 3367936
}
rule MALPEDIA_Win_Gandcrab_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "29847fcc-09b3-527d-b0dd-7d9125e9fd15"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.gandcrab"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.gandcrab_auto.yar#L1-L119"
		license_url = "N/A"
		logic_hash = "d6408193f403eb315d602bf948832f41b6cf91854d92f9adf01b14244cc3a2c5"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 03d8 837f2400 741b ff772c }
		$sequence_1 = { ff772c ff15???????? ff7728 8bf0 ff15???????? 03c3 }
		$sequence_2 = { 837f4800 741b ff7750 ff15???????? ff774c }
		$sequence_3 = { 03c3 8d5e04 03d8 837f3000 741b ff7738 }
		$sequence_4 = { ff15???????? ff7728 8bf0 ff15???????? 03c3 8d5e04 }
		$sequence_5 = { 8d5e04 03d8 837f2400 741b ff772c }
		$sequence_6 = { 03d8 837f3000 741b ff7738 ff15???????? ff7734 8bf0 }
		$sequence_7 = { ff772c ff15???????? ff7728 8bf0 ff15???????? 03c3 8d5e04 }
		$sequence_8 = { 03c3 8d5e04 03d8 837f5400 741b }
		$sequence_9 = { 837f3c00 741b ff7744 ff15???????? }

	condition:
		7 of them and filesize < 1024000
}
rule MALPEDIA_Win_Katz_Stealer_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "8f77903c-7dc7-5a03-abcc-e7b9063e1b00"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.katz_stealer"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.katz_stealer_auto.yar#L1-L133"
		license_url = "N/A"
		logic_hash = "6ad6042323c4518b83e571baa79395572c61d59ef0516fab27d6a9ed81c23694"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 41ffd4 85c0 0f8e8f010000 4898 4889e9 488d157ec20000 c68404101a000000 }
		$sequence_1 = { 0f85f1feffff 4c89f1 ff15???????? e9???????? 4c89742420 4d89e1 4c8d0508750000 }
		$sequence_2 = { 8b9c2488000000 4889d7 4c89c6 4d89cb 81fbff1f0000 7751 }
		$sequence_3 = { 4d85db 0f856e020000 4181f97a000780 7575 4883bc24a000000000 7410 488b442450 }
		$sequence_4 = { ffd6 41b804010000 488d0d983e0000 488d94249c020000 ffd6 488d442470 4531c0 }
		$sequence_5 = { 488d942410080000 4889d9 e8???????? 85c0 75ad 4889d9 ff15???????? }
		$sequence_6 = { 4989d8 488d9424b0130000 e8???????? 488d8c24ac120000 ff15???????? 4d89e1 4c8d0534680000 }
		$sequence_7 = { 4889d9 e8???????? 488d15eb8b0000 4989f0 4889d1 e8???????? 488d0dd98b0000 }
		$sequence_8 = { 488d0ddb390000 ffd5 488d0dda390000 488906 ffd5 488d0dce390000 48894608 }
		$sequence_9 = { ff15???????? 4883660800 488906 4883661000 eb8e 83a424e00e000000 488d9424e00e0000 }

	condition:
		7 of them and filesize < 238592
}
rule MALPEDIA_Win_Fobber_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "fd397088-d02f-5fea-81c1-d39f3c191926"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.fobber"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.fobber_auto.yar#L1-L166"
		license_url = "N/A"
		logic_hash = "8ea71943d67263c4bbad6100aa4b0189000e01bf114977dc0e65fb2098b89161"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 89e5 57 51 8b7d08 }
		$sequence_1 = { 760e 8d0431 39f8 7607 49 01cf 01ce }
		$sequence_2 = { 31c0 50 50 ff750c ff7508 }
		$sequence_3 = { 55 89e5 51 8b4510 8b5508 8b4d0c }
		$sequence_4 = { 8b7d08 57 e8???????? 85c0 740f 89c1 }
		$sequence_5 = { 8b7d08 8b750c 8b4d10 39f7 760e }
		$sequence_6 = { ff750c 6800300000 ff7508 6a00 }
		$sequence_7 = { 660fc146f9 6685c0 7515 0fb646f8 50 0fb746f6 }
		$sequence_8 = { a4 06 4f 96 }
		$sequence_9 = { 81e8ca080000 81e8e1970000 81e83e6e0100 e9???????? 81c6b8690000 }
		$sequence_10 = { 3a918d84a72f bf9cd7e94d 09d9 2817 3f }
		$sequence_11 = { 48 5e fa df9c6182a5b1b2 e8???????? }
		$sequence_12 = { 0f85c44c0100 8b4510 8945f0 663918 7419 83c002 }
		$sequence_13 = { 96 f0f266a2???????? 857f47 94 6960cf0267b974 }
		$sequence_14 = { 81eccd210000 81c4455a0000 81c42c090000 81c4ab1e0000 81ec6f790000 81ec956ffeff 81c45a1b0000 }
		$sequence_15 = { 59 663908 0f842b150100 ff07 }

	condition:
		7 of them and filesize < 188416
}
rule MALPEDIA_Win_Threebyte_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "560651ce-29cb-52d2-b2e7-d94298c0f6ef"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.threebyte"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.threebyte_auto.yar#L1-L128"
		license_url = "N/A"
		logic_hash = "323c21ac2ed070a1c9dfdbbbdf4a45e6acb70c4f044004540cd468fe2737929b"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 6a00 ff15???????? eb51 6a00 e8???????? 83c404 50 }
		$sequence_1 = { 0345f4 33c9 8a08 83f90a 7502 ebae 8b5508 }
		$sequence_2 = { 8b8d40f7ffff ff510c b8feffffff e9???????? c785a0f7ffff00000000 eb0f }
		$sequence_3 = { e9???????? 81bda4f7ffffc8000000 0f8524020000 c78580f7ffff04000000 6a00 }
		$sequence_4 = { 7407 b801000000 eb7a c645e45b c645e53e c645e63e }
		$sequence_5 = { 8b855cf7ffff ff500c 8b8d74f7ffff 51 ff15???????? 8b5514 52 }
		$sequence_6 = { 8985a8fcffff 83bda8fcffffff 0f85d7000000 6804010000 8d8ddcecffff 51 6a00 }
		$sequence_7 = { 8b55a8 8b4204 8945e4 8b4da8 8b5108 8955e8 8b45a8 }
		$sequence_8 = { e9???????? 6a07 8d8dfcfdffff 51 68???????? e8???????? 83c40c }
		$sequence_9 = { 7d66 8b4d08 038df8feffff 8b95f4feffff 8a01 }

	condition:
		7 of them and filesize < 180224
}
rule MALPEDIA_Win_Stealbit_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "3036107e-32c5-5e57-90ed-985fab665495"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.stealbit"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.stealbit_auto.yar#L1-L129"
		license_url = "N/A"
		logic_hash = "897195b8cccfa648ac0c4e8176eb9772763aef497d9250f1595d8ae9f5bbd32f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 6a73 668985eafcffff 58 6a75 668985ecfcffff 58 668985eefcffff }
		$sequence_1 = { 6a2e 668945ee 668975e4 66894de8 668975ea 58 }
		$sequence_2 = { 6683fe20 740a 6683fe2e 7506 8bd1 eb02 }
		$sequence_3 = { 6a70 668985f0fdffff 668995eefdffff 5a 6a6c 58 }
		$sequence_4 = { 8bc6 5e c3 6a25 e8???????? }
		$sequence_5 = { 668945a8 58 6a6f 668945aa 58 6a73 59 }
		$sequence_6 = { 8901 8bc1 c3 e8???????? 8901 c3 8bd1 }
		$sequence_7 = { 83e0f0 660f6f08 660f74c8 660fd7d1 d3ea d3e2 0fbcd2 }
		$sequence_8 = { 8945f8 e8???????? 03c0 8bce 8bd0 e8???????? 6a0c }
		$sequence_9 = { 0f850e020000 2bcf 69c9ff000000 8d8114faffff 2b450c 03f0 8d8114faffff }

	condition:
		7 of them and filesize < 131072
}
rule MALPEDIA_Win_Maui_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "c329ab2b-fb33-5e29-9d2c-ad53dcea6910"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.maui"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.maui_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "f235bbacb006f75c0966b23d62ef269d71bbd841a138e399d7008c5151d8ba4a"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 68???????? e8???????? 8d8c241c040000 51 68???????? 56 e8???????? }
		$sequence_1 = { f7de e8???????? 83c42c 85f6 7450 68d0000000 68???????? }
		$sequence_2 = { 83c404 85c0 751f 68c2020000 68???????? 6a26 68a3000000 }
		$sequence_3 = { 83f901 894c2414 7e70 55 8d4c2424 51 57 }
		$sequence_4 = { 7cce eb2a 8b542428 8b7c2420 8b742434 52 8a542417 }
		$sequence_5 = { 52 8b5314 8b5c2414 57 50 8b442434 52 }
		$sequence_6 = { 8a06 0fb6d0 0fb71451 f6c208 753f 8bff 0fbee8 }
		$sequence_7 = { e8???????? 83c414 85c0 7446 837e0400 7577 837c243400 }
		$sequence_8 = { 0f84ee000000 8b542420 8b44240c 57 52 53 6a00 }
		$sequence_9 = { 8bd9 57 8d7348 56 c744241800000000 e8???????? 40 }

	condition:
		7 of them and filesize < 1616896
}
rule MALPEDIA_Win_Cuegoe_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "4843ffa0-8a39-529d-978f-9c40d4d05b92"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.cuegoe"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.cuegoe_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "df7c9cc40bf19c2e521f363715b76166a4c0dabbb189fabf90623f83f5335c65"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 83c43c 53 6a09 8d8574ffffff 50 e8???????? }
		$sequence_1 = { e8???????? 83c41c 8bd8 8bc7 c645fc07 e8???????? }
		$sequence_2 = { e9???????? 8b442420 03c7 3b442440 89442420 0f8c4dffffff }
		$sequence_3 = { 89752c e9???????? 83ec18 8bc4 896548 53 50 }
		$sequence_4 = { 5b c9 c3 837c240401 7514 83791808 7205 }
		$sequence_5 = { 894c241c 8d4614 8d4c2420 3bc1 740c 8b08 8b542420 }
		$sequence_6 = { 8bf0 e8???????? 84c0 8b45c8 7403 830801 8d4dd0 }
		$sequence_7 = { 83c704 8bc7 8d4dfc 51 53 8d4d10 51 }
		$sequence_8 = { 8b4514 2bc6 40 50 8d1c37 53 }
		$sequence_9 = { 8b850c040000 33db 8bf9 894544 895d18 8d856cffffff 50 }

	condition:
		7 of them and filesize < 540672
}
rule MALPEDIA_Win_Datper_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "8dde547b-14ac-5909-8ea2-8ba3311cb366"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.datper"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.datper_auto.yar#L1-L130"
		license_url = "N/A"
		logic_hash = "211accb2feee453dfa91a20ed44ef680a0106401b3c9a92970125f09d3c94968"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 03db 83c314 8bcb 8b55d4 a1???????? e8???????? 33c0 }
		$sequence_1 = { 55 8bec 6a00 53 56 8bf1 8bd8 }
		$sequence_2 = { 33f6 33c0 89430c 33c0 894310 0fb74304 662db1d7 }
		$sequence_3 = { 68???????? 53 ff15???????? 83f801 1bc0 40 84c0 }
		$sequence_4 = { 0fb64de2 c1e106 0fb65de3 0acb 884c1001 8345f003 3b75e8 }
		$sequence_5 = { e8???????? 8d55e8 e8???????? ff75f8 68???????? }
		$sequence_6 = { 8d45e8 33c9 ba14000000 e8???????? 66c745e80100 8d043e 0fb600 }
		$sequence_7 = { 81c404f0ffff 50 48 75f6 8b45fc 81c4d8f6ffff }
		$sequence_8 = { 894dfc 33c9 894df8 4a 85d2 7c39 }
		$sequence_9 = { 807dfd00 7423 6a00 6800318080 6a00 8b4514 50 }

	condition:
		7 of them and filesize < 253952
}
rule MALPEDIA_Win_Opachki_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "078d00a3-801a-5b29-a762-4ba5605e6c9b"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.opachki"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.opachki_auto.yar#L1-L157"
		license_url = "N/A"
		logic_hash = "876c37d53e5c6616ac0918aebef86ea818ac29bfe7862118ad2bc9267c42757a"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c64401ff00 8b4608 85c0 7410 }
		$sequence_1 = { 897d0c 7422 8bd7 2bd7 035508 837d0c00 742e }
		$sequence_2 = { 8bd8 7413 8b4704 03c8 }
		$sequence_3 = { c706???????? 894608 89460c 894604 e8???????? 8bc6 }
		$sequence_4 = { 6a01 c645ff01 49 81e1feffff3f }
		$sequence_5 = { c3 55 8bec 81ec00010000 ff7508 }
		$sequence_6 = { 81ec20010000 53 56 68ff000000 8d85e0feffff }
		$sequence_7 = { 52 51 50 56 ff15???????? 85c0 0f9545ff }
		$sequence_8 = { 80fd01 7502 b701 80fd02 750a 08db }
		$sequence_9 = { 7702 88da 88c6 80e603 }
		$sequence_10 = { ad 894721 eb3f 08d2 7408 }
		$sequence_11 = { e8???????? 59 81c157010000 3c0f 7509 }
		$sequence_12 = { 08ed 7405 80fd02 7502 b704 4e 80ff01 }
		$sequence_13 = { 7505 884702 ebe9 3c2e 7414 }
		$sequence_14 = { 884701 ebf2 3cf0 7505 }

	condition:
		7 of them and filesize < 122880
}
rule MALPEDIA_Win_Neconyd_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "4ce2a3a2-91ef-5498-b04e-1aa44c029ad5"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.neconyd"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.neconyd_auto.yar#L1-L126"
		license_url = "N/A"
		logic_hash = "73be17d74e0e05d98d4f071e74b5c808944791d58294ea7516126f199b4d8dc7"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 740c 40 394510 7644 66890c47 8bd8 83f802 }
		$sequence_1 = { 6a15 8d44243c 50 ff74241c ff15???????? 89442424 }
		$sequence_2 = { 89450c 7503 897d0c 8b5d0c eb0a e8???????? }
		$sequence_3 = { 6a08 ff35???????? ffd7 8bf8 85ff 897df0 0f844f010000 }
		$sequence_4 = { 8b45fc e8???????? 8bf8 83ff01 59 59 }
		$sequence_5 = { ffd3 50 ff15???????? 8b450c 5f 5b 5e }
		$sequence_6 = { 85c9 7424 85f6 7420 7620 662101 }
		$sequence_7 = { 8bd3 e8???????? 59 8d45c0 50 ba???????? e8???????? }
		$sequence_8 = { 8d5c3701 8a03 84c0 0f8eda000000 3c1e 0f8fd2000000 }
		$sequence_9 = { 8d45f4 50 e8???????? 8d85d8feffff }

	condition:
		7 of them and filesize < 326182
}
rule MALPEDIA_Win_Taintedscribe_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "d58fee4b-c6e5-554c-b4ac-93c4ea6bd974"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.taintedscribe"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.taintedscribe_auto.yar#L1-L121"
		license_url = "N/A"
		logic_hash = "c1bcdcacacb273e231e28bbb88f2d3d9cf338e074692db0759dc55a4eb61fe86"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c785a0fbffff01000000 53 eb61 e8???????? 33c9 668908 83c002 }
		$sequence_1 = { 5e 8be5 5d c20800 c7460c00000001 }
		$sequence_2 = { 33c0 56 8bf1 8b4d0c 89465c 895664 }
		$sequence_3 = { 83c40c 85c0 0f8565feffff 668b95a4fbffff }
		$sequence_4 = { e8???????? 84c0 742c 53 8d9578fbffff 68???????? 52 }
		$sequence_5 = { 50 56 ffd7 6a00 8d5594 }
		$sequence_6 = { 5b 5d c20c00 83f803 7574 }
		$sequence_7 = { 898da8fbffff 8d45e8 8985b4fcffff 8b433c 8bd0 8d4ddc }
		$sequence_8 = { 6a00 6a00 ff15???????? 85c0 7516 }
		$sequence_9 = { 7407 3d50450000 7507 814da400004000 8b7da4 8b5d9c 8b4580 }

	condition:
		7 of them and filesize < 524288
}
rule MALPEDIA_Win_Virtualgate_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "468a8262-a822-59d0-b3d8-a4f1467f63a3"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.virtualgate"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.virtualgate_auto.yar#L1-L123"
		license_url = "N/A"
		logic_hash = "5dcace8cb2655f6d87c5abdb24c69af3d7907a73bdad98fb76e22eff5ff3582a"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 85c0 742a 488bc5 4c8d053d890100 488bcd 48c1f906 }
		$sequence_1 = { b901000000 4c8d05253d0100 488d15263d0100 e8???????? }
		$sequence_2 = { 83b97004000002 0f8493010000 488d2d28270100 897350 89732c e9???????? 48ff4318 }
		$sequence_3 = { 4d03dd 418a0430 41ffc1 4b8b8cd7f0250200 4903c8 }
		$sequence_4 = { 0f8456010000 33f6 0f1f8000000000 4c8d442434 c744243410000000 488d542448 }
		$sequence_5 = { 418bd2 4d8b8cc7f0250200 498bfa 4b8d04f1 443854383e }
		$sequence_6 = { 4b8b8cd7f0250200 4903c8 49ffc0 428844d93e 4963c1 483bc2 }
		$sequence_7 = { c6415401 d1e8 eb14 488d157c1b0100 b806000000 48895148 c6415400 }
		$sequence_8 = { 4c896d97 44886d9f e8???????? 488b442458 bbe9fd0000 39580c 7518 }
		$sequence_9 = { e8???????? 8b08 e8???????? 488bd0 488d0d74d50100 e8???????? }

	condition:
		7 of them and filesize < 323584
}
rule MALPEDIA_Win_Krdownloader_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "9b4c2382-c7c9-51bb-a270-db7f3b8fdc18"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.krdownloader"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.krdownloader_auto.yar#L1-L123"
		license_url = "N/A"
		logic_hash = "e426897d5051d34441bbf890d389e196e8737ba70d93e788b3dc9bdf9efdea1d"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b0a 2b08 8bc1 99 b904050000 f7f9 }
		$sequence_1 = { 8d95e9fbffff 52 e8???????? 83c40c 8b45fc 2b45f4 50 }
		$sequence_2 = { 6840004004 8d45f4 50 68???????? 68???????? }
		$sequence_3 = { e8???????? 8945ac 8b4dd8 0fbe540de8 52 8b45d4 0fbe4c05e8 }
		$sequence_4 = { 83c408 837d1000 7509 c745f801000000 eb07 }
		$sequence_5 = { 6a00 6840004004 8d45f4 50 68???????? 68???????? }
		$sequence_6 = { 837dec00 0f850a010000 8b4df8 894dfc 837dfc00 0f84fa000000 }
		$sequence_7 = { 894df8 c745fc00000000 c745f400000000 eb0c 8b45f8 8b4df4 034804 }
		$sequence_8 = { 50 680000a000 8b4dec 51 6a00 }
		$sequence_9 = { c745bc00000000 c745e002000000 c745e8983a0000 8b45e8 50 }

	condition:
		7 of them and filesize < 352256
}
rule MALPEDIA_Win_Unidentified_077_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "535a2337-8422-5804-a1dc-e1bf17163f49"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.unidentified_077"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.unidentified_077_auto.yar#L1-L125"
		license_url = "N/A"
		logic_hash = "75a7e5d9348fb2d83e66fc45619d44f3b746fa93d980e29b85dcab31867502b7"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 4885c0 750e ff15???????? 418907 e9???????? ba30750000 }
		$sequence_1 = { 2bc8 0f841f050000 8d41ff 8b8482e8400100 85c0 0f8489000000 83f801 }
		$sequence_2 = { 488d4001 4883ea01 75f3 498bd0 488bcb e8???????? b9c0d40100 }
		$sequence_3 = { 2bcb 3bc8 7653 8bd1 }
		$sequence_4 = { 0fb68c8252400100 0fb6b48253400100 8bd9 8bf8 33d2 }
		$sequence_5 = { 498b9cf740c70100 4885db 7407 483bdf 747a eb73 }
		$sequence_6 = { 03c0 2bc8 0f8497000000 8d41ff 8b8482e8400100 85c0 7462 }
		$sequence_7 = { 83e13f 2bd1 8aca 488bd0 48d3ca 4933d0 4b8794f7e0c70100 }
		$sequence_8 = { 33d2 89442420 33c9 ff15???????? 488bc8 83caff ff15???????? }
		$sequence_9 = { 483bdf 747a eb73 4d8bbcf700310100 33d2 }

	condition:
		7 of them and filesize < 270336
}
rule MALPEDIA_Win_Murkytop_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "e3db8eeb-a4fa-53b6-8118-617395007964"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.murkytop"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.murkytop_auto.yar#L1-L122"
		license_url = "N/A"
		logic_hash = "d75881554e577a905c07d41c394dd3ccbdb4904a6ec9c695aa990aad3057e91f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 68???????? e8???????? 83c410 68???????? ff15???????? 5f }
		$sequence_1 = { ff15???????? 81feea000000 0f843affffff 57 ff15???????? }
		$sequence_2 = { 3b7df8 72e0 8b45f4 3bc6 7407 }
		$sequence_3 = { 895df0 895de8 e8???????? 83c40c 8d95d0feffff 52 }
		$sequence_4 = { 0fb6f3 0bce 8bd8 c1fb10 0fb6f3 66c1e608 }
		$sequence_5 = { 0f8485000000 3c76 747b 3c56 }
		$sequence_6 = { 8bc1 c1e004 2bc1 8d0c87 69c960ea0000 53 894de0 }
		$sequence_7 = { e8???????? 83c410 8937 8b7f04 3bfe }
		$sequence_8 = { 0fb6ca 0fbe8960cf4100 85c9 750d e8???????? c7002a000000 eb7a }
		$sequence_9 = { 6a00 6a00 68???????? 8b45c8 50 ffd7 3dea000000 }

	condition:
		7 of them and filesize < 294912
}
rule MALPEDIA_Win_Fast_Pos_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "bf9aabbb-c978-56e9-baa5-66f9c240987a"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.fast_pos"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.fast_pos_auto.yar#L1-L117"
		license_url = "N/A"
		logic_hash = "2870593470a786dd4e420301732f0472454124c0e64d13e03032e875519a255a"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 81feffffff7f 7ecf eb33 8b49f0 85c9 7409 }
		$sequence_1 = { 50 89b578ffffff c7857cffffff00000000 ff15???????? 85c0 8d45e4 }
		$sequence_2 = { 85c0 8d45e4 7407 68???????? }
		$sequence_3 = { 7427 8b46f4 894704 8d4710 8b4ef4 41 51 }
		$sequence_4 = { 6a64 8d4580 c745fc00000000 50 89b578ffffff c7857cffffff00000000 ff15???????? }
		$sequence_5 = { 68???????? 50 e8???????? 8b75f0 83c410 }
		$sequence_6 = { c645fc08 ff15???????? 50 ff36 }
		$sequence_7 = { 8d56fc 8bc8 7c1f 3b4ef0 751a }
		$sequence_8 = { 8be5 5d c20c00 81feffffff7f 7ecf }
		$sequence_9 = { ff36 ff30 e8???????? 8b95e4feffff }

	condition:
		7 of them and filesize < 327680
}
rule MALPEDIA_Win_Babuk_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "70ab8029-e34f-5400-bbb2-6d6d63a03ff7"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.babuk"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.babuk_auto.yar#L1-L174"
		license_url = "N/A"
		logic_hash = "d8533299405feeb726fae6eae480f93d4b39e42520b4fa6ae677b15099868756"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff15???????? 6800000100 e8???????? 83c404 }
		$sequence_1 = { 50 ff15???????? 83f803 7502 }
		$sequence_2 = { 8b4dfc 8b5508 8b44ca04 50 8b0cca 51 e8???????? }
		$sequence_3 = { 8945fc 837dfc0a 0f83dc000000 8b4dfc 8b5508 8b44ca04 }
		$sequence_4 = { 8bec 8b4508 25ff000000 b901000000 }
		$sequence_5 = { b908000000 6bf100 8b45ec 8b55f0 b11a }
		$sequence_6 = { eb09 8b45fc 83c002 8945fc 837dfc0a 0f83dc000000 }
		$sequence_7 = { 50 e8???????? 83c408 8945ec 8955f0 b908000000 6bf100 }
		$sequence_8 = { 6a00 8b45a4 50 6a01 8b4da8 51 }
		$sequence_9 = { 8d148d04000000 8955ec 8b45e0 8b4dec 8d540102 52 6a00 }
		$sequence_10 = { 8b8c8508fdffff 51 ff15???????? eb02 eb21 6800800000 }
		$sequence_11 = { b804000000 6bc800 8b5508 c7040a65787061 b804000000 }
		$sequence_12 = { c7040100000000 c744010400000000 ba08000000 6bc200 8b4d08 8b540104 52 }
		$sequence_13 = { 8b0cca 51 e8???????? 83c408 8945f4 8955f8 }
		$sequence_14 = { e8???????? 83c408 8b4d18 8b5508 89048a 8b4514 8b4d08 }
		$sequence_15 = { 8b5508 c7040a00000000 c7440a0400000000 c745fc00000000 eb09 }

	condition:
		7 of them and filesize < 183296
}
rule MALPEDIA_Win_Ice_Event_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "91b45224-0361-5483-a2cc-fca0371f66cd"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.ice_event"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.ice_event_auto.yar#L1-L119"
		license_url = "N/A"
		logic_hash = "6cefcdeb033d79ba894cfd64224f340a16ea7f0049837caf09ab520a5377ae21"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 486bc000 488d0d1adc0100 8b542430 48891401 }
		$sequence_1 = { 48894a08 488d4808 e8???????? 488d0511250100 488903 }
		$sequence_2 = { 0f82df000000 48c1e82c 660feb15???????? 660feb0d???????? 4c8d0dc4af0000 f20f5cca f2410f590cc1 }
		$sequence_3 = { 7479 488d0dd2260100 483bc1 746d 488b83e0000000 4885c0 }
		$sequence_4 = { 4c8bc3 488bd0 488d4d80 e8???????? 488bc8 e8???????? 90 }
		$sequence_5 = { 57 4883ec20 418bf0 4c8d0d77c30000 }
		$sequence_6 = { 498be8 4c8bea 4b8b8cfee0400200 4c8b15???????? 4883cfff }
		$sequence_7 = { 7205 488b0b eb03 488bcb 4a8d1441 482bf5 4c8d3436 }
		$sequence_8 = { 44896c2444 418d45ff 0fb68c8282e30100 0fb6b48283e30100 }
		$sequence_9 = { e8???????? cc 4883f927 0f866f030000 e8???????? cc }

	condition:
		7 of them and filesize < 331776
}
rule MALPEDIA_Win_Ransomhub_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "63648ac1-f8a9-511a-ba17-4ddf65ebf5f7"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.ransomhub"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.ransomhub_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "f7f4ed6d60d27f46dcd6524acb58921e7f4f3f17e9fb19009ede8dca7f3615a9"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 48ffc3 90 4939db 7365 4c898424d0000000 4c89e8 4c89d9 }
		$sequence_1 = { 488d0515dd1200 e8???????? 833d????????00 750e 488b8c24202b0000 48894818 eb11 }
		$sequence_2 = { e8???????? 4889c1 4889df 488d0549052f00 488b5c2438 0f1f4000 e8???????? }
		$sequence_3 = { 8854242b 0fb654241c 0fb674241f 31f2 8854242c 0fb654241e 4129d7 }
		$sequence_4 = { e8???????? 488b6d00 488b8c2400010000 488b9424f8000000 4883f90e 7e4f 48be03ce445067fcb5d4 }
		$sequence_5 = { eb09 4889c7 90 e8???????? 488d0514f22e00 488b5c2438 488d0d6b903300 }
		$sequence_6 = { e8???????? 4c89e0 4c89e9 e8???????? 4c89e9 4889da e8???????? }
		$sequence_7 = { 493b6610 0f86bf000000 4883ec38 48896c2430 488d6c2430 48ba6162f35d4d2e0b6e 488954241a }
		$sequence_8 = { e8???????? 488d1d3c9a1900 4889c1 488d3d12941b00 488b742428 488d05e6633f00 e8???????? }
		$sequence_9 = { 88542455 0fb654242c 0fb674242a 01f2 88542456 0fb6542422 4131d7 }

	condition:
		7 of them and filesize < 12821504
}
rule MALPEDIA_Win_Cloud_Duke_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "afd42fec-f96f-5085-8fc0-3ae4e524fc43"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.cloud_duke"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.cloud_duke_auto.yar#L1-L123"
		license_url = "N/A"
		logic_hash = "118b563f655ab92982b328d4d9f9cd7ba8785acd782de2cbe46a5dbaac4fdaef"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff15???????? 83f87a 7564 8b44242c 33c9 ba02000000 }
		$sequence_1 = { 72b3 6a00 6a00 6aff 57 6a00 }
		$sequence_2 = { 8d8c2424010000 e8???????? 8d842440010000 ba???????? 50 8d4c247c e8???????? }
		$sequence_3 = { 83f806 0f8563020000 8d85f4fdffff 50 a1???????? 6a00 6a00 }
		$sequence_4 = { 02c8 884de5 85db 7e14 0fb64435e4 }
		$sequence_5 = { 83c40c 33c0 668984242c070000 6816060000 }
		$sequence_6 = { c1e902 f3a5 8bca 83e103 f3a4 8b85e8fbffff 8bbde0fbffff }
		$sequence_7 = { e9???????? 8d8c245c010000 e8???????? 8d8c2440010000 e8???????? 8d8c2408010000 e8???????? }
		$sequence_8 = { 64a300000000 89542420 8bf1 8b4508 }
		$sequence_9 = { ffb42400010000 83bc242001000010 8d84240c010000 ffb4241c010000 0f43842410010000 6a01 }

	condition:
		7 of them and filesize < 368640
}
rule MALPEDIA_Win_Darkdew_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a39d74ae-a2fd-5808-9911-8a4debb1346d"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.darkdew"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.darkdew_auto.yar#L1-L121"
		license_url = "N/A"
		logic_hash = "f4d453f61b0f784ca5e05446bb74bf4d6abe2a9a435128474deede88e3b800a4"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8bbd68ffffff 0f43cf 8d5101 8a01 41 }
		$sequence_1 = { 8b4d18 2bc1 6a03 68???????? 83f803 7221 83fa10 }
		$sequence_2 = { 668945d4 8bc6 2bc2 c745e400000000 }
		$sequence_3 = { 8d8d1cfeffff e8???????? c645fc0b 8d4584 837d9810 8b3d???????? 0f434584 }
		$sequence_4 = { c745e400000000 c745e807000000 668945d4 8945fc 85f6 0f8456010000 8dbd20feffff }
		$sequence_5 = { e8???????? 59 83cfff 897de4 8365fc00 8b049da0f30110 8b4de0 }
		$sequence_6 = { f3a5 89442410 3b442424 0f8501feffff 5f }
		$sequence_7 = { 83fa10 8d7508 8d4103 0f437508 03f1 894518 }
		$sequence_8 = { 8bfb f3a5 8b75fc 8dbdb8fdffff b991000000 }
		$sequence_9 = { 83c408 c745fcffffffff 8b957cffffff c7459400000000 }

	condition:
		7 of them and filesize < 279552
}
rule MALPEDIA_Win_Uacme_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "39a85b56-99d0-5c8f-b924-bd28e51396f7"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.uacme"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.uacme_auto.yar#L1-L125"
		license_url = "N/A"
		logic_hash = "250a1e062b3ea7d50b4ecd3a693b6faddaeb99069a9154c9b738153549d0dbc2"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8d45e8 50 ff75fc ff15???????? 8b4df8 33d2 85c0 }
		$sequence_1 = { 6a08 ff7018 ff15???????? 8bf0 85f6 0f84de000000 }
		$sequence_2 = { 8d95f0fdffff e8???????? ff771c ff15???????? }
		$sequence_3 = { 59 59 85f6 743f ba???????? }
		$sequence_4 = { ff9620060000 33c0 5e 8be5 5d c20400 55 }
		$sequence_5 = { c745f425544d50 c745f8255c7233 58 8b3f }
		$sequence_6 = { c3 55 8bec 81ec20040000 53 56 be0a020000 }
		$sequence_7 = { ba???????? 8d8decfbffff e8???????? ba???????? e8???????? 8d85ecfbffff 50 }
		$sequence_8 = { e8???????? ba???????? 8d8df0fbffff e8???????? 8d85f0fbffff 50 ff15???????? }
		$sequence_9 = { ff7508 8bd3 8d8de0f7ffff e8???????? 59 85c0 741a }

	condition:
		7 of them and filesize < 565248
}
rule MALPEDIA_Win_Fullmetal_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "855da0e4-b67c-5e96-940e-51fe9337ca3a"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.fullmetal"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.fullmetal_auto.yar#L1-L101"
		license_url = "N/A"
		logic_hash = "6ff59e0e5bd1ba537b4bb84615f6a75f4daef5ba07d099bc3ea4d3a200088092"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 488bc8 33d2 e8???????? 488bd8 4885c0 7517 }
		$sequence_1 = { 4863c8 4881f9ff0f0000 7366 807c39ff5c 740a }
		$sequence_2 = { 75f6 48c7c1ffffffff 48ffc1 803c0a00 75f7 48ffc0 }
		$sequence_3 = { 4b0394d8404a0400 8a02 88440dff 48ffc1 48ffc2 }
		$sequence_4 = { e8???????? 4885c0 7520 41b800100000 }
		$sequence_5 = { c3 a1????????3d0000a1 3c00 00053d0000f3 3c00 }
		$sequence_6 = { 7512 ff15???????? 4c8d0d06970200 e9???????? 488d1512970200 488bcb }
		$sequence_7 = { 4d63c8 488bd3 4c8d8340010000 4c895c2420 ff15???????? 0f1000 }

	condition:
		7 of them and filesize < 733184
}
rule MALPEDIA_Win_Grateful_Pos_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "eb55e64c-40ab-5fa4-99d9-21258dd03ab4"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.grateful_pos"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.grateful_pos_auto.yar#L1-L165"
		license_url = "N/A"
		logic_hash = "d8aafbfa295517a00e09dabfcd4bdb2134fc12490d3d8770e7585649d476b211"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { b8feffffff eb1a b8fdffffff eb13 }
		$sequence_1 = { 83f801 7510 e8???????? e8???????? }
		$sequence_2 = { eb07 b8fcffffff eb02 33c0 }
		$sequence_3 = { e8???????? 99 b980ee3600 f7f9 }
		$sequence_4 = { 7407 b8f6ffffff eb02 33c0 }
		$sequence_5 = { b8fdffffff eb13 b8fcffffff eb0c }
		$sequence_6 = { 7411 e8???????? e8???????? 33c0 e9???????? }
		$sequence_7 = { 038ddcfbffff 0fb611 52 68???????? }
		$sequence_8 = { 50 8d8d74feffff 51 8b9568f9ffff 83c23d 52 }
		$sequence_9 = { c6840de4fbffff2e eb74 8b95d4fbffff 0fb68415e4fbffff 83f830 }
		$sequence_10 = { 8b4510 50 8d8d74fdffff 51 8b9560f9ffff }
		$sequence_11 = { c7421400000000 83bdecfffdff00 0f8404040000 81bdecfffdff00000200 760c c785e4fffdff00000200 eb0c }
		$sequence_12 = { 7c64 8b85f8fffdff 0fb68c05fbfffdff 83f93a 7d51 8b95f8fffdff 0fb68415fdfffdff }
		$sequence_13 = { 83e90e 51 e8???????? 83c40c 85c0 0f8491000000 6a03 }
		$sequence_14 = { 83bddcfbffff0f 7d5e 8b95e0fbffff 2b95dcfbffff 0fb602 83f830 }
		$sequence_15 = { 488d051d290200 c3 4883ec28 4885c9 7517 e8???????? c70016000000 }

	condition:
		7 of them and filesize < 3964928
}
rule MALPEDIA_Win_Smanager_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "76076406-af1e-5083-80e5-9d8e141ba94e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.smanager"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.smanager_auto.yar#L1-L226"
		license_url = "N/A"
		logic_hash = "99b09db51ea74ca198adb62ba1a9188653950854000e016f77ed94bbbde7abca"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b4510 85c0 7407 50 }
		$sequence_1 = { 740e 3d45270000 7407 3d46270000 }
		$sequence_2 = { 83c602 6a22 56 e8???????? 83c408 }
		$sequence_3 = { 8b7604 6a00 6a00 56 }
		$sequence_4 = { 56 68???????? 6a00 6a00 ff15???????? 8bf8 897e28 }
		$sequence_5 = { 6a0d e8???????? 83c404 8bf0 }
		$sequence_6 = { c7462cffffffff 7410 6a00 6a00 6830001100 }
		$sequence_7 = { 8b4608 85c0 7420 a801 7515 83e0fe }
		$sequence_8 = { ff15???????? 32c0 e9???????? 0f1005???????? }
		$sequence_9 = { 4c89742420 ff15???????? 85c0 7444 8b16 4c8bc5 }
		$sequence_10 = { 0000 0c0c 0c0c 0c0c 0c0c 0c0c 0102 }
		$sequence_11 = { 48894c2430 443b4120 7305 4889542430 488d442430 }
		$sequence_12 = { 0001 ce 50 0008 }
		$sequence_13 = { 0008 53 4f 00ef }
		$sequence_14 = { 0000 80ed4a 0044feff ff900100008c }
		$sequence_15 = { 0003 b157 0000 0c0c }
		$sequence_16 = { 4889442460 488b4b08 4883c108 488d542430 e8???????? }
		$sequence_17 = { 4057 4883ec20 488d3ddb6e0100 48393d???????? 742b b90c000000 e8???????? }
		$sequence_18 = { 0007 b15a 00c4 b15a }
		$sequence_19 = { eb40 4c8d35757a0100 488b0d???????? e9???????? 4c8d35727a0100 488b0d???????? }
		$sequence_20 = { 488b09 488bf2 4885c9 740a 488b01 ba01000000 ff10 }
		$sequence_21 = { 0007 b15a 0007 b15a }
		$sequence_22 = { 0007 b15a 0089b05a0089 b05a }
		$sequence_23 = { 85c0 0f8470010000 488b442448 488d0d07600100 4c8d4c2460 488b0cc1 }

	condition:
		7 of them and filesize < 10013696
}
rule MALPEDIA_Win_Bruh_Wiper_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "7c9ba4ef-4fa1-51f0-9221-ba77db229e60"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.bruh_wiper"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.bruh_wiper_auto.yar#L1-L126"
		license_url = "N/A"
		logic_hash = "cbaff4d5b7b91bf6e756e6a62487e97a100f6bd9c2c8d699efaa34252266d183"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 6a03 6800000040 68???????? ff15???????? 8b1d???????? 8bf8 6a00 }
		$sequence_1 = { e8???????? 83c40c be01080000 0f1f8000000000 6a00 8d85f8fdffff }
		$sequence_2 = { ffd3 83ee01 75e3 8b4dfc 5f 5e }
		$sequence_3 = { ffd7 8d45f0 50 6a06 6a00 6a00 6a00 }
		$sequence_4 = { 66a1???????? 668945f4 a0???????? 56 8845f6 8d45f4 57 }
		$sequence_5 = { 57 ffd3 83ee01 75e3 8b4dfc 5f }
		$sequence_6 = { 50 6a00 6a01 6a13 ffd7 8d45f0 }
		$sequence_7 = { 57 ffd3 6800020000 8d85fcfdffff 6a00 50 e8???????? }
		$sequence_8 = { 83ec10 a1???????? 33c5 8945fc 66a1???????? 668945f4 }
		$sequence_9 = { 57 ffd3 83ee01 75e3 }

	condition:
		7 of them and filesize < 65536
}
rule MALPEDIA_Win_Flusihoc_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f16a8aa6-5173-5776-bfdd-367ea1a5f768"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.flusihoc"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.flusihoc_auto.yar#L1-L165"
		license_url = "N/A"
		logic_hash = "d8330dac3c8933f56e71f3944575a8c260569f589e3816a42da6b932c4ae4d6a"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 84c0 75f1 8d45f0 50 e8???????? }
		$sequence_1 = { 8d7c2428 50 f3a5 c684246401000000 e8???????? 83c40c }
		$sequence_2 = { 8b542414 52 ffd6 6a0a }
		$sequence_3 = { 57 6a40 8d442428 6a00 50 }
		$sequence_4 = { 7505 fe06 fe4e17 83f834 7503 }
		$sequence_5 = { 6a00 50 c744242c44000000 e8???????? }
		$sequence_6 = { 8b8c247c040000 5f 5e 5b 33cc 33c0 e8???????? }
		$sequence_7 = { ffd3 8b442410 6aff 50 }
		$sequence_8 = { 6aff 50 ff15???????? 8b4c2410 51 ffd6 }
		$sequence_9 = { 8bec 83e4f8 81ece40b0000 a1???????? 33c4 }
		$sequence_10 = { 56 ff15???????? 6a28 ff15???????? }
		$sequence_11 = { 84c0 7420 ff15???????? 83c8ff }
		$sequence_12 = { e8???????? a1???????? 33c4 89842450160000 53 56 }
		$sequence_13 = { 8d95f4feffff 52 6806000200 6a00 68???????? 6802000080 }
		$sequence_14 = { 6804010000 8d85f8feffff 50 6a01 6a00 }
		$sequence_15 = { 6a00 68???????? 6802000080 ff15???????? 85c0 752f 8b8df4feffff }

	condition:
		7 of them and filesize < 319488
}
rule MALPEDIA_Win_M0Yv_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "7d3de172-222f-51ae-b681-dc9e8ee899f4"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.m0yv"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.m0yv_auto.yar#L1-L129"
		license_url = "N/A"
		logic_hash = "7f223b25ee955c3a27734570554abbe0a64f91c8cae040fb2dcad845a1416cb9"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b7210 8b7a14 8b5a18 8b6a1c 448b7220 8b5224 412b00 }
		$sequence_1 = { 4883ec20 8bd9 4c8d0da5890100 b906000000 4c8d0591890100 488d150ae20000 }
		$sequence_2 = { b802000000 4d85f6 0f84a2000000 4885f6 0f8499000000 85c9 0f8491000000 }
		$sequence_3 = { 4881e5000000fc 4929ed 4a8d1c78 48c1fa1a 4a8d0478 480500000001 }
		$sequence_4 = { 8a420e 32410e 4408c0 448a420f 4432410f 4108c0 }
		$sequence_5 = { 4c01f3 4889d9 e8???????? 4889f9 89c2 }
		$sequence_6 = { 498d4e08 48894c2428 498d4ef8 48894c2430 4c8d2d99020000 eb2f 4183c401 }
		$sequence_7 = { 4889fa 4889c7 4c89c0 490faff8 4889bc2480000000 4d01c0 480fafc0 }
		$sequence_8 = { c744242000000000 31ed ba05000000 41b801000000 4531c9 ff5018 488b37 }
		$sequence_9 = { 488d4b0a e8???????? c1e804 25ffff1f00 4889842488010000 488d4b0d e8???????? }

	condition:
		7 of them and filesize < 779264
}
rule MALPEDIA_Win_Zeus_Mailsniffer_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "fdfa3e51-2d98-5fe3-b35f-233007da2aa0"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.zeus_mailsniffer"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.zeus_mailsniffer_auto.yar#L1-L123"
		license_url = "N/A"
		logic_hash = "ec6eb3ab7d6f0d4c1cb5b27d7b923ad5c8d78405a222c392ecde908886a6a479"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b44cde8 a3???????? b001 5f 5e }
		$sequence_1 = { 57 b800070484 7405 b800074484 894dfc 8365fc04 7405 }
		$sequence_2 = { 66837ddc00 8b87a0902d01 7403 6a29 58 8d8dd4fdffff 51 }
		$sequence_3 = { 8bf8 85ff 744a 83650800 85db 7435 83c608 }
		$sequence_4 = { 8bec 81ec1c050000 53 56 8d85f0fcffff 57 33db }
		$sequence_5 = { 50 68???????? 6815010000 53 }
		$sequence_6 = { 8d8424a8070000 50 e8???????? 59 3bc3 }
		$sequence_7 = { 0f8425010000 395df4 0f841c010000 e8???????? }
		$sequence_8 = { ff75f0 8945e4 ffd6 68???????? ff75f0 8945d8 }
		$sequence_9 = { eb70 a80c 7464 8505???????? 745c 8d45e0 50 }

	condition:
		7 of them and filesize < 368640
}
rule MALPEDIA_Win_Unidentified_074_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "912816d1-1d63-519e-a02c-8ccb355e3ce3"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.unidentified_074"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.unidentified_074_auto.yar#L1-L123"
		license_url = "N/A"
		logic_hash = "4ced50d5dc370a643f99f061a1c70a2ad8cfa0c3b6c04f60ca6294040805df6f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 80e10f c0e004 02c8 884ded 85f6 7e2b 8b5de4 }
		$sequence_1 = { 0f87cf000000 81bde8e6ffffff000000 0f87bf000000 81bdece6ffffff000000 0f87af000000 }
		$sequence_2 = { 6a01 83ec08 c745d400000000 e8???????? 50 }
		$sequence_3 = { 7202 8b3f c60700 8bc6 8b4df4 }
		$sequence_4 = { 8d45f4 64a300000000 8b4510 8b5d08 8b750c 8b7d14 c78570dfffff00000000 }
		$sequence_5 = { c743140f000000 c7431000000000 c60300 8b9584e7ffff 83fa10 7324 }
		$sequence_6 = { c0e002 02c8 8ac7 8b5de4 884dec }
		$sequence_7 = { b9???????? e8???????? 8945fc ff55fc ff25???????? 55 8bec }
		$sequence_8 = { 50 0fb68539ffffff 50 0fb68538ffffff 50 }
		$sequence_9 = { 8b5610 8bc2 53 8b5d0c f7d0 57 3bc3 }

	condition:
		7 of them and filesize < 335872
}
rule MALPEDIA_Win_Open_Carrot_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "b5d6b2b0-8922-5dee-975f-04769582260e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.open_carrot"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.open_carrot_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "3ef29b7c7f29ab309141e319daddcf1a29bd01650bf99c77d0ee2218866d546e"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { b910000000 448d4289 e8???????? 41b866010000 488d159ab40b00 498bcc e8???????? }
		$sequence_1 = { 4903d4 4c63c7 664289b445100f0000 e8???????? 6639b510170000 7427 6639b5100f0000 }
		$sequence_2 = { 8bd7 498bcf e8???????? 488be8 85f6 7421 4c8d0d46990f00 }
		$sequence_3 = { 8d50d9 488d0df1021a00 4883c428 e9???????? b838000000 e8???????? 482be0 }
		$sequence_4 = { 7525 4c8d0d5e390e00 c7442420f4000000 baa4000000 8d4806 448d407d e8???????? }
		$sequence_5 = { 762d ba64000000 c744242059000000 4c8d0db1d21000 8d4aa3 448d42dd e8???????? }
		$sequence_6 = { c3 4883b9e002000000 752c ba34010000 c744242005010000 4c8d0d292e0800 b914000000 }
		$sequence_7 = { 7520 410fb64508 3a05???????? 7513 40b701 eb24 498bce }
		$sequence_8 = { 4d8bc8 4c89442460 4180781900 7557 498b4010 80781900 7520 }
		$sequence_9 = { 488d15790a0a00 e8???????? 488bd8 4885c0 7528 4c8d0d650a0a00 c744242056000000 }

	condition:
		7 of them and filesize < 8377344
}
rule MALPEDIA_Win_Scoring_Math_Tea_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "0a9b4328-7478-5d68-af07-e7379aba7e80"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.scoring_math_tea"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.scoring_math_tea_auto.yar#L1-L132"
		license_url = "N/A"
		logic_hash = "74a1a775dff53ecabcce1aaed4623153ddce6947cb8c46845c42b82387255fe7"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 448bc3 33d2 488d8da0030000 e8???????? 448bc3 33d2 }
		$sequence_1 = { 4883f801 410f45fd 85ff 753d 4d85f6 742c 0f2845b0 }
		$sequence_2 = { 72bf b9f5728387 e8???????? 498bcf ffd0 4533ff 4885f6 }
		$sequence_3 = { 33f6 eb38 833b02 7407 b800000800 eb2c }
		$sequence_4 = { ffd0 3d02010000 74cc b9380f2fc0 e8???????? 488d542430 498bce }
		$sequence_5 = { 4883f9fd 7706 ff15???????? 488364243000 488d0d4cfc0000 8364242800 }
		$sequence_6 = { 4c8d0523490100 e8???????? 488bcb 4885c0 740a 8bd7 ff15???????? }
		$sequence_7 = { 7873 3b1d???????? 736b 488bc3 488bf3 48c1fe06 4c8d2d1ec90200 }
		$sequence_8 = { 488d7b7d 4c8dbd20010000 498b5d00 e8???????? 33d2 4898 48f7f3 }
		$sequence_9 = { 488d056eb80400 488983f0af0600 488bcb e8???????? 4585f6 7408 e8???????? }

	condition:
		7 of them and filesize < 881664
}
rule MALPEDIA_Win_Tinyfluff_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "b93f5cfd-7d96-5a5b-9f52-aec58660ddd1"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.tinyfluff"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.tinyfluff_auto.yar#L1-L117"
		license_url = "N/A"
		logic_hash = "0879b7123b8abd7649db9ec24c1439994c896a3142659add731d8e5f9f7da2eb"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c1ff06 6bd838 8b04bd50704100 f644032801 7444 837c0318ff 743d }
		$sequence_1 = { 89861c020000 8b45e0 8d4e0c 6a06 8d9094644100 }
		$sequence_2 = { c1f906 6bf638 8b0c8d50704100 80643128fd }
		$sequence_3 = { 6bf038 03348d50704100 837e18ff 740c 837e18fe 7406 804e2880 }
		$sequence_4 = { e8???????? 8904bd50704100 85c0 7514 6a0c }
		$sequence_5 = { 57 8d3c85506d4100 8b07 83ceff }
		$sequence_6 = { 8b4c2450 8d145502000000 8bc1 81fa00100000 7214 }
		$sequence_7 = { 83f801 0f82f0010000 83bdbcfbffff08 8d85a8fbffff }
		$sequence_8 = { e8???????? 83c408 8b94240c010000 83fa08 7236 8b8c24f8000000 }
		$sequence_9 = { 750e 8b04bd50704100 807c302900 741d 8d45fc 50 }

	condition:
		7 of them and filesize < 245760
}
rule MALPEDIA_Win_Dorkbot_Ngrbot_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "3e4367c2-af26-58c6-a8a2-4f257f32a544"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.dorkbot_ngrbot"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.dorkbot_ngrbot_auto.yar#L1-L132"
		license_url = "N/A"
		logic_hash = "51d16839ca61803db80e8a407155fc609719b201a94501260035b9ee65c2fe4f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b4510 85c0 7405 83f810 7505 b810000000 }
		$sequence_1 = { 50 51 56 e8???????? 83c40c 85c0 7522 }
		$sequence_2 = { 53 53 8d55d4 52 ffd6 85c0 7e2d }
		$sequence_3 = { 740a 8d4614 50 ff15???????? c70700000000 8b4e08 894f04 }
		$sequence_4 = { 68???????? ffd3 56 68???????? ffd3 8bc7 }
		$sequence_5 = { 52 6a00 6a08 6a01 57 e8???????? 85c0 }
		$sequence_6 = { 38480c 740c 8b4004 85c0 75f4 33c0 5e }
		$sequence_7 = { 8b0e 68???????? 51 e8???????? 83c410 85c0 0f8427070000 }
		$sequence_8 = { 8b7508 53 56 e8???????? 83c408 85c0 7408 }
		$sequence_9 = { 0bca 894808 8b4508 50 8d4608 50 e8???????? }

	condition:
		7 of them and filesize < 638976
}
rule MALPEDIA_Win_Stilachi_Rat_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "0f431fb7-ea29-5072-8fa0-c3fa192b7460"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.stilachi_rat"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.stilachi_rat_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "ad539272106c020faf9ca7a195d4b6dfb9b77a394099131ce5e6db91e9aff62d"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 488bcd e8???????? 33f6 e9???????? 4c8b4b20 488b0b }
		$sequence_1 = { ff15???????? b91f9fa753 8bd8 e8???????? 8bcb ffd0 4c8be0 }
		$sequence_2 = { ff5030 8bd8 85c0 7515 4c396d48 7e0f 498b0424 }
		$sequence_3 = { e9???????? 488b0b ba00900000 66855114 740a 4883c430 5b }
		$sequence_4 = { e8???????? 899c24cc000000 eb12 bb02000000 4d8bc7 8bd3 488bcd }
		$sequence_5 = { e8???????? 488b5580 4533c0 8bc8 41b901000000 85c9 750d }
		$sequence_6 = { ffc9 7467 ffc9 0f852b040000 488b5e08 488d4548 418bcb }
		$sequence_7 = { e8???????? ba04000000 488bcd 4c8bf0 e8???????? 488bd6 448bc0 }
		$sequence_8 = { e8???????? b201 488bcf 488bf0 e8???????? 488bcb 4863f8 }
		$sequence_9 = { e8???????? 488b4720 4885c0 7447 833800 458bee 7e38 }

	condition:
		7 of them and filesize < 2629632
}
rule MALPEDIA_Win_Ddkeylogger_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a67b64ba-3a24-5b03-97bb-6fa1fd617831"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.ddkeylogger"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.ddkeylogger_auto.yar#L1-L122"
		license_url = "N/A"
		logic_hash = "35bb77ee32a1ee4cf41a3e8133dabb1263e352712bd1dfe36cdbb7e1ce08650b"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 88140e 0fb611 feca 88140f 83c102 48 }
		$sequence_1 = { c1eb06 03de 0fb61493 885102 }
		$sequence_2 = { 0fb7f1 57 bfffff0000 c745f400000000 }
		$sequence_3 = { 83c418 8d8de7faffff c745fcffffffff e8???????? 85f6 0f8f14feffff 8b85e0faffff }
		$sequence_4 = { 8bce eb99 53 8b1d???????? 6a00 ffd3 }
		$sequence_5 = { 83c8ff e9???????? 8bc6 c1f805 8bfe 53 8d1c8580ee4500 }
		$sequence_6 = { 83f801 8bc7 7508 8a4c0bff 884c3bff c6043b00 5f }
		$sequence_7 = { c1fa05 8b149580ee4500 c1e006 8d440224 }
		$sequence_8 = { 7448 f7c200f00000 7420 f7c200c00000 740c f7c200800000 0f95c0 }
		$sequence_9 = { 56 ff15???????? 56 8bf8 ff15???????? 3b3d???????? }

	condition:
		7 of them and filesize < 808960
}
rule MALPEDIA_Win_Avast_Disabler_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "645a106b-f735-50ef-a098-7cdfe936ba27"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.avast_disabler"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.avast_disabler_auto.yar#L1-L115"
		license_url = "N/A"
		logic_hash = "d9bf9a929cf2cb5bcebd034c783b915e751fc8d18f9e66457ed913ca7fa968a1"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 50 8d85f0feffff 50 e8???????? 8b4c371c }
		$sequence_1 = { c20c00 3b0d???????? 7503 c20000 e9???????? 8bff }
		$sequence_2 = { e8???????? 8b4c371c 8d85f0feffff 2b4c3718 }
		$sequence_3 = { 8bf0 85f6 7815 8d45f8 50 e8???????? 8bf0 }
		$sequence_4 = { 41 83ef01 75f1 8b85ecfeffff 33c9 0fb7d0 33c0 }
		$sequence_5 = { 57 8945e4 33ff 8d45dc }
		$sequence_6 = { 8bf0 85f6 7826 6a04 59 }
		$sequence_7 = { 6a00 ff7508 8bf0 57 }
		$sequence_8 = { 6bf80e 668b450c 6639443712 7408 }
		$sequence_9 = { 6a00 ff7508 8bf0 57 e8???????? }

	condition:
		7 of them and filesize < 41984
}
rule MALPEDIA_Win_Stealc_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f3809993-ed30-5330-bf00-2a7d11825fe9"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.stealc"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.stealc_auto.yar#L1-L168"
		license_url = "N/A"
		logic_hash = "0c667610aa851be4366482380151ce006b0caf01f821905b546741c32ad11ee2"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? e8???????? 81c480000000 e9???????? }
		$sequence_1 = { e8???????? 83c460 e8???????? 83c40c }
		$sequence_2 = { 50 e8???????? e8???????? 81c484000000 }
		$sequence_3 = { ff15???????? 85c0 7507 c685e0feffff43 }
		$sequence_4 = { 68???????? e8???????? e8???????? 83c474 }
		$sequence_5 = { e8???????? e8???????? 83c418 6a3c }
		$sequence_6 = { 8d85dcf7ffff 50 ff15???????? 85c0 0f84a1000000 }
		$sequence_7 = { 69c90ba31400 2bca 884c0588 48ffc0 }
		$sequence_8 = { 8d85dcf7ffff 50 8b450c 53 ff30 895df0 }
		$sequence_9 = { 69c10ba31400 894d80 2bc2 66894584 69c187fd701e }
		$sequence_10 = { 4c8be0 440fb6458e 440fb64d8d 440fb6558c 440fb65d8b }
		$sequence_11 = { 66894584 69c187fd701e b934eddb95 2bc8 }
		$sequence_12 = { 440fb77586 440fb77d84 894c2470 498bcc 4489442468 }
		$sequence_13 = { 0fb67d89 0fb67588 440fb77586 440fb77d84 }
		$sequence_14 = { e8???????? 0fb64d8f 4c8be0 440fb6458e }
		$sequence_15 = { ff15???????? 85c0 750a b043 }
		$sequence_16 = { e8???????? e8???????? 83c47c e9???????? }
		$sequence_17 = { 8bcc 8d95a0f5ffff 52 e8???????? e8???????? 83c414 }

	condition:
		7 of them and filesize < 4891648
}
rule MALPEDIA_Win_Coinminer_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "e70bc026-86d5-5738-97c2-4fd8062bb32e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.coinminer"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.coinminer_auto.yar#L1-L120"
		license_url = "N/A"
		logic_hash = "1abd5165e544d34a8f9ca0186dd5a95e30e4ad777bf13696910d07e2882ee782"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 57 41 752f a0???????? }
		$sequence_1 = { ffd5 48 8d87af010000 80207f 8060287f 4c }
		$sequence_2 = { 8b8554ffffff 8975e4 85c9 7504 85c0 7451 85f6 }
		$sequence_3 = { a2???????? 5f d024e2 37 90 3402 ed }
		$sequence_4 = { 57 f30f7f442440 b920000000 be???????? f30f6f05???????? 8dbc24b8040000 }
		$sequence_5 = { 5d c3 8b45e4 0fb70c50 8b45dc }
		$sequence_6 = { af f1 b28e 2c48 dc11 }
		$sequence_7 = { 50 51 e8???????? 83c408 84c0 7559 }
		$sequence_8 = { e8???????? 83c408 833d????????00 0f8474010000 }
		$sequence_9 = { 50 ff742420 ff15???????? 83c604 83fe0c 7cd4 }

	condition:
		7 of them and filesize < 1523712
}
rule MALPEDIA_Win_Nautilus_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "d96736da-56ff-53d5-9db7-8149d770d8d8"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.nautilus"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.nautilus_auto.yar#L1-L133"
		license_url = "N/A"
		logic_hash = "3ce5e228389d893a9cab0adbc4877b31c05fff133d992c258d037392a77bb9e3"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 83e803 741c 83e802 7417 83f805 0f8596000000 410fb602 }
		$sequence_1 = { e8???????? 8bd8 85c0 755b 488d4558 488d542438 488d4c2420 }
		$sequence_2 = { e9???????? 488b3b 396f08 0f84011a0000 488b07 8b5320 0fb608 }
		$sequence_3 = { 488b7c2448 4883c420 415e c3 488bc8 488bd5 e8???????? }
		$sequence_4 = { 75be 48ffc2 493bd2 7507 b8fdffffff ebb7 0fb602 }
		$sequence_5 = { 783e eb03 488bee 488b442440 48ffc0 4889442440 488d142b }
		$sequence_6 = { d3f8 498bcf 412006 837c244000 c60433bc 750d 4d8bc6 }
		$sequence_7 = { 488bc8 e8???????? 891f 33c0 488b8c2460010000 4833cc }
		$sequence_8 = { e9???????? c74424200e000000 e9???????? 8bc7 41b800010000 41bd13000000 c1e817 }
		$sequence_9 = { 7512 8a4a01 80f9a0 7230 4122c9 413ac9 752d }

	condition:
		7 of them and filesize < 1302528
}
rule MALPEDIA_Win_Session_Manager_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "2eabf316-5aa1-5196-99e8-e18f2cc4275c"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.session_manager"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.session_manager_auto.yar#L1-L124"
		license_url = "N/A"
		logic_hash = "a0cca072ac7383746f7072ea732b90b5c37c4309b764b41249ad42c9de281a1b"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 4c89b8d8080000 4c89b8e0080000 4c89b8e8080000 4c89b8f0080000 }
		$sequence_1 = { 4c89b898220000 4c89b8a0220000 4c89b8a8220000 4c89b8b0220000 4c89b8b8220000 4c89b8c0220000 }
		$sequence_2 = { 4885c9 741e 83c8ff f00fc101 83f801 7512 488d05be730100 }
		$sequence_3 = { 0f8239010000 48ffc0 488b4df7 483d00100000 0f8221010000 f6c11f }
		$sequence_4 = { 4c89b8b8240000 4c89b8c0240000 4c89b8c8240000 4c89b8d0240000 4c89b8d8240000 4c89b8e0240000 4c89b8e8240000 }
		$sequence_5 = { 498b06 498bce ff5018 4c8b08 4533c0 488d15f71a0200 488bc8 }
		$sequence_6 = { 4c89b830160000 4c89b838160000 4c89b840160000 4c89b848160000 4c89b850160000 }
		$sequence_7 = { 488bd0 488d4d68 e8???????? 488d8de8000000 e8???????? }
		$sequence_8 = { 33c0 498be8 4c8d0d7b55ffff 4c8bea f04f0fb1bcf100830200 4c8b05???????? 4883cfff }
		$sequence_9 = { 4c89b838080000 4c89b840080000 4c89b848080000 4c89b850080000 4c89b858080000 4c89b860080000 }

	condition:
		7 of them and filesize < 372736
}
rule MALPEDIA_Win_Tmanger_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "51a8a477-ff28-5ff8-bfa3-eca0eecfe4b8"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.tmanger"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.tmanger_auto.yar#L1-L120"
		license_url = "N/A"
		logic_hash = "6b0b8a8c5c5213a94509ba03b6e61a9c11aa0ae96f436fb23096657bd28dc72d"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c7411cf8f0564e c7412066b8276e c7412425d933d1 c7412861fdc72a c7412cdf9134d2 }
		$sequence_1 = { c74169388b8e92 c7416d9b14f6a0 c7417180fcd6bb c74175d7401d36 c7417958fffa19 66c7417dfc19 }
		$sequence_2 = { c741651f013f62 c74169388b8e92 c7416d9b14f6a0 c7417180fcd6bb c74175d7401d36 c7417958fffa19 }
		$sequence_3 = { c741510f9f2997 c7415565449eac c741594d68b93a c7415d382cd7bd c74161d47bdb0f c741651f013f62 c74169388b8e92 }
		$sequence_4 = { c7410491b20524 c74108cc6188ff c7410c16d9fdf8 c741103a71c135 c74114c2a02ab0 c74118d95dc845 c7411cf8f0564e }
		$sequence_5 = { c741510f9f2997 c7415565449eac c741594d68b93a c7415d382cd7bd }
		$sequence_6 = { c741651f013f62 c74169388b8e92 c7416d9b14f6a0 c7417180fcd6bb }
		$sequence_7 = { c741103a71c135 c74114c2a02ab0 c74118d95dc845 c7411cf8f0564e c7412066b8276e }
		$sequence_8 = { c7415565449eac c741594d68b93a c7415d382cd7bd c74161d47bdb0f c741651f013f62 c74169388b8e92 c7416d9b14f6a0 }
		$sequence_9 = { c7410c16d9fdf8 c741103a71c135 c74114c2a02ab0 c74118d95dc845 c7411cf8f0564e }

	condition:
		7 of them and filesize < 8252416
}
rule MALPEDIA_Win_Transferloader_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "6881fadd-235e-58e1-86ed-39c1ca8da641"
		date = "2026-01-05"
		modified = "2026-01-06"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.transferloader"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.transferloader_auto.yar#L1-L121"
		license_url = "N/A"
		logic_hash = "c6b3fd0089b61d2c316b9ea19bd98256a6361edd3a6f033006f4e490787182fc"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260105"
		malpedia_hash = "19b79e7cab4eaf532122e5b45a77dd8f6bb5cc79"
		malpedia_version = "20251219"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 0fb609 880c02 e9???????? 48837c244800 7412 4c8b442448 33d2 }
		$sequence_1 = { 4889442438 41b810000000 488b542438 488b4c2430 }
		$sequence_2 = { 88440c20 b801000000 486bc002 b901000000 486bc901 }
		$sequence_3 = { 488d442424 48898424f8000000 488d442420 4889842400010000 }
		$sequence_4 = { b903000000 f3aa 48b8bce015361abafbff 48898424c8000000 c744242c00000000 486344242c }
		$sequence_5 = { 4889842498010000 488b842490010000 4889842468010000 c6442440eb c644244108 c644244248 c644244389 }
		$sequence_6 = { 488b09 4863493c 480308 488bc1 4889442430 488b442430 }
		$sequence_7 = { 4889542410 48894c2408 4881eca8000000 c6442420eb c644242108 }
		$sequence_8 = { 488b442420 4889442428 488b442428 0fb700 3d4d5a0000 7404 32c0 }
		$sequence_9 = { 488b8c2420010000 ff15???????? 4883bc24e000000000 7418 4c8b8424e0000000 33d2 }

	condition:
		7 of them and filesize < 216064
}
rule MALPEDIA_Win_Supper_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "dac5d58a-b354-5c65-9d15-0eab7da458d9"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.supper"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.supper_auto.yar#L1-L163"
		license_url = "N/A"
		logic_hash = "cd45eb78663195403eedfda6906a8c519dc90465fd4fbb991d23bb77b062691b"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 53 4883ec38 48833d????????00 7474 }
		$sequence_1 = { 4889c1 488905???????? e8???????? 84c0 7407 }
		$sequence_2 = { e8???????? 48c705????????00000000 b9d0070000 ff15???????? b938000000 e8???????? 4889c1 }
		$sequence_3 = { b9d0070000 4883c428 5b 5e }
		$sequence_4 = { 4885c0 7416 488b4008 4885c0 740d }
		$sequence_5 = { 4531c0 488b4b08 ba01000000 41ffd4 }
		$sequence_6 = { 4883c438 5b 5e c3 488b0d???????? 4885c9 }
		$sequence_7 = { ffd6 48891d???????? 488905???????? 31c0 }
		$sequence_8 = { 83f001 84c0 7425 48837df0ff 7414 488b45f0 4889c1 }
		$sequence_9 = { ba00000000 b900000000 e8???????? 85c0 7f07 }
		$sequence_10 = { ba80000000 4889c1 e8???????? 85c0 0f85e0000000 }
		$sequence_11 = { b801000000 e9???????? c745ac01000000 488d55ac }
		$sequence_12 = { 0fb645ff 4883c438 5b 5d c3 }
		$sequence_13 = { eb31 c745f02c010000 c745f400000000 488b05???????? 4c8d45f0 8b4d18 488b5510 }
		$sequence_14 = { c785ec00000009000000 eb5e 83bde400000002 750c c785ec00000008000000 }
		$sequence_15 = { 488b85e8000000 8b00 89c0 48c1e002 }

	condition:
		7 of them and filesize < 517120
}
rule MALPEDIA_Win_Tempedreve_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a0dc31a3-5a46-5235-bbe5-8dc00685ba75"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.tempedreve"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.tempedreve_auto.yar#L1-L162"
		license_url = "N/A"
		logic_hash = "f54e99d82229a4c3b64296863c22e70eae320d20db9e15346b574c250c649b72"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 011e 015e10 015e0c 0fb75706 }
		$sequence_1 = { 011a 8b87dc000000 83c204 03c6 }
		$sequence_2 = { 7563 397e10 755e 8b4638 }
		$sequence_3 = { 0103 a1???????? 83c004 50 ff15???????? }
		$sequence_4 = { 010f 8b07 83c704 3bc1 }
		$sequence_5 = { 0104b7 8b8424a8000000 83c704 4d }
		$sequence_6 = { 01042f 034c2ff8 8d45ec 894c2ff8 }
		$sequence_7 = { 011a 45 8d14a9 8b02 }
		$sequence_8 = { 01ae14040000 8d5c2bff eb3d 8b5c2458 85ff 7516 8b4c2428 }
		$sequence_9 = { b8eefbeeab 33c9 57 0fb6b90030cb00 }
		$sequence_10 = { 8d0411 3bc7 7602 8bc7 50 8b442414 8beb }
		$sequence_11 = { 8b44240c 81ec2c040000 85c0 7509 81c42c040000 }
		$sequence_12 = { 7506 43 41 3bda 72f3 8b4c2414 }
		$sequence_13 = { 75ed f7d0 8944241c 61 c20800 60 8b742424 }
		$sequence_14 = { 742e 8b4c2460 8b9610040000 2b542450 }
		$sequence_15 = { 85ff 0f84e6000000 3b7c243c 0f85dc000000 8b542454 8bcf 2bcb }

	condition:
		7 of them and filesize < 155648
}
rule MALPEDIA_Win_Mindware_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "c2e13f3f-397e-5de7-b5be-68d9294f83df"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.mindware"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.mindware_auto.yar#L1-L127"
		license_url = "N/A"
		logic_hash = "3162638de8a48701befb0b18544b24373517ba5817e9930a0077003bbbf8e465"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8bcb c1e910 0fb6c9 c1e608 0fb689f0d84400 33f1 }
		$sequence_1 = { 8b4df8 c1e908 0fb6c9 8b1495c0c04400 8b75f4 33148dc0bc4400 8bce }
		$sequence_2 = { 3945f8 741f 8b34bdd4214400 47 85f6 7fb9 5f }
		$sequence_3 = { 0bd9 8945f4 b130 8b04d520414400 8b14d524414400 e8???????? 8b4df0 }
		$sequence_4 = { 2b55e4 8b45d4 1bc1 8955d0 8945d4 8b4de4 33d2 }
		$sequence_5 = { c78588f0ffff2cdf4300 c7858cf0ffff3cdf4300 c78590f0ffff44df4300 c78594f0ffff4cdf4300 }
		$sequence_6 = { 83e1f0 83f910 7309 c745e810000000 eb0f 8b55f8 8b4204 }
		$sequence_7 = { c785ccf1ffff40e24300 c785d0f1ffff50e24300 c785d4f1ffff60e24300 c785d8f1ffff68e24300 c785dcf1ffff70e24300 c785e0f1ffff7ce24300 c785e4f1ffff8ce24300 }
		$sequence_8 = { 884103 0fb64104 d1e8 0fb68060364400 884104 }
		$sequence_9 = { c78550f3ffff38e64300 c78554f3ffff40e64300 c78558f3ffff48e64300 c7855cf3ffff50e64300 c78560f3ffff58e64300 c78564f3ffff60e64300 }

	condition:
		7 of them and filesize < 661504
}
rule MALPEDIA_Win_Cloudwizard_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "001ffb66-fb9f-588e-81cc-d9d838c75b00"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.cloudwizard"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.cloudwizard_auto.yar#L1-L122"
		license_url = "N/A"
		logic_hash = "cc04a1e416def0385ae590198639f0e04c657373d99e5744a8a882094c1f4328"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 40 6685d2 75f6 2bc1 8bce d1f8 }
		$sequence_1 = { d1f8 51 8d844618060000 50 e8???????? bf???????? 8bc7 }
		$sequence_2 = { c645c74d c645c846 c645c95c c645ca7e c645cb49 c645cc5a }
		$sequence_3 = { 33c0 8945ec 8365fc00 6a10 50 }
		$sequence_4 = { 8b35???????? 8365fc00 57 8965f0 6a05 }
		$sequence_5 = { 663930 75f5 8d45e8 50 }
		$sequence_6 = { 668945f0 58 668945f2 6a47 58 668945f4 6a46 }
		$sequence_7 = { ff7508 8bce ff5004 6a04 33d2 59 8bc6 }
		$sequence_8 = { 7506 56 e8???????? 6860ea0000 ff15???????? 837e3000 }
		$sequence_9 = { c9 c3 55 8d6c2488 81ec9c040000 }

	condition:
		7 of them and filesize < 134144
}
rule MALPEDIA_Win_Ismdoor_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "66118ab8-b80d-5180-a0f2-ad21f4fe9137"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.ismdoor"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.ismdoor_auto.yar#L1-L152"
		license_url = "N/A"
		logic_hash = "aec162c3ea815c2764428befc16b64a30adbcd26ca8d97fc3731d15697789a31"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 83f8ff 7504 32c0 eb05 c0e804 2401 84c0 }
		$sequence_1 = { 488b4f70 e8???????? 488b4f68 e8???????? 90 }
		$sequence_2 = { cc 48ffc2 e8???????? 488bf0 33ff 48897c2438 }
		$sequence_3 = { 48895c2440 eb98 85ff 7532 }
		$sequence_4 = { e8???????? 90 4c8d85b0000000 4883bdc800000010 4c0f4385b0000000 }
		$sequence_5 = { 4c897c2430 44887c2420 48837c245810 720a }
		$sequence_6 = { 4883ec20 80b91006000000 488bd9 7407 f0ff0d???????? }
		$sequence_7 = { 83bb8000000000 48894318 7551 4d85f6 744c }
		$sequence_8 = { 8b4004 c74430902cb84700 8b4690 8b4804 }
		$sequence_9 = { 0f84110e0000 8b8d68ffffff b8abaaaa2a 8bb564ffffff }
		$sequence_10 = { e8???????? 83c404 eb03 8b7730 }
		$sequence_11 = { 83ec18 c645fc0d 8bcc 8d459c 6aff }
		$sequence_12 = { 7415 8965d0 6aff 50 }
		$sequence_13 = { 668901 8d4508 50 e8???????? c645fc34 }
		$sequence_14 = { 8d9b00000000 6a04 6a00 68???????? 8d4d08 e8???????? }

	condition:
		7 of them and filesize < 1933312
}
rule MALPEDIA_Win_Cryptbot_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f21ebe9e-fb5e-5698-a471-c2fdfac0b614"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.cryptbot"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.cryptbot_auto.yar#L1-L271"
		license_url = "N/A"
		logic_hash = "718f1b2c7e85365328cec398934adc3a3105954e387276ec167d0b7b017c4536"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 85c0 750e b9ca070200 e8???????? 8bc8 }
		$sequence_1 = { 895804 e8???????? c74004d0070000 e9???????? }
		$sequence_2 = { 33c0 eb0a b917d90000 e8???????? }
		$sequence_3 = { 84c0 7514 b800000002 e9???????? }
		$sequence_4 = { 85c0 740a b9491a0100 e9???????? }
		$sequence_5 = { 85f6 790e b9e2d80000 e8???????? 8907 }
		$sequence_6 = { 85c0 750f b955960100 e8???????? e9???????? }
		$sequence_7 = { 83f8ff 7407 c1e804 2401 8ad8 8ac3 }
		$sequence_8 = { 7411 ffb6c4000000 6a00 50 e8???????? 83c40c 8bce }
		$sequence_9 = { 7518 8b542414 83c718 8bcd }
		$sequence_10 = { 83caff 8bcf e8???????? 83caff }
		$sequence_11 = { 7424 807e4100 7404 33c0 }
		$sequence_12 = { 750f 8a44245c 84c0 7507 }
		$sequence_13 = { 7510 83be9c01000000 7507 8bce }
		$sequence_14 = { 85c0 742c 8bd6 8bcb }
		$sequence_15 = { 741e 8b491c 8b442434 803c0800 7411 33c0 39442438 }
		$sequence_16 = { 750b 8bce e8???????? 8b4c2428 }
		$sequence_17 = { 744e 0fb74802 83e103 3bcb }
		$sequence_18 = { 8b5720 8bce e8???????? 8b5724 }
		$sequence_19 = { 8b4d18 8901 895104 e9???????? 8b4508 }
		$sequence_20 = { 8b4d20 894c2468 8b4d5c 894c2464 }
		$sequence_21 = { 8b95acfeffff 33c0 3802 7406 }
		$sequence_22 = { 8b959cfeffff 8bca 85d2 742a }
		$sequence_23 = { 8b4d18 8b09 81c1fc030000 8b448808 }
		$sequence_24 = { 8b95a0feffff 6a00 6a00 8b08 }
		$sequence_25 = { 8b959cfeffff 8b85acfeffff 33c9 3808 }
		$sequence_26 = { 8b4d34 894c245c dd85b8fbffff dd5c2454 }
		$sequence_27 = { 8b4d18 8b09 83c101 81c1fc030000 }
		$sequence_28 = { 8b4d24 894c247c dd85b0fbffff dd5c2474 }
		$sequence_29 = { 8b4d34 894c2470 8b4d64 894c246c }
		$sequence_30 = { 8b4d28 898d30ffffff 8b958c000000 89952cffffff }
		$sequence_31 = { 8b958cfeffff 2bc2 8bb5a0feffff 03f0 8a02 }

	condition:
		7 of them and filesize < 17138688
}
rule MALPEDIA_Win_Nettraveler_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "16ef2f38-fd0c-5a39-9be8-c8123f45736c"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.nettraveler"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.nettraveler_auto.yar#L1-L126"
		license_url = "N/A"
		logic_hash = "6a4d2faa9132b5f935d7967083e68a3602adf2e8eea5f944bf404111cc41106b"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 0fb6443df0 50 68???????? 56 ff15???????? 83c40c }
		$sequence_1 = { 0f95c0 88440d8c 41 83f938 7cd7 83650800 c745fc1e000000 }
		$sequence_2 = { 68???????? 50 ff15???????? 8d858cfbffff }
		$sequence_3 = { 56 e8???????? 83c410 8d8580f1ffff 68???????? 50 ffd7 }
		$sequence_4 = { 57 e8???????? 50 8b45fc 57 8b0406 ff7008 }
		$sequence_5 = { 750b ff45fc 837dfc03 7d34 ebd5 8b45f0 2b4508 }
		$sequence_6 = { e8???????? ff7514 8d45f4 50 8d45dc 50 ff7508 }
		$sequence_7 = { 8b5d10 8b45fc 2bde 894518 6a01 8d45e4 ff7514 }
		$sequence_8 = { ba???????? 0fb69f4c910010 8d8764910010 807c1dc400 }
		$sequence_9 = { 0106 33df 035de0 8d8c1935f23abd 8bd9 c1eb16 }

	condition:
		7 of them and filesize < 106496
}
rule MALPEDIA_Win_Powerduke_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "b1a14b33-ddbf-5df6-8a25-665602dd43b2"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.powerduke"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.powerduke_auto.yar#L1-L119"
		license_url = "N/A"
		logic_hash = "b0e443670552cebb99307ce5c81f7553239dfaab3a0b54a91654aba975b30757"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 0f8401030000 8945bc 6a00 6800400000 68???????? ff75bc ff15???????? }
		$sequence_1 = { ebea ad 89c2 81fa68747470 0f8586010000 }
		$sequence_2 = { 681b000200 6a00 68???????? 6801000080 ff15???????? 09c0 0f8597000000 }
		$sequence_3 = { 7518 8d85f4f7ffff 6800040000 50 ff35???????? ff15???????? 8d85f4f7ffff }
		$sequence_4 = { 6a00 ff35???????? ff15???????? c705????????00000000 837dfc01 }
		$sequence_5 = { 55 ff15???????? 5a 59 }
		$sequence_6 = { c745fc01000000 eb11 c745d001000000 8b451c }
		$sequence_7 = { 7403 41 ebf1 c6040e00 51 }
		$sequence_8 = { 7419 a3???????? ff7514 50 ff15???????? c705????????01000000 31c0 }
		$sequence_9 = { ff75e4 ff15???????? ff75c4 ff15???????? }

	condition:
		7 of them and filesize < 57344
}
rule MALPEDIA_Win_Soundbill_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "aec5cb22-bc50-5f6a-b47e-e6f5711eccc9"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.soundbill"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.soundbill_auto.yar#L1-L129"
		license_url = "N/A"
		logic_hash = "bed13fe7ebf5cd4e97afb65e76c189f4ee734155cf41306c00f3b40fd6a7d73b"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 85c0 740a b8ff000000 e9???????? 488d15ab930200 488d0d2c930200 }
		$sequence_1 = { e8???????? 488d0d25500300 4883c428 e9???????? 4053 4883ec20 b901000000 }
		$sequence_2 = { e8???????? 488d05f1660300 4533c0 488bd3 488905???????? 488d0d15e50400 e8???????? }
		$sequence_3 = { c745c856145e56 66c745cc563a c7450043726561 c7450474654669 c745086c654d61 }
		$sequence_4 = { 4883ec20 488d1dc7a80300 488d3dc0a80300 eb12 488b03 }
		$sequence_5 = { 4963c8 488d1489 498d1cd2 4803df 33c9 0fb6440b18 48ffc1 }
		$sequence_6 = { 4053 4883ec20 488bd9 488bc2 488d0d8daa0200 48890b }
		$sequence_7 = { 488bd9 488bc2 488d0d8daa0200 48890b 488d5308 33c9 48890a }
		$sequence_8 = { 48c745bf00000000 48c745c70f000000 c645af00 440fb6c6 ba01000000 488d4daf e8???????? }
		$sequence_9 = { 49ffc5 41ffc7 488d45af 4883fe10 490f43c6 803c387f 747d }

	condition:
		7 of them and filesize < 973824
}
rule MALPEDIA_Win_Pickpocket_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "cd2de145-ad2b-5614-8ed3-62375390d902"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.pickpocket"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.pickpocket_auto.yar#L1-L106"
		license_url = "N/A"
		logic_hash = "3e5ccb8e439c20d9bb05494e6dfebf8fda79ef54c3036868eed059295b5ee42a"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 7704 33c0 eb0a b952ca0000 }
		$sequence_1 = { 85c0 750f b9af770100 e8???????? }
		$sequence_2 = { d3e0 a846 750f b99be00100 }
		$sequence_3 = { 760f b980dc0000 e8???????? e9???????? }
		$sequence_4 = { 750e b958de0100 e8???????? 8bc8 }
		$sequence_5 = { 85c0 750e b958de0100 e8???????? 8bc8 }
		$sequence_6 = { 85c0 750e 85c9 7408 }
		$sequence_7 = { e8???????? 85c0 750f b962890100 }
		$sequence_8 = { eb0c b96ccb0000 eb05 b960cb0000 e8???????? }
		$sequence_9 = { b9cecc0000 e9???????? b9c7cc0000 e9???????? }

	condition:
		7 of them and filesize < 1458176
}
rule MALPEDIA_Win_Nightdoor_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "ffb230d3-9255-5208-890e-5454123b931e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.nightdoor"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.nightdoor_auto.yar#L1-L133"
		license_url = "N/A"
		logic_hash = "6b0c38d265d2624f73cc7c76e67a9a2b2b835147a73e16a790021f634c9ca340"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8bd9 c1eb08 81e3ff000000 0fb69bb0e20710 33f3 8b5d08 81e3ff000000 }
		$sequence_1 = { c645fc05 e8???????? 8d8df0feffff c645fc01 e8???????? 8d75b4 8d8d9cfeffff }
		$sequence_2 = { c745f400000000 8b4d18 833900 743e 8b55ec 8b4220 83c001 }
		$sequence_3 = { c68537ffffff01 c645fc05 8d8d40ffffff e8???????? c645fc04 8d8d5fffffff e8???????? }
		$sequence_4 = { e8???????? 83c40c 8d4d18 e8???????? 50 68???????? }
		$sequence_5 = { 8916 894a08 e9???????? 8b12 385a10 751c c6411001 }
		$sequence_6 = { 56 8d4df0 897df0 e8???????? 8b4df4 8b45f0 3bc8 }
		$sequence_7 = { 6a00 53 8bce e8???????? 8bc3 5f 8be5 }
		$sequence_8 = { 8b442430 83c40c 57 50 53 e8???????? 83c40c }
		$sequence_9 = { 894b60 8b8eac000000 6a00 e8???????? 50 8b8548feffff 53 }

	condition:
		7 of them and filesize < 1124352
}
rule MALPEDIA_Win_Edr_Freeze_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "d35dc4f7-b60b-5c26-9663-fb69ee0ce951"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.edr_freeze"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.edr_freeze_auto.yar#L1-L130"
		license_url = "N/A"
		logic_hash = "340b4ca4f0781283574a3f4bd6ad254713e68d6027a238322ecbf33e4700b683"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 4c8bf9 e8???????? 4c8be8 488d4dcf e8???????? 0f1000 0f1145ff }
		$sequence_1 = { 8d4805 e8???????? 488b05???????? 4885c0 751d 4c8d0d2a810100 4c8d051b810100 }
		$sequence_2 = { 66c1e002 8d0c10 6603c9 66442bc1 664183c030 66458902 448bc2 }
		$sequence_3 = { 415c 5f 5e c3 f6c204 7409 488d1d43900200 }
		$sequence_4 = { 4c897daf c645b700 4c897dbf c645c700 4c897dcf 6644897dd7 }
		$sequence_5 = { 8b4c2434 4c8d05102afdff b8cdcccccc f7e1 c1ea03 }
		$sequence_6 = { 488b4c3148 488b01 4d8bc7 498bd5 ff5048 493bc7 7410 }
		$sequence_7 = { 4903f5 458be6 4c8b6dc7 e9???????? 4c8d1ddda5fdff 4f8b84eb20ab0400 }
		$sequence_8 = { 488d0df9820200 e8???????? 90 e8???????? cc e8???????? cc }
		$sequence_9 = { 4d8be9 4c8907 48890e 488b17 493bd1 0f84aa000000 483b8c24a0000000 }

	condition:
		7 of them and filesize < 661504
}
rule MALPEDIA_Win_Lolsnif_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a2471e2f-8170-56f1-9f47-83e35369bbc0"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.lolsnif"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.lolsnif_auto.yar#L1-L127"
		license_url = "N/A"
		logic_hash = "21384501118eea6d041a100ef98490b60000941128ff475e8b7c3d4ab3a5bf7a"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 895dfc 8945d8 7522 f605????????01 7419 8b7708 }
		$sequence_1 = { ffd6 85c0 752b 8b7510 50 ff35???????? }
		$sequence_2 = { 8b7d08 41 837f3c00 894c240c 0f8492000000 8d4738 66833800 }
		$sequence_3 = { 5f 5e 5b 8be5 5d c20800 8b413c }
		$sequence_4 = { 50 e8???????? eb2a ff35???????? ff35???????? }
		$sequence_5 = { 3dd808c373 7437 3d0c293b74 741a }
		$sequence_6 = { 7556 8b7df8 ff75fc 8bcf e8???????? 8bf0 a1???????? }
		$sequence_7 = { c20400 83ec18 8364240c00 53 55 bd04010000 6850020000 }
		$sequence_8 = { 8b4710 8b75ec 3bf3 8945e8 750c c745fc02000000 e9???????? }
		$sequence_9 = { 8be5 5d c20400 55 8bec 83ec14 8b5508 }

	condition:
		7 of them and filesize < 425984
}
rule MALPEDIA_Win_Maskgramstealer_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "781b3df9-5c08-5809-8460-d99138ee56e6"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.maskgramstealer"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.maskgramstealer_auto.yar#L1-L115"
		license_url = "N/A"
		logic_hash = "b565732b1fe5991d8f2e5bc5ae85b253a48fbe11609b27fcc9968dfd908db756"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 7437 48833d????????00 742d 48833d????????00 }
		$sequence_1 = { 498d1400 8a02 3c5c 7404 }
		$sequence_2 = { 498d1400 8a02 3c5c 7404 3c2f 7503 48ffc2 }
		$sequence_3 = { 4531c9 428a0409 468a040a 448d50bf 4180fa19 7703 }
		$sequence_4 = { 7404 39f0 7204 31c0 }
		$sequence_5 = { 4180fa19 7703 83c020 458d50bf 4180fa19 7704 4183c020 }
		$sequence_6 = { 31c0 b980000000 803d????????00 f3ab }
		$sequence_7 = { 4438c0 74ea 4429c0 c3 }
		$sequence_8 = { c3 803900 7405 48ffc1 ebf6 31c0 448a0402 }
		$sequence_9 = { 48833d????????00 488905???????? 7437 48833d????????00 }

	condition:
		7 of them and filesize < 353280
}
rule MALPEDIA_Win_Oldbait_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "eaad67a9-3d36-5c3f-9b91-864b6cb950bd"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.oldbait"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.oldbait_auto.yar#L1-L234"
		license_url = "N/A"
		logic_hash = "656f00fa268fe141012ec700b38bc35be0e007b789365012ce30254ef396ee5b"
		score = 75
		quality = 73
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 0145d8 8b45f0 ff45ec 0fb64004 }
		$sequence_1 = { 8a09 888800b01800 ebda 8b45fc }
		$sequence_2 = { 6880000000 6a03 6a00 6a01 6800000080 ff75f8 ff15???????? }
		$sequence_3 = { 8b4510 69c061ea0000 3571281424 42 3bd6 }
		$sequence_4 = { 85f6 7626 8b4510 8bca 83f101 83e107 }
		$sequence_5 = { 6a40 6800300000 68d4fd1900 6a00 ff15???????? }
		$sequence_6 = { 83e107 d3e8 30043a 8b4510 69c061ea0000 }
		$sequence_7 = { 0145d8 8bb54cffffff 56 ff55d0 }
		$sequence_8 = { 8b45fc 0531b11800 50 8b45f8 }
		$sequence_9 = { 8b450c 56 33d2 57 8b7d08 8d70ff }
		$sequence_10 = { 0145d8 8b45d8 3b45c8 7cc2 }
		$sequence_11 = { 0103 01451c 8b06 8bc8 c1e906 }
		$sequence_12 = { 837d2000 7432 66c7045f0d00 43 66c7045f0a00 43 0fb68696cb1800 }
		$sequence_13 = { 01459c 8b45c8 8945f8 eb05 }
		$sequence_14 = { 0145d8 33ff 8d837ff61800 803800 }
		$sequence_15 = { 0145d4 41 c1ea04 75dc }
		$sequence_16 = { 57 6852020000 68???????? 897dfc c645f469 c645f523 c645f65a }
		$sequence_17 = { 8bc2 894de8 53 c1e803 c1e903 56 8b7514 }
		$sequence_18 = { 8ad8 8bc7 83e007 0a1c30 0fb64437fe }
		$sequence_19 = { a3???????? 8d85c0feffff 68???????? 50 ff55dc }
		$sequence_20 = { 6a00 6a00 ff75fc ff55f0 6a64 68???????? 6a01 }
		$sequence_21 = { ffd6 ffd0 8d45f4 50 8d45dc 50 68???????? }
		$sequence_22 = { 744e 8d45fc 57 50 ff75d4 }
		$sequence_23 = { ffd0 eb1a 57 8d45ec 57 50 53 }

	condition:
		7 of them and filesize < 172032
}
rule MALPEDIA_Win_Evilpony_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "13d73601-5d44-5a2a-8ba6-978b7f0fd230"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.evilpony"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.evilpony_auto.yar#L1-L128"
		license_url = "N/A"
		logic_hash = "26107a72658e2399bbbb35bc492f4214d63dbd56deefcd62b5ea03b18e6c544a"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c3 833eff 741a 57 ff7608 ff15???????? ff7604 }
		$sequence_1 = { ff4dfc 680100efbe 8d4b01 eb20 3c02 7536 }
		$sequence_2 = { 51 50 56 ff5214 33ff 56 }
		$sequence_3 = { 57 e8???????? 56 e8???????? 83c414 ff750c }
		$sequence_4 = { 50 e8???????? 83c40c eb08 8bc7 e8???????? }
		$sequence_5 = { 8b07 56 8d8dc0f7ffff 51 8d8decf7ffff 51 8d8de4f7ffff }
		$sequence_6 = { 47 6a00 ff750c 56 ff7508 ff15???????? }
		$sequence_7 = { 40 75ef 56 ff7510 56 ff7508 }
		$sequence_8 = { c1ca08 23d1 c1c708 23f8 0bd7 8955d8 8b55b4 }
		$sequence_9 = { c14dac02 8d8c08dcbc1b8f 8b45f0 3345e8 894db4 3345dc 3345c8 }

	condition:
		7 of them and filesize < 147456
}
rule MALPEDIA_Win_Newbounce_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "6787a9dc-3af6-530a-af5b-1a666c35cf16"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.newbounce"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.newbounce_auto.yar#L1-L152"
		license_url = "N/A"
		logic_hash = "cf29db743c2c65c48bca8ecca1cbf193a56565539f9a24f5894c73854816a409"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 83e00f 7e05 2bf0 83c610 }
		$sequence_1 = { 7d15 4863ca 0fb7444b10 664189844868ab0600 }
		$sequence_2 = { 7d13 4863ca 8a44191c 42888401b0380400 }
		$sequence_3 = { 7d16 4863cf 8a84191d010000 42888401c0390400 }
		$sequence_4 = { 7d17 486301 488d0c80 488d05e1f70300 }
		$sequence_5 = { 7d07 ffca 83caf0 ffc2 85d2 }
		$sequence_6 = { 7d0d 4889742420 458ac4 498bcd }
		$sequence_7 = { 7d0a 41ffcb 4183cbfe 41ffc3 }
		$sequence_8 = { 81ec58030000 a1???????? 33c5 8945fc 53 }
		$sequence_9 = { 81ec94040000 a1???????? 33c5 8945ec 53 57 }
		$sequence_10 = { 81ec8c010000 56 a1???????? 33c5 }
		$sequence_11 = { 81ecbc000000 a1???????? 33c4 50 8d8424c0000000 64a300000000 6a00 }
		$sequence_12 = { 81ec68010000 a1???????? 33c4 89842464010000 56 57 8bf1 }
		$sequence_13 = { 81ecb40f0000 a1???????? 33c4 898424b00f0000 53 }
		$sequence_14 = { 81ec64060000 a1???????? 33c4 89842460060000 53 8b5d08 }

	condition:
		7 of them and filesize < 8637440
}
rule MALPEDIA_Win_Pvzout_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "f83d2f67-7fbe-57e6-945d-edec07a6868f"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.pvzout"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.pvzout_auto.yar#L1-L121"
		license_url = "N/A"
		logic_hash = "8c661d5ff2d550f2eb1be89a1c695416ee8464fb24e1ad08f8afd6329c115a8f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { bf95f6810e 75a8 43 1dea50873a }
		$sequence_1 = { 75a8 43 2f 3089f33d80f3 }
		$sequence_2 = { 0e 75a8 43 2f 3089f33d80f3 48 e21c }
		$sequence_3 = { bf95f6810e 75a8 43 1dea50873a d4a1 0e 75a8 }
		$sequence_4 = { 2f 3089f33d80f3 48 e21c }
		$sequence_5 = { 1dea50873a d4a1 0e 75a8 43 1dea50873a }
		$sequence_6 = { d4a1 0e 75a8 43 2f 3089f33d80f3 48 }
		$sequence_7 = { 0e 75a8 43 2f 3089f33d80f3 48 }
		$sequence_8 = { b3d7 5a bf95f6810e 75a8 43 1dea50873a d4a1 }
		$sequence_9 = { 43 2f 3089f33d80f3 48 e21c }

	condition:
		7 of them and filesize < 573440
}
rule MALPEDIA_Win_Zenar_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "512d9ee6-0c5b-5e3e-98bd-c3c533db373b"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.zenar"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.zenar_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "0fcf243782f749816c07708d493946ce52898809b6584dbfb0a2a7d3e318865c"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c785bcf7ffff0f000000 c685a8f7ffff00 e8???????? c645fc06 8d8d90f7ffff 8bbda4f7ffff 83ff10 }
		$sequence_1 = { e8???????? eb52 8d4e4c e8???????? 8945d8 8d4dc8 8d45d8 }
		$sequence_2 = { 8365fc00 8b049d98ae4300 8b4de0 f644012801 7515 e8???????? c70009000000 }
		$sequence_3 = { 8b9dd4f6ffff 660f1f440000 660fbe07 0fb7f0 3bca 7326 }
		$sequence_4 = { ff15???????? ff15???????? ffb5f0fdffff ffd7 ffb5f4fdffff eb01 50 }
		$sequence_5 = { 2bc2 8b55e4 8bcb d1f8 2bca 3bc1 7734 }
		$sequence_6 = { 83c001 25fe030000 f20f592c85e0154300 f20f591485e0154300 660f5834c5f01d4300 660f54c5 f20f5ce8 }
		$sequence_7 = { e8???????? 8b404c 83b8a800000000 750e 8b04bd98ae4300 807c302900 741d }
		$sequence_8 = { ff7510 8365fc00 8bc8 ff750c ff7508 56 }
		$sequence_9 = { 7418 83f83f 7413 8d047e 50 e8???????? }

	condition:
		7 of them and filesize < 519168
}
rule MALPEDIA_Win_Railsetter_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "791609ef-2649-5b9f-aae4-cea725aaf48c"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.railsetter"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.railsetter_auto.yar#L1-L132"
		license_url = "N/A"
		logic_hash = "6bc1adc06cae37b98aa7e4251d177a2b4d22e8197eefaf44734eb25e3dc794b5"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 498bcf e8???????? 488bc8 0fb754247e e8???????? }
		$sequence_1 = { e9???????? 488d8ae8020000 e9???????? 488d8ab0020000 e9???????? 488d8a70010000 e9???????? }
		$sequence_2 = { 488b9540070000 4c8d0573300100 498bce e8???????? 85c0 7461 e9???????? }
		$sequence_3 = { 488d4c2420 ff15???????? 85c0 7418 ff15???????? 8bc8 2b4c2424 }
		$sequence_4 = { 410fb608 83e10f 4a0fbe8419587e0400 428a8c19687e0400 4c2bc0 418b40fc d3e8 }
		$sequence_5 = { 498bd5 48c1e506 48c1fa06 4c8d1dffa60200 4889542440 498b04d3 4484442838 }
		$sequence_6 = { 498bca 488b4030 ff15???????? 85c0 7405 83e801 7557 }
		$sequence_7 = { 482bd7 4c3bc2 0f87a6000000 4885ff 750c 498bc0 4883c420 }
		$sequence_8 = { 8b5598 e8???????? 488bc8 488d15e2ec0400 e8???????? 488bc8 8b559c }
		$sequence_9 = { 4533c0 488d1d85aefdff 458bc8 4c8bd9 418a03 413a8419889c0400 740a }

	condition:
		7 of them and filesize < 866304
}
rule MALPEDIA_Win_Turla_Silentmoon_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "886e119e-eb9a-5f1a-a12e-f83a1b204cbd"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.turla_silentmoon"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.turla_silentmoon_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "bf0501b816ca33635214ac0fa37481fefad2cd940a06eb2a823287cb8d8d3ab6"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b55ec 4a 8945f8 894de4 3bc2 7e26 8b4520 }
		$sequence_1 = { 7dd1 8b55f0 8b7df4 b920000000 2b8e5c020000 2b4dd0 d3e7 }
		$sequence_2 = { 83ec18 8b4620 8b4e18 8b9668020000 53 8b5e24 }
		$sequence_3 = { 8b442420 83c40c 6a00 6880000000 6a02 6a00 6a03 }
		$sequence_4 = { 85c0 7406 c70000000000 8db794130000 c787c413000000000000 e8???????? }
		$sequence_5 = { 56 8bf8 8944243c e8???????? 83c408 84c0 0f840b070000 }
		$sequence_6 = { c745f820000000 8bc8 c1f905 8d148b 8bc8 83e11f be01000000 }
		$sequence_7 = { 33c1 898e60020000 898664020000 83fb01 7e07 c7464c00000000 83be6802000002 }
		$sequence_8 = { 52 6880000000 8d44247c 50 51 ff15???????? }
		$sequence_9 = { 894de4 8945f4 c745f800000000 85c9 0f8e1c010000 8bc1 0591000000 }

	condition:
		7 of them and filesize < 204800
}
rule MALPEDIA_Win_Maggie_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "b6023199-5992-5836-a118-81146f6dd2e2"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.maggie"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.maggie_auto.yar#L1-L115"
		license_url = "N/A"
		logic_hash = "5db5b37af3d0221d86a1240055df99486606f604db769858da98aaf3281c3208"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 663b05???????? 7505 e8???????? e8???????? }
		$sequence_1 = { ff15???????? 83f8ff 750f ff15???????? 2d33270000 f7d8 }
		$sequence_2 = { 750f ff15???????? 2d33270000 f7d8 }
		$sequence_3 = { ff15???????? 83f8ff 750f ff15???????? 2d33270000 }
		$sequence_4 = { 750f ff15???????? 2d33270000 f7d8 1bc0 }
		$sequence_5 = { b8ff000000 663b05???????? 7505 e8???????? e8???????? }
		$sequence_6 = { ff15???????? e8???????? 84c0 74ec e8???????? e8???????? }
		$sequence_7 = { ff15???????? 83f8ff 750f ff15???????? 2d33270000 f7d8 1bc0 }
		$sequence_8 = { 7511 ff15???????? 85c0 7407 33c0 }
		$sequence_9 = { 83f8ff 750f ff15???????? 2d33270000 }

	condition:
		7 of them and filesize < 611328
}
rule MALPEDIA_Win_Highnote_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "b0d28496-8673-59fb-b567-198b148df4f3"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.highnote"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.highnote_auto.yar#L1-L126"
		license_url = "N/A"
		logic_hash = "7cacc14b2d0dfaf54710df19550a1288a5ab7f5eb6146a6937a043c66ae24b0f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 3c7b bc9e36398f 8027e9 82ad42476080cd e009 }
		$sequence_1 = { 47 365e 3007 7bae 97 9d 884d13 }
		$sequence_2 = { a8b9 a1???????? 9c 6857414608 d4dc 59 93 }
		$sequence_3 = { 33c5 8945fc 8b4508 53 6808090000 8945e4 e8???????? }
		$sequence_4 = { 4f 59 7def 889de81be9ec b96b0b724f 262415 3a1f }
		$sequence_5 = { 0e ed 47 6908b79d84b8 6935????????3e1f20f8 4a d14529 }
		$sequence_6 = { e76e a9a4fec7f3 1b90bff8ccdd b1e4 f7f4 }
		$sequence_7 = { 0f85dc000000 b763 42 20ce e04b 2bea }
		$sequence_8 = { 1cfe 5f 3d4b9c06b4 12a4c5ea7849d5 ba7ab47152 1c98 d24cdca8 }
		$sequence_9 = { 3cff 145d 853e 235ee7 }

	condition:
		7 of them and filesize < 321536
}
rule MALPEDIA_Win_Invisimole_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "0ff65a0e-9374-5ba0-b2c6-8042545ab4f2"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.invisimole"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.invisimole_auto.yar#L1-L122"
		license_url = "N/A"
		logic_hash = "ad45dfe8d10739424d2bfb5a3d1255511f50540cc5fd5c54695c89218d0dfaa4"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b4df0 52 51 68???????? 50 ff15???????? 83c410 }
		$sequence_1 = { 50 33c9 57 c745f02e007400 }
		$sequence_2 = { 7418 8b8dacfeffff 8b3d???????? 51 ffd7 8b95b0feffff 52 }
		$sequence_3 = { 8b4dd0 8d45f4 50 33f6 56 51 }
		$sequence_4 = { 0f8484010000 8b4514 8b4d10 50 }
		$sequence_5 = { 52 b802000000 e8???????? 33c9 83c408 }
		$sequence_6 = { 56 88550b e8???????? 8b4d0c 6a01 8d550b 52 }
		$sequence_7 = { 8b5d08 e9???????? 394dfc 0f84a50b0000 }
		$sequence_8 = { 5b 5d c3 8b15???????? 6a08 6a08 52 }
		$sequence_9 = { a1???????? 50 ffd7 8bf0 89742434 85f6 0f844b010000 }

	condition:
		7 of them and filesize < 139264
}
rule MALPEDIA_Win_Isaacwiper_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "402fca5b-fef9-57a3-8af7-55828631273c"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.isaacwiper"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.isaacwiper_auto.yar#L1-L121"
		license_url = "N/A"
		logic_hash = "bb3fdc439bfb784d24998889e509c5aaf2753883f111e2441af52afa5001a713"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 81ec18010000 56 57 6a00 8d4c241c e8???????? 8b3d???????? }
		$sequence_1 = { ff5010 0fb7c0 89442410 8a03 3c7f 0f8492000000 84c0 }
		$sequence_2 = { 331486 81e2ffffff7f 331486 8bca d1ea }
		$sequence_3 = { e8???????? 8ad0 83c404 33c0 85db }
		$sequence_4 = { e8???????? 8b4de0 8b01 8b4008 ffd0 85c0 740a }
		$sequence_5 = { 8bc8 e8???????? 8bce c744242000000000 }
		$sequence_6 = { c1e80b 47 33c8 897df8 8bc1 25ad583aff c1e007 }
		$sequence_7 = { 57 6bf838 8955fc 8b0495e8670310 }
		$sequence_8 = { 0f84dd000000 50 8d458c 50 e8???????? }
		$sequence_9 = { 8d41e0 89443184 8b4698 8b4004 c7443098d8270310 8b4698 }

	condition:
		7 of them and filesize < 467968
}
rule MALPEDIA_Win_Skyplex_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "087dca5f-d631-5612-bd75-82c0d735f793"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.skyplex"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.skyplex_auto.yar#L1-L121"
		license_url = "N/A"
		logic_hash = "b55412a36eabe71f96854517e823836caf1f285d3ff56ec8f8e1708327797508"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 52 e8???????? 83c408 85c0 7430 68???????? }
		$sequence_1 = { 68???????? 8d9538f7ffff 52 e8???????? 83c408 85c0 0f8490000000 }
		$sequence_2 = { 8d45fc 50 8d8d30ffffff 51 ff15???????? 8d9530ffffff 52 }
		$sequence_3 = { 85c0 0f85d0000000 68???????? 8d85b0f9ffff 50 e8???????? }
		$sequence_4 = { 89430c 8d4310 8d89649c4100 5a 668b31 }
		$sequence_5 = { 8d95b0f9ffff 52 e8???????? 83c408 85c0 }
		$sequence_6 = { 83c201 88953ff6ffff 8d8d38f6ffff e8???????? 0fb6853ff6ffff }
		$sequence_7 = { 752b e8???????? 0fb6d0 85d2 }
		$sequence_8 = { 8b36 8bce c1f905 8b0c8dc0af4100 83e61f c1e606 89040e }
		$sequence_9 = { c7851cf7ffff04000000 c78520f7ffffb0454100 c78524f7ffffe8454100 c78528f7ffff30464100 c7852cf7ffff80464100 }

	condition:
		7 of them and filesize < 262144
}
rule MALPEDIA_Win_Cherry_Picker_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "693cf6bf-824d-575f-8ec6-1b05f43b9760"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.cherry_picker"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.cherry_picker_auto.yar#L1-L120"
		license_url = "N/A"
		logic_hash = "a18945ed58afcda52a823396be83113979b875c227edc6df895cb712023950b0"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ffd6 68???????? 6800010000 68???????? 68???????? }
		$sequence_1 = { 53 8b1d???????? 56 57 6aff }
		$sequence_2 = { 52 8d442428 50 ff542420 8b442420 }
		$sequence_3 = { 56 89442420 ffd3 68???????? 56 }
		$sequence_4 = { 68???????? 56 89442420 ffd3 68???????? }
		$sequence_5 = { ebd5 6a02 6a00 6a00 56 ff15???????? }
		$sequence_6 = { 8bf0 0fbec9 81e6ff000000 33f1 8a4a01 42 }
		$sequence_7 = { e8???????? 83c42c 6a00 6a00 6a04 6a00 6a00 }
		$sequence_8 = { ffd3 68???????? 56 8944242c ffd3 }
		$sequence_9 = { ffd6 68???????? 68e8030000 68???????? 68???????? a3???????? ffd6 }

	condition:
		7 of them and filesize < 712704
}
rule MALPEDIA_Win_Nightclub_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "ae419fb9-f8a2-5699-97f1-5b8d6135890b"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.nightclub"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.nightclub_auto.yar#L1-L126"
		license_url = "N/A"
		logic_hash = "ad9713f91b0af25291f1fed1d9b6f5d3c8f1d4ad6e82c9d91a4c053ba564ec78"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8d4c2420 c644241b00 ff15???????? c744243800000000 8b4d0c 8b7d08 }
		$sequence_1 = { e8???????? 8d8d88feffff ff15???????? 8d8d20ffffff ff15???????? 8b45c4 85c0 }
		$sequence_2 = { 8b4d08 8b510c 83ec08 53 56 }
		$sequence_3 = { c645fc06 ff15???????? 8d4f64 c645fc05 ff15???????? 8d4f54 c645fc04 }
		$sequence_4 = { ff15???????? 83c404 68???????? 8d953cfeffff c7853cfeffff704e0110 c78558feffff65000000 }
		$sequence_5 = { ff15???????? 8bc6 8b4c2430 64890d00000000 59 }
		$sequence_6 = { 8d957cffffff c645fc04 e8???????? c645fc06 8b45c8 8b3d???????? bb???????? }
		$sequence_7 = { 6a01 6a02 8d8d20ffffff c745fc03000000 ff15???????? 8d8d20ffffff 68???????? }
		$sequence_8 = { 33c0 8bff 83b878a7011001 740d 83c014 41 }
		$sequence_9 = { 42 52 8b5508 52 8d7104 8bc7 }

	condition:
		7 of them and filesize < 247808
}
rule MALPEDIA_Win_Iisniff_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "4bfbfb9b-f0a0-5ad5-bf0a-87e59c344bdf"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.iisniff"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.iisniff_auto.yar#L1-L178"
		license_url = "N/A"
		logic_hash = "4c97168f9fdabf944b6aefc147c51fc867314bb2fe5288047f810d674aefedb5"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8d4d01 8d742418 8bd7 e8???????? 6aff 53 }
		$sequence_1 = { 6a03 68000000c0 68???????? ff15???????? 6a02 }
		$sequence_2 = { 8b9424a8000000 52 e8???????? 83c404 b801000000 5f }
		$sequence_3 = { 8b9424b0000000 52 e8???????? 83c404 8b442420 c78424c40000000f000000 }
		$sequence_4 = { 8b442418 8b4004 397c0420 0f85ba010000 6a0a 8d4c041c 51 }
		$sequence_5 = { ffd1 8b54240c 52 e8???????? 8b4f08 8b9780000000 83c404 }
		$sequence_6 = { 85c0 0f8560040000 391d???????? 0f8686020000 }
		$sequence_7 = { e8???????? 8bc7 8b8c2418010000 64890d00000000 59 5f }
		$sequence_8 = { 894628 897e2c e8???????? 884630 397e28 750a 57 }
		$sequence_9 = { 8bc8 ff5254 89442414 85c0 0f8c53010000 6a02 5e }
		$sequence_10 = { e8???????? 8b44244c 8b4004 397c0454 0f8429010000 8d8424d0010000 50 }
		$sequence_11 = { 8d45f4 64a300000000 8965f0 8b7d08 57 8d45dc 33f6 }
		$sequence_12 = { 33c0 8b8c2460030000 64890d00000000 59 5f 5e 5b }
		$sequence_13 = { 0f84fd000000 385f41 0f84f4000000 8b07 6aff ff5004 }
		$sequence_14 = { 8bc1 c20800 c20400 6a34 }
		$sequence_15 = { 50 ff74243c ff5214 85c0 }

	condition:
		7 of them and filesize < 1441792
}
rule MALPEDIA_Win_Harnig_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "9abf1275-be08-57a2-b590-38e4b33996cd"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.harnig"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.harnig_auto.yar#L1-L126"
		license_url = "N/A"
		logic_hash = "87f18fe78ccecf6b99a233ae62c504e49ba2ae60d8433aec1b3aa385be172cee"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ebba be0cfb1473 56 6a03 e8???????? ff7508 }
		$sequence_1 = { be0cfb1473 56 6a03 e8???????? ff7508 ffd0 56 }
		$sequence_2 = { e8???????? 6a04 8d4df8 51 6a06 ff750c ffd0 }
		$sequence_3 = { 6a06 56 68???????? e8???????? 56 8d85b8fdffff }
		$sequence_4 = { ffd0 bb30ef0298 53 6a01 e8???????? 57 }
		$sequence_5 = { 33ff 8945d0 68d34ee485 8d85b8fdffff 6a04 c745c03c000000 897dc8 }
		$sequence_6 = { ffd7 6a06 56 68???????? e8???????? }
		$sequence_7 = { e8???????? 56 8d85e0fdffff 50 ffd3 e8???????? }
		$sequence_8 = { f3ab e8???????? 8d4df0 51 8d4dac 51 }
		$sequence_9 = { 68d34ee485 8d85b8fdffff 6a04 c745c03c000000 897dc8 c745cc6c104000 }

	condition:
		7 of them and filesize < 49152
}
rule MALPEDIA_Win_Horus_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "12c7c021-b153-5474-a74c-469890c1e922"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.horus"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.horus_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "e6787ec58c9bb6d38c2247320608a821821bda6e6175a9ae30fe8afbfa0a881e"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b442448 eb0a 498bcb e8???????? 03c3 8bc8 488b442450 }
		$sequence_1 = { 75c6 488bde c7442438077c0300 ebda ff15???????? 4c8bc3 33d2 }
		$sequence_2 = { 7419 3d05d80100 0f85f0000000 48895550 c744243099b90100 ebbb 488b8d88000000 }
		$sequence_3 = { 488bc8 ff15???????? 8bc5 eb02 33c0 488b5c2450 4883c420 }
		$sequence_4 = { bf01000000 c745706c320300 e9???????? 33d2 488d4de0 448d4228 e8???????? }
		$sequence_5 = { 4533c0 e9???????? c785300300008a030000 498bf8 8b8530030000 3bc0 0f85d1000000 }
		$sequence_6 = { e8???????? 4c8b4640 488d95e80b0000 498bcc e8???????? 488d9518090000 498bcc }
		$sequence_7 = { 4c39542438 0f84b7050000 4d85f6 0f84ae050000 4c8b442430 4d3910 0f8499050000 }
		$sequence_8 = { 83e23f 4181e0ff030000 8bc2 81e1c0030000 4883c305 83c140 c1e00a }
		$sequence_9 = { 7406 488d55e0 eb28 488d9598010000 eb1f 488d5588 eb15 }

	condition:
		7 of them and filesize < 887808
}
rule MALPEDIA_Win_Sphijacker_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "9cef3de3-26e3-590c-b75c-c3742ae27ed2"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.sphijacker"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.sphijacker_auto.yar#L1-L119"
		license_url = "N/A"
		logic_hash = "a3669f2501be54f6db7bc187d473b642ff5b40ce67de3f9c62283a9442bf36dc"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 488d4518 41b93f000f00 4533c0 4889442420 488d1573de0100 }
		$sequence_1 = { 488d1d9f250200 488d3d98250200 eb12 488b03 }
		$sequence_2 = { 488d054a9f0100 483947f0 741a 488b0f 4885c9 7412 }
		$sequence_3 = { 488d4510 c744242804000000 488d1539e30100 41b904000000 4889442420 4533c0 c7451088888888 }
		$sequence_4 = { 488d1c8d00000000 8d040e 4c8bc3 488d8d34030000 898530030000 e8???????? 488d0daae7feff }
		$sequence_5 = { 488d3d51c90100 eb07 488d3d30c90100 4883a4248000000000 4584f6 740b }
		$sequence_6 = { c3 836a1001 0f88b65e0000 488b02 8808 48ff02 }
		$sequence_7 = { 4c8d0d9de80000 33c9 4c8d0590e80000 488d1591e80000 e8???????? }
		$sequence_8 = { 4863c9 4c8d05c4ad0100 488bc1 83e13f }
		$sequence_9 = { c744242804000000 488d15f7de0100 41b904000000 4889442420 4533c0 }

	condition:
		7 of them and filesize < 808960
}
rule MALPEDIA_Win_Toughprogress_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "1b5c7a38-4dc7-5598-b10f-f46434d6af1c"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.toughprogress"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.toughprogress_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "c0c1c77149f9d902f50f8ad322d079392d7a2679f05955ba5dca6220956a2fb7"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 440f280d???????? 440f2815???????? 440f281d???????? 440f2825???????? 440f282d???????? 6666662e0f1f840000000000 f3440f107c0217 }
		$sequence_1 = { 4c032411 48895dd8 4c89f1 4c89fa 4989c0 41ffd4 488b55f8 }
		$sequence_2 = { 89c2 80f20e 4189db 4180f361 34f1 4420d8 80f39e }
		$sequence_3 = { 488d4b20 488b05???????? 48baf554c5b851c51d63 49b8db5381257b97c77a 4c030410 4889f2 41ffd0 }
		$sequence_4 = { 48b92101fe16591834e4 48bab0f1efb8ebe1c8ea 48031408 488b4de8 ffd2 90 4883c420 }
		$sequence_5 = { 488d35f5f30f00 488d0d0afb1000 4c01c2 ffd0 49bf4f9cdb6635605155 488b36 4c01fe }
		$sequence_6 = { 4983c104 4d39c8 75ea 4c39c1 7414 0f1f440000 488b0e }
		$sequence_7 = { 4c01f8 488d4dd8 4c89f2 ffd0 84db 0f8591000000 488d5f70 }
		$sequence_8 = { ffd0 488d5e40 488b4e68 0fb65678 488b05???????? 49b80ee5f89dd0779459 4a8b0400 }
		$sequence_9 = { 4989f0 4989c1 ffd2 488b05???????? 49be8b72da7706fe2b4a 4c01f0 488dbd20020000 }

	condition:
		7 of them and filesize < 3117056
}
rule MALPEDIA_Win_Odinaff_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "c0819e8d-05d9-5d71-8484-6a32cbac67fb"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.odinaff"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.odinaff_auto.yar#L1-L120"
		license_url = "N/A"
		logic_hash = "cb6040dafc098db20cbfae6c2dca9b570812ce4e0e93732c3b77f524fbe3c43e"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff15???????? 3d1f040000 7505 bf01000000 56 ff15???????? 8bc7 }
		$sequence_1 = { 50 53 68???????? 33db b8???????? e8???????? 8b1d???????? }
		$sequence_2 = { 750e ff15???????? 8b4df4 33c0 668901 }
		$sequence_3 = { 56 6804010000 8bd8 ff15???????? 53 6a00 }
		$sequence_4 = { 681c010000 8d8dc8feffff 6a00 51 }
		$sequence_5 = { 6a08 895df8 ffd7 50 ffd6 }
		$sequence_6 = { 50 ffd7 8945f0 33c0 6a3c 50 }
		$sequence_7 = { 03c9 51 56 ffd3 }
		$sequence_8 = { 6a08 8bd8 c745fc00010000 ff15???????? 50 ff15???????? }
		$sequence_9 = { 68???????? 56 8b35???????? c785c8feffff1c010000 ffd6 85c0 }

	condition:
		7 of them and filesize < 73728
}
rule MALPEDIA_Win_Rawpos_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "bd5af652-e3d8-5d9f-872e-75f5b9f8e9a6"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.rawpos"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.rawpos_auto.yar#L1-L129"
		license_url = "N/A"
		logic_hash = "57dbb9f774601b88b121a308342230d83e62dddd884859e560b042e6ee210b59"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 83c414 8945e0 833e00 0f85fa010000 }
		$sequence_1 = { 837dc400 750a 8b4dc0 ff45c0 8819 eb44 66a1???????? }
		$sequence_2 = { 7e0e 8a9502ffffff 8b4dc0 ff45c0 }
		$sequence_3 = { 23f2 23da 3bde 740d 837d1400 752b 33db }
		$sequence_4 = { ff45ec 8b55ec 3b55f4 7ce2 3b758c 722e 8b4d20 }
		$sequence_5 = { ff15???????? 59 837dbc00 7404 33c0 eb0a 8b45d8 }
		$sequence_6 = { 33c9 8a08 f6813523430004 742c 83fa02 7c1b 6a00 }
		$sequence_7 = { 55 8bec 83c4f8 53 56 8b4510 8b5d08 }
		$sequence_8 = { 53 8b4510 83c6ff 50 57 52 e8???????? }
		$sequence_9 = { 7508 33d2 8955c8 ff45e0 837dc800 7503 47 }

	condition:
		7 of them and filesize < 466944
}
rule MALPEDIA_Win_Spank_Rat_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "0c12d18d-2a15-59a1-bb23-19b614c3efa4"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.spank_rat"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.spank_rat_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "08e747faf6543fac39715390527ff1f19875644181182cef164e53720dab2adf"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c7463000000000 895644 83f902 0f44cf 8d7a18 898be4020000 897e3c }
		$sequence_1 = { 885c3801 88543802 eb35 c1e812 897e2c 894e64 8b7e38 }
		$sequence_2 = { e8???????? 58 8b8524feffff 8b8d28feffff 8b952cfeffff c745f003000000 8945cc }
		$sequence_3 = { e8???????? 83c62c 89f1 e8???????? 5d c3 55 }
		$sequence_4 = { e8???????? 59 85c0 0f8561f8ffff 8d96d8020000 8d8e40010000 c702???????? }
		$sequence_5 = { 8b5dac 8b55d4 8b4dc8 8b7ddc f20f1185dcfeffff f20f118dd4feffff f20f1195ccfeffff }
		$sequence_6 = { e8???????? 58 e9???????? 6a1a 5a b9???????? 68???????? }
		$sequence_7 = { f20f109600040000 8d8e88000000 8d9640010000 c686a500000000 f20f114808 f30f7e8e08040000 f20f1100 }
		$sequence_8 = { eb09 83665000 8b55c8 b104 0fb6c1 c1e608 8d8d44ffffff }
		$sequence_9 = { c7460400000000 e9???????? 6a08 58 894604 c6460c06 e9???????? }

	condition:
		7 of them and filesize < 1803264
}
rule MALPEDIA_Win_Neddnloader_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "486ac737-74fe-5b46-a927-a104de45696a"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.neddnloader"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.neddnloader_auto.yar#L1-L166"
		license_url = "N/A"
		logic_hash = "b4a2f2e78b2621c97cd370c28e906094fb39c89e16acc9c97062a177e62221f3"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 41 8bc1 2b45fc 5f }
		$sequence_1 = { 7311 0fb702 0fb731 663bc6 7506 83c102 83c202 }
		$sequence_2 = { 8b5508 69c0b179379e c1e813 03c9 }
		$sequence_3 = { 55 8bec 83e4f8 81ec10060000 a1???????? 33c4 8984240c060000 }
		$sequence_4 = { 47 57 e8???????? 2b5d10 83c40c 03df }
		$sequence_5 = { 83c204 3bcf 72f0 8d43ff }
		$sequence_6 = { ff15???????? 8b4df8 56 3bc8 }
		$sequence_7 = { 72f0 8d43ff 3bc8 7311 0fb702 0fb731 }
		$sequence_8 = { 741e 488bce 488bc6 488d1500370100 83e11f 48c1f805 }
		$sequence_9 = { 4133bc8c804d0100 4133bc8480590100 418bc0 41337d40 }
		$sequence_10 = { 8bcf 8bc7 0f97c1 4d3be5 0f97c0 85c8 }
		$sequence_11 = { 7403 f0ff00 488d4158 41b806000000 488d1560f50000 483950f0 740b }
		$sequence_12 = { 488d4c2470 488d82fef7ff7f 4885c0 7416 }
		$sequence_13 = { 41c1e008 0fb6c8 420fb68421803b0100 4433c0 400fb6c7 420fb68420803b0100 }
		$sequence_14 = { 488d15b1fa0000 48894c2420 4885c9 7419 }
		$sequence_15 = { 83fb0d 0f8c46020000 418b06 488b9c2480000000 4d8d6601 }

	condition:
		7 of them and filesize < 3438592
}
rule MALPEDIA_Win_Crypt0L0Cker_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "299e9ee9-e0b7-5786-b350-22d4ca49928f"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.crypt0l0cker"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.crypt0l0cker_auto.yar#L1-L130"
		license_url = "N/A"
		logic_hash = "4c176c3ab11d977c0b1b28a2f119b7e187d44cd31c0aeb7ba633d4effbded3fe"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 55 6a00 ff35???????? ff15???????? 8bf0 85f6 0f84c0000000 }
		$sequence_1 = { 7409 80f917 0f85b8000000 51 8b0f }
		$sequence_2 = { 8bcf e8???????? 85c0 74e3 8b4508 33c9 8b13 }
		$sequence_3 = { 8d542428 8bce e8???????? 8944241c 85c0 0f845b020000 55 }
		$sequence_4 = { 85c0 756c 8bb538fdffff 83bdd4fcffff01 750c ffb5dcfcffff e8???????? }
		$sequence_5 = { 03d9 3bd9 7301 47 8b4508 0fb75012 0fb74810 }
		$sequence_6 = { 8b542450 e8???????? 83c420 f646f802 742e }
		$sequence_7 = { 6a20 e8???????? 83c410 8bc6 5f 5e 5b }
		$sequence_8 = { 8974241c ff15???????? 85c0 741f 8b442420 85c0 7406 }
		$sequence_9 = { 83c1fe 85c9 7e10 8d642400 66833c4a2e 7409 49 }

	condition:
		7 of them and filesize < 917504
}
rule MALPEDIA_Win_Misfox_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "ad4a465e-502d-557b-9df0-0d09a5d58c98"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.misfox"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.misfox_auto.yar#L1-L174"
		license_url = "N/A"
		logic_hash = "f0284d77322fd81fc80799ff8b17c387a5c86ef9b47522a47cced1f49d8f1bd3"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ddd8 db2d???????? b801000000 833d????????00 0f8536510000 }
		$sequence_1 = { 8bf7 8906 8d7604 40 3d00010000 7cf3 c745fc00000000 }
		$sequence_2 = { 8d44241c 50 6a01 8d442420 50 8d442440 50 }
		$sequence_3 = { 8b0c8550870110 8b8524e5ffff f644080480 0f8475030000 8b9530e5ffff 33ff 89bd34e5ffff }
		$sequence_4 = { c3 8bc1 85f6 7409 }
		$sequence_5 = { 7f0a b80a000000 5e 8be5 5d c3 53 }
		$sequence_6 = { ff74241c ffd6 85c0 7560 8b3d???????? }
		$sequence_7 = { 83e908 8d7608 660fd60f 8d7f08 8b048d08410010 }
		$sequence_8 = { 488d4dff ba00020000 c745cb00020000 448975c7 }
		$sequence_9 = { e8???????? 8b430c 4c8d6708 894308 8b470c }
		$sequence_10 = { 488bc3 488b5c2430 4883c420 5f c3 488d0d4c6f0100 }
		$sequence_11 = { 48837d0810 4c0f434df0 488d4d10 48837d2810 480f434d10 8b4500 }
		$sequence_12 = { eb15 413bc4 753e 0fb65530 0fb64531 }
		$sequence_13 = { 8d41fa 83f801 7774 488b4dbf ff15???????? 83f826 }
		$sequence_14 = { 488bc3 488bfb 48c1ff05 4c8d3526d20000 83e01f 486bf058 498b04fe }
		$sequence_15 = { 4833c4 48894547 488d0d615f0100 ff15???????? 488d4def ba00080000 }

	condition:
		7 of them and filesize < 266240
}
rule MALPEDIA_Win_Karagany_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "051a4713-7062-583b-b07d-0d34998089e0"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.karagany"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.karagany_auto.yar#L1-L115"
		license_url = "N/A"
		logic_hash = "ae2b092f570a3216f957e4b2fa3f2423cddd07a1857ecfea5f38e17e20134d4d"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 6a40 6800300000 6800000300 6a00 ff15???????? }
		$sequence_1 = { 56 8b35???????? 57 8bf8 6a03 57 }
		$sequence_2 = { 8945d0 8945d8 8945e0 8945e8 8945ec }
		$sequence_3 = { 6a03 57 ffd6 85c0 }
		$sequence_4 = { 56 8b35???????? 57 8bf8 6a03 57 ffd6 }
		$sequence_5 = { 56 8b35???????? 57 8bf8 6a03 }
		$sequence_6 = { 8b4508 0526f8ffff 69c06c010000 034510 }
		$sequence_7 = { 8945d0 8945d8 8945e0 8945e8 8945ec 8945f4 }
		$sequence_8 = { 8b35???????? 57 8bf8 6a03 57 }
		$sequence_9 = { 8d85a4fdffff 50 ffd6 68???????? }

	condition:
		7 of them and filesize < 180224
}
rule MALPEDIA_Win_Apocalipto_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "dc88c15d-d94d-505d-9bf2-8a0d577a0cbd"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.apocalipto"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.apocalipto_auto.yar#L1-L122"
		license_url = "N/A"
		logic_hash = "5e96c8af57c0ca9bc40d4713e70c63fc8060637d885e26e21d4be9185b917e66"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 880e b967666666 89d8 f7e9 89d1 c1f902 }
		$sequence_1 = { 891c24 ff15???????? 83ec08 a3???????? 85c0 0f84ad070000 c744240800000000 }
		$sequence_2 = { 6690 42 803a00 75fa 8a0b 84c9 }
		$sequence_3 = { 3b550c 7d25 803800 7430 89c2 6690 }
		$sequence_4 = { 8b30 01fe 8b06 85c0 }
		$sequence_5 = { 7465 8d5803 c785c8f3ffff00000000 e9???????? ff15???????? }
		$sequence_6 = { ff15???????? 83ec08 a3???????? 85c0 0f84070b0000 c7442404???????? 891c24 }
		$sequence_7 = { 891c24 ff15???????? 83ec08 a3???????? 85c0 0f8466070000 c7442404???????? }
		$sequence_8 = { 83ec08 a3???????? 85c0 0f8467090000 }
		$sequence_9 = { c744240800400000 895c2404 893c24 ff15???????? 83ec0c c744240c00400000 }

	condition:
		7 of them and filesize < 212992
}
rule MALPEDIA_Win_Jimmy_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a02c008a-7b1a-57a9-a44d-bbdcf377e4db"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.jimmy"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.jimmy_auto.yar#L1-L130"
		license_url = "N/A"
		logic_hash = "4360760c129b282eec5344a2cb5c77c62ba272bb868af5384019021fa7c85c8f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b450c 8b4df8 8908 eb11 e8???????? }
		$sequence_1 = { 8945f0 a1???????? 83786800 741c 6a00 6a00 8d45e8 }
		$sequence_2 = { c745fc12030900 e9???????? 837de805 752c ff75e4 8b4508 8b4028 }
		$sequence_3 = { 7402 eb10 8b45e8 40 8945e8 8b45e4 40 }
		$sequence_4 = { 85c0 7428 ff7514 ff75dc e8???????? 59 }
		$sequence_5 = { 50 e8???????? 59 ffb580fdffff e8???????? 59 85c0 }
		$sequence_6 = { 8b45ec 0fb600 48 50 8b45f0 ff30 e8???????? }
		$sequence_7 = { 59 0fb6c0 85c0 7418 6a00 ff75f4 }
		$sequence_8 = { e8???????? 59 59 8945fc ff7508 8d45f0 50 }
		$sequence_9 = { 740d 817dfc18030980 0f85ac000000 8b4508 8b4d08 8b402c 3b4128 }

	condition:
		7 of them and filesize < 188416
}
rule MALPEDIA_Win_Hawking_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "ec9f39f6-86ba-5455-97b7-92972ad75506"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.hawking"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.hawking_auto.yar#L1-L121"
		license_url = "N/A"
		logic_hash = "38946ce524bb812dc9a51e3c54c74cdb8d87a613cbaf2402323bc2266d8ec447"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 2c02 16 2a 06 }
		$sequence_1 = { 06 6f2c00000a 26 06 6f2d00000a 6f2e00000a 750d000001 }
		$sequence_2 = { 08 16 08 8e 69 6f2100000a }
		$sequence_3 = { 2d04 26 14 2b05 }
		$sequence_4 = { 281c00000a 02 07 6f1900000a 72ba010070 6f1a00000a 2807000006 }
		$sequence_5 = { 0b 14 0c 732f00000a 0d 16 }
		$sequence_6 = { 6f0e00000a 1200 280f00000a 2dde de0e 1200 fe160200001b }
		$sequence_7 = { 2df6 06 6f06000006 de0c 6f3400000a 2801000006 }
		$sequence_8 = { 0c 07 6f1900000a 72ba010070 }
		$sequence_9 = { 03 282400000a 2801000006 732500000a 0a 06 }

	condition:
		7 of them and filesize < 50176
}
rule MALPEDIA_Win_Parallax_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a33a6421-135e-5a1a-a563-ca84b1c1d371"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.parallax"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.parallax_auto.yar#L1-L124"
		license_url = "N/A"
		logic_hash = "fb65a506de8d9e468d3f17bb552729cc4c08d4943547963b52fcd6013fa33deb"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 68???????? ff75f0 ff750c e8???????? 8b35???????? }
		$sequence_1 = { 6a20 ff35???????? e8???????? 8b1d???????? 331d???????? 85db 7506 }
		$sequence_2 = { 8d35f4ec4000 8d3d04f14000 b908020000 f3a4 }
		$sequence_3 = { 837f04ff 740f 8b35???????? ff7704 ff9688010000 8d87ac000000 50 }
		$sequence_4 = { 8b15???????? ff9284000000 3de5030000 7413 ff7508 }
		$sequence_5 = { 7534 682c010000 ff7508 ff96dc010000 6a00 ff35???????? ff9630010000 }
		$sequence_6 = { 6a00 ff9628010000 6a04 68???????? }
		$sequence_7 = { e8???????? 8be5 5d c20400 8b35???????? 6a00 }
		$sequence_8 = { 8bec 83c4fc c745fc00000000 eb29 8b4dfc 51 e8???????? }
		$sequence_9 = { 8bec 83c4fc 8b35???????? c745fc01000000 c705????????0c000000 c705????????00000000 c705????????01000000 }

	condition:
		7 of them and filesize < 352256
}
rule MALPEDIA_Win_Unidentified_075_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "147c0d53-aecb-5cae-ac7f-14d52d3c203f"
		date = "2023-07-11"
		modified = "2023-07-15"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.unidentified_075"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.unidentified_075_auto.yar#L1-L115"
		license_url = "N/A"
		logic_hash = "10617fdfd534147bc5e0f7e922724e69d45c37af66d21f98c629fa1bac685120"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20230705"
		malpedia_hash = "42d0574f4405bd7d2b154d321d345acb18834a41"
		malpedia_version = "20230715"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 83c40c 6808020000 8d95dcf6ffff 52 6a00 }
		$sequence_1 = { 8bc1 5e 5d c3 55 8bec ff15???????? }
		$sequence_2 = { 52 e8???????? 6a00 8d85ace6ffff 50 8d8dbceeffff 51 }
		$sequence_3 = { 83c40c 33c0 668985d4f4ffff 6806020000 }
		$sequence_4 = { 837d9400 740d 8b55fc c7821002000000000000 837df000 }
		$sequence_5 = { 52 ff15???????? 83c410 b853000000 66898550ffffff }
		$sequence_6 = { 33c0 668945d0 8d4dd4 51 }
		$sequence_7 = { 742c 8b4514 85c0 7421 }
		$sequence_8 = { 85c0 0f8431ffffff b901000000 85c9 0f8515ffffff }
		$sequence_9 = { 81eca4000000 894dfc c745f400000000 c745f800000000 }

	condition:
		7 of them and filesize < 393216
}
rule MALPEDIA_Win_Hermeticwiper_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "e1a0e497-2c0b-5812-b291-9cdc1c4a7b33"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.hermeticwiper"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.hermeticwiper_auto.yar#L1-L127"
		license_url = "N/A"
		logic_hash = "6b83d74e3c01a7aebeaeea5381a68164ebd22ef7afa1e0231854242a2c3eac04"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 51 6880000000 50 6a00 6a00 6800005600 56 }
		$sequence_1 = { 56 8db54cfeffff 57 8bfe }
		$sequence_2 = { 03cf 74c4 8b5718 89550c 6690 0fb7fe }
		$sequence_3 = { ff770c 8d44244c c744241400000000 68???????? 6804010000 50 ff15???????? }
		$sequence_4 = { 8b35???????? 83c410 85db 0f848f000000 83fbff 0f8486000000 8d442410 }
		$sequence_5 = { 0f85d8010000 8b4710 89442418 8b4714 89442428 8b7710 }
		$sequence_6 = { bfc0240000 57 6a08 ff15???????? 50 ff15???????? 6a00 }
		$sequence_7 = { 83c702 8bcf 2bce d1f9 83f903 7419 49 }
		$sequence_8 = { 53 ffd6 85db 7405 83fbff }
		$sequence_9 = { d3e7 0bf8 8b5dcc 8b4ddc 8b45e4 3bcb 7509 }

	condition:
		7 of them and filesize < 247808
}
rule MALPEDIA_Win_Scarecrow_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "7d172623-7456-574f-89e6-0919984f38bf"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.scarecrow"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.scarecrow_auto.yar#L1-L132"
		license_url = "N/A"
		logic_hash = "3ca0a518ea6582e4d0030ff94d964f801d2d1fe09104b2d1e931f6d2e9f3b2d8"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c685adfdffff37 c685aefdffff37 8a85a5fdffff 80bda4fdffff00 753a 33f6 }
		$sequence_1 = { 83c8fc 40 7445 8b4df4 8d4303 83c102 0fafc8 }
		$sequence_2 = { 752c 33c9 0f1f4000 8a840d79ffffff 0fb6c0 6bc025 83e825 }
		$sequence_3 = { 8d8565faffff 898550f5ffff c68540feffff00 c68541feffff11 c68542feffff13 c68543feffff72 c68544feffff13 }
		$sequence_4 = { 51 ff5010 8bf0 c7858cf7ffff05f26700 8b858cf7ffff 99 f7fb }
		$sequence_5 = { c3 833b00 c785e4feffff00000000 0f8695020000 8d4314 8985e0feffff 8b30 }
		$sequence_6 = { c645c305 c645c405 8a8565ffffff 80bd64ffffff00 7534 33db be05000000 }
		$sequence_7 = { 83e956 8bc1 c1e004 03c1 03c0 99 }
		$sequence_8 = { c685ecfdffff00 c685edfdffff55 c685eefdffff64 c685effdffff06 c685f0fdffff64 c685f1fdffff45 c685f2fdffff64 }
		$sequence_9 = { 8985f8feffff c645a800 c645a94c c645aa41 c645ab34 c645ac41 c645ad03 }

	condition:
		7 of them and filesize < 501760
}
rule MALPEDIA_Win_Rook_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "eb025d93-60a9-566e-9d5f-a0fe7761fbde"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.rook"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.rook_auto.yar#L1-L127"
		license_url = "N/A"
		logic_hash = "78008c43541913c45c31a0ae23587bdcc4df0e54239112c547d81ac14586ca8f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 0fb6843050d10400 c1e008 0bd8 498bc2 48c1e808 0fb6c8 c1e308 }
		$sequence_1 = { 488d1d3b030200 eb07 488d1d1a030200 4883a4249800000000 4084f6 740b b903000000 }
		$sequence_2 = { 48894778 488d05ae720300 c7476801000000 48c7477003000000 48898790000000 c7878000000001000000 }
		$sequence_3 = { 8bc3 48c1e808 0fb6c8 420fb6843170940500 33d0 410fb6c2 }
		$sequence_4 = { 488bf9 488d15c7ba0000 b914000000 e8???????? }
		$sequence_5 = { 4883eb01 7582 4183c9ff 41b801000000 498bd4 8bcf ff15???????? }
		$sequence_6 = { 488bd8 4885c0 74e2 488bd6 488bc8 ff15???????? 488bcb }
		$sequence_7 = { 8bc3 48c1e810 0fb6c8 8bc6 48c1e818 458b8496a0a20500 48c1eb18 }
		$sequence_8 = { 8bd9 4c8d0dddce0000 b904000000 4c8d05c9ce0000 488d15b2bb0000 e8???????? }
		$sequence_9 = { 8b8c82b0e20000 4803ca ffe1 4d8bc2 e9???????? 4d8bc2 }

	condition:
		7 of them and filesize < 843776
}
rule MALPEDIA_Win_Fusiondrive_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "3b4a09c2-0111-5202-b184-0fc07706e9b8"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.fusiondrive"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.fusiondrive_auto.yar#L1-L119"
		license_url = "N/A"
		logic_hash = "9d1137998233de5dcf5ebaeb1ce8a1bfcc4ac12894cafc89d0ef00abfefe9aa5"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 90 488d1d56470100 488d35ef2b0100 48895c2420 488d054b470100 483bd8 }
		$sequence_1 = { 4883ec20 8b1d???????? eb1d 488d058b6c0100 ffcb 488d0c9b }
		$sequence_2 = { 4c8d05896b0100 33d2 488d4c2468 ff15???????? 85c0 0f95c3 84db }
		$sequence_3 = { 57 4883ec20 418bf0 4c8d0d77810000 8bda }
		$sequence_4 = { 85c0 0f84ae020000 c744245804000000 897c2420 4c8d4c2458 4c8d842480000000 }
		$sequence_5 = { 4c8d0db9330100 4c8bc0 b201 b9fdffffff e8???????? c605????????01 b001 }
		$sequence_6 = { 48c1f806 488d0d80000100 4183e23f 4903e8 }
		$sequence_7 = { e8???????? 837b1000 75dd 488d051bf90000 483bd8 }
		$sequence_8 = { 8bd9 4c8d0d4d820000 b904000000 4c8d0539820000 }
		$sequence_9 = { 41ffc0 0fb60a 83e10f 4a0fbe8411a8150100 }

	condition:
		7 of them and filesize < 290816
}
rule MALPEDIA_Win_Bookcodesrat_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "c48179a8-d52a-5449-bf2d-198ae16a6982"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.bookcodesrat"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.bookcodesrat_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "d3c282d86f5c117a201fb00591677be414b29263237fddf59216b2cd83fe8b10"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 4c89642448 4c89642450 4c89642458 4489642460 4c89642468 }
		$sequence_1 = { 488b542468 48897c1008 85ff 7925 833b00 0f8599feffff 488d4c2430 }
		$sequence_2 = { 498bcd e8???????? 488b7c2420 488bd8 e9???????? 498b5520 488b4cf508 }
		$sequence_3 = { 488d4c2460 e8???????? 41b820000000 488d15b4b70200 488d4c2460 e8???????? 41b810000000 }
		$sequence_4 = { 3433 428884058f070000 83fa14 7ce4 4863c2 4c8bc1 8bd1 }
		$sequence_5 = { 488d9580010000 488d8f30330000 41b808020000 448bce e8???????? e9???????? 448b4308 }
		$sequence_6 = { 41b820000000 488d15edba0200 488d4c2448 e8???????? 41b810000000 488d151ebb0200 }
		$sequence_7 = { 488d8d40010000 e8???????? 488d9540010000 48895508 41b918000000 4c8d4500 418d510e }
		$sequence_8 = { 488d442460 33c9 c744245404010000 c744245004010000 4889442420 ff15???????? 85c0 }
		$sequence_9 = { 6683387c 0f859f000000 4883c002 4c8d442460 488bd7 488bcb 488907 }

	condition:
		7 of them and filesize < 544768
}
rule MALPEDIA_Win_Sys10_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "489be560-aac0-5808-aed7-963977ab5e3e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.sys10"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.sys10_auto.yar#L1-L116"
		license_url = "N/A"
		logic_hash = "450fff0df78c1d8c41515a845e69f8defa78c8ea1b7f8fa61c8fddc2e824a427"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8bf8 ffd6 85ff 8b3d???????? 7511 }
		$sequence_1 = { 8902 8b4e0c 51 ff15???????? }
		$sequence_2 = { 6a03 68???????? 68???????? 51 52 }
		$sequence_3 = { 6810270000 ff15???????? 33c0 59 c20c00 8b442410 c70044020000 }
		$sequence_4 = { 6810270000 ff15???????? 33c0 59 }
		$sequence_5 = { 8bf8 ffd3 894610 89442418 }
		$sequence_6 = { e8???????? 83c404 e9???????? 56 6a00 56 }
		$sequence_7 = { e8???????? 57 8d542438 53 52 e8???????? }
		$sequence_8 = { 51 ffd7 8b5304 52 ffd7 8b4308 50 }
		$sequence_9 = { 8b963c020000 8b06 52 50 }

	condition:
		7 of them and filesize < 286720
}
rule MALPEDIA_Win_Webc2_Qbp_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "06ba101e-9797-5160-8466-c700bf70efc4"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.webc2_qbp"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.webc2_qbp_auto.yar#L1-L124"
		license_url = "N/A"
		logic_hash = "cb136ce0e6dd81740d74a10fce0e11de9647a6f524e85eac23a0cac8bc2b19b2"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e9???????? 8b85f0feffff 8d4c0001 898dd8fcffff }
		$sequence_1 = { 668b84464e720000 6689844a4e720000 0fbf4df0 8b55ec 668b45f4 6689844a4e720000 0fbf4d08 }
		$sequence_2 = { 83c404 33c0 e9???????? 8b85d8fcffff }
		$sequence_3 = { 8b4df0 83e901 894df0 837df000 7e21 8b55f8 83e201 }
		$sequence_4 = { 6a03 68???????? 8b4508 50 ff15???????? 83c40c 85c0 }
		$sequence_5 = { 8b75ec 668b84464e720000 6689844a4e720000 0fbf4df0 8b55ec }
		$sequence_6 = { ff15???????? 8945e4 837de4ff 7511 8b4de8 51 ff15???????? }
		$sequence_7 = { 66898c504a300000 eb1e 0fbf55fc 8b45e8 0fbf8c504c520000 }
		$sequence_8 = { 81c173020000 0fbf55fc 8b45f4 66898c50907e0000 0fbf4dfc 8b55f4 668b45fc }
		$sequence_9 = { 0fbf5508 8b45ec 668b8c501c7c0000 66894d08 0fbf5508 8b45ec 668b8c504e720000 }

	condition:
		7 of them and filesize < 630784
}
rule MALPEDIA_Win_Protonbot_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "88b6f894-752d-523c-80e9-a429948930fa"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.protonbot"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.protonbot_auto.yar#L1-L122"
		license_url = "N/A"
		logic_hash = "25e8dbed826364c91d73cbf910263e146791214993bee737d07c4bbf26b335b3"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 57 50 8d45f4 64a300000000 8bf1 6a04 c745fc01000000 }
		$sequence_1 = { 83feff 7429 83bdb8feffff10 8d8da4feffff 56 }
		$sequence_2 = { 8d85a0fbffff 0f4385a0fbffff 50 ffb584fbffff }
		$sequence_3 = { 2bca 8d85f0f7ffff 51 50 6a31 }
		$sequence_4 = { 56 ff15???????? 6a0a ffd3 6a00 }
		$sequence_5 = { 837d1c10 8d4d08 0f434d08 51 ff15???????? a3???????? }
		$sequence_6 = { c7859cfeffff00000000 0f4395bcfeffff 8bca c785a0feffff0f000000 c6858cfeffff00 8d7101 }
		$sequence_7 = { e8???????? 83c404 50 ff15???????? 8b1d???????? be02000000 66a3???????? }
		$sequence_8 = { 8bd0 c745d4ffffffff 899554ecffff b901000000 8bc2 c1e81e 33c2 }
		$sequence_9 = { c785a0feffff0f000000 c6858cfeffff00 8d7101 8a01 41 84c0 }

	condition:
		7 of them and filesize < 1073152
}
rule MALPEDIA_Win_Dusttrap_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "5863495f-c370-53a7-8e4c-3576069d5208"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.dusttrap"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.dusttrap_auto.yar#L1-L130"
		license_url = "N/A"
		logic_hash = "43dda453d9c1763f541134b345dc74600b7354307c33aa7109cb41f9bd2c28f5"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 7219 8b4f38 418b10 ffca 03d1 f7d9 23d1 }
		$sequence_1 = { 0fb6423a 0fb65a3b 0fb6723f 418d8c2478a46ad7 }
		$sequence_2 = { 03c2 8b9424f0000000 81c2051d8804 03d0 c1ca09 4103d0 8bc2 }
		$sequence_3 = { 448b457f 41ffc4 418bc4 4883c30c 483bc1 0f8272feffff 4881c4c8000000 }
		$sequence_4 = { 4983ceff 4d8be1 498be8 4c8bea 498b84ffc8bf0200 90 }
		$sequence_5 = { 448d4203 488b4920 e8???????? 4c8bf8 488bd3 0f1f840000000000 48ffc2 }
		$sequence_6 = { 0f1005???????? 418bc2 4c8d4df0 0f100d???????? 41b820000000 488d55d0 0f1145d0 }
		$sequence_7 = { 448bf6 4903df 4981c600ffffff 33d2 41b820030000 4c03f3 e8???????? }
		$sequence_8 = { bab0070bfe 41b847548cfd 48894128 488d0dc8010200 e8???????? 488b0d???????? bab0070bfe }
		$sequence_9 = { 4889442428 488d442450 48895c2458 488b4940 4c8d4aff 4c897c2450 448d4204 }

	condition:
		7 of them and filesize < 421888
}
rule MALPEDIA_Win_Petrwrap_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "3beebd8a-ed51-581b-ad6a-62a9075befaa"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.petrwrap"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.petrwrap_auto.yar#L1-L132"
		license_url = "N/A"
		logic_hash = "75676640352e6de7f3dc0aa47cc0724f0d6903fe1070006954802fd4a4fea2b9"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 897014 8b07 f76518 03c8 33f6 3bc8 7301 }
		$sequence_1 = { 1394c48c000000 8b442464 0108 8b4c2414 8be9 115004 8b442424 }
		$sequence_2 = { 33fb 237c243c 23cb 33f9 8b4c2418 33d0 }
		$sequence_3 = { 237c2430 f7d2 23542454 8bc6 2344243c 33f9 33d0 }
		$sequence_4 = { 8bd8 8b148d80db4600 83e31f c1e306 894df4 8a441a04 895ddc }
		$sequence_5 = { 6800000040 ff7508 ff15???????? 6a00 8bf0 8d45fc 50 }
		$sequence_6 = { e8???????? 83c420 85c0 752f 68eb020000 68???????? }
		$sequence_7 = { 85c0 752a 39442420 7515 57 55 53 }
		$sequence_8 = { 7508 ff4e04 394604 7fef 5b 5f 5d }
		$sequence_9 = { e8???????? 83c404 53 e8???????? 8b442424 83c404 5f }

	condition:
		7 of them and filesize < 1024000
}
rule MALPEDIA_Win_Global_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "621c031d-dd2f-55a4-b85f-583e8754e767"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.global"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.global_auto.yar#L1-L128"
		license_url = "N/A"
		logic_hash = "4bbe8dd4374d8919118b9b68632f03469cf5573b10f156194c5835ee139d7cd5"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 897ddc 8975fc 8b45e4 8b048500514300 8b4de0 f644012801 7519 }
		$sequence_1 = { 33c0 8bfd f3ab 8b44240c ff742410 50 8b08 }
		$sequence_2 = { 8b8f00100000 8bc1 c1e810 0fb6c0 0fb6c9 }
		$sequence_3 = { 8955f8 43 895de4 8b049500514300 897df0 }
		$sequence_4 = { 688d711ed1 56 a3???????? e8???????? 680ea3e69c 56 }
		$sequence_5 = { 8b4c2424 85c9 7f0f 7c07 3d00005000 7706 6a05 }
		$sequence_6 = { 8b8486000c0000 03848e00080000 33d0 8954be2c 8b8624100000 8b8e00100000 89962c100000 }
		$sequence_7 = { 50 55 ff15???????? b910000000 8dbc2410010000 be???????? }
		$sequence_8 = { 50 e8???????? 83c408 85c0 7411 8d44240c 50 }
		$sequence_9 = { 53 8d4640 03c1 55 50 e8???????? 83c40c }

	condition:
		7 of them and filesize < 475136
}
rule MALPEDIA_Win_Whispergate_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "8dba4a3d-c6ef-5a4e-88e6-b4505d95c338"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.whispergate"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.whispergate_auto.yar#L1-L121"
		license_url = "N/A"
		logic_hash = "3378fc3f22da0f117db64000a51d12fb889e84a085f54b2c4e737e390f317b13"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 892c24 e8???????? 89f2 89e8 e8???????? 83f8ff 898610010000 }
		$sequence_1 = { ffd6 a1???????? 85c0 743a }
		$sequence_2 = { 8b54241c 29c6 85f6 0f8483000000 89d0 }
		$sequence_3 = { 8d7c240c 893c24 89442404 e8???????? 31c9 }
		$sequence_4 = { 83d803 29f8 ba2a000000 89fb 66891407 }
		$sequence_5 = { 5e 5f 5d c3 0fbe57ff 85d2 }
		$sequence_6 = { 0f8581000000 8b0d???????? bb???????? 85c9 0f84be000000 bb???????? 8b4308 }
		$sequence_7 = { e9???????? 8b5508 89f0 e8???????? e9???????? c745c000000000 e9???????? }
		$sequence_8 = { 895c2408 c74424041c000000 c70424???????? e8???????? a1???????? }
		$sequence_9 = { c706???????? 893424 8b4d10 89fa 89d8 e8???????? }

	condition:
		7 of them and filesize < 114688
}
rule MALPEDIA_Win_Dpapi_Loader_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "3c4a14a8-3aa0-5c45-b1eb-f63180990747"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.dpapi_loader"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.dpapi_loader_auto.yar#L1-L130"
		license_url = "N/A"
		logic_hash = "386958a68da2ffe18ebacf56d5ea2e270b8ded2b127075c1bd9d225d3ddfb18b"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 488b00 ff15???????? e9???????? 48833a00 7c69 7506 837a0800 }
		$sequence_1 = { 4c8bc3 488d15a04e0400 e8???????? 85c0 744c 4883fe10 488d4c2428 }
		$sequence_2 = { 4c8d4710 488d4b10 493bc8 7416 498bd0 4983781810 7203 }
		$sequence_3 = { 0fb683a0010000 418886a0010000 488daba8010000 483bf5 7415 488b06 488bce }
		$sequence_4 = { 48897c2458 4c8d442438 488d542460 488d4d60 e8???????? 90 488d4c2438 }
		$sequence_5 = { d3e8 4189411c 410fb608 83e10f 4a0fbe8419c07b0400 }
		$sequence_6 = { e8???????? 498b07 4d8bc6 488bd6 498bcf ff5070 498bb788010000 }
		$sequence_7 = { 488d1dd0a80400 eb15 f6c202 488d1ddca80400 488d05eda80400 480f44d8 }
		$sequence_8 = { 0f114718 0f104e18 0f114f28 48894618 48c746200f000000 884608 488b4d10 }
		$sequence_9 = { 8b4f10 3b4810 7411 488bd8 483bc2 744a }

	condition:
		7 of them and filesize < 855040
}
rule MALPEDIA_Win_Lowzero_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "7931eb0c-c5f3-5aa9-a18d-7a78ac7c913e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.lowzero"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.lowzero_auto.yar#L1-L115"
		license_url = "N/A"
		logic_hash = "62091955e4caddbcd2b87f22ee08f45dad91389ce290338af12dd8cb961c0412"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 0fb77b06 85ff 7420 8d4b24 03c8 8b5104 }
		$sequence_1 = { 8d81f8000000 3bd0 72e0 03d9 }
		$sequence_2 = { 57 8b423c 8b55f4 03c6 }
		$sequence_3 = { 5d c3 0fb74314 57 0fb77b06 }
		$sequence_4 = { 47 2bc8 8d4602 03c3 3b450c }
		$sequence_5 = { c7473400000000 8b45d4 89473c 8b441154 }
		$sequence_6 = { c3 e8???????? 5f 5e 5b c70016000000 33c0 }
		$sequence_7 = { ff740854 51 56 e8???????? 8b55fc }
		$sequence_8 = { 0fb61f 83c307 47 0fb607 47 2bc8 }
		$sequence_9 = { 8b45f8 ff740854 51 56 e8???????? }

	condition:
		7 of them and filesize < 433152
}
rule MALPEDIA_Win_Mount_Locker_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "5cb38a6b-7050-52cc-af6d-f88a4dff8ddf"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.mount_locker"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.mount_locker_auto.yar#L1-L158"
		license_url = "N/A"
		logic_hash = "91f9629be835d978bafeae6b4d7a10a6341356f8effd067abf45736cf5189880"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 498be8 4d8bc8 4c8bc2 4c8bf2 }
		$sequence_1 = { 4c8b05???????? 488bcb 488b15???????? e8???????? 85c0 }
		$sequence_2 = { f30f5905???????? 0f5ad0 66490f7ed0 e8???????? }
		$sequence_3 = { 488364242800 4c8d442430 488364242000 4533c9 488b4c2458 33d2 c744243001000000 }
		$sequence_4 = { 81e10000ffff 81f900000780 7503 0fb7c0 }
		$sequence_5 = { 488d4df0 4889442428 4533c9 4533c0 }
		$sequence_6 = { 4c8bf2 8bf1 33d2 33c9 }
		$sequence_7 = { 488b0b 41b902000000 4533c0 33d2 }
		$sequence_8 = { ff15???????? 8bc8 81e10000ffff 81f900000780 }
		$sequence_9 = { ff15???????? 85c0 7509 f0ff05???????? }
		$sequence_10 = { 488bcb ff15???????? 4c8b05???????? 488bcb }
		$sequence_11 = { 7505 e8???????? 833d????????00 7409 }
		$sequence_12 = { 83f835 7513 8d44242c 50 68???????? e8???????? 59 }
		$sequence_13 = { 8bf8 85ff 7523 f0ff05???????? 53 }
		$sequence_14 = { 6a02 50 ff15???????? 03c0 50 }
		$sequence_15 = { e8???????? 83c40c e8???????? ff15???????? 50 68???????? 57 }

	condition:
		7 of them and filesize < 368640
}
rule MALPEDIA_Win_Pubload_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "67912de9-07cf-5dca-ba81-800ddcc4c2d2"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.pubload"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.pubload_auto.yar#L1-L124"
		license_url = "N/A"
		logic_hash = "5251deed8573b2f425fbaae46d9ed7b84db8b1ec8db0e691b6ba799d1eb45a59"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 6a5c 68???????? e8???????? 83c408 33c9 }
		$sequence_1 = { 6a00 ff15???????? 6a5c 68???????? e8???????? 83c408 33c9 }
		$sequence_2 = { ff15???????? 6a5c 68???????? e8???????? 83c408 33c9 68???????? }
		$sequence_3 = { 6a00 ff15???????? 6a5c 68???????? e8???????? 83c408 }
		$sequence_4 = { 6a5c 68???????? e8???????? 83c408 33c9 68???????? 66894802 }
		$sequence_5 = { 6804010000 68???????? 6a00 ff15???????? 6a5c }
		$sequence_6 = { e8???????? 83c408 33c9 68???????? 66894802 ff15???????? }
		$sequence_7 = { 6804010000 68???????? 6a00 ff15???????? 6a5c 68???????? e8???????? }
		$sequence_8 = { 6a00 6a00 6a00 ff15???????? c3 }
		$sequence_9 = { 68???????? e8???????? 83c408 33c9 68???????? }

	condition:
		7 of them and filesize < 524288
}
rule MALPEDIA_Win_Sidewalk_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "7510d21a-b1ed-5146-8748-52eac8977375"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.sidewalk"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.sidewalk_auto.yar#L1-L162"
		license_url = "N/A"
		logic_hash = "f971709e3587c914ff3aba26d37bf7984df90b3895a4ce0cfaf7d07549993a30"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c1e810 880a c1e918 884202 884a03 4183f810 }
		$sequence_1 = { 0bc8 41890c10 488d5204 4983e901 75d4 4863457f }
		$sequence_2 = { 4489750f 44897d03 448965ff 44896dfb }
		$sequence_3 = { 8bc2 33c6 c1c010 4403d8 }
		$sequence_4 = { 3201 41880408 48ffc1 488d040a }
		$sequence_5 = { c1c010 4403d8 4133db c1c30c 03d3 8bf2 }
		$sequence_6 = { c1c708 4403df 458bc3 4433c0 418bc5 }
		$sequence_7 = { 418b09 418bc0 c1e002 4d8d4904 }
		$sequence_8 = { c1c608 c1c010 4403de 4403e8 4133db }
		$sequence_9 = { c1c610 4433f2 c1c710 4403df }
		$sequence_10 = { c1c710 4403df 41c1c610 4503e6 4403cb 4533d1 4403ee }
		$sequence_11 = { 0fb642fe c1e108 0bc8 41890c10 }
		$sequence_12 = { 483bc6 7ce2 4883c640 4883c340 }
		$sequence_13 = { 48ffc1 488d040a 483bc6 7ce2 }
		$sequence_14 = { 33d0 418bc7 33c3 c1c207 c1c00c 4403c8 4533d1 }
		$sequence_15 = { 4403c8 4533d1 41c1c208 4503fa 418bdf 33d8 }

	condition:
		7 of them and filesize < 237568
}
rule MALPEDIA_Win_Pseudo_Manuscrypt_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "e3cd22ee-09ba-5458-9e50-5eb0d84015e7"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.pseudo_manuscrypt"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.pseudo_manuscrypt_auto.yar#L1-L133"
		license_url = "N/A"
		logic_hash = "5b31fafdf20ffb7c80524796f087e59d3754cec58e8d2af3d41b8d430c2cda55"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c706???????? c7460401000000 c7460800000000 c7460c00000000 c7461010270000 e8???????? 6a00 }
		$sequence_1 = { 53 56 8b35???????? 8bd9 6a00 6a00 6a01 }
		$sequence_2 = { ff750c ff7004 8b4e48 56 8b11 ff5210 5e }
		$sequence_3 = { 0f11465c 660fd6466c c7467400000000 ff763c c7464000000000 c7464400000000 c7465403000000 }
		$sequence_4 = { e8???????? 8b7dd4 56 ff75f0 57 e8???????? 8b45fc }
		$sequence_5 = { 50 ff15???????? 8b95e4fdffff 8b8de8fdffff 42 83c118 8995e4fdffff }
		$sequence_6 = { 85c0 7403 50 ffd7 8d4e1c e8???????? ff7608 }
		$sequence_7 = { 6a40 6800300000 57 6a00 ff742440 ff15???????? }
		$sequence_8 = { c745d400000000 837e7000 8bbeb4000000 8bdf 8b464c 8945f4 897dfc }
		$sequence_9 = { 33c9 8945ec 8b87b4010000 8945e8 83fb08 0f8299000000 8bc3 }

	condition:
		7 of them and filesize < 753664
}
rule MALPEDIA_Win_Spider_Rat_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "9f25cb81-687a-5433-b3d2-d2a7c144a975"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.spider_rat"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.spider_rat_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "41268a98344f1f2673cf6c496e43df2338839e5080d3330d378173295934913a"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 488bf2 488bf9 4585c0 7520 e8???????? 488b5c2430 488b6c2438 }
		$sequence_1 = { e8???????? cc 488d15d8a00200 488bc8 ff15???????? 488b0d???????? }
		$sequence_2 = { 4c89742430 be3f000000 89742428 498b0424 4889442420 458bcf 4c8d05bf8b0500 }
		$sequence_3 = { 4c895d50 44885d40 458d431b 488d1555d10000 488d4d38 e8???????? 488d4d38 }
		$sequence_4 = { 3ac3 0f8419030000 0fb744247a 0fb74c2478 440fb7542476 440fb74c2474 440fb7442472 }
		$sequence_5 = { 5e c3 4c89642438 4c8d0d639f0500 4c8d05689f0500 488d15659f0500 488bc8 }
		$sequence_6 = { 740a 488bcf e8???????? eb05 4883670800 488b5c2448 488b742450 }
		$sequence_7 = { 488d9424d0000000 4183c8ff 896c2420 ff15???????? 85c0 }
		$sequence_8 = { 440fb66828 493bee 7514 0fba66301e 0f8212020000 453bee 0f8509020000 }
		$sequence_9 = { 488bd9 4883c160 ff15???????? 488b4b20 488b7b18 4c8bc1 4c2bc7 }

	condition:
		7 of them and filesize < 1107968
}
rule MALPEDIA_Win_Prestige_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "bcdd734a-760e-5305-b59d-2695b5978961"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.prestige"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.prestige_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "4c67110769e30514bc904af584454bec43c244fac8e39dadd72049d720ccddd1"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 3b45d8 752c 3bd6 7528 8b45e8 8b4de0 3bce }
		$sequence_1 = { 7210 7707 3d00a0724e 7207 6a0e e9???????? 81f9e8000000 }
		$sequence_2 = { 6a09 58 03d0 8955c8 81fa08070000 7d6e 8b4dd0 }
		$sequence_3 = { 8d8dd8f9ffff c645fc80 e8???????? 51 68???????? 8d8df0f9ffff c645fc81 }
		$sequence_4 = { 33d2 42 e9???????? ff75e0 56 e8???????? 8b75e8 }
		$sequence_5 = { 84c0 7509 53 56 e8???????? eb04 c6465000 }
		$sequence_6 = { 8d042f 894310 8bc3 83f910 7202 8b03 8d3428 }
		$sequence_7 = { 8bec 8b5110 3b5114 731b 83791410 8d4201 894110 }
		$sequence_8 = { 743f 8b45f0 33d2 48 f7f6 33d2 8bc8 }
		$sequence_9 = { 53 52 51 8d5e40 8bcf 53 ff5018 }

	condition:
		7 of them and filesize < 1518592
}
rule MALPEDIA_Win_Ondritols_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "dacb9160-2fa3-559f-bf47-c7477f6987c6"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.ondritols"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.ondritols_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "9b6226e15a5ebcca614dccc980f9140cb562c7b8837bc240cadf0047f90be84a"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 83c414 e8???????? 83c040 50 e8???????? 83c404 }
		$sequence_1 = { 50 e8???????? 83c404 8b8d28ffffff c7848d60ffffff00000000 c7852cffffff00000000 8b956cffffff }
		$sequence_2 = { 894108 8b45ec c7400c00000000 8b45ec 8b4808 c1e118 c1f918 }
		$sequence_3 = { 395804 7415 8d4900 8b4804 8919 8b5004 }
		$sequence_4 = { 8d9518ffffff 8910 89b530ffffff 899d2cffffff 889d1cffffff 8d8d78ffffff 51 }
		$sequence_5 = { 52 6a01 8b4508 50 8b4dec e8???????? 8b8df4feffff }
		$sequence_6 = { 83c40c 8b06 8b4804 8b4c3138 33ff 897dec 8975e4 }
		$sequence_7 = { 8b9518ffffff 8b4204 8d8d70ffffff c7840518ffffffd4534600 51 c78570ffffffdc534500 e8???????? }
		$sequence_8 = { 7504 c6451400 8b45e8 8b4d08 894850 8b45e8 8b4d0c }
		$sequence_9 = { 3bc3 7519 8b45e0 83f801 7305 }

	condition:
		7 of them and filesize < 964608
}
rule MALPEDIA_Win_Unidentified_044_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "6eb700da-2e9f-566d-b216-8b582593b50e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.unidentified_044"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.unidentified_044_auto.yar#L1-L125"
		license_url = "N/A"
		logic_hash = "4f60cccd1731d4ef4e70f757e577a0fba8c9578fc3fe077a9b39a7157a06d287"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 52 ff15???????? a1???????? 5f 85c0 7422 8d642400 }
		$sequence_1 = { 8b3d???????? 68???????? ffd7 68???????? ffd7 8b15???????? 52 }
		$sequence_2 = { a1???????? 56 50 be???????? b9???????? e8???????? }
		$sequence_3 = { 7503 32c0 c3 56 68???????? ff15???????? }
		$sequence_4 = { 7505 395e04 7407 8b7620 3bf3 }
		$sequence_5 = { 85c0 74e4 0fb60d???????? 89048d24837000 fe05???????? 85f6 }
		$sequence_6 = { c64424125a bf02000000 3dfe000000 0f8797000000 33f6 6a01 8d442417 }
		$sequence_7 = { ff15???????? 85c0 7442 8d4c2408 51 }
		$sequence_8 = { 660137 ff4c2418 4a 83ef02 89542410 }
		$sequence_9 = { 55 e8???????? 83c40c 84c0 741f 8d642400 807c241200 }

	condition:
		7 of them and filesize < 90112
}
rule MALPEDIA_Win_Faketc_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "969359ba-23ad-5ed9-b63a-bc7c17b33584"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.faketc"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.faketc_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "ff05488c159a83d0eaeaec57b96e8fb3670de8156d7f945004b98c38a179ea38"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c781f886000000000000 8b55f8 c7820487000000000000 8b45f8 c7805804000000000000 8b4df8 c7817004000005000000 }
		$sequence_1 = { e8???????? bd10000000 33db 8d4c247c c684247012000005 e8???????? c684247012000004 }
		$sequence_2 = { e8???????? c7442424d0f14900 c744241840d24c00 c744241c14000000 e9???????? 8d942494000000 52 }
		$sequence_3 = { eb35 8b45e4 50 68???????? 8b4de0 51 e8???????? }
		$sequence_4 = { ffd7 e9???????? 8d950cfdffff 8995a0fdffff 8bf2 c645fc1a e8???????? }
		$sequence_5 = { d0bed0b2d0b0 d0bdd0bdd18b d0b520d182d0 bed0bcd0b0 3c2f 636f6e 7472 }
		$sequence_6 = { e8???????? 83c40c e9???????? 8d9584f6ffff 52 8b4510 50 }
		$sequence_7 = { 8b74240c 8b16 8d4c2420 51 8d4608 52 e8???????? }
		$sequence_8 = { e8???????? 8b4af4 33c8 e8???????? b8???????? e9???????? 8d85d4f9ffff }
		$sequence_9 = { eb0a c785bcfeffff01000000 8b8dbcfeffff 898dc4feffff eb1d 0fb655e4 85d2 }

	condition:
		7 of them and filesize < 6864896
}
rule MALPEDIA_Win_Bee_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "7b79cf75-0ff8-57e6-afa9-901ac56f8833"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.bee"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.bee_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "faf426c3d0907c0b61d7f386e69620a0b3b2ba9837a5815c4e70cadcc6023744"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 3beb 7cb8 8b07 8b5004 8bcf ffd2 5f }
		$sequence_1 = { 8bda e8???????? 8b542424 8b4210 8b5510 50 56 }
		$sequence_2 = { ff15???????? 85db 0f845affffff 8b8e98000000 51 ff15???????? 85c0 }
		$sequence_3 = { 898868010000 8b7e10 397e0c 7605 e8???????? 8b5e0c 8b2e }
		$sequence_4 = { 57 a1???????? 33c4 50 8d442424 64a300000000 807c243400 }
		$sequence_5 = { 83c404 396c2474 7304 8d4c2460 8d542478 52 e8???????? }
		$sequence_6 = { 57 8bf9 8b4f1c 2b4f18 }
		$sequence_7 = { 8b542424 56 6a00 52 e8???????? 8b7c2434 83c40c }
		$sequence_8 = { 56 8bf0 57 3bf5 0f8417010000 8b4510 8b550c }
		$sequence_9 = { 51 c744242c94e24100 e8???????? 8b5508 8b12 66893410 830102 }

	condition:
		7 of them and filesize < 394240
}
rule MALPEDIA_Win_Mutabaha_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "376bf66c-73a7-5a96-b21c-46f1fcf637e9"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.mutabaha"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.mutabaha_auto.yar#L1-L132"
		license_url = "N/A"
		logic_hash = "fb4b77777934a4b350db54146d29a283c26bce8fb5c59b5b92f033ec2770de0f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8bcf e8???????? 3bf0 741a 83ee02 ebd7 }
		$sequence_1 = { 8b0e 8b4604 894104 ff4a04 8b4f18 85c9 7406 }
		$sequence_2 = { 8d4d84 e9???????? 8b459c 83e001 0f840c000000 83659cfe 8b4d80 }
		$sequence_3 = { 33c5 8945fc 53 8b5d08 56 6a00 }
		$sequence_4 = { e8???????? 8b0f 8b01 8b4004 f644080c01 0f8532040000 8b0f }
		$sequence_5 = { 50 56 8d45dc 50 e8???????? 837dec00 7504 }
		$sequence_6 = { 85c0 0f8556010000 ffb5f4f7ffff 8d85fcf7ffff 68???????? 6800020000 50 }
		$sequence_7 = { e8???????? 83c404 c645fc0e 8d8d6ce6ffff 51 8bd0 8d8d3ce6ffff }
		$sequence_8 = { eb05 68???????? 6800020000 50 e8???????? 83c410 8d85fcf3ffff }
		$sequence_9 = { 7426 8d442428 50 6a01 6a02 6a00 68ff010f00 }

	condition:
		7 of them and filesize < 1220608
}
rule MALPEDIA_Win_Applejeus_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "c99e5349-8409-5abd-bd08-befc80fd3cf8"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.applejeus"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.applejeus_auto.yar#L1-L133"
		license_url = "N/A"
		logic_hash = "bd3d6d26c1f7b79856a25c28e6ebe20f46a44cc3bd6b681ec035a077dfa310e3"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 83f065 888520f6ffff 8b8518f6ffff 0405 83f06e 888521f6ffff 8b8518f6ffff }
		$sequence_1 = { 8d8db4fdffff e8???????? 8bbd94fdffff 6a00 8b470c 0fb700 }
		$sequence_2 = { 83c40c c685e8f5ffff1e 33d2 c685e9f5ffff19 8a85e8f5ffff c685eaf5ffff00 66660f1f840000000000 }
		$sequence_3 = { 0f1f840000000000 8a841590feffff 0fbe8d8cfeffff 0fbec0 33c1 88841590feffff 42 }
		$sequence_4 = { 8d8d2cdeffff e9???????? 8d8d30deffff e9???????? 8d8d34deffff e9???????? 8d8d2cdeffff }
		$sequence_5 = { ffb554feffff ffd6 c78558fdffff43000000 8b8558fdffff 83f072 88855cfdffff 8b8558fdffff }
		$sequence_6 = { f7d8 1bc0 2500008000 50 ff770c 8d85d0f7ffff 6a00 }
		$sequence_7 = { 894588 c745dc00000000 c745e000000000 8d7584 c78560ffffff00000000 c78564ffffff00000000 c78568ffffff00000000 }
		$sequence_8 = { e8???????? 6a04 56 e8???????? 6a04 ff75dc e8???????? }
		$sequence_9 = { 8d4da8 e8???????? 8b75ac 8d4db8 83c41c e8???????? 8b7da0 }

	condition:
		7 of them and filesize < 1245184
}
rule MALPEDIA_Win_Nexster_Bot_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a43d5074-419f-56bf-9041-ecb4085c5c0f"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.nexster_bot"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.nexster_bot_auto.yar#L1-L119"
		license_url = "N/A"
		logic_hash = "030c2bb9e4dedc4e668df50b31810c5f051c7ed3a34092c75978caae787f72df"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8a4701 47 84c0 75f8 8b0d???????? 8d84240c010000 }
		$sequence_1 = { 6a00 8908 668b0d???????? 6a00 895004 68000000c0 }
		$sequence_2 = { 42 3acb 75f6 8dbd00080000 8db5000c0000 e8???????? }
		$sequence_3 = { e8???????? 8b54241c 68???????? 8bf0 52 8d44241c 50 }
		$sequence_4 = { 33c0 8da42400000000 8a1485d0604100 889405000e0000 40 83f80b }
		$sequence_5 = { 8d842480000000 50 ff15???????? 8b3d???????? }
		$sequence_6 = { 8d0cbd20804100 8901 8305????????20 8b11 81c200080000 }
		$sequence_7 = { 85c0 0f8581000000 80bc24ae01000001 7533 8b0d???????? 8b15???????? }
		$sequence_8 = { 84c0 75f6 8d85c0140000 48 }
		$sequence_9 = { 75f9 8b1424 6a00 2bc1 8d4c242c }

	condition:
		7 of them and filesize < 245760
}
rule MALPEDIA_Win_Defray_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "2c212e8e-cbb6-56f3-b260-a2356e6a60d8"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.defray"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.defray_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "67a3c8929292a487e5110bec56f6c361320b838daa7878bb3547cfc8ca41f4bc"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 81c630020000 83eb01 75e3 8d8dc8fdffff e8???????? 8d8d98fbffff e8???????? }
		$sequence_1 = { 3bc6 734a 807da100 8a8884e64600 8b4598 8808 7505 }
		$sequence_2 = { ab ab ab 33c0 8dbdf4f9ffff a5 a5 }
		$sequence_3 = { 83c40c 83601000 8b4df0 68???????? 8d4918 e8???????? 8d45ec }
		$sequence_4 = { 6685c0 75ef 46 c785b8fdffff01000000 8935???????? 8d85b8fdffff 33f6 }
		$sequence_5 = { 8d4918 e8???????? 8d45ec c645fc04 50 }
		$sequence_6 = { 52 e8???????? 8bc7 e8???????? c21000 55 8bec }
		$sequence_7 = { 0f85f0030000 8d85c0fdffff 50 ff15???????? 83f8ff 0f84da030000 8d85c0fdffff }
		$sequence_8 = { 83c410 8bf0 8d4dbc 895dfc e8???????? 8b0e c745bc48114800 }
		$sequence_9 = { 8975f0 8b4508 8d4e10 83660c00 8906 8b450c }

	condition:
		7 of them and filesize < 1253376
}
rule MALPEDIA_Win_Thumbthief_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "db3905bb-7231-5d88-b777-00379171d192"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.thumbthief"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.thumbthief_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "8165653ce053fbb55e779e64ab1ebcf612eef7dc6db52589c322fbc23b87168e"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e9???????? 8d8e143d0000 e8???????? 3bd0 0f84f3000000 8d8e203f0000 e8???????? }
		$sequence_1 = { e8???????? c645fc02 8d8d18ffffff e8???????? c645fc03 8d4d9c e8???????? }
		$sequence_2 = { ff75f8 e8???????? 83c40c 85c0 0f856e010000 8bce e8???????? }
		$sequence_3 = { e9???????? 8b4dec 81c1c4210000 e9???????? 8b4dec 81c108230000 e9???????? }
		$sequence_4 = { f30f6f4120 f30f7f4720 f30f6f4130 f30f7f4730 f30f7e4140 660fd64740 8b4148 }
		$sequence_5 = { f644c21c20 8d34c2 8b44b908 8d3c80 7511 8bce e8???????? }
		$sequence_6 = { ff15???????? 8bd8 807e0800 741a 837e1802 b960880000 8d4104 }
		$sequence_7 = { eba7 68de070000 eba0 68df070000 eb99 68db070000 eb92 }
		$sequence_8 = { c785b0feffff0a000000 8b8574feffff 83c0f6 8985acfeffff 8985b8feffff c785b4feffff05000000 c785bcfeffff28000000 }
		$sequence_9 = { eb23 ff7514 ff7510 8bcf e8???????? eb14 885deb }

	condition:
		7 of them and filesize < 4235264
}
rule MALPEDIA_Win_Spedear_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a8a89369-5f3f-5455-aa3a-8d0f5a244f3e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.spedear"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.spedear_auto.yar#L1-L260"
		license_url = "N/A"
		logic_hash = "7981ff403036fac81f3835b6158f5e07c00752ae180632b5718d9f9582e49aef"
		score = 75
		quality = 71
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 83e207 03c2 c1f803 83c40c 85c0 }
		$sequence_1 = { 50 e8???????? 8b7e0c 895e10 }
		$sequence_2 = { 8a5f06 50 894608 e8???????? }
		$sequence_3 = { 57 8bf0 8bfa 8bc7 2507000080 7905 48 }
		$sequence_4 = { 33ce 836c241001 8bf3 75ad 8b4244 8b74241c 8b5240 }
		$sequence_5 = { 50 8bde e8???????? 5b }
		$sequence_6 = { 8d5304 8d4f06 52 e8???????? 8b4718 }
		$sequence_7 = { 6a00 68???????? e8???????? 83c40c 68d0070000 }
		$sequence_8 = { 50 e8???????? 83c420 33c0 396f1c }
		$sequence_9 = { 894618 ffd7 89461c 5f }
		$sequence_10 = { 8bc7 5e 5f 5b 5d c3 6a08 }
		$sequence_11 = { 833e00 741a 6a00 6a00 ff7608 ff5604 }
		$sequence_12 = { 6a00 ff7608 ff5604 6800800000 6a00 ff7608 }
		$sequence_13 = { 394878 7456 39487c 7451 }
		$sequence_14 = { c3 6820040000 b8???????? e8???????? 8b7d08 33db be03010000 }
		$sequence_15 = { 418b0c86 413bcc 7608 428d0422 3bc8 72a8 488bc1 }
		$sequence_16 = { 41be04000000 4d2be3 0f1f00 448bc2 4d8bce 66660f1f840000000000 0fb60431 }
		$sequence_17 = { 6a02 68e8000000 ff15???????? 50 }
		$sequence_18 = { 8bd9 7418 488d0d2bf00000 e8???????? 85c0 7408 }
		$sequence_19 = { ff2485916d2300 838de8fdffffff 89b588fdffff 89b5bcfdffff 89b5c8fdffff 89b5ccfdffff }
		$sequence_20 = { e8???????? 448b5e18 44895f10 8b4e1c e8???????? }
		$sequence_21 = { e8???????? 4c8d1d738c0000 4c891b 488bc3 4883c420 }
		$sequence_22 = { 33ff 8bf3 e8???????? 83bdd0f7ffff10 }
		$sequence_23 = { 448ba088000000 488b4110 4c896c2410 4c89742408 468b74201c 468b6c2024 }
		$sequence_24 = { 41b804010000 c744243004010000 e8???????? 488b4c2438 488d542430 488d442440 }
		$sequence_25 = { 488bfa 488bd9 488d058d760000 488981a0000000 c7411c01000000 }
		$sequence_26 = { 890d???????? 33d2 a3???????? 890d???????? }

	condition:
		7 of them and filesize < 188416
}
rule MALPEDIA_Win_Moker_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "506bb1f3-1a6e-5173-a6b8-b41371cfb69a"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.moker"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.moker_auto.yar#L1-L161"
		license_url = "N/A"
		logic_hash = "7f889f9eebdc91e27549b0607e1ea87da6711b151c6839e65688df858a62e9c4"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 0302 8945d4 8b4dd4 83c102 }
		$sequence_1 = { 0302 8945e8 8b4df8 8b55fc }
		$sequence_2 = { 0302 8945e8 eb09 8b45e8 }
		$sequence_3 = { 0302 50 e8???????? 83c404 3b450c 750b 8b4df0 }
		$sequence_4 = { 0302 8945dc 8b45dc 83c002 }
		$sequence_5 = { 0301 8945e0 e8???????? 8b55e8 }
		$sequence_6 = { 6a00 8b45b8 6bc014 0305???????? 50 }
		$sequence_7 = { 0100 83c414 85c0 7502 eb0a }
		$sequence_8 = { d0838b3f8d57 1c8d 8bae03000029 d1894a018d57 318d8bd20700 }
		$sequence_9 = { 6887000000 ed 713d 8907 }
		$sequence_10 = { 31c0 40 59 5a c9 }
		$sequence_11 = { 8f86b0000000 ff7108 8f86b4000000 31c0 48 5e }
		$sequence_12 = { 50 ff15???????? ed 8408 ebe4 }
		$sequence_13 = { 89442408 48 85c0 0f8409010000 41 c6042401 }
		$sequence_14 = { 8b450c 2580000000 83f800 741d }
		$sequence_15 = { 48 5e 5f 5b c9 c20400 b800000000 }

	condition:
		7 of them and filesize < 1761280
}
rule MALPEDIA_Win_Unidentified_080_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "e05e3dc6-e5d2-5ddf-b092-60ab452f2c88"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.unidentified_080"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.unidentified_080_auto.yar#L1-L130"
		license_url = "N/A"
		logic_hash = "447df05cdb17c0f0f05fa3cc59e3694e8df62d36e58ed0bde45205db0a12131c"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c7433090310210 ff15???????? c7433078310210 8bc3 c745fcffffffff e8???????? 8b4df4 }
		$sequence_1 = { 760f 53 8d75d8 e8???????? }
		$sequence_2 = { 33c0 8945f5 668945f9 8845fb 8b470c 53 2bc1 }
		$sequence_3 = { e8???????? 83c404 894604 85c0 741c 8d0c38 0345e8 }
		$sequence_4 = { ff15???????? 85c0 7526 3bf7 7407 56 ff15???????? }
		$sequence_5 = { 8d5508 52 6a1f 50 ff15???????? b801000000 }
		$sequence_6 = { 6a00 6a00 50 51 6818242200 8d4dbc e8???????? }
		$sequence_7 = { 83f8ff 0f8463050000 be???????? 89b59cfdffff 89bdacfdffff b329 66c785a0fdffff2929 }
		$sequence_8 = { 52 8d0470 50 e8???????? 8b8dbcf7ffff 83c40c 2bdf }
		$sequence_9 = { 33c9 52 66894c780c 83c00c 53 50 8906 }

	condition:
		7 of them and filesize < 392192
}
rule MALPEDIA_Win_Cryptolocker_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "d8377e91-e956-5e02-ad6a-368ae98420be"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.cryptolocker"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.cryptolocker_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "056e1a2754d6589daa7524379beb77ccdb03d545ae31e7dd35318d22b9e309fb"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 0f84d1000000 83fe21 0f84c8000000 83fe22 0f84bf000000 5f }
		$sequence_1 = { b8???????? 0f45c7 33c9 85d2 7521 3808 }
		$sequence_2 = { 6a00 ff35???????? ff15???????? eb10 57 50 6a00 }
		$sequence_3 = { 8b4004 ff743824 ff15???????? 5f 5e 5b 8be5 }
		$sequence_4 = { 83f806 7538 8b0d???????? 85c9 7509 c605????????05 eb25 }
		$sequence_5 = { f7d8 1bc0 2345f8 3bd9 7504 3bf8 }
		$sequence_6 = { 8b4d10 f6c101 7556 8b450c 83f801 7405 83f802 }
		$sequence_7 = { 6a44 8d45a4 56 50 e8???????? 83c40c c745a444000000 }
		$sequence_8 = { 0f8544010000 a0???????? 3c01 757a a1???????? 83f805 7539 }
		$sequence_9 = { 55 8bec 56 8db1e0feffff 8bce e8???????? f6450801 }

	condition:
		7 of them and filesize < 778240
}
rule MALPEDIA_Win_Lokipws_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "283b46a7-a22c-5dce-b2f5-b50b64776e36"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.lokipws"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.lokipws_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "dab98fb05aca565e7a2d5a467561b948c15c3203b005fba98908a0efcb9045f1"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff75fc ff35???????? e8???????? 83c44c 6a00 6a01 53 }
		$sequence_1 = { 68???????? 6a01 be???????? 56 e8???????? 57 53 }
		$sequence_2 = { 83c410 85f6 745f 56 e8???????? 59 85c0 }
		$sequence_3 = { 8bf0 85f6 7468 56 e8???????? 59 85c0 }
		$sequence_4 = { 6800800000 56 53 ffd0 8bde eb03 8b7dfc }
		$sequence_5 = { 83650c00 8365fc00 8365f800 6a02 50 e8???????? 8bd8 }
		$sequence_6 = { 5d c3 55 8bec 6a00 6a00 68e1908ae5 }
		$sequence_7 = { 50 e8???????? 83c418 8945fc 85c0 7529 2105???????? }
		$sequence_8 = { c78510ffffffc0d2e241 53 8d45fc c78514ffffff08104584 50 ff7510 c78518ffffffc975d54d }
		$sequence_9 = { 8bf0 59 85f6 742c 6804010000 6a00 56 }

	condition:
		7 of them and filesize < 1327104
}
rule MALPEDIA_Win_Rtpos_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "ec6410fb-8ac3-55d8-a0e0-833d6edf6d5f"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.rtpos"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.rtpos_auto.yar#L1-L124"
		license_url = "N/A"
		logic_hash = "86f33557c786264394e3871446203167a995b2f0c3eb7592b0020f348ea92bfd"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 0f8e03030000 8b4dbc 0fb611 83fa3d 740f 8b45bc 0fb608 }
		$sequence_1 = { 8945f8 8b4dfc 8b55f8 895110 8b45fc }
		$sequence_2 = { c1f906 6bd030 8b0c8db86a4300 804c112802 5b }
		$sequence_3 = { 51 ff15???????? 85c0 750f 68???????? e8???????? }
		$sequence_4 = { 8b4da0 51 8b55b0 52 8b45bc 50 8b4dac }
		$sequence_5 = { 6bc030 03048db86a4300 eb05 b8???????? f6402820 74c1 }
		$sequence_6 = { 8b4dec 8b4210 ffd0 6a00 6a00 6a04 8b4dec }
		$sequence_7 = { c7420810000000 8b45fc c7400c02000000 c745f800000000 }
		$sequence_8 = { 8b4dfc 8b9168020000 52 e8???????? 83c40c 8b45fc c7806c02000000000000 }
		$sequence_9 = { c745a000000000 e9???????? 8b4508 83c001 894508 8b4d0c }

	condition:
		7 of them and filesize < 507904
}
rule MALPEDIA_Win_Vigilant_Cleaner_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "b2070620-d9f7-5811-b76d-80baf53d08b2"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.vigilant_cleaner"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.vigilant_cleaner_auto.yar#L1-L119"
		license_url = "N/A"
		logic_hash = "7e320a52ca8b714b97d83c5af01f55040082927d0e7ca8657f050cb83fb7182e"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 53 b868584d56 bb00000000 b90a000000 ba58560000 ed 5b }
		$sequence_1 = { ed 5b 59 5a }
		$sequence_2 = { b90a000000 ba58560000 ed 5b 59 }
		$sequence_3 = { b868584d56 bb00000000 b90a000000 ba58560000 ed 5b 59 }
		$sequence_4 = { bb00000000 b90a000000 ba58560000 ed 5b }
		$sequence_5 = { b90a000000 ba58560000 ed 5b 59 5a }
		$sequence_6 = { ba58560000 ed 5b 59 }
		$sequence_7 = { ba58560000 ed 5b 59 5a }
		$sequence_8 = { b868584d56 bb00000000 b90a000000 ba58560000 ed 5b }
		$sequence_9 = { bb00000000 b90a000000 ba58560000 ed 5b 59 }

	condition:
		7 of them and filesize < 1181696
}
rule MALPEDIA_Win_Zhcat_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "4dea5e63-1256-5690-9f7d-6c7129ceb976"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.zhcat"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.zhcat_auto.yar#L1-L117"
		license_url = "N/A"
		logic_hash = "98a93ff9c6f3ed04c9709e8e6f5a1785b7d2e2e43d1553fa0f04208978af1a87"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? 8b45f8 8945b4 8b45f4 83c40c }
		$sequence_1 = { 7353 8bc1 c1f805 8bf1 83e61f 8d3c8540604100 }
		$sequence_2 = { 8b4dfc 83c40c 894104 3975e4 }
		$sequence_3 = { 8d45c8 50 8d45e8 50 68???????? 57 }
		$sequence_4 = { 56 8d34c590444100 833e00 7513 50 }
		$sequence_5 = { 5f ff750c 8bc7 33db 668945e0 ffd6 668945e2 }
		$sequence_6 = { 1bf6 8d7df8 895df4 83e6c2 }
		$sequence_7 = { 59 eb61 8b06 8b4dfc 897d0c 8bf8 }
		$sequence_8 = { 8bf0 897510 83feff 0f849e000000 }
		$sequence_9 = { 59 59 83fe01 7409 895cb5f4 e9???????? }

	condition:
		7 of them and filesize < 376832
}
rule MALPEDIA_Win_Aurastealer_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "e41ff870-1f44-5651-a0c5-c3b53cfa77ee"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.aurastealer"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.aurastealer_auto.yar#L1-L152"
		license_url = "N/A"
		logic_hash = "438c76b099448b6342a7bc8b24706ecc81fa8a1eef0aba6a4dde27d294ea5eb6"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 0f95c0 0fb6c0 c1e006 0d80780000 }
		$sequence_1 = { 01f0 b900000080 89c2 09ca 31c1 }
		$sequence_2 = { 7507 b80a000000 eb15 83e010 83f801 }
		$sequence_3 = { 0f114140 0f114130 0f114120 0f114110 0f1101 e8???????? }
		$sequence_4 = { 09ca 31c1 85c0 0f49ca 89c8 }
		$sequence_5 = { 81fa0c0000a0 741f 81fa030000a0 7507 b80a000000 }
		$sequence_6 = { 31c0 80f92f 0f95c0 c3 }
		$sequence_7 = { 80cb80 e9???????? b308 e9???????? }
		$sequence_8 = { 01442428 8bf1 13d9 33d2 }
		$sequence_9 = { 012c18 42 3bd7 72dc }
		$sequence_10 = { 01442420 13d1 c1eb0b 0fa4c115 }
		$sequence_11 = { 014c241c 13f0 33d2 89742420 }
		$sequence_12 = { 014c2420 8be8 13f0 33ff }
		$sequence_13 = { 0144241c 8b7c2424 136c2414 33c0 }
		$sequence_14 = { 0128 42 3bd7 72db }
		$sequence_15 = { 0002 8a0c0f 83c40c 020e }

	condition:
		7 of them and filesize < 20267008
}
rule MALPEDIA_Win_Bernhardpos_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "c07d45ff-4bbd-5c6d-9066-aab396f37c21"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.bernhardpos"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.bernhardpos_auto.yar#L1-L114"
		license_url = "N/A"
		logic_hash = "0b1424e1b6d3d14c4361c48270653d5c4c0233c7cbd074ecd68f2bf83f46360d"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c1e806 83e03f 8b4d0c 034df4 8a9020544100 }
		$sequence_1 = { c645fd64 c645fe65 c645ff00 b801000000 }
		$sequence_2 = { 817dfcffffff6f 7407 33c0 e9???????? }
		$sequence_3 = { 83bd4cfeffff00 7e0c c78508feffff01000000 eb0a }
		$sequence_4 = { ff15???????? 81bdccfdffffd8010000 0f85d2000000 6a40 8d45a8 }
		$sequence_5 = { 83c408 8b4508 50 e8???????? 83c404 b801000000 }
		$sequence_6 = { 83e863 5f 5e 5b }
		$sequence_7 = { e8???????? 83c408 c785e8fbffff00000000 c785e4fbffff00000000 c785c0fbffff24000000 }
		$sequence_8 = { e8???????? a3???????? 68a86b4aa0 a1???????? 50 e8???????? }
		$sequence_9 = { b801000000 6bc800 81c1???????? 898d58feffff 6a65 ff15???????? 8b8d58feffff }

	condition:
		7 of them and filesize < 368640
}
rule MALPEDIA_Win_Waterminer_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "2a534eb8-9d9c-5bd9-aeca-b5e0da164f1d"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.waterminer"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.waterminer_auto.yar#L1-L160"
		license_url = "N/A"
		logic_hash = "e53e34b0461a0435196ef4d1bfa18622f5fd6c288970234a403508c69ed49afb"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 6a00 68f9030000 68???????? 68???????? }
		$sequence_1 = { 8b45cc 0fb68898e94600 ff248d70e94600 8b55f8 81e2ff64ffff 81ca00900000 }
		$sequence_2 = { 03bc24a8000000 488bcd 4c8d0d35cb0300 83e13f }
		$sequence_3 = { 02d0 49ffc3 418d4001 881418 }
		$sequence_4 = { c1e006 8b0c95c02b4b00 0fbe540104 83e2fd 8b4508 }
		$sequence_5 = { 83bd88fdffff37 0f87270a0000 8b8d88fdffff 0fb6919c794400 ff249560794400 8b85ecfdffff }
		$sequence_6 = { 0344240c 4403d0 428b4405e7 418bd2 }
		$sequence_7 = { 750c 8b5508 8b049524074b00 eb1d 8b4508 8b0c8524074b00 }
		$sequence_8 = { b904000000 6bc900 8b91c02b4b00 81c200080000 3955e4 7375 8b45e4 }
		$sequence_9 = { 03c1 03d0 488d051e580500 418b0400 }
		$sequence_10 = { 837d1000 0f8429010000 b902000000 6bc900 33d2 8b4510 6689940820010000 }
		$sequence_11 = { 8b4d08 034dfc 8b55fc 8a82600a4b00 }
		$sequence_12 = { 03c0 2bc8 0f84ec040000 8d41ff 8b848288d20600 }
		$sequence_13 = { 02c8 41880c18 418a03 240f }
		$sequence_14 = { 03442410 4403e8 428b4405e7 418bd5 }
		$sequence_15 = { 0344240c 4403d0 488d051a560500 418b0400 }

	condition:
		7 of them and filesize < 1556480
}
rule MALPEDIA_Win_Unidentified_087_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "1b2874f1-c918-5932-8f40-2646b02c5a89"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.unidentified_087"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.unidentified_087_auto.yar#L1-L178"
		license_url = "N/A"
		logic_hash = "ded66e6a6182cdb4b252ff7e01b219eb0a952a60e1bcc0c1282a544d6591ef6f"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { f2ae 48f7d1 4c8d41ff 498d4d50 }
		$sequence_1 = { 418bd4 488bcd e8???????? 4c8bd8 4885c0 75d9 }
		$sequence_2 = { 488b03 eb03 488bc3 482bd5 488d0c38 4d8bc4 4903d5 }
		$sequence_3 = { 4a8d1429 4a8d0c28 4d8bc6 4803cd 4803d6 }
		$sequence_4 = { 4533c0 e8???????? 488b442450 48634804 }
		$sequence_5 = { 33d2 448d4268 488d4db0 e8???????? c745b068000000 c745ec01000000 }
		$sequence_6 = { 488d5540 488d4d00 e8???????? 488bc8 e8???????? 448935???????? eb69 }
		$sequence_7 = { 4a8d1429 488d0c38 4d8bc4 4903d4 4c2bc5 }
		$sequence_8 = { 83e01f c1fa05 8b1495602c0210 c1e006 8d440224 802080 884dfd }
		$sequence_9 = { 85db 0f8c0c010000 7f0a 837d1000 0f8600010000 c645fc02 8b0e }
		$sequence_10 = { 6a04 6800100000 53 56 57 ff15???????? 8bf0 }
		$sequence_11 = { 0f8437010000 8b14b8 8911 8b0d???????? 83c104 }
		$sequence_12 = { 8bce 3945c8 8b45b4 7303 8d45b4 8d9554ffffff 52 }
		$sequence_13 = { e8???????? 8a8573ffffff 8b4df4 64890d00000000 59 5e 5b }
		$sequence_14 = { 64a300000000 8b7508 33db bf0f000000 8bc6 897c2430 895c242c }
		$sequence_15 = { e8???????? 33c9 33c0 83c40c 66898d34ffffff }

	condition:
		7 of them and filesize < 462848
}
rule MALPEDIA_Win_Mqsttang_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "8a4b5f44-4e92-5a4a-9654-e9fd50f05a5c"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.mqsttang"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.mqsttang_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "f63a06b297de42c0cb5baf286d5e6f87395f0661855eadc8275dc5465eb1e576"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c7442408c0020000 c7442404???????? c70424???????? e8???????? 8b95ccfcffff 0fb712 8d4ad0 }
		$sequence_1 = { e8???????? 8b530c 8b4210 89c1 83e10e 83f90e 741c }
		$sequence_2 = { 8d749010 8b10 83fa01 7619 8b4004 8b4c2420 890424 }
		$sequence_3 = { f0832801 0f8446030000 8b460c 8b10 85d2 0f8419030000 83faff }
		$sequence_4 = { e8???????? 8bb5a8fcffff 8b4604 8d5801 81fb00010000 899ddcfdffff 0f8f35010000 }
		$sequence_5 = { 8b4310 89442438 0f87fe000000 8b4208 31c9 25ffffff7f 894c2404 }
		$sequence_6 = { e8???????? 83ec08 8b08 3b8bf0000000 89c2 0f84b8010000 8b442458 }
		$sequence_7 = { 8d0482 39c8 89459c 0f84ae010000 8b45a0 894da4 8d5db0 }
		$sequence_8 = { 8d0440 8d04c2 01f2 01f0 39d0 746e 8d7a18 }
		$sequence_9 = { 8d5108 85c0 0f84a1010000 83f8ff 740a f0832a01 0f8447020000 }

	condition:
		7 of them and filesize < 12651520
}
rule MALPEDIA_Win_Purplewave_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "e6a3559e-d00f-5783-9d60-e050d2b7035e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.purplewave"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.purplewave_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "55dca69ac9b6565dfaf3474abc6fa54435708af5928e699a1722a16c7e690ecd"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8bf1 8b7d08 8bc7 2b06 99 6a28 59 }
		$sequence_1 = { 8b45a0 50 8b08 ff5108 ff15???????? 68???????? }
		$sequence_2 = { e8???????? ff7508 8d4dd0 c645fc01 e8???????? }
		$sequence_3 = { e8???????? c20800 55 8bec 81ec18020000 a1???????? 33c5 }
		$sequence_4 = { e8???????? 895e3c 8bc6 895e40 895e44 895e48 895e4c }
		$sequence_5 = { ff5108 8b4d94 85c9 0f8506feffff 8d45a4 8bcf 50 }
		$sequence_6 = { 8bc1 eb03 83c8ff 8b4dfc 5f 5e 33cd }
		$sequence_7 = { 85c0 7528 8bce e8???????? 8b5640 8b7644 8b4df4 }
		$sequence_8 = { 59 c645fc44 0bdf 83781410 899d3cffffff 7202 8b00 }
		$sequence_9 = { 8bf7 6a06 59 8bfa f3a5 83601000 8bfa }

	condition:
		7 of them and filesize < 1400832
}
rule MALPEDIA_Win_Ave_Maria_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a0e0414d-62d6-5506-9ca3-a71286611620"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.ave_maria"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.ave_maria_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "443038418d425ca2cd003304bfa0dea222de0f5a1f8c3b0cbdbc70bc42e72a17"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 5e 2bd6 8b75f4 8b7d0c 6a02 58 03c8 }
		$sequence_1 = { 6801000080 ff15???????? 85c0 7532 8d45fc c745fc04010000 50 }
		$sequence_2 = { 8b450c 8d55fc 56 52 51 33f6 }
		$sequence_3 = { e8???????? 8d4de0 e8???????? 5f 5e c9 c3 }
		$sequence_4 = { 8d4ddc e8???????? 50 8d4dec e8???????? 8b4ddc e8???????? }
		$sequence_5 = { 55 8bec 81ec00010000 33c0 53 56 }
		$sequence_6 = { 56 8bf1 833e00 7505 33c0 40 }
		$sequence_7 = { ff75e0 56 e9???????? 53 eb93 8b75ec e9???????? }
		$sequence_8 = { 8b45fc 8d55f4 57 52 6a01 8b08 50 }
		$sequence_9 = { 83660c00 83660800 5f 5e c3 55 8bec }

	condition:
		7 of them and filesize < 237568
}
rule MALPEDIA_Win_Sanny_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "108fdbf7-1d13-52d4-af5f-aa9dd95cc35c"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.sanny"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.sanny_auto.yar#L1-L127"
		license_url = "N/A"
		logic_hash = "5e3883bc41a38cd62fd9b1025736ca94a220479514f6fb9bdd16c2f659af3b32"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8b5c2410 c1c20e 03d7 03d1 8bfa 33fe 23f9 }
		$sequence_1 = { 8b54246c 52 68???????? 56 e8???????? 8b442478 8b4c2470 }
		$sequence_2 = { 51 8d0480 8d1480 8b842404120000 }
		$sequence_3 = { 8d442422 6a7f 8d8e04c50000 50 51 55 8bce }
		$sequence_4 = { ff35???????? ff15???????? 5e c3 55 8bec 81ec50040000 }
		$sequence_5 = { 8bfd 6a1a 55 50 f3ab ff15???????? 85c0 }
		$sequence_6 = { f2ae f7d1 2bf9 8d9424a0020000 }
		$sequence_7 = { c1f805 83e21f 8b0485c0864100 8d04d0 eb05 b8???????? }
		$sequence_8 = { 53 56 57 8bfa 83c9ff 33c0 8b742418 }
		$sequence_9 = { 0fbe4c0474 51 68???????? 52 ffd5 8d442448 8d4c2454 }

	condition:
		7 of them and filesize < 253952
}
rule MALPEDIA_Win_Pteranodon_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "080a0b09-e604-5865-be86-e3e02ad65853"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.pteranodon"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.pteranodon_auto.yar#L1-L180"
		license_url = "N/A"
		logic_hash = "d212aac965920b1cd6d70a6ca741bdc3fa0b51912a4d79c7f46820032d65a123"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { e8???????? ff75b8 8b5db4 33c0 53 668906 ff75c0 }
		$sequence_1 = { 8bf1 68???????? 8975f8 ff15???????? 85c0 }
		$sequence_2 = { c7869800000038c90210 c7460401000000 8b4dfc 5f 5e 33cd 5b }
		$sequence_3 = { 2bc2 03ca 50 8d85b4fbffff 50 }
		$sequence_4 = { 8d45fc c745f400000000 50 6a00 6a00 8bf1 }
		$sequence_5 = { 25f0070000 660f28a040314300 660f28b8302d4300 660f54f0 660f5cc6 }
		$sequence_6 = { ffd6 ffb5f8fdffff ffd6 33c0 e9???????? 6a00 6a00 }
		$sequence_7 = { 8b8574f8ffff c78504f9ffff0f000000 c78500f9ffff00000000 c685f0f8ffff00 83f810 7213 40 }
		$sequence_8 = { 660f56fa 660fc5cc03 25ff000000 83c001 25fe010000 f20f593c8538f34200 660f122c8538f34200 }
		$sequence_9 = { 51 0f4345d8 50 ff15???????? 898594feffff 83f8ff 0f847e000000 }
		$sequence_10 = { 57 68???????? ff35???????? 8d45e4 8bf9 }
		$sequence_11 = { d1f8 2b14c5e0f00210 7413 85d2 7905 }
		$sequence_12 = { 0f57c0 6a01 50 0f1145e8 }
		$sequence_13 = { 0f8530ffffff b8ffff0000 0fb7c0 0fb7f0 8b55e8 83fa10 0f8288000000 }
		$sequence_14 = { 6a09 68???????? 8d8dd8f8ffff c785ecf8ffff0f000000 c785e8f8ffff00000000 c685d8f8ffff00 e8???????? }
		$sequence_15 = { c1f806 6bc938 8b0485e0874300 0fb6440828 83e040 5d c3 }

	condition:
		7 of them and filesize < 499712
}
rule MALPEDIA_Win_Urlzone_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "4dd4d8e5-7756-57be-8ce5-a21c7832bb2c"
		date = "2026-01-05"
		modified = "2026-01-06"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.urlzone"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.urlzone_auto.yar#L1-L126"
		license_url = "N/A"
		logic_hash = "c42481bd862ad161fd4e6a711568aaf0139280c4a77d4d9855a08ac723543c9d"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260105"
		malpedia_hash = "19b79e7cab4eaf532122e5b45a77dd8f6bb5cc79"
		malpedia_version = "20251219"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 55 8bec 81c4e8fbffff 53 56 57 8b4514 }
		$sequence_1 = { 8910 33c0 8943e4 c745fcffffffff eb1f 46 83c340 }
		$sequence_2 = { 83fbff 0f8420070000 6a00 53 e8???????? 8945f8 }
		$sequence_3 = { 50 e8???????? 6a00 6a00 2df1000000 50 8b06 }
		$sequence_4 = { 6a00 56 6a00 6802000001 6a00 53 }
		$sequence_5 = { 85c0 7c04 85d2 7d02 33c9 8bc1 c3 }
		$sequence_6 = { 50 e8???????? b001 e8???????? 68???????? 68???????? e8???????? }
		$sequence_7 = { c6041000 bf01000000 8db36cfeffff 8b06 85c0 7438 }
		$sequence_8 = { bb???????? 8b45f8 50 8d8577ffffff 50 }
		$sequence_9 = { 7435 e9???????? 56 8d85effdffff }

	condition:
		7 of them and filesize < 155648
}
rule MALPEDIA_Win_Netspy_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "d2a1c13e-c6b8-5d87-8e33-32faf1090fbe"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.netspy"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.netspy_auto.yar#L1-L102"
		license_url = "N/A"
		logic_hash = "173fac619e55d7365d19aa46a3306ea222bbc682a6dfa5bded395960899ad474"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { b810000000 e8???????? 4829c4 488b85b82e0000 4889e1 488901 488b01 }
		$sequence_1 = { 833d????????0a 0f9cc1 89d0 05b88b5b1a 83c001 }
		$sequence_2 = { 4883ec20 e8???????? 488b95d8130000 448b85e4130000 4883c420 }
		$sequence_3 = { 0f8505000000 e9???????? 488b8510520000 0fbe00 89c1 83e120 }
		$sequence_4 = { e8???????? 4829c4 488b8518130000 4889e1 }
		$sequence_5 = { 3d33084a60 0f8467030000 e9???????? 8b857c2f0000 3da51c0a0c 0f8463010000 }
		$sequence_6 = { 48898580340000 e9???????? 488b8580340000 488b4018 48898578340000 }
		$sequence_7 = { 4829c4 488b85e8120000 4889e1 48898d58640000 e8???????? 4829c4 }

	condition:
		7 of them and filesize < 12033024
}
rule MALPEDIA_Win_Wannahusky_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "7a80848d-3fef-5c6b-8da8-b340ccbe0d53"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.wannahusky"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.wannahusky_auto.yar#L1-L122"
		license_url = "N/A"
		logic_hash = "b54fe13c60a6f004e6cf9e80bb7c71936b130641724dd721726d7e3bfb2eb537"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c705????????d11d4100 c705????????60b54100 c605????????01 c705????????20000000 c705????????c0464200 c705????????de1d4100 }
		$sequence_1 = { c705????????00000000 c705????????04000000 c705????????04000000 66c705????????1903 c605????????01 c705????????10000000 c705????????00464200 }
		$sequence_2 = { 66c705????????1903 c605????????01 c705????????0c000000 c705????????40464200 c705????????061d4100 c705????????20b44100 }
		$sequence_3 = { ba???????? e8???????? c7042401000000 e8???????? 890c8540bc4100 }
		$sequence_4 = { e8???????? 84c0 7405 e8???????? 8b45d4 8945bc 85db }
		$sequence_5 = { c705????????0c1e4100 c705????????f0b54100 c705????????04000000 c705????????04000000 }
		$sequence_6 = { c705????????a8b54100 c705????????04000000 c705????????04000000 c605????????16 c705????????a0474200 }
		$sequence_7 = { 8d8500fbffff 57 89d7 f3a5 }
		$sequence_8 = { 8b4db8 ba01000000 0fb63c01 8d4dd0 c1e708 e8???????? 84c0 }
		$sequence_9 = { c705????????b0b14100 c705????????04000000 c705????????04000000 c605????????16 c705????????a02b4200 c705????????8b4b4000 c705????????00000000 }

	condition:
		7 of them and filesize < 862208
}
rule MALPEDIA_Win_Kwampirs_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "518bf747-0ec0-5890-a44d-935f6a988921"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.kwampirs"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.kwampirs_auto.yar#L1-L121"
		license_url = "N/A"
		logic_hash = "594acfa7ac6e695335469ba63a047bbb465864dd00f11675d66afc1b94cf5fba"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { b80d000000 ba02000000 f7e2 0f90c1 }
		$sequence_1 = { 56 8b0f 51 e8???????? 83c418 85c0 7512 }
		$sequence_2 = { 50 6a01 56 8b0f }
		$sequence_3 = { 668955f4 33d2 668955f6 e8???????? 83c40c 33d2 }
		$sequence_4 = { 8be5 5d c3 32c0 8b4df0 64890d00000000 59 }
		$sequence_5 = { b827000000 ba02000000 f7e2 0f90c1 f7d9 }
		$sequence_6 = { 33c5 50 8d45f0 64a300000000 8965e8 8bf9 33db }
		$sequence_7 = { 33d2 668955f6 e8???????? 83c40c 33d2 }
		$sequence_8 = { c3 32c0 8b4df0 64890d00000000 59 5f 5e }
		$sequence_9 = { 56 8b0f 51 e8???????? 83c418 }

	condition:
		7 of them and filesize < 2695168
}
rule MALPEDIA_Win_Earthworm_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "6edcefe0-229f-5473-8908-4805d5869709"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.earthworm"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.earthworm_auto.yar#L1-L132"
		license_url = "N/A"
		logic_hash = "6fc9d2b70dab291cd3129887483a618be5c6229543686708e9ecf395cd25243a"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 488d05738f0400 4889442420 4533c9 41b860000000 488d15b6ff0500 }
		$sequence_1 = { c1f906 4863c9 488d1569e60500 448b442470 4183e03f 4d63c0 4d6bc048 }
		$sequence_2 = { c1f806 4898 488d0d0e170600 8b542450 83e23f 4863d2 486bd248 }
		$sequence_3 = { 8b5524 2bd1 8bca 3bc1 0f8edb000000 8b4504 8b4d24 }
		$sequence_4 = { 89842420010000 eb10 8b442420 2500100000 89842420010000 83bc242001000000 0f84a1000000 }
		$sequence_5 = { 837c243800 753a 488d05a3440800 4889442428 488d054fd60700 4889442420 4533c9 }
		$sequence_6 = { 55 57 4881ece8000000 488d6c2420 488d0d28841300 e8???????? 90 }
		$sequence_7 = { 488d8c24d0030000 488bf9 488bf0 b910000000 f3a4 488d9424d0030000 488d4c2428 }
		$sequence_8 = { 69452480000000 48634d04 488b9520010000 0fbe0c0a 03c1 894524 ebbb }
		$sequence_9 = { 480fbe0401 4889442410 8b442404 488d0d8dec0c00 0fb60401 89442408 488b442430 }

	condition:
		7 of them and filesize < 2659328
}
rule MALPEDIA_Win_Mongall_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "356a62d5-d6d6-5df0-a99e-d61f059d79ab"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.mongall"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.mongall_auto.yar#L1-L119"
		license_url = "N/A"
		logic_hash = "d1ea1582004fd6077867d121a19d4695b72d0838153fa1649e8f4d82e53275b9"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 50 ffd7 8bc3 8da5e0fdffff }
		$sequence_1 = { ff15???????? 85c0 0f84b2000000 6a7f 8d857dffffff 6a00 }
		$sequence_2 = { 8d4598 50 ff15???????? 2bf6 3935???????? 750b }
		$sequence_3 = { 0fbe84c248e24000 c1f804 8985a4fdffff 83f807 0f87c8090000 ff2485b83f4000 33c0 }
		$sequence_4 = { 6a00 56 e8???????? 8b8d6cf8ffff }
		$sequence_5 = { 84d2 75f9 8dbdfcfdffff 2bc1 4f 8a4f01 47 }
		$sequence_6 = { e8???????? 83c40c eb14 8d95f8fdffff 68???????? }
		$sequence_7 = { 57 6a00 50 8945f8 e8???????? 83c410 }
		$sequence_8 = { 50 ffd6 eb06 8b35???????? 6a00 6880000000 }
		$sequence_9 = { 8bf7 85ff 7e2a 6a30 }

	condition:
		7 of them and filesize < 199680
}
rule MALPEDIA_Win_Hui_Loader_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "9d52a9e1-364f-5da9-98e9-94947c68e8f2"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.hui_loader"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.hui_loader_auto.yar#L1-L124"
		license_url = "N/A"
		logic_hash = "9aeecb9fd394041a8c28b780fedfdb6f106e3cf0d7d8dbc8dc34058d911e30dc"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8bc8 83e01f c1f905 56 57 8b348d60e20010 }
		$sequence_1 = { 83c028 83c12c 4a 75eb b902000000 8d742454 83f901 }
		$sequence_2 = { 8db604b40010 6a00 50 ff36 e8???????? }
		$sequence_3 = { 75f8 42 83c628 83fa0a 7ce6 b931000000 33c0 }
		$sequence_4 = { 68???????? ff15???????? 6a00 6a00 6a00 8bf0 6a04 }
		$sequence_5 = { 80f95c 7408 8a48ff 48 3acb 75f3 }
		$sequence_6 = { 56 ff15???????? 8bf8 85ff 7506 50 }
		$sequence_7 = { 6880000000 6a03 53 6a02 6800000080 68???????? }
		$sequence_8 = { ffd0 68e8030000 ffd6 8b0d???????? }
		$sequence_9 = { 6a03 53 6a02 6800000080 68???????? ff15???????? }

	condition:
		7 of them and filesize < 131072
}
rule MALPEDIA_Win_Conficker_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "5078296d-c594-537f-bc2d-6482cdc2a95e"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.conficker"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.conficker_auto.yar#L1-L118"
		license_url = "N/A"
		logic_hash = "52cf1d0c177a82e81a75ed3852f73d51b2ab981010e560cc9f3214d98448c82b"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ff15???????? 3345f8 33c7 33c6 50 ff15???????? }
		$sequence_1 = { c1e805 8b0482 83e11f d3e8 }
		$sequence_2 = { c3 55 8bec 83ec20 8b0d???????? a1???????? }
		$sequence_3 = { 3c08 7422 42 3c04 7415 42 }
		$sequence_4 = { 8945e4 8365fc00 85c0 7420 }
		$sequence_5 = { 8b5d0c 8a1c1e 02da 8d7c8808 }
		$sequence_6 = { 74db 81c751000000 3c0a 74d4 }
		$sequence_7 = { 42 ebe4 f60638 75a8 b008 d0ef 1400 }
		$sequence_8 = { 61 c3 ac 88c4 c0e807 7212 7414 }
		$sequence_9 = { e2f9 ff7510 ff7508 e8???????? 85c0 59 }

	condition:
		7 of them and filesize < 335872
}
rule MALPEDIA_Win_Unidentified_124_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "3f8a34cc-2ccc-5e71-9e0f-f552888a92a5"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.unidentified_124"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.unidentified_124_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "16a7b66487c95c984e08bd814e8eeab9b002a2a44b4bcd33ccfd265362feda16"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { c78570020000b58dbb54 c78574020000fa4e5ed6 c78578020000de8a5b94 c7857c0200006a82d4cf c785800200001da5bd0f c78584020000bf53fb55 c78588020000f8f600c0 }
		$sequence_1 = { 8bf8 e8???????? e9???????? 448975d4 660f1f840000000000 488b05???????? 488d55d0 }
		$sequence_2 = { e9???????? 498b07 488d4dc8 48894c2420 4c8d45d2 498bcf 4533c9 }
		$sequence_3 = { 8b4b1c 4803cf 8b0491 4803c7 48894650 41ffc6 443b7318 }
		$sequence_4 = { e8???????? 488d8d80000000 e9???????? c7858000000014ac0a05 c78584000000d4350882 c78588000000921adb06 c7858c00000078a718f0 }
		$sequence_5 = { 48897c2420 4d8bc5 498bd4 48c7c1ffffffff e8???????? 85c0 0f85c9000000 }
		$sequence_6 = { 33c0 e9???????? 65488b042530000000 4889b424e8050000 488b4830 488b4160 498bce }
		$sequence_7 = { c78518010000d286db91 c7851c010000f8929ecb c785200100005914bf8c c785240100007f4c6de9 c7852801000029c3a840 c7852c0100000e435c23 c785300100008b977f02 }
		$sequence_8 = { e8???????? 4c8d8508010000 33d2 488bcb e8???????? 4883bef800000000 0f84c00c0000 }
		$sequence_9 = { 8bf8 3d8f2f0000 0f85ca000000 4180fe02 0f8d26010000 488b05???????? 4c8d45a0 }

	condition:
		7 of them and filesize < 1437696
}
rule MALPEDIA_Win_Play_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "fb8bcd82-2890-51e9-aef7-15cdb7334359"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.play"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.play_auto.yar#L1-L126"
		license_url = "N/A"
		logic_hash = "98ed430384a69d155a8a3b8add1f6db92e55c318ad1d4defbfbdd225c9837ee9"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 85c9 7ff1 eb1d 8d85b1feffff 03c1 50 }
		$sequence_1 = { 0f1005???????? 8945ac b854040000 6689856cffffff b8e0690000 0f114588 052496ffff }
		$sequence_2 = { 898518feffff b879180000 0f118594feffff 898534ffffff f30f7e05???????? a1???????? 660fd68500ffffff }
		$sequence_3 = { 02c0 02c2 888596feffff b9???????? e8???????? 8a85acfeffff }
		$sequence_4 = { 8a857cfcffff fec0 c745e43d000000 0245fd 8845ff 888521ffffff b83e000000 }
		$sequence_5 = { bbb410624c 8b0d???????? e8???????? 6aff ff75e8 ffd0 }
		$sequence_6 = { e8???????? 33d2 8b4df4 f7f6 8bc2 8945e4 }
		$sequence_7 = { 8955f8 894dfc e8???????? 8b0d???????? 33d2 }
		$sequence_8 = { 889591feffff 888dc9feffff 888d81feffff b920000000 c60000 }
		$sequence_9 = { e8???????? 2467 0fa1 ee d5d8 e9???????? 8c9f381b40b1 }

	condition:
		7 of them and filesize < 389120
}
rule MALPEDIA_Win_Ragnarlocker_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "8cc793bb-8ca1-55d0-a1a2-81219dfd2f79"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.ragnarlocker"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.ragnarlocker_auto.yar#L1-L127"
		license_url = "N/A"
		logic_hash = "366e325211296c7ca816dc215ceed25e7f198d91b28b1ea8ad97a59e1c0e779e"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 8bbed0000000 c6041f80 47 83ff70 7628 b980000000 }
		$sequence_1 = { 0facd11c c1e604 0bf9 c1ea1c 8b4de4 0bf2 }
		$sequence_2 = { 0fb6c5 6a04 0bd0 0fb6c1 6800300000 c1e208 53 }
		$sequence_3 = { 8bf9 0facd112 c1e70e 33f6 0bf1 c1ea12 }
		$sequence_4 = { 7510 ff75fc ff15???????? 8bc6 5e 8be5 5d }
		$sequence_5 = { 8b4d0c 13c7 8945f4 0fb64160 }
		$sequence_6 = { 8bf2 0fa4ca17 c1ee09 0bda c1e117 8b55d4 0bf1 }
		$sequence_7 = { 2375cc 234dd8 8b45f4 33f1 8b4de4 8bd0 2345ec }
		$sequence_8 = { 0fa4de08 99 c1e308 0bd8 899d40ffffff 8b4738 }
		$sequence_9 = { 8955e8 0fb64110 13f7 99 8975ec 8bd8 0fb64111 }

	condition:
		7 of them and filesize < 147456
}
rule MALPEDIA_Win_Reactorbot_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "bd304144-d58a-52b7-a4a0-4009e29e50d3"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.reactorbot"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.reactorbot_auto.yar#L1-L161"
		license_url = "N/A"
		logic_hash = "3893a8bbc6dd227805a8cd5d698132b74afbe1c8a3088337bce719acdc9dc5e4"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 6808020000 8d95d8fbffff 52 ff15???????? }
		$sequence_1 = { 8b4dfc 51 6a00 ff15???????? 50 ff15???????? 8945f8 }
		$sequence_2 = { 8d8d88fbffff 51 e8???????? 8b9590fdffff 83e210 }
		$sequence_3 = { 50 ff15???????? 83c408 c745f401000000 8b45f4 }
		$sequence_4 = { e8???????? 6850020000 8d8590fdffff 50 ff15???????? }
		$sequence_5 = { 8b45f8 8945ec eb13 8b4df8 51 6a00 ff15???????? }
		$sequence_6 = { c745e800000000 c745e400000000 a1???????? 8945e0 8b4d08 }
		$sequence_7 = { 50 ff15???????? 8d8d90fdffff 51 8d9580f9ffff 52 }
		$sequence_8 = { 6bc005 83e803 99 b999000000 }
		$sequence_9 = { 7402 eb0c c705????????b80b0000 eb0a }
		$sequence_10 = { 83c005 99 b905000000 f7f9 }
		$sequence_11 = { 833d????????00 7509 833d????????00 740b }
		$sequence_12 = { 83e101 f7d9 81e12083b8ed 33c1 }
		$sequence_13 = { 69c0b13a0200 99 83e203 03c2 }
		$sequence_14 = { e9???????? 488b8c2488000000 ff15???????? 488d15fd010100 488d8c24c0340000 }
		$sequence_15 = { ba00100000 488d8c24c0440000 ff15???????? 448b44247c 488d1570450000 488d8c24c0440000 }

	condition:
		7 of them and filesize < 1032192
}
rule MALPEDIA_Win_Unidentified_111_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "761c3c1a-627b-5adf-b1c2-f96f11c05a94"
		date = "2023-12-06"
		modified = "2023-12-08"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.unidentified_111"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.unidentified_111_auto.yar#L1-L125"
		license_url = "N/A"
		logic_hash = "8a86a6eb9509e0a5b4e912cde53abfcabb23f3644fc565d69ca8396c5dc5d7c9"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20231130"
		malpedia_hash = "fc8a0e9f343f6d6ded9e7df1a64dac0cc68d7351"
		malpedia_version = "20230808"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 488b4c2428 0fbe09 3bc1 7512 }
		$sequence_1 = { c744242002000000 e9???????? 837c243406 7511 837c243801 750a }
		$sequence_2 = { 8b00 488b4c2430 488b09 0fbe0401 48634c2404 488b542428 0fbe0c0a }
		$sequence_3 = { eb43 41b901000000 448b442424 488b542428 488b4c2448 e8???????? }
		$sequence_4 = { eb1f c744242000000000 4533c9 4533c0 }
		$sequence_5 = { 488b4c2448 ff15???????? 89442444 837c244400 7502 eb11 }
		$sequence_6 = { 488d8c0c60020000 ba02000000 486bd200 4803ca 448bc0 488b542420 e8???????? }
		$sequence_7 = { 66c1ca08 0fb7d2 4c8b8424a0000000 450fb74006 6641c1c808 450fb7c0 4c8b8c24a0000000 }
		$sequence_8 = { e8???????? b910000000 e8???????? 4889442448 488b442448 488b4c2450 488908 }
		$sequence_9 = { 4889542410 48894c2408 4883ec78 c744243000000000 c744243400000000 488b942488000000 488d4c2448 }

	condition:
		7 of them and filesize < 148480
}
rule MALPEDIA_Win_Ravenstealer_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "a5d7ef94-f49c-57fd-8a35-5ea58de4b27b"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.ravenstealer"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.ravenstealer_auto.yar#L1-L134"
		license_url = "N/A"
		logic_hash = "7988e64480a814999f7ac38f68556e016bdf70bd1583e98479ea4d62def9f4b2"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { ba04010000 488d8c24c00e0000 e8???????? 40b601 e9???????? e8???????? 0fbed8 }
		$sequence_1 = { 740a c744247c09000000 eb5a 0fbe05???????? 4103c1 4103c2 0fbe0d???????? }
		$sequence_2 = { 662bd0 664103d7 4863442430 664189544602 e8???????? 0fbec0 89842480000000 }
		$sequence_3 = { b301 e9???????? e8???????? 0fbed8 e8???????? 0fbec8 0fafcb }
		$sequence_4 = { 7435 0fbe05???????? 33d2 0fbe0d???????? 4103c1 f7f1 0fbe0d???????? }
		$sequence_5 = { 899424c0000000 48c7c6ffffffff 0f1f4000 48ffc6 4238142e 75f7 488b01 }
		$sequence_6 = { 33c0 8885b00c0000 0f1003 0f1101 0f104b10 0f114910 f3440f7fb558070000 }
		$sequence_7 = { 75e5 482bf7 48d1fe 0f57c0 0f11842480000000 4c89bc2490000000 4c89bc2498000000 }
		$sequence_8 = { eb07 4c8b95b00c0000 f20f1035???????? 41803a00 0f8531120000 89b5b00c0000 8b85b00c0000 }
		$sequence_9 = { 0f1100 660f6f0d???????? f30f7f8d78040000 41b820000000 488d15b2602600 488d8d68040000 e8???????? }

	condition:
		7 of them and filesize < 8337408
}
rule MALPEDIA_Win_Thanatos_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "721d0dff-1005-50d2-9063-ef3840485ccf"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.thanatos"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.thanatos_auto.yar#L1-L123"
		license_url = "N/A"
		logic_hash = "a00512bf22d7da43edf60d08d0c486cf2e8915c9ab411623a06c332d32b268f4"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 85f6 7543 eb26 8d4d98 eb21 8d4dcc eb1c }
		$sequence_1 = { 8a4415ec 3086e75b0210 ff15???????? 3bf0 }
		$sequence_2 = { 50 ff15???????? 8d45c8 8945e4 8d45e0 }
		$sequence_3 = { e8???????? bad74ffba4 8bcf a3???????? e8???????? 8b35???????? }
		$sequence_4 = { 83c408 eb02 33c0 a3???????? }
		$sequence_5 = { c745e47773325f c745e833322e64 66c745ec6c6c c645ee00 c745f06e74646c c745f46c2e646c }
		$sequence_6 = { 7414 8b4df4 81c900000002 894e04 8b4d24 83c108 eb03 }
		$sequence_7 = { 68???????? 50 ff15???????? 83c40c e8???????? 50 8d85ecfeffff }
		$sequence_8 = { 8d842428020000 50 8d84242c010000 68???????? 50 ff15???????? }
		$sequence_9 = { 99 f7ff 68???????? 46 8a4415f4 30864f580210 ff15???????? }

	condition:
		7 of them and filesize < 1810432
}
rule MALPEDIA_Win_Adaptix_C2_Auto : FILE
{
	meta:
		description = "autogenerated rule brought to you by yara-signator"
		author = "Felix Bilstein - yara-signator at cocacoding dot com"
		id = "2e5fdb57-534f-599c-9964-fdf023a9e52c"
		date = "2026-09-17"
		modified = "2026-09-28"
		reference = "https://malpedia.caad.fkie.fraunhofer.de/details/win.adaptix_c2"
		source_url = "https://github.com/malpedia/signator-rules//blob/eddaf26a30c6daff1b2350f52d0b5c11767f7552/rules/win.adaptix_c2_auto.yar#L1-L131"
		license_url = "N/A"
		logic_hash = "9c0a56303a466deb53d7a5165535797ac5b23cbd914af5975c5fc03644d06a16"
		score = 75
		quality = 75
		tags = "FILE"
		version = "1"
		tool = "yara-signator v0.6.0"
		signator_config = "callsandjumps;datarefs;binvalue"
		malpedia_rule_date = "20260916"
		malpedia_hash = "53a643781c18e08f4a50949af60172d837a0b6f6"
		malpedia_version = "20260917"
		malpedia_license = "CC BY-SA 4.0"
		malpedia_sharing = "TLP:WHITE"

	strings:
		$sequence_0 = { 488b4510 488b4008 5d c3 55 4889e5 48894d10 }
		$sequence_1 = { 488d65f0 5b 5f 5d c3 55 4889e5 }
		$sequence_2 = { 4889442460 48837c246000 755f 488b442470 8b4004 4863d0 4889d0 }
		$sequence_3 = { e8???????? 488b4538 baffff1111 4889c1 e8???????? }
		$sequence_4 = { c6401000 48837d3000 0f8450010000 8b5518 488b4530 c744242047270000 41b900000000 }
		$sequence_5 = { ffd2 48c784242001000000000000 e9???????? 488b8424a8000000 4885c0 7426 488b05???????? }
		$sequence_6 = { 488b4008 488d5004 488b4510 48895008 488b4510 8b4010 8d50fc }
		$sequence_7 = { 488b4518 ba20000000 4889c1 e8???????? 488b5d18 488b4510 8b55dc }
		$sequence_8 = { 4889c1 e8???????? 4889c2 488b05???????? 48899018020000 488b45d0 }
		$sequence_9 = { 48c744246000000000 48c744246800000000 66c74424600200 488b05???????? 488b00 4c8b8898020000 488d542460 }

	condition:
		7 of them and filesize < 377856
}
