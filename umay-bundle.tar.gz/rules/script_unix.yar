/*
    Umay heuristics: shell, Python and other Unix scripting.

    These also apply to small plain-text files, because a payload dropped as
    "update" or "x" has neither a shebang nor an extension.
*/

rule Shell_ReverseShell
{
    meta:
        umay_name = "Heur.Shell.ReverseShell"
        umay_weight = 65
        description = "Connects a command shell to a remote host, giving it control of this machine"
    strings:
        $devtcp = /(ba|z|k)?sh\s+-i\s+[^\r\n]{0,20}>&?\s*\/dev\/(tcp|udp)\/[^\s\/]{1,80}\/[0-9]{1,5}/
        $execfd = /exec\s+[0-9]+<>\s*\/dev\/(tcp|udp)\/[^\s\/]{1,80}\/[0-9]{1,5}/
        $netcat = /\b(nc|ncat|netcat)\b[^\r\n|]{0,80}\s-(e|c)\s+\/?(bin\/)?(ba|z)?sh/
        $fifo = /mkfifo\s+[^\s;]{1,60}\s*;[^\r\n]{0,120}\|\s*(nc|ncat|netcat)\b/
        $socat = /socat\b[^\r\n]{0,120}exec:['"]?(\/bin\/)?(ba|z)?sh/ nocase
    condition:
        (umay_kind == "script" or umay_derived or (umay_kind == "text" and filesize < 64KB))
        and filesize < 5MB and any of them
}

rule Python_ReverseShell
{
    meta:
        umay_name = "Heur.Python.ReverseShell"
        umay_weight = 60
        description = "Redirects a shell's input and output to a network socket"
    strings:
        $socket = "socket.socket(" ascii
        $dup = "os.dup2(" ascii
        $pty = "pty.spawn(" ascii
        $sub = /subprocess\.(call|Popen|run)\(\s*\[?\s*['"]\/bin\/(ba|z)?sh/ ascii
    condition:
        (umay_kind == "script" or umay_derived)
        and filesize < 5MB and $socket and ($dup or $pty) and ($pty or $sub)
}

rule Python_EncodedExec
{
    meta:
        umay_name = "Heur.Python.EncodedExec"
        umay_weight = 40
        description = "Executes code that is stored encoded or compressed inside the script"
    strings:
        $exec = /\b(exec|eval)\s*\(\s*(base64\.b64decode|zlib\.decompress|marshal\.loads|codecs\.decode|bytes\.fromhex|__import__\(['"](base64|zlib|marshal)['"]\))/ ascii
    condition:
        (umay_kind == "script" or umay_derived) and filesize < 5MB and $exec
}

rule Shell_PipeDownloadToInterpreter
{
    meta:
        umay_name = "Heur.Shell.PipeDownloadToInterpreter"
        umay_weight = 20
        description = "Runs whatever a web server returns without saving or checking it"
    strings:
        $pipe = /\b(curl|wget)\b[^\r\n|]{1,300}\|\s*(sudo\s+)?(ba|z|da|k)?sh\b/
    condition:
        (umay_kind == "script" or umay_derived) and filesize < 5MB and $pipe
}

rule Shell_DecodeAndRun
{
    meta:
        umay_name = "Heur.Shell.DecodeAndRun"
        umay_weight = 45
        description = "Decodes hidden commands and feeds them straight to a shell"
    strings:
        $b64 = /base64\s+(-d|-D|--decode)\b[^\r\n|]{0,80}\|\s*(sudo\s+)?(ba|z|da|k)?sh\b/
        $xxd = /xxd\s+-r\b[^\r\n|]{0,80}\|\s*(sudo\s+)?(ba|z|da|k)?sh\b/
        $openssl = /openssl\s+enc\s+-d\b[^\r\n|]{0,160}\|\s*(sudo\s+)?(ba|z|da|k)?sh\b/
        $evalb64 = /eval\s+["']?\$\(\s*(echo|printf)\s+[^\r\n|]{20,}\|\s*base64\s+(-d|-D|--decode)/
    condition:
        (umay_kind == "script" or umay_derived or (umay_kind == "text" and filesize < 64KB))
        and filesize < 5MB and any of them
}

rule Shell_DropToTempAndRun
{
    meta:
        umay_name = "Heur.Shell.DropToTempAndRun"
        umay_weight = 35
        description = "Downloads a file into a temporary directory, makes it executable and runs it"
    strings:
        $drop = /\b(curl|wget)\b[^\r\n]{1,300}\s(-o|-O|>)\s*\/(tmp|var\/tmp|dev\/shm)\/[^\s;&|]{1,80}/
        $chmod = /chmod\s+(\+x|a\+x|u\+x|[0-7]?7[0-7]{2})\s+\/(tmp|var\/tmp|dev\/shm)\//
    condition:
        (umay_kind == "script" or umay_derived) and filesize < 5MB and $drop and $chmod
}

rule Shell_CoverTracks
{
    meta:
        umay_name = "Heur.Shell.CoverTracks"
        umay_weight = 30
        description = "Erases command history and system logs"
    strings:
        $h1 = "history -c" ascii
        $h2 = "unset HISTFILE" ascii
        $h3 = /HISTSIZE=0\b/ ascii
        $h4 = /HISTFILE=\/dev\/null/ ascii
        $l1 = /rm\s+-[rf]{1,2}\s+\/var\/log\b/ ascii
        $l2 = /(>|truncate\s+-s\s*0)\s*\/var\/log\/(wtmp|btmp|lastlog|auth\.log|secure)/ ascii
        $l3 = /shred\s+[^\r\n]{0,40}\/var\/log\// ascii
    condition:
        (umay_kind == "script" or umay_derived) and filesize < 5MB and 2 of them
}

rule Shell_CronPersistence
{
    meta:
        umay_name = "Heur.Shell.CronPersistence"
        umay_weight = 35
        description = "Schedules itself to run again by appending to the system job table"
    strings:
        $append = /\(\s*crontab\s+-l[^\r\n)]{0,80};\s*(echo|printf)\b[^\r\n]{0,300}\)\s*\|\s*crontab\s+-/
        $write = /(>>|tee\s+-a)\s*\/etc\/(crontab|cron\.d\/[^\s]{1,60})/
        $fetch = /\b(curl|wget)\b/
    condition:
        (umay_kind == "script" or umay_derived) and filesize < 5MB and ($append or $write) and $fetch
}

rule Shell_LibraryPreloadHook
{
    meta:
        umay_name = "Heur.Shell.LibraryPreloadHook"
        umay_weight = 50
        description = "Forces a library into every program on the system, the usual way user-mode rootkits hide"
    strings:
        $write = /(>>?|tee(\s+-a)?)\s*\/etc\/ld\.so\.preload/
    condition:
        (umay_kind == "script" or umay_derived) and filesize < 5MB and $write
}

rule Shell_SshKeyImplant
{
    meta:
        umay_name = "Heur.Shell.SshKeyImplant"
        umay_weight = 40
        description = "Adds a login key so someone else can sign in to this account remotely"
    strings:
        $implant = /(echo|printf)\s+["']?ssh-(rsa|ed25519|dss)\s+AAAA[A-Za-z0-9+\/]{40,}[^\r\n]{0,200}>>\s*[^\s]{0,80}authorized_keys/
    condition:
        (umay_kind == "script" or umay_derived) and filesize < 5MB and $implant
}

rule Script_CoinMiner
{
    meta:
        umay_name = "Heur.Script.CoinMiner"
        umay_weight = 55
        description = "Starts a cryptocurrency miner that uses this machine for someone else's profit"
    strings:
        $pool = /stratum\+(tcp|ssl|tls):\/\// nocase
        $m1 = "xmrig" nocase
        $m2 = "--donate-level" nocase
        $m3 = "cryptonight" nocase
        $m4 = "randomx" nocase
    condition:
        (umay_kind == "script" or umay_derived) and filesize < 5MB and $pool and any of ($m*)
}

rule MacOS_LaunchItemRunsRemoteCode
{
    meta:
        umay_name = "Heur.MacOS.LaunchItemRunsRemoteCode"
        umay_weight = 70
        description = "A start-up item that downloads and runs code every time it launches"
    strings:
        $plist = "<plist" nocase
        $args = "<key>ProgramArguments</key>"
        $run = /<key>(RunAtLoad|KeepAlive|StartInterval)<\/key>/
        $pipe = /(curl|wget)\b[^<\r\n]{0,200}\|\s*(ba|z|k)?sh\b/
        $decode = /base64\s+(-d|-D|--decode)[^<\r\n]{0,80}\|\s*(ba|z|k)?sh\b/
        $osascript = /osascript\s+-e[^<\r\n]{0,200}do shell script[^<\r\n]{0,120}(curl|wget)/ nocase
        $python = /python[0-9.]*<\/string>\s*<string>-c<\/string>\s*<string>[^<]{0,400}(urlopen|exec\(|b64decode)/
    condition:
        filesize < 256KB and $plist and $args and $run and any of ($pipe, $decode, $osascript, $python)
}
