import "dotnet"
import "hash"
import "pe"

rule R3C0NST_ATM_Malware_Loup : FILE
{
	meta:
		description = "Detects ATM Malware Loup"
		author = "Frank Boldewin (@r3c0nst)"
		id = "4786362f-b2c5-5b69-8b06-9216561286e6"
		date = "2020-08-17"
		modified = "2020-08-17"
		reference = "https://twitter.com/r3c0nst/status/1295275546780327936"
		source_url = "https://github.com/fboldewin/YARA-rules//blob/54e9e6899b258b72074b2b4db6909257683240c2/ATM.Malware.Loup.yar#L1-L16"
		license_url = "N/A"
		hash = "6c9e9f78963ab3e7acb43826906af22571250dc025f9e7116e0201b805dc1196"
		logic_hash = "39efced4ee3a6147acf5732e4be3a5e9859268b35b79f5e8e87d7c4d77a588c0"
		score = 75
		quality = 90
		tags = "FILE"

	strings:
		$String1 = "C:\\Users\\muham\\source\\repos\\loup\\Debug\\loup.pdb" ascii nocase
		$String2 = "CurrencyDispenser1" ascii nocase
		$Code = {50 68 C0 D4 01 00 8D 4D E8 51 68 2E 01 00 00 0F B7 55 08 52 E8}

	condition:
		uint16( 0 ) == 0x5A4D and filesize < 100KB and all of ( $String* ) and $Code
}
rule R3C0NST_Shellcode_Apihashing_FIN8
{
	meta:
		description = "Detects FIN8 Shellcode APIHashing"
		author = "Frank Boldewin (@r3c0nst)"
		id = "a5b4a925-c4cc-5d3a-a2f1-3372f77ceea2"
		date = "2021-03-16"
		modified = "2021-03-25"
		reference = "https://www.bitdefender.com/files/News/CaseStudies/study/394/Bitdefender-PR-Whitepaper-BADHATCH-creat5237-en-EN.pdf"
		source_url = "https://github.com/fboldewin/YARA-rules//blob/54e9e6899b258b72074b2b4db6909257683240c2/Shellcode.APIHashing.FIN8.yar#L1-L74"
		license_url = "N/A"
		logic_hash = "958d6a3c0c78ad22fb56896d6a97b9fe79c56813dc36a37385f3ce5621008624"
		score = 75
		quality = 90
		tags = ""

	strings:
		$APIHashing32bit1 = {68 F2 55 03 88 68 65 19 6D 1E}
		$APIHashing32bit2 = {68 9B 59 27 21 C1 E9 17 33 4C 24 10 68 37 5C 32 F4}
		$APIHashing64bit = {49 BF 65 19 6D 1E F2 55 03 88 49 BE 37 5C 32 F4 9B 59 27 21}

	condition:
		all of ( $APIHashing32bit* ) or $APIHashing64bit
}
rule R3C0NST_ATM_Malware_Dispcashbr : FILE
{
	meta:
		description = "Detects ATM Malware DispCashBR"
		author = "Frank Boldewin (@r3c0nst)"
		id = "17d22120-0ca2-5b27-9816-21ab4a6fb20c"
		date = "2020-02-27"
		modified = "2020-08-17"
		reference = "https://twitter.com/r3c0nst/status/1232944566208286720"
		source_url = "https://github.com/fboldewin/YARA-rules//blob/54e9e6899b258b72074b2b4db6909257683240c2/ATM.Malware.DispCashBR.yar#L1-L21"
		license_url = "N/A"
		hash = "7cea6510434f2c8f28c9dbada7973449bb1f844cfe589cdc103c9946c2673036"
		logic_hash = "3fb5d62cb779ddc13e9b938290dfa9d2a3353d7969e639a662c1bcaca945de4d"
		score = 75
		quality = 90
		tags = "FILE"

	strings:
		$String1 = "(*) Dispensando: %lu" ascii nocase
		$String2 = "COMANDO EXECUTADO COM SUCESSO" ascii nocase
		$String3 = "[+] FOI SACADO:  %lu R$ [+]" ascii nocase
		$DbgStr1 = "_Get_Information_cdm_cuinfo" ascii nocase
		$DbgStr2 = "_GET_INFORMATION_SHUTTER" ascii nocase
		$Code1 = {C7 44 24 08 00 00 00 00 C7 44 24 04 2F 01 00 00 89 04 24 E8}
		$Code2 = {C7 44 24 08 00 00 00 00 C7 44 24 04 17 05 00 00 89 04 24 E8}
		$Code3 = {89 4C 24 08 C7 44 24 04 2E 01 00 00 89 04 24 E8}

	condition:
		uint16( 0 ) == 0x5A4D and filesize < 100KB and 2 of ( $String* ) and 1 of ( $DbgStr* ) and all of ( $Code* )
}
rule R3C0NST_UNC2891_Winghook : FILE
{
	meta:
		description = "Detects UNC2891 Winghook Keylogger"
		author = "Frank Boldewin (@r3c0nst)"
		id = "e5955fa0-8204-58e3-88a6-de4b47756ede"
		date = "2022-03-30"
		modified = "2023-01-05"
		reference = "https://github.com/fboldewin/YARA-rules/"
		source_url = "https://github.com/fboldewin/YARA-rules//blob/54e9e6899b258b72074b2b4db6909257683240c2/UNC2891_Winghook.yar#L1-L17"
		license_url = "N/A"
		hash = "d071ee723982cf53e4bce89f3de5a8ef1853457b21bffdae387c4c2bd160a38e"
		logic_hash = "b821d0809a91c54d06764f5a04c458ec7190b41823b2fe65d198342715f22050"
		score = 75
		quality = 90
		tags = "FILE"

	strings:
		$code1 = {01 F9 81 E1 FF 00 00 00 41 89 CA [15] 44 01 CF 81 E7 FF 00 00 00}
		$code2 = {83 E2 0F 0F B6 14 1? 32 14 01 88 14 0? 48 83 ?? ?? 48 83 ?? ?? 75}
		$str1 = "fgets" ascii
		$str2 = "read" ascii

	condition:
		uint32( 0 ) == 0x464c457f and filesize < 100KB and 1 of ( $code* ) and all of ( $str* )
}
rule R3C0NST_UNC2891_Slapstick : FILE
{
	meta:
		description = "Detects UNC2891 Slapstick pam backdoor"
		author = "Frank Boldewin (@r3c0nst)"
		id = "a731acff-f657-5877-859e-7447230576df"
		date = "2022-03-30"
		modified = "2023-01-05"
		reference = "https://github.com/fboldewin/YARA-rules/"
		source_url = "https://github.com/fboldewin/YARA-rules//blob/54e9e6899b258b72074b2b4db6909257683240c2/UNC2891_Slapstick.yar#L1-L19"
		license_url = "N/A"
		hash = "9d0165e0484c31bd4ea467650b2ae2f359f67ae1016af49326bb374cead5f789"
		logic_hash = "7777c3b850f5b7ee326be5461ebc3bf37fb201b67ada78b50575fb31f50adf9a"
		score = 75
		quality = 90
		tags = "FILE"

	strings:
		$code1 = {F6 50 04 48 FF C0 48 39 D0 75 F5}
		$code2 = {88 01 48 FF C1 8A 11 89 C8 29 F8 84 D2 0F 85}
		$str1 = "/proc/self/exe" fullword ascii
		$str2 = "%-23s %-23s %-23s %-23s %-23s %s" fullword ascii
		$str3 = "pam_sm_authenticate" ascii
		$str4 = "ACCESS GRANTED & WELCOME" xor

	condition:
		uint32( 0 ) == 0x464c457f and filesize < 100KB and ( all of ( $code* ) or all of ( $str* ) )
}
rule R3C0NST_Gamaredon_Getimportbyhash : FILE
{
	meta:
		description = "Detects Gamaredon APIHashing"
		author = "Frank Boldewin (@r3c0nst)"
		id = "8f28273e-e8ca-52cb-8dbc-a235598b1975"
		date = "2021-05-12"
		modified = "2021-05-12"
		reference = "https://github.com/fboldewin/YARA-rules/"
		source_url = "https://github.com/fboldewin/YARA-rules//blob/54e9e6899b258b72074b2b4db6909257683240c2/APT.Gamaredon.GetImportByHash.yar#L1-L16"
		license_url = "N/A"
		hash = "2d03a301bae0e95a355acd464afc77fde88dd00232aad6c8580b365f97f67a79"
		hash = "43d6e56515cca476f7279c3f276bf848da4bc13fd15fad9663b9e044970253e8"
		hash = "5c09f6ebb7243994ddc466058d5dc9920a5fced5e843200b1f057bda087b8ba6"
		logic_hash = "b3baebfb745ebc7b9e6df746bfa9622f925b8e8130932e44a148881e7d1fc162"
		score = 75
		quality = 90
		tags = "FILE"

	strings:
		$ParseImgExportDir = { 8B 50 3C 03 D0 8B 52 78 03 D0 8B 4A 1C 03 C8 }
		$djb2Hashing = { 8B 75 08 BA 05 15 00 00 8B C2 C1 E2 05 03 D0 33 DB 8A 1E 03 D3 46 33 DB 8A 1E 85 DB 75 }

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}

rule R3C0NST_ATM_CINEO4060_Blackbox : FILE
{
	meta:
		description = "Detects Malware samples for Diebold Nixdorf CINEO 4060 ATMs used in blackboxing attacks across Europe since May 2021"
		author = "Frank Boldewin (@r3c0nst)"
		id = "8fa26e1c-2931-59c8-9cec-20dc6684b8d6"
		date = "2021-05-25"
		modified = "2022-06-21"
		reference = "https://twitter.com/r3c0nst/status/1539036442516660224"
		source_url = "https://github.com/fboldewin/YARA-rules//blob/54e9e6899b258b72074b2b4db6909257683240c2/ATM_CINEO4060_Blackbox.yar#L3-L27"
		license_url = "N/A"
		logic_hash = "80b919d03c1b9a198611994eaf2fafaf8254c73a6f0edb53b2b3eb90ea70d915"
		score = 75
		quality = 90
		tags = "FILE"

	strings:
		$MyAgent1 = "javaagentsdemo/ClassListingTransformer.class" ascii fullword
		$MyAgent2 = "javaagentsdemo/MyUtils.class" ascii fullword
		$MyAgent3 = "javaagentsdemo/SimplestAgent.class" ascii fullword
		$Hook = "### [HookAPI]: Switching context!" fullword ascii
		$Delphi = "Borland\\Delphi\\RTL" fullword ascii
		$WMIHOOK1 = "TPM_SK.DLL" fullword ascii
		$WMIHOOK2 = "GetPCData" fullword ascii
		$WMIHOOK3 = {60 9C A3 E4 2B 41 00 E8 ?? ?? ?? ?? 9D 61 B8 02 00 00 00 C3}
		$TRICK1 = "USERAUTH.DLL" fullword ascii
		$TRICK2 = "GetAllSticksByID" fullword ascii
		$TRICK3 = {6A 06 8B 45 FC 8B 00 B1 4F BA 1C 00 00 00}

	condition:
		( uint16( 0 ) == 0x4b50 and filesize < 50KB and all of ( $MyAgent* ) ) or ( uint16( 0 ) == 0x5A4D and ( pe.characteristics & pe.DLL ) and $Hook and $Delphi and all of ( $WMIHOOK* ) or all of ( $TRICK* ) )
}
rule R3C0NST_UNC2891_Steelcorgi : FILE
{
	meta:
		description = "Detects UNC2891 Steelcorgi packed ELF binaries"
		author = "Frank Boldewin (@r3c0nst)"
		id = "94da7da5-5fc3-5221-97d6-1854aa7b1959"
		date = "2022-03-30"
		modified = "2023-01-05"
		reference = "https://github.com/fboldewin/YARA-rules/"
		source_url = "https://github.com/fboldewin/YARA-rules//blob/54e9e6899b258b72074b2b4db6909257683240c2/UNC2891_Steelcorgi.yar#L1-L17"
		license_url = "N/A"
		hash = "0760cd30d18517e87bf9fd8555513423db1cd80730b47f57167219ddbf91f170"
		hash = "3560ed07aac67f73ef910d0b928db3c0bb5f106b5daee054666638b6575a89c5"
		hash = "5b4bb50055b31dbd897172583c7046dd27cd03e1e3d84f7a23837e8df7943547"
		logic_hash = "4f956b9eaec66bc606ffd0afa2fe9303194e9a8c12d4c3de6ab2334c9856dd99"
		score = 75
		quality = 90
		tags = "FILE"

	strings:
		$pattern1 = {70 61 64 00 6C 63 6B 00}
		$pattern2 = {FF 72 FF 6F FF 63 FF 2F FF 73 FF 65 FF 6C FF 66 FF 2F FF 65 FF 78 FF 65}

	condition:
		uint32( 0 ) == 0x464c457f and all of them
}
rule R3C0NST_Stealbit : FILE
{
	meta:
		description = "Detects Stealbit used by Lockbit 2.0 Ransomware Gang"
		author = "Frank Boldewin (@r3c0nst)"
		id = "07b466cb-92b3-51f2-a702-2930bb7038c6"
		date = "2021-08-12"
		modified = "2021-08-12"
		reference = "https://raw.githubusercontent.com/fboldewin/YARA-rules/master/Lockbit2.Stealbit.yar"
		source_url = "https://github.com/fboldewin/YARA-rules//blob/54e9e6899b258b72074b2b4db6909257683240c2/Lockbit2.Stealbit.yar#L1-L15"
		license_url = "N/A"
		hash = "3407f26b3d69f1dfce76782fee1256274cf92f744c65aa1ff2d3eaaaf61b0b1d"
		hash = "bd14872dd9fdead89fc074fdc5832caea4ceac02983ec41f814278130b3f943e"
		logic_hash = "e5f770cc5887f09af0c5550073d51b9e5ffa9dcfa4db6b77bb28643f0f6224fb"
		score = 75
		quality = 90
		tags = "FILE"

	strings:
		$C2Decryption = {33 C9 8B C1 83 E0 0F 8A 80 ?? ?? ?? ?? 30 81 ?? ?? ?? ?? 41 83 F9 7C 72 E9 E8}

	condition:
		uint16( 0 ) == 0x5A4D and filesize < 100KB and $C2Decryption
}
rule R3C0NST_UNC2891_Caketap
{
	meta:
		description = "Detects UNC2891 Rootkit Caketap"
		author = "Frank Boldewin (@r3c0nst)"
		id = "9c2ffe3d-69ca-5f93-bdb1-40e449139dec"
		date = "2022-03-30"
		modified = "2023-01-05"
		reference = "https://github.com/fboldewin/YARA-rules/"
		source_url = "https://github.com/fboldewin/YARA-rules//blob/54e9e6899b258b72074b2b4db6909257683240c2/UNC2891_Caketap.yar#L1-L16"
		license_url = "N/A"
		logic_hash = "530a7d062a218217d2c05460428b2576c3fe2a6099c93940aabde73c513a8914"
		score = 75
		quality = 88
		tags = ""

	strings:
		$str1 = ".caahGss187" ascii fullword
		$str2 = "ipstat" ascii
		$code1 = {41 80 7E 06 4B 75 ?? 41 80 7E 07 57 75 ?? 41 0F B6 46 2B}
		$code2 = {41 C6 46 01 3D 41 C6 46 08 32}

	condition:
		uint32( 0 ) == 0x464c457f and ( all of ( $code* ) or ( all of ( $str* ) and #str2 == 2 ) )
}
rule R3C0NST_Aplib_Decompression : FILE
{
	meta:
		description = "Detects aPLib decompression code often used in malware"
		author = "@r3c0nst"
		id = "f45c73f5-d316-5fea-a8c4-fd930733415f"
		date = "2021-03-24"
		modified = "2021-03-25"
		reference = "https://ibsensoftware.com/files/aPLib-1.1.1.zip"
		source_url = "https://github.com/fboldewin/YARA-rules//blob/54e9e6899b258b72074b2b4db6909257683240c2/aPLib_decompression.yar#L1-L16"
		license_url = "N/A"
		logic_hash = "1150701724fdb487ebe8fb959afd12fff37a8e9137cb94e78e976a2566ec5fa4"
		score = 75
		quality = 90
		tags = "FILE"

	strings:
		$pattern1 = { FC B2 80 31 DB A4 B3 02 }
		$pattern2 = { AC D1 E8 74 ?? 11 C9 EB }
		$pattern3 = { 73 0A 80 FC 05 73 ?? 83 F8 7F 77 }

	condition:
		filesize < 10MB and all of them
}

rule R3C0NST_ATM_Malware_Ploutusi : FILE
{
	meta:
		description = "Detects Ploutus I .NET samples based on MetabaseQ report"
		author = "Frank Boldewin (@r3c0nst)"
		id = "02104112-6f81-5d19-935d-45cfcd2fa41c"
		date = "2021-03-03"
		modified = "2021-03-04"
		reference = "https://www.metabaseq.com/recursos/ploutus-is-back-targeting-itautec-atms-in-latin-america"
		source_url = "https://github.com/fboldewin/YARA-rules//blob/54e9e6899b258b72074b2b4db6909257683240c2/ATM.Malware.Ploutus-I.yar#L3-L26"
		license_url = "N/A"
		hash = "4f6d4c6f97caf888a98a3097b663055b63e605f15ea8f7cc7347283a0b8424c1"
		hash = "8ca29597152dc79bcf79394e1ae2635b393d844bb0eeef6709d37e6778457b31"
		hash = "dce1f01c08937fb5c98964a0911de403eed2101a9d46c5eb9899755c40c3765a"
		hash = "3a1d992277a862640a0835af9dff4b029cfc6c5451e9716f106efaf07702a98c"
		logic_hash = "77100d300a40219187f5c4b8270f599a91652b69980fe450b791181b8c30b5a4"
		score = 75
		quality = 90
		tags = "FILE"

	strings:
		$Code = {28 ?? 02 00 06 2a}

	condition:
		filesize < 300KB and $Code and pe.pdb_path contains "Diebold.pdb" and pe.imports ( "mscoree.dll" , "_CorExeMain" ) and ( for any i in ( 0 .. pe.number_of_resources -1 ) : ( pe.resources [ i ] . type == pe.RESOURCE_TYPE_VERSION and ( pe.version_info [ "InternalName" ] contains "Diebold.exe" ) ) )
}

rule R3C0NST_Nighthawk_RAT : FILE
{
	meta:
		description = "Detects Nighthawk RAT"
		author = "Frank Boldewin (@r3c0nst)"
		id = "7a58b8bf-fb14-5758-bc2a-ad2c6fff1216"
		date = "2022-11-30"
		modified = "2022-11-30"
		reference = "https://www.proofpoint.com/us/blog/threat-insight/nighthawk-and-coming-pentest-tool-likely-gain-threat-actor-notice"
		source_url = "https://github.com/fboldewin/YARA-rules//blob/54e9e6899b258b72074b2b4db6909257683240c2/nighthawk.yar#L3-L28"
		license_url = "N/A"
		hash = "0551ca07f05c2a8278229c1dc651a2b1273a39914857231b075733753cb2b988"
		hash = "9a57919cc5c194e28acd62719487c563a8f0ef1205b65adbe535386e34e418b8"
		hash = "38881b87826f184cc91559555a3456ecf00128e01986a9df36a72d60fb179ccf"
		hash = "f3bba2bfd4ed48b5426e36eba3b7613973226983a784d24d7a20fcf9df0de74e"
		hash = "b775a8f7629966592cc7727e2081924a7d7cf83edd7447aa60627a2b67d87c94"
		logic_hash = "5124f7c0186f40cf0a7706e17afe6ba791ca82ac4f4ee940f6fbae5223771a95"
		score = 75
		quality = 90
		tags = "FILE"

	strings:
		$pattern1 = { 48 8d 0d ?? ?? ?? ?? 51 5a 48 81 c1 ?? ?? ?? ?? 48 81 c2 ?? ?? ?? ?? ff e2 }
		$pattern2 = { 66 03 D2 66 33 D1 66 C1 E2 02 66 33 D1 66 23 D0 0F B7 C1 }
		$pattern3 = { FF 7F 48 3B F0 48 0F 47 F0 48 8D }
		$pattern4 = { 65 48 8B 04 25 30 00 00 00 8B 40 68 49 89 CA 0F 05 C3 }
		$pattern5 = { 48 B8 AA AA AA AA AA AA AA 02 48 ?? ?? ?? ?? 0F 84 }
		$pattern6 = { 65 48 8B 04 25 30 00 00 00 48 8B 80 }

	condition:
		uint16( 0 ) == 0x5A4D and filesize < 2MB and ( 3 of ( $pattern* ) or ( pe.section_index ( ".profile" ) and pe.section_index ( ".detourc" ) and pe.section_index ( ".detourd" ) ) )
}
rule R3C0NST_Prolock_Malware : FILE
{
	meta:
		description = "Detects Prolock malware in encrypted and decrypted mode"
		author = "Frank Boldewin (@r3c0nst)"
		id = "1440b5f5-f1e7-522e-8852-84c326858bb9"
		date = "2020-05-17"
		modified = "2020-05-20"
		reference = "https://raw.githubusercontent.com/fboldewin/YARA-rules/master/Prolock.Malware.yar"
		source_url = "https://github.com/fboldewin/YARA-rules//blob/54e9e6899b258b72074b2b4db6909257683240c2/Prolock.Malware.yar#L1-L20"
		license_url = "N/A"
		hash = "a6ded68af5a6e5cc8c1adee029347ec72da3b10a439d98f79f4b15801abd7af0"
		hash = "dfbd62a3d1b239601e17a5533e5cef53036647901f3fb72be76d92063e279178"
		logic_hash = "7502011eba1e36c8ec699f1b627c4980cc3009bb43c5aa5a58571330e93211ea"
		score = 75
		quality = 90
		tags = "FILE"

	strings:
		$DecryptionRoutine1 = {31 04 1A 81 3C 1A 90 90 90 90 74}
		$DecryptionRoutine2 = {83 C3 04 81 3C 1A C4 C4 C4 C4 74}
		$DecryptedString1 = "support981723721@protonmail.com" nocase ascii
		$DecryptedString2 = "Your files have been encrypted by ProLock Ransomware" nocase ascii
		$DecryptedString3 = "msaoyrayohnp32tcgwcanhjouetb5k54aekgnwg7dcvtgtecpumrxpqd.onion" nocase ascii
		$CryptoCode = {B8 63 51 E1 B7 31 D2 8D BE ?? ?? ?? ?? B9 63 51 E1 B7 81 C1 B9 79 37 9E}

	condition:
		(( uint16( 0 ) == 0x5A4D ) or ( uint16( 0 ) == 0x4D42 ) ) and filesize < 100KB and all of ( $DecryptionRoutine* ) or ( 1 of ( $DecryptedString* ) and $CryptoCode )
}
rule R3C0NST_Exploit_Outlook_CVE_2023_23397 : CVE_2023_23397 FILE
{
	meta:
		description = "Detects Outlook appointments exploiting CVE-2023-23397"
		author = "Frank Boldewin (@r3c0nst)"
		id = "7e355e5f-93ca-561d-9a12-f73f1d429e4d"
		date = "2023-03-19"
		modified = "2023-03-25"
		reference = "https://www.mdsec.co.uk/2023/03/exploiting-cve-2023-23397-microsoft-outlook-elevation-of-privilege-vulnerability/"
		source_url = "https://github.com/fboldewin/YARA-rules//blob/54e9e6899b258b72074b2b4db6909257683240c2/Exploit_Outlook_CVE_2023_23397.yar#L1-L30"
		license_url = "N/A"
		hash = "078b5023cae7bd784a84ec4ee8df305ee7825025265bf2ddc1f5238c3e432f5f"
		hash = "a034427fd8524fd62380c881c30b9ab483535974ddd567556692cffc206809d1"
		hash = "e7a1391dd53f349094c1235760ed0642519fd87baf740839817d47488b9aef02"
		hash = "1543677037fa339877e1d6ef2d077f94613afbcd6434d7181a18df74aca7742b"
		logic_hash = "1847e8223b2f6d3ec5108e15ee46ef031ee1e26d3a5e8ed4a70c77b031f6a5b6"
		score = 75
		quality = 86
		tags = "CVE-2023-23397, FILE"

	strings:
		$ipmtask = "IPM.Task" wide ascii
		$ipmappointment = "IPM.Appointment" wide ascii
		$ipmtaskb64 = "IPM.Task" base64 base64wide
		$ipmappointmentb64 = "IPM.Appointment" base64 base64wide
		$unc_path1 = { 5C 00 5C 00 (3? 00 2E|3? 00 3? 00 2E|3? 00 3? 00 3? 00 2E) 00 (3? 00 2E|3? 00 3? 00 2E|3? 00 3? 00 3? 00 2E) 00 (3? 00 2E|3? 00 3? 00 2E|3? 00 3? 00 3? 00 2E) 00 (3? 00|3? 00 3? 00|3? 00 3? 00 3? 00) }
		$unc_path2 = { 5C 5C (3? 2E|3? 3? 2E|3? 3? 3? 2E) (3? 2E|3? 3? 2E|3? 3? 3? 2E) (3? 2E|3? 3? 2E|3? 3? 3? 2E) (3?|3? 3?|3? 3? 3?) }
		$unc_a = "\x00\x00\x00\x5c\x5c" base64
		$unc_w = "\x00\x00\x5c\x00\x5c" base64wide
		$mail1 = "from:" ascii wide nocase
		$mail2 = "received:" ascii wide nocase

	condition:
		(( uint32be( 0 ) == 0xD0CF11E0 or uint32be( 0 ) == 0x789F3E22 ) or ( all of ( $mail* ) ) ) and ( ( $ipmtask or $ipmappointment ) or ( $ipmtaskb64 or $ipmappointmentb64 ) ) and ( ( $unc_path1 or $unc_path2 ) or ( $unc_a or $unc_w ) )
}
/*
 * YARA Rule Set
 * Repository Name: CAPE
 * Repository: https://github.com/kevoreilly/CAPEv2
 * Retrieval Date: 2026-11-22
 * Git Commit: 1a84d3ad010a14bb4ba911e4a208a145da94f208
 * Number of Rules: 122
 * Skipped: 53 (age), 38 (quality), 0 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * Cuckoo Sandbox is copyrighted by the Cuckoo Foundation and is licensed under
the following GNU General Public License version 3.

                    GNU GENERAL PUBLIC LICENSE
                       Version 3, 29 June 2007

 Copyright (C) 2007 Free Software Foundation, Inc. <http://fsf.org/>
 Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed.

                            Preamble

  The GNU General Public License is a free, copyleft license for
software and other kinds of works.

  The licenses for most software and other practical works are designed
to take away your freedom to share and change the works.  By contrast,
the GNU General Public License is intended to guarantee your freedom to
share and change all versions of a program--to make sure it remains free
software for all its users.  We, the Free Software Foundation, use the
GNU General Public License for most of our software; it applies also to
any other work released this way by its authors.  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
them if you wish), that you receive source code or can get it if you
want it, that you can change the software or use pieces of it in new
free programs, and that you know you can do these things.

  To protect your rights, we need to prevent others from denying you
these rights or asking you to surrender the rights.  Therefore, you have
certain responsibilities if you distribute copies of the software, or if
you modify it: responsibilities to respect the freedom of others.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must pass on to the recipients the same
freedoms that you received.  You must make sure that they, too, receive
or can get the source code.  And you must show them these terms so they
know their rights.

  Developers that use the GNU GPL protect your rights with two steps:
(1) assert copyright on the software, and (2) offer you this License
giving you legal permission to copy, distribute and/or modify it.

  For the developers' and authors' protection, the GPL clearly explains
that there is no warranty for this free software.  For both users' and
authors' sake, the GPL requires that modified versions be marked as
changed, so that their problems will not be attributed erroneously to
authors of previous versions.

  Some devices are designed to deny users access to install or run
modified versions of the software inside them, although the manufacturer
can do so.  This is fundamentally incompatible with the aim of
protecting users' freedom to change the software.  The systematic
pattern of such abuse occurs in the area of products for individuals to
use, which is precisely where it is most unacceptable.  Therefore, we
have designed this version of the GPL to prohibit the practice for those
products.  If such problems arise substantially in other domains, we
stand ready to extend this provision to those domains in future versions
of the GPL, as needed to protect the freedom of users.

  Finally, every program is threatened constantly by software patents.
States should not allow patents to restrict development and use of
software on general-purpose computers, but in those that do, we wish to
avoid the special danger that patents applied to a free program could
make it effectively proprietary.  To prevent this, the GPL assures that
patents cannot be used to render the program non-free.

  The precise terms and conditions for copying, distribution and
modification follow.

                       TERMS AND CONDITIONS

  0. Definitions.

  "This License" refers to version 3 of the GNU General Public License.

  "Copyright" also means copyright-like laws that apply to other kinds of
works, such as semiconductor masks.

  "The Program" refers to any copyrightable work licensed under this
License.  Each licensee is addressed as "you".  "Licensees" and
"recipients" may be individuals or organizations.

  To "modify" a work means to copy from or adapt all or part of the work
in a fashion requiring copyright permission, other than the making of an
exact copy.  The resulting work is called a "modified version" of the
earlier work or a work "based on" the earlier work.

  A "covered work" means either the unmodified Program or a work based
on the Program.

  To "propagate" a work means to do anything with it that, without
permission, would make you directly or secondarily liable for
infringement under applicable copyright law, except executing it on a
computer or modifying a private copy.  Propagation includes copying,
distribution (with or without modification), making available to the
public, and in some countries other activities as well.

  To "convey" a work means any kind of propagation that enables other
parties to make or receive copies.  Mere interaction with a user through
a computer network, with no transfer of a copy, is not conveying.

  An interactive user interface displays "Appropriate Legal Notices"
to the extent that it includes a convenient and prominently visible
feature that (1) displays an appropriate copyright notice, and (2)
tells the user that there is no warranty for the work (except to the
extent that warranties are provided), that licensees may convey the
work under this License, and how to view a copy of this License.  If
the interface presents a list of user commands or options, such as a
menu, a prominent item in the list meets this criterion.

  1. Source Code.

  The "source code" for a work means the preferred form of the work
for making modifications to it.  "Object code" means any non-source
form of a work.

  A "Standard Interface" means an interface that either is an official
standard defined by a recognized standards body, or, in the case of
interfaces specified for a particular programming language, one that
is widely used among developers working in that language.

  The "System Libraries" of an executable work include anything, other
than the work as a whole, that (a) is included in the normal form of
packaging a Major Component, but which is not part of that Major
Component, and (b) serves only to enable use of the work with that
Major Component, or to implement a Standard Interface for which an
implementation is available to the public in source code form.  A
"Major Component", in this context, means a major essential component
(kernel, window system, and so on) of the specific operating system
(if any) on which the executable work runs, or a compiler used to
produce the work, or an object code interpreter used to run it.

  The "Corresponding Source" for a work in object code form means all
the source code needed to generate, install, and (for an executable
work) run the object code and to modify the work, including scripts to
control those activities.  However, it does not include the work's
System Libraries, or general-purpose tools or generally available free
programs which are used unmodified in performing those activities but
which are not part of the work.  For example, Corresponding Source
includes interface definition files associated with source files for
the work, and the source code for shared libraries and dynamically
linked subprograms that the work is specifically designed to require,
such as by intimate data communication or control flow between those
subprograms and other parts of the work.

  The Corresponding Source need not include anything that users
can regenerate automatically from other parts of the Corresponding
Source.

  The Corresponding Source for a work in source code form is that
same work.

  2. Basic Permissions.

  All rights granted under this License are granted for the term of
copyright on the Program, and are irrevocable provided the stated
conditions are met.  This License explicitly affirms your unlimited
permission to run the unmodified Program.  The output from running a
covered work is covered by this License only if the output, given its
content, constitutes a covered work.  This License acknowledges your
rights of fair use or other equivalent, as provided by copyright law.

  You may make, run and propagate covered works that you do not
convey, without conditions so long as your license otherwise remains
in force.  You may convey covered works to others for the sole purpose
of having them make modifications exclusively for you, or provide you
with facilities for running those works, provided that you comply with
the terms of this License in conveying all material for which you do
not control copyright.  Those thus making or running the covered works
for you must do so exclusively on your behalf, under your direction
and control, on terms that prohibit them from making any copies of
your copyrighted material outside their relationship with you.

  Conveying under any other circumstances is permitted solely under
the conditions stated below.  Sublicensing is not allowed; section 10
makes it unnecessary.

  3. Protecting Users' Legal Rights From Anti-Circumvention Law.

  No covered work shall be deemed part of an effective technological
measure under any applicable law fulfilling obligations under article
11 of the WIPO copyright treaty adopted on 20 December 1996, or
similar laws prohibiting or restricting circumvention of such
measures.

  When you convey a covered work, you waive any legal power to forbid
circumvention of technological measures to the extent such circumvention
is effected by exercising rights under this License with respect to
the covered work, and you disclaim any intention to limit operation or
modification of the work as a means of enforcing, against the work's
users, your or third parties' legal rights to forbid circumvention of
technological measures.

  4. Conveying Verbatim Copies.

  You may convey verbatim copies of the Program's source code as you
receive it, in any medium, provided that you conspicuously and
appropriately publish on each copy an appropriate copyright notice;
keep intact all notices stating that this License and any
non-permissive terms added in accord with section 7 apply to the code;
keep intact all notices of the absence of any warranty; and give all
recipients a copy of this License along with the Program.

  You may charge any price or no price for each copy that you convey,
and you may offer support or warranty protection for a fee.

  5. Conveying Modified Source Versions.

  You may convey a work based on the Program, or the modifications to
produce it from the Program, in the form of source code under the
terms of section 4, provided that you also meet all of these conditions:

    a) The work must carry prominent notices stating that you modified
    it, and giving a relevant date.

    b) The work must carry prominent notices stating that it is
    released under this License and any conditions added under section
    7.  This requirement modifies the requirement in section 4 to
    "keep intact all notices".

    c) You must license the entire work, as a whole, under this
    License to anyone who comes into possession of a copy.  This
    License will therefore apply, along with any applicable section 7
    additional terms, to the whole of the work, and all its parts,
    regardless of how they are packaged.  This License gives no
    permission to license the work in any other way, but it does not
    invalidate such permission if you have separately received it.

    d) If the work has interactive user interfaces, each must display
    Appropriate Legal Notices; however, if the Program has interactive
    interfaces that do not display Appropriate Legal Notices, your
    work need not make them do so.

  A compilation of a covered work with other separate and independent
works, which are not by their nature extensions of the covered work,
and which are not combined with it such as to form a larger program,
in or on a volume of a storage or distribution medium, is called an
"aggregate" if the compilation and its resulting copyright are not
used to limit the access or legal rights of the compilation's users
beyond what the individual works permit.  Inclusion of a covered work
in an aggregate does not cause this License to apply to the other
parts of the aggregate.

  6. Conveying Non-Source Forms.

  You may convey a covered work in object code form under the terms
of sections 4 and 5, provided that you also convey the
machine-readable Corresponding Source under the terms of this License,
in one of these ways:

    a) Convey the object code in, or embodied in, a physical product
    (including a physical distribution medium), accompanied by the
    Corresponding Source fixed on a durable physical medium
    customarily used for software interchange.

    b) Convey the object code in, or embodied in, a physical product
    (including a physical distribution medium), accompanied by a
    written offer, valid for at least three years and valid for as
    long as you offer spare parts or customer support for that product
    model, to give anyone who possesses the object code either (1) a
    copy of the Corresponding Source for all the software in the
    product that is covered by this License, on a durable physical
    medium customarily used for software interchange, for a price no
    more than your reasonable cost of physically performing this
    conveying of source, or (2) access to copy the
    Corresponding Source from a network server at no charge.

    c) Convey individual copies of the object code with a copy of the
    written offer to provide the Corresponding Source.  This
    alternative is allowed only occasionally and noncommercially, and
    only if you received the object code with such an offer, in accord
    with subsection 6b.

    d) Convey the object code by offering access from a designated
    place (gratis or for a charge), and offer equivalent access to the
    Corresponding Source in the same way through the same place at no
    further charge.  You need not require recipients to copy the
    Corresponding Source along with the object code.  If the place to
    copy the object code is a network server, the Corresponding Source
    may be on a different server (operated by you or a third party)
    that supports equivalent copying facilities, provided you maintain
    clear directions next to the object code saying where to find the
    Corresponding Source.  Regardless of what server hosts the
    Corresponding Source, you remain obligated to ensure that it is
    available for as long as needed to satisfy these requirements.

    e) Convey the object code using peer-to-peer transmission, provided
    you inform other peers where the object code and Corresponding
    Source of the work are being offered to the general public at no
    charge under subsection 6d.

  A separable portion of the object code, whose source code is excluded
from the Corresponding Source as a System Library, need not be
included in conveying the object code work.

  A "User Product" is either (1) a "consumer product", which means any
tangible personal property which is normally used for personal, family,
or household purposes, or (2) anything designed or sold for incorporation
into a dwelling.  In determining whether a product is a consumer product,
doubtful cases shall be resolved in favor of coverage.  For a particular
product received by a particular user, "normally used" refers to a
typical or common use of that class of product, regardless of the status
of the particular user or of the way in which the particular user
actually uses, or expects or is expected to use, the product.  A product
is a consumer product regardless of whether the product has substantial
commercial, industrial or non-consumer uses, unless such uses represent
the only significant mode of use of the product.

  "Installation Information" for a User Product means any methods,
procedures, authorization keys, or other information required to install
and execute modified versions of a covered work in that User Product from
a modified version of its Corresponding Source.  The information must
suffice to ensure that the continued functioning of the modified object
code is in no case prevented or interfered with solely because
modification has been made.

  If you convey an object code work under this section in, or with, or
specifically for use in, a User Product, and the conveying occurs as
part of a transaction in which the right of possession and use of the
User Product is transferred to the recipient in perpetuity or for a
fixed term (regardless of how the transaction is characterized), the
Corresponding Source conveyed under this section must be accompanied
by the Installation Information.  But this requirement does not apply
if neither you nor any third party retains the ability to install
modified object code on the User Product (for example, the work has
been installed in ROM).

  The requirement to provide Installation Information does not include a
requirement to continue to provide support service, warranty, or updates
for a work that has been modified or installed by the recipient, or for
the User Product in which it has been modified or installed.  Access to a
network may be denied when the modification itself materially and
adversely affects the operation of the network or violates the rules and
protocols for communication across the network.

  Corresponding Source conveyed, and Installation Information provided,
in accord with this section must be in a format that is publicly
documented (and with an implementation available to the public in
source code form), and must require no special password or key for
unpacking, reading or copying.

  7. Additional Terms.

  "Additional permissions" are terms that supplement the terms of this
License by making exceptions from one or more of its conditions.
Additional permissions that are applicable to the entire Program shall
be treated as though they were included in this License, to the extent
that they are valid under applicable law.  If additional permissions
apply only to part of the Program, that part may be used separately
under those permissions, but the entire Program remains governed by
this License without regard to the additional permissions.

  When you convey a copy of a covered work, you may at your option
remove any additional permissions from that copy, or from any part of
it.  (Additional permissions may be written to require their own
removal in certain cases when you modify the work.)  You may place
additional permissions on material, added by you to a covered work,
for which you have or can give appropriate copyright permission.

  Notwithstanding any other provision of this License, for material you
add to a covered work, you may (if authorized by the copyright holders of
that material) supplement the terms of this License with terms:

    a) Disclaiming warranty or limiting liability differently from the
    terms of sections 15 and 16 of this License; or

    b) Requiring preservation of specified reasonable legal notices or
    author attributions in that material or in the Appropriate Legal
    Notices displayed by works containing it; or

    c) Prohibiting misrepresentation of the origin of that material, or
    requiring that modified versions of such material be marked in
    reasonable ways as different from the original version; or

    d) Limiting the use for publicity purposes of names of licensors or
    authors of the material; or

    e) Declining to grant rights under trademark law for use of some
    trade names, trademarks, or service marks; or

    f) Requiring indemnification of licensors and authors of that
    material by anyone who conveys the material (or modified versions of
    it) with contractual assumptions of liability to the recipient, for
    any liability that these contractual assumptions directly impose on
    those licensors and authors.

  All other non-permissive additional terms are considered "further
restrictions" within the meaning of section 10.  If the Program as you
received it, or any part of it, contains a notice stating that it is
governed by this License along with a term that is a further
restriction, you may remove that term.  If a license document contains
a further restriction but permits relicensing or conveying under this
License, you may add to a covered work material governed by the terms
of that license document, provided that the further restriction does
not survive such relicensing or conveying.

  If you add terms to a covered work in accord with this section, you
must place, in the relevant source files, a statement of the
additional terms that apply to those files, or a notice indicating
where to find the applicable terms.

  Additional terms, permissive or non-permissive, may be stated in the
form of a separately written license, or stated as exceptions;
the above requirements apply either way.

  8. Termination.

  You may not propagate or modify a covered work except as expressly
provided under this License.  Any attempt otherwise to propagate or
modify it is void, and will automatically terminate your rights under
this License (including any patent licenses granted under the third
paragraph of section 11).

  However, if you cease all violation of this License, then your
license from a particular copyright holder is reinstated (a)
provisionally, unless and until the copyright holder explicitly and
finally terminates your license, and (b) permanently, if the copyright
holder fails to notify you of the violation by some reasonable means
prior to 60 days after the cessation.

  Moreover, your license from a particular copyright holder is
reinstated permanently if the copyright holder notifies you of the
violation by some reasonable means, this is the first time you have
received notice of violation of this License (for any work) from that
copyright holder, and you cure the violation prior to 30 days after
your receipt of the notice.

  Termination of your rights under this section does not terminate the
licenses of parties who have received copies or rights from you under
this License.  If your rights have been terminated and not permanently
reinstated, you do not qualify to receive new licenses for the same
material under section 10.

  9. Acceptance Not Required for Having Copies.

  You are not required to accept this License in order to receive or
run a copy of the Program.  Ancillary propagation of a covered work
occurring solely as a consequence of using peer-to-peer transmission
to receive a copy likewise does not require acceptance.  However,
nothing other than this License grants you permission to propagate or
modify any covered work.  These actions infringe copyright if you do
not accept this License.  Therefore, by modifying or propagating a
covered work, you indicate your acceptance of this License to do so.

  10. Automatic Licensing of Downstream Recipients.

  Each time you convey a covered work, the recipient automatically
receives a license from the original licensors, to run, modify and
propagate that work, subject to this License.  You are not responsible
for enforcing compliance by third parties with this License.

  An "entity transaction" is a transaction transferring control of an
organization, or substantially all assets of one, or subdividing an
organization, or merging organizations.  If propagation of a covered
work results from an entity transaction, each party to that
transaction who receives a copy of the work also receives whatever
licenses to the work the party's predecessor in interest had or could
give under the previous paragraph, plus a right to possession of the
Corresponding Source of the work from the predecessor in interest, if
the predecessor has it or can get it with reasonable efforts.

  You may not impose any further restrictions on the exercise of the
rights granted or affirmed under this License.  For example, you may
not impose a license fee, royalty, or other charge for exercise of
rights granted under this License, and you may not initiate litigation
(including a cross-claim or counterclaim in a lawsuit) alleging that
any patent claim is infringed by making, using, selling, offering for
sale, or importing the Program or any portion of it.

  11. Patents.

  A "contributor" is a copyright holder who authorizes use under this
License of the Program or a work on which the Program is based.  The
work thus licensed is called the contributor's "contributor version".

  A contributor's "essential patent claims" are all patent claims
owned or controlled by the contributor, whether already acquired or
hereafter acquired, that would be infringed by some manner, permitted
by this License, of making, using, or selling its contributor version,
but do not include claims that would be infringed only as a
consequence of further modification of the contributor version.  For
purposes of this definition, "control" includes the right to grant
patent sublicenses in a manner consistent with the requirements of
this License.

  Each contributor grants you a non-exclusive, worldwide, royalty-free
patent license under the contributor's essential patent claims, to
make, use, sell, offer for sale, import and otherwise run, modify and
propagate the contents of its contributor version.

  In the following three paragraphs, a "patent license" is any express
agreement or commitment, however denominated, not to enforce a patent
(such as an express permission to practice a patent or covenant not to
sue for patent infringement).  To "grant" such a patent license to a
party means to make such an agreement or commitment not to enforce a
patent against the party.

  If you convey a covered work, knowingly relying on a patent license,
and the Corresponding Source of the work is not available for anyone
to copy, free of charge and under the terms of this License, through a
publicly available network server or other readily accessible means,
then you must either (1) cause the Corresponding Source to be so
available, or (2) arrange to deprive yourself of the benefit of the
patent license for this particular work, or (3) arrange, in a manner
consistent with the requirements of this License, to extend the patent
license to downstream recipients.  "Knowingly relying" means you have
actual knowledge that, but for the patent license, your conveying the
covered work in a country, or your recipient's use of the covered work
in a country, would infringe one or more identifiable patents in that
country that you have reason to believe are valid.

  If, pursuant to or in connection with a single transaction or
arrangement, you convey, or propagate by procuring conveyance of, a
covered work, and grant a patent license to some of the parties
receiving the covered work authorizing them to use, propagate, modify
or convey a specific copy of the covered work, then the patent license
you grant is automatically extended to all recipients of the covered
work and works based on it.

  A patent license is "discriminatory" if it does not include within
the scope of its coverage, prohibits the exercise of, or is
conditioned on the non-exercise of one or more of the rights that are
specifically granted under this License.  You may not convey a covered
work if you are a party to an arrangement with a third party that is
in the business of distributing software, under which you make payment
to the third party based on the extent of your activity of conveying
the work, and under which the third party grants, to any of the
parties who would receive the covered work from you, a discriminatory
patent license (a) in connection with copies of the covered work
conveyed by you (or copies made from those copies), or (b) primarily
for and in connection with specific products or compilations that
contain the covered work, unless you entered into that arrangement,
or that patent license was granted, prior to 28 March 2007.

  Nothing in this License shall be construed as excluding or limiting
any implied license or other defenses to infringement that may
otherwise be available to you under applicable patent law.

  12. No Surrender of Others' Freedom.

  If conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot convey a
covered work so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you may
not convey it at all.  For example, if you agree to terms that obligate you
to collect a royalty for further conveying from those to whom you convey
the Program, the only way you could satisfy both those terms and this
License would be to refrain entirely from conveying the Program.

  13. Use with the GNU Affero General Public License.

  Notwithstanding any other provision of this License, you have
permission to link or combine any covered work with a work licensed
under version 3 of the GNU Affero General Public License into a single
combined work, and to convey the resulting work.  The terms of this
License will continue to apply to the part which is the covered work,
but the special requirements of the GNU Affero General Public License,
section 13, concerning interaction through a network will apply to the
combination as such.

  14. Revised Versions of this License.

  The Free Software Foundation may publish revised and/or new versions of
the GNU General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

  Each version is given a distinguishing version number.  If the
Program specifies that a certain numbered version of the GNU General
Public License "or any later version" applies to it, you have the
option of following the terms and conditions either of that numbered
version or of any later version published by the Free Software
Foundation.  If the Program does not specify a version number of the
GNU General Public License, you may choose any version ever published
by the Free Software Foundation.

  If the Program specifies that a proxy can decide which future
versions of the GNU General Public License can be used, that proxy's
public statement of acceptance of a version permanently authorizes you
to choose that version for the Program.

  Later license versions may give you additional or different
permissions.  However, no additional obligations are imposed on any
author or copyright holder as a result of your choosing to follow a
later version.

  15. Disclaimer of Warranty.

  THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY
APPLICABLE LAW.  EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT
HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY
OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE.  THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM
IS WITH YOU.  SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF
ALL NECESSARY SERVICING, REPAIR OR CORRECTION.

  16. Limitation of Liability.

  IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES AND/OR CONVEYS
THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY
GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE
USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF
DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD
PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS),
EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF
SUCH DAMAGES.

  17. Interpretation of Sections 15 and 16.

  If the disclaimer of warranty and limitation of liability provided
above cannot be given local legal effect according to their terms,
reviewing courts shall apply local law that most closely approximates
an absolute waiver of all civil liability in connection with the
Program, unless a warranty or assumption of liability accompanies a
copy of the Program in return for a fee.

                     END OF TERMS AND CONDITIONS

The file UserDB.txt is copyrighted by BoB / Team PEiD distributed under the following
MIT license.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be included in all copies
or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.

The file jquery.js is copyrighted by John Resig and dual licensed under the MIT or GPL
Version 2 licenses (see: http://jquery.org/license).

The files lightbox.js and lightbox.css are copyrighted by Lokesh Dhakar and licensed under
the Creative Commons Attribution 2.5 License
(see: http://creativecommons.org/licenses/by/2.5/).

The files bootstrap-fileupload.js, jasny-bootstrap.js, jasny-bootstrap.min.js,
jasny-bootstrap.css, jasny-bootstrap.min.css, jasny-bootstrap-responsive.css,
jasny-bootstrap-responsive.min.css are copyrighted by Jasny BV and licensed under the Apache
License, Version 2.0.

The files bootstrap.min.js, bootstrap.min.css, bootstrap-responsive.min.css,
glyphicons-halflings.png, glyphicons-halflings-white.png are copyrighted by Twitter, Inc.
and licensed under the Apache License, Version 2.0.

The file analyzer/windows/modules/amsi.py uses parts of pywintrace
(https://github.com/fireeye/pywintrace), which is copyrighted by FireEye, Inc. and licensed
under the Apache License, Version 2.0.

 */
rule CAPE_Formhooka
{
	meta:
		description = "Formbook Anti-hook Bypass"
		author = "kevoreilly"
		id = "6369de74-99eb-57ae-a315-c15f22effc73"
		date = "2021-03-07"
		modified = "2026-05-15"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Formbook.yar#L1-L14"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "21b8101a7039cfad0e9d49cc1f055bc23a2eb4c973dcda2a81a007e452d77a6d"
		score = 75
		quality = 70
		tags = ""
		cape_options = "clear,bp0=$remap_ntdll_0,action0=setedx:ntdll,count0=1,bp1=$remap_ntdll_1,action1=setdst:ntdll,count1=1"
		packed = "9e38c0c3c516583da526016c4c6a671c53333d3d156562717db79eac63587522"
		packed = "b8e44f4a0d92297c5bb5b217c121f0d032850b38749044face2b0014e789adfb"

	strings:
		$remap_ntdll_0 = {33 56 04 8D 86 [2] 00 00 68 F0 00 00 00 50 89 56 ?? E8 [4] 8B [1-5] 6A 00 6A 04 8D 4D ?? 51 6A 07 52 56 E8 [4] 8B 45 ?? 83 C4 20 3B}
		$remap_ntdll_1 = {33 56 0C 8D 86 [2] 00 00 68 F0 00 00 00 50 89 56 ?? E8 [4] 8B [1-5] 6A 00 6A 04 8D 4D ?? 51 6A 07 52 56 E8 [4] 8B 45 ?? 83 C4 20 3B}

	condition:
		any of them
}
rule CAPE_Formconfa
{
	meta:
		description = "Formbook Config Extraction"
		author = "kevoreilly"
		id = "f9c3fc92-e2c8-5968-b0f4-80bd8199b7ca"
		date = "2021-03-07"
		modified = "2026-05-15"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Formbook.yar#L32-L44"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "b0aa4cec55a21245d8104380c531dd6cc0fdef64fbefd79616eadfb4e95b2d75"
		score = 75
		quality = 70
		tags = ""
		cape_options = "clear,bp0=$c2,action0=string:rcx+1,bp1=$decoy+67,action1=string:rcx+1,count=0,typestring=Formbook Config"
		packed = "b8e44f4a0d92297c5bb5b217c121f0d032850b38749044face2b0014e789adfb"

	strings:
		$c2 = {44 8B C6 48 8B D3 49 8B CE E8 [4] 44 88 23 41 8B DD 48 8D [2] 66 66 66 0F 1F 84 00 00 00 00 00 BA 8D 00 00 00 41 FF C4}
		$decoy = {8B D7 0F 1F 44 00 00 0F B6 03 FF C0 48 98 48 03 D8 48 FF CA 75 ?? 44 0F B6 03 48 8D 53 01 48 8D 4C [2] E8}

	condition:
		all of them
}
rule CAPE_Formhelper
{
	meta:
		description = "Formbook Config Extraction"
		author = "kevoreilly"
		id = "83b56e70-892e-5918-aff7-c2c41a89a5ab"
		date = "2021-03-07"
		modified = "2026-05-15"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Formbook.yar#L46-L58"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "e049fba8e53934587f97bda5108cf9cece4169a8ff65a5d2788a98f709a68dc0"
		score = 75
		quality = 70
		tags = ""
		cape_options = "clear,bp2=$config,action2=scan,count=0"
		packed = "0270016f451f9ba630f2ea4e2ea006fb89356627835b560bb2f4551a735ba0e1"

	strings:
		$config = {40 55 53 56 57 41 54 41 55 41 56 41 57 48 8D AC 24 [4] 48 81 EC [2] 00 00 45 33 ?? 33 C0 4C 8B E9 4C 89}
		$decode = {66 66 66 66 0F 1F 84 00 00 00 00 00 0F (B6|B7) [2-5] 48 FF C9 ?? 41}

	condition:
		all of them
}
rule CAPE_Formconfb
{
	meta:
		description = "Formbook Config Extraction"
		author = "kevoreilly"
		id = "55fe6f1d-1f60-537c-a763-3ea2659609b1"
		date = "2021-03-07"
		modified = "2026-05-15"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Formbook.yar#L60-L75"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "c8bf1d3c242a02ae8bee42d570010c8b4a881db64d82b157fc4ac18f71e11f71"
		score = 75
		quality = 70
		tags = ""
		cape_options = "clear,bp0=$c2,action0=string:rcx,bp1=$decoy,action1=string,bp3=$sleep+5,action3=skip,count=0,typestring=Formbook Config"
		packed = "60571b2683e7b753a77029ebe9b5e1cb9f3fbfa8d6a43e4b7239eefd13141ae4"

	strings:
		$c2_1 = {44 0F B6 5D ?? 45 84 DB 74 ?? 48 8D 4D [1-5] 41 80 FB 2F 74 11 0F B6 41 01 48 FF C1 FF C3 44 0F B6 D8 84 C0 75}
		$c2_2 = {40 53 48 83 EC 20 48 8B DA 48 85 C9 74 28 80 39 00 74 23 48 85 D2 74 1E 48 8B D1 41 B8 04 00 00 00 48 8B CB E8}
		$decoy = {44 8D 1C (33|37) [0-13] 48 8D 7D [1-8] 42 C6 44 [2] 00 [0-11] 48 8B CF E8}
		$config = {40 55 53 56 57 41 54 41 55 41 56 41 57 48 8D AC 24 [4] 48 81 EC [2] 00 00 45 33 ?? 33 C0 4C 8B E9 4C 89}
		$sleep = {B9 88 13 00 00 FF D7 44 8B 9B [4] 41 81 FB 00 01 00 00 75 ?? 48 39 B3 [4] 74 ?? 8B 83 [4] 05 00 20 00 00 39 B0}

	condition:
		$decoy and any of ( $c2_* ) and ( $config or $sleep )
}
rule CAPE_Icedidsyscallwritemem : FILE
{
	meta:
		description = "IcedID 'syscall' packer bypass - direct write variant"
		author = "kevoreilly"
		id = "67935058-4191-587f-ad19-497defd0eef1"
		date = "2021-03-30"
		modified = "2023-11-28"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/IcedID.yar#L1-L13"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "6b068106b038e9efeb9057cadf314d400c1ada1a1cc70336d3272da3a212c993"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$tokencheck+9,action0=jmp,count=0"
		packed = "28075ecae5e224c06e250f2c949c826b81844bca421e9158a7a9e965a29ef894"
		packed = "045dff9f14a03225df55997cb2ca74ff60ecaf317b9e033ea93386785db84161"

	strings:
		$tokencheck = {39 5D ?? 75 06 83 7D ?? 03 74 05 BB 01 00 00 00 41 89 1C ?? 48 8B 4D ?? 41 FF D?}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CAPE_Icedidhook
{
	meta:
		description = "IcedID hook fix"
		author = "kevoreilly"
		id = "011c9cb7-8080-5f8a-9dca-6397e9bf7bf6"
		date = "2021-03-30"
		modified = "2023-11-28"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/IcedID.yar#L15-L25"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "fd62e0ed6f2a18472fa9336daee0e8a3a55e21779a8385394e85f96da928e24f"
		score = 75
		quality = 70
		tags = ""
		cape_options = "ntdll-protect=0"

	strings:
		$hook = {C6 06 E9 83 E8 05 89 46 01 8D 45 ?? 50 FF 75 ?? 6A 05 56 6A FF E8 2D FA FF FF}

	condition:
		any of them
}
rule CAPE_Icedidpackera : FILE
{
	meta:
		description = "IcedID export selection"
		author = "kevoreilly"
		id = "d793d8a1-0e17-56ad-933c-470e2290867b"
		date = "2021-03-30"
		modified = "2023-11-28"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/IcedID.yar#L27-L40"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "fbad60002286599ca06d0ecb3624740efbf13ee5fda545341b3e0bf4d5348cfe"
		logic_hash = "aa0681e7794546355e6d61f739c49035a493cdfca7e666531d74e3835ec44408"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "export=$export"

	strings:
		$init = "init"
		$export = {48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 48 81 EC [2] 00 00 41 8B E9 49 8B F0 48 8B FA 48 8B D9}
		$alloc = {8B 50 50 33 C9 44 8D 49 40 41 B8 00 30 00 00 FF 15 [4] 48 89 44 24 28 [0-3] 48 89 84 24 ?? 00 00 00 E9}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CAPE_Icedidpackerb : FILE
{
	meta:
		description = "IcedID export selection"
		author = "kevoreilly"
		id = "6bd0e64d-e60e-5cd2-af79-946a7f6dc9f5"
		date = "2021-03-30"
		modified = "2023-11-28"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/IcedID.yar#L42-L56"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "6517ef2c579002ec62ddeb01a3175917c75d79ceca355c415a4462922c715cb6"
		logic_hash = "fde1e2c0124d180b2fa3d0675b35e8d78fdd7b06cd27e9228c148aa29ce30ee7"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "export=$export"

	strings:
		$init = "init"
		$export = {44 89 4C 24 20 4C 89 44 24 18 48 89 4C 24 08 41 55 41 56 41 57 48 81 EC ?? 00 00 00 B9 [2] 00 00 4C 8B EA E8}
		$loop = {8B C2 48 8D 49 01 83 E0 07 FF C2 0F B6 44 30 ?? 30 41 FF 3B D5 72}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CAPE_Icedidpackerc : FILE
{
	meta:
		description = "IcedID export selection"
		author = "kevoreilly"
		id = "fddfd0d2-1bc0-56bb-b983-5850e17a3d0f"
		date = "2021-03-30"
		modified = "2023-11-28"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/IcedID.yar#L58-L71"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "c06805b6efd482c1a671ec60c1469e47772c8937ec0496f74e987276fa9020a5"
		hash = "265c1857ac7c20432f36e3967511f1be0b84b1c52e4867889e367c0b5828a844"
		logic_hash = "f1e75e380ab0947fdfda012b7a5077a1c2ef51163239846ab2dc29cac95ba166"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "export=$export"

	strings:
		$export = {44 89 4C 24 20 4C 89 44 24 18 48 89 54 24 10 3A ED 74}
		$alloc = {41 B8 00 10 00 00 8B D0 33 C9 66 3B ?? (74|0F 84)}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CAPE_Icedidpackerd : FILE
{
	meta:
		description = "IcedID export selection"
		author = "kevoreilly"
		id = "df0ca4bd-1ea6-57ef-b85a-7ed0e2a20831"
		date = "2021-03-30"
		modified = "2023-11-28"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/IcedID.yar#L73-L86"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "7b226f8cc05fa7d846c52eb0ec386ab37f9bae04372372509daa6bacc9f885d8"
		logic_hash = "6685e0246f5a11ce0ca33447837de06506b447a5f8591423e2b76f2ab0274dc7"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "export=$export"

	strings:
		$init = "init"
		$export = {44 89 4C 24 20 4C 89 44 24 18 48 89 54 24 10 66 3B ED 74}
		$load = {41 B8 00 80 00 00 33 D2 48 8B 4C [2] EB ?? B9 69 04 00 00 E8 [4] 48 89 84 [2] 00 00 00 66 3B ED 74}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CAPE_Icedsleep : FILE
{
	meta:
		description = "IcedID sleep bypass"
		author = "kevoreilly"
		id = "d6bd708b-47bc-5620-b40e-8fe5f1a67ba4"
		date = "2021-03-30"
		modified = "2023-11-28"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/IcedID.yar#L88-L99"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "0b1a8be95b1b8a3b066837f9e47561ee8202d741b39d64e626c0461c2fbf7c70"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "force-sleepskip=1"
		packed = "e99f3517a36a9f7a55335699cfb4d84d08b042d47146119156f7f3bab580b4d7"

	strings:
		$sleep = {89 4C 24 08 48 83 EC 38 8B 44 24 40 48 69 C0 10 27 00 00 48 F7 D8 48 89 44 24 20 48 8D 54 24 20 33 C9 FF 15 [4] 48 83 C4 38 C3}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CAPE_Smokeinjector : FILE
{
	meta:
		description = "No description has been set in the source file - CAPE"
		author = "kevoreilly"
		id = "955afcbe-45c9-5c9a-a76b-d89ae1b381bc"
		date = "2023-02-06"
		modified = "2025-11-19"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/SmokeLoader.yar#L1-L11"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "757a2bf8aceb92bee839bfcaba3b1a8bc4c037812b969e0f493e4f7a4ddc9ede"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "monitor=explorer"
		packed = "d38f9ab81a054203e5b5940e6d34f3c8766f4f4104b14840e4695df511feaa30"

	strings:
		$dec1 = {80 04 08 [0-7] (49|83 E9 01) [0-7] 41 [0-7] 81 F1 [2] 00 00 [0-7] 01 D9 [0-7] FF E1}

	condition:
		uint16( 0 ) == 0x5A4D and any of them
}
rule CAPE_Agentteslav4Jit
{
	meta:
		description = "AgentTesla V4 JIT native config extractor"
		author = "kevoreilly"
		id = "a87dca44-4974-543c-9565-487ed99be2a6"
		date = "2023-09-13"
		modified = "2024-02-27"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/AgentTesla.yar#L1-L14"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "8f7144d2a989ce8d291af926b292f5f0f7772e707b0e49797eba13ecf91b90bc"
		score = 75
		quality = 70
		tags = ""
		cape_options = "bp0=$decode1+8,count=0,action0=string:ecx,typestring=AgentTesla Strings,no-logs=2"
		packed = "7f8a95173e17256698324886bb138b7936b9e8c5b9ab8fffbfe01080f02f286c"

	strings:
		$decode1 = {8B 01 8B 40 3C FF 50 10 8B C8 E8 [4] 89 45 CC B8 1A 00 00 00}
		$decode2 = {83 F8 18 75 2? 8B [2-5] D1 F8}
		$decode3 = {8D 4C 0? 08 0F B6 01 [0-3] 0F B6 5? 04 33 C2 88 01 B8 19 00 00 00}

	condition:
		2 of them
}
rule CAPE_Agentteslav3Jit
{
	meta:
		description = "AgentTesla V3 JIT native string decryption"
		author = "ClaudioWayne"
		id = "590c5058-c1db-5366-8db5-57449a178999"
		date = "2023-09-13"
		modified = "2024-02-27"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/AgentTesla.yar#L16-L26"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "62a49cf4295df637f96ba7c127cfc4aeb9af2fcced497fdf34d726a062edc1ec"
		score = 75
		quality = 70
		tags = ""
		cape_options = "bp0=$decode+20,count=0,action0=string:eax+8,typestring=AgentTesla Strings,no-logs=2"

	strings:
		$decode = {8B C8 57 FF 75 08 8B [5] 8B 01 8B 40 3C FF [2] 8B F0 B8 03 00 00 00}

	condition:
		all of them
}
rule CAPE_Hijackloaderstub
{
	meta:
		description = "HijackLoader Stub Executable"
		author = "kevoreilly"
		id = "53363a3a-7f2a-52a6-8c0a-5f03fd121f70"
		date = "2026-01-26"
		modified = "2026-01-26"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/HijackLoader.yar#L1-L13"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "686a19a416b94f6ccdd1891ff027452c84b2171ee4268ff971f490e18948a6f5"
		score = 75
		quality = 70
		tags = ""
		cape_options = "dump-limit=0,dump"

	strings:
		$stub1 = {50 83 C0 10 50 56 8D 85 [4] 50 E8 [4] 83 C7 30 8D 85 [4] 3B F8 74 08 8B 35 [4] EB D3}
		$stub2 = {33 C5 89 45 ?? (C6 45 ?? 00|C7 45 ?? 61 7A 2D 2D) 8D 45 ?? FF 75 ?? C7 45 ?? 30 39 41 5A 50 8D 45 (??|?? C7 45 ?? 61 7A 2D 2D) 50 E8}
		$app = "\\app-" wide

	condition:
		2 of them
}
rule CAPE_Slowloader
{
	meta:
		description = "SlowLoader detonation aide for slow cpus (thread race)"
		author = "kevoreilly"
		id = "05724bf4-b767-542d-a2dd-a9ae3e5ea5cc"
		date = "2024-09-23"
		modified = "2024-09-23"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/SlowLoader.yar#L1-L12"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "f07528c646ebd980a5e843caa4a4715e31b22c3cd091576600e9fe45d7fc2fe4"
		score = 75
		quality = 70
		tags = ""
		cape_options = "break-on-return=CreateProcessA,action0=sleep:1000,count=0"
		packed = "f6eeb73ffb3e6d6cc48f74344cb590614db7e3116ba00a52aefd7dff468a60a5"

	strings:
		$code = {0F B6 44 07 08 0F B6 54 1F 08 03 C2 25 FF 00 00 80 79 07 48 0D 00 FF FF FF 40 89 45 ?? 6A 00}

	condition:
		any of them
}
rule CAPE_Remus : FILE
{
	meta:
		description = "No description has been set in the source file - CAPE"
		author = "kevoreilly"
		id = "d8d7ac4b-6fa0-51fa-a005-483de046876c"
		date = "2026-07-31"
		modified = "2026-08-19"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Remus.yar#L1-L14"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "836b4219141a17ba963155881d8d166fe528fcb8804135ceac4141de03796601"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$c2*-11,action0=string:rsi,count=0,typestring=Remus Config"
		packed = "f67a176503343855c88d9aac1217277ee4e2badc5e56fe403e56ca30e144b266"

	strings:
		$wmi = {48 89 F9 45 31 C0 FF D0 48 83 C4 30 85 C0 0F 99 C0 66 8B [1-4] 00 66 83 E9 08 0F 94 C1 20 C8}
		$dec1 = {0F B6 04 0B 41 88 04 (0A|0B) 0F B6 44 0B 01 41 88 44 (0A|0B) 01 0F B6 44 0B 02 41 88 44 (0A|0B) 02 0F B6 44 0B 03 41 88 44 (0A|0B) 03 48 83 C1 04 49 39 C9 75 D1 90}
		$dec2 = {48 B9 00 00 00 00 00 00 F8 7F 48 39 C8 0F 9F C1 48 BA 00 00 00 00 00 80 07 00 48 21 C2 48 B8 00 00 00 00 00 00 02 00 48 39 C2 0F 94 C0 20 C8 0F B6 C0 48 8D 0D [4] FF 24 C1}
		$c2 = {C1 E0 06 48 8D 15 [4] 48 01 C2 48 8D 0D [4] 48 8D B4 24 [2] 00 00 49 89 F0 E8 [4] 48 8D 0D [4] BA 40 00 00 00 49 89 F0 45 31 C9 E8 [4] 40 B6 01 E9}

	condition:
		uint16( 0 ) == 0x5A4D and 2 of them
}
rule CAPE_Mysterysnail
{
	meta:
		description = "MysterySnail anti-sandbox bypass"
		author = "kevoreilly"
		id = "dfeb820a-3101-5588-8348-3b62a6900538"
		date = "2021-10-16"
		modified = "2021-10-16"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/MysterySnail.yar#L1-L11"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "9402dbbbfdd286e2309ee83fc08194f70f73657a3a4e3785dfbcb564dbee86a8"
		score = 75
		quality = 70
		tags = ""
		cape_options = "bp0=$anti+62,action0=skip,count=0"

	strings:
		$anti = {F2 0F 10 [3] 66 0F 2F 05 [4] 76 0A 8B [3] FF C0 89 [3] B9 5B 05 00 00 FF 15 [4] E8 [4] 89 [3] 8B [3] 8B [3] 2B C8 8B C1 3B [3] 7E 16}

	condition:
		any of them
}
rule CAPE_Guloaderprecursor : FILE
{
	meta:
		description = "Guloader precursor"
		author = "kevoreilly"
		id = "663f89d7-a18b-5b03-a7cb-52444a887fa4"
		date = "2020-12-29"
		modified = "2023-10-02"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Guloader.yar#L17-L28"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "ea05c352739366a03da302074b01537382ba26f7fd5049004f156e47d284f070"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$antidbg,action0=scan,hc0=1,count=0"

	strings:
		$antidbg = {39 48 04 (0F 85 [3] ??|75 ??) 39 48 08 (0F 85 [3] ??|75 ??) 39 48 0C (0F 85 [3] ??|75 ??)}
		$except = {8B 45 08 [0-3] 8B 00 [0-3] 8B 58 18 [0-20] 81 38 05 00 00 C0 0F 85 [4-7] 83 FB 00 (0F 84|74)}

	condition:
		2 of them and not uint16( 0 ) == 0x5A4D
}
rule CAPE_Latrodectus : FILE
{
	meta:
		description = "Latrodectus export selection"
		author = "kevoreilly"
		id = "7c6f167a-6b76-5509-b164-306d1cd19b0f"
		date = "2024-02-26"
		modified = "2024-02-26"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Latrodectus.yar#L1-L12"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "378d220bc863a527c2bca204daba36f10358e058df49ef088f8b1045604d9d05"
		logic_hash = "c2c9f23e287253d766425c05eb774f6e07bdcbabc259e04b723a1a87c8b91fbd"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "export=$export"

	strings:
		$export = {48 8B C4 48 89 58 08 48 89 68 10 48 89 70 18 48 89 78 20 41 56 48 83 EC 30 4C 8B 05 [4] 33 D2 C7 40 [5] 88 50 ?? 49 63 40 3C 42 8B 8C 00 88 00 00 00 85 C9 0F 84}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CAPE_Themida : FILE
{
	meta:
		description = "Themida detonation shim"
		author = "kevoreilly"
		id = "cd5c8b08-4864-57f7-b218-1bcb6892bea8"
		date = "2024-09-10"
		modified = "2024-09-11"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Themida.yar#L1-L12"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "c4f1e01a3fe3cb66062ce03253bfe9edc09dc6f1a77db99b281106e8ceff9257"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "unhook-apis=NtSetInformationThread,force-sleepskip=0"
		packed = "6337ff4cf413f56cc6c9a8e67f24b8d7f94f620eae06ac9f0b113b5ba82ea176"

	strings:
		$code = {FC 31 C9 49 89 CA 31 C0 31 DB AC 30 C8 88 E9 88 D5 88 F2 B6 08 66 D1 EB 66 D1 D8 73 09}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CAPE_Rdtscpantivm
{
	meta:
		description = "RdtscpAntiVM bypass"
		author = "kevoreilly"
		id = "11dc634b-1e2f-55b4-be60-98e51de42d43"
		date = "2021-12-11"
		modified = "2021-12-11"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/RdtscpAntiVM.yar#L1-L11"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "be0f9b52fb630730a38160f4ad2d50b6b4bea5edd82e3ea4d1e257cf7b090910"
		score = 75
		quality = 70
		tags = ""
		cape_options = "nop-rdtscp=1"

	strings:
		$antivm = {46 0F 01 F9 [0-4] 66 0F 6E C6 F3 0F E6 C0 66 0F 2F ?? 73}

	condition:
		any of them
}
rule CAPE_Doomedloader : FILE
{
	meta:
		description = "No description has been set in the source file - CAPE"
		author = "kevoreilly"
		id = "88436e71-360e-5719-989f-24e71591ebe0"
		date = "2024-04-12"
		modified = "2024-07-25"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/DoomedLoader.yar#L1-L12"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "54a5962ef49ebf987908c4ea1559788f7c96a7e4ea61d2973636e998a0239c77"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "clear,bp0=$anti*-4,action0=setzeroflag,sysbp=$syscall+7,count=0,procdump=2"
		packed = "914b1b3180e7ec1980d0bafe6fa36daade752bb26aec572399d2f59436eaa635"

	strings:
		$anti = {48 8B 4C 24 ?? E8 [4] 84 C0 B8 [4] 41 0F 45 C6 EB}
		$syscall = {49 89 CA 8B 44 24 08 FF 64 24 10}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CAPE_Risepro : FILE
{
	meta:
		description = "No description has been set in the source file - CAPE"
		author = "kevoreilly"
		id = "63d9cb19-0688-5632-8477-ce9b7e986a55"
		date = "2023-12-16"
		modified = "2023-12-16"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/RisePro.yar#L1-L14"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "1b69a1dd5961241b926605f0a015fa17149c3b2759fb077a30a22d4ddcc273f6"
		logic_hash = "055ca8328923b91f93c116e4a856366356fa11155f4e9fde95da31129b51386a"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$c2+15,action0=string:edx,bp1=$c2+41,action1=string:ecx,count=1"

	strings:
		$decode1 = {8A 06 46 84 C0 75 F9 2B F1 B8 FF FF FF 7F 8B 4D ?? 8B 51 ?? 2B C2 3B C6 72 38 83 79 ?? 10 72 02 8B 09 52 51 56 53 51 FF 75 ?? 8B CF E8}
		$decode2 = {8B D9 81 FF FF FF FF 7F 0F [2] 00 00 00 C7 43 ?? 0F 00 00 00 83 FF 10 73 1A 57 FF 75 ?? 89 7B ?? 53 E8 [4] 83 C4 0C C6 04 1F 00 5F 5B 5D C2 08 00}
		$c2 = {FF 75 30 83 3D [4] 10 BA [4] B9 [4] 0F 43 15 [4] 83 3D [4] 10 0F 43 0D [4] E8 [4] A3}

	condition:
		uint16( 0 ) == 0x5A4D and any of them
}
rule CAPE_Amatera : FILE
{
	meta:
		description = "Amatera syscall capture"
		author = "kevoreilly"
		id = "0d58a054-8636-58d8-99b9-26560aa6c187"
		date = "2025-06-25"
		modified = "2025-06-25"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Amatera.yar#L1-L14"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "35eb93548a0c037d392f870c05e0e9fb1aeff3a5a505e1d4a087f7465ed1f6af"
		logic_hash = "1c02f04846568b85acbd4101b2e944dc824179f7cff1bceaec1c657939b610d5"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "sysbp=$sysenter"

	strings:
		$sysenter = {64 FF 15 C0 00 00 00 C3}
		$harness = {0F B7 55 EC 52 E8 [4] 83 C4 04 C7 45 F0 [4] 8B 45 ?? 50 [0-40] FF 55 F0 83 C4 ?? 8B E5 5D C3}
		$socket = {66 89 [2] 6A 00 6A ?? 8D [3] 68 (03|07) 20 01 00 8B 4D F8 E8 [4] 0F B6 (C0|C8) 85 (C0|C9) 75 04 32 C0 EB}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CAPE_Cargobayloader : FILE
{
	meta:
		description = "CargoBayLoader anti-vm bypass"
		author = "kevoreilly"
		id = "5b347863-0bea-55d2-aaf3-b3d6e604be89"
		date = "2023-02-20"
		modified = "2023-02-20"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/CargoBayLoader.yar#L1-L13"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "75e975031371741498c5ba310882258c23b39310bd258239277708382bdbee9c"
		logic_hash = "1d5c4ca79f97e1fac358189a8c6530be12506974fc2fb42f63b0b621536a45c9"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$jmp1+4,action0=skip,bp1=$jmp2+2,action1=skip,count=1,force-sleepskip=1"

	strings:
		$jmp1 = {40 42 0F 00 0F 82 [2] 00 00 48 8D 15 [4] BF 04 00 00 00 41 B8 04 00 00 00 4C 8D [3] 4C 89 F1 E8}
		$jmp2 = {84 DB 0F 85 [2] 00 00 48 8D 15 [4] 41 BE 03 00 00 00 41 B8 03 00 00 00 4C 8D 7C [2] 4C 89 F9 E8}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CAPE_Qakbot5 : FILE
{
	meta:
		description = "QakBot WMI anti-anti-vm"
		author = "kevoreilly"
		id = "d287b043-15df-5865-ad4c-9eb64ceec04c"
		date = "2022-03-16"
		modified = "2024-02-16"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/QakBot.yar#L1-L13"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "303ea2d8d1a7f0fd0ca5508dae2c1b83c03b1e3e975760f15d36d93bcc152767"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$loop+35,action0=skip,count=0"
		packed = "f4bb0089dcf3629b1570fda839ef2f06c29cbf846c5134755d22d419015c8bd2"

	strings:
		$loop = {8B 75 ?? 48 8B 4C [2] FF 15 [4] 48 8B 4C [2] 48 8B 01 FF 50 ?? 8B DE 48 8B 4C [2] 48 85 C9 0F 85 [4] EB 4E}
		$conf = {0F B7 1D [4] B9 [2] 00 00 E8 [4] 8B D3 48 89 45 ?? 45 33 C9 48 8D 0D [4] 4C 8B C0 48 8B F8 E8}

	condition:
		uint16( 0 ) == 0x5A4D and any of them
}
rule CAPE_Qakbot4 : FILE
{
	meta:
		description = "QakBot Config Extraction"
		author = "kevoreilly"
		id = "401184cf-bbd7-5afe-9589-470f54721af1"
		date = "2022-03-16"
		modified = "2024-02-16"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/QakBot.yar#L15-L29"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "ad75b07b9b786f634fd46cbe6dc089d3f732673320e70714e8ab058f0392c9f5"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$params+23,action0=setdump:eax::ecx,bp1=$c2list1+40,bp1=$c2list2+38,action1=dump,bp2=$conf+13,action2=dump,count=1,typestring=QakBot Config"
		packed = "f084d87078a1e4b0ee208539c53e4853a52b5698e98f0578d7c12948e3831a68"

	strings:
		$params = {8B 7D ?? 8B F1 57 89 55 ?? E8 [4] 8D 9E [2] 00 00 89 03 59 85 C0 75 08 6A FC 58 E9}
		$c2list1 = {59 59 8D 4D D8 89 45 E0 E8 [4] 8B 45 E0 85 C0 74 ?? 8B 90 [2] 00 00 51 8B 88 [2] 00 00 6A 00 E8}
		$c2list2 = {59 59 8B F8 8D 4D ?? 89 7D ?? E8 [4] 85 FF 74 52 8B 97 [2] 00 00 51 8B 8F [2] 00 00 53 E8}
		$conf = {5F 5E 5B C9 C3 51 6A 00 E8 [4] 59 59 85 C0 75 01 C3}

	condition:
		uint16( 0 ) == 0x5A4D and any of them
}
rule CAPE_Qakbotloader : FILE
{
	meta:
		description = "QakBot Export Selection"
		author = "kevoreilly"
		id = "b2d5ef1c-0651-5249-9c4b-7e83235d4a30"
		date = "2022-03-16"
		modified = "2024-02-16"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/QakBot.yar#L31-L46"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "6f99171c95a8ed5d056eeb9234dbbee123a6f95f481ad0e0a966abd2844f0e1a"
		logic_hash = "00869c0a9bf62cde3f46ca915b0ef689557b09dc58d6de34609e3998abfa7e98"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "export=$export1,export=$export2,export=$export3"

	strings:
		$export1 = {55 8B EC 83 EC 50 (3A|66 3B) ?? 74}
		$export2 = {55 8B EC 3A ?? 74 [8-16] 74 [6-16] EB}
		$export3 = {55 8B EC 66 3B ?? 74 [3-5] 74}
		$wind = {(66 3B|3A) ?? 74 [1-14] BB 69 04 00 00 53 E? [5-20] 74}
		$getteb = {EB 00 55 8B EC 66 3B E4 74 ?? [1-5] 64 A1 18 00 00 00 5D EB}

	condition:
		uint16( 0 ) == 0x5A4D and ( any of ( $export* ) ) and ( $wind or $getteb )
}
rule CAPE_Qakbotantivm
{
	meta:
		description = "QakBot AntiVM bypass"
		author = "kevoreilly"
		id = "7446522a-788a-512d-ad68-2fcc56169f5a"
		date = "2022-03-16"
		modified = "2024-02-16"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/QakBot.yar#L48-L59"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "e269497ce458b21c8427b3f6f6594a25d583490930af2d3395cb013b20d08ff7"
		logic_hash = "20f1cd28f38945a3aa328e77e78525fb1ffc47ecf54d5a40c2f18264c3973989"
		score = 75
		quality = 70
		tags = ""
		cape_options = "bp0=$antivm1,action0=unwind,count=1"

	strings:
		$antivm1 = {55 8B EC 3A E4 0F [2] 00 00 00 6A 04 58 3A E4 0F [2] 00 00 00 C7 44 01 [5] 81 44 01 [5] 66 3B FF 74 ?? 6A 04 58 66 3B ED 0F [2] 00 00 00 C7 44 01 [5] 81 6C 01 [5] EB}

	condition:
		all of them
}
rule CAPE_Bruteratelsyscall
{
	meta:
		description = "BruteRatel Syscall Bypass"
		author = "kevoreilly"
		id = "0ddc3e0a-c4ca-5342-b029-107ce1f2751e"
		date = "2024-07-11"
		modified = "2024-07-22"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/BruteRatel.yar#L1-L12"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "5ed054b3cd5d2659c250945d55d6adac90945963c34ad2af0f8d7436141e86b6"
		score = 75
		quality = 70
		tags = ""
		cape_options = "sysbp=$syscall1+6,sysbp=$syscall2+8"

	strings:
		$syscall1 = {49 89 CA 4? 89 ?? (41 FF|FF)}
		$syscall2 = {49 89 CA 48 8B 44 24 ?? FF 64 24}

	condition:
		all of them
}
rule CAPE_Bruteratelpacker
{
	meta:
		description = "BruteRatel Outer Encryption Layer"
		author = "kevoreilly"
		id = "631083be-7058-590a-a394-984545f42ad7"
		date = "2024-07-11"
		modified = "2024-07-22"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/BruteRatel.yar#L14-L26"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "2ccb17efe378d034df34d20d7580c58171d0fd11c18fef6c9a23f1ba238514e6"
		score = 75
		quality = 70
		tags = ""
		cape_options = "bp1=$outer*,action1=scan,count=0"

	strings:
		$outer = {83 45 F8 01 81 7D F8 FF 00 00 00 7E ?? 83 45 FC 01 8B 45 FC 3B 45 ?? 7E ?? 48}
		$inner = {88 E3 32 1C 0E 88 5C 15 00 48 8D 49 01 48 8D 52 01 38 C1 76 ?? 48 01 CE EB ?? FF}
		$date = {48 8B 17 48 85 D2 0F 85 [2] 00 00 8B 47 08 85 C0 0F 85 [2] 00 00}

	condition:
		($outer ) and not ( $inner ) and not ( $date )
}
rule CAPE_Bruterateldate
{
	meta:
		description = "BruteRatel Date Check Bypass"
		author = "kevoreilly"
		id = "94dd5cf3-ed59-51d6-92c8-aee73fe2926b"
		date = "2024-07-11"
		modified = "2024-07-22"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/BruteRatel.yar#L28-L39"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "88589b2d08aea03565668ff1b9af20b6fe11cda50d867c60db7cb4d1826b0fd7"
		score = 75
		quality = 70
		tags = ""
		cape_options = "clear,bp1=$inner*,action1=scan,bp2=$date+6,action2=skip,count=0"

	strings:
		$inner = {88 E3 32 1C 0E 88 5C 15 00 48 8D 49 01 48 8D 52 01 38 C1 76 ?? 48 01 CE EB ?? FF}
		$date = {48 8B 17 48 85 D2 0F 85 [2] 00 00 8B 47 08 85 C0 0F 85 [2] 00 00}

	condition:
		any of them
}
rule CAPE_Bruteratelconfig
{
	meta:
		description = "BruteRatel Config Extraction"
		author = "kevoreilly"
		id = "5ae680b0-5ad2-5e82-87f8-b0af4fec18de"
		date = "2024-07-11"
		modified = "2024-07-22"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/BruteRatel.yar#L41-L51"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "b1815aafec940ab6c8daafc68ccf294845221ada260de5209dcb7e49ccd061c7"
		score = 75
		quality = 70
		tags = ""
		cape_options = "clear,br1=$decode,count=0,action0=string:eax,typestring=BruteRatel Config"

	strings:
		$decode = {55 57 56 53 48 83 EC ?? 31 C0 48 89 CB 48 89 D7 44 89 C6 44 89 CD 44 39 01 77 ?? 41 8D 48 01 E8 [4] 31 C9}

	condition:
		all of them
}
rule CAPE_Emotetpacker : FILE
{
	meta:
		description = "Emotet bypass"
		author = "kevoreilly"
		id = "67b8e14c-5fa8-52af-bb9a-1663b084fbf0"
		date = "2022-03-31"
		modified = "2022-06-09"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/EmotetPacker.yar#L1-L13"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "5a95d1d87ce69881b58a0e3aafc1929861e2633cdd960021d7b23e2a36409e0d"
		logic_hash = "5f27d9d18884f7e0805f69960869b332c1577bf8be8ac103285e8bf98cda0ffd"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$trap1+31,action0=skip,bp1=$trap2+43,action1=jmp:186,count=1"

	strings:
		$trap1 = {8B 45 08 0F 28 0D [4] 0F 57 C0 0F 29 46 30 89 46 40 C7 46 44 00 00 00 00 0F 11 4E 48 E8}
		$trap2 = {F2 0F 10 15 [4] BE 01 00 00 00 0F 01 F9 C7 44 24 60 00 00 00 00 89 4C 24 60 0F 01 F9 C7 44 24 5C 00 00 00 00 89 4C 24 5C 0F 1F 84 00 00 00 00 00}

	condition:
		uint16( 0 ) == 0x5A4D and any of ( $trap* )
}
rule CAPE_Gettickcountantivm
{
	meta:
		description = "GetTickCountAntiVM bypass"
		author = "kevoreilly"
		id = "d90b9768-0525-5963-9817-e3a53b1d4cf3"
		date = "2021-12-14"
		modified = "2022-02-25"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/GetTickCountAntiVM.yar#L1-L20"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "662bc7839ed7ddd82d5fdafa29fafd9a9ec299c28820fe4104fbba9be1a09c42"
		hash = "00f1537b13933762e1146e41f3bac668123fac7eacd0aa1f7be0aa37a91ef3ce"
		hash = "549bca48d0bac94b6a1e6eb36647cd007fed5c0e75a0e4aa315ceabdafe46541"
		hash = "90c29a66209be554dfbd2740f6a54d12616da35d0e5e4af97eb2376b9d053457"
		logic_hash = "9cdb0b2d2e058e1858c2f2baad67005a2019fbbdcb7ca54571c8d20dfbf33471"
		score = 75
		quality = 70
		tags = ""
		cape_options = "bp0=$antivm1-13,bp0=$antivm5-40,bp0=$antivm6,action0=wret,hc0=1,bp1=$antivm2-6,action1=wret,hc1=1,count=1,bp2=$antivm3+42,action2=jmp:96,bp3=$antivm4-9,action3=wret,hc3=1"

	strings:
		$antivm1 = {57 FF D6 FF D6 BF 01 00 00 00 FF D6 F2 0F 10 0D [4] 47 66 0F 6E C7 F3 0F E6 C0 66 0F 2F C8 73}
		$antivm2 = {F2 0F 11 45 ?? FF 15 [4] 6A 00 68 10 27 00 00 52 50 E8 [4] 8B C8 E8 [4] F2 0F 59 45}
		$antivm3 = {0F 57 C0 E8 [4] 8B 35 [4] BF 01 00 00 00 FF D6 F2 0F 10 0D [4] 47 66 0F 6E C7 F3 0F E6 C0 66 0F 2F C8 73}
		$antivm4 = {F2 0F 11 45 EC FF 15 [4] 8B DA 8B C8 BA [4] 89 5D FC F7 E2 BF [4] 89 45 F4 8B F2 8B C1 B9}
		$antivm5 = {BB 01 00 00 00 8B FB 90 FF 15 [4] FF C7 66 0F 6E C7 F3 0F E6 C0 66 0F 2F F8 73 EA}
		$antivm6 = {48 81 EC 88 00 00 00 0F 57 C0 F2 0F 11 44 [2] F2 0F 10 05 [4] F2 0F 11 44 [2] F2 0F 10 05 [4] F2 0F 11}

	condition:
		any of them
}
rule CAPE_Zloader : FILE
{
	meta:
		description = "Zloader API Spam Bypass"
		author = "kevoreilly"
		id = "8a8e7102-1138-59e7-95a6-8647d41d8521"
		date = "2021-03-12"
		modified = "2024-05-03"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Zloader.yar#L1-L12"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "319adca805083c7f5854fe840447cf961addbd748f1f25eb8ec8cdeed7af38aa"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$trap1-5,action0=hooks:0,bp1=$traps-108,action1=jmp:15,bp2=$traps-88,action2=hooks:1,count=0"

	strings:
		$trap1 = {81 F7 4C 01 00 00 8D B4 37 [2] FF FF 31 FE 69 FE 95 03 00 00 E8 [4] 31 FE 0F AF FE 0F AF FE E8}
		$traps = {6A 44 53 E8 [2] FF FF 83 C4 08 8D 85 ?? FF FF FF C7 85 ?? FF FF FF 44 00 00 00 50}

	condition:
		uint16( 0 ) == 0x5A4D and any of them
}
rule CAPE_Zloader_2024 : FILE
{
	meta:
		description = "Zloader Registry and Modulename Bypass"
		author = "enzok"
		id = "7100c27e-021f-552c-9a75-84b07a2f837e"
		date = "2021-03-12"
		modified = "2024-05-03"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Zloader.yar#L14-L26"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "38d555ef5f613cf7ca043697c479100a7a22e7f043acf8b6a46f8009eb92fd7e"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$reg_1*+1,bp0=$reg_2*+1,action0=seteax:1,count=0"

	strings:
		$reg_1 = {FF D0 83 F8 00 0F 94 C0 24 01 88 44 24 ?? 4? 8B [3] B? [9-25] E8 [4] 4? 89 F1 FF D0 8A [3] 24 01 0F B6 C0}
		$reg_2 = {B9 [4] E8 [4] 8B [3] 89 C2 E8 [4] 4? [4] ff D0 8A [3] 24 01 0F B6 C0}
		$name_1 = {56 5? 5? 4? 81 EC [4] C7 44 24 ?? 00 00 00 00 4? 8D 0D [4] E8 [4] 4? 89 [3] 4? 83 [3] 00 75}

	condition:
		uint16( 0 ) == 0x5A4D and 2 of them
}
rule CAPE_Modiloader : FILE
{
	meta:
		description = "ModiLoader detonation shim"
		author = "kevoreilly"
		id = "64f9aa51-d668-5d40-9781-c26970acf781"
		date = "2023-10-19"
		modified = "2025-01-31"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/ModiLoader.yar#L1-L13"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "1f0cbf841a6bc18d632e0bc3c591266e77c99a7717a15fc4b84d3e936605761f"
		logic_hash = "9e64e0c40192cc832a1ffa7b3ac65a704596af82515d03706cd7aa1f4498f32f"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "exclude-apis=NtAllocateVirtualMemory:NtProtectVirtualMemory"

	strings:
		$epilog1 = {81 C2 A1 03 00 00 87 D1 29 D3 33 C0 5A 59 59 64 89 10 68}
		$epilog2 = {6A 00 6A 01 8B 45 ?? 50 FF 55 ?? 33 C0 5A 59 59 64 89 10 68}

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule CAPE_Loadersyscall
{
	meta:
		description = "Loader Syscall"
		author = "enzok"
		id = "45193b38-938e-55cf-9ea0-7bd48f0d77e4"
		date = "2024-10-29"
		modified = "2025-07-23"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/NitrogenLoader.yar#L1-L13"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "3c7ffd8b95032cffecff7fa7e5f5f561cce13e1109f6a9b30bc743642b495e45"
		score = 75
		quality = 70
		tags = ""
		cape_options = "sysbp=$syscall*-2,count=0"

	strings:
		$makehashes = {48 89 4C 24 ?? 48 89 54 24 ?? 4? 89 44 24 ?? 4? 89 4C 24 ?? 4? 83 EC ?? B? [4] E8 [3] 00}
		$number = {49 89 C3 B? [4] E8 [3] 00}
		$syscall = {48 83 C4 ?? 4? 8B 4C 24 ?? 4? 8B 54 24 ?? 4? 8B 44 24 ?? 4? 8B 4C 24 ?? 4? 89 CA 4? FF E3}

	condition:
		all of them
}
rule CAPE_Nitrogenloaderaes
{
	meta:
		description = "NitrogenLoader AES and IV"
		author = "enzok"
		id = "c79a00af-52f9-5f07-9c58-e8964e70986f"
		date = "2024-10-29"
		modified = "2025-07-23"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/NitrogenLoader.yar#L15-L27"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "de8ed0e98948cfadfd579e334fd9ce9f777ddbd988de897529ba71cb5eb2d396"
		score = 75
		quality = 70
		tags = ""
		cape_options = "bp0=$keyiv0+8,action0=dump:ecx::64,hc0=1,bp1=$keyiv0*-4,action1=dump:ecx::32,hc1=1,count=0"

	strings:
		$keyiv0 = {48 8B 8C 24 [4] E8 [3] 00 4? 89 84 24 [4] 4? 8B 84 24 [4] 4? 89 84 24 [4] 4? 8B 8C 24 [4] E8 [3] 00}
		$keyiv1 = {48 89 84 24 [4] 4? 8B 84 24 [4] 4? 8B 94 24 [4] 4? 8D 8C 24 [4] E8 [3] FF}
		$keyiv2 = {48 63 84 24 [4] 4? 8B C0 4? 8B 94 24 [4] 4? 8D 8C 24 [4] E8 [3] FF 4? 8B 84 24}

	condition:
		all of them
}
rule CAPE_Nitrogenloaderbypass
{
	meta:
		description = "Nitrogen Loader Exit Bypass"
		author = "enzok"
		id = "397b0b79-d569-5a71-bcac-ce0d64f706e6"
		date = "2024-10-29"
		modified = "2025-07-23"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/NitrogenLoader.yar#L29-L41"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "3a034d3ddd18723ea1f91814c8c2a2c47a749dfd1496a5d4777d8ff8bfab3457"
		score = 75
		quality = 70
		tags = ""
		cape_options = "bp2=$exit-2,action2=jmp,count=0"

	strings:
		$string1 = "LoadResource"
		$syscall = {48 83 C4 ?? 4? 8B 4C 24 ?? 4? 8B 54 24 ?? 4? 8B 44 24 ?? 4? 8B 4C 24 ?? 4? 89 CA 4? FF E3}
		$exit = {33 C9 E8 [4] E8 [4] 48 8D 84 24 [4] 48 89 44 24 ?? 4? B? E4 00 00 00 4? 8B 05 [4] B? 03 00 00 00 48 8D}

	condition:
		all of them
}
rule CAPE_Nitrogenloaderconfig
{
	meta:
		description = "NitrogenLoader Config Extraction"
		author = "enzok"
		id = "0c8d0655-0592-52b5-b51d-3acdb15a4864"
		date = "2024-10-29"
		modified = "2025-07-23"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/NitrogenLoader.yar#L43-L66"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "06d49ebf3f67476c83a77734dff0245a51027a35d92e5af07bb9146db5b156ca"
		score = 75
		quality = 70
		tags = ""
		cape_options = "bp0=$decrypt1*+1,bp1=$key*,hc0=1,count=0,action0=string:rcx,action1=string:rdx,typestring=NitrogenLoader Config"

	strings:
		$decrypt1 = {48 63 4? 24 ?? 33 D2 48 [0-3] F7 B4 24 [4] 48 8B C2 48 8B 8C 24 [4] 0F BE 04 01}
		$decrypt2 = {8B ?? 24 [1-4] 33 C8 8B C1 48 63 4C 24 ?? 48 8B 94 24 [4] 88 04 0A}
		$decrypt3 = {8B 8C 24 ?? ?? ?? ?? 2B C8 8B C1 48 63 4C 24 ?? 48 8B 94 24 [4] 88 04 0A}
		$key = {74 ?? E8 [4] 85 C0 75 ?? 4? 8B 0D [3] 00 4? 8D 15 [3] 00 E8}
		$taskman_1 = {E8 [4] B9 61 00 00 00 88 84 24 [4] E8 [4] B9 73 00 00 00 88 84 24 [4] E8 [4] B9 6B 00 00 00 88 84 24 [4] E8 [3] FF}
		$taskman_2 = {B9 4D 00 00 00 88 84 24 [4] E8 [4] B9 61 00 00 00 88 84 24 [4] E8 [4] B9 6E 00 00 00 88 84 24 [4] E8 [3] FF}
		$taskman_3 = {B9 61 00 00 00 88 84 24 [4] E8 [4] B9 67 00 00 00 88 84 24 [4] E8 [4] B9 65 00 00 00 88 84 24 [4] E8 [3] FF}
		$taskman_4 = {B9 72 00 00 00 88 84 24 [4] E8 [4] 31 C9 88 84 24 [4] E8 [3] FF}
		$installers_1 = {B9 49 00 00 00 E8 [4] B9 6E 00 00 00 88 84 24 [4] E8 [4] B9 73 00 00 00 88 84 24 [4] E8 [3] FF}
		$installers_2 = {B9 74 00 00 00 88 84 24 [4] E8 [4] B9 61 00 00 00 88 84 24 [4] E8 [4] B9 6C 00 00 00 88 84 24 [4] E8 [3] FF}
		$installers_3 = {B9 6C 00 00 00 88 84 24 [4] E8 [4] B9 65 00 00 00 88 84 24 [4] E8 [3] FF}
		$installers_4 = {B9 72 00 00 00 88 84 24 [4] E8 [4] B9 73 00 00 00 88 84 24 [4] E8 [3] FF}
		$rc4decrypt_1 = {48 89 ?? 4? 89 ?? E8 [4] 4? 8B ?? 24 [1-4] 4? 89 ?? 4? 89 ?? 4? 89 C1 [0-1] 89 ?? E8 [4] 4? 89}
		$rc4decrypt_2 = {E8 [4] 8B ?? 24 [1-4] 4? 89 ?? 48 89 ?? 4? 89 C1 E8 [3] FF}

	condition:
		any of ( $decrypt* ) or ( $key and ( 3 of ( $taskman_* ) or 3 of ( $installers* ) and 1 of ( $rc4decrypt_* ) ) )
}
rule CAPE_Xworm
{
	meta:
		description = "XWorm Config Extractor"
		author = "kevoreilly"
		id = "0f55dbfb-c239-53f2-a1e0-bfa494558d6e"
		date = "2023-11-07"
		modified = "2023-11-07"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/XWorm.yar#L1-L11"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "d8e103f3470e83d71cd4992b74698c0721b8a69d764fdb7a4543997b2853014a"
		score = 75
		quality = 70
		tags = ""
		cape_options = "bp0=$decrypt+11,action0=string:r10,count=1,typestring=XWorm Config"

	strings:
		$decrypt = {45 33 C0 39 09 FF 15 [4] 48 8B F0 E8 [4] 48 8B C8 48 8B D6 48 8B 00 48 8B 40 68 FF 50 ?? 90}

	condition:
		any of them
}
rule CAPE_Dridexloader : FILE
{
	meta:
		description = "DridexLoader API Spam Bypass"
		author = "kevoreilly"
		id = "a8b62f64-87a0-58d3-8876-9b0f6a7deb97"
		date = "2021-03-09"
		modified = "2021-03-09"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/DridexLoader.yar#L1-L11"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "00a3e4e80a2558ee52035f091e2339fa2dad6f6515b9dc099f2f3800e4c70bce"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$trap-13,action0=ret,count=0"

	strings:
		$trap = {6A 50 6A 14 6A 03 5A 8D 4C 24 ?? E8 [4] 68 [4] 68 [4] E8 [4] 85 C0 74 05}

	condition:
		uint16( 0 ) == 0x5A4D and $trap
}
rule CAPE_Buerloader : FILE
{
	meta:
		description = "BuerLoader RDTSC Trap Bypass"
		author = "kevoreilly"
		id = "38f01199-6bd2-5519-b570-8c0f46e74286"
		date = "2021-03-13"
		modified = "2021-03-13"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/BuerLoader.yar#L1-L11"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "6f9f9b4c01251c0643c61701084cca2bdfeea08ca95f982355565cf05483d940"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$trap+43,action0=skip,count=0"

	strings:
		$trap = {0F 31 89 45 ?? 6A 00 8D 45 ?? 8B CB 50 E8 [4] 0F 31}

	condition:
		uint16( 0 ) == 0x5A4D and any of them
}
rule CAPE_Rhadamanthys
{
	meta:
		description = "No description has been set in the source file - CAPE"
		author = "kevoreilly"
		id = "d9d387e1-76b3-55f6-a40f-a8c9cb9e9bea"
		date = "2023-01-25"
		modified = "2025-11-11"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Rhadamanthys.yar#L1-L13"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "3c8fbfe14f81e099fc900023d9c856e3f45b99af38889ed952b2ac67a636f51d"
		score = 75
		quality = 70
		tags = ""
		cape_options = "bp0=$conf-11,hc0=1,action0=setdump:edx::ebx,bp1=$conf+64,hc1=1,action1=dump,count=0,typestring=Rhadamanthys Config,ntdll-protect=0"
		packed = "9e28586ab70b1abdccfe087d81e326a0703f75e9551ced187d37c51130ad02f5"

	strings:
		$rc4 = {88 4C 01 08 41 81 F9 00 01 00 00 7C F3 89 75 08 33 FF 8B 4D 08 3B 4D 10 72 04 83 65 08 00}
		$code = {8B 4D FC 3B CF 8B C1 74 0D 83 78 04 02 74 1C 8B 40 1C 3B C7 75 F3 3B CF 8B C1 74 57 83 78 04 17 74 09 8B 40 1C 3B C7 75 F3 EB}
		$conf = {46 BB FF 00 00 00 23 F3 0F B6 44 31 08 03 F8 23 FB 0F B6 5C 39 08 88 5C 31 08 88 44 39 08 02 C3 8B 5D 08 0F B6 C0 8A 44 08 08}

	condition:
		2 of them
}
rule CAPE_Rhadaanti
{
	meta:
		description = "No description has been set in the source file - CAPE"
		author = "kevoreilly"
		id = "25c31ccc-63e7-56f0-a62f-e64d992c34b5"
		date = "2023-01-25"
		modified = "2025-11-11"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Rhadamanthys.yar#L15-L24"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "b54fd25e3297d358f2a8ec3a868bb4d233ee32d6942f21a53c3d25d35164530b"
		score = 75
		quality = 70
		tags = ""
		cape_options = "bp0=$anti,action0=jmp,count=0,ntdll-protect=0,dump-limit=0"

	strings:
		$anti = {74 0E FF 75 ?? 8D 45 ?? 50 E8 [4] 59 59 8D 45 ?? 50 56 68 04 01 00 00}

	condition:
		all of them
}
rule CAPE_Rhadunhook
{
	meta:
		description = "No description has been set in the source file - CAPE"
		author = "Kevin O'Reilly"
		id = "7bbeeb3a-9437-50d8-89e6-306a07886a17"
		date = "2023-01-25"
		modified = "2025-11-11"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Rhadamanthys.yar#L26-L36"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "f2da2f1ee6b0a3b9fe58b2c35ccf0a0f6dee44228ec92659370d30defdef7ea3"
		score = 75
		quality = 70
		tags = ""
		cape_options = "bp0=$scan*,action0=scan:rbx,count=0,patch=$target+21:9090"
		packed = "dd4af0f1888977f6d9eb820b19f4afc2a73d1c494a132ab4261498328005dda7"

	strings:
		$scan = {48 85 DB 0F 84 E1 00 00 00 4C 8D 44 24 70 48 8D 54 24 40 48 8B CE 44 89 7C 24 50 4C 89 64 24 40 48 C7 44 24 48 00 00 00 00 C6 44 24 54 00 FF}
		$target = {4D 85 C9 48 8B C6 4A 8D 0C 1E 74 15 48 2B D8 49 2B DB 8A 04 0B 88 01 48 83 C1 01 49 83 E9 01 75 F1 5F 5E 5D 5B C3}

	condition:
		any of them
}
rule CAPE_Aurastealerbypass
{
	meta:
		description = "Bypass AuraStealer"
		author = "enzok"
		id = "e510f46b-de7c-50d1-bff3-97c3acf0452e"
		date = "2025-09-02"
		modified = "2025-09-02"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/AuraStealer.yar#L1-L14"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "ae174c96c262b1734c58bd6c5f7112221b08596c180612e4970acada35dbd070"
		score = 75
		quality = 70
		tags = ""
		cape_options = "bp0=$antivm1+3,action0=skip,count=0"
		packed = "a9c47f10d5eb77d7d6b356be00b4814a7c1e5bb75739b464beb6ea03fc36cc85"

	strings:
		$antivm1 = {39 04 11 0f 94 C3 8B 44 ?? ?? 85 C0}
		$conf = {8D BE ?? 00 00 00 68 00 40 00 00 5? 5? FF D1 83 C4 ?? 8B 07 8B 57 04 29 C2}
		$keyexpansion = {31 C0 8A 1C 82 88 1C 81 8A 5C 82 01 88 5C 81 01 8A 5C 82 02 88 5C 81 02 8A 5C 82 03 88 5C 81 03 4? 83 F8 08 75 ?? B? 08 00 00 00}

	condition:
		all of them
}
rule CAPE_Stealcanti : FILE
{
	meta:
		description = "Stealc detonation bypass"
		author = "kevoreilly"
		id = "32e5c1cf-ef57-58eb-9deb-fab0064cc676"
		date = "2023-02-22"
		modified = "2025-09-01"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Stealc.yar#L1-L13"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "77d6f1914af6caf909fa2a246fcec05f500f79dd56e5d0d466d55924695c702d"
		logic_hash = "4132e8094b0b49a89e9f40a8b1a6abbf105bbb04e4ddf3ce739e39fc2baf0d13"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$anti+17,action0=skip,count=1"

	strings:
		$anti = {53 57 57 57 FF 15 [4] 8B F0 74 03 75 01 B8 E8 [4] 74 03 75 01 B8}
		$decode = {6A 03 33 D2 8B F8 59 F7 F1 8B C7 85 D2 74 04 2B C2 03 C1 6A 06 C1 E0 03 33 D2 59 F7 F1}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CAPE_Stealcstrings : FILE
{
	meta:
		description = "Stealc string decryption"
		author = "kevoreilly"
		id = "087b5532-e1e7-5df9-adb2-bf758c8ba352"
		date = "2023-02-22"
		modified = "2025-09-01"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Stealc.yar#L15-L26"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "6d402446a979c00b6257ace9924db381d98c530b22968bd2776c66d58c7faefc"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$decode+17,action0=string:edx,count=0,typestring=Stealc Strings"
		packed = "d0c824e886f14b8c411940a07dc133012b9eed74901b156233ac4cac23378add"

	strings:
		$decode = {51 8B 15 [4] 52 8B 45 ?? 50 E8 [4] 83 C4 0C 6A 04 6A 00 8D 4D ?? 51 FF 15 [4] 83 C4 0C 8B 45 ?? 8B E5 5D C3}

	condition:
		uint16( 0 ) == 0x5A4D and any of them
}
rule CAPE_Stealcv2Strings : FILE
{
	meta:
		description = "StealcV2 string decryption"
		author = "kevoreilly"
		id = "d99fcc9c-35cc-5494-a0cd-738f3ae8d367"
		date = "2023-02-22"
		modified = "2025-09-01"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Stealc.yar#L28-L43"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "923f70edb3ad70957576994008729bf7a087479eed1973c42161aa96fa694baa"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$decode32*,action0=string:[esp],bp1=$decode64,action1=string:eax,bp2=$dump,action2=dumpstrings,count=0,typestring=Stealc Strings"
		packed = "2f42dcf05dd87e6352491ff9d4ea3dc3f854df53d548a8da0c323be42df797b6"
		packed = "8301936f439f43579cffe98e11e3224051e2fb890ffe9df680bbbd8db0729387"

	strings:
		$decode32 = {AB AB AB AB 8B 45 0C 89 4E 10 89 4E 14 39 45 08 75 0B C7 46 14 0F 00 00 00 88 0E EB 0F 2B 45 08 50 51 FF 75 ?? 8B}
		$decode64 = {40 53 48 83 EC 20 48 8B 19 48 85 DB 74 ?? 48 8B 53 18 48 83 FA 0F 76 2C 48 8B 0B 48 FF C2 48 81 FA 00 10 00 00 72}
		$dump32 = {33 C0 89 46 30 88 46 34 89 46 38 89 46 3C 89 46 40 89 46 44 89 46 48 89 46 4C 89 46 50 89 46 54 89 46 58 8B C6 5F 5E C3}
		$dump64 = {48 8B C7 89 6F 40 40 88 6F 44 48 89 6F 48 48 89 6F 50 48 89 6F 58 48 89 6F 60 48 89 6F 68 48 89 6F 70 48 89 6F 78 48 89}

	condition:
		uint16( 0 ) == 0x5A4D and 2 of them
}
rule CAPE_Stealcv2Datecheck : FILE
{
	meta:
		description = "StealcV2 date check bypass"
		author = "kevoreilly"
		id = "4969d005-3532-5b75-9fa9-10e09bab338e"
		date = "2023-02-22"
		modified = "2025-09-01"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Stealc.yar#L45-L56"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "f074aceb7c111156752891acac8690c00dad7c26240fb0752cc12a9a65aa3d30"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "patch=$date32*-1:B000,patch=$date64*-2:B00090"

	strings:
		$date32 = {F3 A5 8D 45 ?? 50 E8 [4] 59 8B F8 8B F2 8D 45 ?? 50 E8 [4] 59 3B F2 7C 08 7F 04 3B F8 76 02 B3 01 8A C3}
		$date64 = {0F 11 44 [2] 0F 11 8C [2] 00 00 00 89 8C [2] 00 00 00 48 8D 4C [2] E8 [4] 48 8B D8 48 8D 4C [2] E8 [4] 48 3B D8 0F 9F C0}

	condition:
		uint16( 0 ) == 0x5A4D and any of them
}
rule CAPE_Singlestepantihook
{
	meta:
		description = "Single-step anti-hook Bypass"
		author = "kevoreilly"
		id = "f7aca40b-d231-543b-81f3-5f4524abab78"
		date = "2021-08-26"
		modified = "2021-08-26"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/SingleStepAntiHook.yar#L1-L11"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "fc9f36b0ecc13192fe8b6caaff256ac52c1f14480223d629a38ba84e90dd0809"
		score = 75
		quality = 70
		tags = ""
		cape_options = "bp0=$antihook+6,action0=skip,count=0"

	strings:
		$antihook = {FF D? 83 EC 08 9C 81 0C 24 00 01 00 00 9D}

	condition:
		any of them
}
rule CAPE_Socks5Systemz : FILE
{
	meta:
		description = "Socks5Systemz config extraction"
		author = "kevoreilly"
		id = "ef14953a-2b48-54f4-8d15-c07c7459103e"
		date = "2024-05-22"
		modified = "2025-05-23"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Socks5Systemz.yar#L1-L19"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "7e324bacd1ea57585435b6a5a4c93bda63ca146c100f2361a1c5530b87668299"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "br0=user32::wsprintfA,br1=ntdll::sprintf,action2=string:[esp],action3=string:[esp],count=0,typestring=Socks5Systemz Config"
		packed = "9b997d0de3fe83091726919a0dc653e22f8f8b20b1bb7d0b8485652e88396f29"

	strings:
		$chunk1 = {0F B6 84 8A [4] E9 [3] (00|FF)}
		$chunk2 = {0F B6 04 8D [4] E9 [3] (00|FF)}
		$chunk3 = {66 0F 6F 05 [4] E9 [3] (00|FF)}
		$chunk4 = {F0 0F B1 95 [4] E9 [3] (00|FF)}
		$chunk5 = {83 FA 04 E9 [3] (00|FF)}
		$chunk6 = {8A 04 8D [4] E9 [3] (00|FF)}
		$chunk7 = {83 C4 04 83 C4 04 E9}
		$chunk8 = {83 C2 04 87 14 24 5C E9}

	condition:
		uint16( 0 ) == 0x5A4D and 5 of them
}
rule CAPE_Darkgate
{
	meta:
		description = "DarkGate config"
		author = "enzok"
		id = "ce81f452-4096-51d6-97cc-624f9fbefa86"
		date = "2024-02-26"
		modified = "2024-02-26"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/DarkGate.yar#L1-L17"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "c1d35921f4fc3bac681a3d5148f517dc0ec90ab8c51e267c8c6cd5b1ca3dc085"
		logic_hash = "25c0e77a83676c6a18445f8df0b1f7a9148de5f64eeb532f9a4f4d4652dd8191"
		score = 75
		quality = 70
		tags = ""
		cape_options = "bp0=$config2+3,action0=dump:edx::1025,count=0,typestring=DarkGate Config"

	strings:
		$part1 = {8B 55 ?? 8A 4D ?? 80 E1 3F C1 E1 02 8A 5D ?? 80 E3 30 81 E3 FF [3] C1 EB 04 02 CB 88 4C 10 FF FF 45 ?? 80 7D ?? 40}
		$part2 = {8B 55 ?? 8A 4D ?? 80 E1 0F C1 E1 04 8A 5D ?? 80 E3 3C 81 E3 FF [3] C1 EB 02 02 CB 88 4C 10 FF FF 45 ?? 80 7D ?? 40}
		$part3 = {8B 55 ?? 8A 4D ?? 80 E1 03 C1 E1 06 8A 5D ?? 80 E3 3F 02 CB 88 4C 10 FF FF 45}
		$alphabet = "zLAxuU0kQKf3sWE7ePRO2imyg9GSpVoYC6rhlX48ZHnvjJDBNFtMd1I5acwbqT+="
		$config1 = {B9 01 04 00 00 E8 [4] 8D 45}
		$config2 = {8B 55 ?? 8D 45 ?? E8 [4] 8D 45 ?? 5? B? 06 00 00 00 B? 01 00 00 00 8B 45 ?? E8 [4] 8B 45 ?? B? [4] E8 [4] 75}

	condition:
		($alphabet ) and ( any of ( $part* ) or all of ( $config* ) )
}
rule CAPE_Anticuckoo : FILE
{
	meta:
		description = "AntiCuckoo bypass: https://github.com/therealdreg/anticuckoo"
		author = "kevoreilly"
		id = "e221e57b-313e-5998-a3fc-5b4e9671b989"
		date = "2023-03-17"
		modified = "2023-03-17"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/AntiCuckoo.yar#L1-L12"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "ad5e52f144bb4a1dae3090978c6ecb4c7732538c9b62a6cedd32eccee6094be5"
		logic_hash = "a039aeca2dae44980e8bffafacfda90975e107001be50f11ac916b35ad43592e"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$HKActivOldStackCrash+36,action0=jmp,count=1"

	strings:
		$HKActivOldStackCrash = {5B 81 FB FA FA FA FA 74 01 41 3B E0 75 ?? 83 E9 0B 83 F9 04 7F 04 C6 45 ?? 00 89 4D ?? 89 65 ?? 80 7D ?? 00 74}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CAPE_Bumblebee : FILE
{
	meta:
		description = "BumbleBee Anti-VM Bypass"
		author = "enzo & kevoreilly"
		id = "85e2c9fd-86de-57c8-99ec-de2cc3996876"
		date = "2022-04-21"
		modified = "2023-02-08"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/BumbleBee.yar#L34-L46"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "0a632a0b30b28d544880eb1cfdd85e95f455c343d60f8d6922d4196ef7415961"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$antivm1+2,bp1=$antivm2+2,bp1=$antivm3+38,action0=jmp,action1=skip,count=0,force-sleepskip=1"

	strings:
		$antivm1 = {84 C0 74 09 33 C9 FF [4] 00 CC 33 C9 E8 [3] 00 4? 8B C8 E8}
		$antivm2 = {84 C0 0F 85 [2] 00 00 33 C9 E8 [4] 48 8B C8 E8 [4] 48 8D 85}
		$antivm3 = {33 C9 E8 [4] 48 8B C8 E8 [4] 83 CA FF 48 8B 0D [4] FF 15 [4] E8 [4] 84 c0}

	condition:
		uint16( 0 ) == 0x5A4D and any of them
}
rule CAPE_Privateloader
{
	meta:
		description = "PrivateLoader indirect syscall capture"
		author = "kevoreilly"
		id = "3a0b16da-ec84-5761-bcf2-106362c5667d"
		date = "2024-10-04"
		modified = "2024-10-04"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/PrivateLoader.yar#L1-L12"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "204a86bb3743f19fed0fe55ff5ccd716661f7f315b5966a29e434ccb3e160526"
		score = 75
		quality = 70
		tags = ""
		cape_options = "clear,sysbp=$syscall*-2"
		packed = "075d0dafd7b794fbabaf53d38895cfd7cffed4a3fe093b0fc7853f3b3ce642a4"

	strings:
		$syscall = {48 31 C0 4C 8B 19 8B 41 10 48 8B 49 08 49 89 CA 41 FF E3}

	condition:
		any of them
}
rule CAPE_Pikahook : FILE
{
	meta:
		description = "Pikabot anti-hook bypass"
		author = "kevoreilly"
		id = "e1b7a807-135f-52d7-bc36-c0419e82b424"
		date = "2024-03-07"
		modified = "2024-03-12"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Pikabot.yar#L1-L14"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "2a50a5f2d905122a5b7ac8ca3666b47caa24d325e246841129e53807daf2a1dd"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "clear,sysbp=$indirect+40,sysbpmode=1,force-sleepskip=1"
		packed = "89dc50024836f9ad406504a3b7445d284e97ec5dafdd8f2741f496cac84ccda9"

	strings:
		$indirect = {31 C0 64 8B 0D C0 00 00 00 85 C9 74 01 40 50 8D 54 24 ?? E8 [4] A3 [4] 8B 25 [4] A1 [4] FF 15}
		$sysenter1 = {89 44 24 08 8D 85 20 FC FF FF C7 44 24 04 FF FF 1F 00 89 04 24 E8}
		$sysenter2 = {C7 44 24 0C 00 00 00 02 C7 44 24 08 00 00 00 02 8B 45 0C 89 44 24 04 8B 45 08 89 04 24 E8}

	condition:
		uint16( 0 ) == 0x5A4D and 2 of them
}
rule CAPE_Pikexport : FILE
{
	meta:
		description = "Pikabot export selection"
		author = "kevoreilly"
		id = "7d2432f2-90ae-5ad0-b579-5789a1c14a08"
		date = "2024-03-07"
		modified = "2024-03-12"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Pikabot.yar#L16-L28"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "238dcc5611ed9066b63d2d0109c9b623f54f8d7b61d5f9de59694cfc60a4e646"
		logic_hash = "33f58703a0e40c2361343dbdcc17111aafbf5cc912393edda79005c6ec566f42"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "export=$export"

	strings:
		$export = {55 8B EC 83 EC ?? C6 45 [2] C6 45 [2] C6 45 [2] C6 45 [2] C6 45}
		$pe = {B8 08 00 00 00 6B C8 00 8B 55 ?? 8B 45 ?? 03 44 0A 78 89 45 ?? 8B 4D ?? 8B 51 18 89 55 E8 C7 45 F8 00 00 00 00}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CAPE_Heavenssyscall : FILE
{
	meta:
		description = "Bypass variants of heaven's gate direct syscalls"
		author = "kevoreilly"
		id = "7c60102a-ac8b-5e28-8dbb-4b6c3f4cddff"
		date = "2024-03-25"
		modified = "2024-03-25"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/HeavensSyscall.yar#L1-L13"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "aeb981fcba0936ff8b1be4c601445fd45e5d3b74856a9439d351edd57f5a50c3"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "clear,br0=$gate1-9,action1=seteax:0,count=0,sysbp=$sysenter+10"
		packed = "2950b4131886e06bdb83ab1611b71273df23b0d31a4d8eb6baddd33327d87ffa"

	strings:
		$gate1 = {00 00 00 00 74 24 8D 45 F8 50 6A FF FF 95 [4] 85 C0 74 08 8B 4D F8 89 4D FC EB 07 C7 45 FC 00 00 00 00 8B 45 FC EB 02 33 C0 8B E5 5D C2 C0}
		$sysenter = {68 [4] E8 [4] E8 [4] C2 ?? 00 CC CC CC CC CC CC CC CC}

	condition:
		uint16( 0 ) == 0x8B55 and all of them
}
rule CAPE_Lumma : FILE
{
	meta:
		description = "Lumma config extraction"
		author = "kevoreilly"
		id = "b2166620-3070-5727-b189-e6959cc5b698"
		date = "2024-01-05"
		modified = "2024-05-09"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Lumma.yar#L1-L14"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "a8f9212b619796f91f14c4164e4d2f30c66b51118f22f3d6c310841b6707b7b0"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$decode+5,action0=string:ebp,count=0,bp1=$patch+8,action1=skip,typestring=Lumma Config"
		packed = "0ee580f0127b821f4f1e7c032cf76475df9724a9fade2e153a69849f652045f8"

	strings:
		$c2 = {8D 44 24 ?? 50 89 4C 24 ?? FF 31 E8 [4] 83 C4 08 B8 FF FF FF FF}
		$decode = {C6 44 05 00 00 83 C4 2C 5E 5F 5B 5D C3}
		$patch = {66 C7 0? 00 00 8B 46 1? C6 00 01 8B}

	condition:
		uint16( 0 ) == 0x5a4d and 2 of them
}
rule CAPE_Lummaremap
{
	meta:
		description = "Lumma ntdll-remap bypass"
		author = "kevoreilly"
		id = "93ae37d1-a38a-5f96-8bb3-cc648a49b588"
		date = "2024-01-05"
		modified = "2024-05-09"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Lumma.yar#L16-L27"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "51093379fbd041f75bdfe161bc9dfcc7d782c23ce16d625ca558bb58d8d57713"
		score = 75
		quality = 70
		tags = ""
		cape_options = "ntdll-remap=0"
		packed = "7972cbf2c143cea3f90f4d8a9ed3d39ac13980adfdcf8ff766b574e2bbcef1b4"

	strings:
		$remap = {C6 44 24 20 00 C7 44 24 1C C2 00 00 90 C7 44 24 18 00 00 FF D2 C7 44 24 14 00 BA 00 00 C7 44 24 10 B8 00 00 00 8B ?? 89 44 24 11}

	condition:
		any of them
}
rule CAPE_Ursnifv3
{
	meta:
		description = "Ursnif Config Extraction"
		author = "kevoreilly"
		id = "4170b638-e51b-59c6-956a-50ff82f629ba"
		date = "2021-06-17"
		modified = "2023-03-23"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/UrsnifV3.yar#L1-L16"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "d679546e37ee58087fce75920b2ce4e6d2b9ae55fb1ef80d14ec14309396757c"
		score = 75
		quality = 70
		tags = ""
		cape_options = "br0=$crypto32_1-48,action1=dump:ebx::eax,bp2=$crypto32_3+50,action2=dump:ebx::eax,bp3=$crypto32_4+11,action3=dump:eax::ecx,typestring=UrsnifV3 Config,count=1"
		packed = "75827be0c600f93d0d23d4b8239f56eb8c7dc4ab6064ad0b79e6695157816988"
		packed = "5d6f1484f6571282790d64821429eeeadee71ba6b6d566088f58370634d2c579"

	strings:
		$crypto32_1 = {8B C3 83 EB 01 85 C0 75 0D 0F B6 16 83 C6 01 89 74 24 14 8D 58 07 8B C2 C1 E8 07 83 E0 01 03 D2 85 C0 0F 84 AB 01 00 00 8B C3 83 EB 01 85 C0 89 5C 24 20 75 13 0F B6 16 83 C6 01 BB 07 00 00 00}
		$crypto32_3 = {F6 46 03 02 75 5? 8B 46 10 40 50 E8 [4] 8B D8 89 5C 24 1C 85 DB 74 41 F6 46 03 01 74 53 8B 46 10 89 44 24 1C 8B 46 0C 53 03 C7 E8 [4] 59}
		$crypto32_4 = {C7 44 24 10 01 00 00 00 8B 4E 10 C6 04 08 00 8B 4D ?? 89 01 8B 46 ?? 8B 4D ?? 89 01 8B 44 24 10 5F 5E 5B 8B E5 5D C2 0C 00}
		$cpuid = {8B C4 FF 18 8B F0 33 C0 0F A2 66 8C D8 66 8E D0 8B E5 8B C6 5E 5B 5D C3}

	condition:
		any of ( $crypto32* ) and $cpuid
}
rule CAPE_Blister : FILE
{
	meta:
		description = "Blister Sleep Bypass"
		author = "kevoreilly"
		id = "34657bab-f100-5ea8-9111-da2806f46b79"
		date = "2022-05-10"
		modified = "2024-05-09"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/Blister.yar#L1-L17"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "aba379b93c85241cf250829832b2c8a5eaafb3abd0ff955dbaf0d06489c00deb"
		score = 75
		quality = 70
		tags = "FILE"
		cape_options = "bp0=$sleep1+6,bp1=$sleep2+7,action0=setsignflag,action1=clearcarryflag,count=3"
		packed = "0a7778cf6f9a1bd894e89f282f2e40f9d6c9cd4b72be97328e681fe32a1b1a00"
		packed = "afb77617a4ca637614c429440c78da438e190dd1ca24dc78483aa731d80832c2"

	strings:
		$sleep1 = {FF FF 83 7D F0 00 (E9|0F 8?)}
		$sleep2 = {81 7D D8 90 B2 08 00 (E9|0F 8?)}
		$protect = {50 6A 20 8D 45 ?? 50 8D 45 ?? 50 6A FF FF D7}
		$lock = {56 33 F6 B9 FF FF FF 7F 89 75 FC 8B C1 F0 FF 45 FC 83 E8 01 75 F7}
		$comp = {6A 04 59 A1 [4] 8B 78 04 8B 75 08 33 C0 F3 A7 75 0B 8B 45 0C 83 20 00 33 C0 40 EB 02 33 C0}

	condition:
		uint16( 0 ) == 0x5A4D and 2 of ( $protect , $lock , $comp ) and all of ( $sleep* )
}
rule CAPE_Darkgateloader
{
	meta:
		description = "DarkGate Loader"
		author = "enzok"
		id = "feb90ae6-ec01-59da-a3df-217df2133588"
		date = "2023-08-09"
		modified = "2025-04-07"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/DarkGateLoader.yar#L1-L15"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "00692123615d2f7eaf8aea07754fc9439cf58e1fb8eb4f44f0428b362f27e794"
		score = 75
		quality = 70
		tags = ""
		cape_options = "bp0=$decrypt1+30,bp0=$decrypt2+29,action0=dump:eax::ebx,bp1=$decrypt3+80,action1=dumpsize:eax,bp2=$decrypt3+124,hc2=1,action2=dump:eax,count=0"
		packed = "b15e4b4fcd9f0d23d902d91af9cc4e01417c426e55f6e0b4ad7256f72ac0231a"

	strings:
		$loader = "loader"
		$decrypt1 = {B? 01 00 00 00 8B [3] E8 [4] 8B D7 32 54 [4] 88 54 18 FF 4? 4? 75}
		$decrypt2 = {B? 01 00 00 00 8B [2] E8 [4] 8B D7 2B D3 [4] 88 54 18 FF 4? 4? 75}
		$decrypt3 = {89 85 [4] 8B 85 [4] 8B F0 8D BD [4] B? 10 [3] F3 A5 8B 85 [4] 33 D2 [2] 8B 85 [4] 99}

	condition:
		$loader and any of ( $decrypt* )
}
rule CAPE_Vbcrypter
{
	meta:
		description = "VBCrypter anti-hook Bypass"
		author = "kevoreilly"
		id = "2e010dfd-5096-5e81-af9b-174322a47d87"
		date = "2021-03-28"
		modified = "2021-03-28"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/analyzer/windows/data/yara/VBCrypter.yar#L1-L11"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "a62bca62ab624ab1a2c2e612c5b7e6d543006026a49c07c46800499e31e41c4e"
		score = 75
		quality = 70
		tags = ""
		cape_options = "bp0=$antihook-12,action0=jmp,count=0"

	strings:
		$antihook = {43 39 C3 0F 84 ?? 00 00 00 80 3B B8 75 ?? 83 7B 01 00 75 ?? 80 7B 05 BA 75 ?? 8B 53 06 83 C3 0A 31 C9}

	condition:
		any of them
}
rule CAPE_Nemty : FILE
{
	meta:
		description = "Nemty Ransomware Payload"
		author = "kevoreilly"
		id = "3aa8e1d7-f9cb-5b04-923d-7bed15ab8c3f"
		date = "2020-04-03"
		modified = "2020-04-03"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Nemty.yar#L1-L13"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "a05974b561c67b4f1e0812639b74831edcf65686a06c0d380f0b45739e342419"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "Nemty Payload"

	strings:
		$tordir = "TorDir"
		$decrypt = "DECRYPT.txt"
		$nemty = "NEMTY"

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CAPE_Stxrat : FILE
{
	meta:
		description = "No description has been set in the source file - CAPE"
		author = "YungBinary"
		id = "9ce51412-52ce-5682-802d-fad96c053c30"
		date = "2026-04-11"
		modified = "2026-04-14"
		reference = "https://www.esentire.com/blog/stx-rat-a-new-rat-in-2026-with-infostealer-capabilities"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/STXRat.yar#L49-L120"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "f82b832e6bf936ff936332c059b1d3b981ce387bf82964ecf64a9cb12cda955d"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "STXRat Payload"

	strings:
		$s1 = {
            8D 51 BF
            83 FA 19
            8D 41 20
            0F 47 C1
            C2 
        }
		$s2 = {
            48 8D 05 ?? ?? ?? ??
            66 C7 45 ?? 48 B8 [0-6]
            48 89 45 ??
            48 8D 55 ??
            66 C7 45 ?? FF E0
        }
		$s3 = {
            65 48 8B 04 25 60 00 00 00
            80 78 02 01
        }
		$s4 = "Microsoft Enhanced RSA and AES Cryptographic Provider (Prototype)" ascii
		$s5 = {
            B9 10 66 00 00 [0-3]
            0F 44 C1
            B9 0F 66 00 00
            41 81 ?? C0 00 00 00
            0F 44 C1
            B9 0E 66 00 00
        }
		$s6 = {
            48 83 FB 5A
            73 ??
            88 84 1C ?? ?? ?? ??
            48 FF C3
            48 FF C1
            8A 01
            84 C0
            75
        }
		$s7 = {
            83 61 18 00
            83 61 14 00
            C7 01 01 23 45 67
            C7 41 04 89 AB CD EF
            C7 41 08 FE DC BA 98
            C7 41 0C 76 54 32 10
            C7 41 10 F0 E1 D2 C3
            C3
        }
		$s8 = {
            80 61 1F 3F
            80 49 1F 40
            80 21 F8
        }

	condition:
		uint16( 0 ) == 0x5a4d and ( 4 of ( $s* ) )
}
rule CAPE_Worldwind : FILE
{
	meta:
		description = "Detects WorldWind infostealer"
		author = "ditekSHen"
		id = "226f591a-dc06-54f5-96ae-d142f624ff71"
		date = "2024-10-09"
		modified = "2026-11-16"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/AsyncRAT.yar#L60-L82"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "9bb04fad460193cd877ea7f2de9337f69aadda01aee6c79f0a23cdf564b1e6c8"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "WorldWind Payload"

	strings:
		$c1 = /WorldWind(\s)?Stealer/ ascii wide
		$x2 = "@FlatLineStealer" ascii wide
		$x3 = "@CashOutGangTalk" ascii wide
		$m1 = ".Passwords.Targets." ascii
		$m2 = ".Modules.Keylogger" ascii
		$m3 = ".Modules.Clipper" ascii
		$m4 = ".Modules.Implant" ascii
		$s1 = "--- Clipper" wide
		$s2 = "Downloading file: \"{file}\"" wide
		$s3 = "/bot{0}/getUpdates?offset={1}" wide
		$s4 = "send command to bot!" wide
		$s5 = " *Keylogger " fullword wide
		$s6 = "*Stealer" wide
		$s7 = "Bot connected" wide

	condition:
		uint16( 0 ) == 0x5a4d and 1 of ( $c* ) and ( 1 of ( $x* ) or 2 of ( $m* ) or 3 of ( $s* ) )
}
rule CAPE_Prynt : FILE
{
	meta:
		description = "Detects Prynt infostealer"
		author = "ditekSHen"
		id = "844fd100-b04e-5ff0-9fab-d45f48b55bcc"
		date = "2024-10-09"
		modified = "2026-11-16"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/AsyncRAT.yar#L85-L107"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "84f2b33285ab1d129a62940a02990639cc8f7c92d490d7257e6aed9170d1e34e"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "Prynt Payload"

	strings:
		$c1 = /Prynt(\s)?Stealer/ ascii wide
		$x2 = "@FlatLineStealer" ascii wide
		$x3 = "@CashOutGangTalk" ascii wide
		$m1 = ".Passwords.Targets." ascii
		$m2 = ".Modules.Keylogger" ascii
		$m3 = ".Modules.Clipper" ascii
		$m4 = ".Modules.Implant" ascii
		$s1 = "--- Clipper" wide
		$s2 = "Downloading file: \"{file}\"" wide
		$s3 = "/bot{0}/getUpdates?offset={1}" wide
		$s4 = "send command to bot!" wide
		$s5 = " *Keylogger " fullword wide
		$s6 = "*Stealer" wide
		$s7 = "Bot connected" wide

	condition:
		uint16( 0 ) == 0x5a4d and 1 of ( $c* ) and ( 1 of ( $x* ) or 2 of ( $m* ) or 3 of ( $s* ) )
}
rule CAPE_Quasarrat : FILE
{
	meta:
		description = "QuasarRAT payload"
		author = "ditekshen"
		id = "f256b88f-eee6-5f8c-afd6-32ed10ea908d"
		date = "2024-10-09"
		modified = "2026-11-16"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/AsyncRAT.yar#L245-L266"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "556b19dc0980761198ea31a285f281adae084463d24bff1eda15326436ad562b"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "QuasarRAT Payload"

	strings:
		$s1 = "GetKeyloggerLogsResponse" fullword ascii
		$s2 = "GetKeyloggerLogs" fullword ascii
		$s3 = "/>Log created on" wide
		$s4 = "User: {0}{3}Pass: {1}{3}Host: {2}" wide
		$s5 = "Domain: {1}{0}Cookie Name: {2}{0}Value: {3}{0}Path: {4}{0}Expired: {5}{0}HttpOnly: {6}{0}Secure: {7}" wide
		$s6 = "grabber_" wide
		$s7 = "<virtualKeyCode>" ascii
		$s8 = "<RunHidden>k__BackingField" fullword ascii
		$s9 = "<keyboardHookStruct>" ascii
		$s10 = "add_OnHotKeysDown" ascii
		$mutex = "QSR_MUTEX_" ascii wide
		$ua1 = "Mozilla/5.0 (Windows NT 6.3; rv:48.0) Gecko/20100101 Firefox/48.0" fullword wide
		$us2 = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/7046A194A" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( $mutex or ( all of ( $ua* ) and 2 of them ) or 6 of ( $s* ) )
}
rule CAPE_Quasarrat_Kingrat
{
	meta:
		description = "No description has been set in the source file - CAPE"
		author = "jeFF0Falltrades"
		id = "dc0139e1-9f69-51da-b28f-212358b2f68b"
		date = "2024-10-09"
		modified = "2026-11-16"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/AsyncRAT.yar#L268-L287"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "1f4296a592134edbe52e256dc353143af02e897ff1afad98f3dac0c5ab13f3f7"
		score = 75
		quality = 70
		tags = ""
		cape_type = "QuasarRAT Payload"

	strings:
		$str_quasar = "Quasar." wide ascii
		$str_hidden = "set_Hidden" wide ascii
		$str_shell = "DoShellExecuteResponse" wide ascii
		$str_close = "echo DONT CLOSE THIS WINDOW!" wide ascii
		$str_pause = "ping -n 10 localhost > nul" wide ascii
		$str_aes_exc = "masterKey can not be null or empty" wide ascii
		$byte_aes_key_base = { 7E [3] 04 73 [3] 06 25 }
		$byte_aes_salt_base = { BF EB 1E 56 FB CD 97 3B B2 19 }
		$byte_special_folder = { 7e 73 [4] 28 [4] 80 }
		$patt_config = { 72 [3] 70 80 [3] 04 }
		$patt_verify_hash = { 7e [3] 04 6f [3] 0a 6f [3] 0a 74 [3] 01 }

	condition:
		6 of them and #patt_config >= 10
}
rule CAPE_Masslogger : FILE
{
	meta:
		description = "MassLogger"
		author = "kevoreilly"
		id = "0743421a-36f7-5b7c-859f-b461511151cb"
		date = "2020-10-20"
		modified = "2020-11-24"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/MassLogger.yar#L1-L12"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "c8d82694810aafbdc6a35a661e7431e9536035e2f7fef90b9359064c4209b66c"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "MassLogger Payload"

	strings:
		$name = "MassLogger"
		$fody = "Costura"

	condition:
		uint16( 0 ) == 0x5A4D and 2 of them
}
rule CAPE_Latrodectus_1
{
	meta:
		description = "Latrodectus Payload"
		author = "enzok"
		id = "956b6736-b3ef-5974-b3dd-02d04336dbe8"
		date = "2024-01-18"
		modified = "2025-05-10"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Latrodectus.yar#L1-L16"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "a547cff9991a713535e5c128a0711ca68acf9298cc2220c4ea0685d580f36811"
		logic_hash = "a8430299930f4c8de0a88c6836d4821871f7183cc5ff44ea9be84fbea47bbb13"
		score = 75
		quality = 70
		tags = ""
		cape_type = "Latrodectus Payload"

	strings:
		$fnvhash1 = {C7 04 24 C5 9D 1C 81 48 8B 44 24 20 48 89 44 24 08}
		$fnvhash2 = {8B 0C 24 33 C8 8B C1 89 04 24 69 04 24 93 01 00 01}
		$procchk1 = {E8 [3] FF 85 C0 74 [2] FF FF FF FF E9 [4] E8 [4] 89 44 24 ?? E8 [4] 83 F8 4B 73 ?? 83 [3] 06}
		$procchk2 = {72 [2] FF FF FF FF E9 [4] E8 [4] 83 F8 32 73 ?? 83 [3] 06}
		$version = {C7 44 2? ?? ?? 00 00 00 C7 44 2? ?? ?? 00 00 00 8B 05 [4] 89}

	condition:
		all of them
}
rule CAPE_Latrodectus_AES
{
	meta:
		description = "Latrodectus Payload"
		author = "enzok"
		id = "16c295f5-cea0-57b5-b826-e1126e50c8cc"
		date = "2024-01-18"
		modified = "2025-05-10"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Latrodectus.yar#L18-L34"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "5cecb26a3f33c24b92a0c8f6f5175da0664b21d7c4216a41694e4a4cad233ca8"
		logic_hash = "058d278c16527969066d1b4ea7f0e3ab2809d5480cdab06ec476b465e0c4795a"
		score = 75
		quality = 70
		tags = ""
		cape_type = "Latrodectus Payload"

	strings:
		$fnvhash1 = {C7 04 24 C5 9D 1C 81 48 8B 44 24 20 48 89 44 24 08}
		$fnvhash2 = {8B 0C 24 33 C8 8B C1 89 04 24 69 04 24 93 01 00 01}
		$key = {C6 44 2? ?? ?? [150] C6 44 2? ?? ?? B8 02}
		$aes_ctr_1 = {8B 44 24 ?? FF C8 89 44 24 ?? 83 7C 24 ?? 00 7C ?? 4? 63 44 24 ?? 4? 8B 4C 24 ?? 0F B6 84 01 F0 00 00 00 3D FF 00 00 00}
		$aes_ctr_2 = {48 03 C8 48 8B C1 0F B6 ?? 48 63 4C 24 ?? 0F B6 4C 0C ?? 33 C1 48 8B 4C 24 ?? 48 8B 54 24 ?? 48 03 D1 48 8B CA 88 01}
		$version = {C7 44 2? ?? ?? 00 00 00 C7 44 2? ?? ?? 00 00 00 8B 05 [4] 89}

	condition:
		all of them
}
rule CAPE_Squirrelwaffle : FILE
{
	meta:
		description = "No description has been set in the source file - CAPE"
		author = "kevoreilly & R3MRUM"
		id = "0ae75f24-7a2a-57d3-8c6f-a61ac6cc08e7"
		date = "2021-09-22"
		modified = "2021-10-13"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/SquirrelWaffle.yar#L1-L11"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "5f799333398421d537ec7a87ca94f6cc9cf1e53e55b353036a5132440990e500"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "SquirrelWaffle Payload"

	strings:
		$code = {8D 45 ?? C6 45 ?? 00 0F 43 4D ?? 83 7D ?? 10 0F 43 45 ?? 8A 04 10 32 04 39 8D 4D ?? 0F B6 C0 50 6A 01 E8 [4] C6 45}
		$decode = {F7 75 ?? 83 7D ?? 10 8D 4D ?? 8D 45 ?? C6 45 ?? 00 0F 43 4D ?? 83 7D ?? 10 0F 43 45 ?? 8A 04 10 32 04 39}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CAPE_Pikabotloader : FILE
{
	meta:
		description = "Pikabot Loader"
		author = "kevoreilly"
		id = "e2c89cdd-0cdb-5367-8aae-2fe685eff972"
		date = "2023-02-13"
		modified = "2024-03-13"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/PikaBot.yar#L1-L13"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "7e5f1f2911545ee6bd36b54f2627fbdec1b957f4b91df901dd1c6cbd4dff0231"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "PikaBot Loader"

	strings:
		$indirect = {31 C0 64 8B 0D C0 00 00 00 85 C9 74 01 40 50 8D 54 24 ?? E8 [4] A3 [4] 8B 25 [4] A1}
		$sysenter1 = {89 44 24 08 8D 85 ?? FC FF FF C7 44 24 04 FF FF 1F 00 89 04 24 E8}
		$sysenter2 = {C7 44 24 0C 00 00 00 02 C7 44 24 08 00 00 00 02 8B 45 0C 89 44 24 04 8B 45 08 89 04 24 E8}

	condition:
		uint16( 0 ) == 0x5A4D and 2 of them
}
rule CAPE_Pikabot : FILE
{
	meta:
		description = "Pikabot Payload"
		author = "kevoreilly"
		id = "140a3e20-9837-5f66-85dc-af278d75e074"
		date = "2023-02-13"
		modified = "2024-03-13"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/PikaBot.yar#L15-L28"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "ed07217c373831a9a67d914854154988696e6fcea70dedabf333385f0e7bb8b7"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "PikaBot Payload"
		packed = "89dc50024836f9ad406504a3b7445d284e97ec5dafdd8f2741f496cac84ccda9"

	strings:
		$decode = {29 D1 01 4B ?? 8D 0C 10 89 4B ?? 85 F6 74 02 89 16}
		$indirect = {31 C0 64 8B 0D C0 00 00 00 85 C9 74 01 40 50 8D 54 24 ?? E8 [4] A3 [4] 8B 25 [4] A1}
		$config = {C7 44 24 [3] 00 00 C7 44 24 [4] 00 89 [1-4] ?? E8 [4] 31 C0 C7 44 24 [3] 00 00 89 44 24 ?? C7 04 24 [4] E8}

	condition:
		uint16( 0 ) == 0x5A4D and 2 of them
}
rule CAPE_Pik23 : FILE
{
	meta:
		description = "PikaBot Payload February 2023"
		author = "kevoreilly"
		id = "fc804c63-fc6c-5b26-92b1-aa5d2fbc4917"
		date = "2023-02-13"
		modified = "2024-03-13"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/PikaBot.yar#L30-L44"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "59f42ecde152f78731e54ea27e761bba748c9309a6ad1c2fd17f0e8b90f8aed1"
		logic_hash = "71a71df2f2a075294941c54eed06cafaaa4d3294e45b3a0098c1cffddd0438bc"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "PikaBot Payload"

	strings:
		$rdtsc = {89 55 FC 89 45 F8 0F 31 89 55 F4 89 45 FC 33 C0 B8 05 00 00 00 C1 E8 02 2B C3 3B C1 0F 31 89 55 F0 89 45 F8 8B 44 8D}
		$int2d = {B8 00 00 00 00 CD 2D 90 C3 CC CC CC CC CC CC CC}
		$subsys = {64 A1 30 00 00 00 8B 40 18 C3}
		$rijndael = {EB 0F 0F B6 04 3? FE C? 8A 80 [4] 88 04 3? 0F B6 [3] 7C EA 5? 5? C9 C3}

	condition:
		uint16( 0 ) == 0x5A4D and 3 of them
}
rule CAPE_Rozena
{
	meta:
		description = "No description has been set in the source file - CAPE"
		author = "Kevin O'Reilly"
		id = "38ca9da3-2a0e-500f-8eb8-9de69a7f2da5"
		date = "2024-03-13"
		modified = "2024-03-15"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Rozena.yar#L1-L10"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "c415a8108b58a125a604031bb8d73b58a8aae5429b5b765e35fa8a4add9cd135"
		score = 75
		quality = 70
		tags = ""
		cape_type = "Rozena Payload"

	strings:
		$ip_port = {FF D5 6A 0A 68 [4] 68 [4] 89 E6 50 50 50 50 40 50 40 50 68 [4] FF D5}
		$socket = {6A 00 6A 04 56 57 68 [4] FF D5 [0-5] 8B 36 6A 40 68 00 10 00 00 56 6A 00 68}

	condition:
		all of them
}
rule CAPE_Conti : FILE
{
	meta:
		description = "Conti Ransomware"
		author = "kevoreilly"
		id = "c94aed07-0eaf-5b51-a81e-e1992543673a"
		date = "2020-10-19"
		modified = "2021-03-15"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Conti.yar#L1-L13"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "c9842f93d012d0189b9c6f10ad558b37ae66226bbb619ad677f6906ccaf0e848"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "Conti Payload"

	strings:
		$crypto1 = {8A 07 8D 7F 01 0F B6 C0 B9 ?? 00 00 00 2B C8 6B C1 ?? 99 F7 FE 8D [2] 99 F7 FE 88 ?? FF 83 EB 01 75 DD}
		$website1 = "https://contirecovery.info" ascii wide
		$website2 = "https://contirecovery.best" ascii wide

	condition:
		uint16( 0 ) == 0x5A4D and any of them
}
rule CAPE_Phantomstealer : FILE
{
	meta:
		description = "PhantomStealer Payload"
		author = "kevoreilly"
		id = "8fbd76f0-da73-51da-a85a-77d9207dd340"
		date = "2026-07-28"
		modified = "2026-07-28"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/PhantomStealer.yar#L1-L13"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "2f6051f4653aca8f6db27b2ecf7156913f5d18542fdcd58ebc4b4bb41c1c3fb2"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "PhantomStealer Payload"

	strings:
		$a1 = "PhantomStealer"
		$a2 = "FormatCreditCards"
		$a3 = "Telegram"

	condition:
		uint16( 0 ) == 0x5A4D and ( all of ( $a* ) )
}
rule CAPE_Oyster
{
	meta:
		description = "Oyster Payload"
		author = "enzok"
		id = "29443d00-e3de-53fd-b617-df470a30e805"
		date = "2024-03-01"
		modified = "2024-05-30"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Oyster.yar#L1-L19"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "8bae0fa9f589cd434a689eebd7a1fde949cc09e6a65e1b56bb620998246a1650"
		logic_hash = "23ab1518712dbce8319b87785d7ffc0c2b61de82c2bbf533ebf0aae39ec33540"
		score = 75
		quality = 70
		tags = ""
		cape_type = "Oyster Payload"

	strings:
		$start_exit = {(05 | 00) 00 00 00 2E 96 1E A6}
		$content_type = {F6 CE 56 F4 76 F6 96 2E 86 C6 96 36 0E 0E 86 04 5C A6 0E 9E 2A B4 2E 76 A6 2E 76 F6 C2}
		$domain = {44 5C 44 76 96 86 B6 F6 26 44 34 44}
		$id = {44 5C 44 64 96 44 DE}
		$ip_local = {44 5C 44 36 86 C6 F6 36 FA 0E 96 44 34 44}
		$table_part_1 = {00 80 40 C0 20 A0 60 E0 10 90 50 D0 30 B0 70 F0 08 88 48 C8 28 A8 68}
		$table_part_2 = {97 57 D7 37 B7 77 F7 0F 8F 4F CF 2F AF 6F EF 1F 9F 5F DF 3F BF 7F FF}
		$decode = {0F B6 0? 8D ?? FF 8A [2] 0F B6 80 [4] 88 04 ?? 46 0F B6 C? 0F B6 80 [4] 88 4? 01 3B F7}

	condition:
		4 of them
}
rule CAPE_Salat : FILE
{
	meta:
		description = "Salat Payload"
		author = "kevoreilly"
		id = "a68d05d7-a8f6-567b-b57a-5255a5d2c4d1"
		date = "2026-04-17"
		modified = "2026-04-17"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Salat.yar#L1-L14"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "162a7398e0b2a83029bc3369127330636dce2b4f0874a17049cd90995ad89911"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "Salat Payload"

	strings:
		$a1 = "salat"
		$a2 = "screenshot"
		$a3 = "task.go"
		$a4 = "tsc.go"

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CAPE_Carbanak : FILE
{
	meta:
		description = "Carnbanak Payload"
		author = "enzok"
		id = "e6d395d5-65ba-5efb-bcbc-c6d56a96f0c1"
		date = "2023-11-30"
		modified = "2024-03-18"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Carbanak.yar#L1-L14"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "c9c1b06cb9c9bd6fc4451f5e2847a1f9524bb2870d7bb6f0ee09b9dd4e3e4c84"
		logic_hash = "8ed5ab07f1635dc7cdf296e86a71a0a99d0b2faef8fc460f43d426b24b8c8367"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "Carbanak Payload"

	strings:
		$sboxinit = {0F BE 02 4? 8D 05 [-] 4? 8D 4D ?? E8 [3] 00 33 F6 4? 8D 5D ?? 4? 63 F8 8B 45 ?? B? B1 E3 14 06}
		$decode_string = {0F BE 03 FF C9 83 F8 20 7D ?? B? 1F [3] 4? 8D 4A E2 EB ?? 3D 80 [3] 7D ?? B? 7F [3] 4? 8D 4A A1 EB ?? B? FF [3] 4? 8D 4A 81}
		$constants = {0F B7 05 [3] 00 0F B7 1D [3] 00 83 25 [3] 00 00 89 05 [3] 00 0F B7 05 [3] 00 89 1D [3] 00 89 05 [3] 00 33 C0 4? 8D 4D}

	condition:
		uint16( 0 ) == 0x5A4D and 2 of them
}
rule CAPE_Kpot : FILE
{
	meta:
		description = "Kpot Stealer"
		author = "kevoreilly"
		id = "724fd6ac-e734-5952-b459-01cbaffdb89d"
		date = "2020-10-19"
		modified = "2020-10-19"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Kpot.yar#L1-L13"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "75abaab9a10e8ac8808425c389238285ab9bd9cb76f0cd03cc1e35b3ea0a1b0f"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "Kpot Payload"

	strings:
		$format = "%s | %s | %s | %s | %s | %s | %s | %d | %s"
		$username = "username:s:"
		$os = "OS: %S x%d"

	condition:
		uint16( 0 ) == 0x5A4D and 2 of them
}
rule CAPE_Nightshadec2 : FILE
{
	meta:
		description = "NightshadeC2 AKA CastleRAT - https://x.com/YungBinary/status/1963751038340534482"
		author = "YungBinary"
		id = "d70f9051-c7ab-537a-ab80-03ae7ef80b81"
		date = "2025-09-04"
		modified = "2025-09-12"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/NightshadeC2.yar#L1-L20"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "963c012d56c62093d105ab5044517fdcce4ab826f7782b3e377932da1df6896d"
		logic_hash = "f9fabc391e21180a1c92abea0a5ded6d7669e8d8f2330b69d6c1227c9b4237a0"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "NightshadeC2 Payload"

	strings:
		$s1 = "keylog.txt" fullword wide
		$s2 = "\"%ws\" --mute-audio --do-not-de-elevate" fullword wide
		$s3 = "\"%ws\" -no-deelevate" fullword wide
		$s4 = "MachineGuid" fullword wide
		$s5 = "www.ip-api.com" fullword wide
		$s6 = "rundll32 \"C:\\Windows\\System32\\shell32.dll\" #61" fullword wide
		$s7 = "IsabellaWine" fullword wide
		$s8 = "Shell_TrayWnd" fullword wide

	condition:
		uint16( 0 ) == 0x5A4D and 3 of them
}

rule CAPE_Nighthawk
{
	meta:
		description = "NightHawk C2"
		author = "Nikhil Ashok Hegde <@ka1do9>"
		id = "096b9d13-6aa7-5b6e-aaeb-e25aa7c8c53f"
		date = "2022-12-03"
		modified = "2022-12-05"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Nighthawk.yar#L3-L24"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "2d77912678e06503ffef0e8ed84aa4f9ac74357480d57742fbae619acebfb5f2"
		score = 75
		quality = 70
		tags = ""
		cape_type = "Nighthawk Payload"

	strings:
		$keying_methods = { 85 C9 74 43 83 E9 01 74 1C 83 F9 01 0F 85 }
		$aes_sbox = { 63 7C 77 7B F2 6B 6F C5 30 }
		$aes_inv_sbox = { 52 09 6A D5 30 36 A5 38 BF }

	condition:
		pe.is_pe and for any s in pe.sections : ( s.name == ".profile" ) and all of them
}
rule CAPE_Adaptixbeacon
{
	meta:
		description = "AdaptixBeacon Payload"
		author = "enzok"
		id = "ae0bc10c-cfcd-59d4-8c24-34a03debe370"
		date = "2025-06-16"
		modified = "2025-10-28"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/AdaptixBeacon.yar#L1-L18"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "f78f5803be5704420cbb2e0ac3c57fcb3d9cdf443fbf1233c069760bee115b5d"
		logic_hash = "2c1d09cd5e19e5a09dde65411691afd5922959d4a7b5232b28ebf56f26d2f07d"
		score = 75
		quality = 70
		tags = ""
		cape_type = "AdaptixBeacon Payload"

	strings:
		$conf_1 = {8D ?? ?? E8 [3] 00 4? 89 [1-2] 4? 8B 4C 24 ?? E8 [3] 00 4? 8B 53 48 66 [0-1] 89 04 ?? E8}
		$conf_2 = {E8 [3] 00 48 8B 4C 24 ?? 48 89 43 78 E8 [3] 00 48 8B 4C 24 ?? 89 83 80 00 00 00 E8 [3] 00 03 83 80 00 00 00 48 8B 4C 24}
		$conf_3 = {E8 [3] 00 4? 8B 4C 24 ?? 4? 89 ?? 4? 89 43 58 E8 [3] 00 4? 8B 4C 24 ?? 4? 89 ?? 4? 89 43 60 E8 [3] 00 4? 8B 4C 24 ?? 4? 89 ?? 4? 89 43 68}
		$conf_4 = {8D ?? ?? 4? 89 ?? FF ?? 4? 89 ?? 4? 89 ?? 4? 8B ?? FF ?? ?? 4? 8B ?? 48 66 ?? 89 ?? ?? EB}
		$conf_5 = {48 89 ?? 4? 89 ?? FF ?? 4? 89 ?? 4? 89 D9 4? 89 ?? ?? 4? 8B 03 FF ?? ?? 4? 89 ?? 4? 89 ?? 4? 89 ?? ?? 4? 8B 03 FF ?? ?? 4? 89}
		$wininet_1 = {B9 77 00 00 00 [0-4] E8 [4] B9 69 00 00 00 88 ?4 24 [0-4] E8 [4] B9 6E 00 00 00 88 ?4 24}
		$wininet_2 = {B9 69 00 00 00 88 ?4 24 [0-4] E8 [4] B9 6E 00 00 00 88 ?4 24 [0-4] E8 [4] B9 65 00 00 00 88 ?4 24}

	condition:
		1 of ( $conf_* ) and 1 of ( $wininet_* )
}
rule CAPE_Bruteratel
{
	meta:
		description = "BruteRatel Payload"
		author = "kevoreilly"
		id = "61b951e4-0c27-59c0-8ea2-715b673fdcee"
		date = "2024-07-11"
		modified = "2024-07-11"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/BruteRatel.yar#L1-L14"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "0984977c716d6f8e068c045166eb5db77c9fbce27513e555dceca348375f1a66"
		score = 75
		quality = 70
		tags = ""
		cape_type = "BruteRatel Payload"

	strings:
		$syscall1 = {49 89 CA 4? 89 ?? (41 FF|FF)}
		$syscall2 = {49 89 CA 48 8B 44 24 ?? FF 64 24}
		$jmpapi = {49 89 ?? 10 49 C7 45 08 ?? 00 00 00 E8 00 00 00 00 ?? (48|49) 83 [2] 41 FF E2}
		$decode = {89 C2 8A 14 17 40 38 EA 75 06 FF C0 89 03 EB 0B 41 88 14 08 48 FF C1 FF 03 EB}

	condition:
		2 of them
}
rule CAPE_Amadey : FILE
{
	meta:
		description = "Amadey Payload"
		author = "kevoreilly, YungBinary"
		id = "81d251a2-84c3-524c-8ea5-c92ca8764777"
		date = "2021-02-18"
		modified = "2025-08-15"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Amadey.yar#L1-L15"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "988258716d5296c1323303e8fe4efd7f4642c87bfdbe970fe9a3bb3f410f70a4"
		logic_hash = "5a7405a174b63826500f3b04c6f10bc9b40d5b49e85377bef027204e75dd1e9e"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "Amadey Payload"

	strings:
		$decode1 = {8B D1 B8 FF FF FF 7F D1 EA 2B C2 3B C8 76 07 BB FF FF FF 7F EB 08 8D 04 0A 3B D8 0F 42 D8}
		$decode2 = {2B C8 8D 04 0A 33 D2 F7 F3 8B 5D ?? 8B CB 83 7B ?? 10}
		$decode3 = {33 D2 8B 4D ?? 8B C7 F7 F6 8A 84 3B [4] 2A 44 0A 01 88 87 [4] 47 8B 45 ?? 8D 50 01}
		$decode4 = {8A 04 02 88 04 0F 41 8B 7D ?? 8D 42 01 3B CB 7C}

	condition:
		uint16( 0 ) == 0x5A4D and 2 of them
}
rule CAPE_Vipkeylogger : FILE
{
	meta:
		description = "Detects VIPKeyLogger Keylogger"
		author = "kevoreilly"
		id = "71606fcc-89b4-519a-833a-b6cb4b569cb8"
		date = "2025-09-11"
		modified = "2025-09-11"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/VIPKeyLogger.yar#L1-L14"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "b9dba7562bba4807c0789692d44650996e62c8d0c4031dedd65773877621b1de"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "VIPKeyLogger Payload"
		packed = "edaba79c3d43a416a86003f336d879ed3a513aa24dd401340584615647ed6da2"

	strings:
		$s1 = "/ VIP Recovery \\" wide
		$s2 = "Clipboard Logs ID" wide
		$s3 = "Keylogger" wide

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule CAPE_Emotetloader : FILE
{
	meta:
		description = "Emotet Loader"
		author = "kevoreilly"
		id = "aea8ff2e-bdf7-5417-a41c-93566d1dd019"
		date = "2022-05-31"
		modified = "2022-05-31"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/EmotetLoader.yar#L1-L12"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "410872d25ed3a89a2cba108f952d606cd1c3bf9ccc89ae6ab3377b83665c2773"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "EmotetLoader Payload"

	strings:
		$antihook = {8B 15 ?? ?? ?? ?? 03 15 ?? ?? ?? ?? 89 95 28 FF FF FF A1 ?? ?? ?? ?? 2D 4D 01 00 00 A3 ?? ?? ?? ?? 8B 0D ?? ?? ?? ?? 3B 0D ?? ?? ?? ?? 76 26 8B 95 18 FF FF FF 8B 42 38}

	condition:
		uint16( 0 ) == 0x5A4D and any of them
}
rule CAPE_Zloader_1 : FILE
{
	meta:
		description = "Zloader Payload"
		author = "kevoreilly, enzok"
		id = "a4250532-ddfc-58c2-bbae-82cc201d0c5d"
		date = "2020-04-04"
		modified = "2025-12-09"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Zloader.yar#L1-L18"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "adbd0c7096a7373be82dd03df1aae61cb39e0a155c00bbb9c67abc01d48718aa"
		logic_hash = "525670973b67aac048199529c97d6be00b0a8cca9bc90deb647366d92a5ea540"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "Zloader Payload"

	strings:
		$rc4_init = {31 [1-3] 66 C7 8? 00 01 00 00 00 00 90 90 [0-5] 8? [5-90] 00 01 00 00 [0-15] (74|75)}
		$decrypt_conf = {83 C4 04 84 C0 74 5? E8 [4] E8 [4] E8 [4] E8 [4] ?8 [4] ?8 [4] ?8}
		$decrypt_conf_1 = {48 8d [5-11] e8 [4] 48 [3-4] 48 [3-4] 48 [6] E8}
		$decrypt_conf_2 = {48 8d [5] 4? [5] e8 [4] 48 [3-4] 48 8d [5] E8 [4] 48}
		$decrypt_key_1 = {66 89 C2 4? 8D 0D [3] 00 4? B? FC 03 00 00 E8 [4] 4? 83 C4 [1-2] C3}
		$decrypt_key_2 = {48 8d 0d [3] 00 66 89 ?? 4? 89 F0 4? [2-5] E8 [4-5] 4? 83 C4}
		$decrypt_key_3 = {48 8d 0d [3] 00 e8 [4] 66 89 [3] b? [4] e8 [4] 66 8b}

	condition:
		uint16( 0 ) == 0x5A4D and 1 of ( $decrypt_conf* ) and ( 1 of ( $decrypt_key* ) or $rc4_init )
}
rule CAPE_Zloader2024 : FILE
{
	meta:
		description = "Zloader Payload"
		author = "enzok"
		id = "f99d0994-d4a4-577b-916d-7eaa98e7c331"
		date = "2020-04-04"
		modified = "2025-12-09"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Zloader.yar#L20-L34"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "49405370a33abbf131c5d550cebe00780cc3fd3cbe888220686582ae88f16af7"
		logic_hash = "27d883f6d6cab07e602f97a0a032a152386693f79dabf1bb87b0a8a053a38b03"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "Zloader Payload"

	strings:
		$conf_1 = {48 01 ?? 48 8D 15 [4] 41 B8 ?? 04 00 00 E8 [4] [0-5] C7 [1-2] 00 00 00 00}
		$confkey_1 = {48 8D 15 [4] 48 89 ?? 49 89 ?? E8 [4] [0-5] C7 [1-2] 00 00 00 00}
		$confkey_2 = {48 01 ?? 48 8D 15 [4] 41 B8 10 00 00 00 E8 [4] [0-5] C7 [1-2] 00 00 00 00 (48 8B|8B)}
		$confkey_3 = {48 01 ?? 48 8D 15 [4] 41 B8 10 00 00 00 E8 [4] [0-5] C7 [1-2] 00 00 00 00 48 83 C4}

	condition:
		uint16( 0 ) == 0x5A4D and $conf_1 and 2 of ( $confkey_* )
}
rule CAPE_Zloader2025 : FILE
{
	meta:
		description = "Zloader Payload"
		author = "enzok"
		id = "dd6ee439-9599-564c-8841-94bd89ae2db0"
		date = "2020-04-04"
		modified = "2025-12-09"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Zloader.yar#L36-L49"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "86ffd411b42d8d06bdb294f48e79393adeea586c56c5c75c1a68ce6315932881"
		logic_hash = "cc9c39f0b5e7e8c8853982d9c896bbaac5a36bb0f501c8901d8854f2d5e1a19c"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "Zloader Payload"

	strings:
		$conf = {4? 01 ?? [4] E8 [4] 4? 8D 15 [4] 4? 89 ?? 4? 89 ?? E8 [4] C7 46 30 00 00 00 00 8B 7E 34}
		$confkey_1 = {4? 01 ?? [2] E8 [4] 4? 8D 15 [4] 4? 89 ?? 4? 89 ?? E8 [4] C7 46 34 00 00 00 00 8B 46 38}
		$confkey_2 = {4? 01 ?? [2] E8 [4] 4? 8D 15 [4] 4? 89 ?? 4? 89 ?? E8 [4] C7 46 38 00 00 00 00 48 83 C4 28}

	condition:
		uint16( 0 ) == 0x5A4D and $conf and all of ( $confkey_* )
}
rule CAPE_Buerloader_1 : FILE
{
	meta:
		description = "No description has been set in the source file - CAPE"
		author = "kevoreilly & Rony (@r0ny_123)"
		id = "95a9b4d7-db1e-50cd-bc08-01e4e4fd6dc4"
		date = "2020-10-29"
		modified = "2022-05-31"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/BuerLoader.yar#L1-L12"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "05c1f008f0a2bb8232867977fb23a5ae8312f10f0637c6265561052596319c29"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "BuerLoader Payload"

	strings:
		$trap = {0F 31 89 45 ?? 6A 00 8D 45 ?? 8B CB 50 E8 [4] 0F 31}
		$decode = {8A 0E 84 C9 74 0E 8B D0 2A 0F 46 88 0A 42 8A 0E 84 C9 75 F4 5F 5E 5D C2 04 00}
		$op = {33 C0 85 D2 7E 1? 3B C7 7D [0-15] 40 3B C2 7C ?? EB 02}

	condition:
		uint16( 0 ) == 0x5A4D and 2 of them
}
rule CAPE_Rhadamanthys_1
{
	meta:
		description = "Rhadamanthys Payload"
		author = "kevoreilly, YungBinary"
		id = "cd34b971-3603-5237-b47f-aea78ca38cac"
		date = "2023-01-25"
		modified = "2025-12-19"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Rhadamanthys.yar#L1-L19"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "3ccfc97202690dd996ffd2b4f09d31e6ee322bf9f0b7759f9b8c455164995f84"
		score = 75
		quality = 70
		tags = ""
		cape_type = "Rhadamanthys Payload"

	strings:
		$rc4 = {88 4C 01 08 41 81 F9 00 01 00 00 7C F3 89 75 08 33 FF 8B 4D 08 3B 4D 10 72 04 83 65 08 00}
		$code = {8B 4D FC 3B CF 8B C1 74 0D 83 78 04 02 74 1C 8B 40 1C 3B C7 75 F3 3B CF 8B C1 74 57 83 78 04 17 74 09 8B 40 1C 3B C7 75 F3 EB}
		$conf_1 = {46 BB FF 00 00 00 23 F3 0F B6 44 31 08 03 F8 23 FB 0F B6 5C 39 08 88 5C 31 08 88 44 39 08 02 C3 8B 5D 08 0F B6 C0 8A 44 08 08}
		$conf_2 = {0F B6 4F 2A 8D 77 2A 33 C0 6A 03 89 45 F8 89 45 FC 89 45 08 8B C1}
		$beef = {57 8D 44 33 FC 53 83 C6 FC 50 56 E8 [4] 83 C4 10 66 81 3F EF BE 0F 85}
		$anti = {50 68 [4] 68 [4] E8 [4] 83 C4 0C A3 [4] 85 C0 74}
		$dnr = {99 52 50 8D 45 ?? 99 52 50 8B C7 99 52 50 8B C3 99 52 50}
		$sys = {83 E4 F0 6A 33 E8 00 00 00 00 83 04 24 05 CB}
		$cape_string = "cape_options"

	condition:
		2 of them and not $cape_string
}
rule CAPE_Rhadamanthysloader
{
	meta:
		description = "Rhadamanthys Loader"
		author = "kevoreilly"
		id = "0d9955e8-c6e5-50f0-8006-8f6157038d40"
		date = "2023-01-25"
		modified = "2025-12-19"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Rhadamanthys.yar#L21-L33"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "5505c9ba1f0c6cb9aa9c212bf8bc2c49ad544e99996a1f4c1fa79a27a14d4c7f"
		score = 75
		quality = 70
		tags = ""
		cape_type = "Rhadamanthys Loader"

	strings:
		$ref = {33 D2 B9 0B 00 00 00 F7 F1 B8 01 00 00 00 6B C8 00 8D 84 0D [4] 0F BE 0C 10 8B 95 [4] 03 95 [4] 0F B6 02 33 C1 8B 8D [4] 03 8D [4] 88 01}
		$ntdll = {B9 6E 00 00 00 66 89 8D [4] BA 74 00 00 00 66 89 95 [4] B8 64 00 00 00 66 89 85 [4] B9 6C 00 00 00 66 89 8D [4] BA 6C 00 00 00 66 89 95}
		$exit = {6A 00 6A 00 6A 00 6A 00 6A 00 6A 00 8B 95 [4] 52 8B 85 [4] 50 6A 00 68 FF FF 1F 00}

	condition:
		2 of them
}
rule CAPE_Lockbit : FILE
{
	meta:
		description = "Lockbit Payload"
		author = "kevoreilly"
		id = "ec9b4fec-0233-5277-b922-07057c2b4b34"
		date = "2020-05-14"
		modified = "2022-06-09"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Lockbit.yar#L1-L15"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "80ab705c8246a0bd5b3de65146cf32b102f39bf9444bdf1d366b5a794c1229b9"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "Lockbit Payload"

	strings:
		$string1 = "/C ping 127.0.0.7 -n 3 > Nul & fsutil file setZeroData offset=0 length=524288 \"%s\" & Del /f /q \"%s\"" wide
		$string2 = "Ransom" ascii wide
		$crypto = {8B 4D 08 C1 E9 10 0F B6 D1 8B 4D 0C C1 E9 08 0F B6 C9 8B 14 95 [4] 8B 7D FC 33 14 8D [4] 8B CF C1 E9 18 33 14 8D [4] 0F B6 CB 33 14 8D [4] 8B CF 33 10}
		$decode1 = {8A ?4 34 ?C 0? 00 00 8B 8? 24 ?8 0? 00 00 0F BE ?? 0F BE C? 33 ?? 88 ?? 34 ?? 0? 00 00 46 83 FE 0? 72 DD}
		$decode2 = {8A 44 24 ?? 30 44 0C ?? 41 83 F9 ?? 72 F2}

	condition:
		uint16( 0 ) == 0x5A4D and ( 2 of them )
}
rule CAPE_Defendnot : FILE
{
	meta:
		description = "Defendnot Payload"
		author = "kevoreilly"
		id = "415181b5-1d12-57d8-9849-07ed340ade54"
		date = "2026-09-22"
		modified = "2026-09-22"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Defendnot.yar#L1-L15"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "b0870e105c7ad37fb0bdcb9305279b2943810d55300e8721eb64bdaa588cc84e"
		logic_hash = "77bdd1891d42947b254ffb0b274071e92e7fb7c62bdaa31793258a23a495e477"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "Defendnot Payload"

	strings:
		$string1 = "defendnot"
		$string2 = "Got HRESULT={:#x} at\n{}:{}"
		$string3 = "init: {:#x}"
		$string4 = "AV Name can not be empty!"

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule CAPE_Aurastealer
{
	meta:
		description = "AuraStealer Payload"
		author = "enzok"
		id = "1fe058a8-1e87-51bb-8b5c-914442bca2e5"
		date = "2025-09-02"
		modified = "2025-09-02"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/AuraStealer.yar#L1-L18"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "960b83639a898509dc272f3235822401a8f861fa6607991993285b618b882d8b"
		score = 75
		quality = 70
		tags = ""
		cape_type = "AuraStealer Payload"
		unpacked = "a9c47f10d5eb77d7d6b356be00b4814a7c1e5bb75739b464beb6ea03fc36cc85"
		packed = "bac52ffc8072893ff26cdbf1df1ecbcbb1762ded80249d3c9d420f62ed0dc202"

	strings:
		$conf = {8D BE ?? 00 00 00 68 00 40 00 00 5? 5? FF D1 83 C4 ?? 8B 07 8B 57 04 29 C2}
		$key1 = {FF D2 8B 2B 8D 75 ?? 8B 5D ?? 33 5D ?? 8D 45}
		$key2 = {89 0B 89 F9 5? 5? 5? E8 [4] 8B 3F 8D 6F 38 8B 77 30 33 77 34 8D 47 20 8D 4C 24 ?? 89 FA 5? E8}
		$keyexpansion = {31 C0 8A 1C 82 88 1C 81 8A 5C 82 01 88 5C 81 01 8A 5C 82 02 88 5C 81 02 8A 5C 82 03 88 5C 81 03 4? 83 F8 08 75 ?? B? 08 00 00 00}
		$antivm2 = {8B 43 04 8B 0D [4] 3B 81 [4] B? [2] 00 00 B? [2] 00 00 0F 44 D1 85 C0 0F 44 D1 8B 8A [4] 03 8A [4] FF E1 31 FF EB ?? 8B 78 0C 33 78 10 B? [4] 03 05 [4] FF D0}
		$antivm1 = {39 04 11 0f 94 C3 8B 44 ?? ?? 85 C0}

	condition:
		3 of them
}
rule CAPE_Lokibot : FILE
{
	meta:
		description = "LokiBot Payload"
		author = "kevoreilly"
		id = "8cdf69e2-ecac-5241-adba-c458cce0610f"
		date = "2022-02-01"
		modified = "2022-02-01"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/LokiBot.yar#L1-L12"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "a5b3d518371138740e913d2d6ce4fa22d3da5cea7e034c7d6b4b502e6bf44b06"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "LokiBot Payload"

	strings:
		$a1 = "DlRycq1tP2vSeaogj5bEUFzQiHT9dmKCn6uf7xsOY0hpwr43VINX8JGBAkLMZW"
		$a2 = "last_compatible_version"

	condition:
		uint16( 0 ) == 0x5A4D and ( all of ( $a* ) )
}
rule CAPE_Koiloader
{
	meta:
		description = "KoiLoader"
		author = "YungBinary"
		id = "258e8857-7ea6-5098-9949-06d9d83853d4"
		date = "2024-10-25"
		modified = "2024-10-25"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/KoiLoader.yar#L1-L35"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "b462e3235c7578450b2b56a8aff875a3d99d22f6970a01db3ba98f7ecb6b01a0"
		logic_hash = "264a536632f8f11c904b00c9d2e505b3263c733ad8fbc2ef19c25a5ad58cef90"
		score = 75
		quality = 70
		tags = ""
		cape_type = "KoiLoader Payload"

	strings:
		$chunk_1 = {
            68 27 11 68 05
            8B 45 ??
            50
            E8 ?? ?? ?? ??
            83 C4 08
            89 45 ??
            68 15 B1 B3 09
            8B 4D ??
            51
            E8 ?? ?? ?? ??
            83 C4 08
            89 45 ??
            68 B5 96 AA 0D
            8B 55 ??
            52
            E8 ?? ?? ?? ??
            83 C4 08
            89 45 ??
            6A 00
            FF 15 ?? ?? ?? ??
        }

	condition:
		$chunk_1
}
rule CAPE_Stealc : FILE
{
	meta:
		description = "Stealc Payload"
		author = "kevoreilly"
		id = "77567584-7c84-5351-938b-d29d612a042d"
		date = "2023-02-22"
		modified = "2025-08-21"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Stealc.yar#L1-L13"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "77d6f1914af6caf909fa2a246fcec05f500f79dd56e5d0d466d55924695c702d"
		logic_hash = "a6165168b7c74761b91d1691465688c748227b830813067edb4e9bdc934271c4"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "Stealc Payload"

	strings:
		$nugget1 = {68 04 01 00 00 6A 00 FF 15 [4] 50 FF 15}
		$nugget2 = {64 A1 30 00 00 00 8B 40 0C 8B 40 0C 8B 00 8B 00 8B 40 18 89 45 FC}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule CAPE_Stealcv2 : FILE
{
	meta:
		description = "Stealc V2 Payload"
		author = "kevoreilly"
		id = "0f72c468-9485-5e29-b29a-7dfc3e579e02"
		date = "2023-02-22"
		modified = "2025-08-21"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Stealc.yar#L15-L32"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "911c6a7f63e91a788898f3cc6e66396e39d5bd48f8fbaac49ee5dbbdaa64d5a0"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "Stealc Payload"
		packed = "2f42dcf05dd87e6352491ff9d4ea3dc3f854df53d548a8da0c323be42df797b6"
		packed = "8301936f439f43579cffe98e11e3224051e2fb890ffe9df680bbbd8db0729387"

	strings:
		$decode32 = {AB AB AB AB 8B 45 0C 89 4E 10 89 4E 14 39 45 08 75 0B C7 46 14 0F 00 00 00 88 0E EB 0F 2B 45 08 50 51 FF 75 ?? 8B}
		$dump32 = {33 C0 89 46 30 88 46 34 89 46 38 89 46 3C 89 46 40 89 46 44 89 46 48 89 46 4C 89 46 50 89 46 54 89 46 58 8B C6 5F 5E C3}
		$date32 = {F3 A5 8D 45 ?? 50 E8 [4] 59 8B F8 8B F2 8D 45 A4 50 E8 [4] 59 3B F2 7C 08 7F 04 3B F8 76 02 B3 01 8A C3}
		$decode64 = {40 53 48 83 EC 20 48 8B 19 48 85 DB 74 ?? 48 8B 53 18 48 83 FA 0F 76 2C 48 8B 0B 48 FF C2 48 81 FA 00 10 00 00 72}
		$dump64 = {48 8B C7 89 6F 40 40 88 6F 44 48 89 6F 48 48 89 6F 50 48 89 6F 58 48 89 6F 60 48 89 6F 68 48 89 6F 70 48 89 6F 78 48 89}
		$date64 = {0F 11 44 [2] 0F 11 8C [2] 00 00 00 89 8C [2] 00 00 00 48 8D 4C [2] E8 [4] 48 8B D8 48 8D 4C [2] E8 [4] 48 3B D8 0F 9F C0}

	condition:
		uint16( 0 ) == 0x5A4D and 2 of them
}
rule CAPE_Mykings : FILE
{
	meta:
		description = "No description has been set in the source file - CAPE"
		author = "YungBinary"
		id = "c9d7b061-b76c-595c-a362-6c89c96093d9"
		date = "2025-10-24"
		modified = "2025-10-26"
		reference = "https://x.com/YungBinary/status/1981108948498333900"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/MyKings.yar#L1-L23"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "82647dd23c0247faa045893ec1cf111da2a30528a1b737b59ce1b71172a64473"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "MyKings Payload"

	strings:
		$s1 = "login.php?uid=0" wide
		$s2 = "download.txt?rnd=" wide
		$s3 = "AcceptOK" ascii
		$s4 = "winsta0\\default" wide
		$s5 = "base64_ip.txt" wide
		$s6 = { 70 00 6F 00 77 00 65 00 72 00 74 00 6F 00 6F 00 6C 00 00 00 6B 00 61 00 73 00 70 00 65 00 72 00 73 00 6B 00 79 }
		$s7 = { 53 00 61 00 66 00 65 00 00 00 00 00 45 00 73 00 65 00 74 }
		$s8 = { 4E 00 6F 00 64 00 33 00 32 00 00 00 4D 00 61 00 6C 00 77 00 61 00 72 00 65 }
		$s9 = "Custom C++ HTTP Client/1.0" wide
		$s10 = "/ru \"SYSTEM\" /f" ascii
		$s11 = "cmd.exe /C timeout /t 1 & del " wide
		$s12 = "/login.aspx?uid=0" wide
		$s13 = "cmd-230812.ru" base64

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $s* ) )
}
rule CAPE_Obfuscar : FILE
{
	meta:
		description = "Obfuscar xor routime"
		author = "kevoreilly"
		id = "81eeb62f-578f-5c75-bc96-091d5727a20a"
		date = "2025-03-07"
		modified = "2025-03-07"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Obfuscar.yar#L1-L12"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "54581e83e5fa13fae4bda74016b3fa1d18c92e2659f493ebe54d70fd5f77bba5"
		score = 75
		quality = 70
		tags = "FILE"

	strings:
		$decode = {06 91 06 61 20 [4] 61 D2 9C 06 17 58 0A 06 7E [4] 8E 69 FE 04 2D ?? 2A}

	condition:
		uint16( 0 ) == 0x5A4D and any of them
}

rule CAPE_Netsupport : FILE
{
	meta:
		description = "Detects NetSupport Manager RAT on disk or in memory"
		author = "YungBinary"
		id = "c517193e-bee3-59c4-9fbf-aad01ee13379"
		date = "2025-10-17"
		modified = "2025-10-17"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/NetSupport.yar#L3-L16"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "d12e46d74ae0ba9f599d27dc2f55ff92a6648accbcd1a43cc3f1a9a2755e5fc7"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "NetSupport Payload"

	strings:
		$a1 = "NetSupport Manager" wide
		$b1 = "NetSupport Remote Control" wide
		$s1 = "Client Application" wide
		$s2 = "NetSupport Ltd" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( ( pe.imports ( "PCICL32.dll" , "_NSMClient32@8" ) ) or ( ( $a1 and $b1 ) or ( $s1 and $s2 ) ) )
}
rule CAPE_Bazar : FILE
{
	meta:
		description = "No description has been set in the source file - CAPE"
		author = "kevoreilly"
		id = "e042f180-2a82-5c93-9858-77281557dd10"
		date = "2021-08-26"
		modified = "2022-06-09"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Bazar.yar#L1-L11"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "9375f59b56e47fd0b90b089afdf3be8f16f960038fc625523a2e2d5509ab099d"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "Bazar Payload"

	strings:
		$decode = {F7 E9 [0-2] C1 FA 0? 8B C2 C1 E8 1F 03 D0 6B C2 ?? 2B C8}
		$rsa = {C7 00 52 53 41 33 48 8D 48 09 C7 40 04 00 08 00 00 4C 8D 05 [3] 00 C6 40 08 03 B8 09 00 00 00 [0-3] 48 8D 89 80 00 00 00 41 0F 10 00}

	condition:
		uint16( 0 ) == 0x5A4D and 2 of them
}
rule CAPE_Bumblebeeshellcode_1
{
	meta:
		description = "BumbleBee Loader 2023"
		author = "kevoreilly"
		id = "e04f80d0-3a57-51bc-8a54-639c7291a0d8"
		date = "2022-04-21"
		modified = "2026-11-13"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/BumbleBee.yar#L18-L33"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "d56f8c4e491d0d1b34e396e73750bef9917ca4f708fb6a2681de772a65c13a40"
		score = 75
		quality = 70
		tags = ""
		cape_type = "BumbleBeeLoader Payload"
		packed = "51bb71bd446bd7fc03cc1234fcc3f489f10db44e312c9ce619b937fad6912656"

	strings:
		$setpath = "setPath"
		$alloc = {B8 01 00 00 00 48 6B C0 08 48 8D 0D [2] 00 00 48 03 C8 48 8B C1 48 89 [3] 00 00 00 8B 44 [2] 05 FF 0F 00 00 25 00 F0 FF FF 8B C0 48 89}
		$hook = {48 85 C9 74 20 48 85 D2 74 1B 4C 8B C9 45 85 C0 74 13 48 2B D1 42 8A 04 0A 41 88 01 49 FF C1 41 83 E8 01 75 F0 48 8B C1 C3}
		$algo = {41 8B C1 C1 E8 0B 0F AF C2 44 3B C0 73 6A 4C 8B [3] 44 8B C8 B8 00 08 00 00 2B C2 C1 E8 05 66 03 C2 8B 94 [2] 00 00 00}
		$cape_string = "cape_options"

	condition:
		2 of them and not $cape_string
}
rule CAPE_Bumblebee_1 : FILE
{
	meta:
		description = "BumbleBee Payload"
		author = "enzo & kevoreilly"
		id = "0b77a46c-5743-541c-9afd-c751284bf40d"
		date = "2022-04-21"
		modified = "2026-11-13"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/BumbleBee.yar#L35-L50"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "a9e6077f5fd4306ebe5faee35bcd432d4455c7e5426f88ae8e038a73da34f07e"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "BumbleBee Payload"

	strings:
		$antivm1 = {84 C0 74 09 33 C9 FF [4] 00 CC 33 C9 E8 [3] 00 4? 8B C8 E8}
		$antivm2 = {84 C0 0F 85 [2] 00 00 33 C9 E8 [4] 48 8B C8 E8 [4] 48 8D 85}
		$antivm3 = {33 C9 E8 [4] 48 8B C8 E8 [4] 83 CA FF 48 8B 0D [4] FF 15}
		$antivm4 = {33 C9 E8 [4] 48 8B C8 E8 [4] 90 48 8B 05 [4] 48 85 C0 74}
		$str_ua = "bumblebee"
		$str_gate = "/gate"

	condition:
		uint16( 0 ) == 0x5A4D and ( any of ( $antivm* ) or ( all of ( $str_* ) and @str_ua > @str_gate and @str_ua - @str_gate <= 16 ) )
}
rule CAPE_Bumblebee2024
{
	meta:
		description = "BumbleBee 2024"
		author = "enzok"
		id = "27b93fa0-6f58-58b0-a8ef-5706ad65d03f"
		date = "2022-04-21"
		modified = "2026-11-13"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/BumbleBee.yar#L52-L68"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "654ff64daae992de263f6254090564d21de86933dee80067ea7a9661887ec5d8"
		score = 75
		quality = 70
		tags = ""
		cape_type = "BumbleBee Payload"
		packed = "a20d56ab2e53b3a599af9904f163bb2e1b2bb7f2c98432519e1fbe87c3867e66"

	strings:
		$rc4key = {48 [6] 48 [6] E8 [4] 4C 89 AD [4] 4C 89 AD [4] 4C 89 B5 [4] 4C 89 AD [4] 44 88 AD [4] 48 8D 15 [4] 44 38 2D [4] 75}
		$botidlgt = {4C 8B C1 B? 4F 00 00 00 48 8D 0D [4] E8 [4] 4C 8B C3 48 8D 0D [4] B? 4F 00 00 00 E8 [4] 4C 8B C3 48 8D 0D [4] B? FF 0F 00 00 E8}
		$botid = {90 48 [6] E8 [4] 4C 89 AD [4] 4C 89 AD [4] 4C 89 B5 [4] 4C 89 AD [4] 44 88 AD [4] 48 8D 15 [4] 44 38 2D [4] 75}
		$port = {4C 89 6D ?? 4C 89 6D ?? 4c 89 75 ?? 4C 89 6D ?? 44 88 6D ?? 48 8D 05 [4] 44 38 2D [4] 75}
		$dga1 = {4C 89 75 ?? 4C 89 6D ?? 44 88 6D ?? 48 8B 1D [4] 48 8D 0D [4] E8 [4] 8B F8}
		$dga2 = {48 8D 0D [4] E8 [4] 8B F0 4C 89 6D ?? 4C 89 6D ?? 4C 89 75 ?? 4C 89 6D ?? 44 88 6D ?? 48 8D 15 [4] 44 38 2D [4] 75}

	condition:
		$rc4key and all of ( $botid* ) and 2 of ( $port , $dga1 , $dga2 )
}
rule CAPE_Nitrobunnydownloader : FILE
{
	meta:
		description = "NitroBunnyDownloader"
		author = "enzok"
		id = "64faa91a-4847-57bd-ab71-27029f6074ac"
		date = "2025-10-28"
		modified = "2025-11-05"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/NitroBunnyDownloader.yar#L1-L18"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "960e59200ec0a4b5fb3b44e6da763f5fec4092997975140797d4eec491de411b"
		logic_hash = "dcc1348c1d1af0c854376cf6331538951362b43d8d76c0ad73bbbdeb1ab4c135"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "NitroBunnyDownloader Payload"

	strings:
		$config1 = {E8 [3] 00 41 B8 ?? ?? 00 00 48 8D 15 [3] 00 48 89 C1 48 89 ?? E8 [3] 00}
		$config2 = {E8 [3] 00 48 8D 15 [3] 00 41 B8 ?? ?? 00 00 48 89 C1 48 89 ?? E8 [3] 00}
		$string1 = "X-Amz-User-Agent:" wide
		$string2 = "Amz-Security-Flag:" wide
		$string3 = "/cart" wide
		$string4 = "Cookie: " wide
		$string5 = "wishlist" wide

	condition:
		uint16( 0 ) == 0x5A4D and 1 of ( $config* ) and 2 of ( $string* )
}
rule CAPE_Monsterv2 : FILE
{
	meta:
		description = "MonsterV2 Payload"
		author = "doomedraven,YungBinary"
		id = "4bc3546f-34ad-579e-9822-272a2b3c74e2"
		date = "2025-09-06"
		modified = "2025-09-12"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/MonsterV2.yar#L1-L21"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "d4e65f860e69b2eee8a818a4146d91b84ce6da30c8fa27593587932e4f0847a8"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "MonsterV2 Payload"
		packed = "fe69e8db634319815270aa0e55fe4b9c62ce8e62484609c3a42904fbe5bb2ab3"

	strings:
		$decrypt_config = {
            41 B8 0E 04 00 00
            48 8D 15 ?? ?? ?? 00
            48 8B C?
            E8 ?? ?? ?? ?? [3-17]
            4C 8B C?
            48 8D 54 24 28
            48 8B CE
            E8 ?? ?? ?? ??
        }

	condition:
		uint16( 0 ) == 0x5A4D and $decrypt_config
}
rule CAPE_Cobaltstrikestager
{
	meta:
		description = "Cobalt Strike Stager Payload"
		author = "@dan__mayer <daniel@stairwell.com>"
		id = "eedf71b1-9f27-5a6f-afe8-3ddae47f9a06"
		date = "2023-01-18"
		modified = "2023-01-18"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/CobaltStrikeStager.yar#L1-L15"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "6a55b0c3ab5f557dfb7a3f8bd616ede1bd9b93198590fc9d52aa19c1154388c5"
		score = 75
		quality = 70
		tags = ""
		cape_type = "CobaltStrikeStager Payload"

	strings:
		$smb = { 68 00 B0 04 00 68 00 B0 04 00 6A 01 6A 06 6A 03 52 68 45 70 DF D4 }
		$http_x86 = { 68 6E 65 74 00 68 77 69 6E 69 54 68 4C 77 26 07 }
		$http_x64 = { 49 BE 77 69 6E 69 6E 65 74 00 41 56 49 89 E6 4C 89 F1 41 BA 4C 77 26 07 }
		$dns = { 68 00 10 00 00 68 FF FF 07 00 6A 00 68 58 A4 53 E5 }

	condition:
		any of them
}
rule CAPE_Lumma_1 : FILE
{
	meta:
		description = "Lumma Payload"
		author = "kevoreilly"
		id = "66cb8b1a-e27e-5008-8f52-0e52e6624057"
		date = "2024-01-05"
		modified = "2025-07-08"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Lumma.yar#L1-L16"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "ca7822292c58af68e7a1610362bf0b5d27c93e3222ceec8d216e05a442008f37"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "Lumma Payload"
		packed = "0ee580f0127b821f4f1e7c032cf76475df9724a9fade2e153a69849f652045f8"
		packed = "23ff1c20b16d9afaf1ce443784fc9a025434a010e2194de9dec041788c369887"

	strings:
		$decode1 = {C1 (E9|EA) 02 [0-3] 0F B6 (44|4C) ?? FF 83 (F8|F9) 3D 74 05 83 (F8|F9) 2E 75 01 (49|4A) [0-30] 2E 75}
		$decode2 = {B0 40 C3 B0 3F C3 89 C8 04 D0 3C 09 77 06 80 C1 04 89 C8 C3 89 C8 04 BF 3C}
		$decode3 = {B0 40 C3 B0 3F C3 80 F9 30 72 ?? 80 F9 39 77 06 80 C1 04 89 C8 C3}
		$decode4 = {89 C8 04 D0 3C 09 77 ?? [3-11] 89 C8 [0-1] C3 89 C8 04 BF 3C 1A 72 ?? 89 C8 04 9F 3C}

	condition:
		uint16( 0 ) == 0x5a4d and any of them
}
rule CAPE_Ursnifv3_1 : FILE
{
	meta:
		description = "UrsnifV3 Payload"
		author = "kevoreilly"
		id = "9dd32f80-b535-52a3-91e1-4db005362fd4"
		date = "2022-05-31"
		modified = "2023-03-23"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/UrsnifV3.yar#L1-L18"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		logic_hash = "501cd52388aba16f9d33b4555f310e1ad58326916b15358a485c701acb87abd8"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "UrsnifV3 Payload"
		packed = "75827be0c600f93d0d23d4b8239f56eb8c7dc4ab6064ad0b79e6695157816988"
		packed = "5d6f1484f6571282790d64821429eeeadee71ba6b6d566088f58370634d2c579"

	strings:
		$crypto32_1 = {8B C3 83 EB 01 85 C0 75 0D 0F B6 16 83 C6 01 89 74 24 14 8D 58 07 8B C2 C1 E8 07 83 E0 01 03 D2 85 C0 0F 84 AB 01 00 00 8B C3 83 EB 01 85 C0 89 5C 24 20 75 13 0F B6 16 83 C6 01 BB 07 00 00 00}
		$crypto32_2 = {8B 45 ?? 0F B6 3? FF 45 [2-4] 8B C? 23 C? 40 40 D1 E? 7?}
		$crypto32_3 = {F6 46 03 02 75 5? 8B 46 10 40 50 E8 [10-12] 74 ?? F6 46 03 01 74}
		$crypto32_4 = {C7 44 24 10 01 00 00 00 8B 4? 10 [12] 8B [2] 89 01 8B 44 24 10 5F 5E 5B 8B E5 5D C2 0C 00}
		$cpuid = {8B C4 FF 18 8B F0 33 C0 0F A2 66 8C D8 66 8E D0 8B E5 8B C6 5E 5B 5D C3}
		$cape_string = "cape_options"

	condition:
		uint16( 0 ) == 0x5A4D and 1 of ( $crypto32_* ) and $cpuid and not $cape_string
}
rule CAPE_Blister_1 : FILE
{
	meta:
		description = "Blister Loader"
		author = "kevoreilly"
		id = "525fc600-2afc-5cf6-bf55-4ce0ea264dca"
		date = "2022-05-10"
		modified = "2023-09-20"
		reference = "https://github.com/kevoreilly/CAPEv2"
		source_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/data/yara/CAPE/Blister.yar#L1-L17"
		license_url = "https://github.com/kevoreilly/CAPEv2/blob/1a84d3ad010a14bb4ba911e4a208a145da94f208/LICENSE"
		hash = "afb77617a4ca637614c429440c78da438e190dd1ca24dc78483aa731d80832c2"
		hash = "d3eab2a134e7bd3f2e8767a6285b38d19cd3df421e8af336a7852b74f194802c"
		logic_hash = "f26d85fdf0eb07e67fe38c43c5f6d024bfb7b2a333cb3411f5cdcff6bf5db12d"
		score = 75
		quality = 70
		tags = "FILE"
		cape_type = "Blister Loader"

	strings:
		$protect1 = {50 6A 20 8D 45 ?? 50 8D 45 ?? 50 6A FF FF D7}
		$protect2 = {48 83 C9 FF 48 8D 55 ?? FF D6 48 8D 87 [2] 00 00 48 8D 4D ?? FF D0}
		$lock1 = {B9 FF FF FF 7F 89 75 FC 8B C1 F0 FF 45 FC 83 E8 01 75}
		$lock2 = {B8 FF FF FF 7F 41 BC 01 00 00 00 89 45 40 F0 FF 4D 40 49 2B C4 75}
		$decode = {0F BE C0 49 03 CC 41 33 C1 44 69 C8 [4] 41 8B C1 C1 E8 0F 44 33 C8 8A 01 84 C0 75 E1 41 81 F9 [4] 74}

	condition:
		uint16( 0 ) == 0x5A4D and 2 of them
}
/*
 * YARA Rule Set
 * Repository Name: DelivrTo
 * Repository: https://github.com/delivr-to/detections
 * Retrieval Date: 2026-11-22
 * Git Commit: f85e1d0c477cbf4689d1cfe4a80049c465673b23
 * Number of Rules: 2
 * Skipped: 0 (age), 6 (quality), 7 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * NO LICENSE SET
 */
rule DELIVRTO_SUSP_PDF_MHT_Activemime_Sept23 : FILE
{
	meta:
		description = "Presence of MHT ActiveMime within PDF for polyglot file"
		author = "delivr.to"
		id = "fbac1371-bad4-5751-a5c4-ce6c270fb83e"
		date = "2023-09-04"
		modified = "2023-09-04"
		reference = "https://blogs.jpcert.or.jp/en/2023/08/maldocinpdf.html"
		source_url = "https://github.com/delivr-to/detections/blob/f85e1d0c477cbf4689d1cfe4a80049c465673b23/yara-rules/pdf_mht_activemime.yar#L1-L19"
		license_url = "N/A"
		logic_hash = "af1450f649de6daec242f11e3b3c35305d3127fac4ef719a4ddb4edab3ae3651"
		score = 70
		quality = 78
		tags = "FILE"

	strings:
		$mht0 = "mime" ascii nocase
		$mht1 = "content-location:" ascii nocase
		$mht2 = "content-type:" ascii nocase
		$act = "edit-time-data" ascii nocase

	condition:
		uint32( 0 ) == 0x46445025 and all of ( $mht* ) and $act
}
rule DELIVRTO_SUSP_HTML_WASM_Smuggling
{
	meta:
		description = "Presence of Base64 JavaScript blob loading WASM"
		author = "delivr.to"
		id = "fc83bb4f-ba8a-52d2-b9ce-632da5341f77"
		date = "2024-02-28"
		modified = "2024-05-24"
		reference = "https://github.com/delivr-to/detections"
		source_url = "https://github.com/delivr-to/detections/blob/f85e1d0c477cbf4689d1cfe4a80049c465673b23/yara-rules/html_wasm.yar#L1-L13"
		license_url = "N/A"
		logic_hash = "4bca88862c28db947c04c40e40fdecc682223d1eb90c98350fbd6c5d8c6c4636"
		score = 70
		quality = 80
		tags = ""

	strings:
		$wasm = "WebAssembly.Module" base64
		$int = "WebAssembly.Instance" base64
		$inst = "WebAssembly.instantiate" base64

	condition:
		all of them
}
/*
 * YARA Rule Set
 * Repository Name: ESET
 * Repository: https://github.com/eset/malware-ioc
 * Retrieval Date: 2026-11-22
 * Git Commit: 8921a81d245cce3f9b7a199b123d221ed8f1fe33
 * Number of Rules: 56
 * Skipped: 56 (age), 25 (quality), 2 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * Copyright (c) 2014-2018 ESET spol. s r.o.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */
rule ESET_Mozi_Killswitch : FILE
{
	meta:
		description = "Mozi botnet kill switch"
		author = "Ivan Besina"
		id = "e3d34ae0-de06-5ff4-b44b-44d264b6dd29"
		date = "2023-09-29"
		modified = "2023-10-31"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/mozi/mozi.yar#L32-L51"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "90eaed2f7f5595b145b2678a46ef6179082192215369fa9235024b0ce1574a49"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$iptables1 = "iptables -I INPUT  -p tcp --destination-port 7547 -j DROP"
		$iptables2 = "iptables -I OUTPUT -p tcp --sport 30005 -j DROP"
		$haha = "/haha"
		$networks = "/usr/networks"

	condition:
		all of them and filesize < 500KB
}
rule ESET_Kobalos
{
	meta:
		description = "Kobalos malware"
		author = "Marc-Etienne M.Léveillé"
		id = "cdffbe3d-c19d-53a8-9051-48affae00c8a"
		date = "2020-11-02"
		modified = "2021-02-01"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/kobalos/kobalos.yar#L32-L56"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "9161d22f9fbb1700dc3121e32104240e34512cb280aaf950aec61513f89061ef"
		score = 75
		quality = 80
		tags = ""
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$encrypted_strings_sizes = {
            05 00 00 00 09 00 00 00  04 00 00 00 06 00 00 00
            08 00 00 00 08 00 00 00  02 00 00 00 02 00 00 00
            01 00 00 00 01 00 00 00  05 00 00 00 07 00 00 00
            05 00 00 00 05 00 00 00  05 00 00 00 0A 00 00 00
        }
		$password_md5_digest = { 3ADD48192654BD558A4A4CED9C255C4C }
		$rsa_512_mod_header = { 10 11 02 00 09 02 00 }
		$strings_rc4_key = { AE0E05090F3AC2B50B1BC6E91D2FE3CE }

	condition:
		any of them
}
rule ESET_Kobalos_Ssh_Credential_Stealer
{
	meta:
		description = "Kobalos SSH credential stealer seen in OpenSSH client"
		author = "Marc-Etienne M.Léveillé"
		id = "b1fc5163-de48-57fc-8ae7-1f2be6c64d8a"
		date = "2020-11-02"
		modified = "2021-02-01"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/kobalos/kobalos.yar#L58-L73"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "be238f5c2cc976a5638584a8c0fc580f2076735aadfe374e8d4162ba723bce10"
		score = 75
		quality = 80
		tags = ""
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$ = "user: %.128s host: %.128s port %05d user: %.128s password: %.128s"

	condition:
		any of them
}
rule ESET_Ebury_V1_7_Crypto
{
	meta:
		description = "This rule detects the strings decryption routine in Ebury v1.7 and v1.8"
		author = "ESET, spol. s r.o."
		id = "93dadf5f-b572-5217-8c82-4957c6d24955"
		date = "2023-08-01"
		modified = "2024-04-29"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/windigo/ebury.yar#L56-L97"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		hash = "e7debd6e453192ad8376db5bab03ed0d87566591"
		logic_hash = "41908951069a472d7528f2f228f3681f008d16a0436e341d339909efc4933e66"
		score = 75
		quality = 80
		tags = ""
		license = "BSD 2-Clause"
		version = 1

	strings:
		$64 = {
            48 69 ( 9C 24 ?? ?? ?? ?? | 5C 24 ?? | D2) 6D 4E C6 41 //  imul    rbx, [rsp+_buf], 41C64E6Dh
            8B (0C 16 | 34 07)                      //  mov     ecx, [rsi+rdx]
            48 81 C? 39 30 00 00                    //  add     rbx, 12345
            ( 31 D? |                               //  xor     ecx, ebx
              31 D? 48 89 9C 24 ?? ?? ?? ?? |       //  mov     [rsp+_buf], rbx
              31 D? 48 89 5C 24 ?? )                //  ^ optional
            89 (0C 10 | 34 01)                      //  mov     [rax+rdx], ecx
            48 83 C? 04                             //  add     rdx, 4
            48 (81 FA | 3D ) ?? ?? ?? ??            //  cmp     rdx, _size
            75 D?                                   //  jnz     short _begin
        }
		$32 = {
            69 C9 6D 4E C6 41      // imul    ecx, 41C64E6Dh
            8B B4 1A ?? ?? ?? ??   // mov     esi, [edx+ebx+_data]
            81 C1 39 30 00 00      // add     ecx, 12345
            31 CE                  // xor     esi, ecx
            89 34 10               // mov     [eax+edx], esi
            83 C2 04               // add     edx, 4
            81 FA ?? ?? ?? ??      // cmp     edx, _size
            75 DD                  // jnz     short loc_69A5
        }

	condition:
		any of them
}

rule ESET_Sparklinggoblin_Chacha20Loader_Richheader
{
	meta:
		description = "Rule matching ChaCha20 loaders rich header"
		author = "ESET Research"
		id = "e1dac369-f25e-5cb3-aafa-b0c45f05b295"
		date = "2021-03-30"
		modified = "2021-08-26"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/sparklinggoblin/SparklingGoblin.yar#L33-L57"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		hash = "09ffe37a54bc4ebebd8d56098e4c76232f35d821"
		hash = "29b147b76bb0d9e09f7297487cb972e6a2905586"
		hash = "33f2c3de2457b758fc5824a2b253ad7c7c2e9e37"
		hash = "45bef297ce78521eac6ee39e7603e18360e67c5a"
		hash = "4cec7cdc78d95c70555a153963064f216dae8799"
		hash = "4d4c1a062a0390b20732ba4d65317827f2339b80"
		hash = "4f6949a4906b834e83ff951e135e0850fe49d5e4"
		logic_hash = "a5c9595036dec0e0aef0a030c590189752217d15d3f53bf3dc537f5b43fae63e"
		score = 75
		quality = 80
		tags = ""
		license = "BSD 2-Clause"

	condition:
		pe.rich_signature.length>= 104 and pe.rich_signature.length <= 112 and pe.rich_signature.toolid ( 241 , 40116 ) >= 5 and pe.rich_signature.toolid ( 241 , 40116 ) <= 10 and pe.rich_signature.toolid ( 147 , 30729 ) == 11 and pe.rich_signature.toolid ( 264 , 24215 ) >= 15 and pe.rich_signature.toolid ( 264 , 24215 ) <= 16
}
rule ESET_Sparklinggoblin_Chacha20 : FILE
{
	meta:
		description = "SparklingGoblin ChaCha20 implementations"
		author = "ESET Research"
		id = "c0caceca-f685-5786-82f6-3ab7435f8061"
		date = "2021-05-20"
		modified = "2021-08-26"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/sparklinggoblin/SparklingGoblin.yar#L59-L368"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		hash = "2edbea43f5c40c867e5b6bbd93cc972525df598b"
		hash = "b6d245d3d49b06645c0578804064ce0c072cbe0f"
		hash = "8be6d5f040d0085c62b1459afc627707b0de89cf"
		hash = "4668302969fe122874fb2447a80378dcb671c86b"
		hash = "9bdecb08e16a23d271d0a3e836d9e7f83d7e2c3b"
		hash = "9ce7650f2c08c391a35d69956e171932d116b8bd"
		hash = "91b32e030a1f286e7d502ca17e107d4bfbd7394a"
		logic_hash = "b742bc22e0ebbce40607cb109b4d6fb03a40c1fb223c8092d93346dd3dd22789"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"

	strings:
		$chunk_1 = {
            8B 4D ??
            56
            8B 75 ??
            57
            8B 7D ??
            8B 04 BB
            01 04 93
            8B 04 B3
            33 04 93
            C1 C0 10
            89 04 B3
            01 04 8B
            8B 04 BB
            33 04 8B
            C1 C0 0C
            89 04 BB
            01 04 93
            8B 04 B3
            33 04 93
            C1 C0 08
            89 04 B3
            01 04 8B
            8B 04 BB
            33 04 8B
            C1 C0 07
            89 04 BB
        }
		$chunk_2 = {
            03 4D ??
            44 03 C0
            03 55 ??
            33 F1
            45 33 D8
            C1 C6 10
            44 33 F2
            41 C1 C3 10
            41 03 FB
            41 C1 C6 10
            45 03 E6
            41 03 DA
            44 33 CB
            44 03 EE
            41 C1 C1 10
            8B C7
            33 45 ??
            45 03 F9
            C1 C0 0C
            44 03 C0
            45 33 D8
            44 89 45 ??
            41 C1 C3 08
            41 03 FB
            44 8B C7
            44 33 C0
            41 8B C5
            33 45 ??
            C1 C0 0C
            03 C8
            41 C1 C0 07
            33 F1
            89 4D ??
            C1 C6 08
            44 03 EE
            41 8B CD
            33 C8
            41 8B C4
            33 45 ??
            C1 C0 0C
            03 D0
            C1 C1 07
            44 33 F2
            89 55 ??
            41 C1 C6 08
            45 03 E6
            41 8B D4
            33 D0
            41 8B C7
            41 33 C2
            C1 C2 07
            C1 C0 0C
            03 D8
            44 33 CB
            41 C1 C1 08
            45 03 F9
            45 8B D7
            44 33 D0
            8B 45 ??
            03 C1
            41 C1 C2 07
            44 33 C8
            89 45 ??
            41 C1 C1 10
            45 03 E1
            41 8B C4
            33 C1
            8B 4D ??
            C1 C0 0C
            03 C8
            44 33 C9
            89 4D ??
            89 4D ??
            41 C1 C1 08
            45 03 E1
            41 8B CC
            33 C8
            8B 45 ??
            C1 C1 07
            89 4D ??
            89 4D ??
            03 C2
            41 03 D8
            89 45 ??
            41 33 C3
            C1 C0 10
            44 03 F8
            41 8B CF
            33 CA
            8B 55 ??
        }
		$chunk_3 = {
            C7 45 ?? 65 78 70 61
            4C 8D 45 ??
            C7 45 ?? 6E 64 20 33
            4D 8B F9
            C7 45 ?? 32 2D 62 79
            4C 2B C1
            C7 45 ?? 74 65 20 6B
        }
		$chunk_4 = {
            0F B6 02
            0F B6 4A ??
            C1 E1 08
            0B C8
            0F B6 42 ??
            C1 E1 08
            0B C8
            0F B6 42 ??
            C1 E1 08
            0B C8
            41 89 0C 10
            48 8D 52 ??
            49 83 E9 01
        }
		$chunk_5 = {
            03 4D ??
            44 03 C0
            03 55 ??
            33 F1
            41 33 F8
            C1 C6 10
            44 33 F2
            C1 C7 10
            44 03 DF
            41 C1 C6 10
            45 03 E6
            44 03 CB
            45 33 D1
            44 03 EE
            41 C1 C2 10
            41 8B C3
            33 45 ??
            45 03 FA
            C1 C0 0C
            44 03 C0
            41 33 F8
            44 89 45 ??
            C1 C7 08
            44 03 DF
            45 8B C3
            44 33 C0
            41 8B C5
            33 45 ??
            C1 C0 0C
            03 C8
            41 C1 C0 07
            33 F1
            89 4D ??
            C1 C6 08
            44 03 EE
            41 8B CD
            33 C8
            41 8B C4
            33 45 ??
            C1 C0 0C
            03 D0
            C1 C1 07
            44 33 F2
            89 55 ??
            41 C1 C6 08
            45 03 E6
            41 8B D4
            33 D0
            41 8B C7
            33 C3
            C1 C2 07
            C1 C0 0C
            44 03 C8
            45 33 D1
            41 C1 C2 08
            45 03 FA
            41 8B DF
            33 D8
            8B 45 ??
            03 C1
            C1 C3 07
            44 33 D0
            89 45 ??
            41 C1 C2 10
            45 03 E2
            41 8B C4
            33 C1
            8B 4D ??
            C1 C0 0C
            03 C8
            44 33 D1
            89 4D ??
            89 4D ??
            41 C1 C2 08
            45 03 E2
            41 8B CC
            33 C8
            8B 45 ??
            C1 C1 07
            89 4D ??
            89 4D ??
            03 C2
            45 03 C8
            89 45 ??
            33 C7
            C1 C0 10
            44 03 F8
            41 8B CF
            33 CA
            8B 55 ??
            C1 C1 0C
            03 D1
            8B FA
            89 55 ??
            33 F8
            89 55 ??
            8B 55 ??
            03 D3
            C1 C7 08
            44 03 FF
            41 8B C7
            33 C1
            C1 C0 07
            89 45 ??
            89 45 ??
            8B C2
            33 C6
            C1 C0 10
            44 03 D8
            41 33 DB
            C1 C3 0C
            03 D3
            8B F2
            89 55 ??
            33 F0
            41 8B C1
            41 33 C6
            C1 C6 08
            C1 C0 10
            44 03 DE
            44 03 E8
            41 33 DB
            41 8B CD
            C1 C3 07
            41 33 C8
            44 8B 45 ??
            C1 C1 0C
            44 03 C9
            45 8B F1
            44 33 F0
            41 C1 C6 08
            45 03 EE
            41 8B C5
            33 C1
            8B 4D ??
            C1 C0 07
        }

	condition:
		any of them and filesize < 450KB
}
rule ESET_Sparklinggoblin_Etweventwrite
{
	meta:
		description = "SparklingGoblin EtwEventWrite patching"
		author = "ESET Research"
		id = "27b36ee1-a98c-5174-a156-8e0b0d0a58cd"
		date = "2021-05-20"
		modified = "2021-08-26"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/sparklinggoblin/SparklingGoblin.yar#L370-L463"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		hash = "2edbea43f5c40c867e5b6bbd93cc972525df598b"
		hash = "b6d245d3d49b06645c0578804064ce0c072cbe0f"
		hash = "8be6d5f040d0085c62b1459afc627707b0de89cf"
		hash = "4668302969fe122874fb2447a80378dcb671c86b"
		hash = "9bdecb08e16a23d271d0a3e836d9e7f83d7e2c3b"
		hash = "9ce7650f2c08c391a35d69956e171932d116b8bd"
		logic_hash = "45615dcc5302392c18052818071623a9d1a1008c460bdb24a4acfb4300356c6b"
		score = 75
		quality = 80
		tags = ""
		license = "BSD 2-Clause"

	strings:
		$chunk_1 = {
            48 8D 0D ?? ?? ?? ??
            C7 44 24 ?? 48 31 C0 C3
            FF 15 ?? ?? ?? ??
            48 8B C8
            48 8D 15 ?? ?? ?? ??
            FF 15 ?? ?? ?? ??
            83 64 24 ?? 00
            4C 8D 4C 24 ??
            BF 04 00 00 00
            48 8B C8
            8B D7
            48 8B D8
            44 8D 47 ??
            FF 15 ?? ?? ?? ??
            44 8B C7
            48 8D 54 24 ??
            48 8B CB
            E8 ?? ?? ?? ??
            44 8B 44 24 ??
            4C 8D 4C 24 ??
            8B D7
            48 8B CB
            FF 15 ?? ?? ?? ??
            48 8B 05 ?? ?? ?? ??
        }
		$chunk_2 = {
            55
            8B EC
            51
            51
            57
            68 08 1A 41 00
            66 C7 45 ?? C2 14
            C6 45 ?? 00
            FF 15 ?? ?? ?? ??
            68 10 1A 41 00
            50
            FF 15 ?? ?? ?? ??
            83 65 ?? 00
            8B F8
            8D 45 ??
            50
            6A 40
            6A 03
            57
            FF 15 ?? ?? ?? ??
            6A 03
            8D 45 ??
            50
            57
            E8 ?? ?? ?? ??
            83 C4 0C
            8D 45 ??
            50
            FF 75 ??
            6A 03
            57
            FF 15 ?? ?? ?? ??
        }
		$chunk_3 = {
            48 8D 0D ?? ?? ?? ??
            C7 44 24 ?? 48 31 C0 C3
            FF 15 ?? ?? ?? ??
            48 8B C8
            48 8D 15 ?? ?? ?? ??
            FF 15 ?? ?? ?? ??
        }

	condition:
		any of them
}
rule ESET_Sparklinggoblin_Mutex
{
	meta:
		description = "SparklingGoblin ChaCha20 loaders mutexes"
		author = "ESET Research"
		id = "e33d2bc1-29d6-5117-8e0f-31f8bced0979"
		date = "2021-05-20"
		modified = "2021-08-26"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/sparklinggoblin/SparklingGoblin.yar#L465-L489"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		hash = "2edbea43f5c40c867e5b6bbd93cc972525df598b"
		hash = "b6d245d3d49b06645c0578804064ce0c072cbe0f"
		hash = "8be6d5f040d0085c62b1459afc627707b0de89cf"
		hash = "4668302969fe122874fb2447a80378dcb671c86b"
		hash = "9bdecb08e16a23d271d0a3e836d9e7f83d7e2c3b"
		hash = "9ce7650f2c08c391a35d69956e171932d116b8bd"
		logic_hash = "00fbd514c8e2d6dea3b0f175e857a613e158b64caf1f970e814d62f1ebe9d35c"
		score = 75
		quality = 80
		tags = ""
		license = "BSD 2-Clause"

	strings:
		$mutex_1 = "kREwdFrOlvASgP4zWZyV89m6T2K0bIno"
		$mutex_2 = "v5EPQFOImpTLaGZes3Nl1JSKHku8AyCw"

	condition:
		any of them
}
rule ESET_Apt_Windows_TA410_Tendyron_Dropper
{
	meta:
		description = "TA410 Tendyron Dropper"
		author = "ESET Research"
		id = "8d1e16d9-b5c2-5427-a0b4-7dd00a9df5ec"
		date = "2020-12-09"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L34-L53"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "45f7300a4b85624ad3fda5c73a24f53f53cb7990def4d84e04dcd8e5747f4f2e"
		score = 75
		quality = 80
		tags = ""
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$s1 = "Global\\{F473B3BE-08EE-4710-A727-9E248F804F4A}" wide
		$s2 = "Global\\8D32CCB321B2" wide
		$s3 = "Global\\E4FE94F75490" wide
		$s4 = "Program Files (x86)\\Internet Explorer\\iexplore.exe" wide
		$s5 = "\\RPC Control\\OLE" wide
		$s6 = "ALPC Port" wide

	condition:
		int16 ( 0 ) == 0x5A4D and 4 of them
}
rule ESET_Apt_Windows_TA410_Tendyron_Installer
{
	meta:
		description = "TA410 Tendyron Installer"
		author = "ESET Research"
		id = "95ccad1c-99fb-5d38-aec0-650db3e06b35"
		date = "2020-12-09"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L55-L73"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "9c3afb924747614f27c31cf2c3d98f4932a9d11597a3ac94263bf93be02801da"
		score = 75
		quality = 80
		tags = ""
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$s1 = "Tendyron" wide
		$s2 = "OnKeyToken_KEB.dll" wide
		$s3 = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run" wide
		$s4 = "Global\\8D32CCB321B2"
		$s5 = "\\RTFExploit\\"

	condition:
		int16 ( 0 ) == 0x5A4D and 3 of them
}
rule ESET_Apt_Windows_TA410_Tendyron_Downloader
{
	meta:
		description = "TA410 Tendyron Downloader"
		author = "ESET Research"
		id = "afd8a2a7-8d58-5a96-b9e0-6f8b859e83c5"
		date = "2020-12-09"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L75-L107"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "16030a78ae9af8783f5913644294ceff861c8264ead8ca99435032be6d7949ef"
		score = 75
		quality = 80
		tags = ""
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$chunk_1 = {
            8A 10
            80 F2 5C
            80 C2 5C
            88 10
            40
            83 E9 01
            75 ??
        }
		$s1 = "startModule" fullword

	condition:
		int16 ( 0 ) == 0x5A4D and all of them
}
rule ESET_Apt_Windows_TA410_X4_Strings
{
	meta:
		description = "Matches various strings found in TA410 X4"
		author = "ESET Research"
		id = "e6af4516-8b79-5182-8571-7dd530632ddc"
		date = "2020-10-09"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L109-L125"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "d4b2321a6d0eb0ca8d7c47596af2a45c22b3aef15d1832d64d6588a62cab312a"
		score = 75
		quality = 74
		tags = ""
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$s1 = "[X]InLoadSC" ascii wide nocase
		$s3 = "MachineKeys\\Log\\rsa.txt" ascii wide nocase
		$s4 = "MachineKeys\\Log\\output.log" ascii wide nocase

	condition:
		any of them
}
rule ESET_Apt_Windows_TA410_X4_Hash_Values : FILE
{
	meta:
		description = "Matches X4 hash function found in TA410 X4"
		author = "ESET Research"
		id = "859bb977-82d0-5314-b1a8-fb3bb06a1b28"
		date = "2020-10-09"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L127-L149"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "bcf3891ff888ca99af9aa0e239b29241ae819022607fb829c5731267add308ea"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$s1 = {D1 10 76 C2 B6 03}
		$s2 = {71 3E A8 0D}
		$s3 = {DC 78 94 0E}
		$s4 = {40 0D E7 D6 06}
		$s5 = {83 BB FD E8 06}
		$s6 = {92 9D 9B FF EC 03}
		$s7 = {DD 0E FC FA F5 03}
		$s8 = {15 60 1E FB F5 03}

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule ESET_Apt_Windows_TA410_X4_Hash_Fct : FILE
{
	meta:
		description = "Matches X4 hash function found in TA410 X4"
		author = "ESET Research"
		id = "5ca435a4-7c6e-594d-8c4d-d577735884e6"
		date = "2020-10-09"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L151-L187"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "3b2d44cb7685a99e9aeb08f886f6876d43ee99d1e52e40705c3fa97ce3bfa9a0"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$chunk_1 = {
            0F B6 01
            84 C0
            74 ??
            48 69 D2 83 00 00 00
            48 0F BE C0
            48 03 D0
            48 FF C1
            E9 ?? ?? ?? ??
        }

	condition:
		uint16( 0 ) == 0x5a4d and any of them
}
rule ESET_Apt_Windows_TA410_Lookback_Decryption : FILE
{
	meta:
		description = "Matches encryption/decryption function used by LookBack."
		author = "ESET Research"
		id = "91947c6b-f357-5cf8-8522-4dcd517d01cb"
		date = "2021-10-12"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L189-L254"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "016dca6be654fcd193acc481e6a998efbb77e7ebd09b26614422be1136dd02c0"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$initialize = {
            8B C6           //mov eax, esi
            99              //cdq
            83 E2 03        //and edx, 3
            03 C2           //add eax, edx
            C1 F8 02        //sar eax, 2
            8A C8           //mov cl, al
            02 C0           //add al, al
            02 C8           //add cl, al
            88 4C 34 10         //mov byte ptr [esp + esi + 0x10], cl
            46              //inc esi
            81 FE 00 01 00 00       //cmp esi, 0x100
            72 ??
        }
		$generate = {
            8A 94 1C 10 01 ?? ??    //mov dl, byte ptr [esp + ebx + 0x110]
            8D 8C 24 10 01 ?? ??    //lea ecx, [esp + 0x110]
            0F B6 C3        //movzx eax, bl
            0F B6 44 04 10      //movzx eax, byte ptr [esp + eax + 0x10]
            32 C2           //xor al, dl
            02 F0           //add dh, al
            0F B6 C6        //movzx eax, dh
            03 C8           //add ecx, eax
            0F B6 01        //movzx eax, byte ptr [ecx]
            88 84 1C 10 01 ?? ??    //mov byte ptr [esp + ebx + 0x110], al
            43              //inc ebx
            88 11           //mov byte ptr [ecx], dl
            81 FB 00 06 00 00       //cmp ebx, 0x600
            72 ??           //jb 0x10025930
        }
		$decrypt = {
            0F B6 C6        //movzx eax, dh
            8D 8C 24 10 01 ?? ??    //lea ecx, [esp + 0x110]
            03 C8           //add ecx, eax
            8A 19           //mov bl, byte ptr [ecx]
            8A C3           //mov al, bl
            02 C6           //add al, dh
            FE C6           //inc dh
            02 F8           //add bh, al
            0F B6 C7        //movzx eax, bh
            8A 94 04 10 01 ?? ??    //mov dl, byte ptr [esp + eax + 0x110]
            88 9C 04 10 01 ?? ??    //mov byte ptr [esp + eax + 0x110], bl
            88 11           //mov byte ptr [ecx], dl
            0F B6 C2        //movzx eax, dl
            0F B6 CB        //movzx ecx, bl
            33 C8           //xor ecx, eax
            8A 84 0C 10 01 ?? ??    //mov al, byte ptr [esp + ecx + 0x110]
            30 04 2E        //xor byte ptr [esi + ebp], al
            46              //inc esi
            3B F7           //cmp esi, edi
            7C ??           //jl 0x10025980
        }

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule ESET_Apt_Windows_TA410_Lookback_Loader : FILE
{
	meta:
		description = "Matches the modified function in LookBack libcurl loader."
		author = "ESET Research"
		id = "d0aac4f6-f72f-5adf-8f8f-9251bad70131"
		date = "2021-10-12"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L256-L309"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "98390dd664227ad747e5572771d12e7ebd2475d26db27e85508347ac6f44f3bf"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$chunk_1 = {
            FF 15 ?? ?? ?? ??      //call dword ptr [0x100530e0]
            6A 40          //push 0x40
            68 00 10 00 00     //push 0x1000
            68 F0 04 00 00     //push 0x4f0
            6A 00          //push 0
            FF 15 ?? ?? ?? ??      //call dword ptr [0x100530d4]
            8B E8          //mov ebp, eax
            B9 3C 01 00 00     //mov ecx, 0x13c
            BE 60 30 06 10     //mov esi, 0x10063060
            8B FD          //mov edi, ebp
            68 F0 04 00 00     //push 0x4f0
            F3 A5          //rep movsd dword ptr es:[edi], dword ptr [esi]
            55             //push ebp
            E8 ?? ?? ?? ??     //call 0x100258d0
            8B 0D ?? ?? ?? ??      //mov ecx, dword ptr [0x100530e4]
            A1 ?? ?? ?? ??     //mov eax, dword ptr [0x100530c8]
            68 6C 02 00 00     //push 0x26c
            89 4C 24 ??        //mov dword ptr [esp + 0x1c], ecx
            89 44 24 ??        //mov dword ptr [esp + 0x20], eax
            FF 15 ?? ?? ?? ??      //call dword ptr [0x10063038]
            8B D8          //mov ebx, eax
            B9 9B 00 00 00     //mov ecx, 0x9b
            BE 50 35 06 10     //mov esi, 0x10063550
            8B FB          //mov edi, ebx
            68 6C 02 00 00      //push 0x26c
            F3 A5          //rep movsd dword ptr es:[edi], dword ptr [esi]
            53             //push ebx
            E8 ?? ?? ?? ??     //call 0x100258d0
            83 C4 14           //add esp, 0x14
            8D 44 24 ??        //lea eax, [esp + 0x10]
            50             //push eax
            53             //push ebx
            8D 44 24 ??        //lea eax, [esp + 0x3c]
            50             //push eax
            A1 ?? ?? ?? ??     //mov eax, dword ptr [0x10063058]
            FF 74 24 ??        //push dword ptr [esp + 0x28]
            03 C5          //add eax, ebp
            FF D0          //call eax
        }

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}

rule ESET_Apt_Windows_TA410_Lookback_Strings : FILE
{
	meta:
		description = "Matches multiple strings and export names in TA410 LookBack."
		author = "ESET Research"
		id = "b693c468-5abf-579d-bc03-67f67339feb9"
		date = "2021-10-12"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L311-L331"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "d17ed604e3691c20fe489f95197b7b802ec951ed13d538fa6643449485b326b2"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$s1 = "SodomMainFree" ascii wide
		$s2 = "SodomMainInit" ascii wide
		$s3 = "SodomNormal.bin" ascii wide
		$s4 = "SodomHttp.bin" ascii wide
		$s5 = "sodom.ini" ascii wide
		$s6 = "SodomMainProc" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of them or pe.exports ( "SodomBodyLoad" ) or pe.exports ( "SodomBodyLoadTest" ) )
}
rule ESET_Apt_Windows_TA410_Lookback_HTTP : FILE
{
	meta:
		description = "Matches LookBack's hardcoded HTTP request"
		author = "ESET Research"
		id = "ca4ee437-5ac9-5715-90fb-e0e74a817bb5"
		date = "2021-10-12"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L333-L349"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "0e777f56136cd11d62abdf4f120410d5fe9cd522cfc06afbf085414a96279bf7"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$s1 = "POST http://%s/status.php?r=%d%d HTTP/1.1\x0d\nAccept: text/html, application/xhtml+xml, */*\x0d\nAccept-Language: en-us\x0d\nUser-Agent: %s\x0d\nContent-Type: application/x-www-form-urlencoded\x0d\nAccept-Encoding: gzip, deflate\x0d\nHost: %s\x0d\nContent-Length: %d\x0d\nConnection: Keep-Alive\x0d\nCache-Control: no-cache\x0d\n\x0d\n" ascii wide
		$s2 = "id=1&op=report&status="

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule ESET_Apt_Windows_TA410_Lookback_Magic : FILE
{
	meta:
		description = "Matches message header creation in LookBack."
		author = "ESET Research"
		id = "5a40a307-772b-5600-9e58-f4bc6dfe6711"
		date = "2021-10-12"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L351-L377"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "442a08a77fd2db03e507c0d5a32b17ab4e5936a209f7af23ef3c33a4b9f3d0d5"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$s1 = {
            C7 03 C2 2E AB 48           //mov dword ptr [ebx], 0x48ab2ec2
            ( A1 | 8B 15 ) ?? ?? ?? ??      //mov (eax | edx), x
            [0-1]               //push ebp
            89 ?3 04            //mov dword ptr [ebc + 4], reg
            8B 4? 24 ??             //mov reg, dword ptr [esp + X]
            89 4? 08            //mov dword ptr [ebx + 8], ??
            89 ?? 0C            //mov dword ptr [ebx + 0xc], ??
            8B 4? 24 ??             //mov reg, dword ptr [esp + X]
            [1-2]               //push 1 or 2 args
            E8 ?? ?? ?? ??          //call
        }

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule ESET_Apt_Windows_TA410_Flowcloud_Loader_Strings : FILE
{
	meta:
		description = "Matches various strings found in TA410 FlowCloud first stage."
		author = "ESET Research"
		id = "a3fb894f-8e26-5cbd-a1f2-8a9ab1db0901"
		date = "2021-10-12"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L379-L415"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "3c90723e009ffe2603910566ac52a324256676ee3ff128d94427681010e10e8b"
		score = 75
		quality = 78
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$key = "y983nfdicu3j2dcn09wur9*^&initialize(y4r3inf;'fdskaf'SKF"
		$s2 = "startModule" fullword
		$s4 = "auto_start_module" wide
		$s5 = "load_main_module_after_install" wide
		$s6 = "terminate_if_fail" wide
		$s7 = "clear_run_mru" wide
		$s8 = "install_to_vista" wide
		$s9 = "load_ext_module" wide
		$s10 = "sll_only" wide
		$s11 = "fail_if_already_installed" wide
		$s12 = "clear_hardware_info" wide
		$s13 = "av_check" wide fullword
		$s14 = "check_rs" wide
		$s15 = "check_360" wide
		$s16 = "responsor.dat" wide ascii
		$s17 = "auto_start_after_install_check_anti" wide fullword
		$s18 = "auto_start_after_install" wide fullword
		$s19 = "extern_config.dat" wide fullword
		$s20 = "is_hhw" wide fullword
		$s21 = "SYSTEM\\Setup\\PrintResponsor" wide
		$event = "Global\\Event_{201a283f-e52b-450e-bf44-7dc436037e56}" wide ascii
		$s23 = "invalid encrypto hdr while decrypting"

	condition:
		uint16( 0 ) == 0x5a4d and ( $key or $event or 5 of ( $s* ) )
}
rule ESET_Apt_Windows_TA410_Flowcloud_Header_Decryption : FILE
{
	meta:
		description = "Matches the function used to decrypt resources headers in TA410 FlowCloud"
		author = "ESET Research"
		id = "403c1845-bc25-5a49-8553-8a0be18d6970"
		date = "2022-04-27"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L417-L496"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "74b6c42bf2de159b2b0a15637e6bd94069367e3000c887714d6e3b50aa3646be"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$chunk_1 = {
            8B 1E
            8B CF
            D3 CB
            8D 0C 28
            83 C7 06
            30 18
            8B 1E
            D3 CB
            8D 0C 02
            30 58 ??
            8B 1E
            D3 CB
            8B 4C 24 ??
            03 C8
            30 58 ??
            8B 1E
            D3 CB
            8B 4C 24 ??
            03 C8
            30 58 ??
            8B 1E
            D3 CB
            8B 4C 24 ??
            03 C8
            83 C0 06
            30 58 ??
            8B 1E
            D3 CB
            30 58 ??
            83 FF 10
            72 ??
        }

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule ESET_Apt_Windows_TA410_Flowcloud_Dll_Hijacking_Strings : FILE
{
	meta:
		description = "Matches filenames inside TA410 FlowCloud malicious DLL."
		author = "ESET Research"
		id = "6636d4d0-0a7f-5971-a7f4-58803042d874"
		date = "2021-10-12"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L498-L517"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "e8082d4216364a12ba395f772b5caed94b3068d26a2b3a97ef711d61a82f65b3"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$dat1 = "emedres.dat" wide
		$dat2 = "vviewres.dat" wide
		$dat3 = "setlangloc.dat" wide
		$dll1 = "emedres.dll" wide
		$dll2 = "vviewres.dll" wide
		$dll3 = "setlangloc.dll" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $dat* ) or all of ( $dll* ) )
}
rule ESET_Apt_Windows_TA410_Flowcloud_Malicious_Dll_Antianalysis : FILE
{
	meta:
		description = "Matches anti-analysis techniques used in TA410 FlowCloud hijacking DLL."
		author = "ESET Research"
		id = "b38a1d4d-5053-5a6d-be8c-c00261936417"
		date = "2021-10-12"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L519-L552"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "8f14352118d32a43c17f70bd753acc48bd314965f10ab97818e8a434bbda96d9"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$chunk_1 = {
            33 C0
            E8 ?? ?? ?? ??
            83 C0 10
            3D 00 00 00 80
            7D 01
            EB FF
            E0 50
            C3
        }

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}

rule ESET_Apt_Windows_TA410_Flowcloud_Pdb : FILE
{
	meta:
		description = "Matches PDB paths found in TA410 FlowCloud."
		author = "ESET Research"
		id = "8bf25768-941e-55c6-bd21-f6b614c9d75d"
		date = "2021-10-12"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L554-L567"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "ff95ab0f8e68efe612a6e0d70cebd8bf815d6b5e3877c098ac0761382dc310d6"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	condition:
		uint16( 0 ) == 0x5a4d and ( pe.pdb_path contains "\\FlowCloud\\trunk\\" or pe.pdb_path contains "\\flowcloud\\trunk\\" )
}
rule ESET_Apt_Windows_TA410_Flowcloud_Shellcode_Decryption : FILE
{
	meta:
		description = "Matches the decryption function used in TA410 FlowCloud self-decrypting DLL"
		author = "ESET Research"
		id = "8af7b2fa-be40-5ec8-8413-1c982a463a9a"
		date = "2021-10-12"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L569-L615"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "939ffe6a41c957aa5d6c012484b2deab49a5e71a4b7e203a41c180f872803921"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$chunk_1 = {
            33 D2
            8B 45 ??
            BB 6B 04 00 00
            F7 F3
            81 C2 A8 01 00 00
            81 E2 FF 00 00 00
            8B 7D ??
            33 C9
            EB ??
            30 14 39
            00 14 39
            41
            3B 4D ??
            72 ??
        }

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule ESET_Apt_Windows_TA410_Flowcloud_Fcclient_Strings : FILE
{
	meta:
		description = "Strings found in fcClient/rescure.dat module."
		author = "ESET Research"
		id = "876bae0b-2612-559b-9ead-b633a3789663"
		date = "2021-10-12"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L617-L639"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "c05b7031a5aec1bcf29eca06c010c402edeb24a093a2043dbc21781dff22c7fe"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$s1 = "df257bdd-847c-490e-9ef9-1d7dc883d3c0"
		$s2 = "\\{2AFF264E-B722-4359-8E0F-947B85594A9A}"
		$s3 = "Global\\{26C96B51-2B5D-4D7B-BED1-3DCA4848EDD1}" wide
		$s4 = "{804423C2-F490-4ac3-BFA5-13DEDE63A71A}" wide
		$s5 = "{A5124AF5-DF23-49bf-B0ED-A18ED3DEA027}" wide
		$s6 = "XXXModule_func.dll"
		$driver1 = "\\drivers\\hidmouse.sys" wide fullword
		$driver2 = "\\drivers\\hidusb.sys" wide fullword

	condition:
		uint16( 0 ) == 0x5a4d and ( any of ( $s* ) or all of ( $driver* ) )
}
rule ESET_Apt_Windows_TA410_Flowcloud_Fcclientdll_Strings : FILE
{
	meta:
		description = "Strings found in fcClientDll/responsor.dat module."
		author = "ESET Research"
		id = "80ecaf51-406f-590c-8f9c-59672683de02"
		date = "2021-10-12"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L641-L669"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "3a93f58cf14b57a96157077ec14aa6fb181e3da80f4ba46c0379a58b67c08a0e"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$s1 = "http://%s/html/portlet/ext/draco/resources/draco_manager.swf/[[DYNAMIC]]/1"
		$s2 = "Cookie: COOKIE_SUPPORT=true; JSESSIONID=5C7E7A60D01D2891F40648DAB6CB3DF4.jvm1; COMPANY_ID=10301; ID=666e7375545678695645673d; PASSWORD=7a4b48574d746470447a303d; LOGIN=6863303130; SCREEN_NAME=4a2b455377766b657451493d; GUEST_LANGUAGE_ID=en-US"
		$fc_msg = ".fc_net.msg"
		$s4 = "\\pipe\\namedpipe_keymousespy_english" wide
		$s5 = "8932910381748^&*^$58876$%^ghjfgsa413901280dfjslajflsdka&*(^7867=89^&*F(^&*5678f5ds765f76%&*%&*5"
		$s6 = "cls_{CACB140B-0B82-4340-9B05-7983017BA3A4}" wide
		$s7 = "HTTP/1.1 200 OK\x0d\nServer: Apache-Coyote/1.1\x0d\nPragma: No-cache\x0d\nCache-Control: no-cache\x0d\nExpires: Thu, 01 Jan 1970 08:00:00 CST\x0d\nLast-Modified: Fri, 27 Apr 2012 08:11:04 GMT\x0d\nContent-Type: application/xml\x0d\nContent-Length: %d\x0d\nDate: %s GMT"
		$sql1 = "create table if not exists table_filed_space"
		$sql2 = "create table if not exists clipboard"
		$sql3 = "create trigger if not exists file_after_delete after delete on file"
		$sql4 = "create trigger if not exists file_data_after_insert after insert on file_data"
		$sql5 = "create trigger if not exists file_data_after_delete after delete on file_data"
		$sql6 = "create trigger if not exists file_data_after_update after update on file_data"
		$sql7 = "insert into file_data(file_id, ofs, data, status)"

	condition:
		uint16( 0 ) == 0x5a4d and ( any of ( $s* ) or #fc_msg >= 8 or 4 of ( $sql* ) )
}
rule ESET_Apt_Windows_TA410_Rootkit_Strings : FILE
{
	meta:
		description = "Strings found in TA410's Rootkit"
		author = "ESET Research"
		id = "a6a97721-571e-5414-9b00-5789d7bcd078"
		date = "2021-10-12"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L671-L697"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "1d3ad63508c5e4bca32b9a44b738cb4a7384ccfa5704ce329260adb342ea4e60"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$driver1 = "\\Driver\\kbdclass" wide
		$driver2 = "\\Driver\\mouclass" wide
		$device1 = "\\Device\\KeyboardClass0" wide
		$device2 = "\\Device\\PointerClass0" wide
		$driver3 = "\\Driver\\tcpip" wide
		$device3 = "\\Device\\tcp" wide
		$driver4 = "\\Driver\\nsiproxy" wide
		$device4 = "\\Device\\Nsi" wide
		$reg1 = "\\Registry\\Machine\\SYSTEM\\Setup\\AllowStart\\ceipCommon" wide
		$reg2 = "RHH%d" wide
		$reg3 = "RHP%d" wide
		$s1 = "\\SystemRoot\\System32\\drivers\\hidmouse.sys" wide

	condition:
		uint16( 0 ) == 0x5a4d and all of ( $s1 , $reg* ) and ( all of ( $driver* ) or all of ( $device* ) )
}

rule ESET_Apt_Windows_TA410_Flowcloud_V5_Resources : FILE
{
	meta:
		description = "Matches sequence of PE resource IDs found in TA410 FlowCloud version 5.0.2"
		author = "ESET Research"
		id = "05a233f0-a823-5154-a47d-cede722d4710"
		date = "2021-10-12"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L699-L720"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "58f75dda53c6d4b3d88f464c452d855ac6dc88add5f4fba2641f52e7a1ae00ed"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	condition:
		uint16( 0 ) == 0x5a4d and pe.number_of_resources >= 13 and for 12 resource in pe.resources : ( resource.type == 10 and resource.language == 1033 and ( resource.name_string == "1\x000\x000\x00" or resource.name_string == "1\x000\x000\x000\x00" or resource.name_string == "1\x000\x000\x000\x000\x00" or resource.name_string == "1\x000\x000\x001\x00" or resource.name_string == "1\x000\x001\x00" or resource.name_string == "1\x000\x002\x00" or resource.name_string == "1\x000\x003\x00" or resource.name_string == "1\x000\x004\x00" or resource.name_string == "1\x000\x005\x00" or resource.name_string == "1\x000\x006\x00" or resource.name_string == "1\x000\x007\x00" or resource.name_string == "1\x000\x008\x00" or resource.name_string == "1\x000\x009\x00" or resource.name_string == "1\x001\x000\x00" or resource.name_string == "2\x000\x000\x000\x00" or resource.name_string == "2\x000\x000\x001\x00" ) )
}

rule ESET_Apt_Windows_TA410_Flowcloud_V4_Resources : FILE
{
	meta:
		description = "Matches sequence of PE resource IDs found in TA410 FlowCloud version 4.1.3"
		author = "ESET Research"
		id = "57b98823-439f-5a2c-a8cb-ac5e98953b06"
		date = "2021-10-12"
		modified = "2022-04-27"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/ta410/ta410.yar#L722-L741"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "7b475cfddb5f995f7e8e3293b8e6ae59a9e36143998bc444499b5dce467f8e9d"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	condition:
		uint16( 0 ) == 0x5a4d and pe.number_of_resources >= 6 and for 5 resource in pe.resources : ( resource.type == 10 and resource.language == 1033 and ( resource.name_string == "1\x000\x000\x000\x000\x00" or resource.name_string == "1\x000\x000\x000\x001\x00" or resource.name_string == "1\x000\x000\x000\x002\x00" or resource.name_string == "1\x000\x000\x000\x003\x00" or resource.name_string == "1\x000\x000\x000\x004\x00" or resource.name_string == "1\x000\x000\x000\x005\x00" or resource.name_string == "1\x000\x001\x000\x000\x00" ) )
}
rule ESET_Cw_Windows_Redline_Panel_Tab_Headers : FILE
{
	meta:
		description = "Matches view headers in Redline Panel"
		author = "ESET Research"
		id = "44a95845-b0a3-59c1-8188-86d415eff0bf"
		date = "2022-10-11"
		modified = "2024-11-12"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/redline/redline.yar#L32-L55"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		hash = "a154dfaedc237c047f419eb6884dab1ef4e2a17d"
		logic_hash = "3198aa9df2814a5f1d5568c6eed5f3189b2f72b3928cc97645f9bf57eebab9ac"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = 2

	strings:
		$ = "RedLine | Log In"
		$ = "RedLine | Autofilles Viewer"
		$ = "RedLine | Choose Browser"
		$ = "RedLine | Cookie Viewer"
		$ = "RedLine | Credit Card Viewer"
		$ = "RedLine | Files Viewer"
		$ = "RedLine | Log saver"
		$ = "RedLine | System Info Viewer"

	condition:
		uint16( 0 ) == 0x5A4D and 6 of them
}
rule ESET_Cw_Windows_Redline_Panel_Distinctive_Strings : FILE
{
	meta:
		description = "Matches rare strings found in Redline panel"
		author = "ESET Research"
		id = "d40ccb6b-e777-5c05-b97c-ead910047649"
		date = "2022-10-11"
		modified = "2024-11-12"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/redline/redline.yar#L57-L77"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		hash = "a154dfaedc237c047f419eb6884dab1ef4e2a17d"
		logic_hash = "7ff0239426c4c3b46a269fad71232295c038c09f276cdc3c7f1142c830260a6d"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = 2

	strings:
		$env_var = "%DSK_23%"
		$fn_name = "IsGratherThan"
		$telegram0 = "Telegram: @REDLINESUPPORT"
		$telegram1 = "https://t.me/REDLINESUPPORT"

	condition:
		uint16( 0 ) == 0x5A4D and any of them
}
rule ESET_Cw_Windows_Redline_Panel_Prompts : FILE
{
	meta:
		description = "Matches prompt messages in Redline panel"
		author = "ESET Research"
		id = "3481586b-ed4b-5a27-82a0-0bbb3eea279e"
		date = "2022-10-11"
		modified = "2024-11-12"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/redline/redline.yar#L79-L113"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		hash = "a154dfaedc237c047f419eb6884dab1ef4e2a17d"
		logic_hash = "0dfab05a9383ba13b3c610f1ab0c81e95804470002f27171ab39706f7723983a"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = 2

	strings:
		$ = "Choose directory to save log"
		$ = "Select log to set comment"
		$ = "Please enter an action to create new task"
		$ = "Please enter a target to create new task"
		$ = "Please enter a final point to create new task"
		$ = "Please enter a correct action to create new task"
		$ = "Please enter a correct final point to create new task"
		$ = "Please enter an action to edit task"
		$ = "Please enter a target to edit task"
		$ = "Please enter a final point to edit task"
		$ = "Please enter a correct action to edit task"
		$ = "Please enter a correct final point to edit task"
		$ = "Please enter a correct status to edit task"
		$ = "Please, enter a domains"
		$ = "Please, enter a valid server ip"
		$ = "Choose a file to pump"
		$ = "Enter a valid count of bytes"
		$ = "Enter a valid count of bytes. Must be more then zero"
		$ = "Disconnected. Reboot your panel"

	condition:
		uint16( 0 ) == 0x5A4D and 10 of them
}
rule ESET_Cw_Windows_Redline_Panel_Status_Message_Strings : FILE
{
	meta:
		description = "Matches error/success messages in Redline panel"
		author = "ESET Research"
		id = "70bdff10-9c86-57e3-b839-e86173a44855"
		date = "2022-10-11"
		modified = "2024-11-12"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/redline/redline.yar#L115-L142"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		hash = "a154dfaedc237c047f419eb6884dab1ef4e2a17d"
		logic_hash = "c60fabc81967b083be72ff564af744ab60441de5d563ea6d88d873c0a99bfbdd"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = 1

	strings:
		$ = "All Browsers are empty"
		$ = "Client [{0}:{1}:{2}] completed task with {3} ID."
		$ = "A List of logs cleared"
		$ = "Browsers not found"
		$ = "Browsers is empty"
		$ = "Done. Check your build file"
		$ = "You must to enable assembly info or certificate in settings"
		$ = "Duplicate log from "
		$ = "Password list is empty"
		$ = "Cookie list is empty"
		$ = "FTPs not found"
		$ = "Files not found"

	condition:
		uint16( 0 ) == 0x5A4D and 8 of them
}
rule ESET_Apt_Windows_Invisimole_Logs : FILE
{
	meta:
		description = "Detects log files with collected created by InvisiMole's RC2CL backdoor"
		author = "ESET Research"
		id = "151883ad-1f44-55b4-b12a-f0d399527189"
		date = "2021-05-17"
		modified = "2021-05-17"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/invisimole/invisimole.yar#L54-L77"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "d42423ccc768f1823c76d5cb2aec26434c796fc35bd4e2fbf435fcf7997d3ff0"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	condition:
		uint32( 0 ) == 0x08F1CAA1 or uint32( 0 ) == 0x08F1CAA2 or uint32( 0 ) == 0x08F1CCC0 or uint32( 0 ) == 0x08F2AFC0 or uint32( 0 ) == 0x083AE4DF or uint32( 0 ) == 0x18F2CBB1 or uint32( 0 ) == 0x1900ABBA or uint32( 0 ) == 0x24F2CEA1 or uint32( 0 ) == 0xDA012193 or uint32( 0 ) == 0xDA018993 or uint32( 0 ) == 0xDA018995 or uint32( 0 ) == 0xDD018991
}
rule ESET_Apt_Windows_Invisimole_SFX_Dropper : FILE
{
	meta:
		description = "Detects trojanized InvisiMole files: patched RAR SFX droppers with added InvisiMole blobs (config encrypted XOR 2A at the end of a file)"
		author = "ESET Research"
		id = "08490bcd-3139-5fac-9c6c-5a32acb7217a"
		date = "2021-05-17"
		modified = "2021-05-17"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/invisimole/invisimole.yar#L79-L95"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "6ca248d42c1e889988e5931d80df071cb20e623fb0c4a208044cabe073f71ce4"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$encrypted_config = {5F 59 4F 58 19 18 04 4E 46 46 2A 5D 59 5A 58 43 44 5E 4C 7D 2A 0F 2A 59 2A 78 2A 4B 2A 58 2A 0E 2A 6F 2A 72 2A 4B 2A 0F 2A 4E 2A 04 2A 0F 2A 4E 2A 76 2A 0F 2A 79 2A 2A 2A 79 42 4F 46 46 6F 52 4F 49 5F 5E 4F 7D 2A 79 42 4F 46 46 19 18 04 4E 46 46 2A 7C 43 58 5E 5F 4B 46 6B 46 46 45 49 2A 66 45 4B 4E 66 43 48 58 4B 58 53 6B}

	condition:
		uint16( 0 ) == 0x5A4D and $encrypted_config
}
rule ESET_Apt_Windows_Invisimole_CPL_Loader : FILE
{
	meta:
		description = "CPL loader"
		author = "ESET Research"
		id = "feff8627-6085-5835-ac1b-d4522245f7db"
		date = "2021-05-17"
		modified = "2021-05-17"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/invisimole/invisimole.yar#L97-L118"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "cd5c19e14faa7fd3758b30193ccf2bed3692ad29d8216466523ca25d2abcfe88"
		score = 75
		quality = 80
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$s1 = "WScr%steObject(\"WScr%s.Run(\"::{20d04fe0-3a%s30309d}\\\\::{21EC%sDD-08002B3030%s\", 0);"
		$s2 = "\\Control.js" wide
		$s3 = "\\Control Panel.lnk" wide
		$s4 = "FPC 3.0.4 [2019/04/13] for x86_64 - Win64"
		$s5 = "FPC 3.0.4 [2019/04/13] for i386 - Win32"
		$s6 = "imageapplet.dat" wide
		$s7 = "wkssvmtx"

	condition:
		uint16( 0 ) == 0x5A4D and ( 3 of them )
}

rule ESET_Apt_Windows_Invisimole_Wrapper_DLL
{
	meta:
		description = "Detects InvisiMole wrapper DLL with embedded RC2CL and RC2FM backdoors, by export and resource names"
		author = "ESET Research"
		id = "b9609b09-3ef5-5793-a3aa-4692cec367d9"
		date = "2021-05-17"
		modified = "2021-05-17"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/invisimole/invisimole.yar#L120-L138"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "156bc5bc7b0ed5c77a5a15e7799a3077d40150896476a60935cf21a9afe36856"
		score = 75
		quality = 80
		tags = ""
		license = "BSD 2-Clause"
		version = "1"

	condition:
		pe.exports( "GetDataLength" ) and for any y in ( 0 .. pe.number_of_resources - 1 ) : ( pe.resources [ y ] . type == pe.RESOURCE_TYPE_RCDATA and pe.resources [ y ] . name_string == "R\x00C\x002\x00C\x00L\x00" ) and for any y in ( 0 .. pe.number_of_resources - 1 ) : ( pe.resources [ y ] . type == pe.RESOURCE_TYPE_RCDATA and pe.resources [ y ] . name_string == "R\x00C\x002\x00F\x00M\x00" )
}
private rule ESET_Invisimole_Blob_PRIVATE
{
	meta:
		description = "Detects InvisiMole blobs by magic values"
		author = "ESET Research"
		id = "6a179d91-50f1-5400-b141-0f162efd2431"
		date = "2021-05-17"
		modified = "2021-05-17"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/invisimole/invisimole.yar#L34-L52"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "8bddaf874da58fbe6362498f8979b511f39531fe2b98d4be8c099bdafb6d0067"
		score = 75
		quality = 80
		tags = ""
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$magic_old_32 = {F9 FF D0 DE}
		$magic_old_64 = {64 FF D0 DE}
		$magic_new_32 = {86 DA 11 CE}
		$magic_new_64 = {64 DA 11 CE}

	condition:
		($magic_old_32 at 0 ) or ( $magic_old_64 at 0 ) or ( $magic_new_32 at 0 ) or ( $magic_new_64 at 0 )
}
rule ESET_Richheaders_Lazarus_Nukesped_Iconicpayloads_3CX_Q12023
{
	meta:
		description = "Rich Headers-based rule covering the IconicLoader and IconicStealer from the 3CX supply chain incident, and also payloads from the cryptocurrency campaigns from 2022-12"
		author = "ESET Research"
		id = "5c815d14-8a3e-5c6a-9dc3-988e0f31c094"
		date = "2023-03-31"
		modified = "2023-04-19"
		reference = "https://github.com/eset/malware-ioc"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/nukesped_lazarus/rich_headers_IconicPayloads_3CX.yar#L6-L23"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		hash = "3b88cda62cdd918b62ef5aa8c5a73a46f176d18b"
		hash = "cad1120d91b812acafef7175f949dd1b09c6c21a"
		hash = "5b03294b72c0caa5fb20e7817002c600645eb475"
		hash = "7491bd61ed15298ce5ee5ffd01c8c82a2cdb40ec"
		logic_hash = "f11a1db798bfcc534982bdf6afaae154b095b6a1e0896e75e2791c01e51a1c16"
		score = 75
		quality = 80
		tags = ""

	condition:
		pe.rich_signature.toolid( 259 , 30818 ) == 9 and pe.rich_signature.toolid ( 256 , 31329 ) == 1 and pe.rich_signature.toolid ( 261 , 30818 ) >= 30 and pe.rich_signature.toolid ( 261 , 30818 ) <= 38 and pe.rich_signature.toolid ( 261 , 29395 ) >= 134 and pe.rich_signature.toolid ( 261 , 29395 ) <= 164 and pe.rich_signature.toolid ( 257 , 29395 ) >= 6 and pe.rich_signature.toolid ( 257 , 29395 ) <= 14
}

private rule ESET_IIS_Native_Module_PRIVATE : FILE
{
	meta:
		description = "Signature to match an IIS native module (clean or malicious)"
		author = "ESET Research"
		id = "e3bacdc8-fde1-5e83-ac94-79fc345e888d"
		date = "2021-08-04"
		modified = "2021-08-04"
		reference = "https://github.com/eset/malware-ioc/"
		source_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/badiis/badiis.yar#L34-L92"
		license_url = "https://github.com/eset/malware-ioc/blob/8921a81d245cce3f9b7a199b123d221ed8f1fe33/LICENSE"
		logic_hash = "5a388dc3253df606e2648d1f9c018e6dde373bbddce66dba69b7aecdd95bac18"
		score = 75
		quality = 55
		tags = "FILE"
		license = "BSD 2-Clause"
		version = "1"

	strings:
		$e1 = "This module subscribed to event"
		$e2 = "CHttpModule::OnBeginRequest"
		$e3 = "CHttpModule::OnPostBeginRequest"
		$e4 = "CHttpModule::OnAuthenticateRequest"
		$e5 = "CHttpModule::OnPostAuthenticateRequest"
		$e6 = "CHttpModule::OnAuthorizeRequest"
		$e7 = "CHttpModule::OnPostAuthorizeRequest"
		$e8 = "CHttpModule::OnResolveRequestCache"
		$e9 = "CHttpModule::OnPostResolveRequestCache"
		$e10 = "CHttpModule::OnMapRequestHandler"
		$e11 = "CHttpModule::OnPostMapRequestHandler"
		$e12 = "CHttpModule::OnAcquireRequestState"
		$e13 = "CHttpModule::OnPostAcquireRequestState"
		$e14 = "CHttpModule::OnPreExecuteRequestHandler"
		$e15 = "CHttpModule::OnPostPreExecuteRequestHandler"
		$e16 = "CHttpModule::OnExecuteRequestHandler"
		$e17 = "CHttpModule::OnPostExecuteRequestHandler"
		$e18 = "CHttpModule::OnReleaseRequestState"
		$e19 = "CHttpModule::OnPostReleaseRequestState"
		$e20 = "CHttpModule::OnUpdateRequestCache"
		$e21 = "CHttpModule::OnPostUpdateRequestCache"
		$e22 = "CHttpModule::OnLogRequest"
		$e23 = "CHttpModule::OnPostLogRequest"
		$e24 = "CHttpModule::OnEndRequest"
		$e25 = "CHttpModule::OnPostEndRequest"
		$e26 = "CHttpModule::OnSendResponse"
		$e27 = "CHttpModule::OnMapPath"
		$e28 = "CHttpModule::OnReadEntity"
		$e29 = "CHttpModule::OnCustomRequestNotification"
		$e30 = "CHttpModule::OnAsyncCompletion"
		$e31 = "CGlobalModule::OnGlobalStopListening"
		$e32 = "CGlobalModule::OnGlobalCacheCleanup"
		$e33 = "CGlobalModule::OnGlobalCacheOperation"
		$e34 = "CGlobalModule::OnGlobalHealthCheck"
		$e35 = "CGlobalModule::OnGlobalConfigurationChange"
		$e36 = "CGlobalModule::OnGlobalFileChange"
		$e37 = "CGlobalModule::OnGlobalApplicationStart"
		$e38 = "CGlobalModule::OnGlobalApplicationResolveModules"
		$e39 = "CGlobalModule::OnGlobalApplicationStop"
		$e40 = "CGlobalModule::OnGlobalRSCAQuery"
		$e41 = "CGlobalModule::OnGlobalTraceEvent"
		$e42 = "CGlobalModule::OnGlobalCustomNotification"
		$e43 = "CGlobalModule::OnGlobalThreadCleanup"
		$e44 = "CGlobalModule::OnGlobalApplicationPreload"

	condition:
		uint16( 0 ) == 0x5A4D and pe.exports ( "RegisterModule" ) and any of ( $e* )
}
rule FIREEYE_RT_Hacktool_MSIL_Wmisharp_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'WMISharp' project."
		author = "FireEye"
		id = "97b9d057-30d3-5af7-bac6-4dd53f47650f"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/WMISHARP/production/yara/HackTool_MSIL_WMISharp_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "d119d52c1410291d582696d5c4c1de3db9008db963c76a9e344959d869c3acc0"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 1

	strings:
		$typelibguid0 = "3a2421d9-c1aa-4fff-ad76-7fcb48ed4bff" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Hacktool_MSIL_Prepshellcode_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'PrepShellcode' project."
		author = "FireEye"
		id = "32fb6b1d-e01f-5555-8516-088dca2166cf"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/PREPSHELLCODE/production/yara/HackTool_MSIL_PrepShellcode_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "aedae87d84275f6589c982c04175ddc0aee3e4f3ae959ced4b4e2294675522e6"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid0 = "d16ed275-70d5-4ae5-8ce7-d249f967616c" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Loader_Raw64_REDFLARE_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "8e937f6a-404f-53bd-9de2-ed63b1cf48b2"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/production/yara/APT_Loader_Raw64_REDFLARE_1.yar#L4-L16"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "5e14f77f85fd9a5be46e7f04b8a144f5"
		logic_hash = "dac122ccece8a6dd35a5fe9d37860a612aa50ab469b79f4375dbe776f60c7b57"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-27"
		date_modified = "2020-11-27"
		rev = 1

	strings:
		$load = { EB ?? 58 48 8B 10 4C 8B 48 ?? 48 8B C8 [1-10] 48 83 C1 ?? 48 03 D1 FF }

	condition:
		( uint16( 0 ) != 0x5A4D ) and all of them
}
rule FIREEYE_RT_APT_Builder_PY_REDFLARE_1
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "3b5ad25d-ce66-572e-9a91-40a73b8fd447"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/production/yara/APT_Builder_PY_REDFLARE_1.yar#L4-L22"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "d0a830403e56ebaa4bfbe87dbfdee44f"
		logic_hash = "1948cadb7242eb69bffbc222802ce9c1af38d7a846da09b6343b1449fe054e42"
		score = 75
		quality = 75
		tags = ""
		date_created = "2020-11-27"
		date_modified = "2020-11-27"
		rev = 1

	strings:
		$1 = "LOAD_OFFSET_32 = 0x612"
		$2 = "LOAD_OFFSET_64 = 0x611"
		$3 = "class RC4:"
		$4 = "struct.pack('<Q' if is64b else '<L'"
		$5 = "stagerConfig['comms']['config']"
		$6 = "_x86.dll"
		$7 = "_x64.dll"

	condition:
		all of them and @1 [ 1 ] < @2 [ 1 ] and @2 [ 1 ] < @3 [ 1 ] and @3 [ 1 ] < @4 [ 1 ] and @4 [ 1 ] < @5 [ 1 ]
}
rule FIREEYE_RT_APT_Downloader_Win64_REDFLARE_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "15a5e22b-84b0-5b36-8772-1d496ac447b2"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/production/yara/APT_Downloader_Win64_REDFLARE_1.yar#L4-L17"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "9529c4c9773392893a8a0ab8ce8f8ce1"
		logic_hash = "1b9bece6083403615841c752eac48fd20095e918d6e175563dd122be2885d875"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-27"
		date_modified = "2020-11-27"
		rev = 2

	strings:
		$const = "Cookie: SID1=%s" fullword
		$http_req = { 00 00 08 80 81 3D [4] BB 01 00 00 75 [1-10] 00 00 80 00 [1-4] 00 10 00 00 [1-4] 00 20 00 00 89 [6-20] 00 00 00 00 [6-20] 00 00 00 00 [2-10] 00 00 00 00 45 33 C9 [4-20] 48 8D 15 [4] 48 8B 0D [4] FF 15 [4-50] B9 14 00 00 00 E8 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) and all of them
}
rule FIREEYE_RT_APT_Controller_Linux_REDFLARE_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "79a69740-7209-5c56-ad6f-eb4d0b29beaf"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/production/yara/APT_Controller_Linux_REDFLARE_1.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "79259451ff47b864d71fb3f94b1774f3, 82773afa0860d668d7fe40e3f22b0f3e"
		logic_hash = "d6b0cc5f386da9bff8a8293f2b3857406044ab42f7c1bb23d5096052a3c42ce4"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-02"
		date_modified = "2020-12-02"
		rev = 1

	strings:
		$1 = "/RedFlare/gorat_server"
		$2 = "RedFlare/sandals"
		$3 = "goratsvr.CommandResponse" fullword
		$4 = "goratsvr.CommandRequest" fullword

	condition:
		( uint32( 0 ) == 0x464c457f ) and all of them
}
rule FIREEYE_RT_APT_Trojan_Win_REDFLARE_8 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "b090df60-8f4e-51ca-944c-6f9ce2d9c913"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/production/yara/APT_Trojan_Win_REDFLARE_8.yar#L4-L22"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "9c8eb908b8c1cda46e844c24f65d9370, 9e85713d615bda23785faf660c1b872c"
		logic_hash = "5b8a0402886daebefb995e7df0877d51727c5b8dc58eeb8ff16ceec5e7811a20"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-02"
		date_modified = "2020-12-02"
		rev = 1

	strings:
		$1 = "PSRunner.PSRunner" fullword
		$2 = "CorBindToRuntime" fullword
		$3 = "ReportEventW" fullword
		$4 = "InvokePS" fullword wide
		$5 = "runCommand" fullword
		$6 = "initialize" fullword
		$trap = { 03 40 00 80 E8 [4] CC }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_APT_Loader_Win32_REDFLARE_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "b8a2c388-3b27-5075-b0ee-2773ae0c67ad"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/production/yara/APT_Loader_Win32_REDFLARE_1.yar#L4-L17"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "01d68343ac46db6065f888a094edfe4f"
		logic_hash = "f9165aabe4bad215211cf98559099030ddb8a76175fbfcfee3c6f25d7614bdad"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-27"
		date_modified = "2020-11-27"
		rev = 1

	strings:
		$alloc_n_load = { 6A 40 68 00 30 00 00 [0-20] 6A 00 [0-20] FF D0 [4-60] F3 A4 [30-100] 6B C0 28 8B 4D ?? 8B 4C 01 10 8B 55 ?? 6B D2 28 }
		$const_values = { 0F B6 ?? 83 C? 20 83 F? 6D [2-20] 83 C? 20 83 F? 7A }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x010B ) and all of them
}
rule FIREEYE_RT_APT_Trojan_Win_REDFLARE_5 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "892981d6-f310-5ee8-95b5-dd4bd720a86c"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/production/yara/APT_Trojan_Win_REDFLARE_5.yar#L4-L20"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dfbb1b988c239ade4c23856e42d4127b, 3322fba40c4de7e3de0fda1123b0bf5d"
		logic_hash = "ab38e5ebded026829672941709797b40f8e13fb244b6a8ed3545de4358f727b8"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-01"
		date_modified = "2020-12-01"
		rev = 3

	strings:
		$s1 = "AdjustTokenPrivileges" fullword
		$s2 = "LookupPrivilegeValueW" fullword
		$s3 = "ImpersonateLoggedOnUser" fullword
		$s4 = "runCommand" fullword
		$steal_token = { FF 15 [4] 85 C0 [1-40] C7 44 24 ?? 01 00 00 00 [0-20] C7 44 24 ?? 02 00 00 00 [0-20] FF 15 [4] FF [1-5] 85 C0 [4-40] 00 04 00 00 FF 15 [4-5] 85 C0 [2-20] ( BA 0F 00 00 00 | 6A 0F ) [1-4] FF 15 [4] 85 C0 74 [1-20] FF 15 [4] 85 C0 74 [1-20] ( 6A 0B | B9 0B 00 00 00 ) E8 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_APT_Loader_Win32_REDFLARE_2 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "6a585401-bfd3-5aad-b484-09b6a30d9af5"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/production/yara/APT_Loader_Win32_REDFLARE_2.yar#L4-L17"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "4e7e90c7147ee8aa01275894734f4492"
		logic_hash = "98dfb71adbde4f8965e612c19f0965d8fa95805825569290fdf72eb1d86cfb70"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-27"
		date_modified = "2020-11-27"
		rev = 1

	strings:
		$inject = { 83 F8 01 [4-50] 6A 00 6A 00 68 04 00 00 08 6A 00 6A 00 6A 00 6A 00 5? [10-70] FF 15 [4] 85 C0 [1-20] 6A 04 68 00 10 00 00 5? 6A 00 5? [1-10] FF 15 [4-8] 85 C0 [1-20] 5? 5? 5? 8B [1-4] 5? 5? FF 15 [4] 85 C0 [1-20] 6A 20 [4-20] FF 15 [4] 85 C0 [1-40] 01 00 01 00 [2-20] FF 15 [4] 85 C0 [1-30] FF 15 [4] 85 C0 [1-20] FF 15 [4] 83 F8 FF }
		$s1 = "ResumeThread"

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x010B ) and all of them
}
rule FIREEYE_RT_APT_Trojan_Win_REDFLARE_4 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "6e8621b0-a0ee-5fc7-a2b8-1973a42d6e37"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/production/yara/APT_Trojan_Win_REDFLARE_4.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "a8b5dcfea5e87bf0e95176daa243943d, 9dcb6424662941d746576e62712220aa"
		logic_hash = "d027e98ad8fa6d03a49ceffd81fba6a621173e2dbabae652bee2f4e8489bb378"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-01"
		date_modified = "2020-12-01"
		rev = 2

	strings:
		$s1 = "LogonUserW" fullword
		$s2 = "ImpersonateLoggedOnUser" fullword
		$s3 = "runCommand" fullword
		$user_logon = { 22 02 00 00 [1-10] 02 02 00 00 [0-4] E8 [4-40] ( 09 00 00 00 [1-10] 03 00 00 00 | 6A 03 6A 09 ) [4-30] FF 15 [4] 85 C0 7? }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_APT_Keylogger_Win64_REDFLARE_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "3c980f5a-c775-5c25-ba28-91a93a1b9a85"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/production/yara/APT_Keylogger_Win64_REDFLARE_1.yar#L4-L17"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "fbefb4074f1672a3c29c1a47595ea261"
		logic_hash = "26fe577ba637c484d9a8ccc2173b5892a76328a90a39a2bebbae6bd2a6329485"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-01"
		date_modified = "2020-12-01"
		rev = 1

	strings:
		$create_window = { 41 B9 00 00 CF 00 [4-40] 33 C9 [2-10] 00 00 00 80 [2-10] 00 00 00 80 [2-10] 00 00 00 80 [2-10] 00 00 00 80 FF 15 }
		$keys_check = { B9 14 00 00 00 FF 15 [4-8] B9 10 00 00 00 FF 15 [4] BE 00 80 FF FF 66 85 C6 75 ?? B9 A0 00 00 00 FF 15 [4] 66 85 C6 75 ?? B9 A1 00 00 00 FF 15 [4] 66 85 C6 74 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) and all of them
}
rule FIREEYE_RT_APT_Trojan_Win_REDFLARE_2 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "84881e5c-05df-5911-af42-ec82e559588c"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/production/yara/APT_Trojan_Win_REDFLARE_2.yar#L4-L20"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "9529c4c9773392893a8a0ab8ce8f8ce1,05b99d438dac63a5a993cea37c036673"
		logic_hash = "1f2e1f644b1932486444dfda30b7dad7f50121f59fa493eb8a1a0528ae46db26"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-27"
		date_modified = "2020-11-27"
		rev = 2

	strings:
		$1 = "initialize" fullword
		$2 = "getData" fullword
		$3 = "putData" fullword
		$4 = "fini" fullword
		$5 = "Cookie: SID1=%s" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_APT_Loader_Win64_REDFLARE_2 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "043f4e29-710d-5e17-a0ed-82cd3a565194"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/production/yara/APT_Loader_Win64_REDFLARE_2.yar#L4-L18"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "100d73b35f23b2fe84bf7cd37140bf4d"
		logic_hash = "9fad845ed963fae46ac7ddc44407d5f6ed0a061f6a106764b9f912ef718279b4"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-27"
		date_modified = "2020-11-27"
		rev = 1

	strings:
		$alloc = { 45 8B C0 33 D2 [2-6] 00 10 00 00 [2-6] 04 00 00 00 [1-6] FF 15 [4-60] FF 15 [4] 85 C0 [4-40] 20 00 00 00 [4-40] FF 15 [4] 85 C0 }
		$inject = { 83 F8 01 [2-20] 33 C0 45 33 C9 [3-10] 45 33 C0 [3-10] 33 D2 [30-100] FF 15 [4] 85 C0 [20-100] 01 00 10 00 [0-10] FF 15 [4] 85 C0 [4-30] FF 15 [4] 85 C0 [2-20] FF 15 [4] 83 F8 FF }
		$s1 = "ResumeThread" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) and all of them
}
rule FIREEYE_RT_APT_Trojan_Win_REDFLARE_3 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "2f6785c4-f4d0-52ff-8c46-da953e2ca92a"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/production/yara/APT_Trojan_Win_REDFLARE_3.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "9ccda4d7511009d5572ef2f8597fba4e,ece07daca53dd0a7c23dacabf50f56f1"
		logic_hash = "ee104bc145686a134e4d6d620dae7d1dacff7645d47f1a8d7a212327352b8e87"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-01"
		date_modified = "2020-12-01"
		rev = 1

	strings:
		$calc_image_size = { 28 00 00 00 [2-30] 83 E2 1F [4-20] C1 F8 05 [0-8] 0F AF C? [0-30] C1 E0 02 }
		$str1 = "CreateCompatibleBitmap" fullword
		$str2 = "BitBlt" fullword
		$str3 = "runCommand" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_APT_Keylogger_Win32_REDFLARE_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "ad14db66-d640-5712-b2c8-a3d42d5a90f3"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/production/yara/APT_Keylogger_Win32_REDFLARE_1.yar#L4-L17"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "d7cfb9fbcf19ce881180f757aeec77dd"
		logic_hash = "aebbaa050bee3775ffac4214ea4ab58284384e7eb41e66ee4838b9359e72821e"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-01"
		date_modified = "2020-12-01"
		rev = 2

	strings:
		$create_window = { 6A 00 68 [4] 6A 00 6A 00 68 00 00 00 80 68 00 00 00 80 68 00 00 00 80 68 00 00 00 80 68 00 00 CF 00 68 [4] 68 [4] 6A 00 FF 15 }
		$keys_check = { 6A 14 [0-5] FF [1-5] 6A 10 [0-5] FF [1-5] B9 00 80 FF FF 66 85 C1 75 ?? 68 A0 00 00 00 FF [1-5] B9 00 80 FF FF 66 85 C1 75 ?? 68 A1 00 00 00 FF [1-5] B9 00 80 FF FF 66 85 C1 74 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x010B ) and all of them
}
rule FIREEYE_RT_APT_Loader_Win64_REDFLARE_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "dc162f26-66d3-5359-b1d7-ef2208b359e2"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/production/yara/APT_Loader_Win64_REDFLARE_1.yar#L4-L17"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "f20824fa6e5c81e3804419f108445368"
		logic_hash = "2cae245a6aa36dccc2228cccefdc4ca0eb278901f063e072a369000f67d73a55"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-27"
		date_modified = "2020-11-27"
		rev = 1

	strings:
		$alloc_n_load = { 41 B9 40 00 00 00 41 B8 00 30 00 00 33 C9 [1-10] FF 50 [4-80] F3 A4 [30-120] 48 6B C9 28 [3-20] 48 6B C9 28 }
		$const_values = { 0F B6 ?? 83 C? 20 83 F? 6D [2-20] 83 C? 20 83 F? 7A }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) and all of them
}
rule FIREEYE_RT_APT_Loader_Raw32_REDFLARE_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "8f8ec27f-afac-5da5-b76f-b984e14e0066"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/production/yara/APT_Loader_Raw32_REDFLARE_1.yar#L4-L16"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "4022baddfda3858a57c9cbb0d49f6f86"
		logic_hash = "05ed89bd82600b4d5ef01ece2e0a9bd84e968988fd2bda1bab4ec316a9a9906b"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-27"
		date_modified = "2020-11-27"
		rev = 1

	strings:
		$load = { EB ?? 58 [0-4] 8B 10 8B 48 [1-3] 8B C8 83 C1 ?? 03 D1 83 E9 [1-3] 83 C1 [1-4] FF D? }

	condition:
		( uint16( 0 ) != 0x5A4D ) and all of them
}
rule FIREEYE_RT_APT_Trojan_Win_REDFLARE_7 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "f891e477-9ff2-57be-9ca5-dd87d9baee29"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/production/yara/APT_Trojan_Win_REDFLARE_7.yar#L4-L21"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "e7beece34bdf67cbb8297833c5953669, 8025bcbe3cc81fc19021ad0fbc11cf9b"
		logic_hash = "6d7822256ac1bef05304d3396df773e2b20a397311ad820d6ec5fe4cb6bdfbbc"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-02"
		date_modified = "2020-12-02"
		rev = 1

	strings:
		$1 = "initialize" fullword
		$2 = "getData" fullword
		$3 = "putData" fullword
		$4 = "fini" fullword
		$5 = "NamedPipe"
		$named_pipe = { 88 13 00 00 [1-8] E8 03 00 00 [20-60] 00 00 00 00 [1-8] 00 00 00 00 [1-40] ( 6A 00 6A 00 6A 03 6A 00 6A 00 68 | 00 00 00 00 [1-6] 00 00 00 00 [1-6] 03 00 00 00 45 33 C? 45 33 C? BA ) 00 00 00 C0 [2-10] FF 15 [4-30] FF 15 [4-7] E7 00 00 00 [4-40] FF 15 [4] 85 C0 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_APT_Downloader_Win32_REDFLARE_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "e8d7ee31-568e-58ac-98ad-49baa2eb37ea"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/production/yara/APT_Downloader_Win32_REDFLARE_1.yar#L4-L17"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "05b99d438dac63a5a993cea37c036673"
		logic_hash = "a340a2a732a9b1aa74ca9d84009a88d1b14b6a03140a859384c0d6e745e4a90a"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-27"
		date_modified = "2020-11-27"
		rev = 1

	strings:
		$const = "Cookie: SID1=%s" fullword
		$http_req = { 00 00 08 80 81 3D [4] BB 01 00 00 75 [1-10] 00 00 80 00 [1-4] 00 10 00 00 [1-4] 00 20 00 00 89 [1-10] 6A 00 8B [1-8] 5? 6A 00 6A 00 6A 00 8B [1-8] 5? 68 [4] 8B [1-8] 5? FF 15 [4-40] 6A 14 E8 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x010B ) and all of them
}
rule FIREEYE_RT_APT_Trojan_Linux_REDFLARE_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "220302bc-4ed3-5e10-9bd2-a8ed2bdaef73"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/supplemental/yara/APT_Trojan_Linux_REDFLARE_1.yar#L4-L20"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "79259451ff47b864d71fb3f94b1774f3, 82773afa0860d668d7fe40e3f22b0f3e"
		logic_hash = "282f11c4c86d88d05f11e92f5483701d9a54c2dd39f21316cd271aa78a338d0f"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-02"
		date_modified = "2020-12-02"
		rev = 1

	strings:
		$s1 = "find_applet_by_name" fullword
		$s2 = "bb_basename" fullword
		$s3 = "hk_printf_chk" fullword
		$s4 = "runCommand" fullword
		$s5 = "initialize" fullword

	condition:
		( uint32( 0 ) == 0x464c457f ) and all of them
}
rule FIREEYE_RT_APT_Trojan_Win_REDFLARE_6 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "5875a9ec-c3ee-57f0-a430-4443db585def"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE/supplemental/yara/APT_Trojan_Win_REDFLARE_6.yar#L4-L20"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "294b1e229c3b1efce29b162e7b3be0ab, 6902862bd81da402e7ac70856afbe6a2"
		logic_hash = "1e6f8320e0c0b601fc72fa4d9c61e46adfbcd84638c97da5988ca848e036312a"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-01"
		date_modified = "2020-12-01"
		rev = 2

	strings:
		$s1 = "RevertToSelf" fullword
		$s2 = "Unsuccessful" fullword
		$s3 = "Successful" fullword
		$s4 = "runCommand" fullword
		$s5 = "initialize" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_Loader_MSIL_DUEDLLIGENCE_3 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "42e4e777-6d51-5733-97df-dc27f13a27b7"
		date = "2020-12-18"
		modified = "2020-12-18"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/DUEDLLIGENCE/production/yara/Loader_MSIL_DUEDLLIGENCE_3.yar#L5-L16"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		logic_hash = "41cc6a4c7765b1e5e88d12660b69e434c83938ca974b9ccf6545b4dd5dd78378"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$create_thread_injected = { 7E [2] 00 0A 0A 16 0B 16 8D [2] 00 01 0C 28 [2] 00 06 2? ?? 2A 28 [2] 00 0A 1E 3? ?? 7E [2] 00 04 7E [2] 00 04 28 [2] 00 0A 28 [2] 00 06 0C 2? ?? 7E [2] 00 04 7E [2] 00 04 28 [2] 00 0A 28 [2] 00 06 0C 7E [2] 00 0A 08 8E 69 7E [2] 00 04 7E [2] 00 04 28 [2] 00 06 0D 09 7E [2] 00 0A 28 [2] 00 0A }
		$iz1 = /_Cor(Exe|Dll)Main/ fullword
		$rc4 = { 20 00 01 00 00 8D [2] 00 01 1? ?? 20 00 01 00 00 8D [2] 00 01 1? ?? 03 8E 69 8D [2] 00 01 1? ?? 16 0B 2B ?? 1? ?? 07 02 07 02 8E 69 5D 91 9E 1? ?? 07 07 9E 07 17 58 0B 07 20 00 01 00 00 32 }
		$suspended_process = { 12 ?? FE 15 [2] 00 02 1? ?? FE 15 [2] 00 02 02 14 7E [2] 00 0A 7E [2] 00 0A 16 20 [2] 00 08 7E [2] 00 0A 14 12 ?? 12 ?? 28 [2] 00 06 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_Hacktool_MSIL_HOLSTER_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the a customized version of the 'DUEDLLIGENCE' project."
		author = "FireEye"
		id = "e1e8979e-2dee-5061-a11d-00dcfba476c3"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/DUEDLLIGENCE/production/yara/HackTool_MSIL_HOLSTER_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "a91bf61cc18705be2288a0f6f125068f"
		logic_hash = "bc254a1ab71f2a6092f139ce5a85347a7a4976f963603ffbbebb9b0d6ce6573c"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid1 = "a8bdbba4-7291-49d1-9a1b-372de45a9d88" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Loader_MSIL_DUEDLLIGENCE_2 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "b10b476a-0d38-53e4-80cf-559618729268"
		date = "2020-12-18"
		modified = "2020-12-18"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/DUEDLLIGENCE/production/yara/Loader_MSIL_DUEDLLIGENCE_2.yar#L5-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		logic_hash = "5a2e0559e3b47c1957a42929fbbeba7a53c21619125381b01dcd8453b6ec4802"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$1 = "DueDLLigence" fullword
		$2 = "CPlApplet" fullword
		$iz1 = /_Cor(Exe|Dll)Main/ fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_Loader_MSIL_DUEDLLIGENCE_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "d438575f-3cb2-5cff-b5d4-733044f62e61"
		date = "2020-12-18"
		modified = "2020-12-18"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/DUEDLLIGENCE/production/yara/Loader_MSIL_DUEDLLIGENCE_1.yar#L5-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		logic_hash = "56237d686b954950849adeedc87d5f9fbff2335a0ff033ba8571b3e3b93f587c"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$create_thread_injected = { 7E [2] 00 0A 0A 16 0B 16 8D [2] 00 01 0C 28 [2] 00 06 2? ?? 2A 28 [2] 00 0A 1E 3? ?? 7E [2] 00 04 7E [2] 00 04 28 [2] 00 0A 28 [2] 00 06 0C 2? ?? 7E [2] 00 04 7E [2] 00 04 28 [2] 00 0A 28 [2] 00 06 0C 7E [2] 00 0A 08 8E 69 7E [2] 00 04 7E [2] 00 04 28 [2] 00 06 0D 09 7E [2] 00 0A 28 [2] 00 0A }
		$iz1 = /_Cor(Exe|Dll)Main/ fullword
		$suspended_process = { 12 ?? FE 15 [2] 00 02 1? ?? FE 15 [2] 00 02 02 14 7E [2] 00 0A 7E [2] 00 0A 16 20 [2] 00 08 7E [2] 00 0A 14 12 ?? 12 ?? 28 [2] 00 06 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_MSIL_Launcher_DUEDLLIGENCE_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'DUEDLLIGENCE' project."
		author = "FireEye"
		id = "86f0ebe5-110b-53e2-bba5-676f00c2cddd"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/DUEDLLIGENCE/production/yara/MSIL_Launcher_DUEDLLIGENCE_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "a91bf61cc18705be2288a0f6f125068f"
		logic_hash = "bd6abaa909f0c776d81ed1115e875888336661c91df3881f4f3ea5dd27e115f8"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 1

	strings:
		$typelibguid0 = "73948912-cebd-48ed-85e2-85fcd1d4f560" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Hacktool_MSIL_Puppyhound_1 : FILE
{
	meta:
		description = "This is a modification of an existing FireEye detection for SharpHound. However, it looks for the string 'PuppyHound' instead of 'SharpHound' as this is all that was needed to detect the PuppyHound variant of SharpHound."
		author = "FireEye"
		id = "1155f959-c8bc-597a-8a80-abee8d95b6ec"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/PUPPYHOUND/production/yara/HackTool_MSIL_PuppyHound_1.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "eeedc09570324767a3de8205f66a5295"
		logic_hash = "39073bbfef15ecd28c1772e5d01e54c3d5774ecb4c90f0076bda5dc400abacba"
		score = 75
		quality = 75
		tags = "FILE"
		rev = 6

	strings:
		$1 = "PuppyHound"
		$2 = "UserDomainKey"
		$3 = "LdapBuilder"
		$init = { 28 [2] 00 0A 0A 72 [2] 00 70 1? ?? 28 [2] 00 0A 72 [2] 00 70 1? ?? 28 [2] 00 0A 28 [2] 00 0A 0B 1F 2D }
		$msil = /\x00_Cor(Exe|Dll)Main\x00/

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_Hacktool_MSIL_Sharphound_3 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the public SharpHound3 project."
		author = "FireEye"
		id = "456b3208-1e8d-5eb7-81ee-39f1c886c5a7"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/PUPPYHOUND/production/yara/HackTool_MSIL_SharpHound_3.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "eeedc09570324767a3de8205f66a5295"
		logic_hash = "baeea6cae42c755ee389378229b2b206c82f60f75a5ce5f9cfa06871fc9507d1"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 4

	strings:
		$typelibguid1 = "A517A8DE-5834-411D-ABDA-2D0E1766539C" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and $typelibguid1
}
rule FIREEYE_RT_Loader_Win_Generic_18 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "6f44bd64-29bd-50e2-8b61-7ba61bb1f688"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/BEACON/supplemental/yara/Loader_Win_Generic_18.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "c74ebb6c238bbfaefd5b32d2bf7c7fcc"
		logic_hash = "28c9497f646fcf3daf7007d7afd37971dd85382062c064173f13049ad419fef1"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-25"
		date_modified = "2020-11-25"
		rev = 3

	strings:
		$s0 = { 89 [1-16] FF 15 [4-16] 89 [1-24] E8 [4-16] 89 C6 [4-24] 8D [1-8] 89 [1-4] 89 [1-4] E8 [4-16] 89 [1-8] E8 [4-24] 01 00 00 00 [1-8] 89 [1-8] E8 [4-64] 8A [1-8] 88 }
		$s2 = { 83 EC [4-24] 00 10 00 00 [4-24] C7 44 24 ?? ?? 00 00 00 [0-8] FF 15 [4-24] 89 [1-4] 89 [1-4] 89 [1-8] FF 15 [4-16] 3? ?? 7? [4-24] 20 00 00 00 [4-24] FF 15 [4-32] F3 A5 }
		$si1 = "fread" fullword
		$si2 = "fwrite" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_Trojan_Win_Generic_101 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "0290aaea-d65b-5883-97f9-549d107e3e1f"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/BEACON/supplemental/yara/Trojan_Win_Generic_101.yar#L4-L20"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "2e67c62bd0307c04af469ee8dcb220f2"
		logic_hash = "e530183f3cab01560b1abc91e2111e5d9e5aadc1c8134027ac07d8917f9419a0"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-25"
		date_modified = "2020-11-25"
		rev = 3

	strings:
		$s0 = { 2A [1-16] 17 [1-16] 02 04 00 00 [1-16] FF 15 }
		$s1 = { 81 7? [1-3] 02 04 00 00 7? [1-3] 83 7? [1-3] 17 7? [1-3] 83 7? [1-3] 2A 7? }
		$s2 = { FF 15 [4-16] FF D? [1-16] 3D [1-24] 89 [1-8] E8 [4-16] 89 [1-8] F3 A4 [1-24] E8 }
		$si1 = "PeekMessageA" fullword
		$si2 = "PostThreadMessageA" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and @s0 [ 1 ] < @s1 [ 1 ] and @s1 [ 1 ] < @s2 [ 1 ] and all of them
}
rule FIREEYE_RT_Loader_Win_Generic_17 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "4e5bf741-c1e3-54af-9580-02925ba6fc6a"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/BEACON/supplemental/yara/Loader_Win_Generic_17.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "562ecbba043552d59a0f23f61cea0983"
		logic_hash = "5c20472c3af0c5b8c825671b12763900d6a711695ed04661b33cbf442422348d"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-25"
		date_modified = "2020-11-25"
		rev = 3

	strings:
		$s0 = { 89 [1-16] FF 15 [4-16] 89 [1-24] E8 [4-16] 89 C6 [4-24] 8D [1-8] 89 [1-4] 89 [1-4] E8 [4-16] 89 [1-8] E8 [4-24] 01 00 00 00 [1-8] 89 [1-8] E8 [4-64] 8A [1-8] 88 }
		$s1 = { 83 EC [1-16] 04 00 00 00 [1-24] 00 30 00 00 [1-24] FF 15 [4-16] EB [16-64] 20 00 00 00 [0-8] FF 15 [4-32] C7 44 24 ?? 00 00 00 00 [0-8] C7 44 24 ?? 00 00 00 00 [0-16] FF 15 }
		$si1 = "fread" fullword
		$si2 = "fwrite" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_Trojan_Raw_Generic_4 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "9092f9bb-cab6-55c0-9452-70a6407db93a"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/BEACON/supplemental/yara/Trojan_Raw_Generic_4.yar#L4-L17"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "f41074be5b423afb02a74bc74222e35d"
		logic_hash = "8ffd23631c1a9d1abe6695858ec34d61261b3b3f097be94372f3f34e46e7211e"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-02"
		date_modified = "2020-12-02"
		rev = 1

	strings:
		$s0 = { 83 ?? 02 [1-16] 40 [1-16] F3 A4 [1-16] 40 [1-16] E8 [4-32] FF ( D? | 5? | 1? ) }
		$s1 = { 0F B? [1-16] 4D 5A [1-32] 3C [16-64] 50 45 [8-32] C3 }

	condition:
		uint16( 0 ) != 0x5A4D and all of them
}
rule FIREEYE_RT_Builder_MSIL_Sharpgenerator_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'SharpGenerator' project."
		author = "FireEye"
		id = "ab661cba-f695-59d2-9071-9b9a90233457"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/SHARPGENERATOR/production/yara/Builder_MSIL_SharpGenerator_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "6dc0780e54d33df733aadc8a89077232baa63bf1cbe47c5d164c57ce3185dd71"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 1

	strings:
		$typelibguid0 = "3f450977-d796-4016-bb78-c9e91c6a0f08" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Hacktool_MSIL_PXELOOT_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the PXE And Loot project."
		author = "FireEye"
		id = "5a72a6ff-bae4-57f5-a19b-a4595ac57293"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/PXELOOT/production/yara/HackTool_MSIL_PXELOOT_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "82e33011ac34adfcced6cddc8ea56a81"
		logic_hash = "c9892adcb9ff5471235e45988f6662d3b8f984fdafca7024a5781eed50f6c0b3"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 7

	strings:
		$typelibguid1 = "78B2197B-2E56-425A-9585-56EDC2C797D6" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and $typelibguid1
}
rule FIREEYE_RT_APT_Hacktool_MSIL_FLUFFY_2 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "ce39710e-7649-5f7d-bbbe-65dc30f678e8"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/FLUFFY/production/yara/APT_HackTool_MSIL_FLUFFY_2.yar#L4-L21"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "11b5aceb428c3e8c61ed24a8ca50553e"
		logic_hash = "872ab717668375a49d6c7b1927a680747b405c0198fe4fc6f43ccc562870eb37"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-04"
		date_modified = "2020-12-04"
		rev = 1

	strings:
		$s1 = "\x00Asktgt\x00"
		$s2 = "\x00Kerberoast\x00"
		$s3 = "\x00HarvestCommand\x00"
		$s4 = "\x00EnumerateTickets\x00"
		$s5 = "[*] Action: " wide
		$s6 = "\x00Fluffy.Commands\x00"

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_FLUFFY_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "6593202d-9b30-59ed-98c0-3e730fb5ceb7"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/FLUFFY/production/yara/APT_HackTool_MSIL_FLUFFY_1.yar#L4-L18"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "11b5aceb428c3e8c61ed24a8ca50553e"
		logic_hash = "4d91c96ab7b628e88f79ee193612acc959448fe2220ef54371f5f5c6e7305d86"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-04"
		date_modified = "2020-12-04"
		rev = 1

	strings:
		$sb1 = { 0E ?? 1? 72 [4] 28 [2] 00 06 [0-16] 28 [2] 00 0A [2-80] 1F 58 0? [0-32] 28 [2] 00 06 [2-32] 1? 28 [2] 00 06 0? 0? 6F [2] 00 06 [2-4] 1F 0B }
		$sb2 = { 73 [2] 00 06 13 ?? 11 ?? 11 ?? 7D [2] 00 04 11 ?? 73 [2] 00 0A 7D [2] 00 04 0E ?? 2D ?? 11 ?? 7B [2] 00 04 72 [4] 28 [2] 00 0A [2-32] 0? 28 [2] 00 0A [2-16] 11 ?? 7B [2] 00 04 0? 28 [2] 00 0A 1? 28 [2] 00 0A [2-32] 7E [2] 00 0A [0-32] FE 15 [2] 00 02 [0-16] 7D [2] 00 04 28 [2] 00 06 [2-32] 7B [2] 00 04 7D [2] 00 04 [2-32] 7C [2] 00 04 FE 15 [2] 00 02 [0-16] 11 ?? 8C [2] 00 02 28 [2] 00 0A 28 [2] 00 0A [2-80] 8C [2] 00 02 28 [2] 00 0A 12 ?? 12 ?? 12 ?? 28 [2] 00 06 }
		$ss1 = "\x00Fluffy\x00"

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_Hacktool_MSIL_SAFETYKATZ_4 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the public SafetyKatz project."
		author = "FireEye"
		id = "e160b75d-cc39-5e16-86e1-cba9fe64a6b6"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/SAFETYKATZ/production/yara/HackTool_MSIL_SAFETYKATZ_4.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "45736deb14f3a68e88b038183c23e597"
		logic_hash = "a02b4acea691d485f427ed26487f2f601065901324a8dcd6cd8de9502d8cd897"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 3

	strings:
		$typelibguid1 = "8347E81B-89FC-42A9-B22C-F59A6A572DEC" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and $typelibguid1
}
rule FIREEYE_RT_APT_Hacktool_MSIL_SHARPSTOMP_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "4b4a54c8-9717-5fbb-8130-a49162bc6b07"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/SHARPSTOMP/production/yara/APT_HackTool_MSIL_SHARPSTOMP_1.yar#L4-L24"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "83ed748cd94576700268d35666bf3e01"
		logic_hash = "af8aa0e87d8b6623a908fde5014f3849cd0ca20d5926c798be82ce4eab2668bb"
		score = 75
		quality = 71
		tags = "FILE"
		date_created = "2020-12-02"
		date_modified = "2020-12-02"
		rev = 3

	strings:
		$s0 = "mscoree.dll" fullword nocase
		$s1 = "timestompfile" fullword nocase
		$s2 = "sharpstomp" fullword nocase
		$s3 = "GetLastWriteTime" fullword
		$s4 = "SetLastWriteTime" fullword
		$s5 = "GetCreationTime" fullword
		$s6 = "SetCreationTime" fullword
		$s7 = "GetLastAccessTime" fullword
		$s8 = "SetLastAccessTime" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_Hacktool_MSIL_Sharpstomp_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the SharpStomp project."
		author = "FireEye"
		id = "e113c221-fabe-5af4-b763-463c4f86288d"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/SHARPSTOMP/production/yara/HackTool_MSIL_SharpStomp_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "83ed748cd94576700268d35666bf3e01"
		logic_hash = "fd0a3d046734d48be74d9a74f27570468550d21911c54ca82c81a1d64e9fdd17"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 4

	strings:
		$typelibguid1 = "41f35e79-2034-496a-8c82-86443164ada2" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and $typelibguid1
}
rule FIREEYE_RT_APT_Hacktool_MSIL_SHARPSTOMP_2 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "d1a3477d-55c6-5c33-bd65-5b1e0d65f24b"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/SHARPSTOMP/production/yara/APT_HackTool_MSIL_SHARPSTOMP_2.yar#L4-L22"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "83ed748cd94576700268d35666bf3e01"
		logic_hash = "4ed1553f12c607792d7d4e7026ecb36231cd417a06eba8b2925c2c643436b5fe"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-02"
		date_modified = "2020-12-02"
		rev = 3

	strings:
		$f0 = "mscoree.dll" fullword nocase
		$s0 = { 06 72 [4] 6F [4] 2C ?? 06 72 [4] 6F [4] 2D ?? 72 [4] 28 [4] 28 [4] 2A }
		$s1 = { 02 28 [4] 0A 02 28 [4] 0B 02 28 [4] 0C 72 [4] 28 [4] 72 }
		$s2 = { 28 [4] 02 28 [4] 0D 12 ?? 03 6C 28 [4] 28 [4] 02 28 [4] 0D 12 ?? 03 6C 28 [4] 28 [4] 02 28 [4] 0D 12 ?? 03 6C 28 [4] 28 [4] 72 }
		$s3 = "SetCreationTime" fullword
		$s4 = "GetLastAccessTime" fullword
		$s5 = "SetLastAccessTime" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_JUSTASK_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'justask' project."
		author = "FireEye"
		id = "06a03d82-db69-5b5a-a578-a8053814e917"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/JUSTASK/production/yara/APT_HackTool_MSIL_JUSTASK_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "24d2f8e3838c4f02cd80644a396ce7cf105761d2feba54e39973564ca5e97571"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid0 = "aa59be52-7845-4fed-9ea5-1ea49085d67a" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Tool_MSIL_Sharpgrep_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'SharpGrep' project."
		author = "FireEye"
		id = "c7569d33-f57d-5f9c-aa2a-78866c680b5b"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/SHARPPGREP/production/yara/Tool_MSIL_SharpGrep_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "c22bfc50b3ab3c4082006aad3c3c89684cffe1e429b001b0bb08758856a47d04"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 1

	strings:
		$typelibguid0 = "f65d75b5-a2a6-488f-b745-e67fc075f445" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Builder_MSIL_Sinfuloffice_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'SinfulOffice' project."
		author = "FireEye"
		id = "cf020fb3-751b-5346-8c0d-dc0a552599a3"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/SINFULOFFICE/production/yara/Builder_MSIL_SinfulOffice_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "b5d49a8720e4daa21e95ec66299daec42e65906017de886ea91f7bb6bfb04c77"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 1

	strings:
		$typelibguid0 = "9940e18f-e3c7-450f-801a-07dd534ccb9a" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Methodology_OLE_CHARENCODING_2 : FILE
{
	meta:
		description = "Looking for suspicious char encoding"
		author = "FireEye"
		id = "7abd1a11-7a55-50ac-aa6b-537e7c59a5ab"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/SINFULOFFICE/supplemental/yara/Methodology_OLE_CHARENCODING_2.yar#L4-L23"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "41b70737fa8dda75d5e95c82699c2e9b"
		logic_hash = "20843295531dfd88934fe0902a5101c5c0828e82df3289d7f263f16df9c92324"
		score = 65
		quality = 75
		tags = "FILE"
		rev = 4

	strings:
		$echo1 = "101;99;104;111;32;111;102;102;" ascii wide
		$echo2 = "101:99:104:111:32:111:102:102:" ascii wide
		$echo3 = "101x99x104x111x32x111x102x102x" ascii wide
		$pe1 = "77;90;144;" ascii wide
		$pe2 = "77:90:144:" ascii wide
		$pe3 = "77x90x144x" ascii wide
		$pk1 = "80;75;3;4;" ascii wide
		$pk2 = "80:75:3:4:" ascii wide
		$pk3 = "80x75x3x4x" ascii wide

	condition:
		( uint32( 0 ) == 0xe011cfd0 ) and filesize < 10MB and any of them
}
rule FIREEYE_RT_Hacktool_MSIL_SHARPZEROLOGON_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the public 'sharpzerologon' project."
		author = "FireEye"
		id = "51f22eee-fb96-55b0-8c02-1a0e9910a93e"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/SHARPZEROLOGON/production/yara/HackTool_MSIL_SHARPZEROLOGON_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "ed6a9bef5c6ee03aff969b8765b284ace517f2e6a1ef114acb04cf094c69cfa5"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 3

	strings:
		$typelibguid0 = "15ce9a3c-4609-4184-87b2-e29fc5e2b770" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_NOAMCI_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'noamci' project."
		author = "FireEye"
		id = "48066258-528f-5a70-81e1-15d6dfd9ff4f"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/NOAMCI/production/yara/APT_HackTool_MSIL_NOAMCI_1.yar#L4-L16"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "6278cfb4e9af20bbe943f4b99227c7fba276315a9f0059575b3ed4ef96a848c4"
		score = 75
		quality = 71
		tags = "FILE"
		rev = 4

	strings:
		$typelibguid0 = "7bcccf21-7ecd-4fd4-8f77-06d461fd4d51" ascii nocase wide
		$typelibguid1 = "ef86214e-54de-41c3-b27f-efc61d0accc3" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Hacktool_MSIL_Corehound_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'CoreHound' project."
		author = "FireEye"
		id = "8c914b34-3e3d-53ae-a5e4-9dbfdff45a24"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/COREHOUND/production/yara/HackTool_MSIL_CoreHound_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "b0f759709428d5c9404507a13259bf85cb8c405d38b807539098f7cc871023d8"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 1

	strings:
		$typelibguid0 = "1fff2aee-a540-4613-94ee-4f208b30c599" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Loader_Win64_MATRYOSHKA_1 : FILE
{
	meta:
		description = "matryoshka_process_hollow.rs"
		author = "FireEye"
		id = "69919a80-8ed1-5b8c-911a-ceb75570f11f"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/MATRYOSHKA/production/yara/APT_Loader_Win64_MATRYOSHKA_1.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "44887551a47ae272d7873a354d24042d"
		logic_hash = "46e5480dc95ce8b9d8385c2e44a50b21629301535b93833c13cc3db319ac15dd"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-02"
		date_modified = "2020-12-02"
		rev = 1

	strings:
		$sb1 = { 48 8B 45 ?? 48 89 85 [0-64] C7 45 ?? 00 00 00 00 31 ?? E8 [4-64] BA 00 10 00 00 [0-32] 41 B8 04 00 00 00 E8 [4] 83 F8 01 [2-32] BA [4] E8 }
		$sb2 = { E8 [4] 83 F8 01 [2-64] 41 B9 00 10 00 00 [0-32] E8 [4] 83 F8 01 [2-32] 3D 4D 5A 00 00 [0-32] 48 63 ?? 3C [0-32] 50 45 00 00 [4-64] 0F B7 [2] 18 81 ?? 0B 01 00 00 [2-32] 81 ?? 0B 02 00 00 [2-32] 8B [2] 28 }
		$sb3 = { 66 C7 45 ?? 48 B8 48 C7 45 ?? 00 00 00 00 66 C7 45 ?? FF E0 [0-64] 41 B9 40 00 00 00 [0-32] E8 [4] 83 F8 01 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) and all of them
}
rule FIREEYE_RT_APT_Dropper_Win_MATRYOSHKA_1 : FILE
{
	meta:
		description = "matryoshka_dropper.rs"
		author = "FireEye"
		id = "7fd305c7-0b1b-5d91-b968-7f1fb0a8ae47"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/MATRYOSHKA/production/yara/APT_Dropper_Win_MATRYOSHKA_1.yar#L4-L20"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "edcd58ba5b1b87705e95089002312281"
		logic_hash = "a7bf7599ec9b4b1d09a8c90b70ae565a9396fb31d449da3c1492d6fa336d9c5e"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-02"
		date_modified = "2020-12-02"
		rev = 1

	strings:
		$s1 = "\x00matryoshka.exe\x00"
		$s2 = "\x00Unable to write data\x00"
		$s3 = "\x00Error while spawning process. NTStatus: \x0a\x00"
		$s4 = "\x00.execmdstart/Cfailed to execute process\x00"

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_APT_Builder_Win64_MATRYOSHKA_1 : FILE
{
	meta:
		description = "matryoshka_pe_to_shellcode.rs"
		author = "FireEye"
		id = "0afcf13e-5cd3-5c1c-897e-b6d0c283ab0f"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/MATRYOSHKA/production/yara/APT_Builder_Win64_MATRYOSHKA_1.yar#L4-L20"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "8d949c34def898f0f32544e43117c057"
		logic_hash = "b370d7dea44bccc92fc8dbd4ea0ee9bec523820108bf8bc67acb17ebf9835f74"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-02"
		date_modified = "2020-12-02"
		rev = 1

	strings:
		$sb1 = { 4D 5A 45 52 [0-32] E8 [0-32] 00 00 00 00 [0-32] 5B 48 83 EB 09 53 48 81 [0-32] C3 [0-32] FF D3 [0-32] C3 }
		$ss1 = "\x00Stub Size: "
		$ss2 = "\x00Executable Size: "
		$ss3 = "\x00[+] Writing out to file"

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) and all of them
}
rule FIREEYE_RT_APT_Builder_PY_MATRYOSHKA_1
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "0135f3bb-28b3-5fc4-85a2-b12c46c8bc45"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/MATRYOSHKA/production/yara/APT_Builder_PY_MATRYOSHKA_1.yar#L4-L22"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "25a97f6dba87ef9906a62c1a305ee1dd"
		logic_hash = "71b26f4b319429ac356b55d22bccd1da85894d61f8c96452422de78d2d893420"
		score = 75
		quality = 75
		tags = ""
		date_created = "2020-12-02"
		date_modified = "2020-12-02"
		rev = 1

	strings:
		$s1 = ".pop(0)])"
		$s2 = "[1].replace('unsigned char buf[] = \"'"
		$s3 = "binascii.hexlify(f.read()).decode("
		$s4 = "os.system(\"cargo build {0} --bin {1}\".format("
		$s5 = "shutil.which('rustc')"
		$s6 = "~/.cargo/bin"
		$s7 = /[\x22\x27]\\\\x[\x22\x27]\.join\(\[\w{1,64}\[\w{1,64}:\w{1,64}[\x09\x20]{0,32}\+[\x09\x20]{0,32}2\]/

	condition:
		all of them
}
rule FIREEYE_RT_APT_Loader_Win64_MATRYOSHKA_2 : FILE
{
	meta:
		description = "matryoshka.rs"
		author = "FireEye"
		id = "25f916bc-6ee1-5175-903c-4266b0a086e1"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/MATRYOSHKA/production/yara/APT_Loader_Win64_MATRYOSHKA_2.yar#L4-L20"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "7f8102b789303b7861a03290c79feba0"
		logic_hash = "daa6f6d526bf959c268b2c5a4cae33307cfec5e9ca51283131bbfa66a582b505"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-02"
		date_modified = "2020-12-02"
		rev = 1

	strings:
		$sb1 = { 4D [2] 00 49 [2] 08 B? 02 00 00 00 31 ?? E8 [4] 48 89 ?? 48 89 ?? 4C 89 ?? 49 89 ?? E8 [4] 4C 89 ?? 48 89 ?? E8 [4] 83 [2] 01 0F 84 [4] 48 89 ?? 48 8B [2] 48 8B [2] 48 89 [5] 48 89 [5] 48 89 [5] 41 B? [4] 4C 89 ?? 31 ?? E8 [4] C7 45 [5] 48 89 ?? 4C 89 ?? E8 [4] 85 C0 }
		$sb2 = { 4C [2] 0F 83 [4] 41 0F [3] 01 41 32 [2] 00 48 8B [5] 48 3B [5] 75 ?? 41 B? 01 00 00 00 4C 89 ?? E8 [4] E9 }
		$si1 = "CreateToolhelp32Snapshot" fullword
		$si2 = "Process32Next" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) and all of them
}
rule FIREEYE_RT_APT_Dropper_Win64_MATRYOSHKA_1 : FILE
{
	meta:
		description = "matryoshka_dropper.rs"
		author = "FireEye"
		id = "1406aafd-6217-51ef-b3af-107ee88f9c99"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/MATRYOSHKA/production/yara/APT_Dropper_Win64_MATRYOSHKA_1.yar#L4-L18"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "edcd58ba5b1b87705e95089002312281"
		logic_hash = "23f811f8e9387ca6a1257a31af66de9739733e4728adba0a3e3f74b5e5c0a556"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-02"
		date_modified = "2020-12-02"
		rev = 1

	strings:
		$sb1 = { 8D 8D [4] E8 [4] 49 89 D0 C6 [2-6] 01 C6 [2-6] 01 [0-8] C7 44 24 ?? 0E 00 00 00 4C 8D 0D [4] 48 8D 8D [4] 48 89 C2 E8 [4] C6 [2-6] 01 C6 [2-6] 01 48 89 E9 48 8D 95 [4] E8 [4] 83 [2] 01 0F 8? [4] 48 01 F3 48 29 F7 48 [2] 08 48 89 85 [4] C6 [2-6] 01 C6 [2-6] 01 C6 [2-6] 01 48 8D 8D [4] 48 89 DA 49 89 F8 E8 }
		$sb2 = { 0F 29 45 ?? 48 C7 45 ?? 00 00 00 00 0F 29 45 ?? 0F 29 45 ?? 0F 29 45 ?? 0F 29 45 ?? 0F 29 45 ?? 0F 29 45 ?? 48 C7 45 ?? 00 00 00 00 C7 45 ?? 68 00 00 00 48 8B [2] 48 8D [2] 48 89 [3] 48 89 [3] 0F 11 44 24 ?? C7 44 24 ?? 08 00 00 0C C7 44 24 ?? 00 00 00 00 31 ?? 48 89 ?? 31 ?? 45 31 ?? 45 31 ?? E8 [4] 83 F8 01 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) and all of them
}
rule FIREEYE_RT_Loader_MSIL_Wildchild_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the WildChild project."
		author = "FireEye"
		id = "350dd658-46c9-573b-b532-07e4b437ba8d"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/WILDCHILD/production/yara/Loader_MSIL_WildChild_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "7e6bc0ed11c2532b2ae7060327457812"
		logic_hash = "e4320e33770613542182518ec787e4ccbb32f83c8afca5ec957d4846e6f4eb04"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 4

	strings:
		$typelibguid1 = "2e71d5ff-ece4-4006-9e98-37bb724a7780" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and $typelibguid1
}
rule FIREEYE_RT_Dropper_HTA_Wildchild_1 : FILE
{
	meta:
		description = "This rule looks for strings present in unobfuscated HTAs generated by the WildChild builder."
		author = "FireEye"
		id = "f570baa5-7d58-5a0a-b713-769e62076f76"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/WILDCHILD/production/yara/Dropper_HTA_WildChild_1.yar#L4-L24"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "3e61ca5057633459e96897f79970a46d"
		logic_hash = "60c1d53b8a43b9b7518f3260a4d61c6806641ee894a2a331a3a0a2ea0aff9d99"
		score = 75
		quality = 75
		tags = "FILE"
		rev = 5

	strings:
		$s1 = "processpath" ascii wide
		$s2 = "v4.0.30319" ascii wide
		$s3 = "v2.0.50727" ascii wide
		$s4 = "COMPLUS_Version" ascii wide
		$s5 = "FromBase64Transform" ascii wide
		$s6 = "MemoryStream" ascii wide
		$s7 = "entry_class" ascii wide
		$s8 = "DynamicInvoke" ascii wide
		$s9 = "Sendoff" ascii wide
		$script_header = "<script language=" ascii wide

	condition:
		$script_header at 0 and all of ( $s* )
}
rule FIREEYE_RT_APT_Loader_MSIL_WILDCHILD_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "b9e0707e-98eb-55da-ad1d-6a84bd113747"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/WILDCHILD/production/yara/APT_Loader_MSIL_WILDCHILD_1.yar#L4-L18"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "6f04a93753ae3ae043203437832363c4"
		logic_hash = "a600c3d127f77dc1f99160e4a242e005970de0abd1798296b6a351b968ca1350"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-01"
		date_modified = "2020-12-01"
		rev = 1

	strings:
		$s1 = "\x00QueueUserAPC\x00"
		$s2 = "\x00WriteProcessMemory\x00"
		$sb1 = { 6F [2] 00 0A 28 [2] 00 0A 6F [2] 00 0A 13 ?? 28 [2] 00 0A 28 [2] 00 0A 13 ?? 11 ?? 11 ?? 28 [2] 00 0A [0-16] 7B [2] 00 04 1? 20 [4] 28 [2] 00 0A 11 ?? 28 [2] 00 0A 28 [2] 00 0A 7E [2] 00 0A 7E [2] 00 0A 28 [2] 00 06 [0-16] 14 7E [2] 00 0A 7E [2] 00 0A 1? 20 04 00 08 08 7E [2] 00 0A 14 12 ?? 12 ?? 28 [2] 00 06 [0-16] 7B [2] 00 04 7E [2] 00 0A [0-16] 8E ?? 7E [2] 00 04 7E [2] 00 04 28 [2] 00 06 [4-120] 28 [2] 00 06 [0-80] 6F [2] 00 0A 6F [2] 00 0A 28 [2] 00 06 13 ?? 11 ?? 11 ?? 7E [2] 00 0A 28 [2] 00 06 }

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_Hacktool_MSIL_Keefarce_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'KeeFarce' project."
		author = "FireEye"
		id = "c17add0c-e09f-5ced-a4e1-bf60afad4725"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/KEEFARCE/production/yara/HackTool_MSIL_KeeFarce_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "8db86230849137608880dbe448737fc70068d308772e294cc69301b18ae10908"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 3

	strings:
		$typelibguid0 = "17589ea6-fcc9-44bb-92ad-d5b3eea6af03" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Hacktool_MSIL_SEATBELT_2 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the public SeatBelt project."
		author = "FireEye"
		id = "225b42fe-c73a-59c0-a1f4-1d6dff6e76e1"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/BELTALOWDA/production/yara/HackTool_MSIL_SEATBELT_2.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "9f401176a9dd18fa2b5b90b4a2aa1356"
		logic_hash = "e48474c5025fd88e3c2824e1e943ff56cde0ea05984aad0249ccf73caa6d4a36"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 3

	strings:
		$typelibguid1 = "AEC32155-D589-4150-8FE7-2900DF4554C8" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and $typelibguid1
}
rule FIREEYE_RT_Loader_MSIL_Wmirunner_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'WMIRunner' project."
		author = "FireEye"
		id = "04c6acfc-859f-5e4a-8c59-9adf08f21657"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/WMIRUNNER/production/yara/Loader_MSIL_WMIRunner_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "49d21756a4f0b29909c4b0fa9f3a98dd0480f9401923032de4b3920814b85f29"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 1

	strings:
		$typelibguid0 = "6cc61995-9fd5-4649-b3cc-6f001d60ceda" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_SHARPSACK_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'sharpsack' project."
		author = "FireEye"
		id = "8e344acb-73c4-5509-be9d-85cf6fe94445"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/SHARPSACK/production/yara/APT_HackTool_MSIL_SHARPSACK_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "ecc3250e65e34595b4b827add3eb3062edad6a3373930048bfd6225d4a229e93"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid0 = "1946808a-1a01-40c5-947b-8b4c3377f742" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Builder_MSIL_G2JS_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the Gadget2JScript project."
		author = "FireEye"
		id = "484202c2-ac7d-5e6c-8bf1-3452a357c668"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/G2JS/production/yara/Builder_MSIL_G2JS_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "fa255fdc88ab656ad9bc383f9b322a76"
		logic_hash = "487d8e8deef218412f241d99ce32b63bfeb3568d23048b9dd4afff8f401bfea5"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid1 = "AF9C62A1-F8D2-4BE0-B019-0A7873E81EA9" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and $typelibguid1
}
rule FIREEYE_RT_Hacktool_MSIL_Keepersist_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'KeePersist' project."
		author = "FireEye"
		id = "950a4744-2696-5eb7-8524-7f689cb5dbb0"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/KEEPERSIST/production/yara/HackTool_MSIL_KeePersist_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "eae67c77a64ca07f9ef59a356bb2c3f3131f14e7f17c898ef8857a21090ace0e"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid0 = "1df47db2-7bb8-47c2-9d85-5f8d3f04a884" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Hacktool_MSIL_Wmispy_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'WMIspy' project."
		author = "FireEye"
		id = "ac394751-da40-564b-8e24-8f353326b46a"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/WMISPY/production/yara/HackTool_MSIL_WMIspy_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "a5a9f7c7a7bfe474e8b21306ea220b4d476832f3ad4fafdd8967a2250d15a701"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 1

	strings:
		$typelibguid0 = "5ee2bca3-01ad-489b-ab1b-bda7962e06bb" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_WMISPY_2 : FILE
{
	meta:
		description = "wql searches"
		author = "FireEye"
		id = "474af878-a657-54bc-a063-04532df928d4"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/WMISPY/production/yara/APT_HackTool_MSIL_WMISPY_2.yar#L4-L24"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "3651f252d53d2f46040652788499d65a"
		logic_hash = "553fc1e536482a56b3228a5c9ebac843af9083e8ac864bf65c81b36a39ca5e5e"
		score = 75
		quality = 75
		tags = "FILE"
		rev = 4

	strings:
		$MSIL = "_CorExeMain"
		$str1 = "root\\cimv2" wide
		$str2 = "root\\standardcimv2" wide
		$str3 = "from MSFT_NetNeighbor" wide
		$str4 = "from Win32_NetworkLoginProfile" wide
		$str5 = "from Win32_IP4RouteTable" wide
		$str6 = "from Win32_DCOMApplication" wide
		$str7 = "from Win32_SystemDriver" wide
		$str8 = "from Win32_Share" wide
		$str9 = "from Win32_Process" wide

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and $MSIL and all of ( $str* )
}
rule FIREEYE_RT_Loader_MSIL_Sharpy_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'SharPy' project."
		author = "FireEye"
		id = "7c7bda22-bacc-5901-a650-a30c9cfcdee7"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/SHARPY/production/yara/Loader_MSIL_SharPy_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "0f73fab3905b4961b8dbeb120d45a34a2383ecdaae0296f38e34f8b7ab4aeee8"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 1

	strings:
		$typelibguid0 = "f6cf1d3b-3e43-4ecf-bb6d-6731610b4866" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Hacktool_MSIL_GETDOMAINPASSWORDPOLICY_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the recon utility 'getdomainpasswordpolicy' project."
		author = "FireEye"
		id = "69745e99-33cc-5171-ae7a-5c98439a0b6d"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/GETDOMAINPASSWORDPOLICY/production/yara/HackTool_MSIL_GETDOMAINPASSWORDPOLICY_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "6b2ea3ebfea2c87f16052f4a43b64eb2d595c2dd4a64d45dfce1642668dcf602"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 4

	strings:
		$typelibguid0 = "a5da1897-29aa-45f4-a924-561804276f08" ascii nocase wide

	condition:
		filesize < 10MB and ( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Hacktool_PY_Impacketobfuscation_2
{
	meta:
		description = "wmiexec"
		author = "FireEye"
		id = "f1059f66-eaff-5866-bafb-c94236cf96a0"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/IMPACKETOBF (Wmiexec)/production/yara/HackTool_PY_ImpacketObfuscation_2.yar#L4-L21"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "f3dd8aa567a01098a8a610529d892485"
		logic_hash = "ccbbe507798f16c7acf0780770fdb81b2e7dc333ab8bc51e6216816276c3f14b"
		score = 75
		quality = 75
		tags = ""
		date_created = "2020-12-01"
		date_modified = "2020-12-01"
		rev = 2

	strings:
		$s1 = "import random"
		$s2 = "class WMIEXEC" nocase
		$s3 = "class RemoteShell" nocase
		$s4 = /=[\x09\x20]{0,32}str\(int\(time\.time\(\)\)[\x09\x20]{0,32}-[\x09\x20]{0,32}random\.randint\(\d{1,10}[\x09\x20]{0,32},[\x09\x20]{0,32}\d{1,10}\)\)[\x09\x20]{0,32}\+[\x09\x20]{0,32}str\(uuid\.uuid4\(\)\)\.split\([\x22\x27]\-[\x22\x27]\)\[0\]/
		$s5 = /self\.__shell[\x09\x20]{0,32}=[\x09\x20]{0,32}[\x22\x27]cmd.exe[\x09\x20]{1,32}\/q[\x09\x20]{1,32}\/K [\x22\x27]/ nocase

	condition:
		all of them
}
rule FIREEYE_RT_Hacktool_MSIL_Sharpivot_2 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "8d6d28ce-de3a-5a38-b654-ba1372d47568"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/SHARPIVOT/production/yara/HackTool_MSIL_SharPivot_2.yar#L4-L20"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "e4efa759d425e2f26fbc29943a30f5bd"
		logic_hash = "14e4a29a32e8441a6f7f322e09cd9bb9822ae47eaa1fdf8e09c90998b03658f5"
		score = 75
		quality = 75
		tags = "FILE"
		rev = 3

	strings:
		$s1 = "costura"
		$s2 = "cmd_schtask" wide
		$s3 = "cmd_wmi" wide
		$s4 = "cmd_rpc" wide
		$s5 = "GoogleUpdateTaskMachineUA" wide
		$s6 = "servicehijack" wide
		$s7 = "poisonhandler" wide

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_Hacktool_MSIL_Sharpivot_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "c2834bd6-efb0-5dac-adcd-a9450090fc28"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/SHARPIVOT/production/yara/HackTool_MSIL_SharPivot_1.yar#L4-L18"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "e4efa759d425e2f26fbc29943a30f5bd"
		logic_hash = "1c71b9641e30c9764f3503e49f8f85472d7e62384c8dd2b420c4fa2b2fccda4f"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-25"
		date_modified = "2020-11-25"
		rev = 3

	strings:
		$s2 = { 73 ?? 00 00 0A 0A 06 1F ?? 1F ?? 6F ?? 00 00 0A 0B 73 ?? 00 00 0A 0C 16 13 04 2B 5E 23 [8] 06 6F ?? 00 00 0A 5A 23 [8] 58 28 ?? 00 00 0A 28 ?? 00 00 0A 28 ?? 00 00 0A }
		$s3 = "cmd_rpc" wide
		$s4 = "costura"

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_Hacktool_MSIL_Sharpivot_4 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the SharPivot project."
		author = "FireEye"
		id = "c1bd64da-6a54-5bc6-8a89-9c8a93dd965c"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/SHARPIVOT/production/yara/HackTool_MSIL_SharPivot_4.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "e4efa759d425e2f26fbc29943a30f5bd"
		logic_hash = "7ef883148926d5786861e5e81b1e645aa2e3ca06bd663f2b5f32e04b5852a218"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 3

	strings:
		$typelibguid1 = "44B83A69-349F-4A3E-8328-A45132A70D62" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and $typelibguid1
}
rule FIREEYE_RT_Loader_MSIL_Inmemorycompilation_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'In-MemoryCompilation' project."
		author = "FireEye"
		id = "80234352-a449-5292-9f0c-beb7a1d39a6c"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/MEMCOMP/production/yara/Loader_MSIL_InMemoryCompilation_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "a964a186eb02a2792db01727a31ddaa2414fe9df83cda9b1c9db15d94603303a"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid0 = "524d2687-0042-4f93-b695-5579f3865205" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_REVOLVER_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'revolver' project."
		author = "FireEye"
		id = "8fa5adb7-dc66-51bc-9f60-2308515f33a8"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REVOLVER/production/yara/APT_HackTool_MSIL_REVOLVER_1.yar#L4-L16"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "8df8a56ed55b7857adb95daa643d544a49eb5f1952b4ad3ef757c34dad2ce317"
		score = 75
		quality = 71
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid0 = "a8bdbba4-7291-49d1-9a1b-372de45a9d88" ascii nocase wide
		$typelibguid1 = "b214d962-7595-440b-abef-f83ecdb999d2" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_FE_APT_Loader_MSIL_REVOLVER_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "d99620e0-39ed-58db-acce-0d885a9e0bf7"
		date = "2020-12-18"
		modified = "2020-12-18"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REVOLVER/production/yara/APT_Loader_MSIL_REVOLVER_1.yar#L5-L14"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		logic_hash = "1231f4c961dec122ebcb142052c2c7c03acf9b556cdb71a3efabde6bcf50a939"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$inject = { 28 [2] 00 06 0? 0? 7B [2] 00 04 7E [2] 00 0A 28 [2] 00 0A [2-40] 7E [2] 00 0A 0? 20 00 10 00 00 28 [2] 00 0A 0? 28 [2] 00 0A 6F [2] 00 0A 1? ?? 7E [2] 00 0A 1? ?? 20 00 30 00 00 1F 40 28 [2] 00 06 [2-40] 28 [2] 00 0A 1? 3? ?? 7E [2] 00 04 7E [2] 00 04 28 [2] 00 0A 28 [2] 00 06 1? ?? 1? ?? 1? 0? 1? ?? 8? 6? 28 [2] 00 0A 2? ?? 7E [2] 00 04 7E [2] 00 04 28 [2] 00 0A 28 [2] 00 06 1? ?? 1? ?? 1? 0? 1? ?? 8? 6? 28 [2] 00 0A 1? ?? FE 15 [2] 00 02 1? ?? 72 [2] 00 70 28 [2] 00 06 1? ?? FE 15 [2] 00 02 1? ?? 1? ?? 1? 28 [2] 00 06 2? 7E [2] 00 0A 1? ?? 0? 7B [2] 00 04 1? ?? 1? 1? ?? 28 [2] 00 06 2? ?? 1? ?? 7E [2] 00 0A 28 [2] 00 0A [2-10] 7E [2] 00 0A 1? ?? 1? ?? 20 [2] 1F 00 7E [2] 00 0A 28 [2] 00 0A 6F [2] 00 0A 1? ?? 7E [2] 00 0A 1? 1? 20 [2] 00 00 20 [2] 00 00 7E [2] 00 0A 28 [2] 00 06 2? 1? ?? 7E [2] 00 0A 28 [2] 00 0A [2-40] 1? ?? 0? 7E [2] 00 0A 7E [2] 00 0A 7E [2] 00 0A 28 [2] 00 06 2? ?? 2? 1? 1? ?? 1? ?? 1? ?? 28 [2] 00 06 }
		$iz1 = /_Cor(Exe|Dll)Main/ fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_Loader_MSIL_Netshshellcoderunner_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'NetshShellCodeRunner' project."
		author = "FireEye"
		id = "b3521812-7ea3-5f80-89bd-3bdd71b687f2"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/NETSHSHELLCODERUNNER/production/yara/Loader_MSIL_NetshShellCodeRunner_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "97f6475a9d42697f633e06a9b04a85021ca4920145eb4af257d71b431448f0e9"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid0 = "49c045bc-59bb-4a00-85c3-4beb59b2ee12" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Loader_Win64_PGF_1 : FILE
{
	meta:
		description = "base dlls: /lib/payload/techniques/unmanaged_exports/"
		author = "FireEye"
		id = "1f2280c0-0fdd-5930-947a-931274bccd6f"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/PGF/production/yara/APT_Loader_Win64_PGF_1.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "2b686a8b83f8e1d8b455976ae70dab6e"
		logic_hash = "2e84d614c34b0b7f93fa70fa3312f22e3ff23f2abd33b2e19c00dd6cba7dcfdc"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-25"
		date_modified = "2020-11-25"
		rev = 1

	strings:
		$sb1 = { B9 14 00 00 00 FF 15 [4-32] 0F B6 ?? 04 [0-32] F3 A4 [0-64] 0F B6 [2-3] 0F B6 [2-3] 33 [0-32] 88 [1-9] EB }
		$sb2 = { 41 B8 00 30 00 00 [0-32] FF 15 [8-64] 83 ?? 01 [4-80] 0F B6 [1-64] 33 [1-32] 88 [1-64] FF ( D? | 5? ) }
		$sb3 = { 48 89 4C 24 08 [4-64] 48 63 48 3C [0-32] 48 03 C1 [0-64] 0F B7 48 14 [0-64] 48 8D 44 08 18 [8-64] 0F B7 40 06 [2-32] 48 6B C0 28 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) and all of them
}
rule FIREEYE_RT_APT_Loader_Win_PGF_1 : FILE
{
	meta:
		description = "PDB string used in some PGF DLL samples"
		author = "FireEye"
		id = "14e2102c-3572-5314-999c-ff3f6c94de03"
		date = "2020-12-08"
		modified = "2024-03-04"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/PGF/production/yara/APT_Loader_Win_PGF_1.yar#L4-L17"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "013c7708f1343d684e3571453261b586"
		logic_hash = "9dede268d33a38e980026917bd01bc47a72bfe60ba4a999c91eb727a2f377462"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 6

	strings:
		$pdb1 = /RSDS[\x00-\xFF]{20}c:\\source\\dllconfig-master\\dllsource[\x00-\xFF]{0,500}\.pdb\x00/ nocase
		$pdb2 = /RSDS[\x00-\xFF]{20}C:\\Users\\Developer\\Source[\x00-\xFF]{0,500}\\Release\\DllSource\.pdb\x00/ nocase
		$pdb3 = /RSDS[\x00-\xFF]{20}q:\\objchk_win7_amd64\\amd64\\init\.pdb\x00/ nocase

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and filesize < 15MB and any of them
}
rule FIREEYE_RT_APT_Loader_Win32_PGF_3 : FILE
{
	meta:
		description = "PGF payload, generated rule based on symfunc/c02594972dbab6d489b46c5dee059e66. Identifies dllmain_hook x86 payloads."
		author = "FireEye"
		id = "adf91482-6e04-5d11-bc00-4b1c7a802c49"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/PGF/production/yara/APT_Loader_Win32_PGF_3.yar#L4-L20"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "4414953fa397a41156f6fa4f9462d207"
		logic_hash = "24d2caad1d740ccbff0cf111a05ecad20ed06f311d530d8de86050d916da32ce"
		score = 75
		quality = 75
		tags = "FILE"
		rev = 4

	strings:
		$cond1 = { 55 89 E5 57 56 53 81 EC FC 06 00 00 C7 85 2C F9 FF FF 90 EE 01 6D C7 85 30 F9 FF FF 6C FE 01 6D 8D 85 34 F9 FF FF 89 28 BA CC 19 00 6D 89 50 04 89 60 08 8D 85 14 F9 FF FF 89 04 24 E8 BB A6 00 00 A1 48 A1 05 6D C7 85 18 F9 FF FF FF FF FF FF FF D0 C7 44 24 08 04 01 00 00 8D 95 B6 FD FF FF 89 54 24 04 89 04 24 E8 B8 AE 00 00 83 EC 0C 85 C0 0F 94 C0 84 C0 0F 85 8B 03 00 00 8D 45 BF 89 C1 E8 56 0B 01 00 8D 85 9C FD FF FF 8D 55 BF 89 54 24 04 8D 95 B6 FD FF FF 89 14 24 C7 85 18 F9 FF FF 01 00 00 00 89 C1 E8 DF B5 01 00 83 EC 08 8D 45 BF 89 C1 E8 52 0B 01 00 A1 4C A1 05 6D C7 85 18 F9 FF FF 02 00 00 00 FF D0 89 44 24 04 C7 04 24 08 00 00 00 E8 51 AE 00 00 83 EC 08 89 45 D0 83 7D D0 00 75 0F C7 85 10 F9 FF FF 00 00 00 00 E9 8C 02 00 00 C7 45 E4 00 00 00 00 C7 45 E0 00 00 00 00 C7 85 74 F9 FF FF 28 04 00 00 8D 85 74 F9 FF FF 89 44 24 04 8B 45 D0 89 04 24 C7 85 18 F9 FF FF 02 00 00 00 E8 EF AD 00 00 83 EC 08 89 45 DC 83 7D DC 00 74 67 8D 85 9C FD FF FF C7 44 24 04 00 00 00 00 8D 95 74 F9 FF FF 83 C2 20 89 14 24 89 C1 E8 82 FF 00 00 83 EC 08 83 F8 FF 0F 95 C0 84 C0 74 12 8B 85 88 F9 FF FF 89 45 E4 8B 85 8C F9 FF FF 89 45 E0 8D 85 74 F9 FF FF 89 44 24 04 8B 45 D0 89 04 24 C7 85 18 F9 FF FF 02 00 00 00 E8 84 AD 00 00 83 EC 08 89 45 DC EB 93 8B 45 D0 89 04 24 A1 2C A1 05 6D C7 85 18 F9 FF FF 02 00 00 00 FF D0 83 EC 04 83 7D E4 00 74 06 83 7D E0 00 75 0F C7 85 10 F9 FF FF 00 00 00 00 E9 AD 01 00 00 C7 04 24 0C 40 05 6D A1 5C A1 05 6D C7 85 18 F9 FF FF 02 00 00 00 FF D0 83 EC 04 C7 44 24 04 18 40 05 6D 89 04 24 A1 60 A1 05 6D FF D0 83 EC 08 89 45 CC 89 E8 89 45 D8 8D 85 6C F9 FF FF 89 44 24 04 8D 85 70 F9 FF FF 89 04 24 A1 54 A1 05 6D FF D0 83 EC 08 C7 45 D4 00 00 00 00 8B 55 D8 8B 85 6C F9 FF FF 39 C2 0F 83 F5 00 00 00 8B 45 D8 8B 00 3D FF 0F 00 00 0F 86 D8 00 00 00 8B 45 D8 8B 00 39 45 CC 73 19 8B 45 D8 8B 00 8B 55 CC 81 C2 00 10 00 00 39 D0 73 07 C7 45 D4 01 00 00 00 83 7D D4 00 0F 84 AF 00 00 00 8B 45 D8 8B 00 39 45 E4 0F 83 A1 00 00 00 8B 45 D8 8B 00 8B 4D E4 8B 55 E0 01 CA 39 D0 0F 83 8C 00 00 00 B9 00 00 00 00 B8 1C 00 00 00 83 E0 FC 89 C2 B8 00 00 00 00 89 8C 05 50 F9 FF FF 83 C0 04 39 D0 72 F2 8B 45 D8 8B 00 C7 44 24 08 1C 00 00 00 8D 95 50 F9 FF FF 89 54 24 04 89 04 24 A1 9C A1 05 6D C7 85 18 F9 FF FF 02 00 00 00 FF D0 83 EC 0C 8B 85 64 F9 FF FF 83 E0 20 85 C0 74 2E 8B 45 D8 8B 00 C7 44 24 04 30 14 00 6D 89 04 24 C7 85 18 F9 FF FF 02 00 00 00 E8 59 FC FF FF C7 85 10 F9 FF FF 00 00 00 00 EB 58 90 EB 01 90 83 45 D8 04 E9 FA FE FF FF 8B 45 E4 89 45 C8 8B 45 C8 8B 40 3C 89 C2 8B 45 E4 01 D0 89 45 C4 8B 45 C4 8B 50 28 8B 45 E4 01 D0 89 45 C0 C7 44 24 04 30 14 00 6D 8B 45 C0 89 04 24 C7 85 18 F9 FF FF 02 00 00 00 E8 FF FB FF FF C7 85 10 F9 FF FF 01 00 00 00 8D 85 9C FD FF FF 89 C1 E8 5D BC 01 00 83 BD 10 F9 FF FF 01 EB 70 8B 95 1C F9 FF FF 8B 85 18 F9 FF FF 85 C0 74 0C 83 E8 01 85 C0 74 2D 83 E8 01 0F 0B 89 95 10 F9 FF FF 8D 45 BF 89 C1 E8 48 08 01 00 8B 85 10 F9 FF FF 89 04 24 C7 85 18 F9 FF FF FF FF FF FF E8 A0 A6 00 00 89 95 10 F9 FF FF 8D 85 9C FD FF FF 89 C1 E8 FD BB 01 00 8B 85 10 F9 FF FF 89 04 24 C7 85 18 F9 FF FF FF FF FF FF E8 75 A6 00 00 90 8D 85 14 F9 FF FF 89 04 24 E8 76 A3 00 00 8D 65 F4 5B 5E 5F 5D C3 }
		$cond2 = { 55 89 E5 57 56 53 81 EC FC 06 00 00 C7 85 2C F9 FF FF B0 EF 3D 6A C7 85 30 F9 FF FF 8C FF 3D 6A 8D 85 34 F9 FF FF 89 28 BA F4 1A 3C 6A 89 50 04 89 60 08 8D 85 14 F9 FF FF 89 04 24 E8 B3 A6 00 00 A1 64 A1 41 6A C7 85 18 F9 FF FF FF FF FF FF FF D0 C7 44 24 08 04 01 00 00 8D 95 B6 FD FF FF 89 54 24 04 89 04 24 E8 B0 AE 00 00 83 EC 0C 85 C0 0F 94 C0 84 C0 0F 85 8B 03 00 00 8D 45 BF 89 C1 E8 4E 0B 01 00 8D 85 9C FD FF FF 8D 55 BF 89 54 24 04 8D 95 B6 FD FF FF 89 14 24 C7 85 18 F9 FF FF 01 00 00 00 89 C1 E8 D7 B5 01 00 83 EC 08 8D 45 BF 89 C1 E8 4A 0B 01 00 A1 68 A1 41 6A C7 85 18 F9 FF FF 02 00 00 00 FF D0 89 44 24 04 C7 04 24 08 00 00 00 E8 49 AE 00 00 83 EC 08 89 45 D0 83 7D D0 00 75 0F C7 85 10 F9 FF FF 00 00 00 00 E9 8C 02 00 00 C7 45 E4 00 00 00 00 C7 45 E0 00 00 00 00 C7 85 74 F9 FF FF 28 04 00 00 8D 85 74 F9 FF FF 89 44 24 04 8B 45 D0 89 04 24 C7 85 18 F9 FF FF 02 00 00 00 E8 E7 AD 00 00 83 EC 08 89 45 DC 83 7D DC 00 74 67 8D 85 9C FD FF FF C7 44 24 04 00 00 00 00 8D 95 74 F9 FF FF 83 C2 20 89 14 24 89 C1 E8 7A FF 00 00 83 EC 08 83 F8 FF 0F 95 C0 84 C0 74 12 8B 85 88 F9 FF FF 89 45 E4 8B 85 8C F9 FF FF 89 45 E0 8D 85 74 F9 FF FF 89 44 24 04 8B 45 D0 89 04 24 C7 85 18 F9 FF FF 02 00 00 00 E8 7C AD 00 00 83 EC 08 89 45 DC EB 93 8B 45 D0 89 04 24 A1 44 A1 41 6A C7 85 18 F9 FF FF 02 00 00 00 FF D0 83 EC 04 83 7D E4 00 74 06 83 7D E0 00 75 0F C7 85 10 F9 FF FF 00 00 00 00 E9 AD 01 00 00 C7 04 24 62 40 41 6A A1 78 A1 41 6A C7 85 18 F9 FF FF 02 00 00 00 FF D0 83 EC 04 C7 44 24 04 6E 40 41 6A 89 04 24 A1 7C A1 41 6A FF D0 83 EC 08 89 45 CC 89 E8 89 45 D8 8D 85 6C F9 FF FF 89 44 24 04 8D 85 70 F9 FF FF 89 04 24 A1 70 A1 41 6A FF D0 83 EC 08 C7 45 D4 00 00 00 00 8B 55 D8 8B 85 6C F9 FF FF 39 C2 0F 83 F5 00 00 00 8B 45 D8 8B 00 3D FF 0F 00 00 0F 86 D8 00 00 00 8B 45 D8 8B 00 39 45 CC 73 19 8B 45 D8 8B 00 8B 55 CC 81 C2 00 10 00 00 39 D0 73 07 C7 45 D4 01 00 00 00 83 7D D4 00 0F 84 AF 00 00 00 8B 45 D8 8B 00 39 45 E4 0F 83 A1 00 00 00 8B 45 D8 8B 00 8B 4D E4 8B 55 E0 01 CA 39 D0 0F 83 8C 00 00 00 B9 00 00 00 00 B8 1C 00 00 00 83 E0 FC 89 C2 B8 00 00 00 00 89 8C 05 50 F9 FF FF 83 C0 04 39 D0 72 F2 8B 45 D8 8B 00 C7 44 24 08 1C 00 00 00 8D 95 50 F9 FF FF 89 54 24 04 89 04 24 A1 C8 A1 41 6A C7 85 18 F9 FF FF 02 00 00 00 FF D0 83 EC 0C 8B 85 64 F9 FF FF 83 E0 20 85 C0 74 2E 8B 45 D8 8B 00 C7 44 24 04 30 14 3C 6A 89 04 24 C7 85 18 F9 FF FF 02 00 00 00 E8 59 FC FF FF C7 85 10 F9 FF FF 00 00 00 00 EB 58 90 EB 01 90 83 45 D8 04 E9 FA FE FF FF 8B 45 E4 89 45 C8 8B 45 C8 8B 40 3C 89 C2 8B 45 E4 01 D0 89 45 C4 8B 45 C4 8B 50 28 8B 45 E4 01 D0 89 45 C0 C7 44 24 04 30 14 3C 6A 8B 45 C0 89 04 24 C7 85 18 F9 FF FF 02 00 00 00 E8 FF FB FF FF C7 85 10 F9 FF FF 01 00 00 00 8D 85 9C FD FF FF 89 C1 E8 55 BC 01 00 83 BD 10 F9 FF FF 01 EB 70 8B 95 1C F9 FF FF 8B 85 18 F9 FF FF 85 C0 74 0C 83 E8 01 85 C0 74 2D 83 E8 01 0F 0B 89 95 10 F9 FF FF 8D 45 BF 89 C1 E8 40 08 01 00 8B 85 10 F9 FF FF 89 04 24 C7 85 18 F9 FF FF FF FF FF FF E8 98 A6 00 00 89 95 10 F9 FF FF 8D 85 9C FD FF FF 89 C1 E8 F5 BB 01 00 8B 85 10 F9 FF FF 89 04 24 C7 85 18 F9 FF FF FF FF FF FF E8 6D A6 00 00 90 8D 85 14 F9 FF FF 89 04 24 E8 6E A3 00 00 8D 65 F4 5B 5E 5F 5D C3 }
		$cond3 = { 55 89 E5 57 56 53 81 EC FC 06 00 00 C7 85 2C F9 FF FF F0 EF D5 63 C7 85 30 F9 FF FF CC FF D5 63 8D 85 34 F9 FF FF 89 28 BA 28 1B D4 63 89 50 04 89 60 08 8D 85 14 F9 FF FF 89 04 24 E8 BF A6 00 00 A1 64 A1 D9 63 C7 85 18 F9 FF FF FF FF FF FF FF D0 C7 44 24 08 04 01 00 00 8D 95 B6 FD FF FF 89 54 24 04 89 04 24 E8 BC AE 00 00 83 EC 0C 85 C0 0F 94 C0 84 C0 0F 85 8B 03 00 00 8D 45 BF 89 C1 E8 5A 0B 01 00 8D 85 9C FD FF FF 8D 55 BF 89 54 24 04 8D 95 B6 FD FF FF 89 14 24 C7 85 18 F9 FF FF 01 00 00 00 89 C1 E8 E3 B5 01 00 83 EC 08 8D 45 BF 89 C1 E8 56 0B 01 00 A1 68 A1 D9 63 C7 85 18 F9 FF FF 02 00 00 00 FF D0 89 44 24 04 C7 04 24 08 00 00 00 E8 55 AE 00 00 83 EC 08 89 45 D0 83 7D D0 00 75 0F C7 85 10 F9 FF FF 00 00 00 00 E9 8C 02 00 00 C7 45 E4 00 00 00 00 C7 45 E0 00 00 00 00 C7 85 74 F9 FF FF 28 04 00 00 8D 85 74 F9 FF FF 89 44 24 04 8B 45 D0 89 04 24 C7 85 18 F9 FF FF 02 00 00 00 E8 F3 AD 00 00 83 EC 08 89 45 DC 83 7D DC 00 74 67 8D 85 9C FD FF FF C7 44 24 04 00 00 00 00 8D 95 74 F9 FF FF 83 C2 20 89 14 24 89 C1 E8 86 FF 00 00 83 EC 08 83 F8 FF 0F 95 C0 84 C0 74 12 8B 85 88 F9 FF FF 89 45 E4 8B 85 8C F9 FF FF 89 45 E0 8D 85 74 F9 FF FF 89 44 24 04 8B 45 D0 89 04 24 C7 85 18 F9 FF FF 02 00 00 00 E8 88 AD 00 00 83 EC 08 89 45 DC EB 93 8B 45 D0 89 04 24 A1 44 A1 D9 63 C7 85 18 F9 FF FF 02 00 00 00 FF D0 83 EC 04 83 7D E4 00 74 06 83 7D E0 00 75 0F C7 85 10 F9 FF FF 00 00 00 00 E9 AD 01 00 00 C7 04 24 7E 40 D9 63 A1 7C A1 D9 63 C7 85 18 F9 FF FF 02 00 00 00 FF D0 83 EC 04 C7 44 24 04 8A 40 D9 63 89 04 24 A1 80 A1 D9 63 FF D0 83 EC 08 89 45 CC 89 E8 89 45 D8 8D 85 6C F9 FF FF 89 44 24 04 8D 85 70 F9 FF FF 89 04 24 A1 70 A1 D9 63 FF D0 83 EC 08 C7 45 D4 00 00 00 00 8B 55 D8 8B 85 6C F9 FF FF 39 C2 0F 83 F5 00 00 00 8B 45 D8 8B 00 3D FF 0F 00 00 0F 86 D8 00 00 00 8B 45 D8 8B 00 39 45 CC 73 19 8B 45 D8 8B 00 8B 55 CC 81 C2 00 10 00 00 39 D0 73 07 C7 45 D4 01 00 00 00 83 7D D4 00 0F 84 AF 00 00 00 8B 45 D8 8B 00 39 45 E4 0F 83 A1 00 00 00 8B 45 D8 8B 00 8B 4D E4 8B 55 E0 01 CA 39 D0 0F 83 8C 00 00 00 B9 00 00 00 00 B8 1C 00 00 00 83 E0 FC 89 C2 B8 00 00 00 00 89 8C 05 50 F9 FF FF 83 C0 04 39 D0 72 F2 8B 45 D8 8B 00 C7 44 24 08 1C 00 00 00 8D 95 50 F9 FF FF 89 54 24 04 89 04 24 A1 C8 A1 D9 63 C7 85 18 F9 FF FF 02 00 00 00 FF D0 83 EC 0C 8B 85 64 F9 FF FF 83 E0 20 85 C0 74 2E 8B 45 D8 8B 00 C7 44 24 04 30 14 D4 63 89 04 24 C7 85 18 F9 FF FF 02 00 00 00 E8 59 FC FF FF C7 85 10 F9 FF FF 00 00 00 00 EB 58 90 EB 01 90 83 45 D8 04 E9 FA FE FF FF 8B 45 E4 89 45 C8 8B 45 C8 8B 40 3C 89 C2 8B 45 E4 01 D0 89 45 C4 8B 45 C4 8B 50 28 8B 45 E4 01 D0 89 45 C0 C7 44 24 04 30 14 D4 63 8B 45 C0 89 04 24 C7 85 18 F9 FF FF 02 00 00 00 E8 FF FB FF FF C7 85 10 F9 FF FF 01 00 00 00 8D 85 9C FD FF FF 89 C1 E8 61 BC 01 00 83 BD 10 F9 FF FF 01 EB 70 8B 95 1C F9 FF FF 8B 85 18 F9 FF FF 85 C0 74 0C 83 E8 01 85 C0 74 2D 83 E8 01 0F 0B 89 95 10 F9 FF FF 8D 45 BF 89 C1 E8 4C 08 01 00 8B 85 10 F9 FF FF 89 04 24 C7 85 18 F9 FF FF FF FF FF FF E8 A4 A6 00 00 89 95 10 F9 FF FF 8D 85 9C FD FF FF 89 C1 E8 01 BC 01 00 8B 85 10 F9 FF FF 89 04 24 C7 85 18 F9 FF FF FF FF FF FF E8 79 A6 00 00 90 8D 85 14 F9 FF FF 89 04 24 E8 7A A3 00 00 8D 65 F4 5B 5E 5F 5D C3 }
		$cond4 = { 55 89 E5 57 56 53 81 EC FC 06 00 00 C7 85 ?? ?? ?? ?? 90 EE 01 6D C7 85 ?? ?? ?? ?? 6C FE 01 6D 8D 85 ?? ?? ?? ?? 89 28 BA CC 19 00 6D 89 50 ?? 89 60 ?? 8D 85 ?? ?? ?? ?? 89 04 24 E8 ?? ?? ?? ?? A1 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? FF FF FF FF FF D0 C7 44 24 ?? 04 01 00 00 8D 95 ?? ?? ?? ?? 89 54 24 ?? 89 04 24 E8 ?? ?? ?? ?? 83 EC 0C 85 C0 0F 94 C0 84 C0 0F 85 ?? ?? ?? ?? 8D 45 ?? 89 C1 E8 ?? ?? ?? ?? 8D 85 ?? ?? ?? ?? 8D 55 ?? 89 54 24 ?? 8D 95 ?? ?? ?? ?? 89 14 24 C7 85 ?? ?? ?? ?? 01 00 00 00 89 C1 E8 ?? ?? ?? ?? 83 EC 08 8D 45 ?? 89 C1 E8 ?? ?? ?? ?? A1 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 02 00 00 00 FF D0 89 44 24 ?? C7 04 24 08 00 00 00 E8 ?? ?? ?? ?? 83 EC 08 89 45 ?? 83 7D ?? 00 75 ?? C7 85 ?? ?? ?? ?? 00 00 00 00 E9 ?? ?? ?? ?? C7 45 ?? 00 00 00 00 C7 45 ?? 00 00 00 00 C7 85 ?? ?? ?? ?? 28 04 00 00 8D 85 ?? ?? ?? ?? 89 44 24 ?? 8B 45 ?? 89 04 24 C7 85 ?? ?? ?? ?? 02 00 00 00 E8 ?? ?? ?? ?? 83 EC 08 89 45 ?? 83 7D ?? 00 74 ?? 8D 85 ?? ?? ?? ?? C7 44 24 ?? 00 00 00 00 8D 95 ?? ?? ?? ?? 83 C2 20 89 14 24 89 C1 E8 ?? ?? ?? ?? 83 EC 08 83 F8 FF 0F 95 C0 84 C0 74 ?? 8B 85 ?? ?? ?? ?? 89 45 ?? 8B 85 ?? ?? ?? ?? 89 45 ?? 8D 85 ?? ?? ?? ?? 89 44 24 ?? 8B 45 ?? 89 04 24 C7 85 ?? ?? ?? ?? 02 00 00 00 E8 ?? ?? ?? ?? 83 EC 08 89 45 ?? EB ?? 8B 45 ?? 89 04 24 A1 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 02 00 00 00 FF D0 83 EC 04 83 7D ?? 00 74 ?? 83 7D ?? 00 75 ?? C7 85 ?? ?? ?? ?? 00 00 00 00 E9 ?? ?? ?? ?? C7 04 24 0C 40 05 6D A1 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 02 00 00 00 FF D0 83 EC 04 C7 44 24 ?? 18 40 05 6D 89 04 24 A1 ?? ?? ?? ?? FF D0 83 EC 08 89 45 ?? 89 E8 89 45 ?? 8D 85 ?? ?? ?? ?? 89 44 24 ?? 8D 85 ?? ?? ?? ?? 89 04 24 A1 ?? ?? ?? ?? FF D0 83 EC 08 C7 45 ?? 00 00 00 00 8B 55 ?? 8B 85 ?? ?? ?? ?? 39 C2 0F 83 ?? ?? ?? ?? 8B 45 ?? 8B 00 3D FF 0F 00 00 0F 86 ?? ?? ?? ?? 8B 45 ?? 8B 00 39 45 ?? 73 ?? 8B 45 ?? 8B 00 8B 55 ?? 81 C2 00 10 00 00 39 D0 73 ?? C7 45 ?? 01 00 00 00 83 7D ?? 00 0F 84 ?? ?? ?? ?? 8B 45 ?? 8B 00 39 45 ?? 0F 83 ?? ?? ?? ?? 8B 45 ?? 8B 00 8B 4D ?? 8B 55 ?? 01 CA 39 D0 0F 83 ?? ?? ?? ?? B9 00 00 00 00 B8 1C 00 00 00 83 E0 FC 89 C2 B8 00 00 00 00 89 8C 05 ?? ?? ?? ?? 83 C0 04 39 D0 72 ?? 8B 45 ?? 8B 00 C7 44 24 ?? 1C 00 00 00 8D 95 ?? ?? ?? ?? 89 54 24 ?? 89 04 24 A1 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 02 00 00 00 FF D0 83 EC 0C 8B 85 ?? ?? ?? ?? 83 E0 20 85 C0 74 ?? 8B 45 ?? 8B 00 C7 44 24 ?? 30 14 00 6D 89 04 24 C7 85 ?? ?? ?? ?? 02 00 00 00 E8 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 00 00 00 00 EB ?? 90 EB ?? 90 83 45 ?? 04 E9 ?? ?? ?? ?? 8B 45 ?? 89 45 ?? 8B 45 ?? 8B 40 ?? 89 C2 8B 45 ?? 01 D0 89 45 ?? 8B 45 ?? 8B 50 ?? 8B 45 ?? 01 D0 89 45 ?? C7 44 24 ?? 30 14 00 6D 8B 45 ?? 89 04 24 C7 85 ?? ?? ?? ?? 02 00 00 00 E8 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 01 00 00 00 8D 85 ?? ?? ?? ?? 89 C1 E8 ?? ?? ?? ?? 83 BD ?? ?? ?? ?? 01 EB ?? 8B 95 ?? ?? ?? ?? 8B 85 ?? ?? ?? ?? 85 C0 74 ?? 83 E8 01 85 C0 74 ?? 83 E8 01 0F 0B 89 95 ?? ?? ?? ?? 8D 45 ?? 89 C1 E8 ?? ?? ?? ?? 8B 85 ?? ?? ?? ?? 89 04 24 C7 85 ?? ?? ?? ?? FF FF FF FF E8 ?? ?? ?? ?? 89 95 ?? ?? ?? ?? 8D 85 ?? ?? ?? ?? 89 C1 E8 ?? ?? ?? ?? 8B 85 ?? ?? ?? ?? 89 04 24 C7 85 ?? ?? ?? ?? FF FF FF FF E8 ?? ?? ?? ?? 90 8D 85 ?? ?? ?? ?? 89 04 24 E8 ?? ?? ?? ?? 8D 65 ?? 5B 5E 5F 5D C3 }
		$cond5 = { 55 89 E5 57 56 53 81 EC FC 06 00 00 C7 85 ?? ?? ?? ?? B0 EF 3D 6A C7 85 ?? ?? ?? ?? 8C FF 3D 6A 8D 85 ?? ?? ?? ?? 89 28 BA F4 1A 3C 6A 89 50 ?? 89 60 ?? 8D 85 ?? ?? ?? ?? 89 04 24 E8 ?? ?? ?? ?? A1 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? FF FF FF FF FF D0 C7 44 24 ?? 04 01 00 00 8D 95 ?? ?? ?? ?? 89 54 24 ?? 89 04 24 E8 ?? ?? ?? ?? 83 EC 0C 85 C0 0F 94 C0 84 C0 0F 85 ?? ?? ?? ?? 8D 45 ?? 89 C1 E8 ?? ?? ?? ?? 8D 85 ?? ?? ?? ?? 8D 55 ?? 89 54 24 ?? 8D 95 ?? ?? ?? ?? 89 14 24 C7 85 ?? ?? ?? ?? 01 00 00 00 89 C1 E8 ?? ?? ?? ?? 83 EC 08 8D 45 ?? 89 C1 E8 ?? ?? ?? ?? A1 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 02 00 00 00 FF D0 89 44 24 ?? C7 04 24 08 00 00 00 E8 ?? ?? ?? ?? 83 EC 08 89 45 ?? 83 7D ?? 00 75 ?? C7 85 ?? ?? ?? ?? 00 00 00 00 E9 ?? ?? ?? ?? C7 45 ?? 00 00 00 00 C7 45 ?? 00 00 00 00 C7 85 ?? ?? ?? ?? 28 04 00 00 8D 85 ?? ?? ?? ?? 89 44 24 ?? 8B 45 ?? 89 04 24 C7 85 ?? ?? ?? ?? 02 00 00 00 E8 ?? ?? ?? ?? 83 EC 08 89 45 ?? 83 7D ?? 00 74 ?? 8D 85 ?? ?? ?? ?? C7 44 24 ?? 00 00 00 00 8D 95 ?? ?? ?? ?? 83 C2 20 89 14 24 89 C1 E8 ?? ?? ?? ?? 83 EC 08 83 F8 FF 0F 95 C0 84 C0 74 ?? 8B 85 ?? ?? ?? ?? 89 45 ?? 8B 85 ?? ?? ?? ?? 89 45 ?? 8D 85 ?? ?? ?? ?? 89 44 24 ?? 8B 45 ?? 89 04 24 C7 85 ?? ?? ?? ?? 02 00 00 00 E8 ?? ?? ?? ?? 83 EC 08 89 45 ?? EB ?? 8B 45 ?? 89 04 24 A1 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 02 00 00 00 FF D0 83 EC 04 83 7D ?? 00 74 ?? 83 7D ?? 00 75 ?? C7 85 ?? ?? ?? ?? 00 00 00 00 E9 ?? ?? ?? ?? C7 04 24 62 40 41 6A A1 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 02 00 00 00 FF D0 83 EC 04 C7 44 24 ?? 6E 40 41 6A 89 04 24 A1 ?? ?? ?? ?? FF D0 83 EC 08 89 45 ?? 89 E8 89 45 ?? 8D 85 ?? ?? ?? ?? 89 44 24 ?? 8D 85 ?? ?? ?? ?? 89 04 24 A1 ?? ?? ?? ?? FF D0 83 EC 08 C7 45 ?? 00 00 00 00 8B 55 ?? 8B 85 ?? ?? ?? ?? 39 C2 0F 83 ?? ?? ?? ?? 8B 45 ?? 8B 00 3D FF 0F 00 00 0F 86 ?? ?? ?? ?? 8B 45 ?? 8B 00 39 45 ?? 73 ?? 8B 45 ?? 8B 00 8B 55 ?? 81 C2 00 10 00 00 39 D0 73 ?? C7 45 ?? 01 00 00 00 83 7D ?? 00 0F 84 ?? ?? ?? ?? 8B 45 ?? 8B 00 39 45 ?? 0F 83 ?? ?? ?? ?? 8B 45 ?? 8B 00 8B 4D ?? 8B 55 ?? 01 CA 39 D0 0F 83 ?? ?? ?? ?? B9 00 00 00 00 B8 1C 00 00 00 83 E0 FC 89 C2 B8 00 00 00 00 89 8C 05 ?? ?? ?? ?? 83 C0 04 39 D0 72 ?? 8B 45 ?? 8B 00 C7 44 24 ?? 1C 00 00 00 8D 95 ?? ?? ?? ?? 89 54 24 ?? 89 04 24 A1 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 02 00 00 00 FF D0 83 EC 0C 8B 85 ?? ?? ?? ?? 83 E0 20 85 C0 74 ?? 8B 45 ?? 8B 00 C7 44 24 ?? 30 14 3C 6A 89 04 24 C7 85 ?? ?? ?? ?? 02 00 00 00 E8 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 00 00 00 00 EB ?? 90 EB ?? 90 83 45 ?? 04 E9 ?? ?? ?? ?? 8B 45 ?? 89 45 ?? 8B 45 ?? 8B 40 ?? 89 C2 8B 45 ?? 01 D0 89 45 ?? 8B 45 ?? 8B 50 ?? 8B 45 ?? 01 D0 89 45 ?? C7 44 24 ?? 30 14 3C 6A 8B 45 ?? 89 04 24 C7 85 ?? ?? ?? ?? 02 00 00 00 E8 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 01 00 00 00 8D 85 ?? ?? ?? ?? 89 C1 E8 ?? ?? ?? ?? 83 BD ?? ?? ?? ?? 01 EB ?? 8B 95 ?? ?? ?? ?? 8B 85 ?? ?? ?? ?? 85 C0 74 ?? 83 E8 01 85 C0 74 ?? 83 E8 01 0F 0B 89 95 ?? ?? ?? ?? 8D 45 ?? 89 C1 E8 ?? ?? ?? ?? 8B 85 ?? ?? ?? ?? 89 04 24 C7 85 ?? ?? ?? ?? FF FF FF FF E8 ?? ?? ?? ?? 89 95 ?? ?? ?? ?? 8D 85 ?? ?? ?? ?? 89 C1 E8 ?? ?? ?? ?? 8B 85 ?? ?? ?? ?? 89 04 24 C7 85 ?? ?? ?? ?? FF FF FF FF E8 ?? ?? ?? ?? 90 8D 85 ?? ?? ?? ?? 89 04 24 E8 ?? ?? ?? ?? 8D 65 ?? 5B 5E 5F 5D C3 }
		$cond6 = { 55 89 E5 57 56 53 81 EC FC 06 00 00 C7 85 ?? ?? ?? ?? F0 EF D5 63 C7 85 ?? ?? ?? ?? CC FF D5 63 8D 85 ?? ?? ?? ?? 89 28 BA 28 1B D4 63 89 50 ?? 89 60 ?? 8D 85 ?? ?? ?? ?? 89 04 24 E8 ?? ?? ?? ?? A1 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? FF FF FF FF FF D0 C7 44 24 ?? 04 01 00 00 8D 95 ?? ?? ?? ?? 89 54 24 ?? 89 04 24 E8 ?? ?? ?? ?? 83 EC 0C 85 C0 0F 94 C0 84 C0 0F 85 ?? ?? ?? ?? 8D 45 ?? 89 C1 E8 ?? ?? ?? ?? 8D 85 ?? ?? ?? ?? 8D 55 ?? 89 54 24 ?? 8D 95 ?? ?? ?? ?? 89 14 24 C7 85 ?? ?? ?? ?? 01 00 00 00 89 C1 E8 ?? ?? ?? ?? 83 EC 08 8D 45 ?? 89 C1 E8 ?? ?? ?? ?? A1 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 02 00 00 00 FF D0 89 44 24 ?? C7 04 24 08 00 00 00 E8 ?? ?? ?? ?? 83 EC 08 89 45 ?? 83 7D ?? 00 75 ?? C7 85 ?? ?? ?? ?? 00 00 00 00 E9 ?? ?? ?? ?? C7 45 ?? 00 00 00 00 C7 45 ?? 00 00 00 00 C7 85 ?? ?? ?? ?? 28 04 00 00 8D 85 ?? ?? ?? ?? 89 44 24 ?? 8B 45 ?? 89 04 24 C7 85 ?? ?? ?? ?? 02 00 00 00 E8 ?? ?? ?? ?? 83 EC 08 89 45 ?? 83 7D ?? 00 74 ?? 8D 85 ?? ?? ?? ?? C7 44 24 ?? 00 00 00 00 8D 95 ?? ?? ?? ?? 83 C2 20 89 14 24 89 C1 E8 ?? ?? ?? ?? 83 EC 08 83 F8 FF 0F 95 C0 84 C0 74 ?? 8B 85 ?? ?? ?? ?? 89 45 ?? 8B 85 ?? ?? ?? ?? 89 45 ?? 8D 85 ?? ?? ?? ?? 89 44 24 ?? 8B 45 ?? 89 04 24 C7 85 ?? ?? ?? ?? 02 00 00 00 E8 ?? ?? ?? ?? 83 EC 08 89 45 ?? EB ?? 8B 45 ?? 89 04 24 A1 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 02 00 00 00 FF D0 83 EC 04 83 7D ?? 00 74 ?? 83 7D ?? 00 75 ?? C7 85 ?? ?? ?? ?? 00 00 00 00 E9 ?? ?? ?? ?? C7 04 24 7E 40 D9 63 A1 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 02 00 00 00 FF D0 83 EC 04 C7 44 24 ?? 8A 40 D9 63 89 04 24 A1 ?? ?? ?? ?? FF D0 83 EC 08 89 45 ?? 89 E8 89 45 ?? 8D 85 ?? ?? ?? ?? 89 44 24 ?? 8D 85 ?? ?? ?? ?? 89 04 24 A1 ?? ?? ?? ?? FF D0 83 EC 08 C7 45 ?? 00 00 00 00 8B 55 ?? 8B 85 ?? ?? ?? ?? 39 C2 0F 83 ?? ?? ?? ?? 8B 45 ?? 8B 00 3D FF 0F 00 00 0F 86 ?? ?? ?? ?? 8B 45 ?? 8B 00 39 45 ?? 73 ?? 8B 45 ?? 8B 00 8B 55 ?? 81 C2 00 10 00 00 39 D0 73 ?? C7 45 ?? 01 00 00 00 83 7D ?? 00 0F 84 ?? ?? ?? ?? 8B 45 ?? 8B 00 39 45 ?? 0F 83 ?? ?? ?? ?? 8B 45 ?? 8B 00 8B 4D ?? 8B 55 ?? 01 CA 39 D0 0F 83 ?? ?? ?? ?? B9 00 00 00 00 B8 1C 00 00 00 83 E0 FC 89 C2 B8 00 00 00 00 89 8C 05 ?? ?? ?? ?? 83 C0 04 39 D0 72 ?? 8B 45 ?? 8B 00 C7 44 24 ?? 1C 00 00 00 8D 95 ?? ?? ?? ?? 89 54 24 ?? 89 04 24 A1 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 02 00 00 00 FF D0 83 EC 0C 8B 85 ?? ?? ?? ?? 83 E0 20 85 C0 74 ?? 8B 45 ?? 8B 00 C7 44 24 ?? 30 14 D4 63 89 04 24 C7 85 ?? ?? ?? ?? 02 00 00 00 E8 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 00 00 00 00 EB ?? 90 EB ?? 90 83 45 ?? 04 E9 ?? ?? ?? ?? 8B 45 ?? 89 45 ?? 8B 45 ?? 8B 40 ?? 89 C2 8B 45 ?? 01 D0 89 45 ?? 8B 45 ?? 8B 50 ?? 8B 45 ?? 01 D0 89 45 ?? C7 44 24 ?? 30 14 D4 63 8B 45 ?? 89 04 24 C7 85 ?? ?? ?? ?? 02 00 00 00 E8 ?? ?? ?? ?? C7 85 ?? ?? ?? ?? 01 00 00 00 8D 85 ?? ?? ?? ?? 89 C1 E8 ?? ?? ?? ?? 83 BD ?? ?? ?? ?? 01 EB ?? 8B 95 ?? ?? ?? ?? 8B 85 ?? ?? ?? ?? 85 C0 74 ?? 83 E8 01 85 C0 74 ?? 83 E8 01 0F 0B 89 95 ?? ?? ?? ?? 8D 45 ?? 89 C1 E8 ?? ?? ?? ?? 8B 85 ?? ?? ?? ?? 89 04 24 C7 85 ?? ?? ?? ?? FF FF FF FF E8 ?? ?? ?? ?? 89 95 ?? ?? ?? ?? 8D 85 ?? ?? ?? ?? 89 C1 E8 ?? ?? ?? ?? 8B 85 ?? ?? ?? ?? 89 04 24 C7 85 ?? ?? ?? ?? FF FF FF FF E8 ?? ?? ?? ?? 90 8D 85 ?? ?? ?? ?? 89 04 24 E8 ?? ?? ?? ?? 8D 65 ?? 5B 5E 5F 5D C3 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x010B ) and any of them
}
rule FIREEYE_RT_APT_Loader_Win32_PGF_2 : FILE
{
	meta:
		description = "base dlls: /lib/payload/techniques/dllmain/"
		author = "FireEye"
		id = "e11a626b-ce91-5f6c-a514-9a8a02a29cbd"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/PGF/production/yara/APT_Loader_Win32_PGF_2.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "04eb45f8546e052fe348fda2425b058c"
		logic_hash = "d69f3f31c4964fe933295563e08bdbb36abadd6611541b9ffa55b6829ced1d21"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-25"
		date_modified = "2020-11-25"
		rev = 1

	strings:
		$sb1 = { 6A ?? FF 15 [4-16] 8A ?? 04 [0-16] 8B ?? 1C [0-64] 0F 10 ?? 66 0F EF C8 0F 11 [0-32] 30 [2] 8D [2] 4? 83 [2] 7? }
		$sb2 = { 8B ?? 08 [0-16] 6A 40 68 00 30 00 00 5? 6A 00 [0-32] FF 15 [4-32] 5? [0-16] E8 [4-64] C1 ?? 04 [0-32] 8A [2] 3? [2] 4? 3? ?? 24 ?? 7? }
		$sb3 = { 8B ?? 3C [0-16] 03 [1-64] 0F B? ?? 14 [0-32] 83 ?? 18 [0-32] 66 3? ?? 06 [4-32] 68 [4] 5? FF 15 [4-16] 85 C0 [2-32] 83 ?? 28 0F B? ?? 06 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x010B ) and all of them
}
rule FIREEYE_RT_APT_Loader_Win32_PGF_1 : FILE
{
	meta:
		description = "base dlls: /lib/payload/techniques/unmanaged_exports/"
		author = "FireEye"
		id = "1af4f2ce-c540-5836-a749-43a0b08609b1"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/PGF/production/yara/APT_Loader_Win32_PGF_1.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "383161e4deaf7eb2ebeda2c5e9c3204c"
		logic_hash = "d3fb0bd7b678b19ee2e0e846f4e13e4ce7e2629ecda123f34ef52f2af42d2a8e"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-25"
		date_modified = "2020-11-25"
		rev = 1

	strings:
		$sb1 = { 6A ?? FF 15 [4-32] 8A ?? 04 [0-32] 8B ?? 89 ?? 8B [2] 89 [2] 8B [2] 89 ?? 08 8B [2] 89 [2] 8B [2] 89 [2-64] 8B [5] 83 ?? 01 89 [5] 83 [5-32] 0F B6 [1-2] 0F B6 [1-2] 33 [1-16] 88 ?? EB }
		$sb2 = { 6A 40 [0-32] 68 00 30 00 00 [0-32] 6A 00 [0-16] FF 15 [4-32] 89 45 [4-64] E8 [4-32] 83 ?? 01 [4-80] 0F B6 [1-64] 33 [1-32] 88 [2-64] FF ( D? | 55 ) }
		$sb3 = { 8B ?? 08 03 ?? 3C [2-32] 0F B? ?? 14 [0-32] 8D [2] 18 [2-64] 0F B? ?? 06 [3-64] 6B ?? 28 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x010B ) and all of them
}
rule FIREEYE_RT_APT_Loader_Win64_PGF_2 : FILE
{
	meta:
		description = "base dlls: /lib/payload/techniques/dllmain/"
		author = "FireEye"
		id = "5253cb2a-28fd-57ab-be3d-f11cf2ea24cf"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/PGF/production/yara/APT_Loader_Win64_PGF_2.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "4326a7e863928ffbb5f6bdf63bb9126e"
		logic_hash = "074f6d9ad78ecd4dd8e3d0b5c8b0f61a48374f3935b85c4222305b207b447ec7"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-25"
		date_modified = "2020-11-25"
		rev = 2

	strings:
		$sb1 = { B9 [4] FF 15 [4-32] 8B ?? 1C [0-16] 0F B? ?? 04 [0-64] F3 0F 6F 00 [0-64] 66 0F EF C8 [0-64] F3 0F 7F 08 [0-64] 30 ?? 48 8D 40 01 48 83 ?? 01 7? }
		$sb2 = { 44 8B ?? 08 [0-32] 41 B8 00 30 00 00 [0-16] FF 15 [4-32] 48 8B C8 [0-16] E8 [4-64] 4D 8D 49 01 [0-32] C1 ?? 04 [0-64] 0F B? [2-16] 41 30 ?? FF 45 3? ?? 7? }
		$sb3 = { 63 ?? 3C [0-16] 03 [1-32] 0F B? ?? 14 [0-16] 8D ?? 18 [0-16] 03 [1-16] 66 ?? 3B ?? 06 7? [1-64] 48 8D 15 [4-32] FF 15 [4-16] 85 C0 [2-32] 41 0F B? ?? 06 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) and all of them
}
rule FIREEYE_RT_APT_Loader_MSIL_PGF_2 : FILE
{
	meta:
		description = "base.js, ./lib/payload/techniques/jscriptdotnet/jscriptdotnet_payload.py"
		author = "FireEye"
		id = "c5f2ec90-cd9b-53ce-893b-e44192fcd507"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/PGF/production/yara/APT_Loader_MSIL_PGF_2.yar#L4-L20"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "7c2a06ceb29cdb25f24c06f2a8892fba"
		logic_hash = "b962ea30c063009c0383e25edda3a65202bea4496d0d6228549dcea82bba0d03"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-25"
		date_modified = "2020-11-25"
		rev = 1

	strings:
		$sb1 = { 2? 00 10 00 00 0A 1? 40 0? 72 [4] 0? 0? 28 [2] 00 0A 0? 03 28 [2] 00 0A 74 [2] 00 01 6F [2] 00 0A 03 1? 0? 74 [2] 00 01 28 [2] 00 0A 6? 0? 0? 28 [2] 00 06 D0 [2] 00 01 28 [2] 00 0A 1? 28 [2] 00 0A 79 [2] 00 01 71 [2] 00 01 13 ?? 0? 1? 11 ?? 0? 74 [2] 00 01 28 [2] 00 0A 28 [2] 00 0A 7E [2] 00 0A 13 ?? 1? 13 ?? 7E [2] 00 0A 13 ?? 03 28 [2] 00 0A 74 [2] 00 01 6F [2] 00 0A 03 1? 1? 11 ?? 11 ?? 1? 11 ?? 28 [2] 00 06 }
		$ss1 = "\x00CreateThread\x00"
		$ss2 = "\x00ScriptObjectStackTop\x00"
		$ss3 = "\x00Microsoft.JScript\x00"

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_APT_Loader_Win64_PGF_5 : FILE
{
	meta:
		description = "PGF payload, generated rule based on symfunc/8167a6d94baca72bac554299d7c7f83c"
		author = "FireEye"
		id = "4fa4a1d6-cb63-582d-801c-b4c89c44d9ca"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/PGF/production/yara/APT_Loader_Win64_PGF_5.yar#L4-L18"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "150224a0ccabce79f963795bf29ec75b"
		logic_hash = "16495ad1e5ce4d4a79f4067f3d687911a1a0a3bfe4c6409ff9de4d111b1ddca6"
		score = 75
		quality = 75
		tags = "FILE"
		rev = 3

	strings:
		$cond1 = { 4C 89 44 24 18 89 54 24 10 48 89 4C 24 08 48 83 EC 38 48 8B 4C 24 40 FF 15 13 FA FF FF 8B 44 24 48 89 44 24 20 83 7C 24 20 01 74 02 EB 17 48 8B 44 24 40 48 89 05 66 23 00 00 48 8B 4C 24 40 FF 15 EB F9 FF FF B8 01 00 00 00 48 83 C4 38 C3 }
		$cond2 = { 4C 89 44 24 18 89 54 24 10 48 89 4C 24 08 48 83 EC 38 48 8B 4C 24 40 FF 15 A3 FA FF FF 8B 44 24 48 89 44 24 20 83 7C 24 20 01 74 02 EB 17 48 8B 44 24 40 48 89 05 F6 20 00 00 48 8B 4C 24 40 FF 15 7B FA FF FF B8 01 00 00 00 48 83 C4 38 C3 }
		$cond3 = { 4C 89 44 24 18 89 54 24 10 48 89 4C 24 08 48 83 EC 38 48 8B 4C 24 40 FF ?? ?? ?? ?? ?? 8B 44 24 48 89 44 24 20 83 7C 24 2? ?1 74 ?? EB ?? 48 8B 44 24 40 48 ?? ?? ?? ?? ?? ?? 48 8B 4C 24 40 FF ?? ?? ?? ?? ?? B8 01 ?? ?? ?? 48 83 C4 38 C3 }
		$cond4 = { 4C 89 44 24 ?? 89 54 24 ?? 48 89 4C 24 ?? 48 83 EC 38 48 8B 4C 24 ?? FF 15 ?? ?? ?? ?? 8B 44 24 ?? 89 44 24 ?? 83 7C 24 ?? 01 74 ?? EB ?? 48 8B 44 24 ?? 48 89 05 ?? ?? ?? ?? 48 8B 4C 24 ?? FF 15 ?? ?? ?? ?? B8 01 00 00 00 48 83 C4 38 C3 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) and any of them
}
rule FIREEYE_RT_APT_Loader_Win32_PGF_4 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "d46d9ae9-cb7d-5a25-9ee2-766097c14af6"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/PGF/production/yara/APT_Loader_Win32_PGF_4.yar#L4-L17"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "4414953fa397a41156f6fa4f9462d207"
		logic_hash = "4256bfd3713f330d76cad9d1ddbba91e588dbca2e2b6842e9482525805ddc1e8"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-26"
		date_modified = "2020-11-26"
		rev = 1

	strings:
		$sb1 = { C7 44 24 0C 04 00 00 00 C7 44 24 08 00 10 00 00 [4-32] C7 04 24 00 00 00 00 [0-32] FF [1-16] 89 45 ?? 83 7D ?? 00 [2-150] 0F B? ?? 8B [2] B? CD CC CC CC 89 ?? F7 ?? C1 ?? 04 89 ?? C1 ?? 02 [0-32] 0F B? [5-32] 3? [1-16] 88 }
		$sb2 = { C? 45 ?? B8 [0-4] C? 45 ?? 00 [0-64] FF [0-32] E0 [0-32] C7 44 24 08 40 00 00 00 [0-32] C7 44 24 04 07 00 00 00 [0-32] FF [1-64] 89 ?? 0F B? [2-3] 89 ?? 04 0F B? [2] 88 ?? 06 8B ?? 08 8D ?? 01 8B 45 0C }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x010B ) and all of them
}
rule FIREEYE_RT_APT_Loader_MSIL_PGF_1 : FILE
{
	meta:
		description = "base.cs"
		author = "FireEye"
		id = "39d9821f-86e8-528a-a0a9-287dbe325484"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/PGF/production/yara/APT_Loader_MSIL_PGF_1.yar#L4-L17"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "a495c6d11ff3f525915345fb762f8047"
		logic_hash = "4174ed53336f3951d26282dc81b99b2044ac6350d4b4c0074194a9b4acecefee"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-24"
		date_modified = "2020-11-24"
		rev = 1

	strings:
		$sb1 = { 72 [4] 6F [2] 00 0A 26 [0-16] 0? 6F [2] 00 0A [1-3] 0? 28 [2] 00 0A [0-1] 0? 72 [4-5] 0? 28 [2] 00 0A [0-1] 0? 6F [2] 00 0A 13 ?? 1? 13 ?? 38 [8-16] 91 [3-6] 8E 6? 5D 91 61 D2 9C 11 ?? 1? 58 13 [3-5] 8E 6? 3F }

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_APT_Loader_Win64_PGF_4 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "4c93ba76-d3a5-568d-88b8-79a6ebc2edbb"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/PGF/production/yara/APT_Loader_Win64_PGF_4.yar#L4-L17"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "3bb34ebd93b8ab5799f4843e8cc829fa"
		logic_hash = "fcc92674e58ec6418d7c709e3f3bc2e1ec859fe0cb444412964a978fb69f5234"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-26"
		date_modified = "2020-11-26"
		rev = 1

	strings:
		$sb1 = { 41 B9 04 00 00 00 41 B8 00 10 00 00 BA [4] B9 00 00 00 00 [0-32] FF [1-24] 7? [1-150] 8B 45 [0-32] 44 0F B? ?? 8B [2-16] B? CD CC CC CC [0-16] C1 ?? 04 [0-16] C1 ?? 02 [0-16] C1 ?? 02 [0-16] 48 8? 05 [4-32] 31 [1-4] 88 }
		$sb2 = { C? 45 ?? 48 [0-32] B8 [0-64] FF [0-32] E0 [0-32] 41 B8 40 00 00 00 BA 0C 00 00 00 48 8B [2] 48 8B [2-32] FF [1-16] 48 89 10 8B 55 ?? 89 ?? 08 48 8B [2] 48 8D ?? 02 48 8B 45 18 48 89 02 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) and all of them
}
rule FIREEYE_RT_APT_Loader_Win32_PGF_5 : FILE
{
	meta:
		description = "PGF payload, generated rule based on symfunc/a86b004b5005c0bcdbd48177b5bac7b8"
		author = "FireEye"
		id = "376875f3-00f2-58d0-ae22-7f52ea566da2"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/PGF/production/yara/APT_Loader_Win32_PGF_5.yar#L4-L18"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "8c91a27bbdbe9fb0877daccd28bd7bb5"
		logic_hash = "dfff615a1d329cf181294f7b0a32c11a21d66ff8a6aa6b9fcd183c9738369623"
		score = 75
		quality = 75
		tags = "FILE"
		rev = 3

	strings:
		$cond1 = { 8B FF 55 8B EC 81 EC 30 01 00 00 A1 00 30 00 10 33 C5 89 45 E0 56 C7 45 F8 00 00 00 00 C6 85 D8 FE FF FF 00 68 03 01 00 00 6A 00 8D 85 D9 FE FF FF 50 E8 F9 07 00 00 83 C4 0C C7 45 F4 00 00 00 00 C6 45 E7 00 C7 45 E8 00 00 00 00 C7 45 EC 00 00 00 00 C7 45 FC 00 00 00 00 C7 45 F0 00 00 00 00 6A 01 6A 00 8D 8D D8 FE FF FF 51 6A 00 68 9C 10 00 10 8B 15 10 30 00 10 52 E8 31 01 00 00 89 45 F8 6A 14 FF 15 5C 10 00 10 83 C4 04 89 45 E8 8B 45 F8 8A 48 04 88 4D E7 8B 55 F8 83 C2 0C 8B 45 E8 8B 0A 89 08 8B 4A 04 89 48 04 8B 4A 08 89 48 08 8B 4A 0C 89 48 0C 8B 52 10 89 50 10 C7 85 D4 FE FF FF 00 00 00 00 EB 0F 8B 85 D4 FE FF FF 83 C0 01 89 85 D4 FE FF FF 83 BD D4 FE FF FF 14 7D 1F 8B 4D E8 03 8D D4 FE FF FF 0F B6 11 0F B6 45 E7 33 D0 8B 4D E8 03 8D D4 FE FF FF 88 11 EB C9 8B 55 F8 8B 42 08 89 45 FC 6A 40 68 00 30 00 00 8B 4D FC 51 6A 00 FF 15 00 10 00 10 89 45 EC 8B 55 FC 52 8B 45 F8 83 C0 20 50 8B 4D EC 51 E8 F0 06 00 00 83 C4 0C C7 85 D0 FE FF FF 00 00 00 00 EB 0F 8B 95 D0 FE FF FF 83 C2 01 89 95 D0 FE FF FF 8B 85 D0 FE FF FF 3B 45 FC 73 30 8B 4D EC 03 8D D0 FE FF FF 0F B6 09 8B 85 D0 FE FF FF 99 BE 14 00 00 00 F7 FE 8B 45 E8 0F B6 14 10 33 CA 8B 45 EC 03 85 D0 FE FF FF 88 08 EB B6 8B 4D EC 89 4D F0 FF 55 F0 5E 8B 4D E0 33 CD E8 6D 06 00 00 8B E5 5D C3 }
		$cond2 = { 8B FF 55 8B EC 81 EC 30 01 00 00 A1 00 30 00 10 33 C5 89 45 E0 56 C7 45 F8 00 00 00 00 C6 85 D8 FE FF FF 00 68 03 01 00 00 6A 00 8D 85 D9 FE FF FF 50 E8 F9 07 00 00 83 C4 0C C7 45 F4 00 00 00 00 C6 45 E7 00 C7 45 E8 00 00 00 00 C7 45 EC 00 00 00 00 C7 45 FC 00 00 00 00 C7 45 F0 00 00 00 00 6A 01 6A 00 8D 8D D8 FE FF FF 51 6A 00 68 9C 10 00 10 8B 15 20 33 00 10 52 E8 31 01 00 00 89 45 F8 6A 14 FF 15 58 10 00 10 83 C4 04 89 45 E8 8B 45 F8 8A 48 04 88 4D E7 8B 55 F8 83 C2 0C 8B 45 E8 8B 0A 89 08 8B 4A 04 89 48 04 8B 4A 08 89 48 08 8B 4A 0C 89 48 0C 8B 52 10 89 50 10 C7 85 D4 FE FF FF 00 00 00 00 EB 0F 8B 85 D4 FE FF FF 83 C0 01 89 85 D4 FE FF FF 83 BD D4 FE FF FF 14 7D 1F 8B 4D E8 03 8D D4 FE FF FF 0F B6 11 0F B6 45 E7 33 D0 8B 4D E8 03 8D D4 FE FF FF 88 11 EB C9 8B 55 F8 8B 42 08 89 45 FC 6A 40 68 00 30 00 00 8B 4D FC 51 6A 00 FF 15 2C 10 00 10 89 45 EC 8B 55 FC 52 8B 45 F8 83 C0 20 50 8B 4D EC 51 E8 F0 06 00 00 83 C4 0C C7 85 D0 FE FF FF 00 00 00 00 EB 0F 8B 95 D0 FE FF FF 83 C2 01 89 95 D0 FE FF FF 8B 85 D0 FE FF FF 3B 45 FC 73 30 8B 4D EC 03 8D D0 FE FF FF 0F B6 09 8B 85 D0 FE FF FF 99 BE 14 00 00 00 F7 FE 8B 45 E8 0F B6 14 10 33 CA 8B 45 EC 03 85 D0 FE FF FF 88 08 EB B6 8B 4D EC 89 4D F0 FF 55 F0 5E 8B 4D E0 33 CD E8 6D 06 00 00 8B E5 5D C3 }
		$cond3 = { 8B FF 55 8B EC 81 EC 30 01 00 00 A1 ?? ?? ?? ?? 33 C5 89 45 ?? 56 C7 45 ?? 00 00 00 00 C6 85 ?? ?? ?? ?? 00 68 03 01 00 00 6A 00 8D 85 ?? ?? ?? ?? 50 E8 ?? ?? ?? ?? 83 C4 0C C7 45 ?? 00 00 00 00 C6 45 ?? 00 C7 45 ?? 00 00 00 00 C7 45 ?? 00 00 00 00 C7 45 ?? 00 00 00 00 C7 45 ?? 00 00 00 00 6A 01 6A 00 8D 8D ?? ?? ?? ?? 51 6A 00 68 9C 10 00 10 8B 15 ?? ?? ?? ?? 52 E8 ?? ?? ?? ?? 89 45 ?? 6A 14 FF 15 ?? ?? ?? ?? 83 C4 04 89 45 ?? 8B 45 ?? 8A 48 ?? 88 4D ?? 8B 55 ?? 83 C2 0C 8B 45 ?? 8B 0A 89 08 8B 4A ?? 89 48 ?? 8B 4A ?? 89 48 ?? 8B 4A ?? 89 48 ?? 8B 52 ?? 89 50 ?? C7 85 ?? ?? ?? ?? 00 00 00 00 EB ?? 8B 85 ?? ?? ?? ?? 83 C0 01 89 85 ?? ?? ?? ?? 83 BD ?? ?? ?? ?? 14 7D ?? 8B 4D ?? 03 8D ?? ?? ?? ?? 0F B6 11 0F B6 45 ?? 33 D0 8B 4D ?? 03 8D ?? ?? ?? ?? 88 11 EB ?? 8B 55 ?? 8B 42 ?? 89 45 ?? 6A 40 68 00 30 00 00 8B 4D ?? 51 6A 00 FF 15 ?? ?? ?? ?? 89 45 ?? 8B 55 ?? 52 8B 45 ?? 83 C0 20 50 8B 4D ?? 51 E8 ?? ?? ?? ?? 83 C4 0C C7 85 ?? ?? ?? ?? 00 00 00 00 EB ?? 8B 95 ?? ?? ?? ?? 83 C2 01 89 95 ?? ?? ?? ?? 8B 85 ?? ?? ?? ?? 3B 45 ?? 73 ?? 8B 4D ?? 03 8D ?? ?? ?? ?? 0F B6 09 8B 85 ?? ?? ?? ?? 99 BE 14 00 00 00 F7 FE 8B 45 ?? 0F B6 14 10 33 CA 8B 45 ?? 03 85 ?? ?? ?? ?? 88 08 EB ?? 8B 4D ?? 89 4D ?? FF 55 ?? 5E 8B 4D ?? 33 CD E8 ?? ?? ?? ?? 8B E5 5D C3 }
		$cond4 = { 8B FF 55 8B EC 81 EC 3? ?1 ?? ?? A1 ?? ?? ?? ?? 33 C5 89 45 E0 56 C7 45 F8 ?? ?? ?? ?? C6 85 D8 FE FF FF ?? 68 ?? ?? ?? ?? 6A ?? 8D 85 D9 FE FF FF 50 E8 ?? ?? ?? ?? 83 C4 0C C7 45 F4 ?? ?? ?? ?? C6 45 E7 ?? C7 45 E8 ?? ?? ?? ?? C7 45 EC ?? ?? ?? ?? C7 45 FC ?? ?? ?? ?? C7 45 F? ?? ?? ?? ?0 6A ?? 6A ?? 8D 8D D8 FE FF FF 51 6A ?? 68 ?? ?? ?? ?? 8B ?? ?? ?? ?? ?? 52 E8 ?? ?? ?? ?? 89 45 F8 6A ?? FF ?? ?? ?? ?? ?? 83 C4 04 89 45 E8 8B 45 F8 8A 48 04 88 4D E7 8B 55 F8 83 ?? ?? 8B 45 E8 8B 0A 89 08 8B 4A 04 89 48 04 8B 4A 08 89 48 08 8B 4A 0C 89 48 0C 8B 52 10 89 50 10 C7 85 D4 FE FF FF ?? ?? ?? ?? EB ?? 8B 85 D4 FE FF FF 83 C? ?1 89 85 D4 FE FF FF 83 BD D4 FE FF FF 14 7D ?? 8B 4D E8 03 8D D4 FE FF FF 0F B6 11 0F B6 45 E7 33 D0 8B 4D E8 03 8D D4 FE FF FF 88 11 EB ?? 8B 55 F8 8B 42 08 89 45 FC 6A ?? 68 ?? ?? ?? ?? 8B 4D FC 51 6A ?? FF ?? ?? ?? ?? ?? 89 45 EC 8B 55 FC 52 8B 45 F8 83 ?? ?? 50 8B 4D EC 51 E8 ?? ?? ?? ?? 83 C4 0C C7 85 D0 FE FF FF ?? ?? ?? ?? EB ?? 8B 95 D0 FE FF FF 83 C2 01 89 95 D0 FE FF FF 8B 85 D0 FE FF FF 3B 45 FC 73 ?? 8B 4D EC 03 8D D0 FE FF FF 0F B6 09 8B 85 D0 FE FF FF 99 BE ?? ?? ?? ?? F7 FE 8B 45 E8 0F B6 14 10 33 CA 8B 45 EC 03 85 D0 FE FF FF 88 08 EB ?? 8B 4D EC 89 4D F0 FF ?? ?? 5E 8B 4D E0 33 CD E8 ?? ?? ?? ?? 8B E5 5D C3 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x010B ) and any of them
}
rule FIREEYE_RT_APT_Loader_Win_PGF_2 : FILE
{
	meta:
		description = "PE rich header matches PGF backdoor"
		author = "FireEye"
		id = "595c9e2a-3d9d-5366-9449-de1bcf333f78"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/PGF/production/yara/APT_Loader_Win_PGF_2.yar#L4-L21"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "226b1ac427eb5a4dc2a00cc72c163214"
		hash = "2398ed2d5b830d226af26dedaf30f64a"
		hash = "24a7c99da9eef1c58f09cf09b9744d7b"
		hash = "aeb0e1d0e71ce2a08db9b1e5fb98e0aa"
		logic_hash = "b8c024c6b4c3ce9915700b62da8a1f12440215b46f3a56078707f5257e575811"
		score = 75
		quality = 75
		tags = "FILE"
		rev = 4

	strings:
		$rich1 = { A8 B7 17 3A EC D6 79 69 EC D6 79 69 EC D6 79 69 2F D9 24 69 E8 D6 79 69 E5 AE EC 69 EA D6 79 69 EC D6 78 69 A8 D6 79 69 E5 AE EA 69 EF D6 79 69 E5 AE FA 69 D0 D6 79 69 E5 AE EB 69 ED D6 79 69 E5 AE FD 69 E2 D6 79 69 CB 10 07 69 ED D6 79 69 E5 AE E8 69 ED D6 79 69 }
		$rich2 = { C1 CF 75 A4 85 AE 1B F7 85 AE 1B F7 85 AE 1B F7 8C D6 88 F7 83 AE 1B F7 0D C9 1A F6 87 AE 1B F7 0D C9 1E F6 8F AE 1B F7 0D C9 1F F6 8F AE 1B F7 0D C9 18 F6 84 AE 1B F7 DE C6 1A F6 86 AE 1B F7 85 AE 1A F7 BF AE 1B F7 84 C3 12 F6 81 AE 1B F7 84 C3 E4 F7 84 AE 1B F7 84 C3 19 F6 84 AE 1B F7 }
		$rich3 = { D6 60 82 B8 92 01 EC EB 92 01 EC EB 92 01 EC EB 9B 79 7F EB 94 01 EC EB 1A 66 ED EA 90 01 EC EB 1A 66 E9 EA 98 01 EC EB 1A 66 E8 EA 9A 01 EC EB 1A 66 EF EA 90 01 EC EB C9 69 ED EA 91 01 EC EB 92 01 ED EB AF 01 EC EB 93 6C E5 EA 96 01 EC EB 93 6C 13 EB 93 01 EC EB 93 6C EE EA 93 01 EC EB }
		$rich4 = { 41 36 64 33 05 57 0A 60 05 57 0A 60 05 57 0A 60 73 CA 71 60 01 57 0A 60 0C 2F 9F 60 04 57 0A 60 0C 2F 89 60 3D 57 0A 60 0C 2F 8E 60 0A 57 0A 60 05 57 0B 60 4A 57 0A 60 0C 2F 99 60 06 57 0A 60 73 CA 67 60 04 57 0A 60 0C 2F 98 60 04 57 0A 60 0C 2F 80 60 04 57 0A 60 22 91 74 60 04 57 0A 60 0C 2F 9B 60 04 57 0A 60 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and filesize < 15MB and ( ( $rich1 at 128 ) or ( $rich2 at 128 ) or ( $rich3 at 128 ) or ( $rich4 at 128 ) )
}
rule FIREEYE_RT_APT_Loader_Win64_PGF_3 : FILE
{
	meta:
		description = "PGF payload, generated rule based on symfunc/8a2f2236fdfaa3583ab89076025c6269. Identifies dllmain_hook x64 payloads."
		author = "FireEye"
		id = "340ea6d4-7111-520c-9bd4-0465a43ea235"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/PGF/production/yara/APT_Loader_Win64_PGF_3.yar#L4-L18"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "3bb34ebd93b8ab5799f4843e8cc829fa"
		logic_hash = "fd82bdec54a76eed12cc8820ef39899f31ea6df21d905530a0d53770b3d9901b"
		score = 75
		quality = 75
		tags = "FILE"
		rev = 4

	strings:
		$cond1 = { 55 53 48 89 E5 48 81 EC 28 07 00 00 48 8B 05 80 8B 06 00 FF D0 48 89 C1 48 8D 85 98 FD FF FF 41 B8 04 01 00 00 48 89 C2 E8 5A B4 00 00 85 C0 0F 94 C0 84 C0 0F 85 16 03 00 00 48 8D 45 AF 48 89 C1 E8 E9 FE 00 00 48 8D 4D AF 48 8D 95 98 FD FF FF 48 8D 85 78 FD FF FF 49 89 C8 48 89 C1 E8 AC 96 01 00 48 8D 45 AF 48 89 C1 E8 F0 FE 00 00 48 8B 05 25 8B 06 00 FF D0 89 C2 B9 08 00 00 00 E8 6B B4 00 00 48 89 45 D0 48 83 7D D0 00 75 0A BB 00 00 00 00 E9 6C 02 00 00 48 C7 45 F0 00 00 00 00 C7 45 EC 00 00 00 00 C7 85 38 F9 FF FF 38 04 00 00 48 8D 95 38 F9 FF FF 48 8B 45 D0 48 89 C1 E8 AA B3 00 00 89 45 E8 83 7D E8 00 74 57 48 8D 85 38 F9 FF FF 48 8D 50 30 48 8D 85 78 FD FF FF 41 B8 00 00 00 00 48 89 C1 E8 61 F3 00 00 48 83 F8 FF 0F 95 C0 84 C0 74 14 48 8B 85 50 F9 FF FF 48 89 45 F0 8B 85 58 F9 FF FF 89 45 EC 48 8D 95 38 F9 FF FF 48 8B 45 D0 48 89 C1 E8 4F B3 00 00 89 45 E8 EB A3 48 8B 45 D0 48 89 C1 48 8B 05 20 8A 06 00 FF D0 48 83 7D F0 00 74 06 83 7D EC 00 75 0A BB 00 00 00 00 E9 B9 01 00 00 48 8D 0D 0E C8 05 00 48 8B 05 69 8A 06 00 FF D0 48 8D 15 0A C8 05 00 48 89 C1 48 8B 05 5E 8A 06 00 FF D0 48 89 45 C8 48 89 E8 48 89 45 E0 48 8D 95 28 F9 FF FF 48 8D 85 30 F9 FF FF 48 89 C1 48 8B 05 19 8A 06 00 FF D0 C7 45 DC 00 00 00 00 48 8B 55 E0 48 8B 85 28 F9 FF FF 48 39 C2 0F 83 0D 01 00 00 48 8B 45 E0 48 8B 00 48 3D FF 0F 00 00 0F 86 EC 00 00 00 48 8B 45 E0 48 8B 00 48 39 45 C8 73 1E 48 8B 45 E0 48 8B 00 48 8B 55 C8 48 81 C2 00 10 00 00 48 39 D0 73 07 C7 45 DC 01 00 00 00 83 7D DC 00 0F 84 BB 00 00 00 48 8B 45 E0 48 8B 00 48 39 45 F0 0F 83 AA 00 00 00 48 8B 45 E0 48 8B 00 8B 4D EC 48 8B 55 F0 48 01 CA 48 39 D0 0F 83 90 00 00 00 48 C7 85 F8 F8 FF FF 00 00 00 00 48 C7 85 00 F9 FF FF 00 00 00 00 48 C7 85 08 F9 FF FF 00 00 00 00 48 C7 85 10 F9 FF FF 00 00 00 00 48 C7 85 18 F9 FF FF 00 00 00 00 48 C7 85 20 F9 FF FF 00 00 00 00 48 8B 45 E0 48 8B 00 48 8D 95 F8 F8 FF FF 41 B8 30 00 00 00 48 89 C1 48 8B 05 01 8A 06 00 FF D0 8B 85 1C F9 FF FF 83 E0 20 85 C0 74 20 48 8B 45 E0 48 8B 00 48 8D 15 E0 F9 FF FF 48 89 C1 E8 D5 FC FF FF BB 00 00 00 00 EB 57 90 EB 01 90 48 83 45 E0 08 E9 DF FE FF FF 48 8B 45 F0 48 89 45 C0 48 8B 45 C0 8B 40 3C 48 63 D0 48 8B 45 F0 48 01 D0 48 89 45 B8 48 8B 45 B8 8B 40 28 89 C2 48 8B 45 F0 48 01 D0 48 89 45 B0 48 8B 45 B0 48 8D 15 87 F9 FF FF 48 89 C1 E8 7C FC FF FF BB 01 00 00 00 48 8D 85 78 FD FF FF 48 89 C1 E8 CB 9C 01 00 83 FB 01 EB 38 48 89 C3 48 8D 45 AF 48 89 C1 E8 37 FC 00 00 48 89 D8 48 89 C1 E8 4C AA 00 00 48 89 C3 48 8D 85 78 FD FF FF 48 89 C1 E8 9A 9C 01 00 48 89 D8 48 89 C1 E8 2F AA 00 00 90 48 81 C4 28 07 00 00 5B 5D C3 }
		$cond2 = { 55 53 48 89 E5 48 81 EC 28 07 00 00 48 8B 05 ?? ?? ?? ?? FF D0 48 89 C1 48 8D 85 ?? ?? ?? ?? 41 B8 04 01 00 00 48 89 C2 E8 ?? ?? ?? ?? 85 C0 0F 94 C0 84 C0 0F 85 ?? ?? ?? ?? 48 8D 45 ?? 48 89 C1 E8 ?? ?? ?? ?? 48 8D 4D ?? 48 8D 95 ?? ?? ?? ?? 48 8D 85 ?? ?? ?? ?? 49 89 C8 48 89 C1 E8 ?? ?? ?? ?? 48 8D 45 ?? 48 89 C1 E8 ?? ?? ?? ?? 48 8B 05 ?? ?? ?? ?? FF D0 89 C2 B9 08 00 00 00 E8 ?? ?? ?? ?? 48 89 45 ?? 48 83 7D ?? 00 75 ?? BB 00 00 00 00 E9 ?? ?? ?? ?? 48 C7 45 ?? 00 00 00 00 C7 45 ?? 00 00 00 00 C7 85 ?? ?? ?? ?? 38 04 00 00 48 8D 95 ?? ?? ?? ?? 48 8B 45 ?? 48 89 C1 E8 ?? ?? ?? ?? 89 45 ?? 83 7D ?? 00 74 ?? 48 8D 85 ?? ?? ?? ?? 48 8D 50 ?? 48 8D 85 ?? ?? ?? ?? 41 B8 00 00 00 00 48 89 C1 E8 ?? ?? ?? ?? 48 83 F8 FF 0F 95 C0 84 C0 74 ?? 48 8B 85 ?? ?? ?? ?? 48 89 45 ?? 8B 85 ?? ?? ?? ?? 89 45 ?? 48 8D 95 ?? ?? ?? ?? 48 8B 45 ?? 48 89 C1 E8 ?? ?? ?? ?? 89 45 ?? EB ?? 48 8B 45 ?? 48 89 C1 48 8B 05 ?? ?? ?? ?? FF D0 48 83 7D ?? 00 74 ?? 83 7D ?? 00 75 ?? BB 00 00 00 00 E9 ?? ?? ?? ?? 48 8D 0D ?? ?? ?? ?? 48 8B 05 ?? ?? ?? ?? FF D0 48 8D 15 ?? ?? ?? ?? 48 89 C1 48 8B 05 ?? ?? ?? ?? FF D0 48 89 45 ?? 48 89 E8 48 89 45 ?? 48 8D 95 ?? ?? ?? ?? 48 8D 85 ?? ?? ?? ?? 48 89 C1 48 8B 05 ?? ?? ?? ?? FF D0 C7 45 ?? 00 00 00 00 48 8B 55 ?? 48 8B 85 ?? ?? ?? ?? 48 39 C2 0F 83 ?? ?? ?? ?? 48 8B 45 ?? 48 8B 00 48 3D FF 0F 00 00 0F 86 ?? ?? ?? ?? 48 8B 45 ?? 48 8B 00 48 39 45 ?? 73 ?? 48 8B 45 ?? 48 8B 00 48 8B 55 ?? 48 81 C2 00 10 00 00 48 39 D0 73 ?? C7 45 ?? 01 00 00 00 83 7D ?? 00 0F 84 ?? ?? ?? ?? 48 8B 45 ?? 48 8B 00 48 39 45 ?? 0F 83 ?? ?? ?? ?? 48 8B 45 ?? 48 8B 00 8B 4D ?? 48 8B 55 ?? 48 01 CA 48 39 D0 0F 83 ?? ?? ?? ?? 48 C7 85 ?? ?? ?? ?? 00 00 00 00 48 C7 85 ?? ?? ?? ?? 00 00 00 00 48 C7 85 ?? ?? ?? ?? 00 00 00 00 48 C7 85 ?? ?? ?? ?? 00 00 00 00 48 C7 85 ?? ?? ?? ?? 00 00 00 00 48 C7 85 ?? ?? ?? ?? 00 00 00 00 48 8B 45 ?? 48 8B 00 48 8D 95 ?? ?? ?? ?? 41 B8 30 00 00 00 48 89 C1 48 8B 05 ?? ?? ?? ?? FF D0 8B 85 ?? ?? ?? ?? 83 E0 20 85 C0 74 ?? 48 8B 45 ?? 48 8B 00 48 8D 15 ?? ?? ?? ?? 48 89 C1 E8 ?? ?? ?? ?? BB 00 00 00 00 EB ?? 90 EB ?? 90 48 83 45 ?? 08 E9 ?? ?? ?? ?? 48 8B 45 ?? 48 89 45 ?? 48 8B 45 ?? 8B 40 ?? 48 63 D0 48 8B 45 ?? 48 01 D0 48 89 45 ?? 48 8B 45 ?? 8B 40 ?? 89 C2 48 8B 45 ?? 48 01 D0 48 89 45 ?? 48 8B 45 ?? 48 8D 15 ?? ?? ?? ?? 48 89 C1 E8 ?? ?? ?? ?? BB 01 00 00 00 48 8D 85 ?? ?? ?? ?? 48 89 C1 E8 ?? ?? ?? ?? 83 FB 01 EB ?? 48 89 C3 48 8D 45 ?? 48 89 C1 E8 ?? ?? ?? ?? 48 89 D8 48 89 C1 E8 ?? ?? ?? ?? 48 89 C3 48 8D 85 ?? ?? ?? ?? 48 89 C1 E8 ?? ?? ?? ?? 48 89 D8 48 89 C1 E8 ?? ?? ?? ?? 90 48 81 C4 28 07 00 00 5B 5D C3 }
		$cond3 = { 55 53 48 89 E5 48 81 EC 28 07 00 00 48 8B 05 C1 7C 06 00 FF D0 48 89 C1 48 8D 85 98 FD FF FF 41 B8 04 01 00 00 48 89 C2 E8 33 B4 00 00 85 C0 0F 94 C0 84 C0 0F 85 16 03 00 00 48 8D 45 AF 48 89 C1 E8 B2 FE 00 00 48 8D 4D AF 48 8D 95 98 FD FF FF 48 8D 85 78 FD FF FF 49 89 C8 48 89 C1 E8 75 96 01 00 48 8D 45 AF 48 89 C1 E8 B9 FE 00 00 48 8B 05 66 7C 06 00 FF D0 89 C2 B9 08 00 00 00 E8 3C B4 00 00 48 89 45 D0 48 83 7D D0 00 75 0A BB 00 00 00 00 E9 6C 02 00 00 48 C7 45 F0 00 00 00 00 C7 45 EC 00 00 00 00 C7 85 38 F9 FF FF 38 04 00 00 48 8D 95 38 F9 FF FF 48 8B 45 D0 48 89 C1 E8 83 B3 00 00 89 45 E8 83 7D E8 00 74 57 48 8D 85 38 F9 FF FF 48 8D 50 30 48 8D 85 78 FD FF FF 41 B8 00 00 00 00 48 89 C1 E8 2A F3 00 00 48 83 F8 FF 0F 95 C0 84 C0 74 14 48 8B 85 50 F9 FF FF 48 89 45 F0 8B 85 58 F9 FF FF 89 45 EC 48 8D 95 38 F9 FF FF 48 8B 45 D0 48 89 C1 E8 28 B3 00 00 89 45 E8 EB A3 48 8B 45 D0 48 89 C1 48 8B 05 69 7B 06 00 FF D0 48 83 7D F0 00 74 06 83 7D EC 00 75 0A BB 00 00 00 00 E9 B9 01 00 00 48 8D 0D 11 B9 05 00 48 8B 05 A2 7B 06 00 FF D0 48 8D 15 0D B9 05 00 48 89 C1 48 8B 05 97 7B 06 00 FF D0 48 89 45 C8 48 89 E8 48 89 45 E0 48 8D 95 28 F9 FF FF 48 8D 85 30 F9 FF FF 48 89 C1 48 8B 05 5A 7B 06 00 FF D0 C7 45 DC 00 00 00 00 48 8B 55 E0 48 8B 85 28 F9 FF FF 48 39 C2 0F 83 0D 01 00 00 48 8B 45 E0 48 8B 00 48 3D FF 0F 00 00 0F 86 EC 00 00 00 48 8B 45 E0 48 8B 00 48 39 45 C8 73 1E 48 8B 45 E0 48 8B 00 48 8B 55 C8 48 81 C2 00 10 00 00 48 39 D0 73 07 C7 45 DC 01 00 00 00 83 7D DC 00 0F 84 BB 00 00 00 48 8B 45 E0 48 8B 00 48 39 45 F0 0F 83 AA 00 00 00 48 8B 45 E0 48 8B 00 8B 4D EC 48 8B 55 F0 48 01 CA 48 39 D0 0F 83 90 00 00 00 48 C7 85 F8 F8 FF FF 00 00 00 00 48 C7 85 00 F9 FF FF 00 00 00 00 48 C7 85 08 F9 FF FF 00 00 00 00 48 C7 85 10 F9 FF FF 00 00 00 00 48 C7 85 18 F9 FF FF 00 00 00 00 48 C7 85 20 F9 FF FF 00 00 00 00 48 8B 45 E0 48 8B 00 48 8D 95 F8 F8 FF FF 41 B8 30 00 00 00 48 89 C1 48 8B 05 22 7B 06 00 FF D0 8B 85 1C F9 FF FF 83 E0 20 85 C0 74 20 48 8B 45 E0 48 8B 00 48 8D 15 59 FB FF FF 48 89 C1 E8 D5 FC FF FF BB 00 00 00 00 EB 57 90 EB 01 90 48 83 45 E0 08 E9 DF FE FF FF 48 8B 45 F0 48 89 45 C0 48 8B 45 C0 8B 40 3C 48 63 D0 48 8B 45 F0 48 01 D0 48 89 45 B8 48 8B 45 B8 8B 40 28 89 C2 48 8B 45 F0 48 01 D0 48 89 45 B0 48 8B 45 B0 48 8D 15 00 FB FF FF 48 89 C1 E8 7C FC FF FF BB 01 00 00 00 48 8D 85 78 FD FF FF 48 89 C1 E8 94 9C 01 00 83 FB 01 EB 38 48 89 C3 48 8D 45 AF 48 89 C1 E8 00 FC 00 00 48 89 D8 48 89 C1 E8 45 AA 00 00 48 89 C3 48 8D 85 78 FD FF FF 48 89 C1 E8 63 9C 01 00 48 89 D8 48 89 C1 E8 28 AA 00 00 90 48 81 C4 28 07 00 00 5B 5D C3 }
		$cond4 = { 55 53 48 89 E5 48 81 EC 28 07 00 00 48 8B 05 D3 8B 06 00 FF D0 48 89 C1 48 8D 85 98 FD FF FF 41 B8 04 01 00 00 48 89 C2 E8 65 B4 00 00 85 C0 0F 94 C0 84 C0 0F 85 16 03 00 00 48 8D 45 AF 48 89 C1 E8 EC FE 00 00 48 8D 4D AF 48 8D 95 98 FD FF FF 48 8D 85 78 FD FF FF 49 89 C8 48 89 C1 E8 AF 96 01 00 48 8D 45 AF 48 89 C1 E8 F3 FE 00 00 48 8B 05 78 8B 06 00 FF D0 89 C2 B9 08 00 00 00 E8 6E B4 00 00 48 89 45 D0 48 83 7D D0 00 75 0A BB 00 00 00 00 E9 6C 02 00 00 48 C7 45 F0 00 00 00 00 C7 45 EC 00 00 00 00 C7 85 38 F9 FF FF 38 04 00 00 48 8D 95 38 F9 FF FF 48 8B 45 D0 48 89 C1 E8 B5 B3 00 00 89 45 E8 83 7D E8 00 74 57 48 8D 85 38 F9 FF FF 48 8D 50 30 48 8D 85 78 FD FF FF 41 B8 00 00 00 00 48 89 C1 E8 64 F3 00 00 48 83 F8 FF 0F 95 C0 84 C0 74 14 48 8B 85 50 F9 FF FF 48 89 45 F0 8B 85 58 F9 FF FF 89 45 EC 48 8D 95 38 F9 FF FF 48 8B 45 D0 48 89 C1 E8 5A B3 00 00 89 45 E8 EB A3 48 8B 45 D0 48 89 C1 48 8B 05 73 8A 06 00 FF D0 48 83 7D F0 00 74 06 83 7D EC 00 75 0A BB 00 00 00 00 E9 B9 01 00 00 48 8D 0D 45 C8 05 00 48 8B 05 B4 8A 06 00 FF D0 48 8D 15 41 C8 05 00 48 89 C1 48 8B 05 A9 8A 06 00 FF D0 48 89 45 C8 48 89 E8 48 89 45 E0 48 8D 95 28 F9 FF FF 48 8D 85 30 F9 FF FF 48 89 C1 48 8B 05 6C 8A 06 00 FF D0 C7 45 DC 00 00 00 00 48 8B 55 E0 48 8B 85 28 F9 FF FF 48 39 C2 0F 83 0D 01 00 00 48 8B 45 E0 48 8B 00 48 3D FF 0F 00 00 0F 86 EC 00 00 00 48 8B 45 E0 48 8B 00 48 39 45 C8 73 1E 48 8B 45 E0 48 8B 00 48 8B 55 C8 48 81 C2 00 10 00 00 48 39 D0 73 07 C7 45 DC 01 00 00 00 83 7D DC 00 0F 84 BB 00 00 00 48 8B 45 E0 48 8B 00 48 39 45 F0 0F 83 AA 00 00 00 48 8B 45 E0 48 8B 00 8B 4D EC 48 8B 55 F0 48 01 CA 48 39 D0 0F 83 90 00 00 00 48 C7 85 F8 F8 FF FF 00 00 00 00 48 C7 85 00 F9 FF FF 00 00 00 00 48 C7 85 08 F9 FF FF 00 00 00 00 48 C7 85 10 F9 FF FF 00 00 00 00 48 C7 85 18 F9 FF FF 00 00 00 00 48 C7 85 20 F9 FF FF 00 00 00 00 48 8B 45 E0 48 8B 00 48 8D 95 F8 F8 FF FF 41 B8 30 00 00 00 48 89 C1 48 8B 05 54 8A 06 00 FF D0 8B 85 1C F9 FF FF 83 E0 20 85 C0 74 20 48 8B 45 E0 48 8B 00 48 8D 15 33 FA FF FF 48 89 C1 E8 D5 FC FF FF BB 00 00 00 00 EB 57 90 EB 01 90 48 83 45 E0 08 E9 DF FE FF FF 48 8B 45 F0 48 89 45 C0 48 8B 45 C0 8B 40 3C 48 63 D0 48 8B 45 F0 48 01 D0 48 89 45 B8 48 8B 45 B8 8B 40 28 89 C2 48 8B 45 F0 48 01 D0 48 89 45 B0 48 8B 45 B0 48 8D 15 DA F9 FF FF 48 89 C1 E8 7C FC FF FF BB 01 00 00 00 48 8D 85 78 FD FF FF 48 89 C1 E8 CE 9C 01 00 83 FB 01 EB 38 48 89 C3 48 8D 45 AF 48 89 C1 E8 3A FC 00 00 48 89 D8 48 89 C1 E8 4F AA 00 00 48 89 C3 48 8D 85 78 FD FF FF 48 89 C1 E8 9D 9C 01 00 48 89 D8 48 89 C1 E8 32 AA 00 00 90 48 81 C4 28 07 00 00 5B 5D C3 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) and any of them
}
rule FIREEYE_RT_APT_Hacktool_Win64_EXCAVATOR_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "e593b589-747d-53c2-a39a-57485e4f7641"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/EXCAVATOR/production/yara/APT_HackTool_Win64_EXCAVATOR_1.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "6a9a114928554c26675884eeb40cc01b"
		logic_hash = "aa06628ddef0f95c4217b97a3476a0ee12e00d04c4827a512730598f3c80f1f6"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-30"
		date_modified = "2020-11-30"
		rev = 3

	strings:
		$api1 = "PssCaptureSnapshot" fullword
		$api2 = "MiniDumpWriteDump" fullword
		$dump = { BA FD 03 00 AC [0-8] 41 B8 1F 00 10 00 48 8B ?? FF 15 [4] 85 C0 0F 85 [2] 00 00 [0-2] 48 8D 05 [5] 89 ?? 24 30 ( C7 44 24 28 80 00 00 00 48 8D 0D ?? ?? ?? ?? | 48 8D 0D ?? ?? ?? ?? C7 44 24 28 80 00 00 00 ) 45 33 C9 [0-5] 45 33 C0 C7 44 24 20 01 00 00 00 BA 00 00 00 10 [0-10] FF 15 [4] 48 8B ?? 48 83 F8 FF ( 74 | 0F 84 ) [1-4] 48 8B 4C 24 ?? 48 8D 44 24 ?? 48 89 44 24 30 ( 41 B9 02 00 00 00 | 44 8D 4D 02 ) ?? 89 ?? 24 28 4C 8B ?? 8B [2] 89 ?? 24 20 FF 15 [4] 48 8B ?? FF 15 [4] 48 8B ?? FF 15 [4] FF 15 [4] 48 8B 54 24 ?? 48 8B C8 FF 15 }
		$lsass = { 6C 73 61 73 [6] 73 2E 65 78 [6] 65 }

	condition:
		(( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) ) and all of them
}
rule FIREEYE_RT_APT_Hacktool_Win64_EXCAVATOR_2 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "4b7640e8-5621-5cc3-8ac9-84347f23f5eb"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/EXCAVATOR/production/yara/APT_HackTool_Win64_EXCAVATOR_2.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "4fd62068e591cbd6f413e1c2b8f75442"
		logic_hash = "14263c17323cd78df10f7f101bd7a9c74f7818b34a2e42125d45205067399381"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-02"
		date_modified = "2020-12-02"
		rev = 1

	strings:
		$api1 = "PssCaptureSnapshot" fullword
		$api2 = "MiniDumpWriteDump" fullword
		$dump = { C7 [2-5] FD 03 00 AC 4C 8D 4D ?? 41 B8 1F 00 10 00 8B [2-5] 48 8B 4D ?? E8 [4] 89 [2-5] 83 [2-5] 00 74 ?? 48 8B 4D ?? FF 15 [4] 33 C0 E9 [4] 41 B8 10 00 00 00 33 D2 48 8D 8D [4] E8 [4] 48 8D 05 [4] 48 89 85 [4] 48 C7 85 [8] 48 C7 44 24 30 00 00 00 00 C7 44 24 28 80 00 00 00 C7 44 24 20 01 00 00 00 45 33 C9 45 33 C0 BA 00 00 00 10 48 8D 0D [4] FF 15 [4] 48 89 85 [4] 48 83 BD [4] FF 75 ?? 48 8B 4D ?? FF 15 [4] 33 C0 EB [0-17] 48 8D [5] 48 89 ?? 24 30 48 C7 44 24 28 00 00 00 00 48 C7 44 24 20 00 00 00 00 41 B9 02 00 00 00 4C 8B 85 [4] 8B [1-5] 48 8B 4D ?? E8 }
		$enable_dbg_pri = { 4C 8D 45 ?? 48 8D 15 [4] 33 C9 FF 15 [4] 85 C0 0F 84 [4] C7 45 ?? 01 00 00 00 B8 0C 00 00 00 48 6B C0 00 48 8B 4D ?? 48 89 4C 05 ?? B8 0C 00 00 00 48 6B C0 00 C7 44 05 ?? 02 00 00 00 FF 15 [4] 4C 8D 45 ?? BA 20 00 00 00 48 8B C8 FF 15 [4] 85 C0 74 ?? 48 C7 44 24 28 00 00 00 00 48 C7 44 24 20 00 00 00 00 45 33 C9 4C 8D 45 ?? 33 D2 48 8B 4D ?? FF 15 }

	condition:
		(( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) ) and all of them
}
rule FIREEYE_RT_Trojan_Win64_Generic_23 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "470bfeed-e000-58c6-b115-dfa8aea25bef"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/EXCAVATOR/supplemental/yara/Trojan_Win64_Generic_23.yar#L4-L22"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "b66347ef110e60b064474ae746701d4a"
		logic_hash = "4c1860801b26abbab8c4aea730bf69f388c902083b9945e11e6782af3ab22789"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-02"
		date_modified = "2020-12-02"
		rev = 1

	strings:
		$api1 = "VirtualAllocEx" fullword
		$api2 = "UpdateProcThreadAttribute" fullword
		$api3 = "DuplicateTokenEx" fullword
		$api4 = "CreateProcessAsUserA" fullword
		$inject = { 8B 85 [4] C7 44 24 20 40 00 00 00 41 B9 00 30 00 00 44 8B C0 33 D2 48 8B 8D [4] FF 15 [4] 48 89 45 ?? 48 83 7D ?? 00 75 ?? 48 8B 45 ?? E9 [4] 8B 85 [4] 48 C7 44 24 20 00 00 00 00 44 8B C8 4C 8B 85 [4] 48 8B 55 ?? 48 8B 8D [4] FF 15 [4] 85 C0 75 ?? 48 8B 45 ?? EB ?? 8B 85 [4] 48 8B 4D ?? 48 03 C8 48 8B C1 48 89 45 48 48 8D 85 [4] 48 89 44 24 30 C7 44 24 28 00 00 00 00 48 8B 85 [4] 48 89 44 24 20 4C 8B 4D ?? 41 B8 00 00 10 00 33 D2 48 8B 8D [4] FF 15 }
		$process = { 48 C7 44 24 30 00 00 00 00 48 C7 44 24 28 00 00 00 00 48 C7 44 24 20 08 00 00 00 4C 8D 8D [4] 41 B8 00 00 02 00 33 D2 48 8B 8D [4] FF 15 [4] 85 C0 75 ?? E9 [4] 48 8B 85 [4] 48 89 85 [4] 48 8D 85 [4] 48 89 44 24 50 48 8D 85 [4] 48 89 44 24 48 48 C7 44 24 40 00 00 00 00 48 C7 44 24 38 00 00 00 00 C7 44 24 30 04 00 08 00 C7 44 24 28 00 00 00 00 48 C7 44 24 20 00 00 00 00 45 33 C9 4C 8D 05 [4] 33 D2 48 8B [2-5] FF 15 }
		$token = { FF 15 [4] 4C 8D 45 ?? BA 0A 00 00 00 48 8B C8 FF 15 [4] 85 C0 75 ?? E9 [4] 48 8D [2-5] 48 89 44 24 28 C7 44 24 20 02 00 00 00 41 B9 02 00 00 00 45 33 C0 BA 0B 00 00 00 48 8B 4D ?? FF 15 [4] 85 C0 75 ?? E9 [4] 4C 8D 8D [4] 45 33 C0 BA 01 00 00 00 33 C9 FF 15 }

	condition:
		(( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) ) and all of them
}
rule FIREEYE_RT_Trojan_Win64_Generic_22 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "e79661a8-5254-5e8e-b92b-edf1ddb072ff"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/EXCAVATOR/supplemental/yara/Trojan_Win64_Generic_22.yar#L4-L22"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "f7d9961463b5110a3d70ee2e97842ed3"
		logic_hash = "52fbe5c0ee7c05df5fcd62c26caaa5498e32352da9c5940e522aa31d6c808028"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-26"
		date_modified = "2020-11-26"
		rev = 2

	strings:
		$api1 = "VirtualAllocEx" fullword
		$api2 = "UpdateProcThreadAttribute" fullword
		$api3 = "DuplicateTokenEx" fullword
		$api4 = "CreateProcessAsUserA" fullword
		$inject = { C7 44 24 20 40 00 00 00 33 D2 41 B9 00 30 00 00 41 B8 [4] 48 8B CB FF 15 [4] 48 8B F0 48 85 C0 74 ?? 4C 89 74 24 20 41 B9 [4] 4C 8D 05 [4] 48 8B D6 48 8B CB FF 15 [4] 85 C0 75 [5-10] 4C 8D 0C 3E 48 8D 44 24 ?? 48 89 44 24 30 44 89 74 24 28 4C 89 74 24 20 33 D2 41 B8 [4] 48 8B CB FF 15 }
		$process = { 89 74 24 30 ?? 8D 4C 24 [2] 89 74 24 28 33 D2 41 B8 00 00 02 00 48 C7 44 24 20 08 00 00 00 48 8B CF FF 15 [4] 85 C0 0F 84 [4] 48 8B [2-3] 48 8D 45 ?? 48 89 44 24 50 4C 8D 05 [4] 48 8D 45 ?? 48 89 7D 08 48 89 44 24 48 45 33 C9 ?? 89 74 24 40 33 D2 ?? 89 74 24 38 C7 44 24 30 04 00 08 00 [0-1] 89 74 24 28 ?? 89 74 24 20 FF 15 }
		$token = { FF 15 [4] 4C 8D 44 24 ?? BA 0A 00 00 00 48 8B C8 FF 15 [4] 85 C0 0F 84 [4] 48 8B 4C 24 ?? 48 8D [2-3] 41 B9 02 00 00 00 48 89 44 24 28 45 33 C0 C7 44 24 20 02 00 00 00 41 8D 51 09 FF 15 [4] 85 C0 0F 84 [4] 45 33 C0 4C 8D 4C 24 ?? 33 C9 41 8D 50 01 FF 15 }

	condition:
		(( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) ) and all of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_SHARPNFS_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'sharpnfs' project."
		author = "FireEye"
		id = "b9d1b4e8-644a-5611-85e8-a124f915b443"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/UNCATEGORIZED/production/yara/APT_HackTool_MSIL_SHARPNFS_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "e7f9883376b153849970599d9ecc308882eb86a67834cfd8ab06b44539346125"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 3

	strings:
		$typelibguid0 = "9f67ebe3-fc9b-40f2-8a18-5940cfed44cf" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_SHARPGOPHER_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'sharpgopher' project."
		author = "FireEye"
		id = "cc8eb9cd-9a51-5fab-b0a4-247baaa69dd7"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/UNCATEGORIZED/production/yara/APT_HackTool_MSIL_SHARPGOPHER_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "ac37f77440cb76d7dafa4c9b4130471ca6ca760f6d72691db9ebb8cbaaad0c58"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid0 = "83413a89-7f5f-4c3f-805d-f4692bc60173" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_DNSOVERHTTPS_C2_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the public 'DoHC2' External C2 project."
		author = "FireEye"
		id = "ee71be6c-e3c8-5365-9f32-157f00066c49"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/UNCATEGORIZED/production/yara/APT_HackTool_MSIL_DNSOVERHTTPS_C2_1.yar#L4-L16"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "a482161bbd8e249977f28466ff1381d4693495f8b8ccd9183ae4fde1ec1471eb"
		score = 75
		quality = 71
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid0 = "5d9515d0-df67-40ed-a6b2-6619620ef0ef" ascii nocase wide
		$typelibguid1 = "7266acbb-b10d-4873-9b99-12d2043b1d4e" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_SHARPDNS_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'sharpdns' project."
		author = "FireEye"
		id = "db6b45be-f42f-5d0f-b50a-32e7a2cbfce6"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/UNCATEGORIZED/production/yara/APT_HackTool_MSIL_SHARPDNS_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "bab36f9b1532c3b24c2aea2907006820ed7cf1c90dae7a8138962e14ac9eff55"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid0 = "d888cec8-7562-40e9-9c76-2bb9e43bb634" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_REDTEAMMATERIALS_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'red_team_materials' project."
		author = "FireEye"
		id = "272cd3e9-884a-566b-ae90-4a79ee726a8d"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/UNCATEGORIZED/production/yara/APT_HackTool_MSIL_REDTEAMMATERIALS_1.yar#L4-L16"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "ca54a1e8335c4256295fc643f5d31eae2e89f020dc7a9b571c4772edaad08022"
		score = 75
		quality = 71
		tags = "FILE"
		rev = 3

	strings:
		$typelibguid0 = "86c95a99-a2d6-4ebe-ad5f-9885b06eab12" ascii nocase wide
		$typelibguid1 = "e06f1411-c7f8-4538-bbb9-46c928732245" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Credtheft_MSIL_Credsnatcher_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'CredSnatcher' project."
		author = "FireEye"
		id = "0d8f7495-4748-577d-8ef2-ccc4829fc165"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/UNCATEGORIZED/production/yara/CredTheft_MSIL_CredSnatcher_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "2c86be1bcf29bcb2c167f9248dee0ab4a5a5c6740fb1f18784ee2e380176df91"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 1

	strings:
		$typelibguid0 = "370b4d21-09d0-433f-b7e4-4ebdd79948ec" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_SHARPZIPLIBZIPPER_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'sharpziplibzipper' project."
		author = "FireEye"
		id = "392a52be-29ae-58e1-b517-1ab34a1e1fb8"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/UNCATEGORIZED/production/yara/APT_HackTool_MSIL_SHARPZIPLIBZIPPER_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "19354edb91a0d79fdf79437f7247bcf155514db40340af91a3320b556dc2e4c2"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 3

	strings:
		$typelibguid0 = "485ba350-59c4-4932-a4c1-c96ffec511ef" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_SHARPNATIVEZIPPER_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'sharpnativezipper' project."
		author = "FireEye"
		id = "c48835a7-06fe-5b30-be4d-086d98dc7a21"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/UNCATEGORIZED/production/yara/APT_HackTool_MSIL_SHARPNATIVEZIPPER_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "fa54375b21abbb613e695f70a15233575fbe6e0536716544bb3b527f5e3ed8c6"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 3

	strings:
		$typelibguid0 = "de5536db-9a35-4e06-bc75-128713ea6d27" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_SHARPDACL_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'sharpdacl' project."
		author = "FireEye"
		id = "13f4e3ea-1e36-5fad-9197-66511d6f026a"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/UNCATEGORIZED/production/yara/APT_HackTool_MSIL_SHARPDACL_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "5f44ec5ddded18fb3a9132b469b2fe7ccbffb3f907325485f0f72fe3d6bbfa23"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 3

	strings:
		$typelibguid0 = "b3c17fb5-5d5a-4b14-af3c-87a9aa941457" ascii nocase wide

	condition:
		filesize < 10MB and ( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Credtheft_MSIL_Wcmdump_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'WCMDump' project."
		author = "FireEye"
		id = "22796ccb-a01e-59d8-8c3a-6cbb62899940"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/UNCATEGORIZED/production/yara/CredTheft_MSIL_WCMDump_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "9fbf53e551342695b306b10f30a3fe32dff359bd70e84e1fa1f190772f5dcbe3"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 1

	strings:
		$typelibguid0 = "21e322f2-4586-4aeb-b1ed-d240e2a79e19" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_MODIFIEDSHARPVIEW_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'modifiedsharpview' project."
		author = "FireEye"
		id = "e07d3d4b-fba3-5df7-85f4-927bb8cec2d1"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/UNCATEGORIZED/production/yara/APT_HackTool_MSIL_MODIFIEDSHARPVIEW_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "db0eaad52465d5a2b86fdd6a6aa869a5"
		logic_hash = "a47c48da998243fab92665649fb9d6ecc6ac32e1fd884c2c0d5ccecb05290c10"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 3

	strings:
		$typelibguid0 = "22a156ea-2623-45c7-8e50-e864d9fc44d3" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_SHARPTEMPLATE_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'sharptemplate' project."
		author = "FireEye"
		id = "0ca9a13c-e0a0-588b-be13-5954b17d95b1"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/UNCATEGORIZED/production/yara/APT_HackTool_MSIL_SHARPTEMPLATE_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "9746c1ab7b945d311c53fbdf95993d255369e06b23a3279c9f2e8a4df73ab63c"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid0 = "e9e452d4-9e58-44ff-ba2d-01b158dda9bb" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_SHARPWEBCRAWLER_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'sharpwebcrawler' project."
		author = "FireEye"
		id = "29b2a410-bcc4-58df-b192-7a413b3db1c0"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/UNCATEGORIZED/production/yara/APT_HackTool_MSIL_SHARPWEBCRAWLER_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "8df328663a813ca0a6864ae0503cbc1b03cfdf839215b9b4f2bb7962adf09bf8"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid0 = "cf27abf4-ef35-46cd-8d0c-756630c686f1" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_SHARPPATCHCHECK_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'sharppatchcheck' project."
		author = "FireEye"
		id = "dedc12b9-b9e7-5c13-ad6d-2e286aba2302"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/UNCATEGORIZED/production/yara/APT_HackTool_MSIL_SHARPPATCHCHECK_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "dec6231b656eed1526d4f70fe1b9a476bfb06246f0a7c25f2687d8c68886d400"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid0 = "528b8df5-6e5e-4f3b-b617-ac35ed2f8975" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_SHARPSQLCLIENT_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'sharpsqlclient' project."
		author = "FireEye"
		id = "4d526c36-f56f-53cf-9bdf-b7a15619eb41"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/UNCATEGORIZED/production/yara/APT_HackTool_MSIL_SHARPSQLCLIENT_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "bc79f80582f4fadecf54d926abdcf61694224654ba5075203f0d1123cf11afc1"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid0 = "13ed03cd-7430-410d-a069-cf377165fbfd" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Loader_Win_Generic_20 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "d1d3eff8-d12e-53f6-8c30-06ecedaf3f49"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/UNCATEGORIZED/supplemental/yara/Loader_Win_Generic_20.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "5125979110847d35a338caac6bff2aa8"
		logic_hash = "9611aed2b4e4278d40254cb5c4fe94a458cfa19f10e6fe888bc7ceb166669cc6"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-02"
		date_modified = "2020-12-02"
		rev = 1

	strings:
		$s0 = { 8B [1-16] 89 [1-16] E8 [4-32] F3 A4 [0-16] 89 [1-8] E8 }
		$s2 = { 83 EC [4-24] 00 10 00 00 [4-24] C7 44 24 ?? ?? 00 00 00 [0-8] FF 15 [4-24] 89 [1-4] 89 [1-4] 89 [1-8] FF 15 [4-16] 3? ?? 7? [4-24] 20 00 00 00 [4-24] FF 15 [4-32] F3 A5 }
		$si1 = "VirtualProtect" fullword
		$si2 = "malloc" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_Loader_MSIL_Generic_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "f919e3fc-cf76-53af-8f04-24921830666f"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/UNCATEGORIZED/supplemental/yara/Loader_MSIL_Generic_1.yar#L4-L21"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "b8415b4056c10c15da5bba4826a44ffd"
		logic_hash = "06cddd7e1c1c778348539cfd50f01d55f86689dec86c045d7ce7b9cd71690e07"
		score = 75
		quality = 75
		tags = "FILE"
		rev = 5

	strings:
		$MSIL = "_CorExeMain"
		$opc1 = { 00 72 [4] 0A 72 [4] 0B 06 28 [4] 0C 12 03 FE 15 [4] 12 04 FE 15 [4] 07 14 }
		$str1 = "DllImportAttribute"
		$str2 = "FromBase64String"
		$str3 = "ResumeThread"
		$str4 = "OpenThread"
		$str5 = "SuspendThread"
		$str6 = "QueueUserAPC"

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and $MSIL and all of them
}
rule FIREEYE_RT_Loader_Win_Generic_19 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "4f4427ee-0f7d-5442-98a6-402d8b797289"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/UNCATEGORIZED/supplemental/yara/Loader_Win_Generic_19.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "3fb9341fb11eca439b50121c6f7c59c7"
		logic_hash = "6db9696663c19857c1f89339b8cc9b0565e877f34e8d8cf77b89ef22b3f41683"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-02"
		date_modified = "2020-12-02"
		rev = 1

	strings:
		$s0 = { 8B [1-16] 89 [1-16] E8 [4-32] F3 A4 [0-16] 89 [1-8] E8 }
		$s1 = { 83 EC [1-16] 04 00 00 00 [1-24] 00 30 00 00 [1-24] FF 15 [4-16] EB [16-64] 20 00 00 00 [0-8] FF 15 [4-32] C7 44 24 ?? 00 00 00 00 [0-8] C7 44 24 ?? 00 00 00 00 [0-16] FF 15 }
		$si1 = "VirtualProtect" fullword
		$si2 = "malloc" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_Trojan_Macro_RESUMEPLEASE_1
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "068662f6-28b8-5538-8bc3-6506565305ae"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/RESUMEPLEASE/production/yara/Trojan_Macro_RESUMEPLEASE_1.yar#L4-L21"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "d5d3d23c8573d999f1c48d3e211b1066"
		logic_hash = "040457bc446e496431129ff4623ddda5d9c2ce339ba65a7fbe42114626f36c60"
		score = 75
		quality = 75
		tags = ""
		date_created = "2020-12-01"
		date_modified = "2020-12-01"
		rev = 1

	strings:
		$str00 = "For Binary As"
		$str01 = "Range.Text"
		$str02 = "Environ("
		$str03 = "CByte("
		$str04 = ".SpawnInstance_"
		$str05 = ".Create("

	condition:
		all of them
}
rule FIREEYE_RT_APT_Loader_MSIL_LUALOADER_2 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "f2826dbb-f0a4-5361-94d1-8509c60c4131"
		date = "2020-12-18"
		modified = "2020-12-18"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/LUALOADER/production/yara/APT_Loader_MSIL_LUALOADER_2.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		logic_hash = "700927768669eda6976071306e991bfaae136279f4265980521597c699fbed88"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$ss1 = "\x3bN\x00e\x00o\x00.\x00I\x00r\x00o\x00n\x00L\x00u\x00a\x00.\x00L\x00u\x00a\x00C\x00o\x00m\x00p\x00i\x00l\x00e\x00O\x00p\x00t\x00i\x00o\x00n\x00s\x00"
		$ss2 = "\x19C\x00o\x00m\x00p\x00i\x00l\x00e\x00C\x00h\x00u\x00n\x00k\x00"
		$ss3 = "\x0fd\x00o\x00c\x00h\x00u\x00n\x00k\x00"
		$ss4 = /.Reflection.Assembly:Load\(\w{1,64}\);?\s{0,245}\w{1,64}\.EntryPoint:Invoke\(nil/ wide
		$ss5 = "1F 8B 08 00 00 00 00 00" wide
		$ss6 = "\x00LoadLibrary\x00"
		$ss7 = "\x00GetProcAddress\x00"
		$ss8 = "\x00VirtualProtect\x00"

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_LUALOADER_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'lualoader' project."
		author = "FireEye"
		id = "e8480cf8-1852-5572-8e92-c0ae676b7507"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/LUALOADER/production/yara/APT_HackTool_MSIL_LUALOADER_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "7e9f9836ec91aa66c8779588cfceff718487f0cb5048d17538c947aba687a4cf"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 3

	strings:
		$typelibguid0 = "8b546b49-2b2c-4577-a323-76dc713fe2ea" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Loader_MSIL_LUALOADER_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "970a869e-bd69-5609-bb8d-77bfa78b0630"
		date = "2020-12-18"
		modified = "2020-12-18"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/LUALOADER/production/yara/APT_Loader_MSIL_LUALOADER_1.yar#L4-L17"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		logic_hash = "2d73d434ac39ebde990aca817a54208cd04bfbce33f1bcadcf48a50d9389658c"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$sb1 = { 1? 72 [4] 14 D0 [2] 00 02 28 [2] 00 0A 1? 8D [2] 00 01 13 ?? 11 ?? 1? 1? 14 28 [2] 00 0A A2 11 ?? 1? 1? 14 28 [2] 00 0A A2 11 ?? 28 [2] 00 0A 28 [2] 00 0A 80 [2] 00 04 7E [2] 00 04 7B [2] 00 0A 7E [2] 00 04 11 ?? 11 ?? 6F [2] 00 0A 6F [2] 00 0A }
		$ss1 = "\x3bN\x00e\x00o\x00.\x00I\x00r\x00o\x00n\x00L\x00u\x00a\x00.\x00L\x00u\x00a\x00C\x00o\x00m\x00p\x00i\x00l\x00e\x00O\x00p\x00t\x00i\x00o\x00n\x00s\x00"
		$ss2 = "\x19C\x00o\x00m\x00p\x00i\x00l\x00e\x00C\x00h\x00u\x00n\x00k\x00"
		$ss3 = "\x0fd\x00o\x00c\x00h\x00u\x00n\x00k\x00"
		$ss4 = /.Reflection.Assembly:Load\(\w{1,64}\);?\s{0,245}\w{1,64}\.EntryPoint:Invoke\(nil/ wide
		$ss5 = "1F 8B 08 00 00 00 00 00" wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_Hacktool_Win32_Andrewspecial_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "69e27e92-d68e-5543-bada-170e32733dbb"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/TITOSPECIAL/production/yara/HackTool_Win32_AndrewSpecial_1.yar#L4-L18"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "e89efa88e3fda86be48c0cc8f2ef7230"
		logic_hash = "529a49fb21250069111d03a174901dc2e1623ee2a1f446aae1bdb1579a227dd3"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-25"
		date_modified = "2020-11-25"
		rev = 4

	strings:
		$dump = { 6A 00 68 FF FF 1F 00 FF 15 [4] 89 45 ?? 83 [2] 00 [1-50] 6A 00 68 80 00 00 00 6A 02 6A 00 6A 00 68 00 00 00 10 68 [4] FF 15 [4] 89 45 [10-70] 6A 00 6A 00 6A 00 6A 02 8B [2-4] 5? 8B [2-4] 5? 8B [2-4] 5? E8 [4-20] FF 15 }
		$shellcode_x86 = { B8 3C 00 00 00 33 C9 8D 54 24 04 64 FF 15 C0 00 00 00 83 C4 04 C2 14 00 }
		$shellcode_x86_inline = { C6 45 ?? B8 C6 45 ?? 3C C6 45 ?? 00 C6 45 ?? 00 C6 45 ?? 00 C6 45 ?? 33 C6 45 ?? C9 C6 45 ?? 8D C6 45 ?? 54 C6 45 ?? 24 C6 45 ?? 04 C6 45 ?? 64 C6 45 ?? FF C6 45 ?? 15 C6 45 ?? C0 C6 45 ?? 00 C6 45 ?? 00 C6 45 ?? 00 C6 45 ?? 83 C6 45 ?? C4 C6 45 ?? 04 C6 45 ?? C2 C6 45 ?? 14 C6 45 ?? 00 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x010B ) and $dump and any of ( $shellcode* )
}
rule FIREEYE_RT_Credtheft_MSIL_Titospecial_1 : FILE
{
	meta:
		description = "This rule looks for .NET PE files that have the strings of various method names in the TitoSpecial code."
		author = "FireEye"
		id = "932bb013-03de-5cf7-89e9-b3232151d303"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/TITOSPECIAL/production/yara/CredTheft_MSIL_TitoSpecial_1.yar#L4-L27"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "4bf96a7040a683bd34c618431e571e26"
		logic_hash = "4ac9a5ede4aea5d73545b459eb635f87ce08ba521afa48b76d2cfa94f1379226"
		score = 75
		quality = 75
		tags = "FILE"
		rev = 4

	strings:
		$str1 = "Minidump" ascii wide
		$str2 = "dumpType" ascii wide
		$str3 = "WriteProcessMemory" ascii wide
		$str4 = "bInheritHandle" ascii wide
		$str5 = "GetProcessById" ascii wide
		$str6 = "SafeHandle" ascii wide
		$str7 = "BeginInvoke" ascii wide
		$str8 = "EndInvoke" ascii wide
		$str9 = "ConsoleApplication1" ascii wide
		$str10 = "getOSInfo" ascii wide
		$str11 = "OpenProcess" ascii wide
		$str12 = "LoadLibrary" ascii wide
		$str13 = "GetProcAddress" ascii wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of ( $str* )
}
rule FIREEYE_RT_Credtheft_MSIL_Titospecial_2 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the TitoSpecial project. There are 2 GUIDs in this rule as the x86 and x64 versions of this tool use a different ProjectGuid."
		author = "FireEye"
		id = "0262c720-e6b8-5bf2-a242-19a7f044973f"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/TITOSPECIAL/production/yara/CredTheft_MSIL_TitoSpecial_2.yar#L4-L16"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "4bf96a7040a683bd34c618431e571e26"
		logic_hash = "2f621f8de2a4679e6cbce7f41859eaa3095ca54090c8bfccd3b767590ac91f2c"
		score = 75
		quality = 71
		tags = "FILE"
		rev = 4

	strings:
		$typelibguid1 = "C6D94B4C-B063-4DEB-A83A-397BA08515D3" ascii nocase wide
		$typelibguid2 = "3b5320cf-74c1-494e-b2c8-a94a24380e60" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( $typelibguid1 or $typelibguid2 )
}
rule FIREEYE_RT_APT_Hacktool_MSIL_TITOSPECIAL_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "b12490ba-41f6-5469-bcbb-0d2e0055c193"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/TITOSPECIAL/production/yara/APT_HackTool_MSIL_TITOSPECIAL_1.yar#L4-L20"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "4bf96a7040a683bd34c618431e571e26"
		logic_hash = "6def0c667d38c1bad9233628e509bdcaed322e75be4ff3823b0f788c391e090c"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-25"
		date_modified = "2020-11-25"
		rev = 5

	strings:
		$ind_dump = { 1F 10 16 28 [2] 00 0A 6F [2] 00 0A [50-200] 18 19 18 73 [2] 00 0A 13 [1-4] 06 07 11 ?? 6F [2] 00 0A 18 7E [2] 00 0A 7E [2] 00 0A 7E [2] 00 0A 28 [2] 00 06 }
		$ind_s1 = "NtReadVirtualMemory" fullword wide
		$ind_s2 = "WriteProcessMemory" fullword
		$shellcode_x64 = { 4C 8B D1 B8 3C 00 00 00 0F 05 C3 }
		$shellcode_x86 = { B8 3C 00 00 00 33 C9 8D 54 24 04 64 FF 15 C0 00 00 00 83 C4 04 C2 14 00 }

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of ( $ind* ) and any of ( $shellcode* )
}
rule FIREEYE_RT_Hacktool_Win64_Andrewspecial_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "20ce4902-4eb3-5ecf-aa8c-0515965dde57"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/TITOSPECIAL/production/yara/HackTool_Win64_AndrewSpecial_1.yar#L4-L18"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "4456e52f6f8543c3ba76cb25ea3e9bd2"
		logic_hash = "96f06c46dfec795fcfd08c188853d0a3f781003ae118833719a175eb59049c0d"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-25"
		date_modified = "2020-11-25"
		rev = 5

	strings:
		$dump = { 33 D2 B9 FF FF 1F 00 FF 15 [10-90] 00 00 00 00 [2-6] 80 00 00 00 [2-6] 02 00 00 00 45 33 C9 45 33 C0 BA 00 00 00 10 48 8D 0D [4] FF 15 [4-120] 00 00 00 00 [2-6] 00 00 00 00 [2-6] 00 00 00 00 41 B9 02 00 00 00 [6-15] E8 [4-20] FF 15 }
		$shellcode_x64 = { 4C 8B D1 B8 3C 00 00 00 0F 05 C3 }
		$shellcode_x64_inline = { C6 44 24 ?? 4C C6 44 24 ?? 8B C6 44 24 ?? D1 C6 44 24 ?? B8 C6 44 24 ?? 3C C6 44 24 ?? 00 C6 44 24 ?? 00 C6 44 24 ?? 00 C6 44 24 ?? 0F C6 44 24 ?? 05 C6 44 24 ?? C3 }

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x020B ) and $dump and any of ( $shellcode* )
}
rule FIREEYE_RT_Dropper_LNK_Lnksmasher_1 : FILE
{
	meta:
		description = "The LNKSmasher project contains a prebuilt LNK file that has pieces added based on various configuration items. Because of this, several artifacts are present in every single LNK file generated by LNKSmasher, including the Drive Serial #, the File Droid GUID, and the GUID CLSID."
		author = "FireEye"
		id = "1b93ddf8-9578-5e47-b479-4c9e8a40b4f4"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/LNKSMASHER/production/yara/Dropper_LNK_LNKSmasher_1.yar#L4-L18"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "0a86d64c3b25aa45428e94b6e0be3e08"
		logic_hash = "61d1ac67ac0d332ad842a522cbebe1b9af1482d58a210b50fb45209355c0aeeb"
		score = 75
		quality = 75
		tags = "FILE"
		rev = 6

	strings:
		$drive_serial = { 12 F7 26 BE }
		$file_droid_guid = { BC 96 28 4F 0A 46 54 42 81 B8 9F 48 64 D7 E9 A5 }
		$guid_clsid = { E0 4F D0 20 EA 3A 69 10 A2 D8 08 00 2B 30 30 9D }
		$header = { 4C 00 00 00 01 14 02 }

	condition:
		$header at 0 and all of them
}
rule FIREEYE_RT_APT_Backdoor_Macos_GORAT_1 : FILE
{
	meta:
		description = "This rule is looking for specific strings associated with network activity found within the MacOS generated variant of GORAT"
		author = "FireEye"
		id = "4646eadb-7acf-582f-9ad6-00f012ceed8a"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE (Gorat)/production/yara/APT_Backdoor_MacOS_GORAT_1.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "68acf11f5e456744262ff31beae58526"
		logic_hash = "2df5f87d44968670511880d21ad184779d0561c7c426a5d6426bcefd0904a9b7"
		score = 75
		quality = 75
		tags = "FILE"
		rev = 3

	strings:
		$s1 = "SID1=%s" ascii wide
		$s2 = "http/http.dylib" ascii wide
		$s3 = "Mozilla/" ascii wide
		$s4 = "User-Agent" ascii wide
		$s5 = "Cookie" ascii wide

	condition:
		(( uint32( 0 ) == 0xBEBAFECA ) or ( uint32( 0 ) == 0xFEEDFACE ) or ( uint32( 0 ) == 0xFEEDFACF ) or ( uint32( 0 ) == 0xCEFAEDFE ) ) and all of them
}
rule FIREEYE_RT_Trojan_MSIL_GORAT_Plugin_DOTNET_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'RedFlare - Plugin - .NET' project."
		author = "FireEye"
		id = "faa73d64-4bb1-5c06-a3a5-1f1aa99ea932"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE (Gorat)/production/yara/Trojan_MSIL_GORAT_Plugin_DOTNET_1.yar#L4-L16"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "e979822273c6d1ccdfebd341c9e2cb1040fe34a04e8b41c024885063fd946ad5"
		score = 75
		quality = 71
		tags = "FILE"
		rev = 1

	strings:
		$typelibguid0 = "cd9407d0-fc8d-41ed-832d-da94daa3e064" ascii nocase wide
		$typelibguid1 = "fc3daedf-1d01-4490-8032-b978079d8c2d" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Trojan_MSIL_GORAT_Module_Powershell_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'RedFlare - Module - PowerShell' project."
		author = "FireEye"
		id = "b0fba130-9cd9-5b7f-a806-9ff8099f5731"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE (Gorat)/production/yara/Trojan_MSIL_GORAT_Module_PowerShell_1.yar#L4-L16"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "e596bc0316a4ef85f04c2683ebc7c94bf9b831843232c33e62c84991e4caeb97"
		score = 75
		quality = 71
		tags = "FILE"
		rev = 1

	strings:
		$typelibguid0 = "38d89034-2dd9-4367-8a6e-5409827a243a" ascii nocase wide
		$typelibguid1 = "845ee9dc-97c9-4c48-834e-dc31ee007c25" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Backdoor_Win_GORAT_1 : FILE
{
	meta:
		description = "This detects if a sample is less than 50KB and has a number of strings found in the Gorat shellcode (stage0 loader). The loader contains an embedded DLL (stage0.dll) that contains a number of unique strings. The 'Cookie' string found in this loader is important as this cookie is needed by the C2 server to download the Gorat implant (stage1 payload)."
		author = "FireEye"
		id = "5ac84cf1-49fb-533d-b211-b1a92239063b"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE (Gorat)/production/yara/APT_Backdoor_Win_GORAT_1.yar#L4-L23"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "66cdaa156e4d372cfa3dea0137850d20"
		logic_hash = "f6a0a923f64375e7ffdc080aec41db19a9e162405f1290ed0bbcce5a342bdadb"
		score = 75
		quality = 75
		tags = "FILE"
		rev = 4

	strings:
		$s1 = "httpComms.dll" ascii wide
		$s2 = "Cookie: SID1=%s" ascii wide
		$s3 = "Global\\" ascii wide
		$s4 = "stage0.dll" ascii wide
		$s5 = "runCommand" ascii wide
		$s6 = "getData" ascii wide
		$s7 = "initialize" ascii wide
		$s8 = "Windows NT %d.%d;" ascii wide
		$s9 = "!This program cannot be run in DOS mode." ascii wide

	condition:
		filesize < 50KB and all of them
}
rule FIREEYE_RT_APT_Backdoor_Win_GORAT_5 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "73102bd2-7b94-5c7b-b9a4-cfc9cf5e3212"
		date = "2020-12-09"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE (Gorat)/production/yara/APT_Backdoor_Win_GORAT_5.yar#L4-L23"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "cdf58a48757010d9891c62940c439adb, a107850eb20a4bb3cc59dbd6861eaf0f"
		logic_hash = "67f85fb3bedfd18a1226c92318f387be3c7ff9566ca2d554c49cf62389482552"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-02"
		date_modified = "2020-12-02"
		rev = 1

	strings:
		$1 = "comms.BeaconData" fullword
		$2 = "comms.CommandResponse" fullword
		$3 = "rat.BaseChannel" fullword
		$4 = "rat.Config" fullword
		$5 = "rat.Core" fullword
		$6 = "platforms.AgentPlatform" fullword
		$7 = "GetHostID" fullword
		$8 = "/rat/cmd/gorat_shared/dllmain.go" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_Loader_MSIL_Allthethings_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'AllTheThings' project."
		author = "FireEye"
		id = "1805b406-2531-56bf-8e08-e63a59ffcc84"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/ALLTHETHINGS/production/yara/Loader_MSIL_AllTheThings_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "e3058095f2a49f8c0f78cb392024795367609b04c1da80210ab8d72c6613ee71"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid0 = "542ccc64-c4c3-4c03-abcd-199a11b26754" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Hacktool_MSIL_Sharpersist_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the SharPersist project."
		author = "FireEye"
		id = "586e6c91-6970-57d1-8d8c-05ae9eb6117a"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/SHARPERSIST/production/yara/HackTool_MSIL_SharPersist_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "98ecf58d48a3eae43899b45cec0fc6b7"
		logic_hash = "cf480026c31b522850e25ba2d7986773d9c664242a2667ecd33151621c98c91e"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 1

	strings:
		$typelibguid1 = "9D1B853E-58F1-4BA5-AEFC-5C221CA30E48" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and $typelibguid1
}
rule FIREEYE_RT_Hacktool_MSIL_Sharpersist_2 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "49d7891e-b97a-52a8-acfd-bbf986732d6c"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/SHARPERSIST/production/yara/HackTool_MSIL_SharPersist_2.yar#L4-L23"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "98ecf58d48a3eae43899b45cec0fc6b7"
		logic_hash = "57387352f8fd08e8b859dffc1164d46370f248b337526c265634160010572a00"
		score = 75
		quality = 75
		tags = "FILE"
		rev = 1

	strings:
		$a1 = "SharPersist.lib"
		$a2 = "SharPersist.exe"
		$b1 = "ERROR: Invalid hotkey location option given." ascii wide
		$b2 = "ERROR: Invalid hotkey given." ascii wide
		$b3 = "ERROR: Keepass configuration file not found." ascii wide
		$b4 = "ERROR: Keepass configuration file was not found." ascii wide
		$b5 = "ERROR: That value already exists in:" ascii wide
		$b6 = "ERROR: Failed to delete hidden registry key." ascii wide
		$pdb1 = "\\SharPersist\\"
		$pdb2 = "\\SharPersist.pdb"

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( ( @pdb2 [ 1 ] < @pdb1 [ 1 ] + 50 ) or ( 1 of ( $a* ) and 2 of ( $b* ) ) )
}
rule FIREEYE_RT_Hacktool_PY_Impacketobfuscation_1
{
	meta:
		description = "smbexec"
		author = "FireEye"
		id = "992d1132-3136-5e1b-a1ef-dcdf36ebf0f5"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/IMPACKETOBF (Smbexec)/production/yara/HackTool_PY_ImpacketObfuscation_1.yar#L4-L22"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "0b1e512afe24c31531d6db6b47bac8ee"
		logic_hash = "45a4c0426b29b8c8bede9c4e8292131da7e756d48fc3ac4a07d08fd52383d21e"
		score = 75
		quality = 75
		tags = ""
		date_created = "2020-12-01"
		date_modified = "2020-12-01"
		rev = 1

	strings:
		$s1 = "class CMDEXEC" nocase
		$s2 = "class RemoteShell" nocase
		$s3 = "self.services_names"
		$s4 = "import random"
		$s6 = /self\.__shell[\x09\x20]{0,32}=[\x09\x20]{0,32}[\x22\x27]%CoMSpEC%[\x09\x20]{1,32}\/q[\x09\x20]{1,32}\/K [\x22\x27]/ nocase
		$s7 = /self\.__serviceName[\x09\x20]{0,32}=[\x09\x20]{0,32}self\.services_names\[random\.randint\([\x09\x20]{0,32}0[\x09\x20]{0,32},[\x09\x20]{0,32}len\(self\.services_names\)[\x09\x20]{0,32}-[\x09\x20]{0,32}1\)\]/

	condition:
		all of them
}
rule FIREEYE_RT_Hacktool_MSIL_Rubeus_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the public Rubeus project."
		author = "FireEye"
		id = "0ca140ea-2b9f-5904-a4c0-8615229626f0"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/RUBEUS/production/yara/HackTool_MSIL_Rubeus_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "66e0681a500c726ed52e5ea9423d2654"
		logic_hash = "ad954f9922ab564d68cb4515b080f6ee69476a8d87f0038e2ae4c222f0e182d7"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 4

	strings:
		$typelibguid = "658C8B7F-3664-4A95-9572-A3E5871DFC06" ascii nocase wide

	condition:
		uint16( 0 ) == 0x5A4D and $typelibguid
}
rule FIREEYE_RT_Hacktool_MSIL_Sharpschtask_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'SharpSchtask' project."
		author = "FireEye"
		id = "5c7a5dee-3bc2-54b2-a7e2-be05ba74d4a1"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/SHARPSCHTASK/production/yara/HackTool_MSIL_SharpSchtask_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "7437fde82920f4d015a7f149b58924baf6cb220c6f6857d9509e23795ff0811c"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 1

	strings:
		$typelibguid0 = "0a64a5f4-bdb6-443c-bdc7-f6f0bf5b5d6c" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Loader_MSIL_Csharpsectioninjection_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'C_Sharp_SectionInjection' project."
		author = "FireEye"
		id = "ca5bf5cd-1950-53ed-8984-e880a15e658e"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/SHARPSECTIONINJECTION/production/yara/Loader_MSIL_CSharpSectionInjection_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "011cf4dffe6ef90a79cdfabb0e297152c00b0404b1801f56fd7e703ab90b1692"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid0 = "d77135da-0496-4b5c-9afe-e1590a4c136a" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Hacktool_MSIL_DTRIM_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'dtrim' project, which is a modified version of SharpSploit."
		author = "FireEye"
		id = "9be695a1-6d18-5952-974c-96a30f035e7a"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/DTRIM/production/yara/APT_HackTool_MSIL_DTRIM_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "357c1f76631ec9ee342995cd12369fd9ff18c541bffe6f5464b1e8db45057196"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid0 = "7760248f-9247-4206-be42-a6952aa46da2" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_APT_Loader_Win32_Dshell_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "dad763bd-0e4a-542a-9920-ece11d23ce24"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/DSHELL/production/yara/APT_Loader_Win32_DShell_1.yar#L4-L20"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "12c3566761495b8353f67298f15b882c"
		logic_hash = "79643f9c252765647d80f6fe1ee7bb698fbc6a6c3a0ff1fd819a09bff031907c"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-27"
		date_modified = "2020-11-27"
		rev = 1

	strings:
		$sb1 = { 6A 40 68 00 30 00 00 [4-32] E8 [4-8] 50 [0-16] E8 [4-150] 6A FF [1-32] 6A 00 6A 00 5? 6A 00 6A 00 [0-32] E8 [4] 50 }
		$sb2 = { FF 7? 0C B? [4-16] FF 7? 08 5? [0-12] E8 [4] 84 C0 74 05 B? 01 00 00 00 [0-16] 80 F2 01 0F 84 }
		$ss1 = "\x00CreateThread\x00"
		$ss2 = "base64.d" fullword
		$ss3 = "core.sys.windows" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x010B ) and all of them
}
rule FIREEYE_RT_APT_Loader_Win32_Dshell_3 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "6b6fccef-ac93-5f1b-b9b6-c2d3ee4d8da7"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/DSHELL/production/yara/APT_Loader_Win32_DShell_3.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "12c3566761495b8353f67298f15b882c"
		logic_hash = "ec2a8b0abc6cb6d1861199b892fbe84782b42babb08e3ea203d10ab17ff7a20a"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-27"
		date_modified = "2020-11-27"
		rev = 1

	strings:
		$sb1 = { 6A 40 68 00 30 00 00 [4-32] E8 [4-8] 50 [0-16] E8 [4-150] 6A FF [1-32] 6A 00 6A 00 5? 6A 00 6A 00 [0-32] E8 [4] 50 }
		$ss1 = "\x00CreateThread\x00"
		$ss2 = "base64.d" fullword
		$ss3 = "core.sys.windows" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x010B ) and all of them
}
rule FIREEYE_RT_APT_Loader_Win32_Dshell_2 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "ae34d547-d979-5ce2-bcf8-a5b4e4567de3"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/DSHELL/production/yara/APT_Loader_Win32_DShell_2.yar#L4-L21"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "590d98bb74879b52b97d8a158af912af"
		logic_hash = "958ff45add46c0a43e839e8007c1d9296ee89ddd8c045b8ec6b031b225207a6c"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-11-27"
		date_modified = "2020-11-27"
		rev = 2

	strings:
		$sb1 = { 6A 40 68 00 30 00 00 [4-32] E8 [4-8] 50 [0-16] E8 [4-150] 6A FF [1-32] 6A 00 6A 00 5? 6A 00 6A 00 [0-32] E8 [4] 50 }
		$ss1 = "\x00CreateThread\x00"
		$ss2 = "base64.d" fullword
		$ss3 = "core.sys.windows" fullword
		$ss4 = "C:\\Users\\config.ini" fullword
		$ss5 = "Invalid config file" fullword

	condition:
		( uint16( 0 ) == 0x5A4D ) and ( uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( uint16( uint32( 0x3C ) + 0x18 ) == 0x010B ) and all of them
}
rule FIREEYE_RT_Hacktool_MSIL_INVEIGHZERO_1 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the 'inveighzero' project."
		author = "FireEye"
		id = "f46fe365-ea50-5597-828e-61a7225e4c6e"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/INVEIGHZERO/production/yara/HackTool_MSIL_INVEIGHZERO_1.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "dd8805d0e470e59b829d98397507d8c2"
		logic_hash = "5d10557a83dae9508469fe87f4c0c91beec4d2812856eee461a82d5dbb89aa35"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 2

	strings:
		$typelibguid0 = "113ae281-d1e5-42e7-9cc2-12d30757baf1" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and any of them
}
rule FIREEYE_RT_Loader_MSIL_RURALBISHOP_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "1b5f1f39-9fa2-5940-8da3-03808e4b7a5d"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/TRIMBISHOP/new/yara/Loader_MSIL_RURALBISHOP_1.yar#L4-L22"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "e91670423930cbbd3dbf5eac1f1a7cb6"
		logic_hash = "f2244c6761639c1162a77a5e82296903c3cc21fbf46d262c779c5e4d6a2ef937"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-03"
		date_modified = "2020-12-03"
		rev = 1

	strings:
		$sb1 = { 28 [2] 00 06 0A 06 7B [2] 00 04 [12-64] 06 7B [2] 00 04 6E 28 [2] 00 06 0B 07 7B [2] 00 04 [12-64] 0? 7B [2] 00 04 0? 7B [2] 00 04 0? 7B [2] 00 04 6E 28 [2] 00 06 0? 0? 7B [2] 00 04 [12-80] 0? 7B [2] 00 04 1? 0? 7B [2] 00 04 }
		$sb2 = { 0F ?? 7C [2] 00 04 28 [2] 00 0A 8C [2] 00 01 [20-80] 28 [2] 00 06 0? 0? 7E [2] 00 0A 28 [2] 00 0A [12-80] 7E [2] 00 0A 13 ?? 0? 7B [2] 00 04 28 [2] 00 0A 0? 28 [2] 00 0A 58 28 [2] 00 0A 13 [1-32] 28 [2] 00 0A [0-32] D0 [2] 00 02 28 [2] 00 0A 28 [2] 00 0A 74 [2] 00 02 }
		$ss1 = "\x00NtMapViewOfSection\x00"
		$ss2 = "\x00NtOpenProcess\x00"
		$ss3 = "\x00NtAlertResumeThread\x00"
		$ss4 = "\x00LdrGetProcedureAddress\x00"
		$tb1 = "\x00SharpSploit.Execution.DynamicInvoke\x00"

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( @sb1 [ 1 ] < @sb2 [ 1 ] ) and ( all of ( $ss* ) ) and ( all of ( $tb* ) )
}
rule FIREEYE_RT_Loader_MSIL_RURALBISHOP_2 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "3befb3f2-81d1-5db2-84d9-773158b9837c"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/TRIMBISHOP/new/yara/Loader_MSIL_RURALBISHOP_2.yar#L4-L22"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "e91670423930cbbd3dbf5eac1f1a7cb6"
		logic_hash = "0467532d643cf0200c6561b0724c884230892bf59db163c311b7d4f8acbb63d6"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-03"
		date_modified = "2020-12-03"
		rev = 1

	strings:
		$ss1 = "\x00NtMapViewOfSection\x00"
		$ss2 = "\x00NtOpenProcess\x00"
		$ss3 = "\x00NtAlertResumeThread\x00"
		$ss4 = "\x00LdrGetProcedureAddress\x00"
		$ss5 = "\x2f(\x00?\x00i\x00)\x00(\x00-\x00|\x00-\x00-\x00|\x00/\x00)\x00(\x00i\x00|\x00I\x00n\x00j\x00e\x00c\x00t\x00)\x00$\x00"
		$ss6 = "\x2d(\x00?\x00i\x00)\x00(\x00-\x00|\x00-\x00-\x00|\x00/\x00)\x00(\x00c\x00|\x00C\x00l\x00e\x00a\x00n\x00)\x00$\x00"
		$tb1 = "\x00SharpSploit.Execution.DynamicInvoke\x00"

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_Loader_MSIL_Ruralbishop_3 : FILE
{
	meta:
		description = "The TypeLibGUID present in a .NET binary maps directly to the ProjectGuid found in the '.csproj' file of a .NET project. This rule looks for .NET PE files that contain the ProjectGuid found in the public RuralBishop project."
		author = "FireEye"
		id = "55a060ef-74e2-50d9-9090-558aaa04d97d"
		date = "2020-12-09"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/TRIMBISHOP/production/yara/Loader_MSIL_RuralBishop_3.yar#L4-L15"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "09bdbad8358b04994e2c04bb26a160ef"
		logic_hash = "a4c55dede432c249e36e96ca09555448b0343969d389bfdb4bd459fe34e05ea1"
		score = 75
		quality = 73
		tags = "FILE"
		rev = 3

	strings:
		$typelibguid1 = "FE4414D9-1D7E-4EEB-B781-D278FE7A5619" ascii nocase wide

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and $typelibguid1
}
rule FIREEYE_RT_APT_Loader_MSIL_TRIMBISHOP_2 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "90ee2569-2e68-517b-b2d7-8c4015d92683"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/TRIMBISHOP/production/yara/APT_Loader_MSIL_TRIMBISHOP_2.yar#L4-L22"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "c0598321d4ad4cf1219cc4f84bad4094"
		logic_hash = "4cccfca0c06954105f762066741b6c35599a6c28df8b7c255a2659059169578f"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-03"
		date_modified = "2020-12-03"
		rev = 1

	strings:
		$ss1 = "\x00NtMapViewOfSection\x00"
		$ss2 = "\x00NtOpenProcess\x00"
		$ss3 = "\x00NtAlertResumeThread\x00"
		$ss4 = "\x00LdrGetProcedureAddress\x00"
		$ss5 = "\x2f(\x00?\x00i\x00)\x00(\x00-\x00|\x00-\x00-\x00|\x00/\x00)\x00(\x00i\x00|\x00I\x00n\x00j\x00e\x00c\x00t\x00)\x00$\x00"
		$ss6 = "\x2d(\x00?\x00i\x00)\x00(\x00-\x00|\x00-\x00-\x00|\x00/\x00)\x00(\x00c\x00|\x00C\x00l\x00e\x00a\x00n\x00)\x00$\x00"
		$tb1 = "\x00DTrim.Execution.DynamicInvoke\x00"

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and all of them
}
rule FIREEYE_RT_APT_Loader_MSIL_TRIMBISHOP_1 : FILE
{
	meta:
		description = "No description has been set in the source file - FireEye-RT"
		author = "FireEye"
		id = "1a3f4247-25f4-51ca-b881-209c0753b915"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/TRIMBISHOP/production/yara/APT_Loader_MSIL_TRIMBISHOP_1.yar#L4-L22"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "e91670423930cbbd3dbf5eac1f1a7cb6"
		logic_hash = "f020efff58c8b7761d700c662c422a9e1ffdf8fe5f6648e421b7c257e3b8d078"
		score = 75
		quality = 75
		tags = "FILE"
		date_created = "2020-12-03"
		date_modified = "2020-12-03"
		rev = 1

	strings:
		$sb1 = { 28 [2] 00 06 0A 06 7B [2] 00 04 [12-64] 06 7B [2] 00 04 6E 28 [2] 00 06 0B 07 7B [2] 00 04 [12-64] 0? 7B [2] 00 04 0? 7B [2] 00 04 0? 7B [2] 00 04 6E 28 [2] 00 06 0? 0? 7B [2] 00 04 [12-80] 0? 7B [2] 00 04 1? 0? 7B [2] 00 04 }
		$sb2 = { 0F ?? 7C [2] 00 04 28 [2] 00 0A 8C [2] 00 01 [20-80] 28 [2] 00 06 0? 0? 7E [2] 00 0A 28 [2] 00 0A [12-80] 7E [2] 00 0A 13 ?? 0? 7B [2] 00 04 28 [2] 00 0A 0? 28 [2] 00 0A 58 28 [2] 00 0A 13 [1-32] 28 [2] 00 0A [0-32] D0 [2] 00 02 28 [2] 00 0A 28 [2] 00 0A 74 [2] 00 02 }
		$ss1 = "\x00NtMapViewOfSection\x00"
		$ss2 = "\x00NtOpenProcess\x00"
		$ss3 = "\x00NtAlertResumeThread\x00"
		$ss4 = "\x00LdrGetProcedureAddress\x00"
		$tb1 = "\x00DTrim.Execution.DynamicInvoke\x00"

	condition:
		( uint16( 0 ) == 0x5A4D and uint32( uint32( 0x3C ) ) == 0x00004550 ) and ( @sb1 [ 1 ] < @sb2 [ 1 ] ) and ( all of ( $ss* ) ) and ( all of ( $tb* ) )
}
/*
 * YARA Rule Set
 * Repository Name: GCTI
 * Repository: https://github.com/chronicle/GCTI
 * Retrieval Date: 2026-11-22
 * Git Commit: 1c5fd42b1895098527fde00c2d9757edf6b303bb
 * Number of Rules: 89
 * Skipped: 0 (age), 2 (quality), 0 (score), 0 (importance)
 *
 * 
 * LICENSE
 * 
 * 
                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright 2022 Google

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

 */
rule GCTI_Sliver_Implant_64Bit
{
	meta:
		description = "Sliver 64-bit implant (with and without --debug flag at compile)"
		author = "gssincla@google.com"
		id = "b84db933-0e11-5871-821d-43697c015665"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/Sliver/Sliver__Implant_64bit.yara#L17-L84"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "2d1c9de42942a16c88a042f307f0ace215cdc67241432e1152080870fe95ea87"
		logic_hash = "ad4ceef08a732174c8ccbcacf0370b26acb9e5ec0784d8827c8104618e018a26"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s_tcppivot = { 48 ?? 74 63 70 70 69 76 6F 74 }
		$s_namedpipe = { 48 ?? 6E 61 6D 65 64 70 69 70 [2-32] 80 ?? 08 65 }
		$s_https = { 81 ?? 68 74 74 70 [2-32] 80 ?? 04 73 }
		$s_wg = {66 81 ?? 77 67}
		$s_dns = { 66 81 ?? 64 6E [2-20] 80 ?? 02 73 }
		$s_mtls = {  81 ?? 6D 74 6C 73  }
		$fp1 = "cloudfoundry" ascii fullword

	condition:
		5 of ( $s* ) and not 1 of ( $fp* )
}
rule GCTI_Cobaltstrike_Resources_Artifact64_V1_49_V2_X_V3_0_V3_3_Thru_V3_14
{
	meta:
		description = "Cobalt Strike's resources/artifact64{.dll,.exe,big.exe,big.dll,bigsvc.exe,big.x64.dll} and resources/rtifactuac(alt)64.dll signature for versions v1.49, v2.x, v3.0, and v3.3 through v3.14"
		author = "gssincla@google.com"
		id = "67902782-500e-5a89-8b2a-59ee21bcba3e"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Artifact64_v1_49_to_v4_x.yara#L17-L54"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "9ec57d306764517b5956b49d34a3a87d4a6b26a2bb3d0fdb993d055e0cc9920d"
		logic_hash = "289950e89fc743ff4a1b7dcb91c561c7d829cfe3ade1c2f1a09f2e9701cce461"
		score = 75
		quality = 85
		tags = ""

	strings:
		$a = { 8B [2] 48 98 48 [2] 48 [3] 8B [2] 48 98 48 [3] 44 [3] 8B [2] 89 ?? C1 ?? 1F C1 ?? 1E 01 ?? 83 ?? 03 29 ?? 48 98 48 [3] 0F B6 00 44 [2] 88 }

	condition:
		$a
}
rule GCTI_Cobaltstrike_Resources_Artifact64_V3_1_V3_2_V3_14_And_V4_0
{
	meta:
		description = "Cobalt Strike's resources/artifact64{svcbig.exe,.dll,big.dll,svc.exe} and resources/artifactuac(big)64.dll signature for versions 3.14 to 4.x and resources/artifact32svc.exe for 3.14 to 4.x"
		author = "gssincla@google.com"
		id = "c9e9b8e0-16fe-5abc-b1fe-0e3e586f6db6"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Artifact64_v1_49_to_v4_x.yara#L56-L84"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "2e7a39bd6ac270f8f548855b97c4cef2c2ce7f54c54dd4d1aa0efabeecf3ba90"
		logic_hash = "e5af04baa1d18d5a2a2c005b40bf93fe6a7b2d7116dfcf3c5b3fa36657448eb9"
		score = 75
		quality = 85
		tags = ""

	strings:
		$decoderFunction = { 31 ?? EB 0F 41 [2] 03 47 [3] 44 [3] 48 [2] 39 ?? 41 [2] 7C EA 4C [6] E9 }

	condition:
		$decoderFunction
}
rule GCTI_Cobaltstrike_Resources_Artifact64_V3_14_To_V4_X
{
	meta:
		description = "Cobalt Strike's resources/artifact64{.exe,.dll,svc.exe,svcbig.exe,big.exe,big.dll,.x64.dll,big.x64.dll} and resource/artifactuac(alt)64.exe signature for versions v3.14 through v4.x"
		author = "gssincla@google.com"
		id = "1c7731d3-429b-57aa-9c17-8de7d0841b1e"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Artifact64_v1_49_to_v4_x.yara#L86-L128"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "decfcca0018f2cec4a200ea057c804bb357300a67c6393b097d52881527b1c44"
		logic_hash = "af8ba6ba62bf1179510b0940e60f893f61b3ba10c81001dd90fe4c3521e56a37"
		score = 75
		quality = 85
		tags = ""

	strings:
		$fmtBuilder = {
			41 ?? 5C 00 00 00
			C7 [3] 5C 00 00 00
			C7 [3] 65 00 00 00
			C7 [3] 70 00 00 00
			C7 [3] 69 00 00 00
			C7 [3] 70 00 00 00
			C7 [3] 5C 00 00 00
			C7 [3] 2E 00 00 00
			89 [3]
			48 [6]
			E8
		}
		$fmtString = "%c%c%c%c%c%c%c%c%cMSSE-%d-server"

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Sleeve_Beaconloader_HA_X86_O_V4_3_V4_4_V4_5_And_V4_6
{
	meta:
		description = "Cobalt Strike's sleeve/BeaconLoader.HA.x86.o (HeapAlloc) Versions 4.3 through at least 4.6"
		author = "gssincla@google.com"
		id = "0ee3fa6f-367c-596f-a3bc-3bcfa61b97aa"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Sleeve_BeaconLoader_all.yara#L17-L59"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "8e4a1862aa3693f0e9011ade23ad3ba036c76ae8ccfb6585dc19ceb101507dcd"
		logic_hash = "d02257bc556d0b1675997ab6af1b28cf5f498855d6254e3c1cd7eb4a0c4d2715"
		score = 75
		quality = 85
		tags = ""

	strings:
		$core_sig = {
      C6 45 F0 48
      C6 45 F1 65
      C6 45 F2 61
      C6 45 F3 70
      C6 45 F4 41
      C6 45 F5 6C
      C6 45 F6 6C
      C6 45 F7 6F
      C6 45 F8 63
      C6 45 F9 00
    }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Sleeve_Beaconloader_MVF_X86_O_V4_3_V4_4_V4_5_And_V4_6
{
	meta:
		description = "Cobalt Strike's sleeve/BeaconLoader.MVF.x86.o (MapViewOfFile) Versions 4.3 through at least 4.6"
		author = "gssincla@google.com"
		id = "3f7c0553-989e-53e7-87a9-3fa1c47f4b62"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Sleeve_BeaconLoader_all.yara#L61-L111"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "cded3791caffbb921e2afa2de4c04546067c3148c187780066e8757e67841b44"
		logic_hash = "dd831fb01a403213c06e3d07daf3da5f56655619a686149f9d4beec2331fe6ca"
		score = 75
		quality = 85
		tags = ""

	strings:
		$core_sig = {
      C6 45 EC 4D
      C6 45 ED 61
      C6 45 EE 70
      C6 45 EF 56
      C6 45 F0 69
      C6 45 F1 65
      C6 45 F2 77
      C6 45 F3 4F
      C6 45 F4 66
      C6 45 F5 46
      C6 45 F6 69
      C6 45 F7 6C
      C6 45 F8 65
      C6 45 F9 00
    }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Sleeve_Beaconloader_VA_X86_O_V4_3_V4_4_V4_5_And_V4_6
{
	meta:
		description = "Cobalt Strike's sleeve/BeaconLoader.VA.x86.o (VirtualAlloc) Versions 4.3 through at least 4.6"
		author = "gssincla@google.com"
		id = "5f89c4be-f4c5-54d3-b923-d125de53902f"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Sleeve_BeaconLoader_all.yara#L114-L194"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "94d1b993a9d5786e0a9b44ea1c0dc27e225c9eb7960154881715c47f9af78cc1"
		logic_hash = "19b2297986bd72204fb117560cddcfb512f5db6c157d9730b5802bf9f968eef4"
		score = 75
		quality = 85
		tags = ""

	strings:
		$core_sig = {
      C6 45 B0 56
      C6 45 B1 69
      C6 45 B2 72
      C6 45 B3 74
      C6 45 B4 75
      C6 45 B5 61
      C6 45 B6 6C
      C6 45 B7 41
      C6 45 B8 6C
      C6 45 B9 6C
      C6 45 BA 6F
      C6 45 BB 63
      C6 45 BC 00
    }
		$deobfuscator = {
      8B 4D FC
      83 C1 01
      89 4D FC
      8B 55 FC
      3B 55 0C
      73 19
      0F B6 45 10
      8B 4D 08
      03 4D FC
      0F BE 11
      33 D0
      8B 45 08
      03 45 FC
      88 10
      EB D6
    }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Sleeve_Beaconloader_X86_O_V4_3_V4_4_V4_5_And_V4_6
{
	meta:
		description = "Cobalt Strike's sleeve/BeaconLoader.x86.o Versions 4.3 through at least 4.6"
		author = "gssincla@google.com"
		id = "32a47966-f3bb-52c3-a977-82a1b09ddf2c"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Sleeve_BeaconLoader_all.yara#L196-L276"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "94d1b993a9d5786e0a9b44ea1c0dc27e225c9eb7960154881715c47f9af78cc1"
		logic_hash = "cab5441ce7d919101fc04aa469e77b71a4c444443e44c752f18cbbc5b17ed5c2"
		score = 75
		quality = 85
		tags = ""

	strings:
		$core_sig = {
      C6 45 B0 56
      C6 45 B1 69
      C6 45 B2 72
      C6 45 B3 74
      C6 45 B4 75
      C6 45 B5 61
      C6 45 B6 6C
      C6 45 B7 41
      C6 45 B8 6C
      C6 45 B9 6C
      C6 45 BA 6F
      C6 45 BB 63
      C6 45 BC 00
    }
		$deobfuscator = {
      8B 4D FC
      83 C1 01
      89 4D FC
      8B 55 FC
      3B 55 0C
      73 19
      0F B6 45 10
      8B 4D 08
      03 4D FC
      0F BE 11
      33 D0
      8B 45 08
      03 45 FC
      88 10
      EB D6
    }

	condition:
		$core_sig and not $deobfuscator
}
rule GCTI_Cobaltstrike_Sleeve_Beaconloader_HA_X64_O_V4_3_V4_4_V4_5_And_V4_6
{
	meta:
		description = "Cobalt Strike's sleeve/BeaconLoader.HA.x64.o (HeapAlloc) Versions 4.3 through at least 4.6"
		author = "gssincla@google.com"
		id = "9b16ff13-2d8e-51dc-9f99-6c45eff76feb"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Sleeve_BeaconLoader_all.yara#L281-L323"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "d64f10d5a486f0f2215774e8ab56087f32bef19ac666e96c5627c70d345a354d"
		logic_hash = "b712a0c218e473f6c64fdead22b291d7fb0bac8ba614adcf1ba6431e854a5e65"
		score = 75
		quality = 85
		tags = ""

	strings:
		$core_sig = {
      C6 44 24 38 48
      C6 44 24 39 65
      C6 44 24 3A 61
      C6 44 24 3B 70
      C6 44 24 3C 41
      C6 44 24 3D 6C
      C6 44 24 3E 6C
      C6 44 24 3F 6F
      C6 44 24 40 63
      C6 44 24 41 00
    }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Sleeve_Beaconloader_MVF_X64_O_V4_3_V4_4_V4_5_And_V4_6
{
	meta:
		description = "Cobalt Strike's sleeve/BeaconLoader.MVF.x64.o (MapViewOfFile) Versions 4.3 through at least 4.6"
		author = "gssincla@google.com"
		id = "38e063db-3d76-5a94-812a-945fcf46a232"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Sleeve_BeaconLoader_all.yara#L326-L374"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "9d5b6ccd0d468da389657309b2dc325851720390f9a5f3d3187aff7d2cd36594"
		logic_hash = "6224000342d87041fd3336656897479c644e94ea36fc061c27fcd64233047c2c"
		score = 75
		quality = 85
		tags = ""

	strings:
		$core_sig = {
      C6 44 24 58 4D
      C6 44 24 59 61
      C6 44 24 5A 70
      C6 44 24 5B 56
      C6 44 24 5C 69
      C6 44 24 5D 65
      C6 44 24 5E 77
      C6 44 24 5F 4F
      C6 44 24 60 66
      C6 44 24 61 46
      C6 44 24 62 69
      C6 44 24 63 6C
      C6 44 24 64 65
    }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Sleeve_Beaconloader_VA_X64_O_V4_3_V4_4_V4_5_And_V4_6
{
	meta:
		description = "Cobalt Strike's sleeve/BeaconLoader.VA.x64.o (VirtualAlloc) Versions 4.3 through at least 4.6"
		author = "gssincla@google.com"
		id = "8ca04f82-a8a8-5162-8b0c-8a7bce678a85"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Sleeve_BeaconLoader_all.yara#L376-L456"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "ac090a0707aa5ccd2c645b523bd23a25999990cf6895fce3bfa3b025e3e8a1c9"
		logic_hash = "17402e952d71d02274a9b2814512b28a402e8d11a6c2a2375844fe24719f87a6"
		score = 75
		quality = 85
		tags = ""

	strings:
		$core_sig = {
      C6 44 24 48 56
      C6 44 24 49 69
      C6 44 24 4A 72
      C6 44 24 4B 74
      C6 44 24 4C 75
      C6 44 24 4D 61
      C6 44 24 4E 6C
      C6 44 24 4F 41
      C6 44 24 50 6C
      C6 44 24 51 6C
      C6 44 24 52 6F
      C6 44 24 53 63
      C6 44 24 54 00
    }
		$deobfuscator = {
      8B 04 24
      FF C0
      89 04 24
      8B 44 24 28
      39 04 24
      73 20
      8B 04 24
      0F B6 4C 24 30
      48 8B 54 24 20
      0F BE 04 02
      33 C1
      8B 0C 24
      48 8B 54 24 20
      88 04 0A
    }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Sleeve_Beaconloader_X64_O_V4_3_V4_4_V4_5_And_V4_6
{
	meta:
		description = "Cobalt Strike's sleeve/BeaconLoader.x64.o (Base) Versions 4.3 through at least 4.6"
		author = "gssincla@google.com"
		id = "07f751e4-f001-5b95-b229-31fbaa867cea"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Sleeve_BeaconLoader_all.yara#L458-L555"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "ac090a0707aa5ccd2c645b523bd23a25999990cf6895fce3bfa3b025e3e8a1c9"
		logic_hash = "50d9da466e2c074b3fb634203c8840d45da8f8e3094790d7c4354a5703b583ef"
		score = 75
		quality = 85
		tags = ""

	strings:
		$core_sig = {
      33 C0
      83 F8 01
      74 63
      48 8B 44 24 20
      0F B7 00
      3D 4D 5A 00 00
      75 45
      48 8B 44 24 20
      48 63 40 3C
      48 89 44 24 28
      48 83 7C 24 28 40
      72 2F
      48 81 7C 24 28 00 04 00 00
      73 24
      48 8B 44 24 20
      48 8B 4C 24 28
      48 03 C8
      48 8B C1
      48 89 44 24 28
      48 8B 44 24 28
      81 38 50 45 00 00
      75 02
    }
		$deobfuscator = {
      8B 04 24
      FF C0
      89 04 24
      8B 44 24 28
      39 04 24
      73 20
      8B 04 24
      0F B6 4C 24 30
      48 8B 54 24 20
      0F BE 04 02
      33 C1
      8B 0C 24
      48 8B 54 24 20
      88 04 0A
    }

	condition:
		$core_sig and not $deobfuscator
}
rule GCTI_Cobaltstrike_Resources_Xor_Bin__64Bit_V3_12_To_V4_X
{
	meta:
		description = "Cobalt Strike's resource/xor64.bin signature for version 3.12 through 4.x"
		author = "gssincla@google.com"
		id = "5bb465ee-3bbd-5bfe-8b63-1f243de217bc"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Xor_Bin__64bit_v3_12_to_4_x.yara#L17-L38"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "01dba8783768093b9a34a1ea2a20f72f29fd9f43183f3719873df5827a04b744"
		logic_hash = "aabaad09408ae292a0bbc678c334f9f54364b4f6b882846072c303bf826fc2da"
		score = 75
		quality = 85
		tags = ""

	strings:
		$stub58 = {fc e8 ?? ?? ?? ?? [1-32] eb 33 5? 8b ?? 00 4? 83 ?? ?4 8b ?? 00 31 ?? 4? 83 ?? ?4 5? 8b ?? 00 31 ?? 89 ?? 00 31 ?? 4? 83 ?? ?4 83 ?? ?4 31 ?? 39 ?? 74 ?2 eb e7 5? fc 4? 83 ?? f0 ff}
		$stub59 = {fc e8 ?? ?? ?? ?? [1-32] eb 2e 5? 8b ??    48 83 c? ?4 8b ??    31 ?? 48 83 c? ?4 5? 8b ??    31 ?? 89 ??    31 ?? 48 83 c? ?4 83 e? ?4 31 ?? 39 ?? 74 ?2 eb e9 5?    48 83 ec ?8 ff e? e8 cd ff ff ff}
		$stub63 = {fc e8 ?? ?? ?? ?? [1-32] eb 32 5d 8b ?? ?? 48 83 c5 ?4 8b ?? ?? 31 ?? 48 83 c5 ?4 55 8b ?? ?? 31 ?? 89 ?? ?? 31 ?? 48 83 c5 ?4 83 e? ?4 31 ?? 39 ?? 74 ?2 eb e7 5?    48 83 ec ?8 ff e? e8 c9 ff ff ff}

	condition:
		any of them
}
rule GCTI_Cobaltstrike_Resources_Template_X64_Ps1_V3_0_To_V4_X_Excluding_3_12_3_13
{
	meta:
		description = "Cobalt Strike's resources/template.x64.ps1, resources/template.hint.x64.ps1 and resources/template.hint.x32.ps1 from v3.0 to v4.x except 3.12 and 3.13"
		author = "gssincla@google.com"
		id = "5a808113-aacb-56ca-b3ec-166c73c54b85"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Template_x64_Ps1_v3_0_to_v4_x_excluding_3_12_3_13.yara#L17-L37"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "ff743027a6bcc0fee02107236c1f5c96362eeb91f3a5a2e520a85294741ded87"
		logic_hash = "80823b8590004686ebd83958cad16094ea2f6958a837d87934507531a00df77a"
		score = 75
		quality = 81
		tags = ""

	strings:
		$dda = "[AppDomain]::CurrentDomain.DefineDynamicAssembly" nocase
		$imm = "InMemoryModule" nocase
		$mdt = "MyDelegateType" nocase
		$rd = "New-Object System.Reflection.AssemblyName('ReflectedDelegate')" nocase
		$data = "[Byte[]]$var_code = [System.Convert]::FromBase64String(" nocase
		$64bitSpecific = "[IntPtr]::size -eq 8"
		$mandatory = "Mandatory = $True"

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Smbstager_Bin_V2_5_Through_V4_X
{
	meta:
		description = "Cobalt Strike's resources/smbstager.bin signature for versions 2.5 to 4.x"
		author = "gssincla@google.com"
		id = "074b7d83-e3d8-541c-804b-2417c21f54d5"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Smbstager_Bin_v2_5_through_v4_x.yara#L17-L95"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "946af5a23e5403ea1caccb2e0988ec1526b375a3e919189f16491eeabc3e7d8c"
		logic_hash = "b0f6535069df16a64de44ca0638ec060c1ff264a7820c94710d61ca7e8474450"
		score = 75
		quality = 85
		tags = ""

	strings:
		$apiLocator = {
			31 ?? 
			AC
			C1 ?? 0D 
			01 ?? 
			38 ?? 
			75 ?? 
			03 [2]
			3B [2]
			75 ?? 
			5? 
			8B ?? 24 
			01 ?? 
			66 8B [2]
			8B ?? 1C 
			01 ?? 
			8B ?? 8B 
			01 ?? 
			89 [3]
			5? 
			5? 
		}
		$smb = { 68 C6 96 87 52 }
		$smbstart = {
			6A 40
			68 00 10 00 00
			68 FF FF 07 00
			6A 00
			68 58 A4 53 E5
		}

	condition:
		$apiLocator and $smb and $smbstart
}
rule GCTI_Cobaltstrike_Resources_Covertvpn_Injector_Exe_V1_44_To_V2_0_49
{
	meta:
		description = "Cobalt Strike's resources/covertvpn-injector.exe signature for version v1.44 to v2.0.49"
		author = "gssincla@google.com"
		id = "48485ae2-1d99-5fa8-b8e8-0047e92ef447"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Covertvpn_injector_Exe_v1_44_to_v2_0_49.yara#L17-L116"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "d741751520f46602f5a57d1ed49feaa5789115aeeba7fa4fc7cbb534ee335462"
		logic_hash = "119602efe6243d8c0dc7b8f4468eb9b3be292620920f69dc8a560f900ac7f622"
		score = 75
		quality = 85
		tags = ""

	strings:
		$dropComponentsAndActivateDriver_prologue = {
			C7 04 24 [4]
			E8 [4]
			83 EC 04
			C7 44 24 04 [4]
			89 04 24
			E8 59 14 00 00
			83 EC 08
			89 45 ?? 
			83 7D ?? 00 
			74 ?? 
			E8 [4]
			8D [2]
			89 [3]
			89 04 24
		}
		$dropFile = {
			C7 44 24 04 00 00 00 00
			8B [2]
			89 ?? 24 
			E8 [4]
			83 F8 FF
			74 ?? 
			8B [2]
			89 ?? 24 04 
			C7 04 24 [4]
			E8 [4]
			E9 [4]
			C7 44 24 18 00 00 00 00
			C7 44 24 14 80 01 00 00
			C7 44 24 10 02 00 00 00
			C7 44 24 0C 00 00 00 00
			C7 44 24 08 05 00 00 00
			C7 44 24 04 00 00 00 40
			8B [2]
			89 04 24
			E8 [4]
			83 EC 1C
			89 45 ?? 
		}
		$nfp = "npf.sys" nocase
		$wpcap = "wpcap.dll" nocase

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Bypassuactoken_Dll_V3_11_To_V3_14
{
	meta:
		description = "Cobalt Strike's resources/bypassuactoken.dll from v3.11 to v3.14 (32-bit version)"
		author = "gssincla@google.com"
		id = "b9f25fa5-bd1d-5ba0-9b1d-bb97e1dbf76b"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Bypassuactoken_Dll_v3_11_to_v3_14.yara#L17-L151"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "df1c7256dfd78506e38c64c54c0645b6a56fc56b2ffad8c553b0f770c5683070"
		logic_hash = "fe0780b7f4c16b55cfa00ea7de4da8ce349ec8a72de763b72e816ebc8e934b6d"
		score = 75
		quality = 85
		tags = ""

	strings:
		$isHighIntegrityProcess = {
			5? 
			5? 
			5? 
			8B ?? 
			6A 19
			5? 
			FF 15 [4]
			85 C0
			75 ?? 
			FF 15 [4]
			83 ?? 7A 
			75 ?? 
			FF [2]
			5? 
			FF 15 [4]
			8B ?? 
			8D [2]
			5? 
			FF [2]
			5? 
			6A 19
			5? 
			FF 15 [4]
			85 C0
			74 ?? 
			FF ?? 
			FF 15 [4]
			8A ?? 
			FE C8
			0F B6 C0
			5? 
			FF ?? 
			FF 15 [4]
			B? 01 00 00 00 
			5? 
			81 ?? 00 30 00 00 
		}
		$executeTaskmgr = {
			6A 3C
			8D ?? C4 
			8B ?? 
			6A 00
			5? 
			8B ?? 
			E8 [4]
			83 C4 0C
			C7 [2] 3C 00 00 00 
			8D [2]
			C7 [2] 40 00 00 00 
			C7 [6]
			C7 [2] 00 00 00 00 
			5? 
			C7 [2] 00 00 00 00 
			C7 [6]
			C7 [2] 00 00 00 00 
			FF 15 [4]
			FF 75 FC
		}

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Command_Ps1_V2_5_To_V3_7_And_Resources_Compress_Ps1_V3_8_To_V4_X
{
	meta:
		description = "Cobalt Strike's resources/command.ps1 for versions 2.5 to v3.7 and resources/compress.ps1 from v3.8 to v4.x"
		author = "gssincla@google.com"
		id = "c0b81deb-ed20-5f7e-8e15-e6a9e9362594"
		date = "2022-11-18"
		modified = "2022-11-22"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Command_Ps1_v2_5_to_v3_7_and_Resources_Compress_Ps1_v3_8_to_v4_x.yara#L17-L33"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "932dec24b3863584b43caf9bb5d0cfbd7ed1969767d3061a7abdc05d3239ed62"
		logic_hash = "31cf47060757b086d325cd205724a7be8931bbbc6ff2f4be67a6179ee99c42ca"
		score = 75
		quality = 85
		tags = ""

	strings:
		$ps1 = "$s=New-Object \x49O.MemoryStream(,[Convert]::\x46romBase64String(" nocase
		$ps2 = "));IEX (New-Object IO.StreamReader(New-Object IO.Compression.GzipStream($s,[IO.Compression.CompressionMode]::Decompress))).ReadToEnd();" nocase

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V1_44
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Version 1.44"
		author = "gssincla@google.com"
		id = "935ee27f-ce1b-5491-b4a3-cb78f199ab1b"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L17-L49"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "75102e8041c58768477f5f982500da7e03498643b6ece86194f4b3396215f9c2"
		logic_hash = "ebed8b6dc0b929164b1aa25b491b9d2fbb61d380a8b1268df7d424afe90f613d"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 0F B7 D2 4A 53 8B D9 83 FA 04 77 36 FF 24 }
		$decode = { B1 ?? 30 88 [4] 40 3D 28 01 00 00 7C F2 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V1_45
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Version 1.45"
		author = "gssincla@google.com"
		id = "04d4d0ee-f1ee-5888-8108-ca55243c770a"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L51-L84"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "1a92b2024320f581232f2ba1e9a11bef082d5e9723429b3e4febb149458d1bb1"
		logic_hash = "b1472907e0fe0cb26219c268f23483681cc076dab96c1b0f2f0ee472ad319b4f"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 51 0F B7 D2 4A 53 56 83 FA 08 77 6B FF 24 }
		$decode = { B1 ?? 30 88 [4] 40 3D 28 01 00 00 7C F2 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V1_46
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Version 1.46"
		author = "gssincla@google.com"
		id = "79715042-1963-5e48-8b64-7d915da58d84"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L86-L115"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "44e34f4024878024d4804246f57a2b819020c88ba7de160415be38cd6b5e2f76"
		logic_hash = "1a5c63c8b5527c0442830a73ded8458cf82a9d8ecb9b31e9a02c10b27ed6195e"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 8B F2 83 F9 0C 0F 87 8E 00 00 00 FF 24 }
		$decode = { B1 ?? 30 88 [4] 40 3D A8 01 00 00 7C F2 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V1_47
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Version 1.47"
		author = "gssincla@google.com"
		id = "ac2249a9-210c-581f-8dd1-7619356dca7d"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L117-L144"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "8ff6dc80581804391183303bb39fca2a5aba5fe13d81886ab21dbd183d536c8d"
		logic_hash = "8c463d3122f3f79ff5d9b88e3d4f5ed14e6c581edfdfafba8a0c596c494ac1b1"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 83 F8 12 77 10 FF 24 }
		$decode = { B1 ?? 30 88 [4] 40 3D A8 01 00 00 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V1_48
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Version 1.48"
		author = "gssincla@google.com"
		id = "dd15099f-ad19-58df-9ed4-ce66d7ee8540"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L146-L178"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "dd4e445572cd5e32d7e9cc121e8de337e6f19ff07547e3f2c6b7fce7eafd15e4"
		logic_hash = "3f789eaf334c9bb3236d2834f38156aa92b22a5b674450977086378d195dd216"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 48 57 8B F1 8B DA 83 F8 17 77 12 FF 24 }
		$decode = { B1 ?? 30 88 [4] 40 3D A8 01 00 00 7C F2 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V1_49
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Version 1.49"
		author = "gssincla@google.com"
		id = "871e28c9-b580-5a32-8529-2290ded1a1b6"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L180-L211"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "52b4bd87e21ee0cbaaa0fc007fd3f894c5fc2c4bae5cbc2a37188de3c2c465fe"
		logic_hash = "935232d5ddccdc0401b4d911cdc73a48305347b495219c8c893615fe918f32f1"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 48 56 83 F8 1E 0F 87 23 01 00 00 FF 24 }
		$decoder = { B1 ?? 90 30 88 [4] 40 3D A8 01 00 00 7C F2 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V2_0_49
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Version 2.0.49"
		author = "gssincla@google.com"
		id = "087c584a-5ceb-536a-8842-53fbd668df54"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L213-L243"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "ed08c1a21906e313f619adaa0a6e5eb8120cddd17d0084a30ada306f2aca3a4e"
		logic_hash = "3616579dabcfd0ba413d17b4fbd0da5313b9beca94f7bf8e41f05d6679b4a215"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 83 F8 22 0F 87 96 01 00 00 FF 24 }
		$decoder = { B1 ?? EB 03 8D 49 00 30 88 [4] 40 3D 30 05 00 00 72 F2  }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V2_1_And_V2_2
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Versions 2.1 and 2.2"
		author = "gssincla@google.com"
		id = "384fb247-aae7-52e1-a45d-6bda0f80a04e"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L245-L276"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "ae7a1d12e98b8c9090abe19bcaddbde8db7b119c73f7b40e76cdebb2610afdc2"
		logic_hash = "eee3702d6fde08b8e9f5533f903fa33fb3da808a3b76ca43e4d5029f9ce91ad0"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 49 56 57 83 F9 24 0F 87 8A 01 00 00 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 10 06 00 00 72 F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V2_3
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Versions 2.3"
		author = "gssincla@google.com"
		id = "aed092f1-fbb1-5efe-be8d-fb7c5aba1cde"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L278-L308"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "00dd982cb9b37f6effb1a5a057b6571e533aac5e9e9ee39a399bb3637775ff83"
		logic_hash = "286d7ffa83634b82160788abaf1c5b319a09c4a1243af2401799f327be76ad75"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 49 56 57 83 F9 26 0F 87 A9 01 00 00 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 10 06 00 00 72 F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V2_4
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Versions 2.4"
		author = "gssincla@google.com"
		id = "347a6b06-84a8-53ff-80a1-05fa1a48a412"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L310-L340"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "78c6f3f2b80e6140c4038e9c2bcd523a1b205d27187e37dc039ede4cf560beed"
		logic_hash = "087ec6f585e90b84c00e746beb37cb8365cb7b4d07ebd0c48e3ba3d5df94dba2"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 4A 56 57 83 FA 2F 0F 87 F9 01 00 00 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 10 06 00 00 72 F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V2_5
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Versions 2.5"
		author = "gssincla@google.com"
		id = "a89f9239-099c-5b97-b1df-e8ce2b95ea52"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L342-L372"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "d99693e3e521f42d19824955bef0cefb79b3a9dbf30f0d832180577674ee2b58"
		logic_hash = "f2d0ca1414a60bf855543d99777ae5e83c451db41aba5e255e4c10b1e0bb7b47"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 48 57 8B F2 83 F8 3A 0F 87 6E 02 00 00 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 10 06 00 00 72 F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V3_0
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Versions 3.0"
		author = "gssincla@google.com"
		id = "132a1be8-f529-5141-ba03-fdf6df3d55d4"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L374-L404"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "30251f22df7f1be8bc75390a2f208b7514647835f07593f25e470342fd2e3f52"
		logic_hash = "951f1b52c14010261022f9f920d53d3c1e88f41461798a23e72083c981f9de76"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 48 57 8B F2 83 F8 3C 0F 87 89 02 00 00 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 10 06 00 00 72 F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V3_1
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Versions 3.1"
		author = "gssincla@google.com"
		id = "aa511dee-69ea-53bd-be90-d2d03d08c550"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L406-L461"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "4de723e784ef4e1633bbbd65e7665adcfb03dd75505b2f17d358d5a40b7f35cf"
		logic_hash = "2d91add3aefe69b4525f93f7ea9f2fcbd7a6c506a224997ff73a2eeef63a8cd4"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 55 8B EC 83 EC 58 A1 [4] 33 C5 89 45 FC E8 DF F5 FF FF 6A 50 8D 45 A8 50 FF 15 [4] 8D 45 ?? 50 FF 15 [4] 85 C0 74 14 8B 40 0C 83 38 00 74 0C 8B 00 FF 30 FF 15 [4] EB 05 B8 [4] 8B 4D FC 33 CD E8 82 B7 00 00 C9 }
		$decoder = { 80 B0 [4] ?? 40 3D 10 06 00 00 72 F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V3_2
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Versions 3.2"
		author = "gssincla@google.com"
		id = "3ccbc0f2-241c-5c10-8930-4a3d264d3b57"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L463-L528"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "b490eeb95d150530b8e155da5d7ef778543836a03cb5c27767f1ae4265449a8d"
		logic_hash = "e1fe0d58d86ad8c845d65608314007ce08e3e524fb92cdb33ddae860c640e3e9"
		score = 75
		quality = 85
		tags = ""
		rs2 = "a93647c373f16d61c38ba6382901f468247f12ba8cbe56663abb2a11ff2a5144"

	strings:
		$version_sig = { 48 57 8B F2 83 F8 3D 0F 87 83 02 00 00 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 10 06 00 00 72 F1 }
		$version3_1_sig = { 55 8B EC 83 EC 58 A1 [4] 33 C5 89 45 FC E8 DF F5 FF FF 6A 50 8D 45 A8 50 FF 15 [4] 8D 45 ?? 50 FF 15 [4] 85 C0 74 14 8B 40 0C 83 38 00 74 0C 8B 00 FF 30 FF 15 [4] EB 05 B8 [4] 8B 4D FC 33 CD E8 82 B7 00 00 C9 }

	condition:
		$version_sig and $decoder and not $version3_1_sig
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V3_3
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Versions 3.3"
		author = "gssincla@google.com"
		id = "7cce26c9-1403-535f-bd9d-19667c7e313c"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L530-L560"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "158dba14099f847816e2fc22f254c60e09ac999b6c6e2ba6f90c6dd6d937bc42"
		logic_hash = "f9b9b669aacc156a4e07eab0c6a638f9b9d828e018d1db89e9e2c922641744ac"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 48 57 8B F1 83 F8 41 0F 87 F0 02 00 00 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 10 06 00 00 72 F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V3_4
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Versions 3.4"
		author = "gssincla@google.com"
		id = "58a34ab6-c061-59a2-b929-8519d3d844e7"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L562-L592"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "5c40bfa04a957d68a095dd33431df883e3a075f5b7dea3e0be9834ce6d92daa3"
		logic_hash = "f3372bc538092e30c62d9599f76f2115dc73faf7a5fd6f86c8d4cfaa35473810"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 48 57 8B F1 83 F8 42 0F 87 F0 02 00 00 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V3_5_Hf1_And_3_5_1
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Versions 3.5-hf1 and 3.5.1 (3.5.x)"
		author = "gssincla@google.com"
		id = "1532596e-be0e-58c2-8d3b-5120c793d677"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L594-L625"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "c78e70cd74f4acda7d1d0bd85854ccacec79983565425e98c16a9871f1950525"
		logic_hash = "c2e975678815638803b04261d46bca216bc0b2f894a1f72fd0d5b949493401d1"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 48 57 8B F1 83 F8 43 0F 87 07 03 00 00 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V3_6
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Versions 3.6"
		author = "gssincla@google.com"
		id = "7e7b5c22-82b3-5298-b794-b06d94a668d5"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L627-L657"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "495a744d0a0b5f08479c53739d08bfbd1f3b9818d8a9cbc75e71fcda6c30207d"
		logic_hash = "3bd3f0b8625e131726fa92d68de041dae6c3d5642cbf22ac596d1d82da1d4a07"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 48 57 8B F9 83 F8 47 0F 87 2F 03 00 00 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V3_7
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Versions 3.7"
		author = "gssincla@google.com"
		id = "6352a31c-34b8-5886-8e34-ef9221c22e6e"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L659-L689"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "f18029e6b12158fb3993f4951dab2dc6e645bb805ae515d205a53a1ef41ca9b2"
		logic_hash = "6ceb2cec8402a4679bad42d367156c74e897af4188442fdebc70d6ce2dd78bd6"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 48 57 8B F9 83 F8 49 0F 87 47 03 00 00 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V3_8
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Versions 3.8"
		author = "gssincla@google.com"
		id = "f76712a4-df1c-5e6b-b5ac-9c74f2e202fc"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L691-L731"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "67b6557f614af118a4c409c992c0d9a0cc800025f77861ecf1f3bbc7c293d603"
		logic_hash = "a0c78dd7cda055bc76a8661b0416a302d7b05d03eeea483d2d1695093cd6dc90"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 48 57 8B F9 83 F8 4B 0F 87 5D 03 00 00 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 00 10 00 00 7C F1 }
		$xmrig_srcpath = "C:/Users/SKOL-NOTE/Desktop/Loader/script.go"
		$c2_1 = "ns7.softline.top" xor
		$c2_2 = "ns8.softline.top" xor
		$c2_3 = "ns9.softline.top" xor

	condition:
		$version_sig and $decoder and not ( 2 of ( $c2_* ) or $xmrig_srcpath )
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V3_11
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Versions 3.11"
		author = "gssincla@google.com"
		id = "00e42396-db81-5d43-90ee-5a97b379019e"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L739-L770"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "2428b93464585229fd234677627431cae09cfaeb1362fe4f648b8bee59d68f29"
		logic_hash = "24ca0a9c2249d1872a53dc228234bdc6803bdfe9e80847995e0951184a8d935c"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 48 57 8B FA 83 F8 50 0F 87 11 03 00 00 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V3_11_Bugfix_And_V3_12
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Versions 3.11-bugfix and 3.12"
		author = "gssincla@google.com"
		id = "08ff2a2f-97bd-5839-b414-d67fbf2cdb0f"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L772-L804"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "5912c96fffeabb2c5c5cdd4387cfbfafad5f2e995f310ace76ca3643b866e3aa"
		logic_hash = "566eb14f918ad422d5a273390263e63ac37b00cd10ac3561e038fb1a27f85d80"
		score = 75
		quality = 85
		tags = ""
		rs2 = "4476a93abe48b7481c7b13dc912090b9476a2cdf46a1c4287b253098e3523192"

	strings:
		$version_sig = { 48 57 8B FA 83 F8 50 0F 87 0D 03 00 00 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V3_13
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Versions 3.13"
		author = "gssincla@google.com"
		id = "98dd32e6-9bb5-57b2-a5e5-1c74a0d1e6d3"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L806-L836"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "362119e3bce42e91cba662ea80f1a7957a5c2b1e92075a28352542f31ac46a0c"
		logic_hash = "adafac8692ad676b0168b3e829bc7948db72953b95c79d483ae1a05f1d4f9b2b"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 4A 56 57 83 FA 5A 0F 87 2D 03 00 00 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_Dll_V3_14
{
	meta:
		description = "Cobalt Strike's resources/beacon.dll Versions 3.14"
		author = "gssincla@google.com"
		id = "00edfc72-c7b8-5100-8275-ae3548b96e49"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L838-L866"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "254c68a92a7108e8c411c7b5b87a2f14654cd9f1324b344f036f6d3b6c7accda"
		logic_hash = "6faed2b69647b87d86d46ae73ad92cfe7b2746c306cd7480dc9f0c484c8882e2"
		score = 75
		quality = 85
		tags = ""
		rs2 = "87b3eb55a346b52fb42b140c03ac93fc82f5a7f80697801d3f05aea1ad236730"

	strings:
		$version_sig = { 83 FA 5B 77 15 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Sleeve_Beacon_Dll_V4_0_Suspected
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.dll Versions 4.0 (suspected, not confirmed)"
		author = "gssincla@google.com"
		id = "50ff6e44-ebc0-5000-a816-b385a6675768"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L868-L901"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "e2b2b72454776531bbc6a4a5dd579404250901557f887a6bccaee287ac71b248"
		logic_hash = "6875099bc6df26f829f9f64e70bd7fdac6ac7b83a5596fc9359c127fef4e6db5"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 51 4A 56 57 83 FA 62 0F 87 8F 03 00 00 FF 24 95 56 7B 00 10 }
		$decoder = { 80 B0 [4] ?? 40 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Sleeve_Beacon_Dll_V4_1_And_V4_2
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.dll Versions 4.1 and 4.2"
		author = "gssincla@google.com"
		id = "793df916-bdf7-5743-b008-0113caf38bae"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L903-L934"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "daa42f4380cccf8729129768f3588bb98e4833b0c40ad0620bb575b5674d5fc3"
		logic_hash = "7280a5c3f478ea40b6b72fb4669d5b8c21603e7fbfbc3815a83bc462ee19c0f5"
		score = 75
		quality = 85
		tags = ""
		rs2 = "9de55f27224a4ddb6b2643224a5da9478999c7b2dea3a3d6b3e1808148012bcf"

	strings:
		$version_sig = { 48 57 8B F2 83 F8 63 0F 87 3C 03 00 00 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Sleeve_Beacon_Dll_V4_3_V4_4_V4_5_And_V4_6
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.dll Versions 4.3 and 4.4"
		author = "gssincla@google.com"
		id = "976e087c-f371-5fc6-85f8-9c803a91f549"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L936-L967"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "51490c01c72c821f476727c26fbbc85bdbc41464f95b28cdc577e5701790845f"
		logic_hash = "6608a84c4fd3bf77fd5b426da8be250d8b99878bd746fa23789f4791a164ce33"
		score = 75
		quality = 85
		tags = ""
		rs2 = "78a6fbefa677eeee29d1af4a294ee57319221b329a2fe254442f5708858b37dc"

	strings:
		$version_sig = { 48 57 8B F2 83 F8 65 0F 87 47 03 00 00 FF 24 }
		$decoder = { 80 B0 [4] ?? 40 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Sleeve_Beacon_Dll_V4_7_Suspected
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.dll Versions 4.7 (suspected, not confirmed)"
		author = "gssincla@google.com"
		id = "4b6f90dd-69f3-5555-9195-6a0aed0fff58"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L969-L1002"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "da9e91b3d8df3d53425dd298778782be3bdcda40037bd5c92928395153160549"
		logic_hash = "297ff7c3acfe6f9676dc6c265c548f017f39ccc5217617344e3bccc704ac4c78"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 53 56 48 57 8B F2 83 F8 67 0F 87 5E 03 00 00  }
		$decoder = { 80 B0 [4] ?? 40 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_X64_V3_2
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.x64.dll Versions 3.2"
		author = "gssincla@google.com"
		id = "61188243-0b90-5bff-bcc8-50f10ed941f6"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L1029-L1068"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "5993a027f301f37f3236551e6ded520e96872723a91042bfc54775dcb34c94a1"
		logic_hash = "3803aaac537aec0b188870177e510a3789a71c19be576569b59aa146b2ba62c5"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 4C 8D 05 9F F8 FF FF 8B D3 48 8B CF E8 05 1A 00 00
                     EB 0A 8B D3 48 8B CF E8 41 21 00 00 48 8B 5C 24 30
                     48 83 C4 20 }
		$decoder = { 80 31 ?? FF C2 48 FF C1 48 63 C2 48 3D 10 06 00 00 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_X64_V3_3
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.x64.dll Versions 3.3"
		author = "gssincla@google.com"
		id = "fb96ecff-809e-5704-974e-a2d8ef022daa"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L1070-L1109"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "7b00721efeff6ed94ab108477d57b03022692e288cc5814feb5e9d83e3788580"
		logic_hash = "514d491b8066ed7127ebb152a27efbe65e1121da3b5460afe6987920a91f2863"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 8B D3 48 8B CF E8 89 66 00 00 E9 23 FB FF FF 
                     41 B8 01 00 00 00 E9 F3 FD FF FF 48 8D 0D 2A F8 FF FF
                     E8 8D 2B 00 00 48 8B 5C 24 30 48 83 C4 20 }
		$decoder = { 80 31 ?? FF C2 48 FF C1 48 63 C2 48 3D 10 06 00 00 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_X64_V3_4
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.x64.dll Versions 3.4"
		author = "gssincla@google.com"
		id = "97ef152c-86c7-513c-a881-e7d594d38dcf"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L1111-L1148"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "5a4d48c2eda8cda79dc130f8306699c8203e026533ce5691bf90363473733bf0"
		logic_hash = "65aa42265133038f6f568c021c0228440e84e236829af50796a73f6923f46395"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 8B D3 48 8B CF E8 56 6F 00 00 E9 17 FB FF FF
                     41 B8 01 00 00 00 8B D3 48 8B CF E8 41 4D 00 00
                     48 8B 5C 24 30 48 83 C4 20 }
		$decoder = { 80 34 28 ?? 48 FF C0 48 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_X64_V3_5_Hf1_And_V3_5_1
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.x64.dll Versions 3.5-hf1 and 3.5.1"
		author = "gssincla@google.com"
		id = "0c0e87d3-e0e2-5ddc-9d89-5e56443da4b8"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L1150-L1189"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "934134ab0ee65ec76ae98a9bb9ad0e9571d80f4bf1eb3491d58bacf06d42dc8d"
		logic_hash = "5cd69554edb91956f4ec4c3c5e55f4cd9c3665656c318220ba3a270c0bb0a690"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 8B D3 48 8B CF E8 38 70 00 00 E9 FD FA FF FF 
                     41 B8 01 00 00 00 8B D3 48 8B CF E8 3F 4D 00 00 
                     48 8B 5C 24 30 48 83 C4 20 5F }
		$decoder = { 80 34 28 ?? 48 FF C0 48 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_X64_V3_6
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.x64.dll Versions 3.6"
		author = "gssincla@google.com"
		id = "9651a1ca-d8ea-5b0b-bcba-a850c2e07791"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L1191-L1233"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "92b0a4aec6a493bcb1b72ce04dd477fd1af5effa0b88a9d8283f26266bb019a1"
		logic_hash = "d6aff186a01386992f004cb775d280f9b6e7e16d7ecee662d61e3485b0bc088b"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 48 89 5C 24 08 57 48 83 EC 20 41 8B D8 48 8B FA 83 F9 27
                     0F 87 47 03 00 00 0F 84 30 03 00 00 83 F9 14
                     0F 87 A4 01 00 00 0F 84 7A 01 00 00 83 F9 0C
                     0F 87 C8 00 00 00 0F 84 B3 00 00 00 }
		$decoder = { 80 34 28 ?? 48 FF C0 48 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_X64_V3_7
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.x64.dll Versions 3.7"
		author = "gssincla@google.com"
		id = "27fad98a-2882-5c52-af6e-c7dcf5559624"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L1235-L1274"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "81296a65a24c0f6f22208b0d29e7bb803569746ce562e2fa0d623183a8bcca60"
		logic_hash = "89499e01acd607b2fbcdd134c74ca4a901c00c7c9cf70dd241cc538c1c0d083a"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 48 89 5C 24 08 57 48 83 EC 20 41 8B D8 48 8B FA 83 F9 28
                     0F 87 7F 03 00 00 0F 84 67 03 00 00 83 F9 15
                     0F 87 DB 01 00 00 0F 84 BF 01 00 00 }
		$decoder = { 80 34 28 ?? 48 FF C0 48 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_X64_V3_8
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.x64.dll Versions 3.8"
		author = "gssincla@google.com"
		id = "89809d81-9a8b-5cf3-a251-689bf52e98e0"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L1276-L1310"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "547d44669dba97a32cb9e95cfb8d3cd278e00599e6a11080df1a9d09226f33ae"
		logic_hash = "8845b71ce4401fd194eb88f04dbf1f313af8b4853da004e63261ca3158fcb1d4"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 8B D3 48 8B CF E8 7A 52 00 00 EB 0D 45 33 C0 8B D3 48 8B CF
                     E8 8F 55 00 00 }
		$decoder = { 80 34 28 ?? 48 FF C0 48 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_X64_V3_11
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.x64.dll Versions 3.11 (two subversions)"
		author = "gssincla@google.com"
		id = "bf0c7661-2583-5fca-beb5-abb2b50c860d"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L1312-L1366"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "64007e104dddb6b5d5153399d850f1e1f1720d222bed19a26d0b1c500a675b1a"
		logic_hash = "9c34b23b659463a0ab92949031a9b3246aa95256d1548b2f0ad53fe3d379997d"
		score = 75
		quality = 85
		tags = ""
		rs2 = "815f313e0835e7fdf4a6d93f2774cf642012fd21ce870c48ff489555012e0047"

	strings:
		$version_sig = { 48 83 EC 20 41 8B D8 48 8B FA 83 F9 2D 0F 87 B2 03 00 00
                     0F 84 90 03 00 00 83 F9 17 0F 87 F8 01 00 00
                     0F 84 DC 01 00 00 83 F9 0E 0F 87 F9 00 00 00
                     0F 84 DD 00 00 00 FF C9 0F 84 C0 00 00 00 83 E9 02
                     0F 84 A6 00 00 00 FF C9 }
		$decoder = {
      80 34 28 ?? 
      48 FF C0
      48 3D 00 10 00 00
      7C F1
    }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_X64_V3_12
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.x64.dll Versions 3.12"
		author = "gssincla@google.com"
		id = "6eeae9f4-96e0-5a98-a8dc-779c916cd968"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L1368-L1404"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "8a28b7a7e32ace2c52c582d0076939d4f10f41f4e5fa82551e7cc8bdbcd77ebc"
		logic_hash = "7457b20f2a7dc7e8c3317cedbcfccae30ecc8dc164188c0321f9485fdfab0f6e"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 8B D3 48 8B CF E8 F8 2E 00 00 EB 16 8B D3 48 8B CF
                     E8 00 5C 00 00 EB 0A 8B D3 48 8B CF E8 64 4F 00 00 }
		$decoder = { 80 34 28 ?? 48 FF C0 48 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_X64_V3_13
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.x64.dll Versions 3.13"
		author = "gssincla@google.com"
		id = "202eb8ea-7afb-515b-9306-67514abf5e55"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L1407-L1440"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "945e10dcd57ba23763481981c6035e0d0427f1d3ba71e75decd94b93f050538e"
		logic_hash = "81571a6c30802430d0df9980e005736d58464bde98c0889b48bf8d0c7e88d247"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 48 8D 0D 01 5B FF FF 48 83 C4 28 E9 A8 54 FF FF 8B D0
                     49 8B CA E8 22 55 FF FF }
		$decoder = { 80 34 28 ?? 48 FF C0 48 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Beacon_X64_V3_14
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.x64.dll Versions 3.14"
		author = "gssincla@google.com"
		id = "d69171e3-86f4-5187-8874-5eee2045f746"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L1442-L1477"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "297a8658aaa4a76599a7b79cb0da5b8aa573dd26c9e2c8f071e591200cf30c93"
		logic_hash = "87cf465154d4294eeda9cf99c6c160da80cfa8a65244bc083737c0c87163431d"
		score = 75
		quality = 85
		tags = ""
		rs2 = "39b9040e3dcd1421a36e02df78fe031cbdd2fb1a9083260b8aedea7c2bc406bf"

	strings:
		$version_sig = { 8B D0 49 8B CA 48 83 C4 28 E9 B1 1F 00 00 8B D0 49 8B CA
                     48 83 C4 28 }
		$decoder = { 80 34 28 ?? 48 FF C0 48 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Sleeve_Beacon_Dll_X86_V4_0_Suspected
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.x64.dll Versions 4.0 (suspected, not confirmed)"
		author = "gssincla@google.com"
		id = "28a735c4-87d1-5e14-9379-46a6fd0cdd2a"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L1480-L1515"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "55aa2b534fcedc92bb3da54827d0daaa23ece0f02a10eb08f5b5247caaa63a73"
		logic_hash = "0dbf6a75dc74f4c2a7604072a01e2dbaaee15f5e57c765f24138d85c248fb305"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 41 B8 01 00 00 00 8B D0 49 8B CA 48 83 C4 28 E9 D1 B3 FF FF
                     8B D0 49 8B CA 48 83 C4 28 E9 AF F5 FF FF 45 33 C0
                     4C 8D 0D 8D 70 FF FF 8B D0 49 8B CA E8 9B B0 FF FF }
		$decoder = { 80 34 28 ?? 48 FF C0 48 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Sleeve_Beacon_X64_V4_1_And_V_4_2
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.x64.dll Versions 4.1 and 4.2"
		author = "gssincla@google.com"
		id = "dc320d17-98fc-5df3-ba05-4d134129317e"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L1517-L1553"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "29ec171300e8d2dad2e1ca2b77912caf0d5f9d1b633a81bb6534acb20a1574b2"
		logic_hash = "9b262ec18f79ab5ae63ad26d3685af088b5feb2d66de6ad3ba584cafbe2ee221"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 83 F9 34 0F 87 8E 03 00 00 0F 84 7A 03 00 00 83 F9 1C 0F 87 E6 01 00 00
                     0F 84 D7 01 00 00 83 F9 0E 0F 87 E9 00 00 00 0F 84 CE 00 00 00 FF C9
                     0F 84 B8 00 00 00 83 E9 02 0F 84 9F 00 00 00 FF C9 }
		$decoder = { 80 34 28 ?? 48 FF C0 48 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Sleeve_Beacon_X64_V4_3
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.x64.dll Version 4.3"
		author = "gssincla@google.com"
		id = "572616c7-d1ec-5aa1-b142-4f2edf73737f"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L1555-L1590"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "3ac9c3525caa29981775bddec43d686c0e855271f23731c376ba48761c27fa3d"
		logic_hash = "0c8934e997583339145749a3167ac010d8c77b2ed878d2c999de68ec2a98101d"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 8B D0 49 8B CA 48 83 C4 28 E9 D3 88 FF FF
                     4C 8D 05 84 6E FF FF 8B D0 49 8B CA 48 83 C4 28 }
		$decoder = { 80 34 28 ?? 48 FF C0 48 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Sleeve_Beacon_X64_V4_4_V_4_5_And_V4_6
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.x64.dll Versions 4.4 through at least 4.6"
		author = "gssincla@google.com"
		id = "79b6bfd4-1e45-5bd9-ac5c-19eb176ce698"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L1593-L1628"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "3280fec57b7ca94fd2bdb5a4ea1c7e648f565ac077152c5a81469030ccf6ab44"
		logic_hash = "be0bbf58a176f8089924b3ce58268d906f49dde51d863524971e46f4bada43a3"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 8B D0 49 8B CA 48 83 C4 28 E9 83 88 FF FF
                     4C 8D 05 A4 6D FF FF 8B D0 49 8B CA 48 83 C4 28 }
		$decoder = { 80 34 28 ?? 48 FF C0 48 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Sleeve_Beacon_X64_V4_5_Variant
{
	meta:
		description = "Cobalt Strike's sleeve/beacon.x64.dll Versions 4.5 (variant)"
		author = "gssincla@google.com"
		id = "45715da9-8f16-5304-b216-1ca36c508c77"
		date = "2022-11-18"
		modified = "2023-12-04"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Beacon_Dll_All_Versions_MemEnabled.yara#L1630-L1665"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "8f0da7a45945b630cd0dfb5661036e365dcdccd085bc6cff2abeec6f4c9f1035"
		logic_hash = "31a108168489a24d1bc297d722741f3fd19abd1bed4c76d54967c73986d18123"
		score = 75
		quality = 85
		tags = ""

	strings:
		$version_sig = { 41 B8 01 00 00 00 8B D0 49 8B CA 48 83 C4 28 E9 E8 AB FF FF
                     8B D0 49 8B CA E8 1A EB FF FF 48 83 C4 28 }
		$decoder = { 80 34 28 ?? 48 FF C0 48 3D 00 10 00 00 7C F1 }

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Bind64_Bin_V2_5_Through_V4_X
{
	meta:
		description = "Cobalt Strike's resources/bind64.bin signature for versions v2.5 to v4.x"
		author = "gssincla@google.com"
		id = "a01e7bc3-40e9-5f87-8fd6-926972be273b"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Bind64_Bin_v2_5_through_v4_x.yara#L17-L109"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "5dd136f5674f66363ea6463fd315e06690d6cb10e3cc516f2d378df63382955d"
		logic_hash = "ba79abc5cfeaccb94699c0d85c16b2ddf6820bc148c0fd1c9b33c07222e36cb6"
		score = 75
		quality = 85
		tags = ""

	strings:
		$apiLocator = {
			48 [2]
			AC
			41 [2] 0D
			41 [2]
			38 ??
			75 ??
			4C [4]
			45 [2]
			75 ??
			5?
			44 [2] 24
			49 [2]
			66 [4]
			44 [2] 1C
			49 [2]
			41 [3]
			48 
		}
		$calls = {
			41 BA C2 DB 37 67
			FF D5
			48 [2]
			48 [2]
			41 BA B7 E9 38 FF
			FF D5
			4D [2]
			48 [2]
			48 [2]
			41 BA 74 EC 3B E1
			FF D5
			48 [2]
			48 [2]
			41 BA 75 6E 4D 61
		}

	condition:
		$apiLocator and $calls
}
rule GCTI_Cobaltstrike_Resources_Reverse64_Bin_V2_5_Through_V4_X
{
	meta:
		description = "Cobalt Strike's resources/reverse64.bin signature for versions v2.5 to v4.x"
		author = "gssincla@google.com"
		id = "966e6e4c-85e2-5c94-8245-25367802b7d2"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Reverse64_Bin_v2_5_through_v4_x.yara#L17-L99"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "d2958138c1b7ef681a63865ec4a57b0c75cc76896bf87b21c415b7ec860397e8"
		logic_hash = "c657234156293b9ac363b677490739ab0b5cc2ef149c9d9c37332dab9bb012f6"
		score = 75
		quality = 85
		tags = ""

	strings:
		$apiLocator = {
			48 [2]
			AC
			41 [2] 0D
			41 [2]
			38 ??
			75 ??
			4C [4]
			45 [2]
			75 ??
			5?
			44 [2] 24
			49 [2]
			66 [4]
			44 [2] 1C
			49 [2]
			41 [3]
			48 
		}
		$calls = {
			48 89 C1
			41 BA EA 0F DF E0
			FF D5
			48 [2]
			6A ??
			41 ??
			4C [2]
			48 [2]
			41 BA 99 A5 74 61
			FF D5
		}

	condition:
		$apiLocator and $calls
}
rule GCTI_Cobaltstrike_Resources__Template_Vbs_V3_3_To_V4_X
{
	meta:
		description = "Cobalt Strike's resources/btemplate.vbs signature for versions v3.3 to v4.x"
		author = "gssincla@google.com"
		id = "62f35d02-1e4e-5651-b575-888ce06b8bdd"
		date = "2022-11-18"
		modified = "2022-11-22"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Template_Vbs_v3_3_to_v4_x.yara#L17-L41"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "e0683f953062e63b2aabad7bc6d76a78748504b114329ef8e2ece808b3294135"
		logic_hash = "c9df0e287eb0eacf7c6cfcf3f6d1043ae6f2fdacd3b22bd42ac71f4b0d7226ff"
		score = 75
		quality = 83
		tags = ""

	strings:
		$ea = "Excel.Application" nocase
		$vis = "Visible = False" nocase
		$wsc = "Wscript.Shell" nocase
		$regkey1 = "HKEY_CURRENT_USER\\Software\\Microsoft\\Office\\" nocase
		$regkey2 = "\\Excel\\Security\\AccessVBOM" nocase
		$regwrite = ".RegWrite" nocase
		$dw = "REG_DWORD"
		$code = ".CodeModule.AddFromString"
		$ao = { 41 75 74 6f 5f 4f 70 65 6e }
		$da = ".DisplayAlerts"

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Template_X86_Vba_V3_8_To_V4_X
{
	meta:
		description = "Cobalt Strike's resources/template.x86.vba signature for versions v3.8 to v4.x"
		author = "gssincla@google.com"
		id = "11c7758e-93b2-5fe3-873d-b98de579d2b4"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Template_x86_Vba_v3_8_to_v4_x.yara#L17-L37"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "fc66cb120e7bc9209882620f5df7fdf45394c44ca71701a8662210cf3a40e142"
		logic_hash = "7114515477d82651806eccef34f599f6ffd4614f987dee29417ac6ef7a1a1c38"
		score = 75
		quality = 85
		tags = ""

	strings:
		$createstuff = "Function CreateStuff Lib \"kernel32\" Alias \"CreateRemoteThread\"" nocase
		$allocstuff = "Function AllocStuff Lib \"kernel32\" Alias \"VirtualAllocEx\"" nocase
		$writestuff = "Function WriteStuff Lib \"kernel32\" Alias \"WriteProcessMemory\"" nocase
		$runstuff = "Function RunStuff Lib \"kernel32\" Alias \"CreateProcessA\"" nocase
		$vars = "Dim rwxpage As Long" nocase
		$res = "RunStuff(sNull, sProc, ByVal 0&, ByVal 0&, ByVal 1&, ByVal 4&, ByVal 0&, sNull, sInfo, pInfo)"
		$rwxpage = "AllocStuff(pInfo.hProcess, 0, UBound(myArray), &H1000, &H40)"

	condition:
		all of them and @vars [ 1 ] < @res [ 1 ] and @allocstuff [ 1 ] < @rwxpage [ 1 ]
}
rule GCTI_Cobaltstrike_Resources_Bypassuactoken_X64_Dll_V3_11_To_V3_14
{
	meta:
		description = "Cobalt Strike's resources/bypassuactoken.x64.dll from v3.11 to v3.14 (64-bit version)"
		author = "gssincla@google.com"
		id = "c89befcd-a622-5947-9ce3-a6031901a45a"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Bypassuactoken_x64_Dll_v3_11_to_v3_14.yara#L17-L118"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "853068822bbc6b1305b2a9780cf1034f5d9d7127001351a6917f9dbb42f30d67"
		logic_hash = "adfd212f2e470f666ab8a2168e976c11d3032c31dab7cf56963dae5fc0f6c5f9"
		score = 75
		quality = 85
		tags = ""

	strings:
		$isHighIntegrityProcess = {
			83 ?? 7A
			75 ??
			8B [3]
			33 ??
			FF 15 [4]
			44 [4]
			8D [2]
			48 8B ??
			48 8D [3]
			48 8B ??
			4C 8B ??
			48 89 [3]
			FF 15 [4]
			85 C0
			74 ??
			48 8B ??
			FF 15 [4]
			8D [2]
			8A ??
			40 [2]
			0F B6 D1
			48 8B 0F
			FF 15 [4]
			81 ?? 00 30 00 00
		}
		$executeTaskmgr = {
			44 8D ?? 70
			48 8D [3]
			E8 [4]
			83 [3] 00
			48 8D [5]
			0F 57 ??
			66 0F 7F [3]
			48 89 [3]
			48 8D [5]
			48 8D [3]
			C7 [3] 70 00 00 00
			C7 [3] 40 00 00 00
			48 89 [3]
			FF 15 
		}

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Artifact32Svc_Exe_V3_1_V3_2_V3_14_And_V4_X
{
	meta:
		description = "Cobalt Strike's resources/artifact32svc(big).exe signature for versions 3.1 and 3.2 (with overlap with v3.14 through v4.x)"
		author = "gssincla@google.com"
		id = "732169be-e334-5774-b0ac-54b217a8b681"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Artifact32svc_Exe_v1_49_to_v4_x.yara#L53-L77"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "871390255156ce35221478c7837c52d926dfd581173818620b738b4b029e6fd9"
		logic_hash = "b55211fc2dbe100edb19c3f3a000be513144e3556c4bce8a29a3c0b77451ba96"
		score = 75
		quality = 85
		tags = ""

	strings:
		$decoderFunc = { 89 ?? B? 04 00 00 00 99 F7 FF 8B [2] 8A [2] 30 }

	condition:
		$decoderFunc
}
rule GCTI_Cobaltstrike_Resources_Reverse_Bin_V2_5_Through_V4_X
{
	meta:
		description = "Cobalt Strike's resources/reverse.bin signature for versions 2.5 to 4.x"
		author = "gssincla@google.com"
		id = "182dbcd0-1180-5516-abe3-cf2eebbd0e39"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Reverse_Bin_v2_5_through_v4_x.yara#L17-L104"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "887f666d6473058e1641c3ce1dd96e47189a59c3b0b85c8b8fccdd41b84000c7"
		logic_hash = "c6c4fc477c7654ec07eb6ef4c6d53805a9b4881ba288754e1f50b3e4b134333c"
		score = 75
		quality = 85
		tags = ""

	strings:
		$apiLocator = {
			31 ?? 
			AC
			C1 ?? 0D 
			01 ?? 
			38 ?? 
			75 ?? 
			03 [2]
			3B [2]
			75 ?? 
			5? 
			8B ?? 24 
			01 ?? 
			66 8B [2]
			8B ?? 1C 
			01 ?? 
			8B ?? 8B 
			01 ?? 
			89 [3]
			5? 
			5? 
		}
		$ws2_32 = {
			5D
			68 33 32 00 00
			68 77 73 32 5F
		}
		$connect = {
			6A 10
			5? 
			5? 
			68 99 A5 74 61
		}

	condition:
		$apiLocator and $ws2_32 and $connect
}
rule GCTI_Cobaltstrike_Resources_Dnsstager_Bin_V1_47_Through_V4_X
{
	meta:
		description = "Cobalt Strike's resources/dnsstager.bin signature for versions 1.47 to 4.x"
		author = "gssincla@google.com"
		id = "e1b0e368-9bcf-5d9b-b2b3-8414742f213e"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Dnsstager_Bin_v1_47_through_v4_x.yara#L17-L78"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "10f946b88486b690305b87c14c244d7bc741015c3fef1c4625fa7f64917897f1"
		logic_hash = "d4500d8a83a821e1df9e808b17a87c1207d78ea0e03886544a632176fe93ccd0"
		score = 75
		quality = 83
		tags = ""

	strings:
		$apiLocator = {
			31 ?? 
			AC
			C1 ?? 0D 
			01 ?? 
			38 ?? 
			75 ?? 
			03 [2]
			3B [2]
			75 ?? 
			5? 
			8B ?? 24 
			01 ?? 
			66 8B [2]
			8B ?? 1C 
			01 ?? 
			8B ?? 8B 
			01 ?? 
			89 [3]
			5? 
			5? 
		}
		$dnsapi = { 68 64 6E 73 61 }

	condition:
		$apiLocator and $dnsapi
}
rule GCTI_Cobaltstrike_Resources_Elevate_Dll_V3_0_To_V3_14_And_Sleeve_Elevate_Dll_V4_X
{
	meta:
		description = "Cobalt Strike's resources/elevate.dll signature for v3.0 to v3.14 and sleeve/elevate.dll for v4.x"
		author = "gssincla@google.com"
		id = "170f62a2-ba4f-5be8-9ec5-402eb7bbde4e"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Elevate_Dll_v3_0_to_v3_14_and_Sleeve_Elevate_Dll_v4_x.yara#L17-L68"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "6deeb2cafe9eeefe5fc5077e63cc08310f895e9d5d492c88c4e567323077aa2f"
		logic_hash = "766a0a390ed8cefe43d82a054a9b2cfec7eced75e0d7ee10231215043577b75e"
		score = 75
		quality = 85
		tags = ""

	strings:
		$wnd_proc = {
			6A 00
			6A 28
			68 00 01 00 00
			5? 
			C7 [5] 01 00 00 00 
			FF ?? 
			6A 00
			6A 27
			68 00 01 00 00
			5? 
			FF ?? 
			6A 00
			6A 00
			68 01 02 00 00
			5? 
			FF ?? 
		}

	condition:
		$wnd_proc
}
rule GCTI_Cobaltstrike_Resources_Bypassuac_Dll_V1_49_To_V3_14_And_Sleeve_Bypassuac_Dll_V4_0_To_V4_X
{
	meta:
		description = "Cobalt Strike's resources/bypassuac(-x86).dll from v1.49 to v3.14 (32-bit version) and sleeve/bypassuac.dll from v4.0 to at least v4.4"
		author = "gssincla@google.com"
		id = "614046b5-cf81-56a5-8824-b3a7e14a8ed5"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Bypassuac_Dll_v1_49_to_v3_14_and_Sleeve_Bypassuac_Dll_v4_0_to_v4_x.yara#L17-L94"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "91d12e1d09a642feedee5da966e1c15a2c5aea90c79ac796e267053e466df365"
		logic_hash = "7d59c0286f1936e386519a919472d01581b68a8167c89bd3cd3108d45251119a"
		score = 75
		quality = 85
		tags = ""

	strings:
		$deleteFileCOM = {
			A1 [4]
			6A 00
			8B ?? 
			5? 
			5? 
			FF ?? 48 
			85 ?? 
			75 ?? 
			A1 [4]
			5? 
			8B ?? 
			FF ?? 54 
		}
		$copyFileCOM = {
			A1 [4]
			6A 00
			FF [2]
			8B ?? 
			FF [5]
			FF [5]
			5? 
			FF ?? 40 
			85 ?? 
			[2 - 6]
			A1 [4]
			5? 
			8B ?? 
			FF ?? 54 
		}

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Template_Py_V3_3_To_V4_X
{
	meta:
		description = "Cobalt Strike's resources/template.py signature for versions v3.3 to v4.x"
		author = "gssincla@google.com"
		id = "16aef9a9-b217-5462-93dc-f6273c99ddd0"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Template_Py_v3_3_to_v4_x.yara#L17-L36"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "d5cb406bee013f51d876da44378c0a89b7b3b800d018527334ea0c5793ea4006"
		logic_hash = "3c26cea4b8f2b200bf58e939ae9ead7a7339d4ec0de8c72b3d9c7da897600081"
		score = 75
		quality = 85
		tags = ""

	strings:
		$arch = "platform.architecture()"
		$nope = "WindowsPE"
		$alloc = "ctypes.windll.kernel32.VirtualAlloc"
		$movemem = "ctypes.windll.kernel32.RtlMoveMemory"
		$thread = "ctypes.windll.kernel32.CreateThread"
		$wait = "ctypes.windll.kernel32.WaitForSingleObject"

	condition:
		all of them
}
rule GCTI_Cobaltstrike_Resources_Httpsstager64_Bin_V3_2_Through_V4_X
{
	meta:
		description = "Cobalt Strike's resources/httpsstager64.bin signature for versions v3.2 to v4.x"
		author = "gssincla@google.com"
		id = "c16e73fc-484a-5f7e-8127-d85a0254d842"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Httpsstager64_Bin_v3_2_through_v4_x.yara#L17-L90"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "109b8c55816ddc0defff360c93e8a07019ac812dd1a42209ea7e95ba79b5a573"
		logic_hash = "4889a23c1f2780044b9fb2a0207676d57e82e6c1275614b684a5a9cbe984b761"
		score = 75
		quality = 85
		tags = ""

	strings:
		$apiLocator = {
			48 [2]
			AC
			41 [2] 0D
			41 [2]
			38 ??
			75 ??
			4C [4]
			45 [2]
			75 ??
			5?
			44 [2] 24
			49 [2]
			66 [4]
			44 [2] 1C
			49 [2]
			41 [3]
			48 
		}
		$InternetSetOptionA = {
			BA 1F 00 00 00
			6A 00
			68 80 33 00 00
			49 [2]
			41 ?? 04 00 00 00
			41 ?? 75 46 9E 86
		}

	condition:
		$apiLocator and $InternetSetOptionA
}
rule GCTI_Cobaltstrike_Resources_Xor_Bin_V2_X_To_V4_X
{
	meta:
		description = "Cobalt Strike's resource/xor.bin signature for version 2.x through 4.x"
		author = "gssincla@google.com"
		id = "1754746c-3a42-5f7d-808a-ba2e1c0a270e"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Xor_Bin__32bit_v2_x_to_4_x.yara#L17-L36"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "211ccc5d28b480760ec997ed88ab2fbc5c19420a3d34c1df7991e65642638a6f"
		logic_hash = "ad662a263ede6c3ba964baf8abe4848ed1e994f2c236d4315cb60c1d51442620"
		score = 75
		quality = 85
		tags = ""

	strings:
		$stub52 = {fc e8 ?? ?? ?? ?? [1-32] eb 27 5? 8b ??    83 c? ?4 8b ??    31 ?? 83 c? ?4 5? 8b ??    31 ?? 89 ??    31 ?? 83 c? ?4 83 e? ?4 31 ?? 39 ?? 74 ?2 eb ea 5? ff e? e8 d4 ff ff ff}
		$stub56 = {fc e8 ?? ?? ?? ?? [1-32] eb 2b 5d 8b ?? ?? 83 c5 ?4 8b ?? ?? 31 ?? 83 c5 ?4 55 8b ?? ?? 31 ?? 89 ?? ?? 31 ?? 83 c5 ?4 83 e? ?4 31 ?? 39 ?? 74 ?2 eb e8 5? ff e? e8 d? ff ff ff}

	condition:
		any of them
}
rule GCTI_Cobaltstrike_Resources_Httpsstager_Bin_V2_5_Through_V4_X
{
	meta:
		description = "Cobalt Strike's resources/httpsstager.bin signature for versions 2.5 to 4.x"
		author = "gssincla@google.com"
		id = "f45aa40a-3936-50f9-a60e-de7181862d19"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Httpsstager_Bin_v2_5_through_v4_x.yara#L17-L95"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "5ebe813a4c899b037ac0ee0962a439833964a7459b7a70f275ac73ea475705b3"
		logic_hash = "d2f722809a59faf8ecd85e46eadf58bf23ba5f515ad9c949843f1e6bfeec1fbf"
		score = 75
		quality = 85
		tags = ""

	strings:
		$apiLocator = {
			31 ?? 
			AC
			C1 ?? 0D 
			01 ?? 
			38 ?? 
			75 ?? 
			03 [2]
			3B [2]
			75 ?? 
			5? 
			8B ?? 24 
			01 ?? 
			66 8B [2]
			8B ?? 1C 
			01 ?? 
			8B ?? 8B 
			01 ?? 
			89 [3]
			5? 
			5? 
		}
		$InternetSetOptionA = {
			6A 04
			5? 
			6A 1F
			5? 
			68 75 46 9E 86
			FF  
		}

	condition:
		$apiLocator and $InternetSetOptionA
}
rule GCTI_Cobaltstrike_Resources_Bypassuac_X64_Dll_V3_3_To_V3_14_And_Sleeve_Bypassuac_X64_Dll_V4_0_And_V4_X
{
	meta:
		description = "Cobalt Strike's resources/bypassuac-x64.dll from v3.3 to v3.14 (64-bit version) and sleeve/bypassuac.x64.dll from v4.0 to at least v4.4"
		author = "gssincla@google.com"
		id = "eef83901-63d9-55a3-b115-03f420416177"
		date = "2022-11-18"
		modified = "2022-11-19"
		reference = "https://cloud.google.com/blog/products/identity-security/making-cobalt-strike-harder-for-threat-actors-to-abuse"
		source_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/YARA/CobaltStrike/CobaltStrike__Resources_Bypassuac_x64_Dll_v3_3_to_v3_14_and_Sleeve_Bypassuac_x64_Dll_v4_0_and_v4_x.yara#L17-L86"
		license_url = "https://github.com/chronicle/GCTI/blob/1c5fd42b1895098527fde00c2d9757edf6b303bb/LICENSE"
		hash = "9ecf56e9099811c461d592c325c65c4f9f27d947cbdf3b8ef8a98a43e583aecb"
		logic_hash = "d76e3601f61ae164a8df9048d59d15cd6913e64adb93132244e83f40bf67d86a"
		score = 75
		quality = 85
		tags = ""

	strings:
		$deleteFileCOM = {
			48 8B [5]
			45 33 ??
			48 8B ??
			FF 90 90 00 00 00
			85 C0
			75 ??
			48 8B [5]
			48 8B ??
			FF 92 A8 00 00 00
			85 C0
		}
		$copyFileCOM = {
			48 8B [5]
			4C 8B [5]
			48 8B [5]
			48 8B ??
			4C 8B ??
			48 89 [3]
			FF 90 80 00 00 00
			85 C0
			0F 85 [4]
			48 8B [5]
			48 8B 11
			FF 92 A8 00 00 00
		}

	condition:
		all of them
}
