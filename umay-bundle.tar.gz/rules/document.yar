/*
    Umay heuristics: documents and web pages used to deliver malware.

    Office files are ZIP containers; the engine unpacks them and scans each
    part, so these rules see `vbaProject.bin` (an OLE2 stream) and the XML
    relationship files individually.
*/

rule PDF_AutoRunScript
{
    meta:
        umay_name = "Heur.PDF.AutoRunScript"
        umay_weight = 25
        description = "Runs JavaScript automatically when the document is opened"
    strings:
        $js1 = "/JavaScript" ascii
        $js2 = "/JS" ascii
        $auto1 = "/OpenAction" ascii
        $auto2 = "/AA" ascii
    condition:
        umay_kind == "pdf" and any of ($js*) and any of ($auto*)
}

rule PDF_LaunchAction
{
    meta:
        umay_name = "Heur.PDF.LaunchesProgram"
        umay_weight = 45
        description = "Tells the PDF reader to start an external program"
    strings:
        $launch = "/Launch" ascii
        $t1 = "cmd.exe" nocase ascii
        $t2 = "powershell" nocase ascii
        $t3 = "mshta" nocase ascii
        $t4 = /\.(exe|bat|cmd|vbs|js|scr|hta)\b/ nocase ascii
        $t5 = "/bin/sh" ascii
    condition:
        umay_kind == "pdf" and $launch and any of ($t*)
}

rule PDF_ObfuscatedNames
{
    meta:
        umay_name = "Heur.PDF.ObfuscatedNames"
        umay_weight = 40
        description = "Spells action names with hex escapes, which only serves to defeat scanners"
    strings:
        $js = /\/J(a|#61)(v|#76)(a|#61)S(c|#63)(r|#72)(i|#69)(p|#70)(t|#74)/ ascii
        $js_plain = "/JavaScript" ascii
        $open = /\/O(p|#70)(e|#65)(n|#6[eE])A(c|#63)(t|#74)(i|#69)(o|#6[fF])(n|#6[eE])/ ascii
        $open_plain = "/OpenAction" ascii
        $launch = /\/L(a|#61)(u|#75)(n|#6[eE])(c|#63)(h|#68)/ ascii
        $launch_plain = "/Launch" ascii
    condition:
        umay_kind == "pdf"
        and (#js > #js_plain or #open > #open_plain or #launch > #launch_plain)
}

rule Office_AutoExecMacro
{
    meta:
        umay_name = "Heur.Office.AutoExecMacro"
        umay_weight = 45
        description = "Macro that starts by itself when the document opens and can run programs or download files"
    strings:
        $auto1 = "AutoOpen" nocase ascii wide
        $auto2 = "Auto_Open" nocase ascii wide
        $auto3 = "Document_Open" nocase ascii wide
        $auto4 = "Workbook_Open" nocase ascii wide
        $auto5 = "AutoExec" nocase ascii wide
        $auto6 = "Document_Close" nocase ascii wide
        $act1 = "WScript.Shell" nocase ascii wide
        $act2 = "ShellExecute" nocase ascii wide
        $act3 = "powershell" nocase ascii wide
        $act4 = "cmd.exe" nocase ascii wide
        $act5 = "URLDownloadToFile" nocase ascii wide
        $act6 = "MSXML2.XMLHTTP" nocase ascii wide
        $act7 = "WinHttp.WinHttpRequest" nocase ascii wide
        $act8 = "CreateObject" nocase ascii wide
        $act9 = "ADODB.Stream" nocase ascii wide
    condition:
        umay_kind == "ole2" and any of ($auto*) and 2 of ($act*)
}

rule Office_EquationEditorObject
{
    meta:
        umay_name = "Heur.Office.EquationEditorObject"
        umay_weight = 45
        description = "Embeds a legacy Equation Editor object, a component with long-exploited memory-corruption bugs"
    strings:
        $clsid = { 02 CE 02 00 00 00 00 00 C0 00 00 00 00 00 00 46 }
        $clsid_hex = "0002ce020000000000c0000000000046" nocase ascii
        $progid = "Equation.3" nocase ascii wide
    condition:
        (umay_kind == "ole2" or umay_kind == "rtf") and any of them
}

rule RTF_AutoUpdatingObject
{
    meta:
        umay_name = "Heur.RTF.AutoUpdatingObject"
        umay_weight = 30
        description = "Embedded object that is loaded automatically when the document opens"
    strings:
        $update = "\\objupdate" ascii
        $data = "\\objdata" ascii
        $ocx = "\\objocx" ascii
        $emb = "\\objemb" ascii
    condition:
        umay_kind == "rtf" and $update and $data and ($ocx or $emb)
}

rule Office_RemoteTemplate
{
    meta:
        umay_name = "Heur.Office.RemoteTemplate"
        umay_weight = 50
        description = "Loads its template from a web address, pulling in macros the file itself does not contain"
    strings:
        $type = "relationships/attachedTemplate" ascii
        $target = /Target\s*=\s*"https?:\/\// nocase ascii
        $external = /TargetMode\s*=\s*"External"/ nocase ascii
    condition:
        filesize < 1MB and all of them
}

rule Office_DdeCommand
{
    meta:
        umay_name = "Heur.Office.DdeCommand"
        umay_weight = 50
        description = "Field that runs a command through DDE when the document opens"
    strings:
        // Only DDE written as a field: DDEAUTO, "{ DDE", or the field
        // markup of Word XML and RTF. Prose that mentions DDE does not match.
        $dde = /(DDEAUTO|\{\s*DDE|instrText[^>]{0,40}>\s*DDE|fldinst[^}]{0,20}DDE)\s+["']?[^<"']{0,80}\b(cmd|powershell|mshta|wscript|cscript|certutil|regsvr32)(\.exe)?\b/ nocase ascii
    condition:
        filesize < 5MB and (umay_kind == "text" or umay_kind == "html" or umay_kind == "rtf" or umay_kind == "unknown" or umay_derived) and $dde
}

rule HTML_FileSmuggling
{
    meta:
        umay_name = "Heur.HTML.FileSmuggling"
        umay_weight = 35
        description = "Page that assembles a file inside the browser and saves it, so no download passes network filters"
    strings:
        $blob = "new Blob" ascii
        $dec1 = "atob(" ascii
        $dec2 = "Uint8Array" ascii
        $save1 = "msSaveOrOpenBlob" ascii
        $save2 = /\.download\s*=/ ascii
        $save3 = "createObjectURL" ascii
        $click = /\.click\s*\(\s*\)/ ascii
    condition:
        umay_kind == "html" and filesize < 20MB and filesize > 30KB
        and $blob and any of ($dec*) and any of ($save*) and $click
}

rule HTML_ScriptHostDropper
{
    meta:
        umay_name = "Heur.HTML.ScriptHostDropper"
        umay_weight = 45
        description = "HTML application that drives the Windows shell from embedded script"
    strings:
        $hta = "<hta:application" nocase ascii wide
        $vbs = /<script[^>]{0,60}vbscript/ nocase ascii wide
        $shell = "WScript.Shell" nocase ascii wide
        $run1 = /\.Run\s*\(?/ nocase ascii wide
        $run2 = "ShellExecute" nocase ascii wide
        $run3 = "powershell" nocase ascii wide
    condition:
        (umay_kind == "html" or umay_kind == "script") and filesize < 5MB
        and ($hta or $vbs) and $shell and any of ($run*)
}
