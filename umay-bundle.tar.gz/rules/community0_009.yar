import "dotnet"
import "hash"
import "pe"

rule SEKOIA_Hacktool_Win_Cookiekatz : FILE
{
	meta:
		description = "Finds ChromeKatz (CookieKatz version) standalone samples based on the strings"
		author = "Sekoia.io"
		id = "a32769bb-4ec4-46c7-9402-21afdf8d4293"
		date = "2024-10-30"
		modified = "2024-12-19"
		reference = "https://github.com/Meckazin/ChromeKatz"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_win_cookiekatz.yar#L1-L36"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "fef9fc33a788489af44b2f732c450d4ef018fbaced7f5471230b282dfd6f1169"
		logic_hash = "a030f551d0f3dedf0f19e22b415aa87dd1c43ab2242db8b5cad14ae6b7695b3a"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "CookieKatz.exe" ascii
		$str02 = "--utility-sub-type=network.mojom.NetworkService" wide
		$str03 = "chrome.dll" wide
		$str04 = "msedge.dll" wide
		$str05 = "msedgewebview2.exe" wide
		$str06 = "Failed to read cookie struct" wide
		$str07 = "Failed to read the root node from given address" wide
		$str08 = "Error reading left node" wide
		$str09 = "By Meckazin" ascii
		$str10 = "By default targets first available Chrome process" ascii
		$str11 = "Kittens love cookies too!" ascii
		$str12 = "Attempting to read the cookie value from address: 0x%p" ascii
		$str13 = "szCookieMonster" ascii
		$str14 = "[*] Targeting Chrome" ascii
		$str15 = "[*] Targeting Edge" ascii
		$str16 = "[*] This Cookie map was empty" ascii
		$str17 = "[+] Found browser process: %d" ascii wide
		$str18 = "[*] Targeting process PID: %d" wide
		$str19 = "[*] Found CookieMonster on 0x%p" wide
		$str20 = "[*] CookieMap should be found in address 0x%p" wide

	condition:
		uint16( 0 ) == 0x5A4D and 8 of them
}
rule SEKOIA_Tool_Safetykatz : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "90f93244-38a7-4574-87c6-15d494e9173b"
		date = "2023-06-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_safetykatz.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f443dd5be1e15f8385427d965f8c8476c5f1b57b7c9ab53d9e13eb47735e09d3"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "SafetyKatz" ascii fullword
		$s2 = "get_mimikatz" ascii fullword
		$s3 = "$8347e81b-89fc-42a9-b22c-f59a6a572dec" ascii fullword

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 1MB and all of them
}

rule SEKOIA_Backdoor_Win_Headertip : FILE
{
	meta:
		description = "Detect HeaderTip backdoor used by the Chinese threat actor Scarab. This backdoor has its hardcoded C2 in strings"
		author = "Sekoia.io"
		id = "82899406-4ec3-41d2-bcc1-bdd1ee440e77"
		date = "2022-03-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_win_headertip.yar#L4-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "e1523185eac41a615b8d2af8b7fd5fe07b755442df2836041be544dff6881237"
		hash = "da8a98d9b9a3c176ba44fb69ad0a820a971950e05f1eb0c4bbbf6c2fbb748bdc"
		hash = "63a218d3fc7c2f7fcadc0f6f907f326cc86eb3f8cf122704597454c34c141cf1"
		logic_hash = "289764df590cd2719d4d4e0dd66f7d8ebb4714d42eea4bb76c47a2b867a113de"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$post = "POST" wide
		$ua = "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko" wide

	condition:
		( uint16( 0 ) == 0x5A4D and $post at 7256 and $ua at 7304 and filesize < 10KB ) or pe.imphash ( ) == "60d01115d6baa0f214990c6e19339133" or hash.md5 ( pe.rich_signature.clear_data ) == "48f9cf422144c033e2ca183f72587910"
}
rule SEKOIA_Apt_Ta428_Tmanger_Strings : FILE
{
	meta:
		description = "Detects Tmanger malware"
		author = "Sekoia.io"
		id = "f600404d-3f93-4e3f-bba7-9f519f67c6cb"
		date = "2022-09-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_ta428_tmanger_strings.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e045f38367fa7f3cdcc908e60de4386889c7878c95b1a40f63fd70683699b0f1"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "sock_hmutex" wide ascii
		$ = "cmd_hmutex" wide ascii
		$ = "%s_%d.bmp" wide ascii
		$ = "WSAStartup Error!" wide ascii
		$ = "4551-8f84-08e738aec" wide ascii
		$ = "Init failed!" wide ascii
		$ = "GetLanIP error!" wide ascii
		$ = "chcp & exit" wide ascii
		$ = "GetHostname error!" wide ascii
		$ = "[Num Lock]" wide ascii

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 200KB and 4 of them
}
rule SEKOIA_Recotool_Adfind_Strings : FILE
{
	meta:
		description = "Detects Adfind utility based on strings"
		author = "Sekoia.io"
		id = "afca88ef-756a-4b2b-91d7-d18d730e7074"
		date = "2022-02-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/recotool_adfind_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "cc1e1dceff28136082f19cebc7584ba08c9006b964e37fc3fda91bc0b41906dc"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Find all person objects on cn=ab container of local ADAM instance"
		$ = "IPv6 IP address w/ port is specified [address]:port"
		$ = "Search Global Catalog (port 3268)."
		$ = "~~~ADCSV~~~"
		$ = "adfind -b dc="

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 5MB and 4 of them
}
rule SEKOIA_Generic_Sharpshooter_Payload_8 : FILE
{
	meta:
		description = "Detects payload created by SharpShooter"
		author = "Sekoia.io"
		id = "e28a1cd3-f7b6-4a55-8229-484e0bbeb7cb"
		date = "2023-02-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/generic_sharpshooter_payload_8.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "71e4eb41968818e1dd484a259af9eec30a517423b00da75ce21773bf695cbc7d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Private Function decodeHex(hex)"
		$ = "Dim serialized_obj"
		$ = "decodeHex = EL.NodeTypedValue"
		$ = "d.DynamicInvoke(al.ToArray()).CreateInstance(entry_class)"

	condition:
		all of them and filesize < 2MB
}
rule SEKOIA_Tool_Xiebroc2_Strings
{
	meta:
		description = "Detects XiebroC2 based on strings"
		author = "Sekoia.io"
		id = "8451878e-5371-440b-b8ac-f9e6f7643d3c"
		date = "2024-09-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_xiebroc2_strings.yar#L1-L40"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "84e665bcbf963a2cf67d879aa3422d79"
		hash = "3558c376420724694ba244a2e2acd20c"
		hash = "e29fb9cd825db51a7a2e519f188e61ba"
		hash = "a3b31739ad5eed51277c8478a83160a3"
		hash = "d6e2499ea7fe8f047da1a95dae16d2c3"
		hash = "1616818b65bf49d985bb1816461a4a75"
		hash = "2e72d3ef2492088a4623d77d5e419ab8"
		hash = "351770f860507d652ec3644ed1988f7f"
		hash = "58fa6ad96028753ba8b0b0ed8fa6dccb"
		hash = "607b541525b27eeefbef1455397bff35"
		hash = "c2a242612468814e2e951e4db3762059"
		hash = "431e275f4e43ec4ef7c2cc8ba126e9d3"
		hash = "ace54bd32c226a7b9a6d4d53791e4021"
		hash = "f22c21ed7bba1ddfc42ffdc66da3a4dd"
		hash = "9a5ff9e07ed04cb0e71102cf1aae380c"
		hash = "d20e01a1af3f40a7a9646d7e7df1b42e"
		hash = "5544b621c9772cd32c4db77a0e59515a"
		logic_hash = "f3be31e0f1ad8e8bce132d861de5068340653547d786378f9b8045382f40939f"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "RemarkClientColor"
		$s2 = "HandlePacket"
		$s3 = "-hide"
		$s4 = "Failed to send data:"
		$s5 = "Pac_ket"
		$s6 = "WANip"
		$s7 = "%s %s && Kernel: %s"
		$g1 = "go.buildid"
		$g2 = "dep    golang.org"

	condition:
		3 of ( $s* ) and any of ( $g* )
}

rule SEKOIA_Implant_Win_Sliver_Dll : FILE
{
	meta:
		description = "Detect the Sliver DLL based on export names (standalone and process/memory dumps)"
		author = "Sekoia.io"
		id = "41d83011-a08b-4245-b633-79fe6afaa4d2"
		date = "2021-11-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_win_sliver_dll.yar#L3-L32"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "251a123fe70338d18c9bc9fb9e0b0d542f2b94203bee8537244e62fa102f371b"
		score = 75
		quality = 80
		tags = "FILE"
		modification_date = "2021-12-22"
		version = "1.1"
		classification = "TLP:CLEAR"

	strings:
		$a1 = "main.RunSliver"
		$a2 = "main.DllInstall"

	condition:
		( filesize > 8MB and filesize < 11MB and uint16be( 0 ) == 0x4d5a and pe.characteristics & pe.DLL and pe.exports ( "RunSliver" ) and pe.exports ( "DllInstall" ) and pe.exports ( "VoidFunc" ) ) or ( true and ( uint32be( 0 ) == 0x4d444d50 or uint32be( 0 ) == 0x00000000 ) and $a2 in ( @a1 .. @a1 + 100 ) )
}
rule SEKOIA_Apt_Apt37_Chinotto_Powershell_Variant
{
	meta:
		description = "Detects APT37 Chinotto Powershell Variant"
		author = "Sekoia.io"
		id = "fa42b225-58fe-4e00-b84b-df37491d8fdd"
		date = "2023-03-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt37_chinotto_powershell_variant.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b4d17467f15d52bd615e335fa8bc31381ec273b67dabb74655f47179f04f631f"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "$env:COMPUTERNAME + '-' + $env:USERNAME;" ascii wide
		$ = "while($true -eq $true)" ascii wide
		$ = "Start-Sleep -Seconds" ascii wide
		$ = " -ne 'null' -and $" ascii wide
		$ = "= 'R=' + [System.Convert]::" ascii wide
		$ = "[string]$([char]0x0D) + [string]$([char]0x0A);" ascii wide

	condition:
		4 of them
}
rule SEKOIA_Apt_Flightnight_Malicious_Lnk : FILE
{
	meta:
		description = "Detects malicious LNK used by FlightNight"
		author = "Sekoia.io"
		id = "06f33ece-ac9f-4dd3-98fb-cd69305ee995"
		date = "2024-04-02"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_flightnight_malicious_lnk.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "3446852709fe425b2c053ffdb9c078cf20e442ef50fe20402d3b4c9e9d8b543a"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s0 = "/c start /B " wide
		$s1 = ".exe &" wide
		$s2 = ".pdf" wide
		$s3 = "%CD%" wide

	condition:
		uint32be( 0 ) == 0x4c000000 and $s1 in ( @s0 .. @s2 ) and $s1 in ( @s0 .. @s0 + 100 ) and $s3
}
rule SEKOIA_Apt_Sandworm_Notpetya_Strings : FILE
{
	meta:
		description = "Detects NotPetya worm"
		author = "Sekoia.io"
		id = "c6021638-1b59-4d20-a29d-95cabf256a28"
		date = "2022-04-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_sandworm_notpetya_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5600071de4b4022a71c48fbcd4b5e47ff6dfa291cc5eac65720bbf763068a6e3"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "wevtutil cl Security &" wide
		$ = "wevtutil cl System &" wide
		$ = "u%s \\%s -accepteula -s" wide
		$ = "\\\\%ws\\admin$\\%ws" wide
		$ = "\\\\%s\\admin$" wide
		$ = "C:\\Windows\\System32\\rundll32.exe \"C:\\Windows\\%s\",#1" wide

	condition:
		uint16be( 0 ) == 0x4d5a and 3 of them
}
rule SEKOIA_Vpn_Mul_Softether
{
	meta:
		description = "Detect the open-source SoftEther VPN"
		author = "Sekoia.io"
		id = "a1fbf4fe-b934-4a66-b6b1-ebe2f83505cd"
		date = "2024-04-15"
		modified = "2024-12-19"
		reference = "https://www.softether.org/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/vpn_mul_softether.yar#L1-L29"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f93e838631518590e518f29557c60a40734da30b62c056f8ebb8febed389551b"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\softether_se%s"
		$ = "GET /vgc_download_dat/ HTTP/1.1"
		$ = "http://x%c.x%c.client.api.vpngate2.jp/api/"
		$ = "http://x0.x0.client.api.vpngate2.jp/check/check.txt"
		$ = "https://x%c.x%c.statistics.api.vpngate2.jp/api/statistics/"
		$ = "Software\\SoftEther Project\\SoftEther VPN\\"
		$ = "|vpnsetup_nosign.exe" wide
		$ = "/ISEASYINSTALLER:%u" wide
		$ = "/CALLERSFXPATH:\"%s\"" wide
		$ = "vpn_client.config" wide
		$ = "vpn_bridge.config" wide
		$ = "|backup_dir_readme.txt" wide
		$ = "vpn_debuginfo_%04u%02u%02u_%02u%02u%02u.zip" wide

	condition:
		8 of them
}
rule SEKOIA_Apt_Sidecopy_Actionrat_Packer_Strings : FILE
{
	meta:
		description = "Detects SideCopy's ActionRAT (packer?)"
		author = "Sekoia.io"
		id = "b9370bd5-12e1-448e-a5b1-2acc72adc4a7"
		date = "2023-05-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_sidecopy_actionrat_packer_strings.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "1bb6896ac3efa0e43cc27f56d7324ab9bdd2c401941eeefc4e7be62b407657af"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "(HTTP/1\\.[01]) (\\d{3})(?: (.*?))?"
		$ = "cpp-httplib/0.7"
		$ = "\\HTTP Arsanel\\"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and all of them
}

rule SEKOIA_Backdoor_Win_Blackrat : FILE
{
	meta:
		description = "Detect Andariel's Black RAT malware"
		author = "Sekoia.io"
		id = "3a5a6290-6344-45ce-8929-ea5a4451840f"
		date = "2023-09-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_win_blackrat.yar#L4-L33"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "c2500a6e12f22b16e221ba01952b69c92278cd05632283d8b84c55c916efe27c"
		logic_hash = "4edf1335e357ebc02e4abb51cd8d808ae39e649cf19cdb3ec667c9cf313181a9"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "I:/01___Tools/02__RAT/Black/Client_Go/Client.go"
		$s2 = "I:/01___Tools/02__RAT/Black/Client_Go/Define.go"
		$s3 = "I:/01___Tools/02__RAT/Black/Client_Go/Screenshot.go"
		$x1 = "RAT/Black/Client"

	condition:
		uint16be( 0 ) == 0x4d5a and ( all of ( $s* ) or #x1 >= 3 ) or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "74c4cdc9d33fc63aee7ae9659b6f8d24" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "298948afbe85985025e176605ee21176" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "e5ca54c5def3c7a950e6d4034dc86277" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "440ae899aea859458df5b6de7dbc5b34" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "98e46f76b965ffb58f6cd53ff8dc91c0" )
}
rule SEKOIA_Apt_Uac0154_Malicious_Html_Smuggling : FILE
{
	meta:
		description = "UAC-0154 Infection chain"
		author = "Sekoia.io"
		id = "923d11e5-6332-456d-8aff-ae7fb76193a8"
		date = "2023-10-02"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_uac0154_malicious_html_smuggling.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ba37b076ac29edcb9af7792420b527b0d64e7838e0237b39afe98a817eafdf7e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Microsoft&reg; HTML Help Workshop 4.1"
		$ = "var a=['"
		$ = ")+b('0x"

	condition:
		all of them and filesize < 100KB
}
rule SEKOIA_Apt_Cloudatlas_Powershower_Variant : FILE
{
	meta:
		description = "Detects PowerShower"
		author = "Sekoia.io"
		id = "416d0cb0-bc59-47ae-8a98-d7b39f8108ab"
		date = "2023-12-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_cloudatlas_powershower_variant.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "7bcfafd5a52d685fe33715c8c3725d95947c65863902fde05cf85685a6bfeab8"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "[System.Text.Encoding]::" ascii wide
		$s2 = "{8}{9}{10}{11}{12}{13}{14}{15}{16}{17}{18}{19}{20}" ascii wide

	condition:
		filesize < 10KB and all of them
}
rule SEKOIA_Guloader_Lnk_File : FILE
{
	meta:
		description = "LNK file delivering Guloader"
		author = "Sekoia.io"
		id = "ecc07753-0910-445b-bf84-911b17195894"
		date = "2024-02-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/guloader_lnk_file.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "d69038a8b26c7fc7ba7b0968c7c91b589b25512dcf7e3ad5ee56453a4654a1ab"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "$PSHOME" wide
		$s2 = "&(${" wide
		$s3 = "}::ToString(" wide
		$s4 = "$([TYPE]${" wide

	condition:
		uint32be( 0 ) == 0x4c000000 and all of them
}
rule SEKOIA_Loader_Win_Piccassoloader : CVE_2023_38831
{
	meta:
		description = "Detect the variant of Picasso used by GhostWriter as CVE-2023-38831 exploitation payload"
		author = "Sekoia.io"
		id = "91d9c2de-451e-467e-8f5c-38bbcce92b72"
		date = "2023-09-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_piccassoloader.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "93e598f6c70dcb1ddf20ea926af72241e135bdf910f3721a7a0c3036f6a3d1b9"
		score = 75
		quality = 76
		tags = "CVE-2023-38831"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = {2c 27 44 65 63 72 79 70 74 6f 72 27 2c 27 6e 6f 64 65 27 2c 27 55 73 65 72 2d}
		$ = {5c 78 32 30 43 68 72 6f 6d 65 2f 31 30 27 2c 27 67 67 65 72 27 2c 27 73 65 64 43 69 70 68 65 72 27 2c 27 5f 61 70 70 65 6e 64 27 2c 27 5f 45 4e 43 5f 58 46 4f 52 4d 27 2c 27 57 53 63 72 69 70 74 2e 53 68 27}

	condition:
		1 of them
}
rule SEKOIA_Apt_Gamaredon_Gammaload_Malicioushta : FILE
{
	meta:
		description = "Detects Gamaredon's GammaLoad HTA"
		author = "Sekoia.io"
		id = "e5e502db-7f37-40f2-9ba3-81e158e767db"
		date = "2022-08-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gamaredon_gammaload_malicioushta.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e41ce63e7c6df2edb548ddc57d51af914dab9200e37eb12463169d587205aa7a"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "platform = window.navigator?.userAgentData?.platform" ascii fullword
		$s2 = "'Win32', 'Win64', 'Windows', 'WinCE'" ascii
		$s3 = "dcreate.download ="
		$s4 = "dcreate.href = 'data:application/x-rar-compressed;base64"
		$s5 = "= \"UmFyI"

	condition:
		uint32be( 0 ) == 0x3c68746d and filesize < 400KB and filesize > 50KB and 4 of them
}
rule SEKOIA_Crypter_Win_Dotrunpex : FILE
{
	meta:
		description = "Detect the dotRunpeX crypter based on strings"
		author = "Sekoia.io"
		id = "6fb4ffe0-3a5c-432c-8ae2-404bb5960c30"
		date = "2023-06-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/crypter_win_dotrunpex.yar#L1-L15"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8a2b9e19b49ba17f976241bec5323121ba13d2ce39fdcf2777fd97a230211e75"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = {52 00 75 00 6e 00 70 00 65 00 58 00 2e 00 53 00 74 00 75 00 62 00 2e 00 46 00 72 00 61 00 6d 00 65 00 77 00 6f 00 72 00 6b 00 2e 00 65 00 78 00 65}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule SEKOIA_Infostealer_Win_Doenerium_Str : FILE
{
	meta:
		description = "Detect the Doenerium infostealer based on specific strings"
		author = "Sekoia.io"
		id = "1645a86f-1063-4e98-a1fa-85fc8c4e9691"
		date = "2022-09-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_doenerium_str.yar#L1-L29"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "9bc28d89ad2654c33f2ecd9736f5fb3a10dfc68dfef44ece6e628f5bb8db0800"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "doenerium" ascii
		$str02 = "<================[   User Info   ]>================>" ascii
		$str03 = "<================[WiFi connections]>================>" ascii
		$str04 = "<================[Executable Info]>================>" ascii
		$str05 = "<================[ Network Data ]>================>" ascii
		$str06 = "\\Network Data.txt" ascii
		$str07 = "\\Update.exe\" --processStart" ascii
		$str09 = "\\WiFi Connections.txt" ascii
		$str10 = "\\User Info.txt" ascii
		$str11 = "\\Executable Info.txt" ascii
		$str12 = "\\Found Wallets.txt" ascii
		$str13 = "SELECT origin_url, username_value, password_value FROM logins" ascii
		$str14 = "https://cdn.discordapp.com/embed/avatars/0.png" ascii
		$str15 = "detectClipboard" ascii
		$str16 = ".gofile.io/uploadFile" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 6 of them
}
rule SEKOIA_Implant_Mul_Alchimist : FILE
{
	meta:
		description = "Detect the Alchimist implant based on strings"
		author = "Sekoia.io"
		id = "66330cc6-a7da-4717-9977-0cede48f46f5"
		date = "2022-10-18"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_mul_alchimist.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "d4a5338c502b145a1d7ad9f35779e24d66ee2d11bf760d498aab39e2c62fbeb4"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "POST /users/loginpage.html HTTP/1.1" ascii
		$str02 = "pm3/apps/Insekt/main.go" ascii
		$str03 = "generate new insekt err" ascii
		$str04 = "[SHELLCODE][filesize]:[scan]" ascii
		$str05 = "\\Device\\NamedPipe\\cygwinbad" ascii
		$str06 = "pm3/utils.GetTmpDir" ascii
		$str07 = "os/exec.Command" ascii

	condition:
		( uint16( 0 ) == 0x5A4D or uint32( 0 ) == 0x464C457F ) and 5 of them
}
rule SEKOIA_Apt_Reaper_Malicious_Lnk : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "8f055d1b-5727-4d77-9671-cdbb1ea69d5f"
		date = "2023-09-12"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_reaper_malicious_lnk.yar#L1-L15"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8cec5819dd7b01b3993acae056f5640fa28ffe76b05d2d9e59779a73eb00bd6e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "*rshell.exe" wide
		$ = "/od') do call" wide

	condition:
		uint32be( 0 ) == 0x4c000000 and all of them
}
rule SEKOIA_Apt_Icepeony_Icecache : FILE
{
	meta:
		description = "Detects IceCache backdoor"
		author = "Sekoia.io"
		id = "3135c70e-c925-4d26-beed-09424fc0c153"
		date = "2024-10-21"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_icepeony_icecache.yar#L1-L46"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "38708c33dafb5625ddde1030a7efa7db"
		hash = "1e102c8909b2bf71c626b81f7526ee01"
		hash = "34bc3c586a48f836b00aff59fe891b30"
		hash = "cd906f4cef84dddeb644b06777474b2e"
		hash = "add23fedfbf238f51173796f3feb12af"
		hash = "25b8daaa5e9c5f8820261d7ebf79f3cd"
		hash = "7fd45cc1de1230c916d5f547a9fc725c"
		hash = "e6e4060e838d7af5f13ad64258d5db0c"
		hash = "87dfc911885420380bea0cf74c8160d3"
		hash = "bd15103b300cad635191972330913d17"
		hash = "a8119b7803a6e0b8aed6bc74d9062b7f"
		hash = "e1bc3efc33b57c9e1e6d37e5011228f2"
		hash = "e1233a5f613aafec2c28133e810f536d"
		hash = "fe88a5b91841b25b4bafa08d42faab22"
		logic_hash = "db82489e1a1eb55960b7a8fd3e6f52db526295ed4e5b90ddea826c5be5f9a1c4"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Source Response Empty!"
		$ = "Source Response Len:"
		$ = "GetFromSource:"
		$ = "Failed add header!"
		$ = "Failed receive response:"
		$ = "Error: Status Code :"
		$ = "WinHttpAddRequestHeaders"
		$ = "X-FORWARDED-HOST:"
		$ = "PROXY_DEL_CONTENT"
		$ = "PROXY_CLEAR_CONTENT"
		$ = "PROXY_SET_JS"
		$ = "PROXY_GET_JS"
		$ = "PROXY_ALLOW_PC"
		$ = "Parse IP failed :"
		$ = "Clear Proxy Contents Success!"
		$ = "FILE_UPLOAD"
		$ = "FILE_DOWNLOAD"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and 6 of them
}
rule SEKOIA_Apt_Apt28_Ukrnet_Phishing_Page : FILE
{
	meta:
		description = "Detects APT28 Phishing page"
		author = "Sekoia.io"
		id = "053158d8-aac0-486f-8432-834a06f41ed2"
		date = "2024-09-02"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt28_ukrnet_phishing_page.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "20dc3a5beb8e3a7801e010b4113efef1"
		hash = "5f1462144d7704101cd71c679ea0322b"
		logic_hash = "3d077a7ce35094bcbda763c131d4564ffbcea0373f5cbd30406ada4e9db36529"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "baseurl+\"/captcha\""
		$ = "(\"sessionID\", sessionID"
		$ = ".responseJSON['origin"
		$ = "var baseurl="
		$ = "(req.responseText.includes("
		$ = "else if (req.responseText=='FAIL')"
		$ = "|| document.getElementById('confpwd"
		$ = "/master/dist/text-security-disc.woff"

	condition:
		4 of them and filesize < 500KB
}
rule SEKOIA_Latrodectus_Br4_Js_Dropper
{
	meta:
		description = "Detect the JS script used to drop Latrodectus"
		author = "Sekoia.io"
		id = "042a598d-66fa-4994-a793-228355abd5dd"
		date = "2024-06-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/latrodectus_br4_js_dropper.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a835bd9a9ad68fd2f285ec5c04a5c78ba5ca85381ff30048ac375bef220fd72f"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = " installer.InstallProduct(msiPath);" ascii
		$s2 = "new ActiveXObject(\"WindowsInstaller.Installer\");" ascii

	condition:
		all of them
}
rule SEKOIA_Apt_Dark_Pink_Pdb_Path : FILE
{
	meta:
		description = "Detects PDB path of some Dark Pink sample"
		author = "Sekoia.io"
		id = "695586dc-66de-4f9d-814a-2d81261a7357"
		date = "2023-01-16"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_dark_pink_pdb_path.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f67e0d50975697424313acc77a9c86e1c2b41fde1663e4f5d8f4765acb997775"
		score = 75
		quality = 76
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "C:\\Users\\hoang\\source\\repos\\Cucky\\Cucky\\obj\\Release\\net46\\Cucky.pdb" wide ascii
		$s2 = "C:\\Users\\build\\source\\repos\\CtealWebCredential\\Release\\CtealWebCredential.pdb" wide ascii

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 5MB and any of them
}
rule SEKOIA_Rule_Lazarus_Generic_Downloader_7C3F94702Fa7 : FILE
{
	meta:
		description = "Detects a Generic Downloader used by Lazarus"
		author = "Sekoia.io"
		id = "eb0f0a91-5e72-4358-91a3-7c3f94702fa7"
		date = "2022-08-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rule_lazarus_generic_downloader_7c3f94702fa7.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "1ee58eb760fb74ef089f7d3eb423f314fe1c22e8c85b01eba0e965dea8c846ce"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "%s%s%s%s = %s%s%s%s"
		$ = "sec-ch-ua-mobile: ?0"
		$ = "%s>%s"
		$ = "d$f92&^$#FESAfaSDage#FDa"
		$ = "Sec-Fetch-User: ?1"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 200KB and 3 of them
}
rule SEKOIA_Clipper_Win_Atlas_Strings
{
	meta:
		description = "Detects Atlas Clipper"
		author = "Sekoia.io"
		id = "f08c6af6-c325-4f7d-8686-575b25550d6a"
		date = "2023-07-10"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/clipper_win_atlas_strings.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c8ad062b69dfe996a488ee9c79f0e7e0016f57f5b54fc39aeb4e207d2a42aa75"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "C:/Users/box/Desktop/ATLAS/ATLAS/main.go" ascii
		$s2 = "ATLAS Clipper" ascii
		$s3 = "Victim: %s" ascii
		$s4 = "Attacker: %s" ascii
		$s5 = "Install Path: %s" ascii
		$s6 = "HWID: %s" ascii
		$s7 = "Install Date: %s" ascii
		$s8 = "https://t.me/atlasclipper_channel" ascii

	condition:
		all of them
}
rule SEKOIA_Apt_Muddywater_Manifestation_Backdoor : FILE
{
	meta:
		description = "Detects Muddys manifestation JScript backdoor"
		author = "Sekoia.io"
		id = "998fb0ab-73ed-41e5-b87e-f987b8f05a8c"
		date = "2022-01-13"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_muddywater_manifestation_backdoor.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "477ed53ccd337dd21ab84b7d36b995a653d0aad6676e02cbe5e9f581bface253"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "/^\\s+|\\s+$/g" ascii
		$l2 = "while (1) {" ascii
		$l3 = { 57 53 63 72 69 70 74 2e 73 6c 65 65 70 28 ?? ?? 20 2a 20 31 30 30 30 29 3b }
		$s4 = ")+ key , false)" ascii
		$s5 = ")+ data , false)" ascii

	condition:
		filesize > 1000 and ( $l3 in ( @l2 .. @l2 + 300 ) ) and ( any of ( $s* ) )
}

rule SEKOIA_Installer_Win_Minibus : FILE
{
	meta:
		description = "Detect MINIBUS installer"
		author = "Sekoia.io"
		id = "0f7f600d-d93b-4b5a-aa0e-7d91038409e6"
		date = "2024-04-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/installer_win_minibus.yar#L4-L27"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "26ca51cb067e1fdf1b8ad54ba49883bc5d1945952239aec0c4840754bff76621"
		hash = "90fa29cc98be1d715df26d22079bdb8ce1d1fd3ce6a4efb39a4c192134e01020"
		logic_hash = "24326c9f5dcb7e66d47b65bf6bec6fe78be18c8d41a3039fbd09b453568a3f8f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "\\essential.dat"
		$ = "TorvaldInitial.dll"

	condition:
		uint16be( 0 ) == 0x4d5a and 1 of them or for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "de3fb5d4419eb6b943872dd6e3dd93d19584ef2b158aa3158b3b09f0a9b628ef" )
}
rule SEKOIA_Malware_Remcom_Strings : FILE
{
	meta:
		description = "Detects RemCom based on strings"
		author = "Sekoia.io"
		id = "7a56d55a-2f35-41ef-b7af-259baf215a62"
		date = "2022-08-30"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/malware_remcom_strings.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a46bb87bf4722303d33707afb19c8d4f209b98a88552363363520536911469ae"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "RemComSvc"
		$ = "RemCom_stderr"
		$ = "RemCom_stdin"
		$ = "\\\\.\\pipe\\%s%s%d"
		$ = "RemCom_stdout"
		$ = "\\\\.\\pipe\\RemCom_communicaton"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and 4 of them
}
rule SEKOIA_Tool_Printnotifypotato : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "8dde175f-025a-4c27-bcc6-d0016dd7238c"
		date = "2023-08-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_printnotifypotato.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5d4b7d1582c2b3f53ca5e1ff6e7ff97a677fe8870e94415f7328ea0a0387049c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "PrintNotifyPotato.exe" ascii wide
		$s2 = "BeichenDream" ascii wide
		$s3 = "interactive" ascii wide
		$s4 = "DuplicateTokenEx" ascii wide
		$s5 = "CurrentUser" ascii wide
		$s6 = "FakeIUnknown" ascii wide

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 8MB and all of them
}
rule SEKOIA_Miner_Win_Xmrig_Strings : FILE
{
	meta:
		description = "Detects XMRig EXE"
		author = "Sekoia.io"
		id = "35f203aa-20cd-4235-9ead-b34be14255d5"
		date = "2024-01-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/miner_win_xmrig_strings.yar#L1-L35"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "34aa0da9d3bb277927c87a3745ec9e35881682319c91141da6ff1cff7e0610d9"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "XMRig "
		$ = "pool_wallet"
		$ = "IP Address currently banned"
		$ = "rigid"
		$ = "diff_current"
		$ = "shares_good"
		$ = "shares_total"
		$ = "avg_time"
		$ = "avg_time_ms"
		$ = "hashes_total"
		$ = "pool address"
		$ = "ping time"
		$ = "connection time"
		$ = "daemon+wss://"
		$ = "daemon+https://"
		$ = "daemon+http://"
		$ = "socks5://"
		$ = "stratum+ssl://"
		$ = "stratum+tcp://"

	condition:
		uint32be( 0 ) == 0x5A4D and filesize < 15MB and 7 of them
}
rule SEKOIA_Apt_Gamaredon_Ddrdoh_Vbs_Downloader_Vbs : FILE
{
	meta:
		description = "Detects malicious VBScript executed by LNK/mshta"
		author = "Sekoia.io"
		id = "cc29d5d9-58bd-4f68-8673-daa41abfc7be"
		date = "2023-01-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gamaredon_ddrdoh_vbs_downloader_vbs.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c91e1ce26c0735e8c68fe39f2fbeda8aed51cd4f9a0b967b5d184843728dcef4"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "b24gZXJyb3IgcmVzd" ascii
		$ = "BinaryStream.readtext" ascii nocase
		$ = "createobject(\"msxml2.domdocument.3.0\").createelement(" ascii nocase
		$ = "Dim cSecond, cMinute, CHour, cDay, cMonth, cYear" ascii nocase
		$ = "tDate & \"T\" & tTime"
		$ = "AutoOpen" ascii nocase

	condition:
		5 of them and filesize < 50KB
}
rule SEKOIA_Apt_Uac0154_Powershell_Infection_Chain_2 : FILE
{
	meta:
		description = "UAC-0154 Infection chain"
		author = "Sekoia.io"
		id = "6fe37d52-9bd3-4aa8-83ba-15399bd1b66c"
		date = "2023-10-02"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_uac0154_powershell_infection_chain_2.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "029d88971030a377b3c93ba4c986668e53b01ee03ba94a0a4ceb54b20b72ff2d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "files.catbox.moe"
		$ = "$pse = $pse.Replace"
		$ = "start -WindowStyle Hidden -FilePath $p"
		$ = "-bxor $xorMask"
		$ = "SysctlHost"

	condition:
		4 of them and filesize < 100KB
}
rule SEKOIA_Ransomware_Win_Scransom : FILE
{
	meta:
		description = "Finds ScRansom samples based on specific strings"
		author = "Sekoia.io"
		id = "ea799295-1332-49c6-9816-035b91fc9b4f"
		date = "2023-08-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_win_scransom.yar#L1-L31"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "3b8034bc5e0919d6c05dd2f2079c40836f241f2db02c1baf70ecb530db90847f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "TIMATOMAFULL" wide
		$str02 = ".Encrypted" wide
		$str03 = ".Encrypting" wide
		$str04 = "File Name :" wide
		$str05 = "File size :" wide
		$str06 = "TIMATOMA#" wide
		$str07 = "Already Encrypted" wide
		$str08 = "HOW TO RECOVERY FILES.TXT" wide
		$str09 = "%d folder(s) searched and %d file(s) found - %.3f second(s)" wide
		$str10 = "Search cancelled -" wide
		$str11 = "note.txt" wide
		$str12 = "Cannot sort the list while a search is in progress." wide
		$str13 = "Cancelling search, please wait..." wide
		$str14 = "Error showing process list" wide
		$str15 = "[System Process]" wide
		$str16 = "taskkill /f /im" wide
		$str17 = "kill.bat" wide

	condition:
		uint16( 0 ) == 0x5a4d and 15 of them
}

rule SEKOIA_Apt_Apt28_Susp_Graphite_Downloader : FILE
{
	meta:
		description = "Matches the routine which decrypts the RSA key blob in the Graphite downloader"
		author = "Sekoia.io"
		id = "9c9da5fe-ffd6-4c45-8ce1-9a6cf4fa2fda"
		date = "2022-01-26"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt28_susp_graphite_downloader.yar#L3-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ca5aa7ea995aca9003fd98da2fba7bbec1e049d979a6b05e07b80876bab5a1c9"
		score = 65
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$gen = { 33 D2
        8B C1
        6A ??
        5E
        F7 F6
        8A 82 ?? ?? ?? ??
        30 81 ?? ?? ?? ??
        41
        81 F9 94 04 00 00
        72 E2 }

	condition:
		uint16be( 0 ) == 0x4d5a and $gen and pe.number_of_exports == 1
}
rule SEKOIA_Loader_Amadey_Clipper_Plugin : FILE
{
	meta:
		description = "Finds Amadey's clipper plugin based on characteristic strings"
		author = "Sekoia.io"
		id = "487b6657-8834-45ee-8fd4-03df9c0dd7be"
		date = "2023-05-16"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_amadey_clipper_plugin.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6f5a2fa9c687f0fb2423ca97540d0173551dd04b31d092e4d47d6d7d22dfb965"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "CLIPPERDLL.dll" ascii
		$str02 = "??4CClipperDLL@@QAEAAV0@$$QAV0@@Z" ascii
		$str03 = "??4CClipperDLL@@QAEAAV0@ABV0@@Z" ascii
		$str04 = "Main" ascii fullword
		$str05 = "OpenClipboard" ascii
		$str06 = "GetClipboardData" ascii
		$str07 = "D:\\Mktmp\\Amadey\\ClipperDLL\\Release\\CLIPPERDLL.pdb" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 5 of them
}
rule SEKOIA_Downloader_Win_Donot
{
	meta:
		description = "Detect the DoNot's downloader malware. There are big binaries in downloader strings."
		author = "Sekoia.io"
		id = "31b153cc-a4b9-40a0-8bcb-ce1370645b4b"
		date = "2023-03-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/downloader_win_donot.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f6a03e6cfda74c1fbb1e8939a66735498d604a821b8b51492c2c5c6a46a38b6e"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "001100000011000100110001001100000011000000110000001100010011000100110000001100010011000100110000001100010011000100110000001100010011"
		$ = "01010011011011110110011001110100011101110110000101110010011001010101110001001101011010010110001101110010011011110111001101101111011001100111010001011100010101110110100101101110011001000110111101110111011100110101110001000011011101010111001001110010011001010110111001110100010101100110010101110010011100110110100101101111011011100101110001010101011011100110100101101110011100110111010001100001011011000110110000000000"
		$ = "0101110001110011011110010111001101110100011001010110110100110011001100100101110001110010011101010110111001100100011011000110110000110011001100100010111001100101011110000110010100000000"

	condition:
		1 of them
}
rule SEKOIA_Apt_Kimsuky_Sharptongue_C2_Source
{
	meta:
		description = "Detects the PHP code of the SharpTongue C2"
		author = "Sekoia.io"
		id = "a2ccf773-511c-4088-8bcf-b923291d024b"
		date = "2022-07-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_kimsuky_sharptongue_c2_source.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c301a99876cfe2863546c990654aa922f9327e0eb010968eaea43f1d8ced76da"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "<?php"
		$ = "foreach($_GET as $variable => $value)"
		$ = "$chk=$value"
		$ = "base64_encode($ip)"

	condition:
		all of them
}
rule SEKOIA_Apt_Gamaredon_Stealer_Obfuscation_1 : FILE
{
	meta:
		description = "Matches the Gamaredon Stealer obfuscation"
		author = "Sekoia.io"
		id = "a6197d16-8ed1-410b-8814-d7eff9a8096c"
		date = "2022-02-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gamaredon_stealer_obfuscation_1.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "7f6a5f8af73c4eb7debbadfd22232ad4e3f44e3aae36c3d624ce7a1a050e8782"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = { 76 61 72 20 [5-30] 3d 20 6e 65 77 20 6f 62 6a 65 63 74 5b 5d 20 7b 20 [2-10] 2c 20 [2-10] 2c 20 [2-10] 2c 20 [2-10] 2c 20 [2-10] 2c 20 [2-10] 20 7d 3b }
		$s2 = { 66 6f 72 28 69 6e 74 20 [5-30] 20 3d 20 30 3b 20 [5-30] 20 3c 20 31 30 3b 20 [5-30] 2b 2b 29 }

	condition:
		uint16be( 0 ) == 0x4d5a and filesize > 100MB and ( #s1 > 100 or #s2 > 100 )
}

rule SEKOIA_Launcher_Win_Mistcloak : FILE
{
	meta:
		description = "Detect the MISTCLOAK malware"
		author = "Sekoia.io"
		id = "3dbf5efa-d77c-436a-a080-9ac58a78425f"
		date = "2022-12-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/launcher_win_mistcloak.yar#L4-L33"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "fc2731ec4e2917be1ad169908ed324931a93f6998aee606319750b5cc02715e2"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "\\usb.ini"
		$ = "autorun.inf\\Protection for Autorun\\System Volume Information"
		$ = "G:\\project\\APT\\U"
		$ = "\\new\\u2ec\\Release\\u2ec.pdb"
		$ = "CheckUsbService"

	condition:
		uint16( 0 ) == 0x5A4D and 3 of them or hash.md5 ( pe.rich_signature.clear_data ) == "0f5082fd7ddd1950fa332a8fa4df052f" or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "0ceac625db1e8405efe45d47486e9e2d" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "6968e6ac7b9c1dfbf40a0b3c4f6f4157" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "e6ed2da41f74e948cba7a002c41c6af5" )
}
rule SEKOIA_Backdoor_Powershellempire_Sharpire : FILE
{
	meta:
		description = "Detect Sharpire version of Empire"
		author = "Sekoia.io"
		id = "fed21fbd-52ed-4649-a1ff-56eae57fc9ef"
		date = "2022-04-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_powershellempire_sharpire.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a4da54a16ee1ac3dea3b3b5a5983638ea28fd1e6d580cd48db595f15a92817a1"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "GetAgentID" ascii wide
		$ = "SetAgentID" ascii wide
		$ = "StartAgentJob" ascii wide
		$ = "get_JobThread" ascii wide
		$ = "GetStagerURI" ascii wide

	condition:
		uint16be( 0 ) == 0x4d5a and 4 of them and filesize < 1MB
}
rule SEKOIA_Downloader_Win_Search : FILE
{
	meta:
		description = "'Search.exe' script used by APT42"
		author = "Sekoia.io"
		id = "8094ddda-6294-4dee-93cb-de79aaed1ec6"
		date = "2024-08-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/downloader_win_search.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "a29fa85ecfc0e5554c21f3b9db185de97b3504517403f4aa102adbd2c46dc1bf"
		hash = "f83e2b3be2e6db20806a4b9b216edc7508fa81ce60bf59436d53d3ae435b6060"
		logic_hash = "1b25f04d1d2c9b7bdc7e0bd17d2f2876c27f9c4acb3a2afca6a4df531e769740"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "C:\\Users\\pc\\source\\repos\\Search\\Search\\obj\\Debug\\Search.pdb"

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Apt_Oilrig_Webshell : FILE
{
	meta:
		description = "Detects a webshell used by OilRig"
		author = "Sekoia.io"
		id = "53955117-5176-4682-89ad-1503faba42aa"
		date = "2024-10-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_oilrig_webshell.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0e0879bafa1becf7e4aef008229a79ab8e0c50eda03232abd5cbb8fc59f482d3"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "string d = com;"
		$ = "string p = fu;"
		$ = "#@rt12!@$$$nnMF##"
		$ = "messi(d)))"

	condition:
		2 of them and filesize < 80KB
}
rule SEKOIA_Apt_Apt29_Wineloader_Malicious_Hta
{
	meta:
		description = "Detects malicious HTA used by APT29 to drop Wineloader"
		author = "Sekoia.io"
		id = "5a17d854-0564-4830-a0e5-7867b99716c2"
		date = "2024-03-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt29_wineloader_malicious_hta.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "efafcd00b9157b4146506bd381326f39"
		logic_hash = "0cc4692e5ff3f258c287f28030147f725d6a534c4f2f7a2a4ff49a305b7fd13d"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "<HTA:APPLICATION ID="
		$ = "var _0x"
		$ = "Date['\\x6e\\x6f\\x77']"

	condition:
		all of them
}
rule SEKOIA_Tool_Exploit_Comahawk_Strings : FILE
{
	meta:
		description = "Detects COMahawk exploit compiled binaries"
		author = "Sekoia.io"
		id = "cc0d10ae-1a14-48c1-9c45-d65fac15f8f1"
		date = "2022-09-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_exploit_comahawk_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a80fed3fd64562dd3e2fa197ca3d2aaf8e33783729b725c71f7eb8931af70d82"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "sc config UsoSvc binpath=" wide
		$ = "binpath= \"cmd.exe /c net localgroup administrators /add"
		$ = "[+] Command executed."
		$ = "Release\\COMahawk.pdb"
		$ = " is added as an admin."

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and 3 of them
}
rule SEKOIA_Infostealer_Win_Lighting : FILE
{
	meta:
		description = "Detect the Lighting infostealer based on specific strings"
		author = "Sekoia.io"
		id = "3c160c16-f417-4fa2-aa44-fb7b981fb2b3"
		date = "2022-04-07"
		modified = "2024-12-19"
		reference = "https://blog.cyble.com/2022/04/05/inside-lightning-stealer/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_lighting.yar#L1-L40"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "1c1d39ce886a433a352c55bf436b959ef528ad7ce38027243ed5b5f1ac79822f"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str0 = "\\logins.json" wide
		$str1 = "key3.db" wide
		$str2 = "\\key4.db" wide
		$str3 = "cert9.db" wide
		$str4 = "\\places.sqlite" wide
		$str5 = "7D78CB380BF5EFB7B851409CA6A875F77DECF09D19B9149DA17A3EBF674BC0F9" ascii
		$str6 = "potentiallyVulnerablePasswords" wide
		$dll0 = "\\mozglue.dll" wide
		$dll1 = "\\nss3.dll" wide
		$dll2 = "SbieDll.dll" wide
		$app00 = "\\discord\\Local Storage\\leveldb\\" wide
		$app01 = "Software\\Valve\\Steam" wide
		$app02 = "Telegram Desktop\\tdata" wide
		$app03 = "\\Wallets\\Armory\\" wide
		$app04 = "\\Wallets\\Atomic\\Local Storage\\leveldb\\" wide
		$app05 = "\\Exodus\\exodus.wallet\\" wide
		$app06 = "\\Wallets\\Zcash\\" wide
		$app07 = "uCozMedia\\Uran" wide
		$app08 = "Comodo\\IceDragon" wide
		$app09 = "8pecxstudios\\Cyberfox" wide
		$app10 = "NETGATE Technologies\\BlackHaw" wide
		$app11 = "Moonchild Productions\\Pale Moon" wide

	condition:
		uint16( 0 ) == 0x5A4D and 6 of ( $str* ) and all of ( $dll* ) and 10 of ( $app* )
}
rule SEKOIA_Tool_Edrsandblast_Strings : FILE
{
	meta:
		description = "Detects EDRSandblast strings"
		author = "Sekoia.io"
		id = "7059b89c-80b5-4768-b3eb-02f173f628b0"
		date = "2024-01-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_edrsandblast_strings.yar#L1-L29"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8528c4c440734ba97b98b6e0857d95f38a91eaf9120ba2eacff292c864fb86a5"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[!] Cred Guard bypass failed: obtained invalid" wide
		$ = "[!] Cred Guard bypass non fatal error:" wide
		$ = "[+] Successfully overwrote wdigest's g_fParameter_UseLogonCredential" wide
		$ = "[!] ERROR: could not allocate memory for the handl" wide
		$ = "[+] [ProcessProtection] Found the handle of the current" wide
		$ = "[+] [ProcessProtection] Found self process EPROCCES struct at" wide
		$ = "ETW Threat Intel ProviderEnableInfo address could not be found." wide
		$ = "The ETW Threat Intel provider was successfully" wide
		$ = "[+] [NotifyRountines]" wide
		$ = "[callback addr: 0x" wide
		$ = "EDR / security products driver(s)" wide
		$ = "Object callback offsets not loaded ! Aborting..." wide
		$ = "No more space to store object callbacks !!" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and 3 of them
}
rule SEKOIA_Trojan_Win_Bbtok_Dll1_Sep23 : FILE
{
	meta:
		description = "Finds BBTok installation DLL file"
		author = "Sekoia.io"
		id = "eebed24b-24ec-4a85-852c-52d0acc9a698"
		date = "2023-09-26"
		modified = "2024-12-19"
		reference = "https://research.checkpoint.com/2023/behind-the-scenes-of-bbtok-analyzing-a-bankers-server-side-components/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/trojan_win_bbtok_dll1_sep23.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "5353956345206982af9bde55300fc405ba6e40722e8f51e8717c30ad32bc8f91"
		logic_hash = "1b1e25f7d760d275d2ef01390c215edb1752ad65383c92a21d71d9e65da3c5f8"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "C:\\Windows\\System32\\rundll32.exe" wide
		$str02 = "C:\\ProgramData\\mmd.exe" wide
		$str03 = "REG ADD HKCU\\Software\\Classes\\.pwn\\Shell\\Open\\command -ve /d" wide
		$str04 = "C:\\ProgramData\\mmd.exe \\\\" wide
		$str05 = "\\file\\Trammy.dll" wide
		$str06 = "Dacl & REG DELETE HKCU\\Software\\Classes\\ms-settings /f" wide
		$str07 = "REG DELETE  HKCU\\Software\\Classes\\.pwn /f" wide
		$str08 = "REG ADD HKCU\\Software\\Classes\\ms-settings\\CurVer -ve /d \".pwn\" /f" wide
		$str09 = "timeout /t 3 >nul & start /MIN computerdefaults.exe" wide
		$str10 = "set_StartInfo" ascii
		$str11 = "set_WindowStyle" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 7 of them and filesize < 50KB
}
rule SEKOIA_Loader_Win_Aresloader : FILE
{
	meta:
		description = "Finds AresLoader samples based on characteristic strings"
		author = "Sekoia.io"
		id = "bf5070fc-c8ca-4458-8702-cd1830667b7a"
		date = "2023-05-02"
		modified = "2024-12-19"
		reference = "https://blog.cyble.com/2023/04/28/citrix-users-at-risk-aresloader-spreading-through-disguised-gitlab-repo/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_aresloader.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "2edbb625394506e865580373d5c3454b4fa201183c84d247b4373f24e25f5fd4"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "{\\\"ip\\\": '%s', \\\"UID\\\": '%s', \\\"geo\\\": '%s', \\\"service\\\": '%s', \\\"owner_token\\\": '%s'}" ascii
		$str02 = "AresLdr_v_3" ascii
		$str03 = "https://ipinfo.io/ip" ascii
		$str04 = "C:\\Users\\%s\\AppData\\Roaming\\%s\\%s" ascii
		$str05 = "/manager/payload" ascii
		$str06 = "/manager/loader" ascii
		$str07 = "/manager/legit" ascii
		$str08 = "/manager/hvnc" ascii
		$str09 = "C%p %d V=%0X w=%ld %s" ascii
		$str10 = "rundll32.exe %s,%s" ascii
		$str11 = "%startinfo" ascii
		$str12 = "%managedapp" ascii
		$str13 = "%has_cctor" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 5 of them
}
rule SEKOIA_Apt_37_Chinotto : FILE
{
	meta:
		description = "Detects obfuscation and string of APT37 stealer"
		author = "Sekoia.io"
		id = "eff8fd11-dc7a-4011-b083-181d0cca8790"
		date = "2023-02-27"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_37_chinotto.yar#L1-L50"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "feab7940559392bbf38f29267509340569160e0a3b257fd86e5c65ae087ea014"
		hash = "c9d2c8b6011a53e68e4a6c6e51142cef3348951d0b379e49b1a65a1891538df5"
		hash = "2f5be3773e7e3a2f6806cdef154adfabc454c0e57a49e437c5889ce09b739302"
		hash = "5bf170c95ca0e2079653d694f783b5bcd38f274ea875f67f0b60db4ac552a66c"
		hash = "6fad04c836bc923f12ebaec8d8fb0c7091b044bf6f5c97e36d7bf46b8494f978"
		hash = "64fe964f342acca6d85d247c4f67503e4222a58dfc5c644dedc2006a4b356d39"
		hash = "6e216b265ea391f71f2a609df995f36b9ba8b17c8859f6d8e4ce4a076d351efd"
		hash = "70dcc03cde3dd5c5ec6a6a240190cfb51667aaba9c867e20281e8dfc43afa891"
		hash = "5053390bde150b771f8efe344b692c6c5718ba9203a4b23f5323af1ee9060ff2"
		hash = "089e4dfd8b25afe596eff05baae86156a4e3243c84faa15416cff31a5120e107"
		hash = "37e096338a78cb06d6236cb5a04cf125f191871ded3c9421f08a37890a095eb8"
		hash = "b90a2b0249407b271a5d849fe82cbf4e9a31c2c6259caf515c9be3897e327414"
		hash = "8f4751ed22619b04009c4b85ec45c8140b570835ca4c638c9e6019e7b7eb66c7"
		logic_hash = "a721f102b4c9568379649f8004fa4eb460240145ab829d8ce3740dafb52d13c8"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$chunk_1 = {
        C7 85 ?? ?? ?? ?? ?? ?? ?? 00
        C7 85 ?? ?? ?? ?? ?? ?? ?? 00
        33 C0
        EB 03
        8D 49 00
        8B 8C 85 ?? ?? ?? ??
        3B 8C 85 ?? ?? ?? ??
        }
		$chunk_2 = {
        C7 84 24 ?? ?? ?? ?? ?? ?? 0? 00
        C7 84 24 ?? ?? ?? ?? ?? ?? 0? 00
        33 C0
        EB 0D
        8D A4 24 00 00 00 00
        8D 9B 00 00 00 00
        8B 8C 84 ?? ?? ?? ??
        3B 8C 84 ?? ?? ?? ??
        }
		$movs_zip_dir_start = { C7 45 ?? 5A 69 70 20 C7 45 ?? 44 69 72 20 C7 45 ?? 53 74 61 72  C7 45 ?? 74 20 2D 20}

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 1MB and ( $chunk_1 or $chunk_2 ) and $movs_zip_dir_start
}
rule SEKOIA_Generic_Sharpshooter_Payload_5 : FILE
{
	meta:
		description = "Detects payload created by SharpShooter"
		author = "Sekoia.io"
		id = "cb4d266e-f2b7-4642-a223-57180e66a9a6"
		date = "2023-02-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/generic_sharpshooter_payload_5.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a68342b5bb2622deb71432da85cc249f35ca5b7b5dc70e069d6dcb6e9488e97e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "rc4 = function(key, str)"
		$ = "<job id=\"JS Code\""
		$ = "var e={},i,b=0,c,x,l=0,a,r="
		$ = "var plain = rc4("
		$ = "eval(plain);"

	condition:
		all of them and filesize < 2MB
}
rule SEKOIA_Loader_Win_Red0044_Powershell_May24 : FILE
{
	meta:
		description = "Finds PowerShell scripts used in a malvertising campaign to deliver NetSupport RAT"
		author = "Sekoia.io"
		id = "ba3454b4-31cf-458d-8d78-c5cc5fa348ff"
		date = "2024-05-03"
		modified = "2024-12-19"
		reference = "https://twitter.com/crep1x/status/1786150734121120075"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_red0044_powershell_may24.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "73939f65b93b320b9e220ee284ea524864a6b05c7608213009ac5f00b3faeedc"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "Start-Job -ScriptBlock" ascii
		$str02 = "Get-WmiObject" ascii
		$str03 = "-Class Win32_OperatingSystem" ascii
		$str04 = "-Class AntiVirusProduct" ascii
		$str05 = "$_.Exception.Message" ascii
		$str06 = ".DownloadString" ascii
		$str07 = "New-Object Net.WebClient" ascii
		$str08 = "myUserAgentHere" ascii
		$str09 = "GetFolderPath('Desktop'))\\document.pdf" ascii
		$str10 = "Receive-Job -Job" ascii
		$str11 = "Start-Process" ascii

	condition:
		8 of them and filesize < 20KB
}
rule SEKOIA_Rat_Win_Asbit : FILE
{
	meta:
		description = "Finds Asbit samples based on characteristic strings"
		author = "Sekoia.io"
		id = "b2d60eff-3dc8-4857-a0ea-d4fcd34c40bc"
		date = "2022-09-19"
		modified = "2024-12-19"
		reference = "https://blogs.juniper.net/en-us/threat-research/asbit-an-emerging-remote-desktop-trojan"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_asbit.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "1362ebe89a4d2645eb687d92510daa355a16f05da7f5513817f8439f29722827"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "/build?project=libexpat&_={0}" wide
		$str02 = "/resolve?name={0}&short=true&_={1}" wide
		$str03 = "/c ping 127.0.0.1 & del {0} /q & del /a:H {0} /q" wide

	condition:
		uint16( 0 ) == 0x5A4D and 1 of them
}

rule SEKOIA_Reverseshell_Win_1St_Troy : FILE
{
	meta:
		description = "Detect the 1st Troy Reverse Shell agent used by Andariel"
		author = "Sekoia.io"
		id = "b40b742d-8b1e-4d99-8df5-6cb8c9a7d8bd"
		date = "2023-09-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/reverseshell_win_1st_troy.yar#L4-L32"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "186a6663eb91999b3e2637898ab40034f5fcd451150c9199d9b49328e64f90b5"
		hash = "5b015e69629de37507e96ce258c27479d157714121d7c622698c6d1d6b547425"
		logic_hash = "a85a6ef0fe3b3fde3cb833579f4fd69cd159737888ae41e69e40a6bdc1172d1f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "1th Troy/02___Go/Reverse_Base64_Pipe"

	condition:
		uint16be( 0 ) == 0x4d5a and all of them or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "657d7495796c36297ec1c13aaedf1dd3" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "debd992f27402355766cf3b5b47abe94" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "687d2535086bd055af5716760a2d87ce" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "78389349844e8d2d719603fc389779bf" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "44563b597e806af8a9ebe026c9ea6a53" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "5db8685a067d106fe66292b828a2161c" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "1268012f292e60785825726967a4e63e" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "c7b760c8b603f39a5ff9867accbad427" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "d28526f9543ecf429de4a863b8901575" )
}
rule SEKOIA_Unk_Quad7_Netd_Strings : FILE
{
	meta:
		description = "Matches netd binary"
		author = "Sekoia.io"
		id = "3f527f0e-c101-4356-9024-fc61aea644d1"
		date = "2024-08-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/unk_quad7_netd_strings.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "cdb37db4543dde5ca2bd98a43699828f"
		logic_hash = "abd59c5fa0c4c73a2cd9a2263d5573d896c6c0d71d96bd59167b1e2d7fbf108e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "./netd.dat"
		$ = "./sys.dat"
		$ = "--conf"
		$ = "--init"
		$ = "--nobg"
		$ = "Url is NULL."

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 1MB and 4 of them
}
rule SEKOIA_Apt_Mustangpanda_Windows_Shellcode_Decryptionalgorithm : FILE
{
	meta:
		description = "Decryption routine for Shellcode of MustangPanda"
		author = "Sekoia.io"
		id = "c9873a5f-97a6-477f-a1a0-650441c73444"
		date = "2022-12-05"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_mustangpanda_windows_shellcode_decryptionalgorithm.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a2ad3bd4dcbee3e23762b674ee8b6717e7ece712b0128145518bfa5d2e4bd66a"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$chunk_1 = {
        7E ??
        8B 55 ??
        53
        56
        8B 75 ??
        57
        8B 7D ??
        4F
        8D A4 24 ?? ?? ?? ??
        8A 1C 11
        30 1C 30
        }

	condition:
		filesize < 8MB and all of them
}
rule SEKOIA_Infostealer_Win_Redline_Strings : FILE
{
	meta:
		description = "Finds Redline samples based on characteristic strings"
		author = "Sekoia.io"
		id = "0c9fcb0e-ce8f-44f4-90b2-abafcdd6c02e"
		date = "2022-09-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_redline_strings.yar#L1-L47"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "44443e16b788231b3f256b4d1e91c458c33963d5737d69fc5850f6b0efa7726b"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$gen01 = "ChromeGetRoamingName" ascii
		$gen02 = "ChromeGetLocalName" ascii
		$gen03 = "get_UserDomainName" ascii
		$gen04 = "get_encrypted_key" ascii
		$gen05 = "browserPaths" ascii
		$gen06 = "GetBrowsers" ascii
		$gen07 = "get_InstalledInputLanguages" ascii
		$gen08 = "BCRYPT_INIT_AUTH_MODE_INFO_VERSION" ascii
		$spe0 = "Profile_encrypted_value" wide
		$spe1 = "[AString-ZaString-z\\d]{2String4}\\.[String\\w-]{String6}\\.[\\wString-]{2String7}" wide
		$spe2 = "AFileSystemntivFileSystemirusPrFileSystemoduFileSystemct|AntiFileSystemSpyWFileSystemareProFileSystemduct|FireFileSystemwallProdFileSystemuct" wide
		$spe3 = "OpHandlerenVPHandlerN ConHandlernect%DSK_23%Opera GXcookies" wide
		$spe4 = "//settinString.Removeg[@name=\\PasswString.Removeord\\]/valuString.RemoveeROOT\\SecurityCenter" wide
		$spe5 = "ROOT\\SecurityCenter2Web DataSteamPath" wide
		$spe6 = "windows-1251, CommandLine:" wide
		$spe7 = "OFileInfopeFileInfora GFileInfoX StabFileInfole" wide
		$spe8 = "ApGenericpDaGenericta\\RGenericoamiGenericng\\" wide
		$spe9 = "*wallet*" wide
		$typ01 = "359A00EF6C789FD4C18644F56C5D3F97453FFF20" ascii
		$typ02 = "F413CEA9BAA458730567FE47F57CC3C94DDF63C0" ascii
		$typ03 = "A937C899247696B6565665BE3BD09607F49A2042" ascii
		$typ04 = "D67333042BFFC20116BF01BC556566EC76C6F7E2" ascii
		$typ05 = "4E3D7F188A5F5102BEC5B820632BBAEC26839E63" ascii
		$typ06 = "FB10FF1AD09FE8F5CA3A85B06BC96596AF83B350" ascii
		$typ07 = "77A9683FAF2EC9EC3DABC09D33C3BD04E8897D60" ascii
		$typ08 = "A8F9B62160DF085B926D5ED70E2B0F6C95A25280" ascii
		$typ09 = "718D1294A5C2D3F3D70E09F2F473155C4F567201" ascii
		$typ10 = "2FBDC611D3D91C142C969071EA8A7D3D10FF6301" ascii
		$typ11 = "2A19BFD7333718195216588A698752C517111B02" ascii
		$typ12 = "EB7EF1973CDC295B7B08FE6D82B9ECDAD1106AF2" ascii
		$typ13 = "04EC68A0FC7D9B6A255684F330C28A4DCAB91F13" ascii

	condition:
		uint16( 0 ) == 0x5A4D and ( 7 of ( $gen* ) or 3 of ( $spe* ) or 2 of ( $typ* ) )
}
rule SEKOIA_Apt_Sugargh0Stcampaign_Malicious_Lnk : FILE
{
	meta:
		description = "Detects malicious LNK used in SugarGh0st campaign"
		author = "Sekoia.io"
		id = "4297c150-d125-49b9-8850-fcedf5284ae9"
		date = "2023-12-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_sugargh0stcampaign_malicious_lnk.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "9efa131fdb02f31812c8a3f2053e1b60d0970c748eb0f82aed92a1c0719e048c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "dir /S/b *.lnk " wide
		$ = "%temp%\\*.lnk" wide

	condition:
		uint32be( 0 ) == 0x4c000000 and filesize < 1MB and all of them
}

rule SEKOIA_Wiper_Win_Nominatus_Toxicbattery : FILE
{
	meta:
		description = "Detect the Nominatus_ToxicBattery malware"
		author = "Sekoia.io"
		id = "0262378f-f509-4ea4-a3eb-cd0183c4361d"
		date = "2022-11-21"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/wiper_win_nominatus_toxicbattery.yar#L4-L42"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c226a4c3bcc451482eb782c1cb84f3e956be1e214368d1b315076078d3148955"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "DISK"
		$ = "FileNaME"
		$ = "FILNAME"
		$ = "runCommand"
		$ = "HAHAH"
		$ = "Damage"
		$ = "fastInfector"
		$ = "d:\\again\\SharpDevelop Projects\\RInjector\\Virus.win32RozbehStrike\\obj\\Debug\\Nominatus_ToxicBattery.pdb"
		$ = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run" wide
		$ = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon" wide
		$ = "\\Antivirus.bat" wide
		$ = "\\Antivirus3.vbs" wide
		$ = "vssadmin Delete Shadows /all /quiet" wide

	condition:
		uint16( 0 ) == 0x5A4D and 10 of them or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "e7f35c173c34b7080d437a90ec90a982" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "2e25c5d3baba182f008a5a15c6f06403" ) or for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "70b1c002e4c0c9782c7ce1ef4a13c58ec1da54a26fd06dd7821a71f29431da82" )
}
rule SEKOIA_Apt_Gelsemium_Firewood_Backdoor : FILE
{
	meta:
		description = "Detects Gelsemium's FireWood backdoor"
		author = "Sekoia.io"
		id = "93670c07-9edd-4ea2-b8ed-6fee625491f4"
		date = "2024-11-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gelsemium_firewood_backdoor.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "2251bc7910fe46fd0baf8bc05599bdcf"
		logic_hash = "dea8c7cfb35b3cc026a0df844e118b495e3ad0a85f55e2fd3b63a41dde2ea944"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "root dir:%s"
		$ = "df -h|grep 'dev' |grep -v none|awk '/dev/{print $6}'"
		$ = "rm -rf ../lib/%s"
		$ = "Total Disk space:%luG, Free Disk spae:%luG"

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 1MB and all of them
}
rule SEKOIA_Crime_Sload_Scheduledtask_Dropper_Strings
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "01c51da8-71a5-449f-a609-933c37bc2e63"
		date = "2022-08-02"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/crime_sload_scheduledtask_dropper_strings.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "3a48009933d1de47314ec15c262375636574a7565016eab3792106fa2c0ba79f"
		score = 75
		quality = 78
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "$hh='hi'+'dd'+'en';"
		$ = { 7D 65 6C 73 65 7B 0A 24 72 73 3D 30 3B 0A 7D 0A }
		$ = { 6B 69 6C 6C 20 2D 6E 61 6D 65 20 2A 77 65 72 73 68 65 6C 2A }

	condition:
		all of them
}
rule SEKOIA_Koi_Koiloader : FILE
{
	meta:
		description = "Detects Koi Loader"
		author = "Sekoia.io"
		id = "b8289d78-42de-4919-b2c5-3c926ddd8043"
		date = "2024-03-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/koi_koiloader.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "7b4f12b0dec3927a46db1c8b2163e54a0a515d2b7360ba94647097fecf3d4653"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s2 = "%d|%s|%.16s|" ascii wide
		$s3 = "Release" ascii wide
		$s4 = "%s|%d.%d (%d)|%S|%S|%S" ascii wide
		$s5 = "InitiateSystemShutdownExW" ascii wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 11MB and all of them
}
rule SEKOIA_Spyware_And_Bahamut
{
	meta:
		description = "Detect Bahamut's spyware based on common information gathering function names"
		author = "Sekoia.io"
		id = "d416997e-baf1-412c-bf39-905a6e19b65e"
		date = "2022-11-23"
		modified = "2024-12-19"
		reference = "https://www.welivesecurity.com/2022/11/23/bahamut-cybermercenary-group-targets-android-users-fake-vpn-apps/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/spyware_and_bahamut.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "c51dc2132c830c560aaeae4bf48e5f0d28c84b36d27840b5c2ba170d87f4afa5"
		hash = "d7e2cf642b236dba9ba0cbe5a9dc28baf22477973d5ce163e21ec40f5f26e078"
		logic_hash = "5f44c938fed9b32eaf183be979a67e0c7fde409e72875359105ad7ffb393893d"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "FbDao"
		$ = "SignalDao"
		$ = "conionDao"

	condition:
		all of them
}

rule SEKOIA_Implant_Win_Magicrat : FILE
{
	meta:
		description = "Detect Lazarus' MagicRAT"
		author = "Sekoia.io"
		id = "74973682-b214-48ee-98c3-f4b6bef76587"
		date = "2022-09-13"
		modified = "2024-12-19"
		reference = "https://blog.talosintelligence.com/2022/09/lazarus-magicrat.html"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_win_magicrat.yar#L4-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "9dc04153455d054d7e04d46bcd8c13dd1ca16ab2995e518ba9bf33b43008d592"
		hash = "c2904dc8bbb569536c742fca0c51a766e836d0da8fac1c1abd99744e9b50164f"
		hash = "f6827dc5af661fbb4bf64bc625c78283ef836c6985bb2bfb836bd0c8d5397332"
		logic_hash = "9abc223c5ae9300b06b9161cbd9f5a501b6aaf46970b0bb74d98168792b7e659"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		uint16( 0 ) == 0x5A4D and filesize > 15MB and for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "39dfb9f035cba21ffd90973904f90469" and pe.sections [ i ] . name == ".qtmetad" )
}
rule SEKOIA_Guerrilla_Lemongroup : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "df635b5a-a19a-48ab-9a3a-9723e265c71d"
		date = "2023-05-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/guerrilla_lemongroup.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b644cb537a42217f2549f37bfe07ae0b7ba39fc248ab3d5fd870384c7684683b"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$dex = { 64 65 78 0A 30 33 ?? 00 }
		$odex = { 64 65 79 0A 30 33 ?? 00 }
		$s2 = "data response code===" ascii
		$s3 = "httpCon:" ascii
		$s4 = "processName :" ascii
		$s5 = "startListTasks......" ascii
		$s6 = "url==" ascii
		$s7 = "java core run ZYGOTE_PROCESS" ascii
		$api1 = "/api.php" ascii
		$api2 = "/event.php" ascii
		$api3 = "/apiRS.php" ascii

	condition:
		($dex at 0 or $odex at 0 ) and filesize > 100KB and filesize < 5MB and 5 of ( $s* ) and 1 of ( $api* )
}

rule SEKOIA_Ransomware_Win_Eking_Rich_Header
{
	meta:
		description = "Detect Eking ransomware using its rich header"
		author = "Sekoia.io"
		id = "9fe76f89-f27a-4a47-a61c-2d767a1a8acb"
		date = "2021-10-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_win_eking_rich_header.yar#L4-L15"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0028200fc2e929dba6fcc4ddf5d8e07825842e2f65c69ad94ebd032ae3748c90"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		hash.md5( pe.rich_signature.clear_data ) == "256b60751602028612562b73ecdb163c"
}
rule SEKOIA_Tool_Revsocks_Strings : FILE
{
	meta:
		description = "Detects revsocks client"
		author = "Sekoia.io"
		id = "f5f34e74-0795-4c81-a385-218a8197a0b7"
		date = "2024-03-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_revsocks_strings.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f1702aaaebc1ba720f688f0694a69fef55a2556b1f07dd4b846be1ae32ff5529"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "reverse socks5 server/client by kost" ascii fullword
		$ = "github.com/kost/"
		$ = "revsocks -listen"
		$ = "Start on the DNS server: revsocks -dns"
		$ = "crypto/aes."

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a or uint32be( 0 ) == 0xfeedface or uint32be( 0 ) == 0xfeedfacf or uint32be( 0 ) == 0xcafebabe or uint32be( 0 ) == 0xCFFAEDFE ) and 3 of them
}
rule SEKOIA_Apt_Queueseed : FILE
{
	meta:
		description = "Detects strings of Queueseed/Kapeka malware"
		author = "Sekoia.io"
		id = "35f7ffd5-4f6f-4b31-8d60-c713a15d14e8"
		date = "2024-04-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_queueseed.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "80d1135d63a351cabf45d2266c0ffc770e11669103107cd40caf00eb62c836ed"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = {2D 00 6F 00 00 00}
		$ = {2D 00 62 00 63 00 00 00}
		$ = {20 00 00 00 00 00 00 00}
		$ = {20 00 2D 00 77 00 00 00}
		$ = {35 00 3A 00 20 00 00 00}
		$ = {34 00 3A 00 20 00 00 00}
		$ = {33 00 3A 00 20 00 00 00}
		$ = {32 00 3A 00 20 00 00 00}
		$ = {31 00 3A 00 20 00 00 00}
		$ = {50 00 49 00 44 00 20 00 3A 00 20 00 00 00 00 00}
		$ = "ExitCode : " wide

	condition:
		uint16be( 0 ) == 0x4d5a and all of them and filesize < 200KB
}
rule SEKOIA_Infostealer_Win_Mars_Stealer_Xor_Routine : FILE
{
	meta:
		description = "Detect Mars Stealer based on a specific XOR routine"
		author = "Sekoia.io"
		id = "3e2c7440b2fc9e4b039e6fa8152ac8ff"
		date = "2022-04-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_mars_stealer_xor_routine.yar#L1-L15"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c7e65550a225431552e8a81bbce81dd66350021b6444c94fe7a37aa96712e9b1"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$xor = {8b 4d ?? 03 4d ?? 0f be 19 8b 55 ?? 52 e8 ?? ?? ?? ?? 83 c4 ?? 8b c8 8b 45 ?? 33 d2 f7 f1 8b 45 ?? 0f be 0c 10 33 d9 8b 55 ?? 03 55 ?? 88 1a eb be}

	condition:
		uint16( 0 ) == 0x5A4D and $xor
}
rule SEKOIA_Apt_Kimsuky_Malicious_Gotopwsh_Lnk : FILE
{
	meta:
		description = "Detects malicious LNK used by Kimsuky"
		author = "Sekoia.io"
		id = "cfe9adf5-2c06-4d04-8006-c4eea0dab549"
		date = "2023-09-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_kimsuky_malicious_gotopwsh_lnk.yar#L1-L15"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "1537ea232e745b1ed9e4b7f6b9ba779a3498f5edf0c46bdccfdc511137b2bb3a"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = {67 00 6f 00 74 00 6f 00 26 00 70 00 5e 00 6f 00 77 00 5e 00 65 00 5e 00 72 00 73 00 5e 00 68 00 65 00 5e 00 6c 00 5e 00 6c}

	condition:
		uint32be( 0 ) == 0x4c000000 and all of them
}
rule SEKOIA_Apt_Unk_Malicious_Lnk : FILE
{
	meta:
		description = "Detects a malicious LNK used by an APT"
		author = "Sekoia.io"
		id = "d2248803-7ddf-4cde-ab6a-78b20e760919"
		date = "2024-09-06"
		modified = "2024-12-19"
		reference = "https://www.seqrite.com/blog/operation-oxidovy-sophisticated-malware-campaign-targets-czech-officials-using-nato-themed-decoys/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_unk_malicious_lnk.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "a8d7e56eb01a8cf576533db9af2e92ec"
		logic_hash = "993411ceba45d1212a4840e6a35b72b52e64e78cbb2599ebc5c70c2fd3b8e552"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = ".pdf.lnkPK"
		$ = ".jfifPK"
		$ = ".batPK"
		$ = ".pdfPK"

	condition:
		uint32be( 0 ) == 0x504b0304 and all of them
}
rule SEKOIA_Apt_Mustangpanda_Xoreddll : FILE
{
	meta:
		description = "Detects xored DLL from MustangPanda embedding a document"
		author = "Sekoia.io"
		id = "73d13624-01df-41ab-b449-86db43dc6c55"
		date = "2022-07-19"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_mustangpanda_xoreddll.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "685be191cf187c0d5bfd00354400c47a961c9d047aa7e65e4cfc2201ec5eb1bc"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$clear = "This program cannot be run in DOS mode"
		$stub = "This program cannot be run in DOS mode" xor
		$res1 = "5w>w9wR'31Z" xor
		$res2 = "r0y0~0KlBD" xor
		$res3 = "d&o&h&öé7Æ" xor
		$res4 = "9{2{5{+0" xor

	condition:
		$stub and any of ( $res* ) and not $clear and filesize < 3MB
}
rule SEKOIA_Win_Malware_Agnianestealer : FILE
{
	meta:
		description = "Detect the Agniane stealer using strings"
		author = "Sekoia.io"
		id = "704c85b7-8b82-4160-ae1b-fd1054cae8e2"
		date = "2023-08-10"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/win_malware_agnianestealer.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0aa40fcb713ab40711108290e8274d783c1336a2c4c03eba2fcc4a44f2ebe39f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "Agniane.pdb" ascii
		$s2 = "Agniane.exe" wide ascii

	condition:
		( uint16be( 0 ) == 0x4d5a ) and filesize > 100KB and filesize < 3MB and 2 of them
}
rule SEKOIA_Infostealer_Win_Pennywise_Mar23 : FILE
{
	meta:
		description = "Finds PennyWise samples based on strings"
		author = "Sekoia.io"
		id = "9852b7e7-dfff-44e6-9068-d287cc84b069"
		date = "2023-03-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_pennywise_mar23.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "55d7d6894de23af38230eaaff0a38c31d11d3df34aacd21fd93393d266c9357c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$chr01 = "MvgmsudRT3loHygSj1F9K" ascii
		$chr02 = "WebInfidelity2023" ascii
		$chr03 = "PennyWise" ascii
		$str01 = "get_Handle" ascii
		$str02 = "get_Now" ascii
		$str03 = "get_Ticks" ascii
		$str04 = "set_Expect100Continue" ascii
		$str05 = "get_Jpeg" ascii
		$str06 = "set_UseShellExecute" ascii
		$str07 = "get_ProcessName" ascii
		$str08 = "get_UtcNow" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 1 of ( $chr* ) and 5 of ( $str* )
}

rule SEKOIA_Loader_Win_Ninerat
{
	meta:
		description = "Detect the NineRAT instrumentator"
		author = "Sekoia.io"
		id = "b9aa3ddc-7892-402f-b045-182884ee9bad"
		date = "2023-12-12"
		modified = "2024-12-19"
		reference = "https://blog.talosintelligence.com/lazarus_new_rats_dlang_and_telegram/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_ninerat.yar#L4-L37"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "ba8cd92cc059232203bcadee260ddbae273fc4c89b18424974955607476982c4"
		hash = "5b02fc3cfb5d74c09cab724b5b54c53a7c07e5766bffe5b1adf782c9e86a8541"
		logic_hash = "eab81277a2ffe926c2d9f990ee2e36f0e5f27a14d3048c50d31952d90ce7ab0b"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "TelegramRat\\lastest\\Dropper"
		$ = "\\Release\\ServiceMid.pdb"

	condition:
		all of them or pe.imphash ( ) == "104a3dc970a385f64de39e0dad61a9a2" or hash.md5 ( pe.rich_signature.clear_data ) == "aab0aa6b89d883e42be8b65a4e41a139" or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "827d5fd4b1a0426037529ee9bba48da0" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "82354f92508dcb33acda01c226de2975" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "ccd0f5d837a6cc05a861f040cbdfe080" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "8d2c169356afe8b53b0ecb83de3084b9" )
}
rule SEKOIA_Radx_Stealer : FILE
{
	meta:
		description = "detection of RADX stealer based on function named in the .NET payload"
		author = "Sekoia.io"
		id = "bf2aae08-169c-4bc9-a1ac-80f4b79ef6d7"
		date = "2023-12-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/radx_stealer.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b83ca089bb0ea7ad8b0f372de9a95ea9d35514f6a063b63986e6fd25bdc07095"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "get_FileName" ascii fullword
		$s2 = "set_FileName" ascii fullword
		$f1 = "TripleDESCryptoServiceProvider" ascii fullword
		$f2 = "SendBase64ToServer" ascii fullword
		$f3 = "SendCommandOutputToServer" ascii fullword

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize > 500KB and all of them
}
rule SEKOIA_Tool_Inswor_Strings : FILE
{
	meta:
		description = "Detects In-Swor based on strings"
		author = "Sekoia.io"
		id = "99aaad33-510a-41b9-9022-800588c18d6d"
		date = "2024-09-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_inswor_strings.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "c393128a143b2a3397100b4a30c75112"
		logic_hash = "b25072e6a9fa5728c24c91056a221778f5fbc9d8ba7a78a6684cd6755761373e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "open encrypted file error:" ascii
		$ = "open config file error:" ascii
		$ = "payload.ini" ascii

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Guloader_Unpacker_Decoded : FILE
{
	meta:
		description = "GuLoader Unpacker b64 decoded"
		author = "Sekoia.io"
		id = "ca3f4fce-b3a1-4672-a2ca-29ea347eb23d"
		date = "2024-02-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/guloader_unpacker_decoded.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5de4a147b2dea8a144905b7f1786199bfeef3006ac58179409cfd3dcaa116725"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$jumps = {71 01 9b 71 01 9b}
		$s1 = "([String]$"
		$s2 = "For($"
		$s3 = ",[Parameter(Position = 1)] [Type] $"

	condition:
		filesize < 500KB and @jumps < 1000 and 2 of ( $s* )
}
rule SEKOIA_Tool_Rubeus_Strings : FILE
{
	meta:
		description = "Detects Rubeus"
		author = "Sekoia.io"
		id = "df1860d0-ec34-4c2d-bd83-5f16b26d075c"
		date = "2024-03-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_rubeus_strings.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "adc6a5207bb15c8020ca170564ea9066b2c0b0e09839d6838744c623f59153cf"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = ".Ndr.RPC_DISPATCH_TABLE32"
		$ = ".Ndr.RPC_PROTSEQ_ENDPOINT32"
		$ = ".Ndr.RPC_SERVER_INTERFACE32"
		$ = ".Ndr.NDR_EXPR_DESC32"
		$ = "$krb5tgs${0}$*{1}${2}${3}*${4}${5}" wide
		$ = "$krb5asrep$23${0}@{1}:{2}" wide
		$ = "Unable to decrypt the EncTicketPart using key:" wide
		$ = "[*] Target service  : {0:x}" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and 5 of them
}
rule SEKOIA_Tool_Edrsandblast_Kernelcallbacks : FILE
{
	meta:
		description = "Detects EDRSandblast KernelCallbacks strings"
		author = "Sekoia.io"
		id = "74cf4444-5bd6-4167-930a-5dbf2e529f92"
		date = "2024-11-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_edrsandblast_kernelcallbacks.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ffb1185dca42c5b2b273c3a48f3ba86204a3474a9a045f72dbdb0ba7c9e89c7d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[+] '%s' service ACL configured to for Everyone" wide
		$ = "%s callback of EDR driver \"%s\" [callback addr: 0x%I64x" wide
		$ = "[!] Could not resolve %s kernel module's address" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 3MB and 3 of them
}
rule SEKOIA_Apt_Apt41_Keyplug_Dropper : FILE
{
	meta:
		description = "Detects a dropper used by keyplug"
		author = "Sekoia.io"
		id = "b6740371-c4c3-437e-8235-0bd4f7b9c3f5"
		date = "2024-06-12"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt41_keyplug_dropper.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a61f57302d8fe58ed8b77542c94159acbc36a3bd52c204171e76e668d10a74e7"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "C:\\ProgramData\\pfm.ico" wide
		$ = "C:\\\\ProgramData\\\\pfm.ico" wide
		$ = "67f8de349abc5ghi" wide
		$ = "3abc64597f8diegh" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 2MB and any of them
}
rule SEKOIA_Apt_Badmagic_Reco_Pshscript : FILE
{
	meta:
		description = "Detects BadMagic Reco powershell script"
		author = "Sekoia.io"
		id = "7a1b2d31-03b7-4a43-8f4e-ed38ba8e118e"
		date = "2023-05-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_badmagic_reco_pshscript.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "86369267545241f33c6fc7dab11eb06f71641d8e9cd0365ddcc676d4f4c9739b"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "$headers = @{};"
		$ = "==ARP Cache=="
		$ = "ipconfig.me"
		$ = "-ComputerName $env:computername;"

	condition:
		all of them and filesize < 1KB
}

rule SEKOIA_Apt_Spikedwine_Wineloader : FILE
{
	meta:
		description = "Detects vineloader"
		author = "Sekoia.io"
		id = "7a599076-cd9d-42c4-a83a-9a991ede19fb"
		date = "2024-02-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_spikedwine_wineloader.yar#L3-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c71d7ef8cb89d8fcd42e3178a729d912d5fe8e9eb396e46d7a0f5176a9398d75"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$c = { E8 ?? ?? ?? ?? 48 8D 0D
        ?? ?? ?? ?? 48 8D 05 ??
        ?? ?? ?? 48 89 05 ?? ??
        ?? ?? 48 C7 05 ?? ?? ??
        ?? ?? ?? 00 00 48 C7 05
        ?? ?? ?? ?? ?? ?? 00 00 }

	condition:
		pe.is_dll( ) and filesize < 100KB and for any export in pe.export_details : ( $c in ( export.offset..export.offset + 100 ) )
}
rule SEKOIA_Generic_Bat_Script_Mock_Http_Services : FILE
{
	meta:
		description = "Generic rule detecting BAT script using mock HTTP services (used by APT28)"
		author = "Sekoia.io"
		id = "1cfbe5ba-6304-476d-8308-928100a85c16"
		date = "2023-09-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/generic_bat_script_mock_http_services.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "d34be59cfb054895381580e7852bba6b899cfb680882b7fd24a72438131c3bee"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$bat1 = "@echo off"
		$bat2 = "chcp 65001"
		$ps1 = "WebClient"
		$ps2 = "UploadString"
		$dom1 = "mockbin.org"
		$dom2 = "webhook.site"
		$dom3 = "mocky.io"
		$dom4 = "pipedream.com"

	condition:
		(1 of ( $bat* ) or 1 of ( $ps* ) ) and 1 of ( $dom* ) and filesize < 2000
}
rule SEKOIA_Infostealer_Win_Spacestealer : FILE
{
	meta:
		description = "Detects SpaceStealer based on specific strings"
		author = "Sekoia.io"
		id = "aceae3b3-1f5a-48b4-84cb-d0ba68d26df5"
		date = "2022-11-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_spacestealer.yar#L1-L31"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "94edfd0606816ff01d1345357a852cab4321d8881921e51ba96d8d2d4cb893b5"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "spacestealerxD" ascii
		$str02 = "\\spacex" ascii
		$str03 = "@~$~@spacex-" ascii
		$str04 = "StealerClient" ascii
		$str05 = "kill-process-by-name" ascii
		$str06 = "\\BetterDiscord\\data\\betterdiscord.asar" ascii
		$str07 = "api/webhooks" ascii
		$str08 = "discordPath" ascii
		$str09 = "SELECT host_key, name, encrypted_value FROM cookies" ascii
		$str10 = "SELECT origin_url, username_value, password_value FROM logins" ascii
		$str11 = "SELECT name_on_card, expiration_month, expiration_year, card_number_encrypted FROM credit_cards" ascii
		$str12 = "Cookies don't found." ascii
		$str13 = "/api/cookies?auth=" ascii
		$str14 = "/api/passwords?auth=" ascii
		$str15 = "/api/autofill?auth=" ascii
		$str16 = "/api/creditcards?auth=" ascii
		$str17 = "\\Yandex\\YandexBrowser\\User Data\\Guest Profile\\Network\\" ascii

	condition:
		uint16( 0 ) == 0x5A4D and filesize > 10MB and 13 of them
}
rule SEKOIA_Apt_Uac0154_Powershell_Infection_Chain_1 : FILE
{
	meta:
		description = "UAC-0154 Infection chain"
		author = "Sekoia.io"
		id = "428eb021-b37f-4db5-8cab-ca2f6dd2e202"
		date = "2023-10-02"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_uac0154_powershell_infection_chain_1.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a849c397e7f61e41ea7e67a265717d7d66f6af42f3d1e930020d1433dd3aab18"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "command $es ="
		$ = "function isV"
		$ = "doIn;"
		$ = "System.IO.Comp"

	condition:
		all of them and filesize < 100KB
}
rule SEKOIA_Apt_Badmagic_Malicious_Lnk : FILE
{
	meta:
		description = "Detect LNK used by BadMagic to execute MSI payloads."
		author = "Sekoia.io"
		id = "731bd51d-c4e4-4efb-9fa8-f981a8555ed3"
		date = "2023-05-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_badmagic_malicious_lnk.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b83749c71cefb485f8bbea1d465fc477de159e086efa04ebce4d0778a203ed89"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "/i http" wide
		$ = ".msi /quiet" wide
		$ = "%WINDIR%\\System32\\msiexec.exe"

	condition:
		uint32be( 0 ) == 0x4c000000 and filesize < 1KB and all of them
}
rule SEKOIA_Kimsuky_Konni_Dll : FILE
{
	meta:
		description = "Rule based on structure offset and file extension"
		author = "Sekoia.io"
		id = "6a20c492-e932-41bd-ac4a-01d35bfb0c49"
		date = "2022-09-12"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/kimsuky_konni_dll.yar#L1-L29"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "7099156decdfe35cde22958133d851479f12180fff7b5744af0c549ab8259636"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ext_1 = ".zip" wide ascii fullword
		$ext_2 = ".cab" wide ascii fullword
		$ext_3 = ".rar" wide ascii fullword
		$ext_4 = ".ini" wide ascii fullword
		$ext_5 = ".dat" wide ascii fullword
		$offset_structure_1 = { 8d ?? 08 02 00 00 }
		$offset_structure_2 = { 8d ?? 10 04 00 00 }
		$offset_structure_3 = { 8d ?? 18 06 00 00 }
		$offset_structure_4 = { 8d ?? 20 08 00 00 }
		$offset_structure_5 = { 8d ?? 28 0a 00 00 }
		$offset_structure_6 = { 89 ?? f8 11 00 00 }
		$offset_structure_7 = { 8d ?? fc 11 00 00 }
		$offset_structure_8 = { 89 ?? 0c 12 00 00 }
		$offset_structure_9 = { 89 ?? 10 12 00 00 }

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 11MB and all of them
}
rule SEKOIA_Truesightkiller_Avkiller_Strings : FILE
{
	meta:
		description = "TrueSightKiller based on string"
		author = "Sekoia.io"
		id = "8f249ac4-5181-4169-9eb2-7d73ec4fd68d"
		date = "2024-10-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/truesightkiller_avkiller_strings.yar#L1-L45"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "891202963430a4b1dea2dc5b9af01dc5"
		hash = "367af202029bf51fc347a8f414fa2a5c"
		hash = "64439836d69084b129c2dc4264176149"
		hash = "6e69b890b1c228fa4225776b185b5af7"
		hash = "daaf7bdf1e7fd882c0bfb89450ec0ab2"
		hash = "dcf36765ed9386c169eb2695d26f6a6f"
		logic_hash = "829d144023569f332a27b7f2344d2da7be59ae5044a13c299c5da50d896288ed"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[+] Process PID: " wide
		$ = "[-] OpenSCManager failed" wide
		$ = "[+] Creating service: truesight" wide
		$ = "[+] Full path: " wide
		$ = "[-] Error getting current directory." wide
		$ = "[-] CreateService failed" wide
		$ = "[!] Service is already running" wide
		$ = "[-] QueryServiceStatus failed" wide
		$ = "[-] StartService failed" wide
		$ = "[+] Driver loaded successfully!" wide
		$ = "[-] OpenService failed" wide
		$ = "[-] ControlService failed" wide
		$ = "[-] DeleteService failed" wide
		$ = "Welcome to EDR/AV Killer using truesight driver!" wide
		$ = "This is a PoC, use it at your own risk!" wide
		$ = "[-] Failed to set CTRL+C handler. Exiting..." wide
		$ = "ntdll.dll" wide
		$ = "\\\\.\\TrueSight" wide
		$ = "[-] CreateFileA failed" wide
		$ = " not running" wide
		$ = "[-] Process name: " wide
		$ = "[+] Terminating PID: " wide
		$ = "[-] DevicesIoControl failed" wide
		$ = "[!] Stoping and Deleting trueSight Service!" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and filesize > 20KB and 20 of them
}
rule SEKOIA_Hacktool_Socat_Strings : FILE
{
	meta:
		description = "Detects socat"
		author = "Sekoia.io"
		id = "7c7e4085-39b2-445e-a9ff-52f21936e714"
		date = "2023-12-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_socat_strings.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8f0c907fa2de4141c55073ea5b4a8174f50c716fc7a60d3e838115859a938084"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[options] <bi-address> <bi-address>"
		$ = "version %s on %s"
		$ = "socat_signal():"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 5MB and all of them
}

rule SEKOIA_Wiper_Hermeticwiper_Variants
{
	meta:
		description = "Matches HermeticWiper and possible variants"
		author = "Sekoia.io"
		id = "102ecf15-167e-49e4-932c-6334e3cdcc69"
		date = "2022-02-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/wiper_hermeticwiper_variants.yar#L3-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "d0c358517b0a6334d430d3bd75d6c58243ce84e0f90afe48a5069a1e1954119c"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "SeLoadDriverPrivilege" wide
		$ = "\\\\.\\PhysicalDrive" wide
		$ = "::$INDEX_ALLOCATION" wide
		$ = "CrashDumpEnabled" wide

	condition:
		2 of them and pe.characteristics and pe.number_of_signatures == 1 and pe.number_of_resources > 2 and for 2 i in ( 0 .. pe.number_of_resources - 1 ) : ( uint32be( pe.resources [ i ] . offset + 15 ) == 0x4D5A9000 and uint16be( pe.resources [ i ] . offset ) == 0x535A )
}
rule SEKOIA_Apt_Mustangpanda_Malicious_Lnk_Worm : FILE
{
	meta:
		description = "Detects MustangPanda infected ThumbDrive"
		author = "Sekoia.io"
		id = "e7cc5ecc-2369-49ff-9e35-c9faeb69acda"
		date = "2023-09-21"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_mustangpanda_malicious_lnk_worm.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ca19a925af695cbbb41fdfbb161dceafeb8aae6d42000cc09bb07e1dbdfdb9e5"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "RECYCLER.BIN\\1\\CEFHelper.exe" wide

	condition:
		uint32be( 0 ) == 0x4C000000 and 1 of them
}
rule SEKOIA_Dropper_Mac_Lazarus_Manuscrypt : FILE
{
	meta:
		description = "MacOS Manuscrypt dropped by TraderTraitor"
		author = "Sekoia.io"
		id = "6138bd0c-1fcf-4586-b2b6-29955c7d6266"
		date = "2022-04-19"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/dropper_mac_lazarus_manuscrypt.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "dced1acbbe11db2b9e7ae44a617f3c12d6613a8188f6a1ece0451e4cd4205156"
		hash = "9d9dda39af17a37d92b429b68f4a8fc0a76e93ff1bd03f06258c51b73eb40efa"
		logic_hash = "dbe75a34f91906fc275c04af0fc068923993bab37a7574b3fe38733d87f31835"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "networksetup -getwebproxy '%s'" ascii
		$ = "Cookie: _ga=%s%02d%d%d%02d%s" ascii
		$ = "networksetup -listallnetworkservices" ascii
		$ = "gid=%s%02d%d%03d%s" ascii

	condition:
		uint32( 0 ) == 0xFEEDFACF and all of them
}
rule SEKOIA_Apt_Mustangpanda_Zpakage : FILE
{
	meta:
		description = "Detect obfuscation seen in ZPAKAGE"
		author = "Sekoia.io"
		id = "a4767d12-5058-4a26-be62-0cec685917bd"
		date = "2023-03-27"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_mustangpanda_zpakage.yar#L1-L31"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "711c0e83f4e626a7b54e3948b281a71915a056c5341c8f509ecba535bc199bee"
		logic_hash = "52ad51589ca154fbf6e5829a2c80a9b811809288bed6995820a0ca8aa218d8ef"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$chunk_1 = {
        88 94 1D ?? ?? ?? ??
        8A 84 1D ?? ?? ?? ??
        83 ?? ??
        88 84 1D ?? ?? ?? ??
        8A 84 1D ?? ?? ?? ??
        83 ?? ??
        88 84 1D ?? ?? ?? ??
        8A 84 1D ?? ?? ?? ??
        83 ?? ??
        88 84 1D ?? ?? ?? ??
        0F BE 8C 1D ?? ?? ?? ??
        0F BE 84 1D ?? ?? ?? ??
        }

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 1MB and filesize < 11MB and #chunk_1 > 20
}
rule SEKOIA_Malware_Valleyrat_Downloader_Strings : FILE
{
	meta:
		description = "Detects ValleyRat downloader"
		author = "Sekoia.io"
		id = "12985f34-f894-402b-80d1-5d6b2486d730"
		date = "2024-06-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/malware_valleyrat_downloader_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "321683ac5bdec626cf140cb50507fb03aea2a32635eb6cec884a3fa43c1a9d91"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = { 43 00 3a 00 5c [0-30]
        5c 00 4e 00 54 00 55
        00 53 00 45 00 52 00
        2e 00 44 00 58 }

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 2MB and all of them
}
rule SEKOIA_Tool_Win_Driverjack : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "08bc0fe8-38f1-4c73-99c8-2659b4a55815"
		date = "2024-09-11"
		modified = "2024-12-19"
		reference = "https://github.com/klezVirus/DriverJack/blob/master/DriverJack"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_win_driverjack.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "649fc12915bdcdebbc3798a8ad0b9b32"
		logic_hash = "0ea81c32b75ff66434f0c949be7d1478ce9268eb1b67dc5b7d6c7604cedcd72c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "(*) Decrypting %llu bytes of file content using key '%s' of length %u..."
		$ = "(*) Modifying file %s in mapped drive..."
		$ = "(*) Checking file %s in mapped drive..."
		$ = "(-) CreateProcess failed '%s' (%08x)."
		$ = "(*) Mounted Drive Letter: %s"

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Stealer_Win_Mgbot_Credential_Stealer : FILE
{
	meta:
		description = "Detect MgBot credential stealer plugin"
		author = "Sekoia.io"
		id = "e06501c1-c842-43f7-a429-9026bc0a4fd4"
		date = "2024-03-20"
		modified = "2024-12-19"
		reference = "https://www.welivesecurity.com/2023/04/26/evasive-panda-apt-group-malware-updates-popular-chinese-software/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/stealer_win_mgbot_credential_stealer.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "174a62201c7e2af67b7ad37bf7935f064a379f169cf257ca16e912a46ecc9841"
		hash = "cb7d9feda7d8ebfba93ec428d5a8a4382bf58e5a70e4b51eb1938d2691d5d4a5"
		logic_hash = "27f1b0ac818753804f0e67ac158d9376ab6beff8613ef94a1aa6cf8dd6815d49"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Software\\Aerofox\\Foxmail\\Indenties" wide
		$ = "Software\\Aerofox\\FoxmailPreview" wide
		$ = "IMAP Password" wide
		$ = "POP3 Password" wide

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Infostealer_Win_Stormkitty : FILE
{
	meta:
		description = "Finds StormKitty samples (or their variants) based on specific strings"
		author = "Sekoia.io"
		id = "5014d2e5-af5c-4800-ab1e-b57de37a2450"
		date = "2023-03-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_stormkitty.yar#L1-L31"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "57a4603faf6af9742db79f9bc8751f3a5c091b6271998434f0a3b9f5c30cb1e8"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$sk01 = "LimerBoy/StormKitty" ascii wide
		$sk02 = "StormKitty-Latest.log" wide
		$sk03 = "StormKitty.exe" ascii
		$sk04 = "Debug\\StormKitty.pdb" ascii
		$sk05 = "StormKitty.Implant" ascii
		$str01 = "set_sUsername" ascii
		$str02 = "set_sIsSecure" ascii
		$str03 = "set_sExpMonth" ascii
		$str04 = "WritePasswords" ascii
		$str05 = "WriteCookies" ascii
		$str06 = "sChromiumPswPaths" ascii
		$str07 = "sGeckoBrowserPaths" ascii
		$str08 = "Username: {1}" wide
		$str09 = "Password: {2}" wide
		$str10 = "encrypted_key\":\"(.*?)\"" wide

	condition:
		uint16( 0 ) == 0x5A4D and ( ( 1 of ( $sk* ) and 3 of ( $str* ) ) or 7 of ( $str* ) )
}
rule SEKOIA_Apt_Konni_Check_Bat : FILE
{
	meta:
		description = "Script used to performs check before executing Konni"
		author = "Sekoia.io"
		id = "f05e6ba2-c128-4c17-8f74-f7640103c859"
		date = "2023-11-27"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_konni_check_bat.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "13a9dd6978985eb17960794c6de2ee2e6411e6afeb705ff95ced72bc0efb5d8c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = ":64BIT"
		$ = ":32BIT"
		$ = ":INSTALL"
		$ = ":EXIT"
		$ = "netpp.dll"
		$ = "wpns.dll"
		$ = "netpp64.dll"
		$ = "wpns64.dll"
		$ = "rundll32"

	condition:
		filesize < 1MB and 7 of them
}
rule SEKOIA_Tool_Swor : FILE
{
	meta:
		description = "Detects swor"
		author = "Sekoia.io"
		id = "75ce2ed7-2972-4e04-98dc-451acf80c842"
		date = "2024-09-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_swor.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "d3f92b3349109fc6de26f5e40800fec15308c27fa4fe81fe42af5030637a3a63"
		logic_hash = "bcd1c0afece740b82b606aad8bdebcc88b72ae61df6513318215a217021efab4"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$old_sword_s1 = "Failed to open payload file: "
		$old_sword_s2 = "Failed to open config file: "
		$sword_s1 = "open encrypted file error: "
		$sword_s2 = "open config file error: "
		$enum_calendar = "EnumCalendarInfo"

	condition:
		uint16be( 0 ) == 0x4d5a and $enum_calendar and ( 2 of ( $old_sword_s* ) or 2 of ( $sword_s* ) ) and filesize < 1MB and true
}
rule SEKOIA_Infostealer_Win_Nemesis_In_Memory : FILE
{
	meta:
		description = "Finds Nemesis Stealer samples based on specific strings, from samples without strings obsucation, or from memory"
		author = "Sekoia.io"
		id = "01d85bd5-ea93-44ff-b36a-9cd9eb54d634"
		date = "2023-03-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_nemesis_in_memory.yar#L1-L27"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "65d2dd9a10238e6d65d8992aa9cc145f73bcba9be49ed552f8b0c44723ec4c87"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "NemesisProject.Modules." ascii
		$str02 = "~[NEMESIS INIZIALIZE]~" wide
		$str03 = "Clip_BoardText.txt" wide
		$str04 = "stealer_out.zip" wide
		$str05 = "<span style=\"color:#FFFFFF\">Number of running processes:</span>" wide
		$str06 = "<span style=\"color:#FFFFFF\">Installed FireWall: </span>" wide
		$str07 = "~[Panel_Receiving_Data]~ Incorrect data when receiving data on the panel" wide
		$str08 = "ProcessInfo_Log.txt" wide
		$str09 = "Installed_Software_Log.txt" wide
		$str10 = "Detect Data ClipBoard] - [ {DateTime.Now:MM.dd.yyyy - HH:mm:ss}]" wide
		$str11 = "VPN/ProtonVPN_Log.txt" wide
		$str12 = "VPN/Nord_Log.txt" wide
		$str13 = "Steam/SteamID_Log.txt" wide

	condition:
		uint16( 0 ) == 0x5A4D and 6 of them
}
rule SEKOIA_Apt_Muddywater_Rotrot_Strings : FILE
{
	meta:
		description = "Detects RotRot backdoor based on strings"
		author = "Sekoia.io"
		id = "f7bc195a-0e60-4495-b78a-78f101543700"
		date = "2024-06-10"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_muddywater_rotrot_strings.yar#L1-L36"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "425168003d0f14d791e7f46bf47c18652a1f6b66b9329155d2bca72cf0d8126b"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "qsphsbnebub"
		$s2 = "rtqitcofcvc"
		$s3 = "surjudpgdwd"
		$s4 = "tvskveqhexe"
		$s5 = "uwtlwfrifyf"
		$s6 = "vxumxgsjgzg"
		$t1 = "MpbeMjcsbs"
		$t2 = "NqcfNkdtct"
		$t3 = "OrdgOleudu"
		$t4 = "PsehPmfvev"
		$t5 = "QtfiQngwfw"
		$t6 = "RugjRohxgx"
		$u1 = "UfsnjobufKpcPckfdu"
		$u2 = "VgtokpcvgLqdQdlgev"
		$u3 = "WhuplqdwhMreRemhfw"
		$u4 = "XivqmrexiNsfSfnigx"
		$u5 = "YjwrnsfyjOtgTgojhy"
		$u6 = "ZkxsotgzkPuhUhpkiz"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize > 100KB and filesize < 300KB and any of ( $s* ) and any of ( $t* ) and any of ( $u* )
}

rule SEKOIA_Loader_Win_Jennlog
{
	meta:
		description = "Jennlog loader used to deliver the Apostle ransomware"
		author = "Sekoia.io"
		id = "a69088e5-207f-494f-876b-766b8050e8c2"
		date = "2021-10-04"
		modified = "2024-12-19"
		reference = "https://www.sentinelone.com/labs/new-version-of-apostle-ransomware-reemerges-in-targeted-attack-on-higher-education/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_jennlog.yar#L4-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0ffcd1f35570b28a1bd6f9a0361f8f921942f7345dcb2896fc092bb92f7d4d6d"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		pe.timestamp== 3140259112 or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "4c4577276ff0323d9aedcc39ecf2c964" ) or for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "8476a7fca587f1e5d3ae076293b9fbcccbebc4bd4f7b783228ad5da39305a3d9" )
}
rule SEKOIA_Apt_Sandworm_Caddywiper_Stacked_Strings : FILE
{
	meta:
		description = "Detects stacked strings used in the wiper."
		author = "Sekoia.io"
		id = "7750c4b6-5781-4b1c-8200-cbce9f18aa56"
		date = "2022-04-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_sandworm_caddywiper_stacked_strings.yar#L1-L74"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e8c94e8611a50080368785d2b341a95d5359d1d814e1d665553324118700ed10"
		score = 75
		quality = 80
		tags = "FILE"
		version = "2.0"
		classification = "TLP:CLEAR"

	strings:
		$ = { C6 45 ?? 6E
        C6 45 ?? 65
        C6 45 ?? 74
        C6 45 ?? 61
        C6 45 ?? 70
        C6 45 ?? 69
        C6 45 ?? 33
        C6 45 ?? 32
        C6 45 ?? 2E
        C6 45 ?? 64
        C6 45 ?? 6C
        C6 45 ?? 6C }
		$ = {  C6 45 ?? 44
        C6 45 ?? 65
        C6 45 ?? 76
        C6 45 ?? 69
        C6 45 ?? 63
        C6 45 ?? 65
        C6 45 ?? 49
        C6 45 ?? 6F
        C6 45 ?? 43
        C6 45 ?? 6F
        C6 45 ?? 6E
        C6 45 ?? 74
        C6 45 ?? 72
        C6 45 ?? 6F
        C6 45 ?? 6C }
		$ = { C6 45 ?? 5C
        C6 45 ?? 00
        C6 45 ?? 5C
        C6 45 ?? 00
        C6 45 ?? 2E
        C6 45 ?? 00
        C6 45 ?? 5C
        C6 45 ?? 00
        C6 45 ?? 50
        C6 45 ?? 00
        C6 45 ?? 48
        C6 45 ?? 00
        C6 45 ?? 59
        C6 45 ?? 00
        C6 45 ?? 53
        C6 45 ?? 00
        C6 45 ?? 49
        C6 45 ?? 00
        C6 45 ?? 43
        C6 45 ?? 00
        C6 45 ?? 41
        C6 45 ?? 00
        C6 45 ?? 4C
        C6 45 ?? 00
        C6 45 ?? 44
        C6 45 ?? 00
        C6 45 ?? 52
        C6 45 ?? 00
        C6 45 ?? 49
        C6 45 ?? 00
        C6 45 ?? 56
        C6 45 ?? 00
        C6 45 ?? 45 }

	condition:
		uint16be( 0 ) == 0x4d5a and 2 of them
}
rule SEKOIA_Generic_Sharpshooter_Payload_3 : FILE
{
	meta:
		description = "Detects payload created by SharpShooter"
		author = "Sekoia.io"
		id = "57b3ca9a-59c5-4b28-8eb9-36ff5b3633c2"
		date = "2023-02-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/generic_sharpshooter_payload_3.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ef62075c804080c0450f856b768da84a32f20e2f1ce5714e477b3e6f01d60503"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Function RC4(byteMessage, strKey)"
		$ = "Sub Run()"
		$ = "plain = RC4(decoded, "
		$ = "Dim plain"

	condition:
		all of them and filesize < 2MB
}

rule SEKOIA_Apt_Mustang_Panda_Toneins : FILE
{
	meta:
		description = "Detect the TONEINS implant used by Mustang Panda"
		author = "Sekoia.io"
		id = "f178217a-ff28-4dd7-9395-f19f3e2e934c"
		date = "2022-11-28"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_mustang_panda_toneins.yar#L4-L44"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b71932f16ffb1d8d1780b6f9b4db2f0c98d1c770829a4d2284e78c19d37e54bb"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$rtti1 = ".?AVDNameNode@@"
		$rtti2 = ".?AVcharNode@@"
		$rtti3 = ".?AVpcharNode@@"
		$rtti4 = ".?AVpDNameNode@@"
		$rtti5 = ".?AVDNameStatusNode@@"
		$rtti6 = ".?AVpairNode@@"
		$s1 = "DefWindowProcW1222_test" wide ascii
		$s2 = "schtasks /create /sc minute /mo 2 /tn" wide ascii
		$fnv_CreateFile = {CE C9 CA BD}
		$fnv_GetFileSize = {18 81 ED 44}
		$fnv_ReadFile = {43 C9 FC 54}
		$fnv_CloseHandle = {65 00 BA FA}
		$fnv_WriteFile = {4A C4 07 7F}
		$fnv_CreateEventA = {E2 DD D2 F9}
		$fnv_TerminateProcess = {59 EE 4E F8}
		$fnv_GetCurrentProcess = {45 A8 D8 6D}
		$fnv_CreateProcessA = { 09 0A 7C 4A}

	condition:
		uint16be( 0 ) == 0x4d5a and 4 of ( $rtti* ) and filesize < 8MB and ( for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "69f400d3ff4679294e63fb8a8ca97dbb" ) or ( all of ( $s* ) and 5 of ( $fnv* ) ) )
}
rule SEKOIA_Apt_Mustangpanda_Tinynote : FILE
{
	meta:
		description = "Detects strings in TinyNote backdoor"
		author = "Sekoia.io"
		id = "a2b9bea4-a211-456f-8a3f-0f31733e8b29"
		date = "2023-06-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_mustangpanda_tinynote.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "20723b449d057ddf09fa34aa7511275939f98c6c84593af64d99f980c679b2c1"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "bypassSMADAV" ascii fullword
		$s2 = "excuteCmdLine" ascii fullword
		$s3 = "/Create1953125" ascii
		$s4 = "MINUTEMonday" ascii
		$s5 = "WndProc" ascii

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 8MB and all of them
}
rule SEKOIA_Apt_Gobrat_2 : FILE
{
	meta:
		description = "Detects GobRat related files"
		author = "Sekoia.io"
		id = "6b7e38f5-00bc-49c8-b34d-3e878bf426d8"
		date = "2024-09-10"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gobrat_2.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "9f2fdbe2cc39c91b2ac8904fb29a0142bf770859d17590017920203641860a13"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "thisisweird" ascii
		$ = "ZzZzZzZzZzZz"

	condition:
		all of them and uint32be( 0 ) == 0x7f454c46
}
rule SEKOIA_Apt_Kimsuky_Malicious_Vba : FILE
{
	meta:
		description = "Detects malicious VBA used by Kimsuky"
		author = "Sekoia.io"
		id = "2dbe2431-3592-4395-8164-49abae4a5a3d"
		date = "2022-08-30"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_kimsuky_malicious_vba.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "68d7b757f660907fcea3ea03c4027b429f8acdef6569d63cdb744e9d77637080"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Certutil -decode %TMP%"
		$ = "%LOCALAPPDATA%\\Microsoft\\Office"

	condition:
		uint32be( 0 ) == 0xD0CF11E0 and filesize < 1MB and all of them
}
rule SEKOIA_Ransomware_Win_Honkai_Jan2023 : FILE
{
	meta:
		description = "Rule to detect Honkai ransomware samples."
		author = "Sekoia.io"
		id = "6ef91cb5-e122-4f91-bc15-3813b8f91cbf"
		date = "2023-02-13"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_win_honkai_jan2023.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "989cf96da60d9ebfb6f364717b4f0cae1667fdc7f9d89f77acc254ab47d439e6"
		logic_hash = "19f831f77e043f11b790b7f24e9f585e4986d9af6580bae7c344b7960f2f0965"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "DP_Main.exe" ascii wide
		$s2 = "DP_MainForm" ascii wide
		$s3 = "DP_Main" ascii wide
		$s4 = "#DECRYPT MY FILES#.html" ascii wide
		$s5 = "/api/Encrypted.php" ascii wide
		$s6 = "http://upload.paradisenewgenshinimpact.top:2095" ascii wide
		$s7 = "main@paradisenewgenshinimpact.top" ascii wide
		$s8 = ".honkai" ascii wide

	condition:
		uint16be( 0 ) == 0x4d5a and 6 of them
}
rule SEKOIA_Apt_Cloudatlas_Init_Module_Virtualalloc : FILE
{
	meta:
		description = "Find init module of CloudAtlas with params passed to VirtualAlloc"
		author = "Sekoia.io"
		id = "299ed681-9d1f-4b47-8389-ff5a608f49d4"
		date = "2023-09-19"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_cloudatlas_init_module_virtualalloc.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "02a1a9582f5ccf421b08c41c35049416b9cdefc9228daf6b38d95e9b0930cc5a"
		hash = "c7f19c7c295c86867ea7fa4597ba0cebe12f751753866e7298fd5d84676facc3"
		logic_hash = "31ffaeccc0b8fe36eea3b3a8200eff6a420b1a3937fd439dc84121654fcea502"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$chunk_1 = {
        6A 40
        68 00 30 10 00
        8B 8D ?? ?? ?? ??
        8B 51 50
        52
        6A 00
        FF 15 ?? ?? ?? ??
        }

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and $chunk_1 and filesize < 3MB
}
rule SEKOIA_Keylogger_Win_Donot
{
	meta:
		description = "Detect the DoNot's keylogger malware"
		author = "Sekoia.io"
		id = "4f67dda7-da68-4496-a8b4-a8a769ddd763"
		date = "2023-03-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/keylogger_win_donot.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "eb935f84335e934346511b4108f70df469deef6ecaaba809c144197c04a28f64"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "iwrct2mTFAu0ew1nyqQgoaNtNo0+52R0XiTKbwy1W48Bn1b2YcNt0+tptyY6oGoAeLDGekM/yHcdikNGi8bLqkUQ8CIdkWeT3QiympOTfjs="
		$ = "ZmVwZW9kbWZ2c24ucHMuZ3h4LngweXBvdWpkYm1qcXE7YnFmVXp1LmZvb3VEcA=="

	condition:
		1 of them
}
rule SEKOIA_Apt_Unc4990_Explorer_Ps1_Reverse_B64 : FILE
{
	meta:
		description = "Detects reverse base64 files (explorer.ps1)"
		author = "Sekoia.io"
		id = "35c3ffb2-2ced-426c-ac3f-a8cd0c357672"
		date = "2024-02-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_unc4990_explorer_ps1_reverse_b64.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "bf13fbf2dbe6a718510f3e435a9fe06517ed962f8e129d79a15e6a301e5713ca"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s0 = "Invoke-Expression ([System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String(\""
		$s1 = "Wa1VHJ\"[-1..-"
		$s2 = "-join '')))"

	condition:
		all of them and $s0 at 0 and @s2 - @s2 < 20
}
rule SEKOIA_Hacktool_Win_Uknowseckeylogger : FILE
{
	meta:
		description = "Detect the uknowsec keylogger based on strings"
		author = "Sekoia.io"
		id = "ab08136d-b1f3-4e64-b73c-e6344b610f91"
		date = "2022-10-05"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_win_uknowseckeylogger.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "83a731a5b1853edcce963d458fc170206086305f3e43403c930c9633918e8ff1"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str0 = "github.com/atotto/clipboard" ascii
		$str1 = "github.com/TheTitanrain/w32" ascii
		$str2 = "github.com/aliyun/aliyun-oss-go-sdk" ascii
		$str3 = "golang.org/x/sys" ascii
		$str4 = "golang.org/x/time" ascii
		$str5 = "WSARecvWSASend[Print][Right][Shift][Sleep][debug][error]" ascii

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}

rule SEKOIA_Apt_Muddywater_Moriagent : FILE
{
	meta:
		description = "Detects Muddy's Mori Agent implant"
		author = "Sekoia.io"
		id = "e7a83663-6a30-416a-8f29-87a6b9445ea4"
		date = "2022-01-14"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_muddywater_moriagent.yar#L3-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "21389d4e71e9a19a9d263b8ced740c337ea88ed4ac97199897b0aa3f5914594a"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$mut = "0x50504060" ascii fullword
		$cmd1 = "TType" ascii fullword
		$cmd2 = "TPath" ascii fullword
		$cmd3 = "TFileid" ascii fullword
		$cmd4 = "TCommand" ascii fullword
		$cmd5 = "TTimeout" ascii fullword
		$cmd6 = "TFilter" ascii fullword

	condition:
		uint16be( 0 ) == 0x4d5a and ( ( pe.number_of_exports == 2 and pe.exports ( "DllRegisterServer" ) and pe.exports ( "DllUnregisterServer" ) ) and ( 5 of them ) )
}

rule SEKOIA_Wiper_Win_Isaacwiper
{
	meta:
		description = "Detect the IsaacWiper using multiple methods + ReversingLab rule's condition"
		author = "Sekoia.io"
		id = "b081e3a3-612e-46ae-93af-82e7ee98fcf7"
		date = "2022-03-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/wiper_win_isaacwiper.yar#L4-L45"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0338e11ece112b6f7d88db49cfc703a4431d7ee54f4b9ff0b9e2ea50d39cab4f"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "getting drives..." wide
		$s2 = "physical drives:" wide
		$s3 = "-- system physical drive" wide
		$s4 = "-- physical drive" wide
		$s5 = "logical drives:" wide
		$s6 = "-- system logical drive:" wide
		$s7 = "-- logical drive:" wide
		$s8 = "start erasing physical drives..." wide
		$s9 = "-- FAILED" wide
		$s10 = "-- start erasing logical drive" wide
		$s11 = "start erasing system physical drive..." wide
		$s12 = "system physical drive -- FAILED" wide
		$s13 = "start erasing system logical drive" wide

	condition:
		pe.imphash( ) == "a4b162717c197e11b76a4d9bc58ea25d" or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "06d63fddf89fae3948764028712c36d6" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "48f101db632bb445c21a10fd5501e343" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "5efc98798d0979e69e2a667fc20e3f24" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "9676f7c827fb9388358aaba3e4bd0cc6" ) or hash.md5 ( pe.rich_signature.clear_data ) == "ec862d3013903478c2ff8dce2792815f" or all of ( $s* )
}
rule SEKOIA_Infostealer_Win_44Caliber : FILE
{
	meta:
		description = "Finds samples of the 44Caliber stealer"
		author = "Sekoia.io"
		id = "44e5bbc1-f442-47d3-8431-25182f38439d"
		date = "2022-03-08"
		modified = "2024-12-19"
		reference = "https://github.com/razexgod/44CALIBER"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_44caliber.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "4b80d6b2116f53926897aa79a7c232413974caefaf524f50e6a7cede11f3aaa0"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str0 = "44 CALIBER" fullword ascii
		$str1 = "https://api.vimeworld.ru/user/name/" wide
		$str2 = "https://freegeoip.app/xml/" wide
		$str3 = "SOFTWARE\\Wow6432Node\\Valve\\Steam" wide
		$str4 = "VPN\\NordVPN\\\\accounts.txt" wide
		$str5 = "OpenVPN Connect\\profiles" wide
		$str6 = "FuckTheSystem Copyright" wide
		$str7 = "lolz.guru" wide
		$str8 = "xss.is" wide
		$str9 = "Test message recieved successfully! :raised_hands:" wide
		$str10 = "Specify a single character: either D or F" wide

	condition:
		uint16( 0 ) == 0x5A4D and 9 of ( $str* ) and filesize > 100KB and filesize < 1MB
}
rule SEKOIA_Tool_Exploit_Badpotato_Strings : FILE
{
	meta:
		description = "Detects BadPotato compiled exploit"
		author = "Sekoia.io"
		id = "079aabbc-6978-4d71-92d2-d2a7ce1cc915"
		date = "2022-09-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_exploit_badpotato_strings.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a45935ea5877a4b81468cbe0e1a4a7232b955771442f84bb3b88b7992ed23937"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "RpcStringBindingCompose failed with status 0x" wide
		$ = "RpcBindingFromStringBinding failed with status 0x" wide
		$ = "RpcBindingSetAuthInfoEx failed with status 0x" wide
		$ = "RpcBindingSetOption failed with status 0x" wide
		$ = "\\\\.\\pipe\\{0}\\pipe\\spoolss" wide
		$ = "[*] {0} Success! ProcessPid:{1}" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and 5 of them
}
rule SEKOIA_Apt_Cloudmensis_Downloader_Strings : FILE
{
	meta:
		description = "Detects CloudMensis downloader"
		author = "Sekoia.io"
		id = "450cfa42-7b56-4d93-afe2-9cf5c1049217"
		date = "2022-07-26"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_cloudmensis_downloader_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "9532530f9b6c39d64611354f5d3c95e7c8b9ebf917ab797c162c3b51945db1fc"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "https://api.pcloud.com/getfilelink?path=%@&forcedownload=1"
		$ = "python -c 'import os; print(os.confstr(65538))'"
		$ = "getCmdResult:"
		$ = "[pCloud DownloadFile:]"

	condition:
		uint32be( 0 ) == 0xcafebabe and filesize < 1MB and all of them
}
rule SEKOIA_Apt_Implant_Xdealer_Strings : FILE
{
	meta:
		description = "Detects XDealer based on strings"
		author = "Sekoia.io"
		id = "06ef72ca-b4e3-493b-8e01-d34b98259c6d"
		date = "2024-03-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_implant_xdealer_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "13c0bbc933f68164b0fe1c2768148bb649b1755bed0cfbc6ed90188fab6876d5"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "unknow_PC"
		$ = "rdp-tcp#"
		$ = "Din_%s_%s_%u_"
		$ = "nslookup %s %s"
		$ = "XFByb2dyYW1EYXRhXA=="

	condition:
		uint16be( 0 ) == 0x4d5a and 3 of them and filesize < 1MB
}
rule SEKOIA_Apt_Toddycat_Waexp_Strings : FILE
{
	meta:
		description = "Detects WAExp based on strings"
		author = "Sekoia.io"
		id = "1bbb3e81-14a9-4bda-b647-b6f5255e9a16"
		date = "2024-04-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_toddycat_waexp_strings.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "4377183b326329fb14ae3911fbb1e29cde220d7b247d048fba4bbbda9de8938d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[>] Profile:" wide ascii
		$ = "[+] All Done" wide ascii
		$ = "[+] Files:" wide ascii

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and all of them and filesize < 1MB
}

rule SEKOIA_Downloader_Win_Fake_Tor_Browser
{
	meta:
		description = "Detect fake TOR browser used to spy Chinese TOR users"
		author = "Sekoia.io"
		id = "6b070ba6-490b-43c2-9a01-65812d829eeb"
		date = "2022-10-05"
		modified = "2024-12-19"
		reference = "https://securelist.com/onionpoison-infected-tor-browser-installer-youtube/107627/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/downloader_win_fake_tor_browser.yar#L4-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5fe60673e54a6904f4fd068b04b950b895b18e7766d2e7343eae2b1bba9591f9"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "7172f95f934574be95c0250fb42b8f51" )
}
rule SEKOIA_Platypus_Winlinmac_Strings : FILE
{
	meta:
		description = "Catch Platypus based on strings"
		author = "Sekoia.io"
		id = "4519448d-b91b-4794-9521-359b8cf4af78"
		date = "2023-12-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/platypus_winlinmac_strings.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "3c8e928fb8328381997230d4b60de20d07a9a3aee006aad9fc0b67fcfe61a63b"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$pl1 = "platypus.go" ascii
		$pl2 = "Platypus/lib/context/server.go" ascii
		$pl3 = "Platypus/lib/context/context.go" ascii
		$pl4 = "Platypus/lib/context/client.go" ascii
		$pl5 = "github.com/WangYihang/" ascii
		$f1 = "reflection/reflection.go" ascii
		$f2 = "socksUsernamePassword" ascii
		$go = "/golang" ascii

	condition:
		uint32( 0 ) == 0x464c457f and 4 of ( $pl* ) and 1 of ( $f* ) and #go > 30
}
rule SEKOIA_Implant_Lin_Lightning : FILE
{
	meta:
		description = "Detect the Lightning framework (Core & Downloader plugin)"
		author = "Sekoia.io"
		id = "56f53e89-3b63-4ce7-a3c8-da0ba37246f1"
		date = "2022-07-21"
		modified = "2024-12-19"
		reference = "https://www.intezer.com/blog/research/lightning-framework-new-linux-threat/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_lin_lightning.yar#L1-L27"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "215eea8275fa69a901f6413b334d2824086098e9a9bb2cffd7cb9df5c869be4c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "{\"ComputerName\":\"%s\",\"Guid\":\"%s\",\"RequestName\":\"%s\",\"Licence\":\"%s\"}"
		$ = "kill -9 %s"
		$ = "{%08X-%04X-%04X-%04X-%04X%04X%04X}"
		$ = "sleep 60 && ./%s &"
		$ = "cat /sys/class/net/%s/address"
		$ = "/usr/bin/netstat"
		$ = "/usr/bin/whoami"
		$ = "/usr/bin/su"
		$ = "dup2: %s"
		$ = "Linux.Plugin.Kernel_%s"
		$ = "Lightning"

	condition:
		uint32( 0 ) == 0x464c457f and 9 of them
}

rule SEKOIA_Tool_Pchunter_And_Related_Certificate : FILE
{
	meta:
		description = "Detects PCHunter and associated binairies & drivers"
		author = "Sekoia.io"
		id = "757c7738-4ee8-4b4e-bdda-0c5b0c010f40"
		date = "2022-09-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_pchunter_and_related_certificate.yar#L3-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "924a85b2eaec73b628e705b3bb2e464582a71c19317d2023b1422b1b8ad97a51"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		uint16be( 0 ) == 0x4d5a and for any i in ( 0 .. pe.number_of_signatures ) : ( pe.signatures [ i ] . serial contains "05:51:bc:8c:6a:a2:ca:03:2b:c6:71:38:30:d8:49:a3" ) and filesize > 400KB and filesize < 20MB
}

rule SEKOIA_Apt_Apt33_Tickler : FILE
{
	meta:
		description = "Detects APT33 Tickler malware"
		author = "Sekoia.io"
		id = "e9ecf678-350c-47d2-ab4c-522974c70a45"
		date = "2024-08-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt33_tickler.yar#L4-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "8bd712b0a49f4fecd39d30ebd121832c"
		hash = "3f29429fce0168748d7cc75e1478aedc"
		logic_hash = "97b858819a1920e6dcdd1a9489754a948de8e6e39b4282e7fe4f6431617a9849"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		uint16be( 0 ) == 0x4d5a and ( hash.md5 ( pe.rich_signature.clear_data ) == "2fe65623e6b22577516a4cd051ec3baa" or pe.imphash ( ) == "a5accd1a0d3eaf2c131bc662dd7ff8ea" )
}
rule SEKOIA_Apt_Cloudatlas_Powershower_Clean : FILE
{
	meta:
		description = "Detects clean version of PowerShower"
		author = "Sekoia.io"
		id = "4a7c37df-3f53-4190-a86f-94bba3df628e"
		date = "2022-12-05"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_cloudatlas_powershower_clean.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "24ea6ec0cd8dbcebdf7e42dbd48319562d8682fefd5d0d464a3a5c4b90be40f3"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[io.file]::WriteAllBytes($zipfile" ascii wide
		$ = "System.IO.File]::Exists($p_t" ascii wide
		$ = "HttpRequestP" ascii wide
		$ = "$http_request.getOption(2)" ascii wide
		$ = "HttpRequestP($url)" ascii wide

	condition:
		uint8( 0 ) == 0x24 and filesize < 4000 and 4 of them
}
rule SEKOIA_Apt_Badmagic_Commonmagic_Screenshot_Module : FILE
{
	meta:
		description = "Detects CommonMagic related implants"
		author = "Sekoia.io"
		id = "d1ef0bd1-37dc-405f-b82b-288b1798455c"
		date = "2023-05-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_badmagic_commonmagic_screenshot_module.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "caab57534a00620974f7d49c7b38a3f191aca596b69b3e4c499e3099023c2f9c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "%s_%02d.%02d.%04d_%02d.%02d.%02d.%03d.%s" wide
		$ = "Screenshot" wide
		$ = "\\\\.\\pipe\\PipeDtMd" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and all of them
}
rule SEKOIA_Tool_Dogtunnel_Strings : FILE
{
	meta:
		description = "Detects Dog Tunnel based on strings"
		author = "Sekoia.io"
		id = "00705613-6367-454f-b3f2-1e2b0a52459c"
		date = "2024-03-14"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_dogtunnel_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "04e7141e67ba841b0955b9e36c43be1f5b22e635b96d58b8b1b52fd507ddd929"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "pipe.(*UDPMakeSession).doAndWait"
		$ = "ikcp.ikcp_parse_fastack"
		$ = "pipe.ListenWithSetting"
		$ = "pipe.DialTimeoutWithSetting"
		$ = "common.ReadUDP"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and all of them and filesize < 10MB
}
rule SEKOIA_Apt_Kimsuky_Sharpext_Devtoolmodule_Strings : FILE
{
	meta:
		description = "Detects the DevTool module used by SharpExt"
		author = "Sekoia.io"
		id = "6f589a9c-344a-4ddc-929e-f123a2c3c187"
		date = "2022-07-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_kimsuky_sharpext_devtoolmodule_strings.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "61007801d28636c6d88b14225f34910d03e82337520257637a5017d58600b2bc"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "packetProc = function" ascii fullword
		$ = "var url = request.request.url" ascii fullword
		$ = "https://mail" ascii fullword

	condition:
		all of them and filesize < 50KB
}

rule SEKOIA_Rat_Win_Ninerat
{
	meta:
		description = "Detect the NineRAT payload"
		author = "Sekoia.io"
		id = "a9f4f78b-5b86-4ac1-9b9b-ba2672b938bf"
		date = "2023-12-12"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_ninerat.yar#L4-L31"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "47e017b40d418374c0889e4d22aa48633b1d41b16b61b1f2897a39112a435d30"
		hash = "82d4a0fef550af4f01a07041c16d851f262d859a3352475c62630e2c16a21def"
		logic_hash = "bbb695444a6ec0d6049d0ce233ca37de6f78393e5ceb5d454867c8b554269684"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "https://api.telegram.org/bot"
		$ = "/getMe"
		$ = "/upgrade"
		$ = "/getFile"
		$ = "/sendMessage"
		$ = ">> Request send time:"

	condition:
		all of them or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "3ce78c89e2c0e795ad3382aa12e99683" )
}
rule SEKOIA_Spyware_And_Fastfire : FILE
{
	meta:
		description = "Detect the FastFire malware"
		author = "Sekoia.io"
		id = "93c0ffd5-faa5-4ead-8848-1c44b459dc29"
		date = "2022-11-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/spyware_and_fastfire.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "2600fc0a8fc6279936decf80256be1fc8cb581a59ef6646fe48b5885e104365e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$funct1 = {22 00 87 18 70 20 f3 ae 40 00 6e 10 f4 ae 00 00 0c 04 1f 04 16 19 13 00 28 23 6e 20 e3 ae 04 00 12 10 6e 20 e5 ae 04 00 1a 00 25 19 6e 20 ea ae 04 00 28 05 0d 00 6e 10 ef ae 00 00 6e 10 da ae 04 00 6e 10 e1 ae 04 00 0a 00 13 01 c8 00 32 10 20 00 1c 00 ea 17 6e 10 73 ad 00 00 0c 00 22 01 60 18 70 10 5d ae 01 00 1a 02 ff 50 6e 20 69 ae 21 00 6e 10 e1 ae 04 00 0a 04 6e 20 64 ae 41 00 6e 10 72 ae 01 00 0c 04 71 20 1d 09 40 00}
		$funct2 = {22 00 77 00 1a 01 88 56 70 20 f1 02 10 00 15 01 00 10 6e 20 f4 02 10 00 1a 01 80 8d 6e 20 32 ae 13 00 0a 01 38 01 0b 00 1a 01 25 76 71 10 b3 06 01 00 0c 01 6e 20 22 03 10 00 1a 01 56 61 6e 20 32 ae 13 00 0a 01 38 01 0b 00 1a 01 23 76 71 10 b3 06 01 00 0c 01 6e 20 22 03 10 00 1a 01 55 66 6e 20 32 ae 13 00 0a 03 38 03 0b 00 1a 03 24 76 71 10 b3 06 03 00 0c 03 6e 20 22 03 30 00 13 03 64 00 15 01 00 08 71 40 07 02 32 10 0c 03 11 03}
		$s0 = "TokenResult{token="
		$s1 = "[-] Send Resp Code ="
		$s2 = "/report_token/report_token.php?token="
		$s3 = "naver"
		$s4 = "daum"
		$s5 = "facebook"

	condition:
		uint32be( 0 ) == 0x6465780A and ( 1 of ( $funct* ) or all of ( $s* ) )
}
rule SEKOIA_Apt_Oilrig_Clipog_Strings : FILE
{
	meta:
		description = "Detects OilRig's Clipog stealer"
		author = "Sekoia.io"
		id = "0ac40fd9-f67d-41fa-a774-77a3a1b7cac3"
		date = "2023-10-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_oilrig_clipog_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "16f3fef59db9c58025a4a977de944b628e9dc850f87c1bb22e2f2f97601e5107"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[ClipBoard=" wide
		$ = "[NUMPAD .]" wide
		$ = "[SPACE]" wide
		$ = "GetClipboardData"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 350KB and all of them
}
rule SEKOIA_Hacktool_Nbtscan_Strings : FILE
{
	meta:
		description = "Detects NBTScan hacktool based on strings, ELF & PE variants"
		author = "Sekoia.io"
		id = "8883b56c-a085-459c-9ec6-a139ad5a2671"
		date = "2022-02-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_nbtscan_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "87e4f5dd16ee29dfd23b70dccbc41b0ef40c2db28f42fbd7fd84e5e93ca5c943"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "CHT:nfp:bt:vw:mVO:1P"
		$ = "usage: %s [options] target [targets...]"
		$ = "Targets are lists of IP addresses, DNS names, or address"
		$ = "net bits [%d] must be 1..32"
		$ = "subnet /%d is too large (%d max)"
		$ = "[%s] is invalid IP address"
		$ = "[%s] is an invalid target (bad IP/hostname)"

	condition:
		uint16be( 0 ) == 0x4d5a and 5 of them
}
rule SEKOIA_Zip_Win_Abcloader
{
	meta:
		description = "Use the CRC32 to detect a zip containing the doc file used to drop and launch ABCloader"
		author = "Sekoia.io"
		id = "0d14b34a-9095-48fa-b616-4e8239f3b547"
		date = "2024-08-19"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/zip_win_abcloader.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "0c7d8e611781b29e15df415640858294"
		logic_hash = "024d068a86432f35b0f7af0c4cdccb37d0979d01e90f7c9d1ae8a2dddfa3bfc8"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$crc = {32 56 27 e2}
		$name = "iden.doc"

	condition:
		$name at @crc [ 1 ] + 16
}

rule SEKOIA_Implant_Win_Lyceum : FILE
{
	meta:
		description = "Detect the DnsSystem malware used by Lyceum in March 2022"
		author = "Sekoia.io"
		id = "e061562f-9c17-4ef4-b7f9-2c6708bb6570"
		date = "2022-06-13"
		modified = "2024-12-19"
		reference = "https://www.zscaler.com/blogs/security-research/lyceum-net-dns-backdoor"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_win_lyceum.yar#L4-L30"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f6b4acf48877c1dd62fd2bfa19d701b0a79f052ec44fc5d4fe3dc7b02aa689c8"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "$02c7afab-7f96-4dfa-b452-832e3624e270" ascii
		$ = "C:\\Users\\u1\\Downloads\\Compressed\\article_src\\DnsDig\\DnsDig\\obj\\Release\\DnsDig.pdb" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 1 of them or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "d0e0c140e4831f835bcdcc6b463f3acc" ) or for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "22c92a1ba6ffd828637d7045261db7a45608ddd6d7c85836af011b3c679c725f" )
}
rule SEKOIA_Apt_Gelsemium_Wolfsbane_Backdoor : FILE
{
	meta:
		description = "Detects Gelsemium's WolfsBane backdoor"
		author = "Sekoia.io"
		id = "db2ad5a4-b592-4646-a385-c668bb2ea090"
		date = "2024-11-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gelsemium_wolfsbane_backdoor.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "1418fe9a743226b9661a2b6decb19db0"
		logic_hash = "97d5076ca4c204a2e2276fd250d64bc140da1f2c8dec9996db7a622385f2c0ac"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "udp_session"
		$ = "session_interface"
		$ = "plugin_persist"
		$ = "Udp.cpp"
		$ = "ikcp.c"
		$ = "' %s 2>/dev/null"

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize > 3MB and filesize < 4MB and 4 of them
}
rule SEKOIA_Apt_Apt28_Document_Phishing_Webpage : FILE
{
	meta:
		description = "Detects APT28 document phishing webpage"
		author = "Sekoia.io"
		id = "585a8e23-c302-41d3-938f-eda60c82ef28"
		date = "2024-04-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt28_document_phishing_webpage.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b64888c1d8568cf9d8f4dfcd2e18093db8635966d88abaa368dc46a1e4453782"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "webhook.site"
		$ = "document.createElement('img')"
		$ = "brightness(15%) blur(7.0px)"
		$ = "This document is not available from mobile devices."
		$ = "Capture2.PNG"
		$ = ">CLICK TO VIEW DOCUMENT<"
		$ = "window.location.href = 's"
		$ = ".oast."

	condition:
		4 of them and filesize < 20KB
}
rule SEKOIA_Backdoor_Win_Spacecolon : FILE
{
	meta:
		description = "Finds Spacecolon samples based on specific strings (ScHackTool component)"
		author = "Sekoia.io"
		id = "ae09f0e2-e913-44d5-abe1-715170368cc8"
		date = "2023-08-25"
		modified = "2024-12-19"
		reference = "https://www.welivesecurity.com/en/eset-research/scarabs-colon-izing-vulnerable-servers/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_win_spacecolon.yar#L1-L39"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "1251df19c521e9ee9da307d56eea265265f2bee4a8e7eec099e4ebfb4e2bd7a2"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "Before Work" ascii
		$str02 = "DEFENDER OFF" ascii
		$str03 = "Stop Service" ascii
		$str04 = "Kill All (Default)" ascii
		$str05 = "Keyboard EN" ascii
		$str06 = "After Work" ascii
		$str07 = "Del Shadow Log" ascii
		$str08 = "Kill OSK" ascii
		$str09 = "PWGEN" ascii
		$str10 = "Character :" ascii
		$str11 = "PW GEN" ascii
		$str12 = "Cobian UI Pass" ascii
		$str13 = "Credssp" ascii
		$str14 = "Username :" ascii
		$str15 = "Password :" ascii
		$str16 = "TSpeedButton" ascii
		$str17 = "Ab1q2w3e!" ascii
		$str18 = "PC Details" ascii
		$str19 = "Mimi Dump" ascii
		$str20 = "MIMI Dump" ascii
		$str21 = "powershell -ExecutionPolicy Bypass -File \"" wide
		$str22 = "lastlog.txt" wide
		$str23 = "$AdminGroupName = (Get-WmiObject -Class Win32_Group -Filter 'LocalAccount = True AND SID = \"S-1-5-32-544\"').Name" wide
		$str24 = "net localgroup $AdminGroupName " wide

	condition:
		uint16( 0 ) == 0x5a4d and 17 of them
}
rule SEKOIA_Apt_Yemen_Apk_Guardzoo : FILE
{
	meta:
		description = "Detects Dex files containing GuardZoo strings."
		author = "Sekoia.io"
		id = "f4004e7c-2904-46ea-a3e6-2bdd3e704fea"
		date = "2024-08-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_yemen_apk_guardzoo.yar#L1-L40"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "3afad114c68489e2d294720339baf570"
		hash = "c59d0f5c8d00485199f147b96c5abca0"
		hash = "75c58948725133160085dc1cfdf602ec"
		hash = "d76a39ee85263900f7e6eaacb804f5e2"
		hash = "51356c95dfe1221c0f4ca2475bc787f8"
		hash = "1d0dd8201c051d9c8d2c945c8b31a48c"
		hash = "b7b6be5e8eec44dd13e1df1f3908fcf0"
		hash = "229984f004578a8fa643afb881d81e8c"
		hash = "f3f1ccb3912c49a0a6ea710a0bd856de"
		hash = "a3f8365bfa5f8185e8c7eba8efc63165"
		hash = "7392deaf81ddf50b8a6f2179538f7e81"
		hash = "c40d56e1586f9fa382c688d624d25525"
		hash = "629fb04b91c4db4ea282440e20317dab"
		hash = "bcebc41628196f8bd119f72e1e8eb47c"
		hash = "f1cfdc9e91c3a20563246cf366b94f10"
		hash = "a75ffb11adbace40a7c59128adba43ad"
		logic_hash = "7d98aefa4c2ee7316e0ff47a67d9f19913852d1a451ef38ccb77709394e4ba73"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$classes_1 = "GuardZoo.java"
		$classes_2 = "com/animals"
		$path_1 = "&Password="
		$path_2 = "&Coordinates="
		$path_3 = "&Data="
		$path_4 = "&Device="
		$path_5 = "&ISPICTURE="
		$path_6 = "&Phone_Number="
		$path_7 = "&Provider="

	condition:
		uint32be( 0 ) == 0x6465780a and filesize < 10MB and ( ( any of ( $classes_* ) ) and ( 3 of ( $path_* ) ) )
}

rule SEKOIA_Wiper_Win_Ruransom : FILE
{
	meta:
		description = "Detect the RURansom malware"
		author = "Sekoia.io"
		id = "7bf3694b-c689-482f-88cd-b1f3b86bbc36"
		date = "2022-11-21"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/wiper_win_ruransom.yar#L4-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e16cfe7a273bfa01e2ae56174e6ea10a84d42542a62dda5e7b095a0c30082a31"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "RURansom"
		$ = "AesCrypter"
		$ = "RURansom" wide

	condition:
		uint16( 0 ) == 0x5A4D and all of them or for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "e4b6b5b2b293d497ddf373ca9f7e97458328703d2769f451890ac48771c85070" )
}
rule SEKOIA_Launcher_Win_Stealthmutant_Bat_Launcher : FILE
{
	meta:
		description = "StealthMutant/StealthVector bat launcher"
		author = "Sekoia.io"
		id = "7452291f-2244-469e-bb7c-5eff1ca17aa2"
		date = "2021-08-26"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/launcher_win_stealthmutant_bat_launcher.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "06ae4bc3ed938738dfca10c182a6a2363aa6aa70e730aefd41f6fe73c675785d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "set \"WORK_DIR=" ascii
		$s2 = "set \"DLL_NAME=" ascii
		$s3 = "set \"SERVICE_NAME=" ascii
		$s4 = "set \"DISPLAY_NAME=" ascii
		$s5 = "set \"DESCRIPTION=" ascii
		$start = "@echo off" ascii
		$end = "net start \"%SERVICE_NAME%\"" ascii

	condition:
		uint16( 0 ) != 0x5A4D and all of ( $s* ) and filesize < 2KB and $start at 0 and $end in ( filesize -30 .. filesize )
}
rule SEKOIA_Unknown_Quad7_Wildcard_Login : FILE
{
	meta:
		description = "Detects the (x|r|a)login bind shells"
		author = "Sekoia.io"
		id = "01510244-0795-4299-aa66-056a2b4682e7"
		date = "2024-07-18"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/unknown_quad7_wildcard_login.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "4d9067e7cf517158337123a30a9bd0e3"
		hash = "43ea387b8294cc4d0baaef6d26ff7c72"
		hash = "777d6f907da38365924a0c2a12e973c5"
		hash = "8542a3cbe232fe78baa0882736c61926"
		hash = "1b08725acc371f6b7d05bb72d0c2d759"
		logic_hash = "72de6fe656313bdd4f4b092ceca7248c67b8047c224104cd569dff7af1d86135"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$string1 = { 2f 62 69 6e 2f 73 68 00 2f 74 6d 70 2f 6c 6f 67 69 6e }
		$string2 = { 2f 62 69 6e 2f 73 68 00 2d 63 00 65 78 69 74 20 30 }

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 180KB and @string2 - @string1 < 3400
}

rule SEKOIA_Wiper_Win_Dnwipe : FILE
{
	meta:
		description = "Detect the dnWipe malware"
		author = "Sekoia.io"
		id = "522fdaa5-8fe6-4e37-aaf8-13e3a7787d21"
		date = "2022-11-21"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/wiper_win_dnwipe.yar#L4-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "634ca80a168c9d98ce87a3a1a451769bddb7ae27e28b3682693b34ccce2c7ad4"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "dnWIPE"
		$ = "dnWIPE" wide
		$ = "C:\\Users\\Admin1\\source\\repos\\dnWIPE\\dnWIPE\\obj\\Debug\\dnWIPE.pdb"

	condition:
		uint16( 0 ) == 0x5A4D and all of them and filesize < 50KB or for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "93290ef6447b0a16b92e50a1652ac3eb8f1237cc5f8005e080750fb58c19d230" )
}
rule SEKOIA_Luckymouse_Sysupdate_Loader : FILE
{
	meta:
		description = "Detects decryption routine prologue of sysupdate loader"
		author = "Sekoia.io"
		id = "6007e846-d467-4d07-b345-e25191b7c8bc"
		date = "2022-08-19"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/luckymouse_sysupdate_loader.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "9d46b74d8e5f94ecd844cffcd6d0d29eb662374c1d6fbe87acf3c877e5f963b3"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = { DB D4 33 C9 66 B9 ?? ?? E8 FF FF FF FF }

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and all of them
}
rule SEKOIA_Apt_Gamaredon_Gammaload_Maliciouslnk : FILE
{
	meta:
		description = "Detects Gamaredon's GammaLoad LNK"
		author = "Sekoia.io"
		id = "2612e6c6-0bda-4bfa-a840-aa0a0b4c945b"
		date = "2022-08-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gamaredon_gammaload_maliciouslnk.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "94ba156cd6697a9999b6a4f78c4356ea3382b7b3e7a1af79d488aa34df2c3b40"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$mshta = "System32\\mshta.exe"
		$trait = { 0D 0A ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? 0D 0A }

	condition:
		uint32be( 0 ) == 0x4c000000 and #trait > 100 and $mshta and filesize > 100KB and filesize < 300KB
}
rule SEKOIA_Ransomware_Win_Masons_Jan2023 : FILE
{
	meta:
		description = "Rule to detect Masons ransomware samples."
		author = "Sekoia.io"
		id = "cf2af08b-b4a8-4245-9308-242e15aeb346"
		date = "2023-02-13"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_win_masons_jan2023.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "7826978642c568f975e2b65d1575fdf92e634f7c80db2c86c9d7c8066e8955b8"
		logic_hash = "05badf0364c6f61cd081a3ae64bc92b48e6f59c026a5d6b5b68acd5a8987cf91"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "Masons" wide
		$s2 = "@mineralIaha/@root_king1" wide
		$s3 = "Glory @six62ix" wide

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Exploit_Linux_Eop_Dirtypipe_Strings : FILE
{
	meta:
		description = "Detects DirtyPipe Local Privesc exploit"
		author = "Sekoia.io"
		id = "712d8a01-576e-4f43-a930-63dcdc535d93"
		date = "2023-12-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/exploit_linux_eop_dirtypipe_strings.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0abb8de541acea57ced20f66c0aad7b010fea647996039809d36e94555dee204"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[+] hijacking suid binary.."
		$ = "[+] dropping suid shell.."
		$ = "[+] restoring suid binary.."
		$ = "[+] popping root shell.."

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 1MB and all of them
}
rule SEKOIA_Apt_Uac0099_Lonepage : FILE
{
	meta:
		description = "Detects LonePage vbs malware"
		author = "Sekoia.io"
		id = "007f62f5-da5c-4df7-8b5c-5ed815ce6993"
		date = "2024-01-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_uac0099_lonepage.yar#L1-L30"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "479f438acb63c76e09722640b973e76d1f1924bf24db477ca6898d123091d5f8"
		score = 75
		quality = 76
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s0 = "dim r, c" ascii fullword
		$s1 = "= createobject(\"WScript.Shell\")" ascii fullword
		$s2 = "r.Run c, 0, false" ascii fullword
		$t1 = "GetHostAddresses" ascii fullword nocase
		$t2 = "upgrade.txt" ascii fullword nocase
		$t3 = "net.webclient" ascii fullword nocase
		$t4 = "downloaddata" ascii fullword nocase
		$t5 = "[System.Environment]::NewLine" ascii fullword nocase
		$t6 = ".uploaddata('" ascii nocase

	condition:
		true and filesize < 10KB and ( ( $s1 at 0x10 and $s0 at 0 and $s2 and 2 of ( $t* ) ) or ( all of ( $t* ) and any of ( $s* ) ) )
}
rule SEKOIA_Apt_Andariel_Dorarat_Strings : FILE
{
	meta:
		description = "Detects Dora RAT based on strings"
		author = "Sekoia.io"
		id = "30388291-a287-489f-a060-c90a16cda217"
		date = "2024-06-17"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_andariel_dorarat_strings.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "21e1c77d486cbf6ddaa2eca673275c7c21cc59fa9551c2eb02c526518ed5b217"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$x1 = "/encryption.go" ascii fullword
		$x2 = "/handshake.go" ascii fullword
		$x3 = "/trans_module.go" ascii fullword
		$enc_rsc = { 14 02 72 14 D3 4C 4A 49 55 36 14 DF 8D 6F 2D CF }

	condition:
		uint16be( 0 ) == 0x4d5a and ( all of ( $x* ) or $enc_rsc )
}
rule SEKOIA_Backdoor_Powershellempire_Python : FILE
{
	meta:
		description = "Detects Empire Python version"
		author = "Sekoia.io"
		id = "c2913f60-46a2-42c1-8569-72568eaddaed"
		date = "2022-04-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_powershellempire_python.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "81c74a73ff7fe02420f29a53b350f1b53964f5a04f0694fed5b1b4bd6cc5ad03"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "import sys,base64;exec"
		$ = "aW1wb3J0IHN5cztpbXBvcnQgcmUsIHN1YnByb2"

	condition:
		all of them and filesize < 1MB
}
rule SEKOIA_Apt_Coathanger_Beacon : FILE
{
	meta:
		description = "Detects COATHANGER beacon"
		author = "Sekoia.io"
		id = "cc201479-016a-46d2-a9e2-41b4914ce618"
		date = "2024-02-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_coathanger_beacon.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e44496e62de8c885d5bd941819a97f4c0dd90ce2d0cfe9d042ab9590cc354ddb"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = {
        48 B8 47 45 54 20 2F 20 48 54
        48 89 45 B0 48 B8 54 50 2F 32 0A 48 6F 73
        48 89 45 B8 48 B8 74 3A 20 77 77 77 2E 67
        48 89 45 C0 48 B8 6F 6F 67 6C 65 2E 63 6F
        }

	condition:
		uint32( 0 ) == 0x464c457f and filesize < 5MB and any of them
}
rule SEKOIA_Exploit_Linux_Eop_Cve202121974_Exploit_Strings : CVE_2021_21974 FILE
{
	meta:
		description = "Detects CVE-2021-21974 Local Privesc exploit"
		author = "Sekoia.io"
		id = "8e1fbbe5-7d51-48b4-80d5-90abff8cab9e"
		date = "2023-12-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/exploit_linux_eop_cve202121974_exploit_strings.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a2e6e2660fcbf6ffa80809c02ca78fae85d27f6cd8d2c83bb2645a86124ca7f2"
		score = 75
		quality = 80
		tags = "CVE-2021-21974, FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = ".name.replace('Thread','SLP Client'"
		$ = "print('[' + name + '] recv: ', d)"
		$ = "requests[28].put(connect())"
		$ = "[+] stack enviorn address:"

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 1MB and all of them
}
rule SEKOIA_Tool_Win_Forkplayground : FILE
{
	meta:
		description = "Detect the ForkPlayground malware"
		author = "Sekoia.io"
		id = "ec9af403-7647-447d-af17-c6931363a166"
		date = "2023-02-28"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_win_forkplayground.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "23d93b7eef978f76c9aa6c0bc28a661d160b0a871fd320442b6c27bc92bc279e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Failed to open dump file %s with the last error %i."
		$ = "Successfully dumped process %i to %s"
		$ = "ForkPlayground"
		$ = "Second attempt at taking a snapshot of the target failed. It is likely that there is a difference in process privilege or the handle was stripped."
		$ = "Failed to take a snapshot of the target process. Attempting to escalate debug privilege..."
		$ = "Failed to escalate debug privileges, are you running ForkDump as Administrator"

	condition:
		uint16( 0 ) == 0x5A4D and 1 of them
}
rule SEKOIA_Apt_Luckymouse_Rshell_Strings : FILE
{
	meta:
		description = "Detects LuckyMouse RShell Mach-O implant"
		author = "Sekoia.io"
		id = "89f18013-ea3e-440f-821e-cef102a43b7b"
		date = "2022-08-05"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_luckymouse_rshell_strings.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ffca47856d4c4d83312220cff23c0a556be0e675d59ac009c2f74fc0e39cb816"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = { 64 69 72 00 70 61 74 68
        00 64 6F 77 6E 00 72 65
        61 64 00 75 70 6C 6F 61
        64 00 77 72 69 74 65 00
        64 65 6C }
		$ = { 6C 6F 67 69 6E 00 68 6F
        73 74 6E 61 6D 65 00 6C
        61 6E 00 75 73 65 72 6E
        61 6D 65 00 76 65 72 73
        69 6F 6E }

	condition:
		( uint32be( 0 ) == 0xCFFAEDFE or uint16be( 0 ) == 0x4d5a ) and filesize < 300KB and all of them
}
rule SEKOIA_Shell_Win_Danfuan : FILE
{
	meta:
		description = "Detect the Danfuan malware"
		author = "Sekoia.io"
		id = "d1cf9988-270b-4a22-bdd5-f40b625715a8"
		date = "2022-11-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/shell_win_danfuan.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "96929ef478a8773022233a4092b3c157867aae6ee185568a6327d033c05a68f1"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "<%@ WebHandler Language=\"C#\" class=\"DynamicCodeCompiler\"%>"
		$ = "CompilerResults compilerResults = compiler.CompileAssemblyFromSource(comPara, SourceText(txt))"
		$ = "MethodInfo objMifo = objInstance.GetType().GetMethod("

	condition:
		filesize < 15KB and all of them
}
rule SEKOIA_Implant_Win_Geacon : FILE
{
	meta:
		description = "Finds Geacon samples based on specific strings"
		author = "Sekoia.io"
		id = "064eabe0-aee5-4e5e-9f5e-69b32b1ba0da"
		date = "2024-01-11"
		modified = "2024-12-19"
		reference = "https://www.sentinelone.com/blog/geacon-brings-cobalt-strike-capabilities-to-macos-threat-actors/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_win_geacon.yar#L1-L35"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "74b0d2fbb8b7f6666543ba4fdfd9f9d2064d3a89d21c90d794b57f0009199fea"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$gea01 = "geacon/config.init" ascii
		$gea02 = "geacon_pro-master/config/config.go" ascii
		$gea03 = "geacon_plus-main/config/config.go" ascii
		$gea04 = "command type %d is not support by geacon now" ascii
		$gea05 = "main/sysinfo.GeaconID" ascii
		$str01 = "command.StealToken" ascii
		$str02 = "command.MakeToken" ascii
		$str03 = "command/misc.go" ascii
		$str04 = "config/c2profile.go" ascii
		$str05 = "crypt.AesCBCDecrypt" ascii
		$str06 = "packet.File_Browse" ascii
		$str07 = "packet.FirstBlood" ascii
		$str08 = "packet.ParseCommandShell" ascii
		$str09 = "packet.ParseCommandUpload" ascii
		$str10 = "packet.PushResult" ascii
		$str11 = "sysinfo.GetComputerName" ascii
		$str12 = "sysinfo.IsOSX64" ascii
		$str13 = "util..inittask" ascii

	condition:
		uint16( 0 ) == 0x5A4D and ( ( 1 of ( $gea* ) and 2 of ( $str* ) ) or 8 of ( $str* ) )
}
rule SEKOIA_Rat_Win_Hiddenz : FILE
{
	meta:
		description = "Lazy rule to detect Hiddenz's HVNC sample based on te malware name contained in numerous samples"
		author = "Sekoia.io"
		id = "4e582cda-4c50-4554-8e26-9d26206a02ee"
		date = "2022-08-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_hiddenz.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "92f62c893d8a081cd52deaaac93d622fbb1c8e9c7df214e34c6b8066be72a424"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$name0 = "Hiddenz's HVNC" wide ascii
		$name1 = "Hiddenzs_HVNC_DLL" wide ascii
		$name2 = "HiddenzHVNC" wide ascii

	condition:
		uint16( 0 ) == 0x5A4D and 1 of ( $name* )
}
rule SEKOIA_Apt_Mustangpanda_Decrypt_Payload : FILE
{
	meta:
		description = "Detects the decryption routine of DAT file"
		author = "Sekoia.io"
		id = "7b954007-0929-454d-8a10-05279a337f1b"
		date = "2022-12-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_mustangpanda_decrypt_payload.yar#L1-L27"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "dcc32580e351e605d21dc29558764c6fd85f8a9506de8e78f301459a5a2610b7"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$chunk_1 = {
        85 ??
        74 ??
        8B ??
        D1 EA
        A1 ?? ?? ?? ??
        03 C2
        A3 ?? ?? ?? ??
        30 04 29
        41
        3B ??
        72 EC
        }

	condition:
		filesize < 8MB and all of them
}

rule SEKOIA_Backoor_Win_Tinyturla_Ng : FILE
{
	meta:
		description = "Detect the TinyTurla-NG backdoor used by Turla"
		author = "Sekoia.io"
		id = "019043bb-0212-4b73-bc93-03e9a746d28d"
		date = "2024-03-04"
		modified = "2024-12-19"
		reference = "https://blog.talosintelligence.com/tinyturla-next-generation/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backoor_win_tinyturla_ng.yar#L3-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "267071df79927abd1e57f57106924dd8a68e1c4ed74e7b69403cdcdf6e6a453b"
		hash = "d6ac21a409f35a80ba9ccfe58ae1ae32883e44ecc724e4ae8289e7465ab2cf40"
		logic_hash = "a2fe2187e0cdd02fa31cbbecd600d044d4d12788ea6f76086aef7e77cbf232a0"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "delkill /F /IM explENT_USER\\Softwar"
		$ = "Set-PSReadLineOption -HistorySaveStyle SaveNothing"
		$ = "changeshell"
		$ = "chcp 437 > $null"
		$ = "powershell.exe -nologo"

	condition:
		uint16be( 0 ) == 0x4d5a and all of them or pe.imphash ( ) == "2240ae6f0dcbc0537836dfd9205a1f2b"
}
rule SEKOIA_Implant_Lin_Geacon : FILE
{
	meta:
		description = "Finds Geacon samples based on specific strings"
		author = "Sekoia.io"
		id = "ad71522e-270b-47d0-9c01-081f05a2b72a"
		date = "2024-01-11"
		modified = "2024-12-19"
		reference = "https://www.sentinelone.com/blog/geacon-brings-cobalt-strike-capabilities-to-macos-threat-actors/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_lin_geacon.yar#L1-L35"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c6fa5815bf618eb588d511f18231042944dee20c1b13096c44910d43ca552bfa"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$gea01 = "geacon/config.init" ascii
		$gea02 = "geacon_pro-master/config/config.go" ascii
		$gea03 = "geacon_plus-main/config/config.go" ascii
		$gea04 = "command type %d is not support by geacon now" ascii
		$gea05 = "main/sysinfo.GeaconID" ascii
		$str01 = "command.StealToken" ascii
		$str02 = "command.MakeToken" ascii
		$str03 = "command/misc.go" ascii
		$str04 = "config/c2profile.go" ascii
		$str05 = "crypt.AesCBCDecrypt" ascii
		$str06 = "packet.File_Browse" ascii
		$str07 = "packet.FirstBlood" ascii
		$str08 = "packet.ParseCommandShell" ascii
		$str09 = "packet.ParseCommandUpload" ascii
		$str10 = "packet.PushResult" ascii
		$str11 = "sysinfo.GetComputerName" ascii
		$str12 = "sysinfo.IsOSX64" ascii
		$str13 = "util..inittask" ascii

	condition:
		uint32( 0 ) == 0x464C457F and ( ( 1 of ( $gea* ) and 2 of ( $str* ) ) or 8 of ( $str* ) )
}
rule SEKOIA_Apt_Tealkurma_Snappytcp_Reverse_Shell_Strings : FILE
{
	meta:
		description = "Detects TealKurma SnappyTCP reverse shell"
		author = "Sekoia.io"
		id = "e842825c-546c-475a-bc94-7e97aea4e9e0"
		date = "2023-12-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_tealkurma_snappytcp_reverse_shell_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "feb24cafcf5b080c91dab42bf8d78fbdb0b7fae9395c7513f02aa90a25663d2c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "2>&1>/dev/null&" ascii
		$ = ".php HTTP/1.1" ascii
		$ = "GET /" ascii
		$ = "Hostname: %s" ascii
		$ = "bash -c \"./" ascii

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 3MB and 3 of them
}

rule SEKOIA_Downloader_Win_Apt33_Tickler : FILE
{
	meta:
		description = "Detect the downloader used by APT33 to diwnload Tickler"
		author = "Sekoia.io"
		id = "e1f704d6-d527-479a-8311-d286c06768ac"
		date = "2024-08-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/downloader_win_apt33_tickler.yar#L4-L29"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e6fff291b73812e5a999fbc566e8f7181dcdf01b849a9664ba05fe0a2bc982fe"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		uint16be( 0 ) == 0x4d5a and pe.imphash ( ) == "e43c58659b5b3082387307603478881a" or hash.md5 ( pe.rich_signature.clear_data ) == "d30bd7875b225709ecf95bf68dbd435f" or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "d7d2079d0a656c06a03f2c277bb08bda" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "61a1425e6a0d28e29c6fd3d451ac3717" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "916bf96ed3274ce8322d9f370432844f" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "3fab9d4ae989d53cecb2f443b8ce88d0" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "e0967483e074da72ceff4dea3bc17530" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "b4a571736b6646765155ffbd57c27c83" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "35c88ba521887f8fe1b2501f8cd8bd98" ) or for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "636dc666c7496cb3382b029fed53473f181cdc24405886c468e51a103d78b4d4" )
}
rule SEKOIA_Guloader_Powershell_1 : FILE
{
	meta:
		description = "Powershell downloading decoy and delivering GuLoader"
		author = "Sekoia.io"
		id = "28c68991-db8b-4f00-b3a3-17286418a4ed"
		date = "2024-02-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/guloader_powershell_1.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "9fd2d0e31f939e7e96444eaa4802c9c33407c5fb77067670d8ce2d3796199961"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "powershell -win hidden"
		$s2 = "=iex($"
		$s3 = ".Replace('"
		$s4 = "$(Get-ChildItem -Include *.lnk -Name));"

	condition:
		all of them and filesize < 10KB and #s3 > 3
}
rule SEKOIA_Hacktool_Microsocks_Strings : FILE
{
	meta:
		description = "Detects Microsocks"
		author = "Sekoia.io"
		id = "20e82008-249b-47a3-885b-7c4b04b31a57"
		date = "2023-12-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_microsocks_strings.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b76b66fbdd9a7e2ea8adb68781d6b14c18189a8b330a61c2a65e7394ef8024c3"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "microsocks -1 -i listenip -p port -u user -P password"
		$ = "user/pass, it is added to a whitelist"

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 1MB and all of them
}

rule SEKOIA_Loader_Win_Doppeldridex
{
	meta:
		description = "Detect the DoppelDridex banking trojan using its Rich header"
		author = "Sekoia.io"
		id = "ee5111ae-ba0b-4cd3-abe6-c66324d16840"
		date = "2021-09-28"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_doppeldridex.yar#L3-L33"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "4ceed302cb36b73d98070996ede64742579a261ef3ede6e1eb1723ddca32e839"
		score = 75
		quality = 80
		tags = ""
		version = "1.1"
		classification = "TLP:CLEAR"

	condition:
		pe.rich_signature.toolid( 122 , 50727 ) and pe.rich_signature.toolid ( 1 , 0 ) and pe.rich_signature.toolid ( 222 , 40629 ) and pe.rich_signature.toolid ( 131 , 30729 ) and pe.rich_signature.toolid ( 220 , 31101 ) and pe.rich_signature.toolid ( 202 , 60315 ) and pe.rich_signature.toolid ( 202 , 50727 ) and pe.rich_signature.toolid ( 261 , 23506 ) and pe.rich_signature.toolid ( 149 , 21022 ) and pe.rich_signature.toolid ( 261 , 23918 ) and pe.rich_signature.toolid ( 219 , 21005 ) and pe.rich_signature.toolid ( 171 , 30319 ) and pe.rich_signature.toolid ( 225 , 21005 ) and pe.rich_signature.toolid ( 221 , 21005 ) and pe.rich_signature.toolid ( 259 , 24210 ) and pe.rich_signature.toolid ( 258 , 24213 ) and pe.rich_signature.toolid ( 158 , 40219 ) and pe.rich_signature.toolid ( 145 , 21022 ) and pe.rich_signature.toolid ( 207 , 60315 ) and pe.rich_signature.toolid ( 256 , 23026 )
}
rule SEKOIA_Apt_Oilrig_Maliciousdocument_May2022 : FILE
{
	meta:
		description = "Detects OilRig Malicious Document"
		author = "Sekoia.io"
		id = "cb4ab310-e24c-4edc-8804-0c49c30124fb"
		date = "2022-05-13"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_oilrig_maliciousdocument_may2022.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "d4aa960d4471ddf66ec6f98a5c883177763771ba9960b749509311a05384d9a7"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "<LogonType>InteractiveToken</LogonType>"
		$s2 = "Select * From Win32_PingStatus Where Address"
		$s3 = "She@et1"
		$s4 = "_VBA_PROJECT" wide
		$s5 = "This program cannot be run in DOS mode." base64
		$s6 = ".Agent.pdb" base64
		$s7 = "GetAgentID" base64

	condition:
		uint32be( 0 ) == 0xD0CF11E0 and 3 of them
}
rule SEKOIA_Generic_Tor_Hidden_Service_Leading_To_Winports : FILE
{
	meta:
		description = "Detects malicious TOR redirection affecting RDP, NetBios"
		author = "Sekoia.io"
		id = "1e5c469b-f721-44af-87b3-1adf423719c1"
		date = "2023-09-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/generic_tor_hidden_service_leading_to_winports.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "39db199ba7fede8df4bdb505b071240dda96b74f66f818f90047dad338dc4a72"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "HiddenServiceDir "
		$s2 = "SocksPort "
		$s3 = "HiddenServicePort "
		$s4 = ":3389"
		$s5 = ":445"

	condition:
		$s1 and $s2 and ( $s4 in ( @s3 .. @s3 + 100 ) or $s5 in ( @s3 .. @s3 + 100 ) ) and filesize < 2000
}
rule SEKOIA_Rat_Win_Xworm_V2 : FILE
{
	meta:
		description = "Finds XWorm v2 samples based on characteristic strings"
		author = "Sekoia.io"
		id = "6cf06f52-0337-415d-8f29-f63d67e228f8"
		date = "2022-11-07"
		modified = "2024-12-19"
		reference = "https://blog.cyble.com/2022/08/19/evilcoder-project-selling-multiple-dangerous-tools-online/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_xworm_v2.yar#L1-L38"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "58a2dbfbd453855021942902a6d55d150eee3acba67a294da24448cfca4f811e"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "XWorm.exe" wide ascii
		$str02 = "ngrok" wide ascii
		$str03 = "Mutexx" ascii
		$str04 = "FileManagerSplitFileManagerSplit" wide
		$str05 = "InstallngC" wide
		$str06 = "downloadedfile" wide
		$str07 = "creatfile" wide
		$str08 = "creatnewfolder" wide
		$str09 = "showfolderfile" wide
		$str10 = "hidefolderfile" wide
		$str11 = "txtttt" wide
		$str12 = "\\root\\SecurityCenter2" wide
		$str13 = "[USB]" wide
		$str14 = "[Drive]" wide
		$str15 = "[Folder]" wide
		$str16 = "HVNC" wide
		$str17 = "http://exmple.com/Uploader.php" wide
		$str18 = "XKlog.txt" wide
		$str19 = "Select * from AntivirusProduct" wide
		$str20 = "runnnnnn" wide
		$str21 = "RunBotKiller" wide
		$str22 = "bypss" wide
		$str23 = "<Xwormmm>" wide

	condition:
		uint16( 0 ) == 0x5A4D and 12 of them
}
rule SEKOIA_Crime_Sload_Mainpowershellimplant : FILE
{
	meta:
		description = "Detects the main PowerShell implant"
		author = "Sekoia.io"
		id = "09d268e7-d688-4390-856e-9e9ed47aec04"
		date = "2022-08-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/crime_sload_mainpowershellimplant.yar#L1-L31"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "37ec263dddf7719d03a3d58b4b196597737a1e28f8072f3933cdf954f2b696cd"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$c1 = "priority FOREGROUND"
		$c2 = "app|Services|RuntimeBroker|Search|host"
		$c3 = "([wmiclass]\"win32_Process\").create("
		$c4 = "Start-Sleep -seconds"
		$c5 = "while($e -eq 1){ $dCnt++;"
		$d1 = "112,114,105,111,114,105,116,121,32,70,79,82,69,71,82,79,85,78,68"
		$d2 = "97,112,112,124,83,101,114,118,105,99,101,115,124,82,117,110,116,105,109,101,66,114,111,107,101,114,124,83,101,97,114,99,104,124,104,111,115,116"
		$d3 = "40,91,119,109,105,99,108,97,115,115,93,34,119,105,110,51,50,95,80,114,111,99,101,115,115,34,41,46,99,114,101,97,116,101,40"
		$d4 = "83,116,97,114,116,45,83,108,101,101,112,32,45,115,101,99,111,110,100,115"
		$d5 = "119,104,105,108,101,40,36,101,32,45,101,113,32,49,41,123,32,36,100,67,110,116,43,43,59"
		$b1 = "priority FOREGROUND" base64
		$b2 = "app|Services|RuntimeBroker|Search|host" base64
		$b3 = "([wmiclass]\"win32_Process\").create(" base64
		$b4 = "Start-Sleep -seconds" base64
		$b5 = "while($e -eq 1){ $dCnt++;" base64

	condition:
		3 of ( $c* ) or 3 of ( $d* ) or 3 of ( $b* ) and filesize < 30KB
}
rule SEKOIA_Tool_Powershell_Unicorn : FILE
{
	meta:
		description = "Detects Unicorn Powershell"
		author = "Sekoia.io"
		id = "287c1669-2ee1-488e-bf66-a99bfe309c90"
		date = "2022-08-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_powershell_unicorn.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8be79789cf77d4f304d9fef4ad6a2d2ac7686b015fff3301fb3e369f2f06230a"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = ").value.toString() ('JAB" ascii wide
		$ = ").value.toString());powershell (" ascii wide
		$ = "powershell /w 1 " ascii wide

	condition:
		all of them and filesize < 100KB
}
rule SEKOIA_Win_Malware_Janelarat_Strings : FILE
{
	meta:
		description = "Detect the JanelaRAT malware"
		author = "Sekoia.io"
		id = "891f182e-8a7a-4d0c-a481-62c198bb901b"
		date = "2023-08-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/win_malware_janelarat_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "00df0a1f037e24ff1528d524fb7398735e2c3e0a9995a9f95a5293b04748f06e"
		logic_hash = "cf2ca92cf790211f69ea9645f1c1b865d5503d14a1dcce535b4a69c735ea3dad"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s2 = {4d 58 4e 4f 42 55 47 4d 41 47}
		$s1 = "block.blq" wide

	condition:
		( uint16be( 0 ) == 0x4d5a ) and filesize > 100KB and filesize < 1MB and 2 of them
}
rule SEKOIA_Apt_Apt29_Malicious_Rdp_File : FILE
{
	meta:
		description = "Detects malicious RDP files"
		author = "Sekoia.io"
		id = "a7b092b5-53a1-4638-a6c1-733d3f063139"
		date = "2024-10-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt29_malicious_rdp_file.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "db326d934e386059cc56c4e61695128e"
		hash = "b38e7e8bba44bc5619b2689024ad9fca"
		hash = "f58cf55b944f5942f1d120d95140b800"
		hash = "40f957b756096fa6b80f95334ba92034"
		logic_hash = "da9d8dfbbf82f48c8b880cbde21f75ecd1e9f779e462da5ced32b6587c71eaf2"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "RedirectPrinters" wide
		$ = "RedirectCOMPorts" wide
		$ = "RedirectSmartCards" wide
		$ = "RedirectPOSDevices" wide
		$ = "RedirectClipboard" wide
		$ = "DrivesToRedirect" wide
		$ = "full address:s:" wide

	condition:
		uint16be( 0 ) == 0xFFFE and all of them and filesize < 20KB
}
rule SEKOIA_Darkriver_Encodedurl : FILE
{
	meta:
		description = "Detects encoding URL inside docx documents"
		author = "Sekoia.io"
		id = "60f1676f-dade-4376-9980-f510dff52ae5"
		date = "2023-10-10"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/darkriver_encodedurl.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "5c9551388213f54c4b54cd42ccb034d8d9173a4bbfcf8b666e0db8df929762e7"
		hash = "13de9f39b1ad232e704b5e0b5051800fcd844e9f661185ace8287a23e9b3868e"
		hash = "3b05e89ff2338472cc493d59bae450338effd29f0ed7d46fb999709e63cf2472"
		logic_hash = "9477ec39cc1d4cfad676d071748e7e1918a3996b342663cb0a01658846bbf9f5"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "&#109;&#104;&#116;&#109;&#108;&#58;&#104;&#116;&#116;&#112;"
		$s2 = "&#38;&#95;&#116;&#115;&#61;"
		$header = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"

	condition:
		filesize < 500KB and any of ( $s* ) and $header at 0
}
rule SEKOIA_Tool_Pivotnacci_Webshell : FILE
{
	meta:
		description = "Detects pivotnacci webshell"
		author = "Sekoia.io"
		id = "729b6381-b59d-46fe-9ad4-b8b68fb0ceea"
		date = "2024-04-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_pivotnacci_webshell.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a57792915b4c888547ebe0b08b928e4bc32b3526c98a3ccc9fca0193cedee20a"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "if (cmd == SEND_OPERATION) {"
		$ = "Response.BinaryWrite(newBuff)"
		$ = "Request.Headers.Get(ID_HEADER)"
		$ = "[$READ_BUFFER_SESSION_KEY . $connection_id]"
		$ = "extract_session_readbuf($conn_id"
		$ = "Failed connecting to target $addr:$port : $errstr"
		$ = "void handle_post(String cmd)"
		$ = "SocketChannel socketChannel = this.get_socket(socket_id"
		$ = "this.get_svc().compareTo(this.get_hostname())"

	condition:
		3 of them and filesize < 10KB
}

rule SEKOIA_Infostealer_Win_Mars_Stealer : FILE
{
	meta:
		description = "Detect Mars Stealer based on specific strings"
		author = "Sekoia.io"
		id = "3e2c7440b2fc9e4b039e6fa8152ac8fd"
		date = "2022-02-03"
		modified = "2024-12-19"
		reference = "https://3xp0rt.com/posts/mars-stealer"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_mars_stealer.yar#L3-L44"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b2b36a280c3c6cbbb8cbb9f1dd3eb48a4943ebbddb48eba2ac3d0db03924cafd"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		modification_date = "2022-02-14"
		classification = "TLP:CLEAR"

	strings:
		$dec = {a3 ?? ?? ?? ?? 68 ?? ?? ?? ?? e8 ?? ?? 00 00 83 c4 ??}
		$api00 = "LoadLibrary" ascii
		$api01 = "GetProcAddress" ascii
		$api02 = "ExitProcess" ascii
		$api03 = "advapi32.dll" ascii
		$api04 = "crypt32.dll" ascii
		$api05 = "GetTickCount" ascii
		$api06 = "Sleep" ascii
		$api07 = "GetUserDefaultLangID" ascii
		$api08 = "CreateMutex" ascii
		$api09 = "GetLastError" ascii
		$api10 = "HeapAlloc" ascii
		$api11 = "GetProcessHeap" ascii
		$api12 = "GetComputerName" ascii
		$api13 = "VirtualProtect" ascii
		$api14 = "GetUserName" ascii
		$api15 = "CryptStringToBinary" ascii
		$str0 = "JohnDoe" ascii

	condition:
		uint16( 0 ) == 0x5A4D and ( #dec > 400 and 12 of ( $api* ) and $str0 ) or for any i in ( 0 .. pe.number_of_sections -1 ) : ( pe.sections [ i ] . name == "LLCPPC" and pe.sections [ i ] . raw_data_size < 5000 )
}

rule SEKOIA_Merlin_Win_Dll : FILE
{
	meta:
		description = "Detects Merling agent (DLL)"
		author = "Sekoia.io"
		id = "c9c57f5e-26c3-43be-b2cf-10f5129d3be5"
		date = "2022-01-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/merlin_win_dll.yar#L4-L42"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "eefaed10bd3accc884673437a1cc6b8c503db4ef797e58bd95daec36a297c4be"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = ".CRT" ascii
		$s2 = ".tls" ascii
		$s3 = "github.com/Ne0nd0g/merlin" ascii
		$s4 = "github.com/lucas-clemente" ascii
		$s5 = "SendMerlinMessage" ascii

	condition:
		uint16( 0 ) == 0x5A4D and pe.imphash ( ) == "da7f8acb6151c95be088a02465d68ef8" and for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "491d9a18aea3d0eb3653fdaf0b9b86bb" ) and for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "d41d8cd98f00b204e9800998ecf8427e" ) and for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "bf619eac0cdf3f68d496ea9344137e8b" ) and for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "ce7969c1e894363133e386361be064e5" ) and for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "c6179cdcd9ba0758a18a1280f98062eb" ) and all of them and $s1 at 712 and $s2 at 752 and filesize < 15MB
}
rule SEKOIA_Ransomware_Win_Karma : FILE
{
	meta:
		description = "Detect the Karma ransomware payload"
		author = "Sekoia.io"
		id = "efd87a17-7c99-404a-8ea6-2f5c2121f9f2"
		date = "2021-08-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_win_karma.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ef272be7ae5fea084120db95f7b002e9061d72442836e836ca43ddc7b461be4e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$a1 = "KARMA" ascii
		$u1 = "KARMA" wide
		$u2 = "-ENCRYPTED.txt" wide
		$u3 = "Encrypting directory:" wide
		$u4 = "Encrypting file:" wide
		$u5 = "Trying to import ECC public key..." wide

	condition:
		uint16( 0 ) == 0x5A4D and filesize < 150KB and all of them
}

rule SEKOIA_Dropper_Win_Ninerat
{
	meta:
		description = "NineRAT dropper"
		author = "Sekoia.io"
		id = "798e3bee-4cee-4647-abda-3c3dcc602f0a"
		date = "2023-12-12"
		modified = "2024-12-19"
		reference = "https://blog.talosintelligence.com/lazarus_new_rats_dlang_and_telegram/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/dropper_win_ninerat.yar#L4-L41"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "534f5612954db99c86baa67ef51a3ad88bc21735bce7bb591afa8a4317c35433"
		hash = "f91188d23b14526676706a5c9ead05c1a91ea0b9d6ac902623bc565e1c200a59"
		logic_hash = "00f69545c7351fba8b45e2b4d21855ba8ae94f2d10df199732665e8f3f00c1b4"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "\\x64\\Release\\Dropper.pdb"
		$ = "TelegramRat\\lastest\\Dropper"

	condition:
		all of them or pe.imphash ( ) == "92b8e9dea06fd5719e29a510e95b92ac" or hash.md5 ( pe.rich_signature.clear_data ) == "ba1ea20fe779ef0b747e5073c0881a99" or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "c0471e0a78eef692b567cd89eeaddf08" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "965dc8b7c98325ca3d3371ced8424823" ) or for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "bae1db350e313bf7bbd3b2178b20e6f6dd9b0331780099374edae5a99625bc5b" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "1abb447513b4435837029933e722b6ed92222291571a8ce0a306c9f6a335aa19" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "ffbcd5bbe6c02aa5c993886811d7597f020abd6665fc82af133c5756ab72fb0a" )
}
rule SEKOIA_Rat_Darkvision_String : FILE
{
	meta:
		description = "DarkVision RAT based on string"
		author = "Sekoia.io"
		id = "ab698a79-42ee-452a-a3ba-1a9872d5e2bc"
		date = "2024-09-17"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_darkvision_string.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "8ec5526cecc596e0711c82e39cd4f2ce"
		hash = "2dd476464e46d91ffe68483cb478d9b4"
		hash = "20de7547d79d3637430b6a0787e59df5"
		hash = "60d1e02316e6f22e078f9aa710790912"
		hash = "e136e51efc22b0e071c11e7d652ea3be"
		hash = "f466be81310147fcdd9a7886735a3786"
		hash = "5065134cf4ba765bd97bb2edb61c5869"
		hash = "6ed21c4f507e8cc830141ff732bd5acc"
		hash = "40b2641150f291ca07bd08ab629fe1ed"
		hash = "3f20cd14137e0abfa84b39e29a277350"
		hash = "7dc8427be8b4d26a49fd380ad40d3b96"
		logic_hash = "63ed3b1a991dc07bd06678a58449e0a67dd9453b358c0ac82a9c38235394122b"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "DarkVision Installation" wide
		$ = "You are about to install DarkVision Remote Access Tool." wide

	condition:
		uint16be( 0 ) == 0x4d5a and 2 of them
}
rule SEKOIA_Bumblebee_Loader : FILE
{
	meta:
		description = "Detect the BUMBLEBEE loader"
		author = "Sekoia.io"
		id = "8fd795c7-6896-498c-a892-de9da6427b60"
		date = "2022-05-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/bumblebee_loader.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "73c0195c51b5f8c36ab6d7a0e783f1229709d51fc42e2486c02fa65bbbdf955b"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str0 = { 5a 00 3a 00 5c 00 68 00 6f 00 6f 00 6b 00 65 00 72 00 32 00 5c 00 43 00 6f 00 6d 00 6d 00 6f 00 6e 00 5c 00 6d 00 64 00 35 00 2e 00 63 00 70 00 70 00 }
		$str1 = "/gate" ascii
		$str2 = "3C29FEA2-6FE8-4BF9-B98A-0E3442115F67" wide
		$str3 = "BLACK" ascii

	condition:
		uint16be( 0 ) == 0x4d5a and 3 of them
}

rule SEKOIA_Loader_Win_Stealthvector : FILE
{
	meta:
		description = "Detect the StealthVector malware, updated in July 2024"
		author = "Sekoia.io"
		id = "ecf6421a-f492-43c4-9ed7-eb4724d24779"
		date = "2021-08-26"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_stealthvector.yar#L4-L32"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "166b6dcdac31f4bf51e4b20a7c3f7d4f7017ca0c30fa123d5591e25c3fa66107"
		hash = "ab56501167fe689fe55f6e6ddc3bb91952299bd5c3ef004b02bf1c3b4061c7cf"
		hash = "0faddbe1713455e3fc9777ec45adf07b28e24f4c3ddca37586c2aa6b539898c0"
		hash = "1c88150ec85a07c3db5f18c5eedcb0b653467b897af01d690ed996e5e07ba8e3"
		hash = "ec10a9396dca694fe64366e0dab82d046cf92457f97efd50a68ceb85adef6b74"
		logic_hash = "71ea017462bbb1891ef306d1e56dece5864885f5c8db5c50431ab085d37bda03"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		modification_date = "2024-07-15"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "Global\\kREwdFrOlvASgP4zWZyV89m6T2K0bIno" ascii
		$s2 = "Global\\v5EPQFOImpTLaGZes3Nl1JSKHku8AyCw" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 1 of them or pe.imphash ( ) == "0cd7b92b97ccc7e255df1f46b5299986" or pe.imphash ( ) == "be777e91e3c42ac62471cfb7239be471" or hash.md5 ( pe.rich_signature.clear_data ) == "fcc67611d136cce0e785029bbb879b45"
}
rule SEKOIA_Rat_Win_Lilith
{
	meta:
		description = "Detect the Lilith malware"
		author = "Sekoia.io"
		id = "944637e6-c4e4-423f-9f4c-a26b4fce3729"
		date = "2023-02-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_lilith.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ac2ad9e68616e6e7d07e105293545c96b72c956dbcf3c3bf317460cafc13be48"
		score = 75
		quality = 76
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = {55 6d 56 6e 55 58 56 6c 63 6e 6c 57 59 57 78 31 5a 55 56 34 51 51 3d 3d}
		$ = {67 65 74 61 64 64 72 69 6e 66 6f 3a 20 25 73}

	condition:
		all of them
}
rule SEKOIA_Downloader_Win_Curl_Agent
{
	meta:
		description = "Detect the downloader used by Bluenoroff to install it CurlAgent"
		author = "Sekoia.io"
		id = "ddeb2d8f-1b10-4a33-b768-d19412e8551a"
		date = "2023-05-02"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/downloader_win_curl_agent.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b34375ec051c969adec82901c1130b0a389261912559d70c652ee826cb2d4107"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "%s\\marcoor.dll" wide
		$ = "curl -A cur1-agent -L %s -s -d dl"
		$ = "curl -A cur1-agent -L %s -s -d da"
		$ = "cmd /c timeout /t 10 & rundll32 \"%s\" #1" wide
		$ = "cmd /c timeout /t 10 & Del /f /q \"%s\" & attrib -s -h \"%s\" & rundll32 \"%s\" #1" wide

	condition:
		3 of them
}
rule SEKOIA_Exploit_Linux_Eop_Cve20177308_Strings : CVE_2017_7308 FILE
{
	meta:
		description = "Detects CVE-2017-7308 exploit"
		author = "Sekoia.io"
		id = "72d225dd-386c-47d5-afb3-c6712c0bdd9a"
		date = "2023-12-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/exploit_linux_eop_cve20177308_strings.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c9fd605ced8bb2c3861f642cdc08b99b320ee19658ce60f1b9679a1ccc427bf7"
		score = 75
		quality = 80
		tags = "CVE-2017-7308, FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[.] SMEP & SMAP bypass enabled, turning them off"
		$ = "[.] done, SMEP & SMAP should be off now"
		$ = "[.] executing get root payload %p"
		$ = "[.] done, should be root now"

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 1MB and all of them
}
rule SEKOIA_Tool_Win_Snap2Html : FILE
{
	meta:
		description = "Finds Snap2HTML samples based on specific strings. Legitimate tool used by ransomware affiliates to perform discovery"
		author = "Sekoia.io"
		id = "9865daac-f23b-417e-813e-cbed03f45161"
		date = "2024-02-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_win_snap2html.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8805a80193ba1323dffd68456833f27cc93f2182660a5047dbe69e8ed65ac184"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "Snap2HTML.exe" fullword wide ascii
		$str02 = "Snap2HTML.Properties" ascii
		$str03 = "set_txtRoot" ascii
		$str04 = "set_chkHidden" ascii
		$str05 = "set_chkSystem" ascii
		$str06 = "set_chkLinkFiles" ascii
		$str07 = "set_txtLinkRoot" ascii
		$str08 = "set_chkOpenOutput" ascii
		$str09 = "set_txtTitle" ascii
		$str10 = "get_CancellationPending" ascii
		$str11 = "set_RootFolder" ascii
		$str12 = "add_SettingsLoaded" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 7 of them
}
rule SEKOIA_Generic_Perl_Reverse_Shell : FILE
{
	meta:
		description = "Detects simple reverse shell written in Perl"
		author = "Sekoia.io"
		id = "4eb2ef0d-3ada-4566-bd82-8c75d6931acc"
		date = "2023-12-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/generic_perl_reverse_shell.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "d0a23db712746bac4684d6b4508dd891caf06d72af153b1a0ab489a93edbfaf4"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "open(STDIN,\">&S\");"
		$ = "open(STDERR,\">&S\");"
		$ = "use Socket;$i="

	condition:
		filesize < 300 and all of them
}
rule SEKOIA_Loader_Win_Gcleaner : FILE
{
	meta:
		description = "Detect the GCleaner loader using specific strings"
		author = "Sekoia.io"
		id = "0c085da3-ec77-4141-a927-bef1578a6dee"
		date = "2022-10-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_gcleaner.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f38aaab2911e4e901780bb6df2c58f02fa80d3e39fb56f60072285d0a929ba23"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "G-Cleaner can clean unneeded files, settings, and Registry entries" ascii
		$str02 = "3.  Click \"Run G-Cleaner\"" ascii
		$str03 = "Garbage_Cleaner" ascii
		$str04 = "GCleaner.Properties" ascii
		$str05 = "SOFTWARE\\GCleaner\\Install" wide
		$str06 = "SOFTWARE\\GCleaner\\Trial" wide
		$str07 = "SOFTWARE\\GCleaner\\License" wide
		$str08 = "G-Cleaner activation" wide

	condition:
		uint16( 0 ) == 0x5A4D and 6 of them
}
rule SEKOIA_Apt_Gamaredon_Htmlsmuggling_Attachment_Stage2 : FILE
{
	meta:
		description = "Detects Gamaredon HTMLSmuggling attachment"
		author = "Sekoia.io"
		id = "e82335ea-48d5-409c-a270-cfd5a2197c44"
		date = "2023-01-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gamaredon_htmlsmuggling_attachment_stage2.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "42e637f628db6719342ae104c6c89bb80609c5f3f5c2586daccb31f7d688a2a1"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = ") == -1) die();" ascii
		$ = "'data:application/x-rar-compressed;base64, ' +" ascii
		$ = ".appendChild(img);" ascii
		$ = "['Win32', 'Win64', 'Windows', 'WinCE'].indexOf(" ascii
		$ = " = navigator[\"platform\"];" ascii

	condition:
		4 of them and filesize < 1MB
}
rule SEKOIA_Infostealer_Win_Whitesnake_Stealer_Feb23 : FILE
{
	meta:
		description = "Finds WhiteSnake samples (stealer module)"
		author = "Sekoia.io"
		id = "68ae7fbc-4486-4b60-af5e-f37ddc58f170"
		date = "2023-03-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_whitesnake_stealer_feb23.yar#L1-L31"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "90007c38c644b79b2a60d9a252bd95071c5be57c649d73b66a73a1158cddc2fb"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$fun01 = "Ibhiyptxjhiacrnxomvqjb" ascii
		$fun02 = "Irwcvmgzsduiiizaabbczm" ascii
		$whi = "WhiteSnake.Properties.Resources" ascii
		$str01 = "get_UtcNow" ascii
		$str02 = "get_IPAddress" ascii
		$str03 = "get_Ticks" ascii
		$str04 = "set_commands" ascii
		$str05 = "set_Information" ascii
		$str06 = "set_filedata" ascii
		$str07 = "get_Jpeg" ascii
		$str08 = "set_Culture" ascii
		$str09 = "MakeScreenshot" ascii

	condition:
		uint16( 0 ) == 0x5A4D and ( ( all of ( $fun* ) or $whi ) and 3 of ( $str* ) or 7 of ( $str* ) ) and filesize < 100KB
}

rule SEKOIA_Apt_Nobelium_Nativezone_Gen : FILE
{
	meta:
		description = "Detects NativeZone used in 2022"
		author = "Sekoia.io"
		id = "e16cac97-38dd-4145-95f5-cf641940a19b"
		date = "2022-02-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_nobelium_nativezone_gen.yar#L3-L31"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "63ad9fc510541f98237fa5b254dc4a147539cbf485b2889d97bf3b619c3db3ae"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$rich = { 52 69 63 68 [4] 00 }
		$obs = { C7 85 [8] C7 85 }
		$nobs = { C7 85 [6] 00 00 C7 85 }

	condition:
		pe.DLL and filesize < 2500KB and pe.number_of_exports > 20 and pe.number_of_imports < 30 and ( pe.imports ( "kernel32.dll" , "VirtualAlloc" ) and pe.imports ( "kernel32.dll" , "VirtualProtect" ) ) and for any i in ( 0 .. pe.number_of_sections - 1 ) : ( pe.sections [ i ] . name == ".rdata" and pe.sections [ i ] . raw_data_size > 300000 ) and #obs > 300 and #nobs < 150 and not $rich
}
rule SEKOIA_Apt_Apt31_Pakdoor : FILE
{
	meta:
		description = "Detects APT31 ORB implant - 2019/2021"
		author = "Sekoia.io"
		id = "463b8d0d-30f4-45ed-8f19-4b32436fbbf0"
		date = "2021-10-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt31_pakdoor.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "1d60edb577641ce47dc2a8299f8b7f878e37120b192655aaf80d1cde5ee482d2"
		logic_hash = "ef001e31b34761688f32ec767082d9d7f9fc4e4368d567eb64b66583bcb7fc78"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"
		version = "1.0"

	strings:
		$s1 = "mv -f %s %s ;chmod 777 %s"
		$s2 = "GET /plain HTTP/1.1"
		$s3 = "exc_cmd time out"
		$s4 = "exc_cmd pipe err"
		$s5 = { 2e 2f [1-10] 20 20 64 65 6c }

	condition:
		int32be ( 0 ) == 0x7f454c46 and filesize < 800KB and filesize > 400KB and 4 of ( $s* )
}
rule SEKOIA_Tool_Runpeinmemory_Strings : FILE
{
	meta:
		description = "Detects standard implementation of RunPEInMemory"
		author = "Sekoia.io"
		id = "64129ab0-b599-4760-ab21-20c475c2c07f"
		date = "2024-05-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_runpeinmemory_strings.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "154f3db98f8ee902ec7b58812525dbbef837ae30279c40b8d95ec93ae1260a69"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[+] Fix Import Address Table"
		$ = "[+] Relocation Fixed."
		$ = "[+] File %s isn't a PE file."

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 500KB and all of them
}

rule SEKOIA_Backdoor_Win_Sidewinder_Cobaltstrike_2022_09
{
	meta:
		description = "Detect the SideWinder malware"
		author = "Sekoia.io"
		id = "b5e8f87a-4a2c-49bb-aa98-bf3fb5056b23"
		date = "2022-10-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_win_sidewinder_cobaltstrike_2022_09.yar#L4-L29"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f2b719170783c1bfaa4c4772e5cff73797be3056204566844c236d1857869e4c"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = {65004e004500560045005200200047004f004e004e00410020004700490056004500200059004f0055002000550050002100}

	condition:
		$s1 or pe.imphash ( ) == "b1e345b2d78e4b82617d995d18100790" or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "ac989507d4af352fa354560efef99ba6" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "8090b29a44c750b7b21287f9639fe747" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "ea8693d6bacf3e7876f717a3d8abc433" )
}
rule SEKOIA_Generic_Sharpshooter_Payload_4 : FILE
{
	meta:
		description = "Detects payload created by SharpShooter"
		author = "Sekoia.io"
		id = "b8327436-3f3d-441c-86b7-35cd30144dc2"
		date = "2023-02-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/generic_sharpshooter_payload_4.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ee67eb7b51ff6f3882c6b3ad86c3581396ba02f616c29a0190d0a2ad3d2ea614"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Function RC4(byteMessage, strKey)"
		$ = "Set EL = DM.createElement("
		$ = "decodeBase64 = EL.NodeTypedValue"
		$ = "Execute plain"

	condition:
		all of them and filesize < 2MB
}
rule SEKOIA_Apt_Badmagic_Listfiles_Pshscript : FILE
{
	meta:
		description = "Detects BadMagic ListFiles powershell script"
		author = "Sekoia.io"
		id = "55f1c409-234e-4feb-91a3-9bf5c41ec2b8"
		date = "2023-05-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_badmagic_listfiles_pshscript.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "4401d31e4b0484776aab51c161a301fc4ee3e944a1669df763bd274014178368"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "$env:USERPROFILE"
		$ = "-Include *.jpg, *.odt, *.doc, *.docx"

	condition:
		all of them and filesize < 1KB
}
rule SEKOIA_Tool_Enum4Linux_Strings
{
	meta:
		description = "Detects enum4linux based on strings"
		author = "Sekoia.io"
		id = "6b3094fe-1292-4da3-a1ed-9e255be531da"
		date = "2024-02-02"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_enum4linux_strings.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "d3f7ddbdfb679b34777298aec84464d55fac7600b855526a7f13d8c8f17ab888"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "my $os_info = `$command`;"
		$ = "($global_workgroup) = $os_info =~"
		$ = "sub enum_groups {"
		$ = "if ($shares =~ /NT_STATUS_ACCESS_DENIED/) {"
		$ = "Can't open share list file $shares_file"
		$ = "my $users = `$command`;"
		$ = "my @shares = <SHARES>;"
		$ = "foreach my $grouptype (\"builtin\", \"domain\") {"

	condition:
		6 of them
}
rule SEKOIA_Stealer_Win_Demotryspy : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "70af0e40-b177-49a3-bff4-723f3f4aa375"
		date = "2024-02-09"
		modified = "2024-12-19"
		reference = "https://paper.seebug.org/3115/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/stealer_win_demotryspy.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b7a910e4d394d2122e6b4fe76daa6691a642396e27f7a47d09232f4b7eb424ee"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$demotry1 = "DemoTry.exe"
		$demotry2 = "DemoTry\\Release\\DemoTry.pdb"
		$wide1 = "\\loc.tmp" wide
		$wide2 = "\\log.tmp" wide
		$wide3 = "\\Google\\Chrome\\User Data" wide
		$wide4 = "\\Default\\Login data" wide
		$wide5 = "\\Local State" wide

	condition:
		uint16be( 0 ) == 0x4d5a and ( 1 of ( $demotry* ) or all of ( $wide* ) )
}

rule SEKOIA_Implant_Win_Graphiron_Downloader : FILE
{
	meta:
		description = "Detect the downloader of Graphiron"
		author = "Sekoia.io"
		id = "c50c4bd2-3828-43bf-b45c-8e911c298536"
		date = "2023-02-10"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_win_graphiron_downloader.yar#L4-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "0d0a675516f1ff9247f74df31e90f06b0fea160953e5e3bada5d1c8304cfbe63"
		hash = "878450da2e44f5c89ce1af91479b9a9491fe45211fee312354dfe69e967622db"
		logic_hash = "f0aa0541cbf3f93ee136cf3235a4935f1c0588b5cdb21203abee9f61baf3f4f2"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "1b614f8d813125f56d2e772ed0ca5dae" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "5c6496d33de5a35bd38ddb12d8b42e03" ) and filesize > 3MB and filesize < 6MB
}
rule SEKOIA_Clwiper_Strings : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "91e531e2-8548-460f-88a8-cc09abb901e0"
		date = "2022-09-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/clwiper_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b6bcd7e20b07ab8a9a54672f60a8ffe6d6bf787630f01b9dcefd1cbc78297050"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$w1 = "missing args"
		$w2 = "wp starts"
		$w3 = "Total Bytez : %lld"
		$w4 = "percent is %f spent time is %.2fs"
		$d1 = "\\\\?\\RawDisk3"
		$d2 = "B4B615C28CCD059CF8ED1ABF1C71FE03C0354522990AF63ADF3C911E2287A4B906D47D"

	condition:
		uint16be( 0 ) == 0x4d5a and ( 3 of ( $w* ) or all of ( $d* ) )
}
rule SEKOIA_Infostealer_Win_Lumma_Strings_Aug23 : FILE
{
	meta:
		description = "Finds Lumma samples based on the specific strings"
		author = "Sekoia.io"
		id = "728f7825-a463-4b19-b2d3-3460e4c06dc9"
		date = "2023-09-14"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_lumma_strings_aug23.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "704a31b0f7c30602305768f13bf6108ebaf08c62451833731d2f2f020efce386"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "lid=%s&j=%s&ver" ascii
		$str02 = "%s (%d.%d.%d)" ascii
		$str03 = "- Screen Resoluton:" ascii
		$str04 = "- Physical Installed Memory:" ascii
		$str05 = "Content-Type: attachment/x-object" ascii
		$str06 = "Content-Type: application/x-www-form-urlencoded" ascii
		$str07 = "Content-Type: multipart/form-data; boundary=%s" wide
		$str08 = "SysmonDrv" wide
		$str09 = "TeslaBrowser/5.5" wide

	condition:
		uint16( 0 ) == 0x5A4D and 6 of them
}
rule SEKOIA_Generic_Sharpshooter_Payload_13 : FILE
{
	meta:
		description = "Detects payload created by SharpShooter"
		author = "Sekoia.io"
		id = "2d61d7b8-5348-4cc8-9d41-61799b573e3b"
		date = "2023-02-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/generic_sharpshooter_payload_13.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "fb6b71bf1e89abf872fb3ef02a228f370f0fcc10d5aab70418fe8735283165da"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Private Function decodeHex(hex)"
		$ = "EL.Text = hex "
		$ = "serialized_obj = serialized_obj & "
		$ = "d.DynamicInvoke(al.ToArray()).CreateInstance(entry_class)"

	condition:
		all of them and filesize < 2MB
}

rule SEKOIA_Latrodectus_Exports : FILE
{
	meta:
		description = "detection based on the exports"
		author = "Sekoia.io"
		id = "29076cf5-f391-42f2-918f-e1c929bd368d"
		date = "2024-07-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/latrodectus_exports.yar#L3-L15"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "01385f31b1f2fc94453a2ead136a1f7fb253a72bee95f74d755acfa97abdb26d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		(pe.exports ( "stow" ) or pe.exports ( "homq" ) or pe.exports ( "scub" ) ) and pe.number_of_exports >= 3 and uint16( 0 ) == 0x5a4d
}

rule SEKOIA_Plugx_Final_Payload : FILE
{
	meta:
		description = "Detects encrypted plugx config with a specific size"
		author = "Sekoia.io"
		id = "a4047324-81a7-4c17-be84-c0fa479d2f89"
		date = "2023-07-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/plugx_final_payload.yar#L3-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "bf5035eb7ed620edcf7a0e8e8be220451ce268fc49310f28059b60576d8c5182"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = {30 31 32 33 34 35 36 37 38 39 41 42 43 44 45 46 88 13 00 00 60 ea 00 00 ?? ?? ?? ?? 00 00 00 00}

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 8MB and for any i in ( 0 .. pe.number_of_sections -1 ) : ( pe.sections [ i ] . name == ".data" and $s1 in ( pe.sections [ i ] . raw_data_offset..pe.sections [ i ] . raw_data_offset + pe.sections [ i ] . raw_data_size ) )
}
rule SEKOIA_Apt_Oilrig_Sc5Kv3_Strings : FILE
{
	meta:
		description = "Detects SC5kv3 malware based on strings"
		author = "Sekoia.io"
		id = "885ea13b-47b0-4a6d-8136-9b31abc9064a"
		date = "2023-12-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_oilrig_sc5kv3_strings.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ace8e227abd97d0ec21815cc58c24d46e4944f2b0e1987672be53f81356a7a57"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "no-reply this email!" ascii wide
		$ = "The serial is " ascii wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 5MB and all of them
}
rule SEKOIA_Apt_Apt41_Powershell_Collection_Script : FILE
{
	meta:
		description = "Detects PowerShell collection script"
		author = "Sekoia.io"
		id = "55b6cc3e-24b2-4faa-a7fb-b4203a8e6d83"
		date = "2023-11-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt41_powershell_collection_script.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8b0462636c9f6270baff2bf09638e94db6d5a0472b8216ddd1919a77b6a63aca"
		score = 75
		quality = 70
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "$yestoday.ToString(" ascii wide nocase
		$ = "$m.LastAccessTime -" ascii wide nocase
		$ = "$fmat=" ascii wide nocase
		$ = "$computername" ascii wide nocase
		$ = "Rar.exe" ascii wide nocase

	condition:
		filesize < 10KB and all of them
}

rule SEKOIA_Icebot_Exported_Function : FILE
{
	meta:
		description = "Detects the IceBot RAT used by FIN7 based on the exported function"
		author = "Sekoia.io"
		id = "1a1fb651-6ce3-4751-be23-c27a3d8dabde"
		date = "2022-01-17"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/icebot_exported_function.yar#L4-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "5ee5b869689686d9352c73173304627bb424b8d0a8510e6f16726ac84fdec79d"
		hash = "0f76768f65775329d7a0ddb977ea822d992d086ce48a23679cef66e3b4d2f4ed"
		hash = "f06c7f1b91fb2f64e1f38df6eaf2b52a74b16cc958d74c4401fdaf180deb595a"
		hash = "cbed0cf3273ce544a7e4e316d5c8f5e9c9ac6deaefa485a6afad2654fe75ff1e"
		logic_hash = "c029693f555726d28375717fe459ccf4521d2d63fc7053032bbafd60129848f0"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$a = {cc cc cc 48 89 4c 24 ?? 53 55 56 57 41 54 41 55 41 56 41 57 ?? ?? ?? ?? 33 f6 44 8b ee 48 89 74 24 ?? 8b ee 48 89 b4 24 ?? ?? ?? ?? 44 8b f6 48 89 74 24 ?? 44 8b e6 e8 bf ff ff ff 4c 8b f8 8d 5e ?? b8 ?? ?? ?? ?? 66 41 39 07 75 1b 49 63 57 ?? 48 8d 4a ?? 48 81 f9 ?? ?? ?? ?? 77 0a 42 81 3c 3a ?? ?? ?? ?? 74 05 4c 2b fb eb d5 65 48 8b 04 25 ?? ?? ?? ?? bf ?? ?? ?? ?? 4c 89 bc 24 ?? ?? ?? ?? 48 8b 48 ?? 4c 8b 59 ?? 4c 89 9c 24 ?? ?? ?? ?? 4d 85 db 0f 84 d5 01 00 00 41 b9 ff ff 00 00 49 8b 53 ?? 48 8b c6 45 0f b7 43 ?? 0f b6 0a c1 c8 ?? 80 f9 ?? 72 04 48 83 c0 ?? 48 03 c1 48 03 d3 66 45 03 c1 75 e5 3d ?? ?? ?? ?? 0f 85 d2 00 00 00 49 8b 53 ?? 41 bb ff ff 00 00 48 63 42 ?? 8b b4 10 ?? ?? ?? ?? 44 8b 54 16 ?? 8b 5c 16 ?? 4c 03 d2 48 03 da 45 33 c9 45 8d 79 ?? 45 8b 02 41 8b c9 4c 03 c2 41 8a 00 4d 03 c7 c1 c9 ?? 0f be c0 03 c8 41 8a 00 84 c0 75 ee 81 f9 ?? ?? ?? ?? 74 10 81 f9 ?? ?? ?? ?? 74 08 81 f9 ?? ?? ?? ?? 75 44 44 8b 4c 16 ?? 44 0f b7 03 4c 03 ca 81 f9 ?? ?? ?? ?? 75 09 47 8b 2c 81 4c 03 ea eb 20 81 f9 ?? ?? ?? ?? 75 09 43 8b 2c 81 48 03 ea eb 0f 81 f9 ?? ?? ?? ?? 75 07 47 8b 34 81 4c 03 f2 66 41 03 fb 45 33 c9 49 83 c2 ?? 48 83 c3 ?? 66 85 ff 0f 85 75 ff ff ff 4c 8b 9c 24 ?? ?? ?? ?? 33 f6 48 89 ac 24 ?? ?? ?? ?? 4c 89 6c 24 ?? e9 8d 00 00 00 3d ?? ?? ?? ?? 0f 85 90 00 00 00 4d 8b 43 ?? 41 bf ?? ?? ?? ?? 41 0f b7 ff bd ff ff 00 00 49 63 40 ?? 42 8b 9c 00 ?? ?? ?? ?? 46 8b 4c 03 ?? 46 8b 54 03 ?? 4d 03 c8 4d 03 d0 41 8b 11 8b ce 49 03 d0 8a 02 49 03 d7 c1 c9 ?? 0f be c0 03 c8 8a 02 84 c0 75 ef 81 f9 ?? ?? ?? ?? 75 16 42 8b 4c 03 ?? 41 0f b7 12 49 03 c8 44 8b 24 91 4d 03 e0 66 03 fd 49 83 c1 ?? 49 83 c2 ?? 66 85 ff 75 ba 48 8b ac 24 ?? ?? ?? ?? 4c 89 64 24 ?? 41 b9 ff ff 00 00 bf ?? ?? ?? ?? 49 8b df 4d 85 ed 74 0f 48 85 ed 74 0a 4d 85 f6 74 05 4d 85 e4 75 14 4d 8b 1b 4c 89 9c 24 ?? ?? ?? ?? 4d 85 db 0f 85 39 fe ff ff 4c 8b bc 24 ?? ?? ?? ?? 49 63 6f ?? 33 c9 49 03 ef 89 b4 24 ?? ?? ?? ?? 41 b8 00 ?? ?? ?? 48 89 6c 24 ?? 4c 8b e6 44 8d 49 ?? 8b 55 ?? 41 ff d6 44 0f b7 45 ?? 48 8b f8 44 0f b7 55 ?? 49 83 c0 ?? 4d 85 d2 74 4f 4c 03 c5 41 8b 00 4c 2b d3 45 8b 48 ?? 41 8b 48 ?? 48 03 cf 49 8d 14 07 41 03 c1 89 84 24 ?? ?? ?? ?? 48 8b c1 48 2b c2 4d 85 e4 49 0f 45 c4 4c 8b e0 4d 85 c9 74 0f 8a 02 48 03 d3 88 01 48 03 cb 4c 2b cb 75 f1 49 83 c0 ?? 4d 85 d2 75 b4 8b 85 ?? ?? ?? ?? 41 be ?? ?? ?? ?? 85 c0 0f 84 e8 00 00 00 48 8d 1c 07 8b 43 ?? 85 c0 0f 84 d9 00 00 00 48 8b ac 24 ?? ?? ?? ?? 8b c8 48 03 cf 41 ff d5 44 8b 7b ?? 33 c9 8b 33 4c 03 ff 48 03 f7 4c 8b e8 49 39 0f 74 7d 48 85 f6 74 31 48 39 0e 7d 2c 49 63 45 ?? 0f b7 16 42 8b 8c 28 ?? ?? ?? ?? 42 8b 44 29 ?? 42 8b 4c 29 ?? 48 2b d0 49 03 cd 8b 04 91 49 03 c5 49 89 07 33 c9 eb 2a 4d 8b 37 49 8b cd 49 83 c6 ?? 4c 03 f7 49 8b d6 ff d5 33 c9 49 89 07 41 38 0e 74 0e 8d 41 ?? 41 88 0e 4c 03 f0 41 38 0e 75 f5 49 83 c7 ?? 48 8d 46 ?? 48 85 f6 48 0f 44 c6 48 8b f0 49 39 0f 75 89 41 be ?? ?? ?? ?? 8b 43 ?? 48 03 c7 33 f6 eb 06 40 88 30 49 03 c6 40 38 30 75 f5 8b 43 ?? 48 83 c3 ?? 4c 8b 6c 24 ?? 85 c0 0f 85 3c ff ff ff 48 8b 6c 24 ?? 4c 8b bc 24 ?? ?? ?? ?? 4c 8b cf 4c 2b 4d ?? 39 b5 ?? ?? ?? ?? 0f 84 b5 00 00 00 8b 95 ?? ?? ?? ?? 48 03 d7 8b 42 ?? 85 c0 0f 84 a1 00 00 00 41 bf ?? ?? ?? ?? bb ff ?? ?? ?? 45 8d 6f ?? 44 8b 02 4c 8d 5a ?? 44 8b d0 4c 03 c7 49 83 ea ?? 49 d1 ea 74 62 41 be ?? ?? ?? ?? 41 0f b7 0b 4d 2b d6 0f b7 c1 66 c1 e8 ?? 66 83 f8 ?? 75 09 48 23 cb 4e 01 0c 01 eb 34 66 41 3b c5 75 09 48 23 cb 46 01 0c 01 eb 25 66 41 3b c6 75 11 48 23 cb 49 8b c1 48 c1 e8 ?? 66 42 01 04 01 eb 0e 66 41 3b c7 75 08 48 23 cb 66 46 01 0c 01 4d 03 df 4d 85 d2 75 a7 8b 42 ?? 48 03 d0 8b 42 ?? 85 c0 0f 85 7a ff ff ff 4c 8b bc 24 ?? ?? ?? ?? 44 8d 70 ?? 8b 5d ?? 45 33 c0 33 d2 48 83 c9 ff 48 03 df ff 54 24 ?? e8 21 fb ff ff 4d 85 e4 74 13 48 85 c0 74 0e 4a 8d 0c 20 4c 8b e6 e8 67 00 00 00 eb 3b 8b 94 24 ?? ?? ?? ?? c1 ea ?? 89 b4 24 ?? ?? ?? ?? eb 1d 48 63 84 24 ?? ?? ?? ?? 41 89 34 87 8b 84 24 ?? ?? ?? ?? 41 03 c6 89 84 24 ?? ?? ?? ?? 8b 84 24 ?? ?? ?? ?? 3b c2 72 d8 4c 8b 84 24 ?? ?? ?? ?? ba ?? ?? ?? ?? 48 8b cf ff d3 49 8d 04 3c ?? ?? ?? ?? 41 5f 41 5e 41 5d 41 5c 5f 5e 5d 5b c3}

	condition:
		uint16( 0 ) == 0x5A4D and $a or pe.imphash ( ) == "37af5cd8fc35f39f0815827f7b80b304" or hash.md5 ( pe.rich_signature.clear_data ) == "b857cf76a54ce175c225eaaae66547a2"
}
rule SEKOIA_Trojan_And_Keepspy : FILE
{
	meta:
		description = "Finds KeepSpy samples based on specific strings"
		author = "Sekoia.io"
		id = "9390e7c8-a996-45cc-b642-c23d4b7dcf34"
		date = "2023-06-28"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/trojan_and_keepspy.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "03a954a5585a9a80fdc5a0cd2644a819c540d43b260e040b627530ca88ee08fa"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "Characters entered %1$d of %2$d" ascii
		$str02 = "com.google.android.material.behavior.HideBottomViewOnScrollBehavior" ascii
		$str03 = "com/j256/ormlite/core/VERSION.txt" ascii
		$str04 = "res/raw/empty.wav" ascii
		$str05 = "res/mipmap/ic_launcher.png" ascii
		$str06 = "res/interpolator/fast_out_slow_in.xml" ascii
		$str07 = "OnePixelActivity" ascii

	condition:
		uint32be( 0 ) == 0x504B0304 and 6 of them and filesize > 2MB
}
rule SEKOIA_Ransomware_Lin_Avoslocker_Strings : FILE
{
	meta:
		description = "Detect AvosLocker ransomware for Linux by using strings from its ransom note and the onion domains"
		author = "Sekoia.io"
		id = "6056e15c-d656-41cb-bea0-704776c52c92"
		date = "2022-02-21"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_lin_avoslocker_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "0cd7b6ea8857ce827180342a1c955e79c3336a6cf2000244e5cfd4279c5fc1b6"
		hash = "7c935dcd672c4854495f41008120288e8e1c144089f1f06a23bd0a0f52a544b1"
		hash = "10ab76cd6d6b50d26fde5fe54e8d80fceeb744de8dbafddff470939fac6a98c4"
		logic_hash = "b65cf6713027644de281f17a4c5c170fc09a154e7119d04a92aceed0e2d7e4fd"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "The corporations whom don't pay or fail to respond in a swift manner can be found in our blog, accessible at" ascii
		$s2 = "http://avosqxh72b5ia23dl5fgwcpndkctuzqvh2iefk5imp3pi5gfhel5klad.onion" ascii
		$s3 = "http://avosjon4pfh3y7ew3jdwz6ofw7lljcxlbk7hcxxmnxlh5kvf2akcqjad.onion" ascii

	condition:
		uint32( 0 ) == 0x464c457f and all of them
}
rule SEKOIA_Tool_Rathole_Strings : FILE
{
	meta:
		description = "Detects RATHole based on strings"
		author = "Sekoia.io"
		id = "39d11285-a3bf-46c3-901d-ab46601a9066"
		date = "2024-05-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_rathole_strings.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f7c42328a38b2c101ea2d179b6adf9cf3d842d9e1c91e85fc6e684ee4f82458f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "rathole\\src\\" ascii
		$ = "\\\\?\\\\\\?\\UNC\\" wide
		$ = "rathole::" ascii
		$ = "src/server.rs"
		$ = "`[server]` or `[client]"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a or uint32be( 0 ) == 0xfeedface or uint32be( 0 ) == 0xfeedfacf or uint32be( 0 ) == 0xcafebabe or uint32be( 0 ) == 0xCFFAEDFE ) and 3 of them
}
rule SEKOIA_Apt_Turla_Comlook : FILE
{
	meta:
		description = "Detects Class and Method names used inside ComLook"
		author = "Sekoia.io"
		id = "c3bf886b-f952-47f9-aff6-3cd74c27077d"
		date = "2023-10-30"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_turla_comlook.yar#L1-L31"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "882a2efda4c3888c34a2802797c9eac4ab8b96774f2eea19e586ff9c8adb9292"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ClassName1 = "AgentConfig"
		$ClassName2 = "CommandPerforming"
		$MethodName1 = "CmdCommand"
		$MethodName2 = "GetConfigCommand"
		$MethodName3 = "GetFileCommand"
		$MethodName4 = "PutFileCommand"
		$MethodName5 = "SetConfigCommand"
		$MethodName6 = "AgentProtocol"
		$Log1 = "CONFIG_SERVERS_LIST_PARSING_ERROR" ascii wide
		$Log2 = "GET_UIDS_TO_CHECK_PARSING_ERROR" ascii wide
		$Log3 = "PAYLOAD_PARSING_FILEPATH_AND_FILE_ERROR" ascii wide
		$Log4 = "COMMAND_EMPTY_ERROR" ascii wide
		$Log5 = "IMAP_USERNAME_FORMAT_INCORRECT" ascii wide
		$Log6 = "NO_MESSAGES_TO_RETRIEVE" ascii wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 10MB and any of ( $ClassName* ) and any of ( $MethodName* ) and any of ( $Log* )
}
rule SEKOIA_Hacktool_Ntdsdumpex_Strings : FILE
{
	meta:
		description = "Detects NTDSDumpEx based on strings"
		author = "Sekoia.io"
		id = "9a0fe20a-49e9-4aaf-8f0e-d51800e0a6e0"
		date = "2022-02-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_ntdsdumpex_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "3295816133ca00aeaf3f4967135ed045ed64d20393f482eafbe4e74f0f63aa47"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Example : ntdsdumpex.exe -r" ascii wide
		$ = "[x]can not open output file %s for write." ascii wide
		$ = "[+]dump completed in %.3f seconds." ascii wide
		$ = "[+]total %d entries dumped,%d" ascii wide
		$ = "[x]can not get PEK!" ascii wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 200KB and 3 of them
}
rule SEKOIA_Apt_Lazarus_Backdoored_Jslib : FILE
{
	meta:
		description = "Detects InvisibleFerret based on common ressource."
		author = "Sekoia.io"
		id = "73ffd449-93c8-494e-9c14-2e933b21a200"
		date = "2024-10-28"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_lazarus_backdoored_jslib.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "52e92be527690f4e63608cbc699e2f70"
		logic_hash = "205ad321afcb22ae2bf6cf2a58ce970ea9b0edda7fab60ddeda5ea36ecfe3cb9"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$obf = "(function(_0x" ascii
		$exp = "module.exports =" ascii

	condition:
		$exp in ( filesize -500 .. filesize ) and #obf == 1
}

rule SEKOIA_Backdoor_Win_Andardoor : FILE
{
	meta:
		description = "Detect the Andardoor backdoor used by Andariel"
		author = "Sekoia.io"
		id = "27f28f6e-b8fd-41dc-88a8-92f5a125a807"
		date = "2023-09-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_win_andardoor.yar#L4-L34"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "631836634222f4e081d3070c92150a4e14f06bcdd462fbfdf0756aa1f2661b59"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = " : Deleted Dir" wide
		$ = " : Not Exists" wide
		$ = " : Deleted File" wide
		$ = " : Closed." wide
		$ = " : Opened." wide
		$ = "GoodLuck!" wide

	condition:
		uint16( 0 ) == 0x5A4D and all of them or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "9fea4972270c492ca304f3663913ae63" ) or for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "34fde27c3c864efa6225e72016992d341f29cbbea638432a1c63ce05ca568300" )
}
rule SEKOIA_Crime_Sload_Vbs_Wsf_Downloader : FILE
{
	meta:
		description = "Detects sLoad Downloader"
		author = "Sekoia.io"
		id = "55d87205-5f8f-479a-a616-bf3fce571f03"
		date = "2022-08-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/crime_sload_vbs_wsf_downloader.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "bd6a9112edb01544463aa7112432ad49360221e89a9ac15d5e8f6731b2b8780a"
		score = 75
		quality = 76
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = { 53 65 74 20 6c 69 6e 6b 20 3d 20 [5-10] 2e 43 72 65 61 74 65 53 68 6f 72 74 63 75 74 28 }
		$ = { 2e 72 75 6e 20 22 63 3a 5c 55 73 65 72 73 5c 50 75 62 6c 69 63 5c 44 6f 63 75 6d 65 6e 74 73 5c [5-10] 2e 6c 6e 6b 20 2f 63 20 70 6f 77 65 72 73 68 65 6c 6c }
		$ = { 3d 22 20 2f 63 20 70 6f 77 65 72 73 68 65 6c 6c 20 22 }
		$ = { 20 2f 63 20 70 6f 77 65 72 73 68 65 6c 6c 20 22 20 26 20 }

	condition:
		2 of them and filesize < 1KB
}
rule SEKOIA_Exploit_Win_Cloudatlas_Cve_2018_0798 : CVE_2018_0798 FILE
{
	meta:
		description = "Detect RTF files used by CloudAtlas to exploit CVE-2018-0798"
		author = "Sekoia.io"
		id = "fcff4bc7-fe88-4546-bb5b-f2a1c2f8b0a5"
		date = "2022-11-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/exploit_win_cloudatlas_cve_2018_0798.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "c2064c7f4826c46bc609c472597366fd"
		hash = "e2281402c63d4b544b81678250d24e61"
		hash = "a97fa135d7e42886bcfdacca0d96c047"
		logic_hash = "1ed1009d77835f60834c20e61158b00ce7416ade8aa86c3314f4d8d1f6742fa0"
		score = 75
		quality = 80
		tags = "CVE-2018-0798, FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "6060606061616161616161616161616161616161" ascii nocase
		$ = "FB0B00004bE8FFFFFFFFC35F83C71B33C966B908" ascii nocase
		$ = "010f0d00ddd8d97424f4668137" ascii nocase

	condition:
		uint32be( 0 ) == 0x7b5c7274 and all of them
}
rule SEKOIA_Apt_Sandworm_Awfulshred_Obfuscation_Apr2022 : FILE
{
	meta:
		description = "Detects the AWFULSHRED wiper used by Sandworm"
		author = "Sekoia.io"
		id = "52317e6b-7f2c-4c2a-bcfc-ebb4ab4c728e"
		date = "2022-04-12"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_sandworm_awfulshred_obfuscation_apr2022.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "3e1eed3a4b638893828289f928a75b855bc9e1e29444ffa81c0461fdc1277cad"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$h = "#!/bin/bash"
		$s = { 64 65 63 6c 61 72 65 20 2d 72 20 [8] 3d }

	condition:
		$h at 0 and #s > 15
}
rule SEKOIA_Hacktool_Ligolo_Relay_Strings : FILE
{
	meta:
		description = "Detects Ligolo Relay based on strings"
		author = "Sekoia.io"
		id = "1e32f2e5-b66b-4b55-9dd4-1402b2f627ed"
		date = "2022-02-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_ligolo_relay_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "57150b394cc7af9ae786b63d83acc29529fa037f0a52afde0e12a2eef93bf6c8"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "ligolo/cmd/localrelay"
		$ = "main.LigoloRelay.Start"
		$ = "main.LigoloRelay.startRelayHandler"
		$ = "main.LigoloRelay.startLocalHandler"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize > 2MB and filesize < 5MB and 3 of them
}
rule SEKOIA_Evilnumpayload_Fmtstr
{
	meta:
		description = "Detect payload of EvilNum"
		author = "Sekoia.io"
		id = "980c58e4-e04d-4076-a92e-2c04ced19ece"
		date = "2022-07-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/evilnumpayload_fmtstr.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "7aa55d0677e58658bb76a2d7386a7434011b5f9b8c9de1b718c37f85907ddcc3"
		score = 75
		quality = 80
		tags = ""
		version = "1.1"
		classification = "TLP:CLEAR"

	strings:
		$fmtstr01 = "{\"v\":\"" ascii wide
		$fmtstr02 = ",\"u\":\"" ascii wide
		$fmtstr03 = ",\"a\":\"" ascii wide
		$fmtstr04 = ",\"w\":\"" ascii wide
		$fmtstr05 = ",\"d\":\"" ascii wide
		$fmtstr06 = ",\"n\":\"" ascii wide
		$fmtstr07 = ",\"r\":\"1\"" ascii wide
		$fmtstr08 = ",\"r\":\"0\"" ascii wide
		$fmtstr09 = ",\"xn\":\"" ascii wide
		$fmtstr10 = ",\"s\":0}" ascii wide
		$fmtstr11 = "{\"u\":\"" ascii wide
		$fmtstr12 = "\",\"sc\":1" ascii wide
		$fmtstr13 = ",\"dt\":\"" ascii wide

	condition:
		8 of ( $fmtstr* )
}

rule SEKOIA_Backdoor_Win_Winordll64
{
	meta:
		description = "Detect the WinorDLL64 backdoor"
		author = "Sekoia.io"
		id = "86a32538-bc69-47ea-9842-4af360588c27"
		date = "2023-02-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_win_winordll64.yar#L4-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "30e6f01f30d6ef11c75e133d309cebc87b69ede8eb38aa14d237760e99b52c54"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		hash.md5( pe.rich_signature.clear_data ) == "d16713cbfe04151b3a9e832c8afd55df" or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "3f638774c2565594029fb52ceb67db7a" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "f9416bfb43b2c70837927e43e7591a2a" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "6eede2cebaef39eec5bd1c24c809e3dc" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "1177658fb0469cd5982102c9f3cd2eea" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "658d877d1bf0d2928b2c3efec9ec06cf" ) or pe.imphash ( ) == "d6b6f8cdffb06f469e06c7af9639897c"
}

rule SEKOIA_Rootkit_Win_Purplefox_Kernel_Driver : FILE
{
	meta:
		description = "Detect the Purple Fox trojan"
		author = "Sekoia.io"
		id = "798dc20b-76cd-4e31-b9ee-f363fb39cd58"
		date = "2022-03-28"
		modified = "2024-12-19"
		reference = "https://www.trendmicro.com/content/dam/trendmicro/global/en/research/22/c/purple-fox-uses-new-arrival-vector-and-improves-malware-arsenal/IOCs-Purple-Fox.txt"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rootkit_win_purplefox_kernel_driver.yar#L3-L35"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "91d7caca7c0c41e70813d52b5662bf0238d078fca519bfc2c03f3f87fe3805b8"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "\\DosDevices\\Global\\MyDriver" wide
		$ = "IOCTL_IO_KILL_PROCESS" ascii
		$ = "IOCTL_IO_DELET_FILE" ascii
		$ = "IOCTL_IO_COPY_FILE" ascii
		$ = "IOCTL_IO_KILL_MINIFITER" ascii

	condition:
		uint16( 0 ) == 0x5A4D and all of them or ( pe.rich_signature.toolid ( 171 , 30319 ) and pe.rich_signature.toolid ( 158 , 30319 ) and pe.rich_signature.toolid ( 170 , 30319 ) and pe.rich_signature.toolid ( 147 , 30729 ) and pe.rich_signature.toolid ( 1 , 0 ) ) and for any i in ( 0 .. pe.number_of_signatures -1 ) : ( pe.signatures [ i ] . thumbprint == "c7939f8303ca22effb28246e970b13bee6cb8043" )
}
rule SEKOIA_Rat_Win_Atharvan
{
	meta:
		description = "Detect Atharvan RAT"
		author = "Sekoia.io"
		id = "61347490-d281-4892-adba-89cf6187545f"
		date = "2023-02-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_atharvan.yar#L1-L15"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "fee9a5a684b3e9bd629a0e87bdf63ba0c1fc1e970ca3b7fec8d7a4f2f60a355a"
		score = 75
		quality = 78
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = {44 3a 5c 72 61 6e 67 5c 54 4f 4f 4c 5c 33 52 41 54}

	condition:
		all of them
}
rule SEKOIA_Tool_Iodine_Strings : FILE
{
	meta:
		description = "Detects iodine based on strings"
		author = "Sekoia.io"
		id = "029766cc-80fb-423d-adc5-8867c438c5d3"
		date = "2024-02-02"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_iodine_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "049b5af42d204061bd7e0c0294bb0abea492647dce8ec63fa3f296d1a19cb246"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Sending DNS queries for %s to %s"
		$ = "No tun devices found, trying utun"
		$ = "iodine IP over DNS tunneling client"
		$ = "topdomain is the FQDN that is delegated to the tunnel endpoint."

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 1MB and 3 of them
}
rule SEKOIA_Tool_Win_Gosecretsdump : FILE
{
	meta:
		description = "Finds gosecretsdump EXE based on strings"
		author = "Sekoia.io"
		id = "9225fe95-e37c-48ff-b5b5-680f255349bd"
		date = "2024-06-10"
		modified = "2024-12-19"
		reference = "https://github.com/C-Sto/gosecretsdump/releases"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_win_gosecretsdump.yar#L1-L27"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "957b0deae745e4fda5a790acc391cebf9d193efb2a19ad5eb18c54da8c17bcfa"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "github.com/C-Sto/gosecretsdump" ascii
		$str02 = "/pkg/esent" ascii
		$str03 = "/pkg/ditreader" ascii
		$str04 = "/pkg/samreader" ascii
		$str05 = "ntdsFileLocation" ascii
		$str06 = "NTDSLoc" ascii
		$str07 = "SAMEntries" ascii
		$str08 = "SAMHashAES" ascii
		$str09 = "NTLMHash" ascii
		$str10 = "HasNoLMHashPolicy" ascii
		$str11 = "PreviousIncBackup" ascii
		$str12 = "Esent_record" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 7 of them
}
rule SEKOIA_Ransomware_Win_Wing : FILE
{
	meta:
		description = "Finds Wing ransomware samples based on specific strings"
		author = "Sekoia.io"
		id = "c2fe8321-8013-4aa4-91a6-c0face3e6b52"
		date = "2024-01-30"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_win_wing.yar#L1-L52"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c9f373c12f4fb5efc29d0f293a2e0b46cf03c1abe124e9dd4118bef6c6e3f731"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$fun01 = "LockBIT" ascii fullword
		$fun02 = "BigEncrypt" ascii
		$fun03 = "RunEncrypt" ascii
		$fun04 = "AesEncrypt" ascii
		$fun05 = "KeyGenerator" ascii
		$fun06 = "GetUniqueKey" ascii
		$fun07 = "SearchFolder" ascii
		$fun08 = "ThreadFolders" ascii
		$fun09 = "ContainsKeyword" ascii
		$fun10 = "ReadMeMaker" ascii
		$fun11 = "StopAndConfigureSqlServices" ascii
		$fun12 = "WipeRecycleBin" ascii
		$fun13 = "TelSender" ascii
		$str01 = "AnyDesk" wide
		$str02 = "firebird" wide
		$str03 = "Acronis" wide
		$str04 = "config \"" wide
		$str05 = " start= demand" wide
		$str06 = "' stopped and configured to start automatically." wide
		$str07 = "Error processing service '" wide
		$str08 = "$RECYCLE.BIN" wide
		$str09 = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run" wide
		$str10 = "UniqueID:" wide
		$str11 = "PersonalID:" wide
		$ran01 = "C:\\Readme.txt" wide
		$ran02 = "C:\\LockBIT\\systemID" wide
		$ran03 = "Your system has been encrypted by our team, and your files have been locked using our proprietary algorithm !" wide
		$ran04 = "* Please read this message carefully and patiently *" wide
		$ran05 = "* If you use any tools, programs, or methods to recover your files and they get damaged, we will not be responsible for any harm to your files !" wide
		$ran06 = "* Note that your files have not been harmed in any way they have only been encrypted by our algorithm." wide
		$ran07 = "Your files and your entire system will return to normal mode through the program we provide to you. No one but us will be able to decrypt your files !" wide
		$ran08 = "* To gain trust in us, you can send us a maximum of 2 non-important files, and we will decrypt them for you free of charge." wide
		$ran09 = "Please put your Unique ID as the title of the email or as the starting title of the conversation." wide
		$ran10 = "* For faster decryption, first message us on Telegram. If there is no response within 24 hours, please email us *" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 5 of ( $fun* ) and 5 of ( $str* ) and 2 of ( $ran* ) ) or 12 of ( $fun* ) or 10 of ( $ran* ) or 8 of ( $ran* ) )
}
rule SEKOIA_Tool_Ehole : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "7d30ffd0-fada-4ef4-98c3-5572a4e1e140"
		date = "2023-06-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_ehole.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "df937417b2f8e12f80fbe2edaa0863de6ed7862c117dff2a21255cb7d1d9ad3d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "main.http400"
		$s2 = "main.fofa_c"
		$s3 = "main.Jsjump"
		$s4 = "main.StandBase64"
		$s5 = "main.fofa_http"
		$s6 = "main.fofa_seach"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 11MB and all of them
}
rule SEKOIA_Tool_Sy_Runas : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "cb1f3707-6716-49b5-9fe0-45c5baf2e491"
		date = "2023-08-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_sy_runas.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b606f921b0ff6adf0e6979d43be0ddf77e2967e703562f1dea4406d1f5b3f5fd"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "Sy_Runas.exe" ascii wide
		$s2 = "password *.exe" ascii wide
		$s3 = "This tools just work on webshell" ascii wide
		$s4 = "Code By slls124@gmail.com" ascii wide

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 4MB and all of them
}
rule SEKOIA_Apt_Lazarus_Dangerouspassword_Lnk : FILE
{
	meta:
		description = "Detects Lazarus DangerousPassword LNKs"
		author = "Sekoia.io"
		id = "32533880-7f75-4682-a7ae-9868d0b5174b"
		date = "2022-07-26"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_lazarus_dangerouspassword_lnk.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "79731450c4623f614c55d8c08d879579e21fd38c85d2a288724b6e9470de6e29"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = {6D 00 73 00 68 00 2A}
		$s2 = {25 00 70 00 75 00 62 00 6C 00 69 00 63 00 25}
		$s3 = {44 00 4F 00 20 00 73 00 74 00 61 00 72 00 74}
		$b1 = {2F 00 63 00 20 00 73 00 74 00 61 00 72 00 74 00 20 00 2F 00 62 00 20 00 6D 00 73 00 68 00 74 00 61}
		$c1 = {68 00 74 00 74 00 70 00 73 00 3A 00 2F 00 2F 00 62 00 69 00 74 00 2E 00 6C 00 79 00 2F}

	condition:
		uint32be( 0 ) == 0x4C000000 and filesize > 1KB and filesize < 40MB and ( all of ( $s* ) or $b1 or ( $s1 and $c1 ) )
}
rule SEKOIA_Tool_Scanline_Strings : FILE
{
	meta:
		description = "Detects scanline (non-packed)"
		author = "Sekoia.io"
		id = "65677b81-d077-4d01-8398-cbb06ce49edf"
		date = "2024-09-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_scanline_strings.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e02ae30451aa5eaffb588e92ecc221bf6ed07097bc493c6a55cf688da8b76151"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Resolve IP addresses to hostnames"
		$ = "Randomize IP and port scan order"
		$ = "?bhijnprsT"
		$ = "sl -bht"

	condition:
		uint16be( 0 ) == 0x4d5a and 3 of them
}
rule SEKOIA_Loader_Win_Squirrelwaffle : FILE
{
	meta:
		description = "Detect the Squirrelwaffle DLL"
		author = "Sekoia.io"
		id = "bea3125e-6e84-435f-855b-fd3239a0deac"
		date = "2021-09-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_squirrelwaffle.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ab1a95f09564d0417d5c06c578d4dc8d790ec09bc67716d8c9e5207262a0594d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "AEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE" ascii
		$s2 = "c:\\equal\\True\\bird_Select\\780\\true.pdb" ascii

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule SEKOIA_Apt_Boldmove_Strings : FILE
{
	meta:
		description = "Detects BOLDMOVE via strings"
		author = "Sekoia.io"
		id = "0458e282-f92f-4600-964a-de6b66b4a82d"
		date = "2023-01-16"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_boldmove_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "71649451b88629da1779c0856b2f1f60f87501962c69556f7943b049688a2d96"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "cwd=%s" ascii wide
		$s2 = "executable=%s" ascii wide
		$s3 = "curl/6.12.34" ascii wide
		$s4 = "www.example.com" ascii wide
		$s5 = "GET /ws HTTP/1.1" ascii wide

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 4MB and 4 of them
}
rule SEKOIA_Tool_Advancedrun_Strings : FILE
{
	meta:
		description = "Detects AdvancedRun strings"
		author = "Sekoia.io"
		id = "842a996e-0cf2-485f-9d3c-ccbd40c9ab6c"
		date = "2024-09-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_advancedrun_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "a1d50ebe6124584f32de0625475cdb74"
		logic_hash = "58e5e0c903057ff382a78a37ba289cbaa5949d99a4b5ff77a223e86aab591f5d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "nirsoft.net" wide
		$ = "Another logged-in user" wide
		$ = "Choose config file to save" wide
		$ = "AdvancedRun" ascii wide

	condition:
		uint16be( 0 ) == 0x4d5a and all of them and filesize < 1MB
}
rule SEKOIA_Rat_Win_Remcos : FILE
{
	meta:
		description = "DEPRECATED : Find Remcos RAT samples based on specific strings"
		author = "Sekoia.io"
		id = "011132f5-c5d9-4e97-bfed-0b94c9a30481"
		date = "2023-01-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_remcos.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "259f31d745449dc81cde698bb0ae4a20b4bbf050a1c818fbb5a891f26ca2e856"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		modification_date = "2024-01-08"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "/k %windir%\\System32\\reg.exe ADD HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v EnableLUA /t REG_DWORD /d 0 /f" ascii
		$str02 = "Disconnection occurred, retrying to connect..." ascii
		$str03 = "[Following text has been pasted from clipboard:]" ascii
		$str04 = "[Following text has been copied to clipboard:]" ascii
		$str05 = "[Chrome StoredLogins found, cleared!]" ascii
		$str06 = "PING 127.0.0.1 -n 2" ascii
		$str07 = "Remcos_Mutex_Inj" ascii
		$str08 = " * REMCOS v" ascii
		$str09 = "Connected to C&C!" ascii
		$str10 = "[Cleared all cookies & stored logins!]" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 3 of them
}
rule SEKOIA_Apt_Sugardump_Credentials_Stealer_Smtp : FILE
{
	meta:
		description = "Detects SUGARDUMP SMTP version"
		author = "Sekoia.io"
		id = "bf028ebc-bfaa-45b3-9a3f-8949a5efbb73"
		date = "2022-08-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_sugardump_credentials_stealer_smtp.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "1f423f38ff323e67667e35af5603e608cba6eaf8d98633467b0292c5f81c8d1c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "<<<<<<<< ------ Passwords Total: {0} --------- >>>>>>>>" wide
		$ = "Url = {0} , Count = {1}" wide
		$ = "smtp." wide
		$ = "encrypted_key\":\"(.*?)\"" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and all of them
}
rule SEKOIA_Tool_Sharpefspotato_Strings : FILE
{
	meta:
		description = "Detects SharpEfsPotato based on strings"
		author = "Sekoia.io"
		id = "4286c72b-c0b9-4d2c-9847-68fc39ed4894"
		date = "2023-06-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_sharpefspotato_strings.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "4987b0d728472186a255adc1fba2d72288dd1f2b368212afd08ea8d7ff18e992"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Program to launch (default cmd.exe)" wide
		$ = "[!] Cannot perform interception, necessary privileges missing." wide
		$ = "[!] Failed to created impersonated process with token:" wide
		$ = "No authenticated interception took place, exploit failed"

	condition:
		uint16be( 0 ) == 0x4d5a and 3 of them
}
rule SEKOIA_Bot_Win_Yamabot : FILE
{
	meta:
		description = "Detect the Yamabot implant used by Lazarus"
		author = "Sekoia.io"
		id = "9f5b85c4-59e3-448f-b054-5b4932ee89bb"
		date = "2023-08-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/bot_win_yamabot.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "1e4de822695570421eb2f12fdfe1d32ab8639655e12180a7ab3cf429e7811b8f"
		hash = "66415464a0795d0569efa5cb5664785f74ed0b92a593280d689f3a2ac68dca66"
		hash = "74529dd15d1953a47f0d7ecc2916b2b92865274a106e453a24943ca9ee434643"
		hash = "def2f01fbd4be85f48101e5ab7ddd82efb720e67daa6838f30fd8dcda1977563"
		logic_hash = "cb183cbf9703d96b5f463d635885eab66e0d36c4763752a5cb934538ada60ec3"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "_/D_/Bot/YamaBot/"
		$s2 = "Go build ID: \"ujRRNborth3MgXzS7HTu/aYhLszO8_95srnr8Fk1n/Xr8P792kGZ_VUqOQVc97/kgx_H7YuMZBl2Ajyac2M\""

	condition:
		uint16be( 0 ) == 0x4d5a and 1 of them and filesize > 3MB
}
rule SEKOIA_Apt_Evasive_Panda_Rphost_Dll : FILE
{
	meta:
		description = "Detects DLL used by Evasive Panda"
		author = "Sekoia.io"
		id = "8d70639d-b736-4823-86ad-37f0e383b5f7"
		date = "2024-03-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_evasive_panda_rphost_dll.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "fa44028115912c95b5efb43218f3c7237d5c349f"
		logic_hash = "2132f1c69db8fd5793c858ada2443fdfa1f941e68d24cc337766df99f8b3a895"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "htks.ini" ascii fullword
		$s2 = "MyDemo" wide fullword

	condition:
		uint16be( 0 ) == 0x4d5a and all of them and filesize < 1MB
}
rule SEKOIA_Dropper_Win_Konni_Cab : FILE
{
	meta:
		description = "Detect the CAB files used to drop the KONNI malware"
		author = "Sekoia.io"
		id = "87a209d5-667a-4a81-837a-660ab98c33c8"
		date = "2023-09-26"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/dropper_win_konni_cab.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b49bb875d5ddd4b815da5bd184ec7f1d23cfb7ad316760c9a9876607245d0a95"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$magic = "MSCF"
		$file2 = "check.bat"
		$file3 = "wpnprv64.dll"
		$file4 = "wpnprv32.dll"

	condition:
		$magic at 0 and all of ( $file* )
}
rule SEKOIA_Tool_Webshell_B374K_Strings : FILE
{
	meta:
		description = "Detects b374k webshell"
		author = "Sekoia.io"
		id = "f53fc668-e1fc-4b85-b850-59aceefb6418"
		date = "2024-09-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_webshell_b374k_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "1d27b23fceecbb9e854c41f6a8fb878e"
		hash = "71fd853a3f3efc3dc2846e866187ee59"
		hash = "187e001c32487d0d68197ddb7e7796c3"
		hash = "6eac497dfc1020a8475e95542fad197e"
		hash = "61c6a0bc15efa442853f04bb276ac96e"
		logic_hash = "b085a50d50fc1fd06d6f75397cf1fa6fa1bc4a0d18b56ed3458990f4abde0632"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "$func('$x','ev'.'al'.'("
		$ = "(ba'.'se'.'64'.'_de'.'co'.'de($x)))"

	condition:
		2 of them and filesize < 1MB
}

rule SEKOIA_Apt_Lazarus_Gopuram_Backdoor : FILE
{
	meta:
		description = "Detects Gopuram Backdoor"
		author = "Sekoia.io"
		id = "947d4ee3-79fa-450b-8482-beafe607baae"
		date = "2023-04-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_lazarus_gopuram_backdoor.yar#L3-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "97b95b4a5461f950e712b82783930cb2a152ec0288c00a977983ca7788342df7"
		hash = "beb775af5196f30e0ee021790a4978ca7a7ac2a7cf970a5a620ffeb89cc60b2c"
		logic_hash = "c019b65d28a7b0edf408a1a159a7535e7e14593bbd42c8df3201108ed02f96c0"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$x1 = "%s\\config\\TxR\\%s.TxR.0.regtrans-ms"
		$xop = {D1 E8 33 C3 D1 EB A8 01 74 ?? 81 F3 25 A3 87 DE D1 E8 33 C3 D1 EB A8 01 74 ?? 81 F3 25 A3 87 DE D1 E8 33 C3 D1 EB A8 01 74 ?? 81 F3 25 A3 87 DE D1 E8 33 C3 D1 EB A8 01 74 ?? 81 F3 25 A3 87 DE}
		$opa1 = {48 89 44 24 ?? 45 33 C9 45 33 C0 33 D2 89 5C 24 ?? 48 89 74 24 ?? 48 89 5C 24 ?? 89 7C 24 ?? FF 15 ?? ?? ?? ?? 85 C0 74 ?? 48 8B 4C 24 ?? 4C 8D 4C 24 ?? 44 8D 43 ??}
		$opa2 = {48 89 B4 24 ?? ?? ?? ?? 44 8D 43 ?? 33 D2 48 89 BC 24 ?? ?? ?? ?? 4C 89 B4 24 ?? ?? ?? ?? E8 ?? ?? ?? ?? 48 8B 4C 24 ?? E8 ?? ?? ?? ?? 48 8B 4C 24 ?? 45 33 C0 33 D2 8B F8 E8 ?? ?? ?? ?? 8D 4F ?? E8 ?? ?? ?? ?? 4C 8B 4C 24 ?? 44 8D 43 ?? 48 8B C8 8B D7 48 8B F0 44 8B F7 E8 ?? ?? ?? ?? 48 8B 4C 24 ?? E8 ?? ?? ??}

	condition:
		( uint16( 0 ) == 0x4d5a and filesize < 2MB and pe.characteristics & pe.DLL and 1 of ( $x* ) ) or all of ( $opa* )
}
rule SEKOIA_Spyware_And_Strongpity_Mobile_Backdoor : FILE
{
	meta:
		description = "Detect the mobile backdoor using the name used in the certificate"
		author = "Sekoia.io"
		id = "58ceb85b-d94f-47b2-86e4-59bd41f4fea8"
		date = "2023-01-16"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/spyware_and_strongpity_mobile_backdoor.yar#L1-L15"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "9005fe938433223f32642f6bbf7c4c58f0b927a006e283c8b12f79103ec02cfc"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "Elizabeth Mckinsen0"

	condition:
		all of them and filesize > 2MB
}
rule SEKOIA_Apt_Andariel_Siennablue : FILE
{
	meta:
		description = "Detects SiennaBlue based routine names"
		author = "Sekoia.io"
		id = "ab3f8b49-0851-47a8-ac77-98d4e26f448e"
		date = "2023-11-16"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_andariel_siennablue.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0876deb2e76098ac8d304737243d3a76e9741b2ca1570034bec51fea5a40818d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "main_cryptAVPass"
		$ = "main_DecryptString"
		$ = "main_DisableNetworkDevice"
		$ = "main_DeleteSchTask"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize > 4MB and filesize < 15MB and all of them
}
rule SEKOIA_Apt_Cloudmensis_Spyagent_Strings : FILE
{
	meta:
		description = "Detects CloudMensis SpyAgent"
		author = "Sekoia.io"
		id = "c2df8373-6698-4b23-9d77-8e7968bd69f0"
		date = "2022-07-26"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_cloudmensis_spyagent_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ad858b1b78fb4ac6efee093b11fde14956d63bc6b300ef37bf1f2a3356cf4402"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[control_thread loop_DirStructure:]"
		$ = "[screen_keylog getScreenShotData]"
		$ = "[screen_keylog loop_usb]"
		$ = "[Management UploadFilebyPath:destination:]"
		$ = "[control_thread loop_pwd:]"

	condition:
		uint32be( 0 ) == 0xcafebabe and filesize < 2MB and all of them
}
rule SEKOIA_Apt_Qnapworm_Loader_May2022 : FILE
{
	meta:
		description = "Detects the QNAPWorm loader"
		author = "Sekoia.io"
		id = "c6e87a55-73ea-4df4-ab61-b5d34968d741"
		date = "2022-05-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_qnapworm_loader_may2022.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "d31fdaaacd417a4191e79e3a287e84c55109158eaacc789b2129e2ba94e443f6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = {
        66 C1 C0 05
        0F B7 D8
        81 C3 85 D0 FF FF
        66 C1 C3 02
        0F B7 C3
        0F B6 9A ?? ?? ?? ??
        33 D8
        88 1C 11
        42
        0F B6 D2
        81 FA ?? 00 00 00
        }

	condition:
		uint16be( 0 ) == 0x4d5a and all of ( $s* )
}
rule SEKOIA_Implant_Any_Sliver : FILE
{
	meta:
		description = "Rule which detects any Sliver implant PE/Dlls/ELFs/MAC-O."
		author = "Sekoia.io"
		id = "4b16f28a-2048-4044-8620-8e7a1651f2b1"
		date = "2021-11-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_any_sliver.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c7a2790fd13de0476cfe16ef26b2d4c8775f4f453d076c78975e2c372f03322c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.1"
		classification = "TLP:CLEAR"

	strings:
		$s1 = ").GetActiveC2" ascii
		$s2 = ").GetVersion" ascii
		$s3 = ").GetReconnectInterval" ascii
		$s4 = ").GetProxyURL" ascii
		$s5 = ").GetPollInterval" ascii

	condition:
		( uint16be( 0 ) == 0x4d5a or uint32be( 0 ) == 0x7f454c46 or uint32be( 0 ) == 0xcffaedfe ) and ( true and filesize < 11MB and filesize > 7MB ) and ( all of ( $s* ) )
}
rule SEKOIA_Apt_Apt35_Iisraid_Strings : FILE
{
	meta:
		description = "Detects APT35s ISSRaid implant"
		author = "Sekoia.io"
		id = "ee42f406-0c7e-4385-9098-409611dbe0a5"
		date = "2023-05-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt35_iisraid_strings.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "de2ebef5ab46136aa54b146dbd4198f69801f3414d1d239fc7983c5b3c0115c4"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "CHttpModule::"
		$ = "X-Forward-Verify"
		$ = "X-Beserver-Verify"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 500KB and all of them
}
rule SEKOIA_Apt_Kimsuky_Vbs_Powershell_Downloader : FILE
{
	meta:
		description = "Detects VBS/Powershell Downloader used by Kimsuky"
		author = "Sekoia.io"
		id = "4c9af11f-802b-4ffe-9783-90fc2ee53809"
		date = "2022-08-30"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_kimsuky_vbs_powershell_downloader.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "dc24ca206a3122b34be978287f907b12c809f76058fe9355bbd00b3159b0a4d4"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "& WScript.ScriptFullName &" ascii fullword
		$ = "/c schtasks /create /sc minute /mo 5 /tn"
		$ = "pOwErsHeLl -ep bypass -encodedCommand"

	condition:
		filesize < 200KB and 2 of them
}
rule SEKOIA_Apt_Gamaredon_Htmlsmuggling_Attachment : FILE
{
	meta:
		description = "Detects Gamaredon HTMLSmuggling attachment"
		author = "Sekoia.io"
		id = "a39b6e67-9327-4c5b-902a-b9853cfefc8e"
		date = "2023-01-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gamaredon_htmlsmuggling_attachment.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e13da493404b27ef0c026ca32accbb30792981e810c099d633f5de225e241b4d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "['at'+'ob'](" ascii
		$ = "['ev'+'al'](" ascii
		$ = "document.querySelectorAll('[" ascii
		$ = "[0].innerHTML.split(' ').join('')))" ascii

	condition:
		filesize < 1MB and 2 of them
}
rule SEKOIA_Apt_Gamaredon_Lnks_Farl139_Hostname : FILE
{
	meta:
		description = "Detects some hostname used in Gamaredon LNKs"
		author = "Sekoia.io"
		id = "f8bb2e6b-e544-46b0-b61b-048fe84e1100"
		date = "2023-01-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gamaredon_lnks_farl139_hostname.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8be31a4fed363f0e2791efb96a229f6cdec5bfaeaf3e9cd880f8d25c9ae0435e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "desktop-farl139"

	condition:
		uint32be( 0 ) == 0x4c000000 and all of them and filesize < 10KB
}
rule SEKOIA_Apt_Apt28_Htmlsmuggling_Disclosing_Ip : FILE
{
	meta:
		description = "Detects some kind of HTMLSmuggling used by APT28"
		author = "Sekoia.io"
		id = "57adc227-2b72-457e-a786-97ca1a7300d8"
		date = "2023-09-11"
		modified = "2024-12-19"
		reference = "https://www.zscaler.com/blogs/security-research/steal-it-campaign"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt28_htmlsmuggling_disclosing_ip.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "047d2d5f8d04576b6d57bc599f82406804845a3acb7628e7ad9b56e71e4dfe92"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "ipapi.co/json"
		$s2 = "a.download("
		$s3 = "a.click("

	condition:
		$s1 and $s2 and $s3 and filesize < 5000
}
rule SEKOIA_Infostealer_Win_Blackcap : FILE
{
	meta:
		description = "Finds BlackCap Grabber samples (Python code obfuscated using Py-Fuscate)"
		author = "Sekoia.io"
		id = "1aa1fadb-3413-46e2-b733-1ad2134f7be2"
		date = "2023-03-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_blackcap.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b826c88d557ea0a516534946ad9531eda1a875cb9c4ddf92d9b98f8c7b86623e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$imp01 = "import asyncio, json, ntpath, random, re, shutil, sqlite3, subprocess, threading, winreg, zipfile, httpx, psutil, win32gui, win32con, pyperclip, base64, requests, ctypes, time" ascii
		$imp02 = "from ctypes import windll, wintypes, byref, cdll, Structure, POINTER, c_char, c_buffer;from Crypto.Cipher import AES;from PIL import ImageGrab;from win32crypt import CryptUnprotectData" ascii
		$pyf01 = "import marshal,lzma,gzip,bz2,binascii,zlib;exec(marshal.loads(binascii.a2b_base64(b'YwAAAAAA" ascii

	condition:
		($imp01 in ( 0 .. 500 ) and $pyf01 in ( @imp01 + 200 .. @imp01 + 1000 ) or $imp02 in ( 0 .. 1000 ) and $pyf01 in ( @imp02 + 100 .. @imp02 + 500 ) ) and filesize > 100KB and filesize < 500KB
}
rule SEKOIA_Apt_Ta410_Driver_Keylogger : FILE
{
	meta:
		description = "Keylogger TA410"
		author = "Sekoia.io"
		id = "0cba1b3b-b93e-41e3-a7df-afd306e6b519"
		date = "2022-10-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_ta410_driver_keylogger.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5ed152cc068f194cb7bf8c34744f0f1ebd4f621e6ae47f14bab64b18d94af4c5"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "namedpipe_keymousespy" ascii wide
		$ = "[`LCTRL]" ascii wide
		$ = "[`RCTRL]" ascii wide
		$ = "[`BREAK]" ascii wide
		$ = "[`NUMLOCK]" ascii wide
		$ = "[`L]" ascii wide
		$ = "[`R]" ascii wide
		$ = "[`M]" ascii wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and 3 of them
}
rule SEKOIA_Malicious_Lnk_Exploiting_Webdav_Share_Generic : FILE
{
	meta:
		description = "Detects some malicious LNK"
		author = "Sekoia.io"
		id = "b228643c-ab23-46e1-b170-3da6bcb2dd23"
		date = "2024-11-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/malicious_lnk_exploiting_webdav_share_generic.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "cffb40e13e3aa6761330090b42314c36"
		logic_hash = "8179ef8ac43cb67a1b70baf7824452834f498d988df84e138c857ac0ef164b4b"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "powershell.exe" wide
		$ = "-Name explorer; \\\\" wide
		$ = "@80\\"
		$ = "desktop-tcrdu4c"

	condition:
		uint32be( 0 ) == 0x4c000000 and 2 of them
}

rule SEKOIA_Implant_Win_Apt29_2022_10
{
	meta:
		description = "APT29 implants from October 2022"
		author = "Sekoia.io"
		id = "0f270e75-f687-4fdc-a980-fde81107a4d6"
		date = "2023-02-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_win_apt29_2022_10.yar#L4-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "1cffaf3be725d1514c87c328ca578d5df1a86ea3b488e9586f9db89d992da5c4"
		hash = "381a3c6c7e119f58dfde6f03a9890353a20badfa1bfa7c38ede62c6b0692103c"
		logic_hash = "b9300c2f06b54b16e1cab579d686d986caacf3b6eccec3a4e62d58e94b50bfb4"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		pe.imphash( ) == "39b818e7bac0a276f509f8c47e467666" or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "6621113d9f212c71b8dd3ce85c62b251" )
}
rule SEKOIA_Apt_Gamaredon_Flash_Infostealer : FILE
{
	meta:
		description = "Detects the Gamaredon's Flash InfoStealer"
		author = "Sekoia.io"
		id = "f060fe4b-74fd-4ef3-ac86-916e2113ff24"
		date = "2023-01-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gamaredon_flash_infostealer.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5a3ee8c2c3c377bea7de1993e5ef744796130643575bcce1b6181d68190aafb7"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$a1 = "Content-Type: multipart/form-data; boundary=----%s" ascii
		$a2 = "Content-Disposition: form-data; name=\"p\"" ascii
		$a3 = "Content-Type: application/octet-stream"
		$w1 = "%s||%s||%s||%s" wide
		$w2 = "Pragma: no-cache" wide
		$w3 = { 64 00 6F 00 63 00 00 00 00 00 2E 00 64 00 6F 00 63 00 78 00 }

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 500KB and 2 of ( $a* ) and 2 of ( $w* )
}
rule SEKOIA_Apt_Aptk47_Asyncshell : FILE
{
	meta:
		description = "Detects APT-K-47's Asyncshell"
		author = "Sekoia.io"
		id = "2d009cf4-e30e-406d-8860-03b37a396ffa"
		date = "2024-11-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_aptk47_asyncshell.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "ce6a589d5e3604112e5595a1f8d53e1e"
		hash = "751f427da8e11d8ab394574260735220"
		logic_hash = "ac202f7dc317d17118badf71c32776c5666eea4a47e1b439a287b6b8766e9da6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Error executing command:" wide
		$ = "Error occurred:" wide
		$ = "Attempting to reconnect in {0} seconds..." wide
		$ = "Exiting the application." wide
		$ = "Server disconnected." wide
		$ = "_CorExeMain"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and 4 of them
}
rule SEKOIA_Generic_Sharpshooter_Payload_7 : FILE
{
	meta:
		description = "Detects payload created by SharpShooter"
		author = "Sekoia.io"
		id = "de8069bb-59d7-4753-974a-f77c4b9e9bae"
		date = "2023-02-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/generic_sharpshooter_payload_7.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "27b5f3d24f7269e80b628be044d828d365fdba25891a5a1ecc973c419cf1dc6c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "ms.Write(ba, 0, (length / 4) * 3)"
		$ = "var serialized_obj = "
		$ = "var n = fmt.SurrogateSelector;"
		$ = "var o = d.DynamicInvoke(al.ToArray())"

	condition:
		all of them and filesize < 2MB
}
rule SEKOIA_Loader_Fakebat_Initial_Powershell_May24 : FILE
{
	meta:
		description = "Finds FakeBat initial PowerShell script downloading and executing the next-stage payload."
		author = "Sekoia.io"
		id = "adf0e4fc-fa98-470b-9535-bd30d0bdb3aa"
		date = "2024-05-28"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_fakebat_initial_powershell_may24.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6a699df361b0cb2baf1d0b128f795aa9918ebe11daaeb1fa49aebf9320add762"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		modification_date = "2024-06-21"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "='http" wide
		$str02 = "=(iwr -Uri $" wide
		$str03 = " -UserAgent $" wide
		$str04 = " -UseBasicParsing).Content; iex $" wide

	condition:
		3 of ( $str* ) and filesize < 1KB and true
}
rule SEKOIA_Rat_Win_Arrow_Str : FILE
{
	meta:
		description = "Finds Arrow RAT samples based on the specific malware strings"
		author = "Sekoia.io"
		id = "69f6572c-91ed-4fb6-b886-5ad2dabef3d3"
		date = "2022-08-19"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_arrow_str.yar#L1-L27"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "faf66a14e563066bb86ceadc787c092a5a13a43f936f0d9d19fbe7d4352ea5d8"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$hvnc01 = "DESKTOP_JOURNALRECORD" ascii
		$hvnc02 = "DESKTOP_ENUMERATE" ascii
		$hvnc03 = "DESKTOP_SWITCHDESKTOP" ascii
		$hvnc04 = "DESKTOP_CREATEWINDOW" ascii
		$hvnc05 = "StartHVNC" ascii
		$str01 = "U29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3MgTlRcQ3VycmVudFZlcnNpb25cV2lubG9nb25c" wide
		$str02 = "powershell.exe -ExecutionPolicy Bypass -WindowStyle Hidden -NoProfile -Command Add-MpPreference -ExclusionPath" wide
		$str03 = "cvtres.exe" wide
		$str04 = "qbkTHriRRbQjaArtJfF" wide
		$str05 = "29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3MgTlRcQ3VycmVudFZlcnNpb25cV2lubG9nb24=" wide
		$str06 = "Stub.exe" ascii wide
		$str07 = "DePikoloData" ascii

	condition:
		uint16be( 0 ) == 0x4d5a and 4 of ( $hvnc* ) and 5 of ( $str* )
}
rule SEKOIA_Apt_Scanbox_Obfuscated_Versions : FILE
{
	meta:
		description = "Detects obfuscated versions of the scanbox framework"
		author = "Sekoia.io"
		id = "2866cead-7f16-4895-80ef-aad6fb66e864"
		date = "2022-09-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_scanbox_obfuscated_versions.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0395d1ac9a593aa8249f6d16c485e431349cecf2f379d2b5bac466541f71968c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "$_$_$_$__$_____$__$_$_$_$__$"
		$ = "NztCm_NcDkh"
		$ = "____$_$__$__$_______w____$_$__$__$_____i____$_$__$__$_____"
		$ = "391,379,398,381,386"
		$ = "plguinurl"
		$ = "plugin_timeout*1000"

	condition:
		2 of them and filesize < 500KB
}
rule SEKOIA_Infostealer_Win_Acridrain_Mar23 : FILE
{
	meta:
		description = "Finds AcridRain samples"
		author = "Sekoia.io"
		id = "049b502a-0fb6-4fa9-a1ce-f01a40269bdb"
		date = "2023-03-21"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_acridrain_mar23.yar#L1-L40"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "7fa1822acc6264a3a58fffef3fc572f8818d99037b20d5abb8bfb41f025949d4"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "\",\"r\":" ascii
		$str02 = "\",\"s\":\"" ascii
		$str03 = "\",\"p\":\"" ascii
		$str04 = "\",\"a\":\"" ascii
		$str05 = ",\"c\":" ascii
		$str06 = ",\"g\" :" ascii
		$str07 = "v7166637466625297979 t2537736810932639330 ath5ee645e0 altpriv cvcv=2 cexpw=1 smf=0" ascii
		$str08 = "Content-Type: multipart/form-data; boundary=----974767299852498929531610575" ascii
		$str09 = "\\Roaming\\Bitwarden\\data\\bitwarden.sqlite3" ascii
		$ste01 = "\\Roaming\\Exodus\\exodus.wallet" ascii
		$ste02 = "\\Roaming\\Electron Cash\\wallets" ascii
		$ste03 = "\\Roaming\\com.liberty.jaxx\\IndexedDB\\file__0.indexeddb.leveldb" ascii
		$ste04 = "\\Local Extension Settings\\" ascii
		$ste05 = "cnmamaachppnkjgnildpdmkaakejnhae" ascii
		$ste06 = "ffnbelfdoeiohenkjibnmadjiehjhajb" ascii
		$ste07 = "\\formhistory.sqlite" ascii
		$ste08 = "\\logins.json" ascii
		$ste09 = "encrypted_key" ascii
		$ste10 = "\\Login Data" ascii
		$enc01 = "bX5cVw8FKyAKZVxXXUAdSTUXCXdCV0FoOxoSF0ZEUEZS" ascii
		$enc02 = "bX5cVw8FKywUaVVbRlkyPAQAFCB1U0dV" ascii
		$enc03 = "bX5cVw8FKzQvUBFhRkYINSIWA3IRdlJADw==" ascii
		$enc04 = "bX5cVw8FKzYWdUVcWl8iCBU5NXBERl1dBTUiFgNyEXZSQA8=" ascii
		$enc05 = "bWBcVQMAGQI6UEJbGGgeGxgDD2xUQW9QCw8WEAp0" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 5 of ( $str* ) and 7 of ( $ste* ) and 1 of ( $enc* )
}
rule SEKOIA_Apt_Micdown_Encrypted_Configuration : FILE
{
	meta:
		description = "Encrypted C2 configuration of micDown"
		author = "Sekoia.io"
		id = "9567d68b-05d1-4d41-b87f-c8691ee689cd"
		date = "2023-08-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_micdown_encrypted_configuration.yar#L1-L15"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "9b80bd284f9aa9e4073bdead7bb0c5412ec1809c36a85dfd35d9ea7ac62da8a3"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = {?? [20] 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 37 84 36}

	condition:
		filesize == 66 and all of them
}
rule SEKOIA_Tool_Yasso_Strings : FILE
{
	meta:
		description = "Detects Yasso based on strings"
		author = "Sekoia.io"
		id = "31ec7510-6770-4fde-b835-e8b12f8f2b30"
		date = "2023-06-21"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_yasso_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "1d715b0962ba9ecbe11649ea85870a8f884f6dd7eda27b1f8eff0d7f5de8c765"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Yasso/cmd.setting"
		$ = "Yasso/cmd.Client"
		$ = "Yasso/cmd.IdentifyResult"
		$ = "Yasso/cmd.RespLab"
		$ = "Go build ID"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize > 15MB and filesize < 20MB and all of them
}
rule SEKOIA_Infostealer_Win_Mars_Stealer_Variant_Llcppc1 : FILE
{
	meta:
		description = "Detect Mars Stealer variand llcppc1"
		author = "Sekoia.io"
		id = "3e2c7440b2fc9e4b039e6fa8152ac8fe"
		date = "2022-03-10"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_mars_stealer_variant_llcppc1.yar#L1-L15"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f9d92338fa31c38648b72d7f9a953201c7e498237bc9d02d6247d1882d1e3432"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$a = {ff 15 ?? ?? ?? ?? 89 45 ?? 6a 14 68 ?? ?? ?? ?? ff 75 ?? e8 23 00 00 00 ff 75 ?? ff 75 ?? ff 75 ?? e8 5c 00 00 00}

	condition:
		uint16( 0 ) == 0x5A4D and $a
}
rule SEKOIA_Apt_Sidecopy_Reverserat_Strings : FILE
{
	meta:
		description = "Detects SideCopy's ReverseRAT"
		author = "Sekoia.io"
		id = "383397c9-fd4a-4255-a8f2-27683bdbb7f7"
		date = "2023-05-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_sidecopy_reverserat_strings.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "be657405b5703dc402b53350aa7ef18529bda3dc44c759585c4cfa1bc1eb76ff"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "downloadexe" wide
		$ = "creatdir" wide
		$ = "regnewkey" wide
		$ = "reglist" wide
		$ = "regdelkey" wide
		$ = "clipboardset" wide
		$ = "shellexec" wide
		$ = "SELECT maxclockspeed,  datawidth, name, manufacturer FROM Win32_Processor" wide

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Rat_Win_Konni_Rat : FILE
{
	meta:
		description = "Detect the KONNI RAT DLL files (x32 and x64)"
		author = "Sekoia.io"
		id = "032f1c79-6f03-4588-a4af-38b1f3ca1cb8"
		date = "2023-09-26"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_konni_rat.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "764e75d3e433a8784e826f436896c50c9622129412ff277b55ec9aaf1402ff5e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = ".cab" wide
		$ = ".zip" wide
		$ = ".rar" wide
		$ = ".ini" wide
		$ = ".dat" wide
		$ = "%s(%d)" wide
		$ = "%s %s \"%s\"" wide
		$ = "\\Temp\\" wide

	condition:
		uint16( 0 ) == 0x5A4D and all of them and filesize > 60KB and filesize < 120KB
}
rule SEKOIA_Infostealer_Win_Meduzastealer : FILE
{
	meta:
		description = "Finds MeduzaStealer samples based on specific strings"
		author = "Sekoia.io"
		id = "1276f485-aa5d-491b-89d8-77f98dc496e1"
		date = "2023-06-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_meduzastealer.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e81a5a9611662422eb7a87c0c1a370cee6f138fd6169225d969b669337d91a06"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "emoji" ascii
		$str02 = "%d-%m-%Y, %H:%M:%S" ascii
		$str03 = "[UTC" ascii
		$str04 = "user_name" ascii
		$str05 = "computer_name" ascii
		$str06 = "timezone" ascii
		$str07 = "current_path()" ascii
		$str08 = "[json.exception." ascii
		$str09 = "GDI32.dll" ascii
		$str10 = "GdipGetImageEncoders" ascii
		$str11 = "GetGeoInfoA" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 8 of them and filesize > 500KB
}
rule SEKOIA_Backdoor_Lin_Bifrost : FILE
{
	meta:
		description = "Detect the Bifrost backdor based on strings"
		author = "Sekoia.io"
		id = "9726b5f5-8cc3-4fad-950b-f20cac04d496"
		date = "2024-03-05"
		modified = "2024-12-19"
		reference = "https://unit42.paloaltonetworks.com/new-linux-variant-bifrost-malware/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_lin_bifrost.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "8e85cb6f2215999dc6823ea3982ff4376c2cbea53286e95ed00250a4a2fe4729"
		hash = "2aeb70f72e87a1957e3bc478e1982fe608429cad4580737abe58f6d78a626c05"
		hash = "f2bef6bed27f4b527118dd62b4035003c14afaffa72729c8117f213623f644ec"
		logic_hash = "a3fd671c02c29f67cf5b8d2d0e857336da72f989688f2db19cd028398080c5e2"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "%c2%s%c3%u%c4%u-%.2u-%.2u %.2u:%.2u"
		$ = "%c1%s%c3D%c4%u-%.2u-%.2u %.2u:%.2u"

	condition:
		uint32be( 0 ) == 0x7f454c46 and all of them
}
rule SEKOIA_Hacktool_Defendercontrol_Strings : FILE
{
	meta:
		description = "Detects DefenderControl based on strings"
		author = "Sekoia.io"
		id = "c6587a46-5f9b-4bf0-9231-9d2505293557"
		date = "2022-03-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_defendercontrol_strings.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8372ab6f922471c28b528d908527f52d393cf6e6308d6acad882d6d5862df43c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "www.sordum.org All Rights Reserved." wide
		$ = "dControl.exe" wide
		$ = "By BlueLife" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 600KB and all of them
}

rule SEKOIA_Implant_Win_Mysterysnail : FILE
{
	meta:
		description = "Detect the MysterySnail using section hashes"
		author = "Sekoia.io"
		id = "dfd2eba8-eb9c-411a-b5e0-663593453e3d"
		date = "2021-10-13"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_win_mysterysnail.yar#L4-L27"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "37c02a5916ad7ce3190ce926d576365d1e17fee0f10e9b31619ea4b6fee29ae6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		uint16( 0 ) == 0x5A4D and ( pe.imphash ( ) == "de0c9e6aec27d278ccdb6718b3e96e32" or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "a41b6fb1cc34d6393e30c13a58f6ecd4" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "f263a2be76694feab7e2ce79ecf8b724" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "e9056ae96619d7aa18daa973da592afc" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "3e38e89e9e8329f5cff8a7022d88fff7" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "ce78f8599167c63e8f1c8d3e789c4a60" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "456d4f1096bf5c72cd6e1e3eb9980ec6" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "37e2bff637001fc64566fe651757f66e" ) or hash.md5 ( pe.rich_signature.clear_data ) == "e4116fffa240ba6d91b400541ce85182" )
}
rule SEKOIA_Infostealer_Win_Solarmarker_Powershell : FILE
{
	meta:
		description = "Finds SolarMarker PowerShell script based on characteristic strings"
		author = "Sekoia.io"
		id = "a2fe7f09-7134-4054-ba40-5ea66785a26d"
		date = "2022-12-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_solarmarker_powershell.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "32267cf7e03ed65da969aeeff5ef5d7291e47446ea11a4b391f085967e8aa67d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$fun = "function " ascii
		$ps0 = "return -join (0..(10..30|Get-Random)|%{[char]((65..90)+(97..122)|Get-Random)})" ascii
		$ps1 = /new-item -path \$[a-zA-Z0-9_]* -itemtype registrykey -force;/
		$ps2 = /set-item -path \$[a-zA-Z0-9_]* -value \$[a-zA-Z0-9_]*;/
		$str0 = "[IO.File]::WriteAllText($" ascii
		$str1 = "CreateShortcut($env:appdata+" ascii
		$str2 = "Registry::HKEY_CURRENT_USER\\Software\\Classes\\" ascii
		$str3 = "New-Object System.Security.Cryptography.AesCryptoServiceProvider" ascii
		$str4 = "[Convert]::FromBase64String([IO.File]::ReadAllText(" ascii

	condition:
		$fun at 0 and 1 of ( $ps* ) and 2 of ( $str* )
}
rule SEKOIA_Win_Infostealer_Serpent_Strings : FILE
{
	meta:
		description = "Serpent Stealer string"
		author = "Sekoia.io"
		id = "ad9e2366-c95e-4090-a0db-48f3cc325209"
		date = "2023-12-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/win_infostealer_serpent_strings.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5266d1c8228f02e8ac9da5ddd8b968fde0d0e83afa408d405ec4ca50c3453928"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "User Has SSH Dir." wide
		$s2 = "[+] Executing Wallets" wide
		$s3 = "'serpent' folder" wide
		$s4 = "Buddy Kys!!!" wide
		$s5 = "http://checkip.dyndns.org/" wide
		$s6 = "[+] Target has discord installed" wide
		$s7 = "Target has minecraft." wide

	condition:
		( uint16be( 0 ) == 0x4d5a ) and filesize < 100KB and 5 of them
}
rule SEKOIA_Generic_Sharpshooter_Payload_9 : FILE
{
	meta:
		description = "Detects payload created by SharpShooter"
		author = "Sekoia.io"
		id = "e4283d6e-d829-4f21-ba60-9e6232519e54"
		date = "2023-02-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/generic_sharpshooter_payload_9.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "deb0773e6300ed0f4c099359731812216390017eaf8de678b2a5ed237906f03f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "shell.Environment(\"Process\").Item(\"COMPLUS_Version\")"
		$ = "(enc.GetBytes_4(b), 0, length), 0, ((length / 4) * 3)"
		$ = "DebugPrint Err.Description"

	condition:
		all of them and filesize < 2MB
}
rule SEKOIA_Ransomware_Win_Dodo_2023 : FILE
{
	meta:
		description = "Rule to detect Dodo ransomware samples."
		author = "Sekoia.io"
		id = "190977d4-5a7a-4e15-8f90-085f82ec56c8"
		date = "2023-02-13"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_win_dodo_2023.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "aee45cc2540d49a28e765c30f1c4d0b853c1a74ea2260bd7614ece8e54c3bcb3"
		logic_hash = "01924360ef4bbecd220439290eba22838a3977793fdebd0ef0be74c342c0d152"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "DODOCRYPTER" ascii wide
		$s2 = "dodov2" ascii wide
		$s3 = "dodov2SPREAD.exe" ascii wide
		$s4 = "dodov2_readit.txt" ascii wide
		$s5 = "WELCOME, DODO has returned" ascii wide
		$s6 = "Monero Address: 442n8nf9zojie1JdkZqxDQJFDumBEgZmVZozLdYd5jVPSMws2oUPvNLJKca6JKojyA7zDCZCnMyYnKbY1JLNsbzWK6HNNqW" ascii wide
		$s7 = "The price for the software is $15. Payment can be made in Bitcoin or XMR." ascii wide

	condition:
		uint16be( 0 ) == 0x4d5a and 4 of them
}

rule SEKOIA_In2Al5D_P3In4Er_Loader : FILE
{
	meta:
		description = "Invalid printer loader detection based on the XOR key"
		author = "Sekoia.io"
		id = "6dd3046d-55fb-4bcc-8735-dbc0add4d570"
		date = "2023-04-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/in2al5d_p3in4er_loader.yar#L3-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "fb7dadcd1e87c15cacfc046e76648b1fa29f1bce44fa0314b84746ca57eebaed"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$xor_key = "in2al5d p3in4er" ascii fullword

	condition:
		all of them and ( filesize > 4MB and filesize < 7MB ) and pe.is_pe
}
rule SEKOIA_Apt_Implant_Xdealer_Linux_Variant_Strings : FILE
{
	meta:
		description = "Detects XDealer linux variant"
		author = "Sekoia.io"
		id = "42690513-753f-4296-b641-4d3b59a5e5e1"
		date = "2024-03-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_implant_xdealer_linux_variant_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "400beb53d0f7b7727962175c7c4f8dfccdfed56bb3978d3e847147e8ad7644fb"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "ls -l /proc/%s/exe"
		$ = "Linux_%s_%s_%u"
		$ = "chkconfig --add"
		$ = "cmd over return [%s]"
		$ = "touch   -d"
		$ = "%s can't be opened/n"
		$ = "/proc/%s/status"

	condition:
		uint32be( 0 ) == 0x7f454c46 and 3 of them and filesize < 1MB
}

rule SEKOIA_Apt_Darkpink_Loader_Decryptionroutine : FILE
{
	meta:
		description = "Detects decryption routine of dark pink loader"
		author = "Sekoia.io"
		id = "fefc7b2f-eecc-49dc-84bc-24c45e9ea8f0"
		date = "2023-01-17"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_darkpink_loader_decryptionroutine.yar#L4-L49"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "3f38860d0f6f0ff1b65219379f8793383cba85b11de1c853192fb2d2ba99e481"
		hash = "b3f1d6366ebc184f634a240c838b39d729c28b8718b0b9ca6be988a7e446ec42"
		logic_hash = "fe2726b77c293fc2aa19216025cfa2b4cd0c5194730cbc57a1fcceb6f6198977"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$chunk_1 = {
        8A 08
        40
        84 C9
        75 ??
        6A 00
        2B C2
        50
        53
        56
        E8 ?? ?? ?? ??
        8A 88 ?? ?? ?? ??
        30 0C 3E
        83 C6 01
        83 D3 00
        78 ??
        7F ??
        81 FE ?? ?? ?? ??
        72 ??
        55
        }

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 3MB and ( all of them or hash.md5 ( pe.rich_signature.clear_data ) == "950c0710dc4cbf6e2cd6b857d25da523" or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "547e43dd8560fa8b0ca0be9f633bf62d" ) )
}
rule SEKOIA_Tool_Juicypotatong_Strings : FILE
{
	meta:
		description = "Detects JuicyPotatoNG"
		author = "Sekoia.io"
		id = "4634251b-ea41-4f58-aabd-db83ccf4edaa"
		date = "2023-06-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_juicypotatong_strings.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "7014b206b293c8254304d97bec7b367c6039566f60511a51d4a41d3e1ed98612"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[!] CryptStringToBinaryW failed with error code %d" ascii
		$ = "-b : Bruteforce all CLSIDs. !ALERT:" ascii
		$ = "[-] CreateProcessWithTokenW Failed to create proc: %d" ascii

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Downloader_Win_Cobianrat : FILE
{
	meta:
		description = "Detect CobianRAT downloader"
		author = "Sekoia.io"
		id = "7a86c17f-bf4e-4465-9488-244b75fc36f1"
		date = "2024-08-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/downloader_win_cobianrat.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "7a70779d9d7de5e370fac0fa2d4ccd13"
		hash = "2ce40599a4990680db3af5defcd5381a"
		hash = "56515c48f82475e7bb6a26b027a459d7"
		hash = "3450bece12bd8103d5e718a2661d0404"
		hash = "132858739129d2b863dc547facbed7e9"
		hash = "693bd96d162c54d7e9605580eaf54a6e"
		hash = "d03a4988e22e6c7b2a03efa2bdb1502d"
		hash = "ab8c68b907ec2ce316bf18f00938710c"
		logic_hash = "6437a2d0854fb7bd9ddde8434e9a2b95cbb7ccc04381400db211f38a6a575e43"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = {24 00 44 00 6F 00 77 00 6E 00 6C 00 6F 00 61 00 64 00 55 00 72 00 6C 00 20 00 3D 00 20 00 27}

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Apt_Badmagic_Commonmagic_Generic_1 : FILE
{
	meta:
		description = "Detects CommonMagic related implants"
		author = "Sekoia.io"
		id = "0b328771-f674-4606-bb30-d20d07c67832"
		date = "2023-05-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_badmagic_commonmagic_generic_1.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "513226d050945af1a8bbc51f9a48936c815bfc6cd43b0766e34ac000d3c90625"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "\\CommonCommand\\Clean\\"
		$ = "\\CommonCommand\\Overall\\"
		$ = "\\CommonCommand\\Other\\"
		$ = "\\CommonCommand\\Other\\*"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 1MB and all of them
}
rule SEKOIA_Emmenhtal_Strings_Hta_Exe : FILE
{
	meta:
		description = "Emmenhtal Loader string"
		author = "Sekoia.io"
		id = "64e08610-e8a4-4edd-8f6b-d4e8d2b47d87"
		date = "2024-09-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/emmenhtal_strings_hta_exe.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "e86a22f1c73b85678e64341427c7193ba65903f3c0f29af2e65d7c56d833d912"
		logic_hash = "93f85a4ccb58c6aeb664c4c843ff80a4ab7b4308a944537f7ebe087515a61659"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$char = / = String\.fromCharCode\([a-zA-Z]{2,4},[a-zA-Z]{2,4},/
		$var = "var "
		$eval = "eval("
		$script1 = "<script>"
		$script2 = "</script>MZ"

	condition:
		uint16be( 0 ) == 0x4d5a and all of them and $var in ( @script1 .. @script1 + 2000 ) and $char in ( @var .. @var + 100 )
}
rule SEKOIA_Bot_Lin_Kinsing_Strings : FILE
{
	meta:
		description = "Catch Kinsing malware based on strings"
		author = "Sekoia.io"
		id = "ce41b6d0-bc22-4a85-a3bb-ed3234871524"
		date = "2023-11-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/bot_lin_kinsing_strings.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "164b22734541d43047a2ea868cf0a269efe69c64a6392030168f4d391b1be777"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "MinerUrl" ascii
		$s2 = "main.masscan" ascii
		$s3 = "redisBrute" ascii
		$s4 = "ActiveC2CUrl" ascii
		$s5 = "main.getKi" ascii
		$s6 = "main.getMu" ascii
		$s7 = "tryToRunMiner" ascii
		$s8 = "main.kiLoader" ascii
		$s9 = "main.downloadAndExecute" ascii

	condition:
		uint32( 0 ) == 0x464c457f and all of them
}
rule SEKOIA_Apt_Kimsuky_Toddlershark_Obfuscated : FILE
{
	meta:
		description = "Detects obfuscated version of Kimsuky TODDLERSHARK vbs malware"
		author = "Sekoia.io"
		id = "9ab82466-4f38-4597-b75b-13252e180c70"
		date = "2024-03-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_kimsuky_toddlershark_obfuscated.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5f067ce32e7fee5cf481d82bb98f4ae10bd7187078bc111b08fc58d043954152"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = { 3a 20 [3-10] 20 3d 20 22 [3-30] 22 3a }
		$s2 = { 45 78 65 63 75 74 65 28  [3-15] 28 22 }
		$s3 = { 50 72 69 76 61 74 65 20 46 75 6e 63 74 69 6f 6e 20 [3-15] 28 42 79 56 61 6c 20 [3-15] 29 3a }
		$s4 = "& Chr(\"&H\" & Mid("

	condition:
		#s4== 1 and #s3 == 1 and #s2 == 1 and #s1 > 20 and filesize < 1MB
}

rule SEKOIA_Downloader_Win_Andarloader : FILE
{
	meta:
		description = "Detect the AndarLoader downloader used by Andariel"
		author = "Sekoia.io"
		id = "96dd737e-601c-4370-9fa6-4bbafafae203"
		date = "2023-09-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/downloader_win_andarloader.yar#L4-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "02135f60f3edff0b9baa4c20715ee6a80c94f282079bf879265f5e020d37cf88"
		hash = "54ed7a7430974cc2ea694f49f3e637b835dcd24aa19d66af854ad47b87068c92"
		logic_hash = "33e5490b9564333c27a2c23d7f0362c582ca3bd352cafde6b334dc376fd37762"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "b338ad077c7f5be85c33def7287198841d55af8cd1ad856fdcd16fdc78f18838" ) and filesize < 100KB
}
rule SEKOIA_Bot_Lin_Xorddos_Strings : FILE
{
	meta:
		description = "Catch XORDDoS strings"
		author = "Sekoia.io"
		id = "2f5c70a3-fe3f-4091-905d-d779bd0cb2cd"
		date = "2023-11-02"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/bot_lin_xorddos_strings.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b91cfeeaddffe98ac1649c5d88a2091cf7ab8ff65b232f09c323d23684cb2a2d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; SV1; TencentTraveler ; .NET CLR 1.1.4322)" ascii fullword
		$s2 = "sed -i '/\\/etc\\/cron.hourly\\/gcc.sh/d' /etc/crontab && echo '*/3 * * * * root /etc/cron.hourly/gcc.sh' >> /etc/crontab" ascii fullword
		$s3 = "for i in `cat /proc/net/dev|grep :|awk -F: {'print $1'}`; do ifconfig $i up& done"

	condition:
		uint32( 0 ) == 0x464c457f and filesize > 600KB and filesize < 700KB and 3 of them
}
rule SEKOIA_Apt_Unk_Hrserv_Webshell_Strings : FILE
{
	meta:
		description = "Detects HrServ web shell based on strings"
		author = "Sekoia.io"
		id = "684fd41c-9ea6-4f4e-8db4-82325a2ff80b"
		date = "2023-11-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_unk_hrserv_webshell_strings.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b5650e08227bbdb82c635bd67abae57e3107be9126639619809bfbe2a7ffee89"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "open file error!"
		$ = "create file error!"
		$ = "[!] CreatePipe failed."
		$ = "[!] CreateProcess failed."
		$ = "[!] CreateProcess success,no result return."
		$ = "; cadataIV="
		$ = "cadataKey="

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 300KB and 5 of them
}
rule SEKOIA_Tinyfluff_Nodejs : FILE
{
	meta:
		description = "Detect TinyFluff backdoor by OldGremlin"
		author = "Sekoia.io"
		id = "ca8cbd90-f275-4442-8354-b8b069e2efc3"
		date = "2022-04-20"
		modified = "2024-12-19"
		reference = "https://blog.group-ib.com/oldgremlin_comeback"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tinyfluff_nodejs.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "bd0a6a3628f268a37ac9d708d03f57feef5ed55e"
		hash = "bd0a6a3628f268a37ac9d708d03f57feef5ed55e"
		logic_hash = "7fa07b6ea32b914887bdcada0f9fda086bc29a44bfdf27e7433ef589192f4b82"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "TinyFluff.pdb" fullword ascii
		$s2 = "node.exe" fullword wide

	condition:
		filesize < 500KB and uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Infostealer_Win_Vidar_Strings_Nov23 : FILE
{
	meta:
		description = "Finds Vidar samples based on the specific strings"
		author = "Sekoia.io"
		id = "b2c17627-f9b8-4401-b657-1cce560edc76"
		date = "2023-11-10"
		modified = "2024-12-19"
		reference = "https://twitter.com/crep1x/status/1722652451319202242"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_vidar_strings_nov23.yar#L1-L33"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "1a2fc421fb4058b78de28d97d69b126e685f7677b7998f5b6ae3cbcee0ef3f00"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "MachineID:" ascii
		$str02 = "Work Dir: In memory" ascii
		$str03 = "[Hardware]" ascii
		$str04 = "VideoCard:" ascii
		$str05 = "[Processes]" ascii
		$str06 = "[Software]" ascii
		$str07 = "information.txt" ascii
		$str08 = "%s\\*" ascii
		$str09 = "Select * From AntiVirusProduct" ascii
		$str10 = "SELECT target_path, tab_url from downloads" ascii
		$str11 = "Software\\Martin Prikryl\\WinSCP 2\\Configuration" ascii
		$str12 = "UseMasterPassword" ascii
		$str13 = "Soft: WinSCP" ascii
		$str14 = "<Pass encoding=\"base64\">" ascii
		$str15 = "Soft: FileZilla" ascii
		$str16 = "passwords.txt" ascii
		$str17 = "build_id" ascii
		$str18 = "file_data" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 10 of ( $str* )
}
rule SEKOIA_Apt_Unc4990_Emptyspace_Pyc : FILE
{
	meta:
		description = "Detects Python Bytecode of EmptySpace"
		author = "Sekoia.io"
		id = "d970fd9c-1ce5-471c-96a1-146250f36b89"
		date = "2024-02-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_unc4990_emptyspace_pyc.yar#L1-L43"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "98e9c848f6b6276815b040681d7f36548b367257bb75d133309e89e8572a50b7"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "PYBOOTSTRAP"
		$ = "http://google.com/generate_204"
		$ = "from"
		$ = "pathZ"
		$ = "usernamez"
		$ = "timeZ"
		$ = "win32api"
		$ = "base64Z"
		$ = "json"
		$ = "marshalZ"
		$ = "BOOTSTRAP_VERSION"
		$ = "getZ"
		$ = "sleepZ    b64encode"
		$ = "dumps"
		$ = "executableZ"
		$ = "GetUserNameExZ"
		$ = "NameSamCompatible"
		$ = "encode"
		$ = "decodeZ"
		$ = "request_dataZ"
		$ = "server"
		$ = "post"
		$ = "raise_for_status"
		$ = "exec"
		$ = "loadsZ    b64decode"
		$ = "text"
		$ = "globals"
		$ = "bootstrap.py"
		$ = "<module>"

	condition:
		uint32be( 0 ) == 0x420d0d0a and all of them
}
rule SEKOIA_Tool_Gost_Tunnel_Strings : FILE
{
	meta:
		description = "Detects GOST Go Tunnel, based on strings"
		author = "Sekoia.io"
		id = "2de7aae9-9cf8-4007-aa27-5caea4123713"
		date = "2023-02-28"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_gost_tunnel_strings.yar#L1-L35"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "eba1557acc1d9f16817a4bcd24631334a12357e45ad23f1c333de686f20f9291"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = ".(*shadowUDPHandler).transportUDP" ascii
		$ = ".(*quicCipherConn).decrypt" ascii
		$ = ".(*socks4aConnector).ConnectContext.func1" ascii
		$ = ".(*mtlsTransporter).Handshake" ascii
		$ = ".(*FIFOStrategy).Apply" ascii
		$ = ".dnsTCPExchanger" ascii
		$ = ".dohResponseWriter" ascii
		$ = ".tcpRemoteForwardListener" ascii
		$ = ".shadowUDPPacketConn" ascii
		$ = ".sshTunnelListener" ascii
		$ = "/listener/rtcp/listener.go" ascii
		$ = "/handler/unix/handler.go" ascii
		$ = "/handler/tunnel/tunnel.go" ascii
		$ = "/internal/net/proxyproto/listener.go" ascii
		$ = "/internal/util/serial/conn.go" ascii
		$ = "github.com/go-gost/x" ascii

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a or uint32be( 0 ) == 0xcefaedfe or uint32be( 0 ) == 0xcffaedfe or uint32be( 0 ) == 0xbebafeca ) and 5 of them
}
rule SEKOIA_Hacktool_Iox_Tunneling : FILE
{
	meta:
		description = "Detects IOX tunneling tool"
		author = "Sekoia.io"
		id = "45b31d67-95e9-405d-88ea-3f2006ef160a"
		date = "2022-10-13"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_iox_tunneling.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e15df032864799e282ee89402d22b82e5d4b8f469ec292575a1bcb78d24db012"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "iox/operate.Local2Remote"
		$ = "iox/operate.Local2Local"
		$ = "iox/operate.Remote2Remote"
		$ = "iox/operate.ProxyLocal"
		$ = "iox/operate.ProxyRemote"
		$ = "iox/operate.ProxyRemoteL2L"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 5MB and all of them
}
rule SEKOIA_Launcher_Win_Romcom_Launcher : FILE
{
	meta:
		description = "Detect the launcher of RomCom malware"
		author = "Sekoia.io"
		id = "e8fa8239-a763-4be2-8f34-8e112e65b35e"
		date = "2022-11-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/launcher_win_romcom_launcher.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "7d94f187c3fb85cbfe961dd3b292dc1abd36a8cee7c9ff9ec08c4c1e23d38588"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = {43 3a 5c 55 73 65 72 73 5c 31 32 33 5c 73 6f 75 72 63 65 5c 72 65 70 6f 73 5c 69 6e 73 5f 61 73 69 5c 57 69 6e 33 32 5c 52 65 6c 65 61 73 65 5c 73 65 74 75 70 2e 70 64 62}

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule SEKOIA_Rootkit_Win_Purplefox_360_Tct : FILE
{
	meta:
		description = "Detects Purple Fox payloads used during end-2021 and 2022 campaigns based on characteristics shared by TrendMicro details."
		author = "Sekoia.io"
		id = "e992d574-6a44-4bea-97e2-6d5579ce8d01"
		date = "2022-03-28"
		modified = "2024-12-19"
		reference = "https://www.trendmicro.com/en_us/research/22/c/purple-fox-uses-new-arrival-vector-and-improves-malware-arsenal.html"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rootkit_win_purplefox_360_tct.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6b4ca65bc05ea1e8036140a62b94c8b75afe30a5e37cae9a5ae2a9c828cd6275"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$rar = "Rar!"
		$str0 = "svchost.txt"
		$str1 = "rundll3222.exe"
		$str2 = "ojbkcg.exe"

	condition:
		$rar at 0 and all of ( $str* ) and filesize > 800KB and filesize < 2800KB
}
rule SEKOIA_Ransomware_Linux_Icefire_2023 : FILE
{
	meta:
		description = "Rule to detect Linux IceFire ransomware samples."
		author = "Sekoia.io"
		id = "b04964f4-3fdc-4745-9f4a-95a5a79bc7e1"
		date = "2023-02-13"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_linux_icefire_2023.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "e9cc7fdfa3cf40ff9c3db0248a79f4817b170f2660aa2b2ed6c551eae1c38e0b"
		logic_hash = "25033bd33311b070809d150f60803f32011d78a6a74d6b5f620a3216f0f95a6e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$string01 = "********************Your network has been infected!!!********************"
		$string02 = "IMPORTANT : DO NOT DELETE THIS FILE UNTIL ALL YOUR DATA HAVE BEEN RECOVERED!!!"
		$string03 = "username:"
		$string04 = "password:"
		$string05 = ".cfg.o.sh.img.txt.xml.jar.pid.ini.pyc.a.so.run.env.cache.xmlb"
		$string06 = "./boot./dev./etc./lib./proc./srv./sys./usr./var./run"
		$string07 = "/iFire-readme.txt"
		$string08 = ".iFire"
		$string09 = "iFire.pid"

	condition:
		uint32be( 0 ) == 0x7F454C46 and all of them
}
rule SEKOIA_Infostealer_Win_Edgeguard : FILE
{
	meta:
		description = "Finds EdgeGuard Stealer samples based on specific strings"
		author = "Sekoia.io"
		id = "bbdb362f-d235-48f8-8fa5-d340d4e3e3f0"
		date = "2023-08-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_edgeguard.yar#L1-L32"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "11396aea2e166456ec8311f95a8037aac41f69caf3158f8c19cb0c38327842d6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "main.downloadnecessary" ascii
		$str02 = "main.extractchromepasswords" ascii
		$str03 = "main.extracttasksch" ascii
		$str04 = "main.BrowserDownloadsViewExtract" ascii
		$str05 = "main.stealmetamask" ascii
		$str06 = "main.stealexoduswallet" ascii
		$str07 = "main.moveatomic" ascii
		$str08 = "main.movefirefoxcookies" ascii
		$str09 = "main.movepasswords" ascii
		$str10 = "main.FinallyZIPIPFolder" ascii
		$str11 = "edgeguard.business" ascii
		$str12 = "/License.XenArmor" ascii
		$str13 = "/TaskSchedulerView.exe" ascii
		$str14 = "/BrowsingHistoryView.exe" ascii
		$str15 = "/outlookfiles/starter.exe" ascii
		$str16 = "/outlookfiles/External.zip" ascii
		$str17 = "/outlookfiles/XenManager.dll" ascii
		$str18 = "/outlookfiles/EmailPasswordRecoveryPro.exe" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 10 of ( $str* )
}
rule SEKOIA_Apt_Unc3524_Quietexit_Strings : FILE
{
	meta:
		description = "Detect the QUIETEXIT malware used by UNC3524"
		author = "Sekoia.io"
		id = "1bfa9baa-40a3-4ad7-83dc-f9340fbed180"
		date = "2022-05-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_unc3524_quietexit_strings.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "9f8bc7516fdefd94c6bddaf77ea3ac1ba8a3a6380530118c4b28d74b42eaae54"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Child connection from %s:%s" ascii
		$ = "Failed to run %s" ascii
		$ = "add %s %s %s" ascii
		$ = "/usr/bin/xauth -q" ascii
		$ = "/tmp/dropbear-%" ascii
		$ = "cron" ascii
		$ = { DD E5 D5 97 20 53 27 BF F0 A2 BA CD 96 35 9A AD 1C 75 EB 47 }

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize > 1MB and 5 of them
}
rule SEKOIA_Tool_Sharpnbtscan_Strings : FILE
{
	meta:
		description = "Detects SharpNBTScan based on strings"
		author = "Sekoia.io"
		id = "e9d28dcb-b4b1-4d66-b225-ed0925f307d9"
		date = "2024-09-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_sharpnbtscan_strings.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "adc19140e84c4aa3433b8ae4096355e384bbd106326ed56b54fb44a86fd9fbc6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[+]Udp client will stop in 10 s ..." ascii wide
		$ = "[*]Stop udp client ..." ascii wide
		$ = "[*]Start udp client ..." ascii wide
		$ = "[+] ip range {0} - {1} " ascii wide

	condition:
		uint32be( 0 ) == 0x5A4D and all of them
}

rule SEKOIA_Apt_Mustang_Panda_Toneshell : FILE
{
	meta:
		description = "Detect the TONESHELL implant used by Mustang Panda from specific functions"
		author = "Sekoia.io"
		id = "bf7c68a9-dddc-494a-a603-c2311ed712a4"
		date = "2022-11-28"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_mustang_panda_toneshell.yar#L4-L160"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "192fb01817cc6361062999cf539c51616d1755a5cd8e9d6e37bee6f6d04b0721"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$func1 = {
        55
        89 E5
        64 A1 18 00 00 00
        A3 ?? ?? ?? ??
        5D
        C3
        }
		$func2 = {
        55
        89 E5
        50
        8B 45 ??
        8B 45 ??
        8B 45 ??
        8B 45 ??
        89 45 ??
        8B 45 ??
        89 C1
        83 C1 FF
        89 4D ??
        83 F8 00
        0F 84 ?? ?? ?? ??
        8B 45 ??
        8A 08
        8B 45 ??
        88 08
        8B 45 ??
        83 C0 01
        89 45 ??
        8B 45 ??
        83 C0 01
        89 45 ??
        E9 ?? ?? ?? ??
        8B 45 ??
        83 C4 04
        5D
        C3
        }
		$decryption_routine1 = {
        8B 45 ??
        C7 45 ?? 00 00 00 00
        83 7D ?? 20
        0F 8D ?? ?? ?? ??
        8B 45 ??
        8B 4D ??
        0F BE 04 08
        83 F0 ??
        88 C2
        8B 45 ??
        8B 4D ??
        88 14 08
        8B 45 ??
        83 C0 01
        89 45 ??
        E9 ?? ?? ?? ??
        83 C4 04
        }
		$decryption_routine2 = {
        55
        89 E5
        83 EC 08
        8B 45 ??
        8B 45 ??
        8B 45 ??
        8B 45 ??
        C7 45 ?? 00 00 00 00
        C7 45 ?? 00 00 00 00
        8B 45 ??
        3B 45 ??
        0F 8D ?? ?? ?? ??
        8B 45 ??
        8B 4D ??
        0F BE 04 08
        8B 4D ??
        8B 55 ??
        0F BE 0C 11
        31 C8
        88 C2
        8B 45 ??
        8B 4D ??
        88 14 08
        8B 45 ??
        8B 4D ??
        83 E9 01
        39 C8
        0F 85 ?? ?? ?? ??
        C7 45 ?? 00 00 00 00
        E9 ?? ?? ?? ??
        8B 45 ??
        83 C0 01
        89 45 ??
        8B 45 ??
        83 C0 01
        89 45 ??
        E9 ?? ?? ?? ??
        83 C4 08
        5D
        C3
        }

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 8MB and for all i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) != "69f400d3ff4679294e63fb8a8ca97dbb" ) and 3 of them and true
}
rule SEKOIA_Apt_Muddywater_Manifestation_Backdoor_Obfuscated : FILE
{
	meta:
		description = "Detects obfuscated Muddys manifestation JScript backdoor"
		author = "Sekoia.io"
		id = "58df72a1-822c-4b82-904d-1c0124dc7bc1"
		date = "2022-01-13"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_muddywater_manifestation_backdoor_obfuscated.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8610f0895fafd2bc9a19bbff816754b563565ba6b105cc3d0a32b80bf5ebdc47"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$m = { 76 61 72 20 5f 30 78 [4-6] 3d 5b }
		$w = {57 53 63 72 69 70 74 5b 5f 30 78 [4-6] 28 30 78 [2-3] 29 5d 28 30 78 [2-3] 2a 30 78 [2-3] 29 2c }
		$t = "subkeys(key));}"

	condition:
		$m at 0 and ( $t at ( filesize -16 ) or $w in ( filesize -200 .. filesize ) )
}
rule SEKOIA_Backdoor_Xploitspy_Strings : FILE
{
	meta:
		description = "Detects XploitSPY DEX file"
		author = "Sekoia.io"
		id = "0aa86c2e-dba6-4ef4-a47e-f1b43e04f1f3"
		date = "2022-08-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_xploitspy_strings.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "eabb1dbeaa8aefc33beb7fb158bbd8ad2c5b848d34c99473704da36a6dc461aa"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = { 04 30 78 43 42 00 }
		$ = { 04 30 78 43 4C 00 }
		$ = { 04 30 78 43 4F 00 }
		$ = { 04 30 78 46 49 00 }
		$ = { 04 30 78 47 50 00 }
		$ = { 04 30 78 49 4E 00 }
		$ = { 04 30 78 4C 4F 00 }
		$ = { 04 30 78 4D 49 00 }
		$ = { 04 30 78 4E 4F 00 }
		$ = { 04 30 78 50 4D 00 }
		$ = { 04 30 78 53 4D 00 }
		$ = { 04 30 78 57 49 00 }

	condition:
		uint32be( 0 ) == 0x6465780A and filesize < 1MB and 10 of them
}
rule SEKOIA_Implant_Mac_Smoothoperator_Update_Agent : FILE
{
	meta:
		description = "UpdateAgent payload delivered by SmoothOperator during the 3CX supply chain attack"
		author = "Sekoia.io"
		id = "45a1d0d9-083b-4b4a-b53c-e5d86f804f01"
		date = "2023-07-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_mac_smoothoperator_update_agent.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "d5a0d87ac810097983df92ab1b1ff9775093b0aaaf551a74ff6fe5149dbd3a21"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "3CX Desktop App/.main_storage"
		$ = "3CX Desktop App/config.json"
		$ = "3cx_auth_token_content=%s"
		$ = "3cx_auth_id=%s"

	condition:
		uint32be( 0 ) == 0xcffaedfe and 2 of them
}

rule SEKOIA_Launcher_Win_Bluehaze : FILE
{
	meta:
		description = "Detect the BLUEHAZE malware"
		author = "Sekoia.io"
		id = "ccfe0593-0a9f-4369-952e-5cef2f459bb3"
		date = "2022-12-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/launcher_win_bluehaze.yar#L4-L35"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "56a9d6d713a5744e77c8d34ad28983bb3b2aded1abff47dbf2d887724bd3ed4e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Libraries\\CNNUDTV"
		$ = "cmd.exe /C wuwebv.exe -t -e"
		$ = "cmd.exe /C reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run /v ACNTV /t REG_SZ /d \"Rundll32.exe SHELL32.DLL,ShellExec_RunDLL"

	condition:
		uint16( 0 ) == 0x5A4D and 3 of them or pe.imphash ( ) == "1b3d8fae6035e34f91baa59643746efe" or hash.md5 ( pe.rich_signature.clear_data ) == "44022b7cefeae4d55edcceb5b9bcd295" or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "1cdcb493593f8793b10e109f6b5b2993" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "276d668ed7d1b46e101425e02a16460f" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "f6a474220add335b5696256235ce8c9c" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "82bccb3330d50080f86ab1aa566cae8e" )
}
rule SEKOIA_Apt_Cloudatlas_Rtf_Shellcode_Cve_2018_0798 : FILE
{
	meta:
		description = "CloudAtlas Shellcode for CVE_2018_0798 "
		author = "Sekoia.io"
		id = "6c602c66-df40-4436-800f-e548dacc1e81"
		date = "2022-12-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_cloudatlas_rtf_shellcode_cve_2018_0798.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a8c320ca81ef196b84a8fb08d9e02ef8cfb338024fa7e6776ff6c8c049b8e63c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "6060606061616161616161616161616161616161FB0B00004bE8FFFFFFFFC35F83C71B33C966B908010f0d00ddd8d97424f4668137" ascii nocase

	condition:
		filesize < 8MB and all of them
}
rule SEKOIA_Rat_Win_Xeno_Rat : FILE
{
	meta:
		description = "Xeno RAT is an open-source RAT, used by Kimsuky in January 2024"
		author = "Sekoia.io"
		id = "4be1ff07-8180-42a8-9f51-b5e17bf23442"
		date = "2024-02-09"
		modified = "2024-12-19"
		reference = "https://github.com/moom825/xeno-rat/tree/main/xeno%20rat%20client"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_xeno_rat.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "252dd8b236ce3570b6df504d307d88ee7431c0eee361813f1d4f8a66ef1db703"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Xeno-manager" wide
		$ = "moom825"

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule SEKOIA_Apt_Emberbear_Credpump_Strings : FILE
{
	meta:
		description = "Detects CredPump backdoor"
		author = "Sekoia.io"
		id = "c9898e34-4ab8-49d6-9c8a-3fce592449e2"
		date = "2023-02-28"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_emberbear_credpump_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6f2c96fe3f314221626b4c053658af0e7231f151886f10eb1d69e07ea3e5c634"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "User=%s Pass=%s Host=%s"
		$ = "/etc/rc0.d/.rc0.d"
		$ = "pam_get_authtok"
		$ = "Password:"

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 200KB and all of them
}
rule SEKOIA_Apt_Tortoiseshell_Imaploader : FILE
{
	meta:
		description = "Detects IMAPLoader malware"
		author = "Sekoia.io"
		id = "e1706b59-5c94-4fbf-8560-0022ca631d1d"
		date = "2023-11-13"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_tortoiseshell_imaploader.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "93f57940ed69145064e5153cc9b099fb9456116cae808acfb4e6f7f14003dde7"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "yandex.com"
		$s2 = "saveImapMessage.pdb"
		$s3 = "downloader"
		$s4 = "MailServer.Auth"

	condition:
		filesize < 1MB and 3 of them
}
rule SEKOIA_Apt_Spynote_Android_Dex_Strings : FILE
{
	meta:
		description = "Detects Android SpyNote DEX file"
		author = "Sekoia.io"
		id = "87fb8b7a-bfac-4003-b618-50b4a7863928"
		date = "2022-08-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_spynote_android_dex_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "474617628afe110d9e7ea2acef57c5e560139b57aa7e497bf9e111af239e9588"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "is not file found"
		$ = "Can not access"
		$ = "PANG !!"
		$ = "On Start!!"

	condition:
		uint32be( 0 ) == 0x6465780A and filesize < 1MB and all of them
}

rule SEKOIA_Infostealer_Win_Aurora_Str : FILE
{
	meta:
		description = "Finds Aurora botnet samples based on characteristic strings."
		author = "Sekoia.io"
		id = "1f4391b8-700f-4702-9ef6-68ce3d55a176"
		date = "2022-07-21"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_aurora_str.yar#L3-L34"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "745443bb58f00cb09a1f323f530219913eaaf0d0e71c9a25af2072006f8c5f92"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "Logs.tar" ascii
		$str02 = "*main.StealerData" ascii
		$str03 = "AppData\\Roaming\\Armory" ascii
		$str04 = "AppData\\Local\\BraveSoftware\\Brave-Browser\\User Data" ascii
		$str05 = "github.com/TheTitanrain/w32" ascii
		$str06 = "github.com/mattn/go-sqlite3" ascii
		$str07 = "ScreenShot" ascii
		$str08 = "*sql.stmtConnGrabber" ascii
		$str09 = "Default\\Network\\Cookies" ascii
		$str10 = "BuildID" ascii
		$str11 = "Clipper" ascii
		$str12 = "GeoPos" ascii
		$str13 = "AppData\\Roaming\\Exodus\\exodus.wallet" ascii
		$str14 = "FileGrabber\\Documents" ascii
		$str15 = "193.233.48." ascii
		$str16 = "ShellExecute" ascii
		$str17 = "crypto/aes.(*aesCipherGCM).Encrypt" ascii
		$str18 = "File-Download" ascii

	condition:
		uint16( 0 ) == 0x5A4D and ( 14 of them or pe.imphash ( ) == "8ee5c1c09f740fbe63e8b35dac5d6f70" or pe.imphash ( ) == "369b4f5b6c99674f15070689e1f675af" )
}
rule SEKOIA_Apt_Badmagic_Generic_Pshscript : FILE
{
	meta:
		description = "Detects BadMagic generic powershell script (Possible FPs)"
		author = "Sekoia.io"
		id = "82cda554-3c2b-4c04-b9f9-b5ba50c53271"
		date = "2023-05-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_badmagic_generic_pshscript.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f442e1ba815cc7eae0c627db5ad1917021d69b8ce37155923a0f19776aeba95d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "$ExecutablePath"
		$ = "Start-Sleep -Second 2"

	condition:
		all of them and filesize < 1KB
}
rule SEKOIA_Generic_Sharpshooter_Payload_1 : FILE
{
	meta:
		description = "Detects payload created by SharpShooter"
		author = "Sekoia.io"
		id = "82fd284a-47c2-4d29-9c80-f3affaa61a13"
		date = "2023-02-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/generic_sharpshooter_payload_1.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "20e42042bd03bde3d0eec42f81d560896e8ec9e67ad64611dc4bc21152db3ff0"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "rc4 = function(key, str)"
		$ = "var e={},i,b=0,c,x,l=0,a,r="
		$ = "var plain = rc4("
		$ = "<script language="

	condition:
		all of them and filesize < 2MB
}
rule SEKOIA_Win_Malware_Statc_Downloader : FILE
{
	meta:
		description = "Statc Downloader powershell script. Base64 powershell"
		author = "Sekoia.io"
		id = "4a2e9607-635b-4cd8-ba27-d70e0c76fd45"
		date = "2023-08-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/win_malware_statc_downloader.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "173ea5af2e71b6ed70abd52a5d2f4de040393a6d2ff4978bbb6e73d96742b010"
		logic_hash = "a99970a6ace88234e5e2bda009f8d87e6a0dc8c1a4655cca128e30292a21502c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$powershell = "powershell.exe"
		$a1 = "KABOAGUAdwAtAE8AYgBqAGUAYwB0ACAATgBlAHQALgBXAGUAYgBjAGwAaQBlAG4AdAApAC4AZABvAHcAbgBsAG8AYQBkAGYAaQBsAGUAKAAiAGgAdAB0AHAAcwA6AC8A"
		$a2 = "gATgBlAHcALQBPAGIAagBlAGMAdAAgAE4AZQB0AC4AVwBlAGIAYwBsAGkAZQBuAHQAKQAuAGQAbwB3AG4AbABvAGEAZABmAGkAbABlACgAIgBoAHQAdABwAHMAOgAvA"
		$a3 = "oAE4AZQB3AC0ATwBiAGoAZQBjAHQAIABOAGUAdAAuAFcAZQBiAGMAbABpAGUAbgB0ACkALgBkAG8AdwBuAGwAbwBhAGQAZgBpAGwAZQAoACIAaAB0AHQAcABzADoALw"
		$b1 = "aQBuAHYAbwBrAGUALQBlAHgAcAByAGUAcwBzAGkAbwBuACAAIgAkAGUAbgB2ADoAVABFAE0AUABc"
		$b2 = "kAbgB2AG8AawBlAC0AZQB4AHAAcgBlAHMAcwBpAG8AbgAgACIAJABlAG4AdgA6AFQARQBNAFAAX"
		$b3 = "pAG4AdgBvAGsAZQAtAGUAeABwAHIAZQBzAHMAaQBvAG4AIAAiACQAZQBuAHYAOgBUAEUATQBQAF"
		$c1 = "MQAgADEAIgA7ACAAIgBPAEsAIgA7"
		$c2 = "EAIAAxACIAOwAgACIATwBLACIAO"
		$c3 = "xACAAMQAiADsAIAAiAE8ASwAiAD"

	condition:
		$powershell at 0 and 1 of ( $a* ) and 1 of ( $b* ) and 1 of ( $c* ) and filesize < 1MB
}
rule SEKOIA_Generic_Sharpshooter_Payload_12 : FILE
{
	meta:
		description = "Detects payload created by SharpShooter"
		author = "Sekoia.io"
		id = "b69186cf-9825-4d90-be20-7caa9e7de61f"
		date = "2023-02-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/generic_sharpshooter_payload_12.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5c9692337c0dd533c7e49bd3850feedad93b256bc2fba45af6121f50ad83f4cc"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "ms.Write(ba, 0, (length / 4) * 3);"
		$ = "var serialized_obj = "
		$ = "d.DynamicInvoke(al.ToArray()).CreateInstance(entry_class);"
		$ = "var sc ="

	condition:
		all of them and filesize < 2MB
}
rule SEKOIA_Tool_Execit_Obfuscator_Strings : FILE
{
	meta:
		description = "Detects ExecIT Dlls"
		author = "Sekoia.io"
		id = "59eaeb20-150b-41a4-b866-1c91a07623ac"
		date = "2024-09-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_execit_obfuscator_strings.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "1c185e2e11d8eadccfb130766ca30d85"
		hash = "a0898f57f2b139ea278d8a7e97bbe358"
		hash = "e0e12a8891f5585ce1ad55dbffb4f9c2"
		hash = "d4102676d536bacffcf6c94364e26828"
		logic_hash = "cd8edbe9c6cb7dcde56860e0ff47f4496b36848f46a89f6945b7762f86ff5e59"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "yromeMlautriVetacollAtN"
		$ = "xEdaerhTetaerCtN"
		$ = "tcejbOelgniSroFtiaWtN"
		$ = "lld.esablenrek"
		$ = "txetnoCdaerhTteG"
		$ = "txetnoCdaerhTteS"
		$ = "cef_api_hash"
		$ = "cef_execute_process"
		$ = "cef_get_path"

	condition:
		uint16be( 0 ) == 0x4d5a and 5 of them
}
rule SEKOIA_Malware_Venom_Admin_Strings : FILE
{
	meta:
		description = "Detects Venom admin strings"
		author = "Sekoia.io"
		id = "4929340c-310b-4c59-a111-23409f973d22"
		date = "2022-08-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/malware_venom_admin_strings.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "205f16b07f58290b2898de7a7dd1e20f3d7651d738f0b15bf810f9be66eedf3d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "/admin/admin.go"
		$ = "/cli/interactive.go"
		$ = "/cli/cli.go"
		$ = "/dispather/sender.go"
		$ = "/dispather/proxy.go"
		$ = "/dispather/handler.go"
		$ = "/dispather/forward.go"
		$ = "/utils/reuse_port.go"

	condition:
		filesize < 11MB and 6 of them
}
rule SEKOIA_Ransomware_Win_Raworld
{
	meta:
		description = "Detects files related to stage 1 of a campaign from the ransomware group RA World."
		author = "Sekoia.io"
		id = "a9ed9c5a-7a0e-4c2e-90f4-d52f5589b2b8"
		date = "2024-07-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_win_raworld.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "583dd2ea8e20a87d0b67783d1dd59212eb133de1f945d5b4afad89e8a5017d35"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "Loder.exe" ascii fullword
		$s2 = "Stage2.exe" wide
		$s3 = "SYSVOL" wide
		$s4 = "Finish.exe" wide
		$s5 = "Exclude.exe" wide
		$s6 = "Stage3.exe" wide
		$s7 = "Pay.txt" ascii fullword
		$s8 = "RA World" ascii fullword
		$s9 = "Stage1.exe" ascii fullword

	condition:
		4 of them
}
rule SEKOIA_Apt_Scanbox_Framework_Not_Obfuscated : FILE
{
	meta:
		description = "Detects the non obfuscated version of ScanBox"
		author = "Sekoia.io"
		id = "4790f122-89de-4f7b-a25f-9ac7b1af8333"
		date = "2022-09-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_scanbox_framework_not_obfuscated.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "52779571eb4e68442542a1c4cff58d5b00a264bb567396126cd93dc4ec4eda45"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "php?m=a&data="
		$ = "php?m=p&data="
		$ = ".fun.split_data = function"
		$ = ".php?data="
		$ = ".php?m=b"
		$ = "basic.apipath"
		$ = ".info.seed ="
		$ = "loadjs ="
		$ = "info.color = screen.colorDepth"

	condition:
		5 of them and filesize < 500KB
}
rule SEKOIA_Apt_Apt29_Wineloader_Malicious_Pdf : FILE
{
	meta:
		description = "Detects malicious PDF used by APT29 to drop Wineloader"
		author = "Sekoia.io"
		id = "b1db731e-471e-493a-b76c-38d2808ccac9"
		date = "2024-03-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt29_wineloader_malicious_pdf.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "9712217ff3597468b48cdf45da588005de3a725ba554789bb7e5ae1b0f7c02a7"
		hash = "3739b2eae11c8367b576869b68d502b97676fb68d18cc0045f661fbe354afcb9"
		logic_hash = "784f5ab2602e2185e8253b5b8d9a084ede0604457b0a0674fceffbcb226e3ba1"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "<</Type/Annot/Subtype/Link/Border[0 0 0]/Rect["
		$s2 = "/A<</Type/Action/S/URI/URI("
		$s3 = { 2f [2-10] 2e 70 68 70 29 3e 3e }
		$s4 = "JamrulNormal"

	condition:
		uint32be( 0 ) == 0x25504446 and $s2 in ( @s1 .. @s3 ) and $s4
}
rule SEKOIA_Pe_Princeransomware_Strings : FILE
{
	meta:
		description = "Prince Ransomware exe files"
		author = "Sekoia.io"
		id = "9c5cad6e-2b11-469c-ace1-2dc51562b035"
		date = "2024-08-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/pe_princeransomware_strings.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "8bd8de169f45e32bab53f6e06088836d6f0526105f03efa1faf84f3b02c43011"
		hash = "a83aad6861c8fdfe2392b8e286ab7051d223c6b0bbba5996165964f429657a37"
		logic_hash = "18577c5673b4fc5280dee88aefac3747c254a97fdc84b584af241277361f6400"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "https://i.imgur.com/RfsCOES.png" ascii
		$ = {596f75722066696c65732068617665206265656e20656e63727970746564207573696e67205072696e63652052616e736f6d77617265}

	condition:
		all of them and uint16( 0 ) == 0x5a4d and filesize > 1MB
}
rule SEKOIA_Apt_Badmagic_Startrevsocks_Pshscript : FILE
{
	meta:
		description = "Detects BadMagic DLL Loader powershell script"
		author = "Sekoia.io"
		id = "a6c96aee-9e78-47d2-afe3-f3c5246a9370"
		date = "2023-05-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_badmagic_startrevsocks_pshscript.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6a4615afb836330634cde9559dacfff50daef44a370f6191c6771a2066074a31"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "$ExecutablePath"
		$ = "Start-Sleep -Second 2"
		$ = "recn -15 -rect 15"

	condition:
		all of them and filesize < 1KB
}
rule SEKOIA_Loader_Win_Purecrypter : FILE
{
	meta:
		description = "Detect the PureCrypter loader"
		author = "Sekoia.io"
		id = "500b4d9e-55f8-41d1-ad4f-d587bbeb4507"
		date = "2022-09-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_purecrypter.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5d0d733a4f8447d2d51656a20640fc9482581e19ba1d53fed7d98e85bb748763"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$hex01 = /http:\/\/[^\s]{5,90}_[A-Z][a-z]{7}\.(bmp|jpg|png)/ wide
		$hex02 = "WrapNonExceptionThrows" ascii

	condition:
		uint16( 0 ) == 0x5A4D and ( $hex02 in ( @hex01 .. @hex01 + 1000 ) or $hex01 in ( @hex02 .. @hex02 + 1000 ) )
}
rule SEKOIA_Hacktool_Ntospy_Strings : FILE
{
	meta:
		description = "Detects Ntospy based on strings"
		author = "Sekoia.io"
		id = "c3281666-6a31-4718-a9c0-82944c6fdcb0"
		date = "2023-12-05"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_ntospy_strings.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e5bd963419e515d65a03592051822fd801f4a21d54cdb18d408556c4bfef78f5"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "NPGetCaps"
		$ = "NPLogonNotify"
		$ = {43 00 3A 00 5C 00 [10-150] 00 2E 00 6D 00 73 00 75}

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 300KB and all of them
}
rule SEKOIA_Downloader_Win_Newsterminal : FILE
{
	meta:
		description = "Detect the PowerShell based downloader used by APT42 called NEWSTERMINAL"
		author = "Sekoia.io"
		id = "2f9aae45-e3bd-4d87-b336-5d141738952b"
		date = "2024-08-26"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/downloader_win_newsterminal.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "2b756515400d7e3b6e21ee3a83f313c8"
		logic_hash = "45c6c2b5b3723bf3ed46c82e6a254547d8c8b3446bb2fa4b4f0fc8441731ae7e"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Start-Process -FilePath $takeownCommand -ArgumentList $takeownArgs -Wait -NoNewWindow"
		$ = "function Download-And-Extract-Dll {"
		$ = {24 69 63 61 63 6C 73 41 72 67 73 20 3D 20 24 64 65 73 74 69 6E 61 74 69 6F 6E 46 69 6C 65 50 61 74 68 2C 20 22 2F 67 72 61 6E 74 22 2C 20 22 41 64 6D 69 6E 69 73 74 72 61 74 6F 72 73 3A 46 22 2C 20 22 2F 63 22 2C 20 22 2F 71 22}
		$ = "$publicip=(iwr http://127.0.0.1:4040/api/tunnels"

	condition:
		1 of them and filesize < 30KB
}

rule SEKOIA_Implant_Win_Incontroller : FILE
{
	meta:
		description = "Detect the INCONTROLLER implant "
		author = "Sekoia.io"
		id = "c346c6ea-c5c0-4e9f-a632-1e8ed0286fbc"
		date = "2022-04-14"
		modified = "2024-12-19"
		reference = "https://www.mandiant.com/resources/incontroller-state-sponsored-ics-tool"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_win_incontroller.yar#L4-L49"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "69296ca3575d9bc04ce0250d734d1a83c1348f5b6da756944933af0578bd41d2"
		logic_hash = "988e3004169817758a38dc7cd621ed351dac4de41e6dad03ab1cdfc07b8a6cac"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "AsRockDrv.sys" ascii
		$ = "C:\\Users\\User1\\Desktop\\dev projects\\SignSploit1\\x64\\Release\\AsrDrv_exploit.pdb" ascii
		$ = "found map in %.3f sec physical address : %016I64x" ascii
		$ = "get physical regions error : %x!"
		$ = "Device AsrDrv103 was opened successefuly!" ascii
		$ = "Ioctl handler AsrDrv103 was found successefuly!" ascii
		$ = "cant open the AsrDrv103!" ascii
		$ = "can't read a unsigned driver ! " ascii
		$ = "cant drop and load exploatable driver ! " ascii
		$ = "please set unsigned driver as argument to program!" ascii
		$ = "\\DosDevices\\AsrDrv103" wide
		$t = "This program cannot be run in DOS mode."

	condition:
		( uint16( 0 ) == 0x5A4D and 4 of them and filesize < 800KB and #t == 2 ) or pe.imphash ( ) == "f139e860bc959a7e65a008399425c090" or for any i in ( 0 .. pe.number_of_sections -1 ) : ( hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "a2fe4d32d74354c391a283178f0291e6" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "c33f9caa68fe46c6996a928ba5a38fd6" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "d9a1f1a4d48906da1d9f33eae0f0eaef" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "76426b0209a87fa32ca28e9f2361be67" or hash.md5 ( pe.sections [ i ] . raw_data_offset , pe.sections [ i ] . raw_data_size ) == "9e63a5064b755925598b8d72ace52dc9" ) or hash.md5 ( pe.rich_signature.clear_data ) == "140d7fb360dbebb03edab903b5d08285"
}
rule SEKOIA_Loader_Win_Erbium : FILE
{
	meta:
		description = "Detect the Erbium loader based on specific user-agent and URI"
		author = "Sekoia.io"
		id = "d1e5be62-5677-4ef4-9f10-65baf36ab619"
		date = "2022-09-30"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_win_erbium.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e93e9dbf0e5412afa4640b4cf5d94374c4df38f8044d44c375e86508c0d4190a"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36" wide
		$str02 = "cloud/getHost.php?method=getstub&bid=" wide
		$str03 = "api.php?method=getstub&bid=" wide
		$api = "WinHttp" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 2 of ( $str* ) and #api > 6
}
rule SEKOIA_Apt_Cerana_Keeper_Dropboxflop : FILE
{
	meta:
		description = "Detects DropboxFlop malware"
		author = "Sekoia.io"
		id = "e077901f-3847-45f3-82cb-d52724cd3fb5"
		date = "2024-10-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_cerana_keeper_dropboxflop.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "2b65b74e52fbf25cb400dbdfcd1a06a7"
		logic_hash = "5b2dfdf0c35f574e7006bb3e6eafa10d0e7fc7d980d443b31d4d6d6b7cec2fce"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "<assemblyIdentity type=\"win32\" name=\"dropboxflop\""

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Apt_Kimsuky_Fpspy : FILE
{
	meta:
		description = "Detects FPSpy, a backdoor used by Kimsuky"
		author = "Sekoia.io"
		id = "75d41851-a7a6-4068-8ea5-6a3e6e62a965"
		date = "2024-09-27"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_kimsuky_fpspy.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "6d6c1b175e435f5564341cc1f2c33ddf"
		hash = "54c58b72f98cb63c44e7694add551e9d"
		logic_hash = "65904b77a30b2e2a25f8d80ab32742f0ad931f07c034ae576a4fbde7e1fd999c"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Chrome/31.0." wide
		$ = "%srundll32.exe %s, %s %%1" wide
		$ = "MazeFunc" wide
		$ = "sys.dll" wide
		$ = "KLog" wide

	condition:
		uint16be( 0 ) == 0x4d5a and 4 of them
}
rule SEKOIA_Backdoor_Win_Rollsling : FILE
{
	meta:
		description = "Detect Lazarus' RollSling malware (aka LazarLoader)"
		author = "Sekoia.io"
		id = "5ef23b9c-5bc5-4f02-b1b4-1af18a03241a"
		date = "2023-10-24"
		modified = "2024-12-19"
		reference = "https://www.microsoft.com/en-us/security/blog/2023/10/18/multiple-north-korean-threat-actors-exploiting-the-teamcity-cve-2023-42793-vulnerability/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_win_rollsling.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "d9add2bfdfebfa235575687de356f0cefb3e4c55964c4cb8bfdcdc58294eeaca"
		hash = "48538a935ddf2cbeb4918d0ccf9372ec8e0a57c5fd145a584a9b1bb4ebbcd5ce"
		hash = "18825be6b269087d7699f3d0aa2e6db2ae72ded36c56aa8e7b8a606dde3741fa"
		hash = "645205e38dfdd560f6242ba717af1bfdd8e85baf5e710d724b853fe9808c4551"
		hash = "455bab490a300d9d63b8777c223287c0a6a647ca7b98b96fd3236f83b8adc77b"
		logic_hash = "5cee25638bdc86b3ffb1c616943d647ca170c5c0140ae3e3118f56b504fa862f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "LookupPrivilegeVCreateRemoteThreAdjustTokenPriviOpenProcessToken"

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Tool_Nssm_Strings : FILE
{
	meta:
		description = "Detects nssm tool"
		author = "Sekoia.io"
		id = "fab99d44-6494-4bfc-80c0-67c45bad0425"
		date = "2024-09-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_nssm_strings.yar#L1-L22"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "beceae2fdc4f7729a93e94ac2ccd78cc"
		logic_hash = "ca883f3ed9f510cbcd9b96ad167e9d6725341c311b023f22edcba721e801f07d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "nssm start <servicename>" wide
		$ = "nssm stop <servicename>" wide
		$ = "nssm restart <servicename>" wide
		$ = "nssm status <servicename>" wide
		$ = "nssm rotate <servicename>" wide

	condition:
		uint16be( 0 ) == 0x4d5a and all of them and filesize < 500KB
}
rule SEKOIA_Infostealer_Win_Whitesnake_Loader_Feb23 : FILE
{
	meta:
		description = "Finds WhiteSnake samples (loader module, bat file)"
		author = "Sekoia.io"
		id = "f81a8a96-6fd2-4f5c-8a56-ff66ff1a80d3"
		date = "2023-03-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_whitesnake_loader_feb23.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "c9d4414fb17c28a3ea2e75837732e1657bdc7b2df4a7ab34e458d659441759e8"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "echo         Please wait... a while Loading data ...." ascii
		$str02 = "CERTUTIL -f -decode" ascii
		$str03 = "%Temp%\\build.exe" ascii
		$crt = "-----BEGIN CERTIFICATE-----" ascii
		$mz = "TVqQAAMAAAAEAAAA" ascii

	condition:
		($str01 in ( 0 .. 200 ) or $str02 in ( 0 .. 200 ) or $str03 in ( 0 .. 200 ) ) and $mz in ( @crt .. @crt + 50 ) and filesize < 100KB
}
rule SEKOIA_Apt_Sidecopy_Cheex : FILE
{
	meta:
		description = "Detects PDB path of Cheex"
		author = "Sekoia.io"
		id = "e9b57f15-e703-4367-b501-fa8a873e4455"
		date = "2024-08-14"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_sidecopy_cheex.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "825c7a1603f800ff247c8f3e9a1420af"
		logic_hash = "e5561466b616c746b33c0c4a46e8bdb0859e55aef8896bc1b14e54838c1661ee"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "C:\\Users\\Dead Snake\\source\\repos\\cheex" ascii fullword

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Apt_Konni_Dropper : FILE
{
	meta:
		description = "Detects Konni dropper used when distributed via malicious document"
		author = "Sekoia.io"
		id = "0783a55e-1d1e-40ca-a661-2c5dec6d78d6"
		date = "2023-11-27"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_konni_dropper.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6d1b1f5ccbdc20908891e5f40ceb85c251b1ca2a395fa4b106e63718c6393a22"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "UnzipAFile"
		$ = "check.bat"
		$ = "FOF_SILENT"
		$ = "fLieObj"

	condition:
		filesize < 1MB and 3 of them
}

rule SEKOIA_Apt_Windows_Wip19_Screencap : FILE
{
	meta:
		description = "Detects ScreenCap resource"
		author = "Sekoia.io"
		id = "ebf5d2c5-81c9-45c3-aa61-05870f800f6b"
		date = "2022-10-18"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_windows_wip19_screencap.yar#L4-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "02479f0c8199b31f089608da0f44f1487b75790cb31c77bb65ca1fb0fd57ac0d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "89f4d0e3f7f3318270aa9c8345c1402202b1a02ffefc03c7a86636e297aa0ffc" ) and filesize < 2MB
}
rule SEKOIA_Trojan_Android_Brata : FILE
{
	meta:
		description = "Detect samples of the Android banking trojan BRATA"
		author = "Sekoia.io"
		id = "fde9b82e-c677-44ed-b512-b225a3aba201"
		date = "2022-01-27"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/trojan_android_brata.yar#L1-L29"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0c94e5e0c01d4fa9bf28603787029938a3159f468dd3876e7d25646e93dd68b8"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$goo0 = "Google Play services error"
		$goo1 = "Error de Serveis de Google Play"
		$goo2 = "Fehler bei Zugriff auf Google Play-Dienste"
		$goo3 = "Erro nos servizos de Google Play"
		$goo4 = "Fout met Google Play-services"
		$goo5 = "Virhe Google Play -palveluissa"
		$goo6 = "Erro do Google Play Services"
		$goo7 = "Error de Google Play Services"
		$res0 = "res/xml/device_admin.xml"
		$res1 = "res/xml/windowchangedetectingservice.xml"
		$res2 = "res/xml-v22/windowchangedetectingservice.xml"

	condition:
		uint32be( 0 ) == 0x504B0304 and filesize > 2MB and filesize < 6MB and 7 of ( $goo* ) and 2 of ( $res* )
}
rule SEKOIA_Apt_Kimsuky_Toddlershark_Strings : FILE
{
	meta:
		description = "Detects Kimsuky TODDLERSHARK vbs malware"
		author = "Sekoia.io"
		id = "2db1a424-9e83-4168-8ebf-d3b415b6a576"
		date = "2024-03-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_kimsuky_toddlershark_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "dee9d03f498437dd6d8399975cd91ec44307067ac4642b9ff31df1a6d6b10468"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "On Error Resume Next"
		$ = ".open \"POST\", \"http"
		$ = ".setRequestHeader"
		$ = ".send"
		$ = "Execute("
		$ = ".responseText)"

	condition:
		all of them and filesize < 450
}
rule SEKOIA_Exploit_Linux_Eop_Rationallove_Strings : FILE
{
	meta:
		description = "Detects RationalLove Local Privesc exploit"
		author = "Sekoia.io"
		id = "e71e026e-ca2c-42b7-b552-b3fd013676db"
		date = "2023-12-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/exploit_linux_eop_rationallove_strings.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "84a53a1d4f08e178a5cf1c968b3b98ae8624c3d052760517ec88bddd25833108"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "../x/../../AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/"
		$ = "Detected OS version: %s"
		$ = "Content-Type: text/plain; charset=UTF-8"

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 1MB and all of them
}
rule SEKOIA_Apt_Unknown_Sessionmanageriis_Strings : FILE
{
	meta:
		description = "Detects the IIS SessionManager backdoor"
		author = "Sekoia.io"
		id = "7d55dd82-509f-444d-a1ba-6417b51f392f"
		date = "2022-07-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_unknown_sessionmanageriis_strings.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b1058b07c8e40431f8f3841b5ad49b4d6ead21a91d014f24c083f37eeacc5ac5"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Wokring OK"
		$ = "Delete File Success :"
		$ = "Delete File Error :"
		$ = "SM_SESSION="
		$ = "SM_SESSIONID"
		$ = "attachment; filename ="
		$ = "CHttpModule::"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize > 100KB and filesize < 400KB and 4 of them
}
rule SEKOIA_Apt_Mustangpanda_Payload : FILE
{
	meta:
		description = "Decryption routine of mustang panda payload"
		author = "Sekoia.io"
		id = "ce7ddf20-e13f-4b5f-8fff-4b1387b29568"
		date = "2022-12-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_mustangpanda_payload.yar#L1-L42"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "734d42aed4574de620773f1f2d08c6b1fc206efd1b576f0f3679edcc0b2ce91d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$chunk_1 = {
        89 74 24 ??
        B9 ?? ?? ?? ??
        8B 44 24 ??
        3D ?? ?? ?? ??
        B8 ?? ?? ?? ??
        0F 4C C1
        E9 ?? ?? ?? ??
        B8 ?? ?? ?? ??
        31 DB
        31 ED
        31 FF
        E9 ?? ?? ?? ??
        8B 44 24 ??
        B9 ?? ?? ?? ??
        3B 44 24 ??
        B8 ?? ?? ?? ??
        0F 42 C1
        E9 ?? ?? ?? ??
        88 5C 24 ??
        89 6C 24 ??
        89 7C 24 ??
        B9 ?? ?? ?? ??
        8B 44 24 ??
        3D ?? ?? ?? ??
        B8 ?? ?? ?? ??
        0F 4C C1
        }

	condition:
		filesize < 8MB and all of them
}
rule SEKOIA_Infostealer_Win_Bebra : FILE
{
	meta:
		description = "Find samples of Bebra Stealer based on specific strings"
		author = "Sekoia.io"
		id = "e84d04a7-1232-47e5-b797-ac8e56066796"
		date = "2023-02-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_bebra.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "7841746c54c53dbcafdf3f357c7a84b90fe3b089e07f30dea15ef6f7f15b0f00"
		logic_hash = "588fa3091f0dc565123c60d59479202d036e092499eca6204d420395ddc332f9"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "https://studio.youtube.com/youtubei/v1/att/esr?alt=json&key=" ascii
		$str02 = "https://www.youtube.com/getAccountSwitcher" ascii
		$str03 = "\"challenge\":\"" ascii
		$str04 = "\"botguardResponse\":\"" ascii
		$str05 = "\"continueUrl\":\"https://studio.youtube.com/reauth\"," ascii
		$str06 = "\"flow\":\"REAUTH_FLOW_YT_STUDIO_COLD_LOAD\"," ascii
		$str07 = "\"xguardClientStatus\":0" ascii
		$str08 = "SAPISIDHASH" ascii
		$str09 = "system32\\cmd.exe /C choice /C Y /N /D Y /T 0 &Del" ascii
		$str10 = "/new.php" ascii
		$str11 = "github.com/mattn/go-sqlite3" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 9 of them
}
rule SEKOIA_Malware_Sugargh0St_Strings : FILE
{
	meta:
		description = "Detects SugarGh0st based on strings"
		author = "Sekoia.io"
		id = "51930498-b04a-4f13-8d14-ee975a28126e"
		date = "2023-12-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/malware_sugargh0st_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b878b5d3b3f62952d79c0ea5811838f4e79302b85f25494e91dc730dec8e1d8d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "%sd.%s /c \"%s\"" wide
		$ = "[Num Lock]" wide
		$ = "#32770" wide
		$ = "]%s (%4d-%02d-%02d %02d:%02d:%02d)" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 100KB and all of them
}
rule SEKOIA_Infostealer_Win_Aurora : FILE
{
	meta:
		description = "Finds Aurora samples based on characteristic strings"
		author = "Sekoia.io"
		id = "22ae81b4-647f-4b46-9b2a-dd96e0615d65"
		date = "2022-11-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_aurora.yar#L1-L35"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "e88cbb012ffb65aa8a70b76163a834c0bc4615b0effc93945c6d915e33c04549"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str00 = "I'm a teapot" ascii
		$str01 = "wmic cpu get name" ascii
		$str02 = "wmic path win32_VideoController get" ascii
		$str03 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Time Zones" ascii
		$str04 = "Exodus\\exodus.wallet" ascii
		$str05 = "PaliWallet" ascii
		$str06 = "cookies.sqlite" ascii
		$str07 = "Startup\\Documents\\User Data" ascii
		$str08 = "atomic\\Local Storage\\leveldb" ascii
		$str09 = "com.liberty.jaxx\\IndexedDB" ascii
		$str10 = "Guarda\\Local Storage\\leveldb" ascii
		$str11 = "AppData\\Roaming\\Telegram Desktop\\tdata" ascii
		$str12 = "Ethereum\\keystore" ascii
		$str13 = "Coin98" ascii
		$str14 = ".bat.cmd.com.css.exe.gif.htm.jpg.mjs.pdf.png.svg.xml.zip" ascii
		$str15 = "type..eq.main.Grabber" ascii
		$str16 = "type..eq.main.Loader_A" ascii
		$str17 = "type..eq.net/http.socksUsernamePassword" ascii
		$str18 = "powershell" ascii
		$str19 = "start-process" ascii
		$str20 = "http/httpproxy" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 15 of them and filesize > 4MB
}
rule SEKOIA_Apt_Badmagic_Installpzz_Pshscript : FILE
{
	meta:
		description = "Detects BadMagic InstallPZZ powershell script"
		author = "Sekoia.io"
		id = "d01bc217-9e14-498b-a92a-17f6aedec269"
		date = "2023-05-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_badmagic_installpzz_pshscript.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "58256cffd1d5060769f304393c22b6488abe9515eb7df2a967ba2fed85a9ec9a"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "start-job -ScriptBlock $script;"
		$ = "Start-Sleep -Second 1;"
		$ = "Write-Output \"$url$j"
		$ = "Start-Sleep -Second 2;"

	condition:
		all of them and filesize < 1KB
}
rule SEKOIA_Implant_Any_Sliver_Not_Stripped : FILE
{
	meta:
		description = "Rule which detects non stripped Sliver PE/Dlls/ELFs/MAC-O."
		author = "Sekoia.io"
		id = "35543c7c-c39b-4f96-b37c-1d27736e40fc"
		date = "2021-11-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_any_sliver_not_stripped.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5240f3ea1fb421697eeb12eb17d0b31c036b53f39c3a590473d87065b5d28e3e"
		score = 75
		quality = 80
		tags = "FILE"
		modification_date = "2021-12-22"
		version = "1.1"
		classification = "TLP:CLEAR"

	strings:
		$a1 = "github.com/bishopfox/sliver/implant/sliver/"

	condition:
		( uint16be( 0 ) == 0x4d5a or uint32be( 0 ) == 0x7f454c46 or uint32be( 0 ) == 0xcffaedfe ) and filesize < 11MB and filesize > 8MB and #a1 > 200
}
rule SEKOIA_Apt_Lazarus_Vhd_Ransomware_Downloader : FILE
{
	meta:
		description = "Detects VHD ransomware downloader"
		author = "Sekoia.io"
		id = "edcc9df8-650c-437a-adb8-a671e8b75e64"
		date = "2022-11-28"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_lazarus_vhd_ransomware_downloader.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "042ab0029d170937af9b9ee6a8e499843532c84cf99faed3d2d47cb18a1500ac"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "rundll32.exe %s #1 %S" wide
		$ = "cmd /c timeout /t 10 & Del /f /q \"%s\" & attrib -s -h \"%s\" & rundll32 \"%s\" #1" wide
		$ = "cmd /c timeout /t 10 & rundll32 \"%s\" #1" wide
		$ = "curl -A cur1-agent -L %s -s -d da"
		$ = "curl -A cur1-agent -L %s -s -d dl"

	condition:
		filesize < 2MB and 3 of them
}

rule SEKOIA_Apt_Sofacy_Graphitemalware_Generic : FILE
{
	meta:
		description = "Detects APT28 graphite malware based on strings"
		author = "Sekoia.io"
		id = "6b51cfa3-4a7d-4c2a-9fd9-f129b8a18466"
		date = "2022-09-27"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_sofacy_graphitemalware_generic.yar#L3-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f4c994c36768bae6d6e3b5aeefb634e485ab7b483a693781f29d5ff44c71996f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Microsoft Enhanced RSA and AES Cryptographic Provider" wide
		$ = "Microsoft Enhanced RSA and AES Cryptographic Provider (Prototype)" wide
		$ = "%s %04d sp%1d.%1d %s"
		$ = "%s%c%s%c%s"
		$ = "InternetReadFile"
		$ = "ObtainUserAgentString"
		$ = "CryptImportKey"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 100KB and ( all of them or pe.imphash ( ) == "c56c322548250651361aef7dacf93eaf" )
}
rule SEKOIA_Implant_Win_Flagpro : FILE
{
	meta:
		description = "Detect the Flagpro malware used by Blacktech"
		author = "Sekoia.io"
		id = "08dd2de4-b359-424f-af04-7f294d519363"
		date = "2022-04-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_win_flagpro.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "eb1aba9924af474d6d890572a9bf72e0d1aa5dc31dd4cc34648195b0207ab4d6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "<BODY ID=CV20_LoaderDlg BGCOLOR=LIGHTGREY style=\"font-family:MS Shell Dlg;font-size:8\">" ascii
		$ = "<TABLE WIDTH=100% HEIGHT=100%>" ascii
		$ = "<TR WIDTH=100% HEIGHT=45%>" ascii
		$ = "<TD ALIGN=CENTER VALIGN=BOTTOM>" ascii
		$ = "TODO: Place controls here." ascii
		$ = "<TD ALIGN=RIGHT VALIGN=BOTTOM>" ascii
		$ = "<BUTTON STYLE=\"WIDTH:100\" ID=\"ButtonHelp\">Help</BUTTON>&nbsp;&nbsp;<BUTTON STYLE=\"WIDTH:100\" ID=\"ButtonOK\">OK</BUTTON>&nbsp;<BUTTON STYLE=\"WIDTH:100\" ID=\"ButtonCancel\">Cancel</BUTTON>" ascii
		$about_loader = /About V[0-9]+\.[0-9]+_Loader.../ wide
		$path = "f:\\dd\\vctools\\vc7libs\\ship\\atlmfc\\include\\" wide
		$regitry = "Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\" wide

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}

rule SEKOIA_Backdoor_Win_Kimsuky : FILE
{
	meta:
		description = "Detect the backdoors used by Kimsuky based on specific PE ressources"
		author = "Sekoia.io"
		id = "db927d1c-34cf-4501-a6ce-3e8ecdefc5a3"
		date = "2024-06-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_win_kimsuky.yar#L4-L38"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "000e2926f6e094d01c64ff972e958cd38590299e9128a766868088aa273599c7"
		hash = "cca1705d7a85fe45dce9faec5790d498427b3fa8e546d7d7b57f18a925fdfa5d"
		logic_hash = "ba40427f7e305a6e6cec6bb0165b49e6ce215ecf66fc2e05954c10e4d9acf9b0"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		uint16be( 0 ) == 0x4d5a and for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "3d570af85db2bb18265d80e7209a5c90f7cc82e0c868c0088a925df6f34e9066" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "3d570af85db2bb18265d80e7209a5c90f7cc82e0c868c0088a925df6f34e9066" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "ac9ed305c6dac749163db359736e7d92fca9173ff5c9e1f021d500b306e3c5ec" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "0ca965ccf7324b098da617909d38986c1e6aae3e12d9629975f1815ed4ed3907" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "25d79e59a6b625e5c22ccb55cc49373d38cc6f20cb75504b0df1bc0804bb1247" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "ce5619ffe04ec569bf2565e0964156378bda7c42eb646bedbac2191a5af7bebf" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "ce10e65f7bf105fc06005340f0a8eaea9b351f3750d2818c1cf2ca25a7f495be" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "5a9e2a392c530ab8b38ff917ae0f28496107f1bde94e89515931fd29a0bfb2e5" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "19f4f3a05b809d8e33bb0004f62899ca5f9eac7e4cdba68dfd5c0a6f2d71bec3" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "b9c208b9bada7bac4d5bfe53992f570e34e0b4d5cfa0862de9847ddf5630ab9a" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "3d570af85db2bb18265d80e7209a5c90f7cc82e0c868c0088a925df6f34e9066" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "ac9ed305c6dac749163db359736e7d92fca9173ff5c9e1f021d500b306e3c5ec" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "0ca965ccf7324b098da617909d38986c1e6aae3e12d9629975f1815ed4ed3907" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "25d79e59a6b625e5c22ccb55cc49373d38cc6f20cb75504b0df1bc0804bb1247" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "ce5619ffe04ec569bf2565e0964156378bda7c42eb646bedbac2191a5af7bebf" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "ce10e65f7bf105fc06005340f0a8eaea9b351f3750d2818c1cf2ca25a7f495be" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "5a9e2a392c530ab8b38ff917ae0f28496107f1bde94e89515931fd29a0bfb2e5" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "19f4f3a05b809d8e33bb0004f62899ca5f9eac7e4cdba68dfd5c0a6f2d71bec3" or hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "b9c208b9bada7bac4d5bfe53992f570e34e0b4d5cfa0862de9847ddf5630ab9a" )
}
rule SEKOIA_Merlin_Crossplatform : FILE
{
	meta:
		description = "Detects Merlin agent cross platform"
		author = "Sekoia.io"
		id = "c9c57f5e-26c3-43be-b2cf-10f5129d3be6"
		date = "2022-01-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/merlin_crossplatform.yar#L1-L23"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "975cc4fe0d89383188f9fd3c516d1e853dd6070d7703c0b5b5874dc1e7e6f32a"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = ".CRT" ascii
		$s2 = ".tls" ascii
		$s3 = "github.com/Ne0nd0g/merlin" ascii
		$s4 = "github.com/refraction-networking" ascii
		$s5 = "SendMerlinMessage" ascii
		$s6 = "ifconfigH9" ascii

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0x457f ) and all of them and filesize > 5MB and filesize < 15MB
}
rule SEKOIA_Tool_Dynamicwrapper_Strings : FILE
{
	meta:
		description = "Detects DynamicWrapperX"
		author = "Sekoia.io"
		id = "bbfad0a8-8b86-47c7-bf70-0a3f6859d64b"
		date = "2023-12-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_dynamicwrapper_strings.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "fad5fec74dc3efdd7fc67ef1c6373957df4ee564f3fe6333b924b236ea7458d9"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Software\\Classes\\DynamicWrapperX" ascii
		$ = "DllRegisterServer" ascii
		$ = "GoLink, GoAsm" ascii

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 100KB and all of them
}
rule SEKOIA_Apt_Susp_Lazarus_Dangerous_Password : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "726c8b92-7fbe-40f8-917a-cabd206028da"
		date = "2023-09-12"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_susp_lazarus_dangerous_password.yar#L1-L15"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "2b159266bd6bba20ffaa627dac840840eaaad98e7962f48bbae428e687155b3d"
		score = 65
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = ".jpeg" wide
		$ = "mshta"

	condition:
		uint32be( 0 ) == 0x4c000000 and all of them and filesize < 5KB
}

rule SEKOIA_Tool_Impersonate_Strings : FILE
{
	meta:
		description = "Detects Impersonate"
		author = "Sekoia.io"
		id = "2ab345a2-9366-4673-b398-a59ba6954af5"
		date = "2024-07-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_impersonate_strings.yar#L3-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "63c46a2d97d0a8360351b8906665186c5ad2dcaa6f2edba6da7bf4de2ce00241"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[*] Listing available tokens"
		$ = "[ID: %2d][SESSION: %d][INTEGRITY: %-6ws][%-18ws][%-22ws] User: %ws"
		$ = "[*] Impersonating %ws"
		$ = "[!] Impersonation failed error: %d"
		$ = "[*] Adding user %ls on %ls"
		$ = "[!] Add user failed with error: %d"
		$ = "[*] Adding user %ws to domain group %ws"
		$ = "[!] Add user in domain %ws failed with error: %d"
		$ = "[!] Couldn't change token session id (error: %d)"

	condition:
		uint16be( 0 ) == 0x4d5a and 3 of them or pe.imphash ( ) == "e14ce763114276674e22b7b8b637bd4b"
}
rule SEKOIA_Xworm_Dotnet_Injector
{
	meta:
		description = ".NET injector used by XWorm TA"
		author = "Sekoia.io"
		id = "50581a9d-afc3-43da-9e34-3a553cbd01b4"
		date = "2022-12-02"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/xworm_dotnet_injector.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "4777edacf4719e602ae1fb7204ea97cd594277faa1c2b7ad430066ad82b40768"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$first_payload = "jBGIcSr2fKhj1ZT2YNLBTcYYeAw/vWUT98dCA/H6hpI+dY+lkoSe1ATx7XEIXKtAdTSwl1PKhNROoxstXsnsHTZbS2ikRLv6lmHd5v09DltsPeXIOA789wZC8qR1OScJFohGxuWQSQ8K2TAFUQAntIFdX+Om1QZUARdDnb4f+P8VFucU9avWD75yK1IcTDDDEYwvm/rwUYTqWitcrfIY+aFcgQwyvEzkN7Pbsah4Kts+XmK0C3TzlnDd2mz6TdsPphGbBxcbBdZGMTyzunZUEKRYea7xM6u+az9v7m6a1G6vhsSqz4C/nleDmzL2dIVnVR6Ni6+0hlExcP" wide
		$rijndael_key1 = { e5 a0 b1 e8 89 be e8 8e 8e e4 bb a3 e5 ba b5 e9 85 8d e7 89 b9 e6 b0 8f e5 85 8b e9 9b 99 e8 89 be e5 8b 92 e6 8b 89 e6 a1 83 e9 ad 9a e6 88 91 e6 96 af e6 a1 83 e5 ba 95 e5 be b7 }
		$rijndael_key2 = { e7 9b 9f e7 91 aa e6 a1 83 e9 87 91 e5 90 89 e9 97 95 e5 a0 b1 e9 9b 99 e9 97 95 e5 96 ac e5 ba 95 e5 a0 b1 e5 be b7 e6 8b 89 e5 92 8c e7 a0 b4 e7 88 be e9 a6 ac e6 88 91 e5 8a a0 }
		$rijndael_key3 = { e6 9b b2 e6 b0 8f e5 ba b5 e5 a3 ab e9 97 95 e5 be b7 e6 96 af e8 9b 8b }
		$s1 = "fullofdick"
		$s2 = "holdmeback"
		$s3 = "C:\\Windows\\Microsoft.NET\\Framework\\v4.0.30319\\RegAsm.exe" wide

	condition:
		($first_payload and all of ( $rijndael_key* ) ) or 2 of ( $s* )
}
rule SEKOIA_Hacktool_Win_Processhacker : FILE
{
	meta:
		description = "Detect ProcessHacker hacktool"
		author = "Sekoia.io"
		id = "1dffe8c9-2ab7-4265-965e-8673b80f17d5"
		date = "2022-09-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_win_processhacker.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "cfcfaa7f3afc8b82ce0188d9ead63746a7effd40acb6ad504f8d70a45d8476d5"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str0 = "Unable to uninstall KProcessHacker" wide
		$str1 = "Process Hacker's settings file is corrupt. Do you want to reset it?" wide
		$str2 = "Process Hacker uses the following components:" wide

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule SEKOIA_Apt_Suspected_Sandworm_Sdelete_Wiper : FILE
{
	meta:
		description = "Detects Sdelete wiper"
		author = "Sekoia.io"
		id = "c1419b11-33e5-4280-b92a-039719cb17d3"
		date = "2023-10-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_suspected_sandworm_sdelete_wiper.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "094b946b89cfb475b8692f88af73fa8768a933139e0df9d6e7d7aa8614d3ab14"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = ".exe -accepteula -r -s -q" wide
		$s2 = "sdelete [-p passes] [-r]" wide
		$s3 = "!This program cannot be run in DOS mode."

	condition:
		uint16be( 0 ) == 0x4d5a and $s1 and $s2 and #s3 == 2 and filesize < 500KB
}
rule SEKOIA_Infostealer_Win_Acrstealer_Str : FILE
{
	meta:
		description = "Finds ACR Stealer standalone samples based on specific strings."
		author = "Sekoia.io"
		id = "63b4d6ff-0cab-44ec-9d53-bb2612371a48"
		date = "2024-04-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_acrstealer_str.yar#L1-L29"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "53d313857577b39b51a3e396c078d39a8b8ab803295b689357c3e8ea94cac9f7"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "ref.txt" ascii
		$str02 = "Wininet.dll" ascii
		$str03 = "Content-Type: application/octet-stream; boundary=----" ascii
		$str04 = "POST" ascii
		$str05 = "os_c" ascii fullword
		$str06 = "en_k" ascii fullword
		$str07 = "MyApp/1.0" ascii
		$str08 = "/Up/b" ascii
		$str09 = "Hello, World!" ascii
		$str10 = "/ujs/" ascii
		$str11 = "/Up/" ascii fullword
		$str12 = "ostr" ascii fullword
		$str13 = "brCH" ascii fullword
		$str14 = "brGk" ascii fullword
		$str15 = "https://steamcommunity.com/profiles/" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 10 of them
}
rule SEKOIA_Tool_Soaphound_Strings : FILE
{
	meta:
		description = "Detects SOAPHound based on strings"
		author = "Sekoia.io"
		id = "adf48506-f07d-445a-83cc-0aed3b6b55eb"
		date = "2024-11-12"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_soaphound_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "b2a953590d75213388473fb51e6b5f2f"
		logic_hash = "14ff92230d0999a39a6e1042f5c42b5ae275d90ece3d74727e5da44c569a93eb"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Output files generated in" wide
		$ = "(&(cn=*)(!(cn=a*))(!(cn=b*))" wide
		$ = "unicodePassword" wide
		$ = "net.tcp://localhost:9389/ActiveDirectoryWebServices/" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 2MB and all of them
}
rule SEKOIA_Tool_Koblas_Server_Strings : FILE
{
	meta:
		description = "Detects Koblas server"
		author = "Sekoia.io"
		id = "ebd891da-69dd-474c-9e08-63d0b4cc654e"
		date = "2024-05-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_koblas_server_strings.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "590f3f71564c347be7b3b2a583606c3854744d0023cde464374cd7b61ec5a2d7"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "sent {sent} bytes and received {received} bytes" wide ascii
		$ = "connection denied" ascii
		$ = "loaded {} users" ascii
		$ = "listening on {}:{} for incoming connections" ascii

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and 3 of them
}

rule SEKOIA_Backoor_Win_Gobear
{
	meta:
		description = "Detect the GoBear backdoor used by Kimsuky"
		author = "Sekoia.io"
		id = "f922bf1b-652e-4a2f-91e9-76ecd2e3bf6a"
		date = "2024-02-13"
		modified = "2024-12-19"
		reference = "https://medium.com/s2wblog/kimsuky-disguised-as-a-korean-company-signed-with-a-valid-certificate-to-distribute-troll-stealer-cfa5d54314e2"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backoor_win_gobear.yar#L4-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8ca2699058ded62cbf4b78040985a4e5ebce0a1ff94034206c81a4c8e91f479b"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	condition:
		for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "668031f53390dc749971888029911c12d4171534f77c17a962e698bf121d0e20" )
}
rule SEKOIA_Apt_Konni : FILE
{
	meta:
		description = "Rule based on structure offsets and file extension"
		author = "Sekoia.io"
		id = "6a20c492-e932-41bd-ac4a-01d35bfb0c49"
		date = "2022-09-12"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_konni.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "8f178421fd0968f4ce809054022579c7fc8dede5f6514e89966d13acb83d75d9"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ext_1 = ".zip" wide ascii fullword
		$ext_2 = ".cab" wide ascii fullword
		$ext_3 = ".rar" wide ascii fullword
		$ext_4 = ".ini" wide ascii fullword
		$ext_5 = ".dat" wide ascii fullword
		$offset_structure_1 = { 8d ?? 08 02 00 00 }
		$offset_structure_2 = { 8d ?? 10 04 00 00 }
		$offset_structure_3 = { 8d ?? 18 06 00 00 }
		$url = "%s/dn.php?name=%s&prefix=%s" wide

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 3MB and 3 of ( $ext_* ) and all of ( $offset_structure_* ) and $url
}
rule SEKOIA_Ransomware_Win_Agenda : FILE
{
	meta:
		description = "Finds Agenda ransomware (aka Qilin) samples based on characteristic strings"
		author = "Sekoia.io"
		id = "b0ea8e69-8f29-452f-95f7-67ee0e545b66"
		date = "2022-12-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_win_agenda.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "7e315f639c4d785639bf7ed3bd805551366b4da10a664a42bf801c54c6f7bd2d"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str00 = "\"note\": \"-- Qilin" ascii
		$str01 = "README-RECOVER-.txt" ascii
		$str02 = "\"file_black_list\": [" ascii
		$str03 = "\"file_pattern_black_list\": [" ascii
		$str04 = "Encrypted files have new extension." ascii
		$str05 = "We have downloaded compromising and sensitive data from you system/network" ascii
		$str06 = "Employees personal dataCVsDLSSN." ascii
		$str07 = "ueegj65kwr3v3sjhli73gjtmfnh2uqlte3vyg2kkyqq7cja2yx2ptaad.onion" ascii
		$str08 = "cmdvssadmin.exe delete shadows /all /quiet" ascii
		$str09 = "[WARNING] Removing shadows failed." ascii
		$str10 = "[INFO] Shadow copies removed" ascii
		$str11 = "[WARNING] net sahre enum failed with:" ascii

	condition:
		uint16( 0 ) == 0x5A4D and 2 of them
}
rule SEKOIA_Generic_Python_Reverse_Shell : FILE
{
	meta:
		description = "Detects simple reverse shell written in Python"
		author = "Sekoia.io"
		id = "ab25f8db-e39d-4aa4-b431-cf5cd2e038e5"
		date = "2023-12-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/generic_python_reverse_shell.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "ced9923ef8018796545d93d9ac8ba3138dd7d4e79db742eb3babcd94c8d3c304"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "import pty"
		$ = "lhost ="
		$ = "os.dup2(s.fileno(),0)"
		$ = "os.putenv(\"HISTFILE\",'/dev/null')"

	condition:
		filesize < 1KB and all of them
}
rule SEKOIA_Infostealer_Win_Ginzostealer_Str : FILE
{
	meta:
		description = "Finds samples of the Ginzo Stealer"
		author = "Sekoia.io"
		id = "ef87e94b-9c53-44b4-b8a1-87d371a6d2cb"
		date = "2022-04-21"
		modified = "2024-12-19"
		reference = "https://blog.talosintelligence.com/2022/04/haskers-gang-zingostealer.html"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_ginzostealer_str.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b1c811a13cf0f632ac839b6a6de050fc59ffe3ed0704545feff02e13521ea53f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str0 = "Ginzo.pdb" ascii
		$str1 = "Ginzo.exe" wide
		$str2 = "SELECT creation_utc,top_frame_site_key,host_key,name,value,encrypted_value,path,expires_utc,is_secure,is_httponly,last_access_utc,has_expires,is_persistent,priority,samesite,source_scheme,source_port,is_same_party FROM cookies" wide
		$str3 = "SELECT origin_url,action_url,username_element,username_value,password_element,password_value,submit_element,signon_realm,date_created,blacklisted_by_user,scheme,password_type,times_used,form_data,display_name,icon_url,federation_url,skip_zero_click,generation_upload_status,possible_username_pairs,id,date_last_used,moving_blocked_for,date_password_modified FROM logins" wide
		$str4 = "SELECT id,originAttributes,name,value,host,path,expiry,lastAccessed,creationTime,isSecure,isHttpOnly,inBrowserElement,sameSite,rawSameSite,schemeMap FROM moz_cookies" wide

	condition:
		uint16( 0 ) == 0x5A4D and 4 of them
}
rule SEKOIA_Tool_Lsass_Dump_Strings : FILE
{
	meta:
		description = "Detects Lsass dump based on strings"
		author = "Sekoia.io"
		id = "bf024dc6-a1c8-4c3f-9bf8-8d246c129639"
		date = "2024-09-09"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_lsass_dump_strings.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "f4540f42902c068b9290239729c45324"
		logic_hash = "7dfee9368297b3fd6c7f247a65b5344da0f5438c2145c5d53af48983d0d9a745"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[SUCCESS] Successfully dumped core LSASS information for PID:"
		$ = "[SUCCESS] All data dumped to "
		$ = "[ERROR] Unable to dump process"

	condition:
		uint16be( 0 ) == 0x4d5a and 3 of them
}
rule SEKOIA_Nomercy : FILE
{
	meta:
		description = "Detect NoMercy sample version up to 1.1.0"
		author = "Sekoia.io"
		id = "2591f74b-8ab8-45ef-ba64-62a93df305c1"
		date = "2022-07-11"
		modified = "2024-12-19"
		reference = "https://blog.cyble.com/2022/07/07/nomercy-stealer-adding-new-features/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/nomercy.yar#L1-L61"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "9ecc76d4cda47a93681ddbb67b642c2e1f303ab834160ab94b79b47381e23a65"
		hash = "557acce8b787aba87c8eeb939438b52c5ca953f28ad680a7faeb2b3046d3fda0"
		logic_hash = "175bc58f1b34bb60f6cacc15747e944cbbdd58fe287ff46abed969eaa39870db"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$debug1 = "Posted uid and version" wide ascii
		$debug2 = "Posted cli info to server" wide ascii
		$debug3 = "Posted other info to server" wide ascii
		$debug4 = "Sending screenshot..." wide ascii
		$debug5 = "Sent screenshot" wide ascii
		$debug6 = "Listening to Microphone..." wide ascii
		$debug7 = "Collecting other info..." wide ascii
		$url1 = "/a?uid=" wide ascii
		$url2 = "/c?uid=" wide ascii
		$url3 = "/d?uid=" wide ascii
		$url4 = "/e?uid=" wide ascii
		$url5 = "/b?sysinfoother=" wide ascii
		$url6 = "/b?sysinfocli=" wide ascii
		$info1 = "PUBLIC IP:" wide ascii
		$info2 = "HWID:" wide ascii
		$info3 = "RAM:" wide ascii
		$info4 = "GPU:" wide ascii
		$info5 = "MEDIA ACCESS CONTROL ADDRESS:" wide ascii
		$info6 = "PRIVATE IP:" wide ascii
		$info7 = "OS VERSION:" wide ascii
		$info8 = "ANTIVIRUS:" wide ascii
		$info9 = "KEYBOARD LANGUAGE:" wide ascii
		$info10 = "CLIPBOARD: {0}{1}{2}" wide ascii
		$info11 = "RUNNING PROCESSES:" wide ascii
		$info12 = "WINDOW TITLE:" wide ascii
		$cmd1 = "/c whoami /all" wide ascii
		$cmd2 = "/c whoami" wide ascii
		$cmd3 = "/c arp -a" wide ascii
		$cmd4 = "/c ipconfig /all" wide ascii
		$cmd5 = "/c net view /all" wide ascii
		$cmd6 = "/c net share" wide ascii
		$cmd7 = "/c route print" wide ascii
		$cmd8 = "/c netstat -nao" wide ascii
		$cmd9 = "/c net localgroup" wide ascii
		$cmd10 = "/c systeminfo" wide ascii
		$inv1 = "http://api.ipify.org" wide ascii
		$inv2 = "NoMercy" wide ascii

	condition:
		uint16be( 0 ) == 0x4d5a and 3 of ( $debug* ) and 8 of ( $info* ) and 2 of ( $url* ) and 6 of ( $cmd* ) and 1 of ( $inv* ) and filesize > 700KB and filesize < 3000KB
}
rule SEKOIA_Apt_Muddywater_Powgoop_Decode_Loop : FILE
{
	meta:
		description = "Detects the loop used in PowGoop and its loader"
		author = "Sekoia.io"
		id = "644ed1c4-e0e1-496e-9efc-7d9e15565f7b"
		date = "2022-01-13"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_muddywater_powgoop_decode_loop.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "1d60f53014fb1934a85a573856244431c8f565c2f024511991817e6235566815"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "System.Collections.Generic.List[System.Object]" ascii wide
		$s2 = "$d.Add($in[$i]);" ascii wide
		$s3 = "[System.Convert]::FromBase64String(" ascii wide

	condition:
		filesize < 1MB and $s2 in ( @s1 .. @s1 + 400 ) and $s3 in ( @s1 .. @s1 + 400 )
}
rule SEKOIA_Backdoor_Win_Foresttiger : FILE
{
	meta:
		description = "Detect Lazarus' malware ForestTiger"
		author = "Sekoia.io"
		id = "d3128da2-a86d-4db8-9b75-2f3048831c7e"
		date = "2023-10-24"
		modified = "2024-12-19"
		reference = "https://www.microsoft.com/en-us/security/blog/2023/10/18/multiple-north-korean-threat-actors-exploiting-the-teamcity-cve-2023-42793-vulnerability/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_win_foresttiger.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "e06f29dccfe90ae80812c2357171b5c48fba189ae103d28e972067b107e58795"
		hash = "0be1908566efb9d23a98797884f2827de040e4cedb642b60ed66e208715ed4aa"
		logic_hash = "401adaad1597c017c976c5b0b8f67851469c95758779b7691ebb037d0dda9f38"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36 Edg/107.0.1418.42"
		$ = "biwbih="
		$ = "rlzbiw="
		$ = "whoami EnDePriv Erro" wide

	condition:
		uint16be( 0 ) == 0x4d5a and all of them
}
rule SEKOIA_Apt_Redhotel_Maliciouslnk_Strings : FILE
{
	meta:
		description = "Detects RedHotel's malicious LNKs"
		author = "Sekoia.io"
		id = "df2f0002-7921-4378-a936-ea0de5fbfa5a"
		date = "2024-09-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_redhotel_maliciouslnk_strings.yar#L1-L25"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "8e2c17040ec78cbcdc07bb2cf9dd7e01"
		hash = "dc613a519e515ca817fdfb88f81fc9d7"
		hash = "6f7d85c196c277a6a619f6d94b8f69b9"
		hash = "b04d484d1e1d793b04af2a5fb88a8a57"
		logic_hash = "c1d64b3eca5961d7eaab82a6934299642a70301ef791493a371ae5a29376225f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "desktop-" ascii
		$ = ".\\1.docx" wide
		$ = ".\\1.pdf" wide
		$ = ".\\1.doc" wide
		$ = ".\\1.ppt" wide
		$ = ".\\1.pptx" wide
		$ = "MACOS" wide

	condition:
		uint32be( 0 ) == 0x4c000000 and 3 of them
}
rule SEKOIA_Malware_Tinyshell_Strings : FILE
{
	meta:
		description = "Detects TinyShell based on strings"
		author = "Sekoia.io"
		id = "51fe9986-cb33-4802-bb8d-fe3d4cdfdcc8"
		date = "2024-09-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/malware_tinyshell_strings.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "fffc89ebbe6ea37072077996e27f86dd"
		hash = "59a97d4fbd3a54e991dc7e1f0451acf5"
		hash = "d7ee59eab7f703bfaf1002a39b05c7b9"
		hash = "3f2dfe47d4563919d889132b2759fd9c"
		logic_hash = "18d10e7e6f0ba8a9ea7fa8446a930f84ce5eb2f3a022ce3dc62bc3f8fd5699e1"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "_tsh_get_file"
		$ = "_tsh_put_file"
		$ = "_tsh_runshell"
		$ = "Authentication failed."
		$ = "pel_send_msg"
		$ = "exec bash --login"

	condition:
		3 of them and filesize < 150KB
}
rule SEKOIA_Loader_Amadey_Standalone_May23 : FILE
{
	meta:
		description = "Finds standalone samples of Amadey based on characteristic strings"
		author = "Sekoia.io"
		id = "5013586c-5ac3-4c1a-a82e-edce4889eedc"
		date = "2023-05-17"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/loader_amadey_standalone_may23.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "40d2d7a52066ca4e1a65c82ebfa882a77616a1c68f1d315946ab14467787d468"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "\\Amadey\\Release\\Amadey.pdb" ascii
		$hex01 = { 6E 74 64 6C 6C 2E 64 6C  6C 00 00 00 72 75 6E 61 73 }

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule SEKOIA_Apt_Tealkurma_Snappytcp_Strings : FILE
{
	meta:
		description = "Detects TealKurma SnappyTCP shell script"
		author = "Sekoia.io"
		id = "6bbee6d6-f490-4550-bd61-a643f93a8788"
		date = "2023-12-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_tealkurma_snappytcp_strings.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "b91adef3332850d952cace104fc05e1b09e6175a27ae991905defc46de608e88"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "#!/bin/bash" ascii
		$s2 = "2>&1>/dev/null&" ascii
		$s3 = "PATH=$PATH:$PWD;" ascii

	condition:
		$s1 at 0 and $s2 at filesize -16 and $s3 and filesize < 300
}
rule SEKOIA_Trojan_Win_Grandoreiro : FILE
{
	meta:
		description = "Finds Grandorerio samples based on the specific strings"
		author = "Sekoia.io"
		id = "e48c86a1-e34f-4945-817a-9c85198a77bb"
		date = "2022-08-24"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/trojan_win_grandoreiro.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "7424478b0cdfe922c2f98bf42e505f22fb0700cfeb54912630ce404c59b05c5e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$mut = "ZTP@11" wide
		$reg01 = "Software\\Embarcadero\\Locales" wide
		$reg02 = "Software\\CodeGear\\Locales" wide
		$reg03 = "Software\\Borland\\Locales" wide
		$reg04 = "Software\\Borland\\Delphi\\Locale" wide
		$reg05 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\FontSubstitutes" wide
		$str01 = "SELECT * FROM AntiVirusProduct" wide
		$str02 = "GetTickCount64" wide
		$str03 = "C:\\Program Files (x86)\\Embarcadero\\Studio\\20.0\\lib\\Clever Internet Suite" wide
		$str04 = "{43826D1E-E718-42EE-BC55-A1E261C37BFE}" wide

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}

rule SEKOIA_Infostealer_Win_Irontiger_Chrome_Stealer : FILE
{
	meta:
		description = "Detect the chrome_stealer malware"
		author = "Sekoia.io"
		id = "8c5c3ed0-e1ea-4079-b330-ace8724bff2a"
		date = "2023-03-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_irontiger_chrome_stealer.yar#L3-L32"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "dfddebf9623661508e993541106d4dcbb2270b311b2902567bd309810aff58dd"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "passwords.txt"
		$ = "CryptUnprotectData: 0x%08x"
		$ = "cookies.txt"
		$ = "decrypt to %s"
		$ = ".\\chromedb_tmp" wide ascii
		$ = "SELECT ORIGIN_URL,USERNAME_VALUE,PASSWORD_VALUE FROM LOGINS;"
		$ = "decrypt successful!"
		$ = "url: %s"
		$ = "user: %s"
		$ = "pass: %s"
		$ = "aes key:"
		$ = "\\Google\\Chrome\\User Data\\Default\\Login Data" wide
		$ = "password file %s" wide
		$ = "cookies file %s" wide
		$ = "keyfile: %s" wide

	condition:
		( uint16( 0 ) == 0x5A4D and all of them ) or pe.imphash ( ) == "e862f5a6671f9dbd6f53d3d557e568f0"
}
rule SEKOIA_Apt_Kimsuky_Sharpext_Compromised_Securepreferences
{
	meta:
		description = "Detects compromised Chrome SecurePreferences file"
		author = "Sekoia.io"
		id = "aeda5d15-82e1-4ffc-8252-1eb4fc78d024"
		date = "2022-07-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_kimsuky_sharpext_compromised_securepreferences.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "662358fdb4c4cfa9984d06e391ade52e1c7a3d7b78724aea4fb0d6035fe2e7b2"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "\"devtools\", \"tabs\", \"webNavigation\", \"webRequest\", \"webRequestBlocking\""
		$ = "AppData\\\\Roaming"
		$ = "https://*/*"

	condition:
		all of them
}
rule SEKOIA_Apt_Muddywater_Muddyc2Go_Dll_Launcher_Strings : FILE
{
	meta:
		description = "Detects MuddyC2Go DLL launcher"
		author = "Sekoia.io"
		id = "59756195-d842-4038-8fbf-43d26f4353bc"
		date = "2024-03-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_muddywater_muddyc2go_dll_launcher_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "1a0827082d4b517b643c86ee678eaa53f85f1b33ad409a23c50164c3909fdaca"
		logic_hash = "b91653e313258ebd2073a398d0467800056ac94adab02c3a83aa8a379710e4e6"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "-Method GET -ErrorAction Stop;Write-Output $response.Content;iex $response.Content;"
		$ = "GetCurrentProcess"
		$ = "TerminateProcess"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 50KB and all of them
}
rule SEKOIA_Apt_Emissarypanda_Web_Auto_Attack_Tool : FILE
{
	meta:
		description = "Detect LuckyMouse's Web auto attack tool"
		author = "Sekoia.io"
		id = "c93eb792-a443-4c9a-8fcb-6015cc69f9b3"
		date = "2022-08-03"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_emissarypanda_web_auto_attack_tool.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "bc55758367ba0a6b5cf963bcb51b7770b2c7b1cf43b0b79e663b4110f6a7bba8"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "[192.168.1.1/24|192.168.1.1|192.168.1|@host.txt]" ascii
		$ = "80,s443,8080,s8443,8000-8010" ascii
		$ = "exploit When find module vul" ascii
		$ = "<title>\\s*(.*?)\\s*</title>" ascii
		$ = "<meta.+?charset=[^\\w]?([-\\w]+)" ascii
		$ = "%s is not existed" ascii
		$ = "%-15s %4d Open" wide

	condition:
		uint16be( 0 ) == 0x4d5a and 4 of them and filesize < 500KB
}
rule SEKOIA_Ransomware_Win_Fonix : FILE
{
	meta:
		description = "Detect the Fonix / XINOF ransomware by spotting its specific debug path"
		author = "Sekoia.io"
		id = "b28467d5-69a0-4a8b-8938-8fdac2ae8d19"
		date = "2021-10-07"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/ransomware_win_fonix.yar#L1-L16"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "2085fae62c07f63723a417566c204b0a9942de35ed80272d1486dc2c96ca0037"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "Ransomware\\Fonix" ascii
		$s2 = "Release\\Fonix.pdb" ascii

	condition:
		uint16( 0 ) == 0x5A4D and all of them
}
rule SEKOIA_Apt_Apt10_Hui_Loader : FILE
{
	meta:
		description = "Specific string for HUI Loader"
		author = "Sekoia.io"
		id = "97d17052-80d0-4f8e-8b3a-2e0d622522a9"
		date = "2022-07-04"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt10_hui_loader.yar#L1-L17"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "33df202599c6bceff2cf76acdc0096f7167acb69c541b3cfe4cdc34edc174005"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "HUIHWASDIHWEIUDHDSFSFEFWEFEWFDSGEFERWGWEEFWFWEWD" wide fullword

	condition:
		( uint16be( 0 ) == 0x4d5a ) and filesize > 30KB and filesize < 100KB and 1 of them
}
rule SEKOIA_Apt_Kimsuky_Sharptongue_Strings : FILE
{
	meta:
		description = "Detects SharpTongue variants."
		author = "Sekoia.io"
		id = "56027edb-4e6e-40ec-a1b9-36c52b0dd3ec"
		date = "2022-07-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_kimsuky_sharptongue_strings.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a7a9045485f6e713a8ae1bc87cd1296d64905b18e5d13d6e2b9a95328181af54"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "Post0.Open" ascii wide
		$s2 = ".php?op=" ascii wide
		$s3 = "s=s&Mid(c,ix*d+jx+1,1)" ascii wide
		$s4 = "curl -o " ascii wide

	condition:
		$s2 in ( @s1 .. @s1 + 200 ) or $s2 in ( @s4 .. @s4 + 200 ) or $s3 and filesize < 500KB
}
rule SEKOIA_Apt_Sandworm_Olympicdestroyer : FILE
{
	meta:
		description = "Detects OlympicDestroyer malware"
		author = "Sekoia.io"
		id = "6820eb32-fea2-4a00-a5a2-672ba09f8206"
		date = "2022-04-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_sandworm_olympicdestroyer.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "a68a96ab036e69a32e173b2d2fa6a81ab872032f89bfdfc3cd4446305a33921b"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "cmd.exe /c (ping 0.0.0.0 > nul)" wide
		$ = "if exist %programdata%\\evtchk.txt" wide
		$ = "\\\\.\\pipe\\%ls" wide
		$ = "%ProgramData%\\%COMPUTERNAME%.exe" wide
		$ = "(exit 5) else ( type nul >" wide
		$ = "Select * From Win32_ProcessStopTrace" nocase

	condition:
		uint16be( 0 ) == 0x4d5a and 3 of them
}
rule SEKOIA_Rat_Win_Asyncrat : FILE
{
	meta:
		description = "Detect AsyncRAT based on specific strings"
		author = "Sekoia.io"
		id = "d698e4a1-77ff-4cd7-acb3-27fb16168ceb"
		date = "2023-01-25"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_asyncrat.yar#L1-L26"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5e35b034ba1761fae780429be377b70ae8ce62273670042ff067c38ed8bb5a9e"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "get_ActivatePong" ascii
		$str02 = "get_SslClient" ascii
		$str03 = "get_TcpClient" ascii
		$str04 = "get_SendSync" ascii
		$str05 = "get_IsConnected" ascii
		$str06 = "set_UseShellExecute" ascii
		$str07 = "Pastebin" wide
		$str08 = "Select * from AntivirusProduct" wide
		$str09 = "Stub.exe" wide
		$str10 = "timeout 3 > NUL" wide
		$str11 = "/c schtasks /create /f /sc onlogon /rl highest /tn " wide
		$str12 = "\\nuR\\noisreVtnerruC\\swodniW\\tfosorciM\\erawtfoS" wide

	condition:
		uint16( 0 ) == 0x5A4D and 9 of them
}
rule SEKOIA_Infostealer_Win_Enigma_Stealer_Module : FILE
{
	meta:
		description = "Find stealer module of Enigma Stealer based on specific strings"
		author = "Sekoia.io"
		id = "664fe8de-b406-4d63-9a4b-1c350b444f02"
		date = "2023-01-30"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_enigma_stealer_module.yar#L1-L28"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "4d2fb518c9e23c5c70e70095ba3b63580cafc4b03f7e6dce2931c54895f13b2c"
		logic_hash = "0a6615d65867a160e1c87fbcfe30090d44d7f5c25b3a904f8719be7b385b14bb"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$eni01 = "enigma.common" nocase ascii wide
		$eni02 = "--ENIGMA STEALER--" wide
		$str01 = "SELECT * FROM Win32_PnPEntity WHERE (PNPClass = 'Image' OR PNPClass = 'Camera')" wide
		$str02 = "/C chcp 65001 && netsh wlan show profile | findstr All" wide
		$str03 = "/C chcp 65001 && netsh wlan show networks mode=bssid" wide
		$str04 = "[Open google maps]" wide
		$str05 = "Stealerium.Target." ascii
		$str06 = "--- ClipperBCH ---" wide
		$str07 = "//setting[@name='Username']/value" wide
		$str08 = "Stealer >> Failed recursive remove directory with passwords" wide
		$str09 = "[a-zA-Z0-9]{24}\\.[a-zA-Z0-9]{6}\\.[a-zA-Z0-9_\\-]{27}|mfa\\.[a-zA-Z0-9_\\-]{84}" wide
		$str10 = "^(5018|5020|5038|6304|6759|6761|6763)[0-9]{8,15}$" wide

	condition:
		uint16( 0 ) == 0x5A4D and 1 of ( $eni* ) and 4 of ( $str* )
}
rule SEKOIA_Infostealer_Win_Agrat : FILE
{
	meta:
		description = "No description has been set in the source file - SEKOIA"
		author = "Sekoia.io"
		id = "472effe8-5044-4ca1-88e0-3e19d445b9d1"
		date = "2022-06-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_agrat.yar#L1-L27"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5b02880dbc75d9e4d95ec55c8e8630a47198ee4cc25e3ff79c93e9fe634fadca"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str00 = "Vault.txt" wide
		$str01 = "Credman.txt" wide
		$str02 = "[Networks] {0}" wide
		$str03 = "[Screenshot] {0}" wide
		$str04 = "[Twitch] {0}" wide
		$str05 = "Servers.txt" wide
		$str06 = "[WindscribeVPN] {0}" wide
		$str07 = "[{0}] Thread finished!" wide
		$str08 = "[ERROR] Unable to enumerate vaults. Error (0x" wide
		$str09 = "snowflake-ssh" wide
		$str10 = "//setting[@name='Password']/value" wide
		$str11 = "MakeScreenshot" ascii
		$sys = "System.Collections.Generic.IEnumerator<Stealer." ascii

	condition:
		uint16( 0 ) == 0x5A4D and all of them and #sys > 10
}
rule SEKOIA_Apt_3Cx_Payload_Stealer : FILE
{
	meta:
		description = "Detects stealer used in 3CX campaign"
		author = "Sekoia.io"
		id = "1ca0605d-101f-4d1d-a476-9dfd93e74b4c"
		date = "2023-03-31"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_3cx_payload_stealer.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "17630ab86a3da3408e29765c0c30f14c76b870b88fea634b998392fe5d46cfa2"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = "******************************** %s ******************************" wide
		$s2 = "\\3CXDesktopApp\\config.json" wide
		$s3 = "{\"HostName\": \"%s\", \"DomainName\": \"%s\", \"OsVersion\":" wide
		$s4 = "%s.old" wide

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize < 8MB and all of them
}
rule SEKOIA_Suspicious_Users_Dev : FILE
{
	meta:
		description = "Nirscord stealer"
		author = "Sekoia.io"
		id = "9e8af456-6f84-4922-a262-20b8f5c8a1eb"
		date = "2022-12-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/suspicious_users_dev.yar#L1-L19"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "6084b319efb7b4137517c63dd2ed1023a4b25513b7ac50e95154bbac0fea0af7"
		score = 65
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$user1 = "\\Users\\raghus1\\" ascii
		$user2 = "\\Users\\drill\\" ascii
		$key = {58 69 b3 5f b3 87 74 f6 65 eb 96 e7 6f 4d 16 83 }

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 6MB and 1 of ( $user* ) and $key
}
rule SEKOIA_Apt_Backdoordiplomaty_Custommerlinagent_Strings : FILE
{
	meta:
		description = "Detects custom variant of Merlin agent used by BackdoorDiplomaty"
		author = "Sekoia.io"
		id = "965693ba-93b8-4c52-9292-957884411968"
		date = "2024-06-06"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_backdoordiplomaty_custommerlinagent_strings.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "31d13e234dc3f68f6826a5310ac38693750f896318249d04a31c5e6c8d5eba91"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "agent.GetSpecificID"
		$ = "agent.ExecuteCommand"
		$ = "agent.getClient"
		$ = "agent.SignalListen"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 10MB and all of them
}
rule SEKOIA_Rat_Win_Millenium : FILE
{
	meta:
		description = "Finds MilleniumRAT samples based on the specific strings"
		author = "Sekoia.io"
		id = "91320924-5c74-457a-8601-29c4e4034761"
		date = "2023-11-16"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/rat_win_millenium.yar#L1-L30"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "bcf4158b9bfee65cd9bd74163ac108ea1de8ec0e9ad066e77bec788ae6fb7283"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str01 = "Millenium RAT, version:" wide
		$str02 = "Coded by @shinyenigma" wide
		$str03 = "*gift*<NEW TOKEN>*<NEW CHAT ID>*<message> - gift this bot to another user, his telegram bot has to be started" wide
		$str04 = "*historyForce - grab more browser history by killing browser processes, use carefully" wide
		$str05 = "*download - victim`s PC downloads a file attached to this message, if it is a picture it should also be attached as a file" wide
		$str06 = "No keylogs recorded!" wide
		$str07 = "Successfully added RAT to startup" wide
		$str08 = "You`ve gifted gifted a bot:" wide
		$str09 = "Incorrect agrument, please enter 0/90/180/270" wide
		$str10 = "SELECT action_url, username_value, password_value FROM logins" wide
		$str11 = "Yandex\\YandexBrowser\\User Data\\Default" wide
		$str12 = "Millenium-rat-CSharp (main project)" ascii
		$str13 = "get_BatteryLifePercent" ascii
		$str14 = "get_ExpirationMonth" ascii
		$str15 = "sqlite3_extension_init " ascii

	condition:
		uint16( 0 ) == 0x5A4D and 10 of ( $str* )
}
rule SEKOIA_Dropper_Win_Selfau3
{
	meta:
		description = "Finds SelfAU3 Dropper samples based on specific strings"
		author = "Sekoia.io"
		id = "2d005a54-b013-40e9-b88a-30454e4b22af"
		date = "2024-02-12"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/dropper_win_selfau3.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "5f69457127ae6cb84b04f72dd30393dbcf32b4ba26ec6d529eebcc03191cbed3"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$sfx = "!Require Windows" ascii
		$ins01 = ";!@Install@!UTF-8!" ascii
		$set = {53 65 74 45 6e 76 69 72 6f 6e 6d 65 6e 74 3d 22 [1-15] 3d ?? 22}
		$run = "RunProgram=\"hidcon:c" ascii
		$ins02 = ";!@InstallEnd@!" ascii

	condition:
		$sfx at 77 and $set in ( @ins01 .. @ins01 + 500 ) and #set > 5 and $run in ( @set .. @set + 1000 ) and $ins02 in ( @run .. @run + 500 )
}

rule SEKOIA_Backdoor_Win_Minibus : FILE
{
	meta:
		description = "Detect the MINIBUS backdoor used by UNC1549 since August 2023"
		author = "Sekoia.io"
		id = "f88bcf15-9a9f-4d84-adc6-db1db55fe93c"
		date = "2024-02-29"
		modified = "2024-12-19"
		reference = "https://www.mandiant.com/resources/blog/suspected-iranian-unc1549-targets-israel-middle-east"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/backdoor_win_minibus.yar#L4-L41"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "57dabcc15c84c4497b3561f19a7e464fb0dfe93576f4caea88c7cd8534cb4bfd"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$dll_150_1 = "TorvaldsPersist.dll"
		$dll_150_2 = "FileCoAuth.exe"
		$dll_50_1 = "TorvaldInitial.dll"
		$dll_50_2 = "\\essential.dat"

	condition:
		( uint16( 0 ) == 0x5A4D and all of ( $dll_150_* ) or for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "2cf9797b1cfb5795d0fb892b7c371d506a5dd8b7c64fdc82975b3fde6d997df0" ) ) or ( uint16( 0 ) == 0x5A4D and all of ( $dll_50_* ) or for any i in ( 0 .. pe.number_of_resources -1 ) : ( hash.sha256 ( pe.resources [ i ] . offset , pe.resources [ i ] . length ) == "de3fb5d4419eb6b943872dd6e3dd93d19584ef2b158aa3158b3b09f0a9b628ef" ) )
}
rule SEKOIA_Infostealer_Win_Stealerium : FILE
{
	meta:
		description = "Detects Stealerium based on specific strings"
		author = "Sekoia.io"
		id = "165c7d3d-de7e-4d71-b94a-8ab4a0e5ddd5"
		date = "2022-12-01"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/infostealer_win_stealerium.yar#L1-L36"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "f420848164ad4b6966f2a776a58d90b7d70c8b151a42d6f56b654f1700b5e564"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$stl = "Stealerium" ascii wide
		$str01 = "Processe: " wide
		$str02 = "Compname: " wide
		$str03 = "Language: " wide
		$str04 = "SandBoxie: " wide
		$str05 = "== System Info ==" wide
		$str06 = "== Hardware ==" wide
		$str07 = "== Domains ==" wide
		$str08 = "WEBCAMS COUNT: " wide
		$str09 = "[Virtualization]" wide
		$str10 = "[Open google maps](" wide
		$str11 = "Remember password: " wide
		$str12 = "Target.Browsers.Firefox" ascii
		$str13 = "Modules.Keylogger" ascii
		$str14 = "ClipperAddresses" ascii
		$str15 = "ChromiumPswPaths" ascii
		$str16 = "DetectedBankingServices" ascii
		$str17 = "DetectCryptocurrencyServices" ascii
		$str18 = "CheckRemoteDebuggerPresent" ascii
		$str19 = "GetConnectedCamerasCount" ascii
		$str20 = "costura.discord-webhook-client.dll.compressed" ascii wide

	condition:
		uint16( 0 ) == 0x5A4D and filesize > 1MB and ( ( #stl > 5 and 2 of ( $str* ) ) or 15 of ( $str* ) )
}
rule SEKOIA_Apt_Apt41_Powershell_Exfiltration_Script : FILE
{
	meta:
		description = "Detects PowerShell exfiltration script"
		author = "Sekoia.io"
		id = "9a15f845-c0af-4f1c-a033-b4f40232dc0d"
		date = "2023-11-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_apt41_powershell_exfiltration_script.yar#L1-L18"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0ba4118855d6bd54cbb3a35e3b5fc36484eeb1e742ed3480e6c967b078ec4881"
		score = 75
		quality = 72
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "$UPLOAD_PASSPORT" ascii wide nocase
		$ = "$fileName=$singleFile.Name" ascii wide nocase
		$ = "Upload-Passport" ascii wide nocase
		$ = "$singleFile in $files" ascii wide nocase

	condition:
		filesize < 10KB and all of them
}
rule SEKOIA_Apt_Gelsemium_Wolfsbane_Rootkit : FILE
{
	meta:
		description = "Detects Gelsemium's WolfsBane rootkit"
		author = "Sekoia.io"
		id = "e93f4515-62f5-4057-a464-aae11cbe0639"
		date = "2024-11-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_gelsemium_wolfsbane_rootkit.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		hash = "ba08e63ad65a9bdcdb1655f25d32c808"
		logic_hash = "a7440e1b4c0bbff0d80d7152e3bfb0867abe9b0151b45f88aa656f3c9a55b303"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "__non_hooked_symbols"
		$ = "__hidden_literals"
		$ = "extract_type_2_socket_inode2"
		$ = "/proc/%s/fd"
		$ = "pluginkey" wide
		$ = "mainpath" wide
		$ = "hiderpath" wide

	condition:
		uint32be( 0 ) == 0x7f454c46 and filesize < 1MB and all of them
}
rule SEKOIA_Hacktool_Ligolo_Strings : FILE
{
	meta:
		description = "Detects ligolo based on strings"
		author = "Sekoia.io"
		id = "5013256b-eda3-417e-ac72-959055b01c7e"
		date = "2022-02-08"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_ligolo_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "12609bed61ef4d86737bc652a75c74f01e4a251466129ff56da0d7e002566d50"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Restarting Ligolo..."
		$ = "Ligolo starts a socks5 proxy server"
		$ = "main.startSocksProxy"
		$ = "main.handleRelay"
		$ = "main.StartLigolo"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and filesize > 2MB and filesize < 5MB and 3 of them
}
rule SEKOIA_Implant_Macos_Geacon : FILE
{
	meta:
		description = "Finds Geacon samples based on specific strings"
		author = "Sekoia.io"
		id = "a7784bfa-66a7-47df-b88b-d98217d8cca5"
		date = "2024-01-11"
		modified = "2024-12-19"
		reference = "https://www.sentinelone.com/blog/geacon-brings-cobalt-strike-capabilities-to-macos-threat-actors/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/implant_macos_geacon.yar#L1-L35"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "284574d185d3777a373f4a19e0870eec5245fb8ea5ebd6124bc281f8c74e0998"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$gea01 = "geacon/config.init" ascii
		$gea02 = "geacon_pro-master/config/config.go" ascii
		$gea03 = "geacon_plus-main/config/config.go" ascii
		$gea04 = "command type %d is not support by geacon now" ascii
		$gea05 = "main/sysinfo.GeaconID" ascii
		$str01 = "command.StealToken" ascii
		$str02 = "command.MakeToken" ascii
		$str03 = "command/misc.go" ascii
		$str04 = "config/c2profile.go" ascii
		$str05 = "crypt.AesCBCDecrypt" ascii
		$str06 = "packet.File_Browse" ascii
		$str07 = "packet.FirstBlood" ascii
		$str08 = "packet.ParseCommandShell" ascii
		$str09 = "packet.ParseCommandUpload" ascii
		$str10 = "packet.PushResult" ascii
		$str11 = "sysinfo.GetComputerName" ascii
		$str12 = "sysinfo.IsOSX64" ascii
		$str13 = "util..inittask" ascii

	condition:
		uint32( 0 ) == 0xFEEDFACF and ( ( 1 of ( $gea* ) and 2 of ( $str* ) ) or 8 of ( $str* ) )
}
rule SEKOIA_Hacktool_Stowaway_Strings : FILE
{
	meta:
		description = "Detects Stowaway based on strings"
		author = "Sekoia.io"
		id = "a952b45a-269b-4075-bf72-16d6d863e97c"
		date = "2023-11-15"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/hacktool_stowaway_strings.yar#L1-L24"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "10d28637e47d43497923a192c9e3a8bb35b480a314c71132866bdf0e49c2c460"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "agent.CloseLowConn"
		$ = "agent.CloseListener"
		$ = "agent.SimpleNodeInit"
		$ = "agent.HandleConnToLowerNode"
		$ = "agent.HandleConnFromLowerNode"
		$ = "common.NewPassToLowerNodeData"
		$ = "agent.HandleSimpleNodeConn"
		$ = "agent.HandleConnToUpperNode"
		$ = "agent.HandleConnFromUpperNode"
		$ = "agent.StartSocks"

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16be( 0 ) == 0x4d5a ) and all of them
}

rule SEKOIA_Apt_Win_Disabledefender
{
	meta:
		description = "detects strings and imphash"
		author = "Sekoia.io"
		id = "a7b124ab-4c9d-47c0-a59e-211cc713b9b3"
		date = "2022-09-23"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_win_disabledefender.yar#L3-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "3b8c8d9144d9f97ee053c7cefc30d3920940bc33efcd1d7f5c61666217ef7896"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Restarting with privileges"
		$ = "Windows defender is currently ACTIVE"
		$ = "Windows defender is currently OFF"
		$ = "Disabled windows defender"
		$ = "Failed to disable defender..."

	condition:
		4 of them or pe.imphash ( ) == "74a6ef9e7b49c71341e439022f643c8e"
}
rule SEKOIA_Apt_Darkpink_Kamikakabot_Strings
{
	meta:
		description = "Detects KamiKakaBot strings (.NET sample of Dark Pink)"
		author = "Sekoia.io"
		id = "0f5a7d72-81c8-4fdd-aefd-136bc6d48aa5"
		date = "2023-02-22"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/apt_darkpink_kamikakabot_strings.yar#L1-L30"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "0bc37c96b591d8edb1fd288ef874b3cc31879ce166b8734a3dd0e29644cbea55"
		score = 75
		quality = 80
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "Execute"
		$ = "f4869"
		$ = "getIndentifyName"
		$ = "getMessageAsync"
		$ = "requestMessageID"
		$ = "run_command"
		$ = "sendFile"
		$ = "sendMessage"
		$ = "send_brw_data"
		$ = "updateMessageID"
		$ = "update_new_token"
		$ = "update_new_xml"
		$ = {53 00 74 00 61 00 72 00 74 00 65 00 64 00 20 00 75 00 70 00 20 00 72 00 75 00 6e}
		$ = {20 00 72 00 65 00 63 00 6f 00 6e 00 6e 00 65 00 63 00 74 00 65 00 64 00 21}
		$ = {6e 00 65 00 77 00 20 00 63 00 6f 00 6e 00 6e 00 65 00 63 00 74 00 65 00 64 00 21}
		$ = {74 00 6f 00 6b 00 65 00 6e 00 20 00 75 00 70 00 64 00 61 00 74 00 65 00 20 00 73 00 75 00 63 00 63 00 65 00 73 00 73 00 21 00 21 00 21}

	condition:
		6 of them
}
rule SEKOIA_Tool_Sharphoundexecutable_Strings : FILE
{
	meta:
		description = "Detects the SharpHound tool"
		author = "Sekoia.io"
		id = "2cf8046e-5b4d-4ff7-b4b2-7aaeaf58883b"
		date = "2022-08-11"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/tool_sharphoundexecutable_strings.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "1b28a2b9dd594f344a1a2a74fd9b30527a66dabb451b21afca40a0e6ec8d3553"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "BloodHoundLoopResults.zip" wide
		$ = "[-] Removed PSRemote Collection" wide
		$ = "Initializing SharpHound at {time} on {date}" wide
		$ = "[SearchForest] Cross-domain enumeration may result in reduced data quality" wide
		$ = "SharpHound Enumeration Completed at {Time} on {Date}! Happy Graphing!" wide
		$ = "Consumer task on thread {id} completed" wide

	condition:
		uint16be( 0 ) == 0x4d5a and 3 of them
}
rule SEKOIA_Koi_Netstealer : FILE
{
	meta:
		description = "Detects NET ofbuscated Stealer used loaded by KoiLoader"
		author = "Sekoia.io"
		id = "deb06e2a-848c-44b3-be95-017ebccf11f8"
		date = "2024-03-20"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/yara_rules/koi_netstealer.yar#L1-L20"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/ae52d3fed661f7459c3877fec630e66a1771d5d0/LICENSE.md"
		logic_hash = "814db1092820ff1ed9e592dc92c72ad73643eb6d68df9f593ed637434373e41b"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$name_1 = "pg20"
		$name_2 = "pg40"
		$s1 = "Curve25519"
		$s2 = "ConsoleApp"
		$s3 = "e0d2eec7-eb14-48ba-8709-dcc9de65947d"

	condition:
		uint16be( 0 ) == 0x4d5a and filesize < 150KB and any of ( $name_* ) and all of ( $s* )
}
