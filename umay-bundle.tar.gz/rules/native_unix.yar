/*
    Umay heuristics: macOS and Linux executables, plus the shell commands
    macOS malware runs through `osascript` and `sh -c`.
*/

rule MacOS_PasswordPrompt
{
    meta:
        umay_name = "Heur.MacOS.FakePasswordPrompt"
        umay_weight = 40
        description = "Shows its own dialog asking for a password with hidden input, instead of the system prompt"
    strings:
        $osa = "osascript" ascii
        $dialog = "display dialog" nocase ascii
        $hidden = "hidden answer" nocase ascii
    condition:
        (umay_kind == "macho" or umay_kind == "script" or umay_derived) and all of them
}

rule MacOS_PasswordValidation
{
    meta:
        umay_name = "Heur.MacOS.StolenPasswordCheck"
        umay_weight = 55
        description = "Asks for the login password in a custom dialog and silently verifies it, as macOS stealers do"
    strings:
        $dialog = "display dialog" nocase ascii
        $hidden = "hidden answer" nocase ascii
        $check = /dscl\s+[^\r\n]{0,40}-authonly/ ascii
    condition:
        (umay_kind == "macho" or umay_kind == "script" or umay_derived) and all of them
}

rule MacOS_KeychainAndBrowserTheft
{
    meta:
        umay_name = "Heur.MacOS.CredentialStoreTheft"
        umay_weight = 45
        description = "References the login keychain together with browser password stores and wallets"
    strings:
        $kc1 = "login.keychain-db" ascii
        $kc2 = "security find-generic-password" ascii
        $kc3 = "dump-keychain" ascii
        $b1 = "Google/Chrome/Default/Login Data" ascii
        $b2 = "Library/Application Support/Google/Chrome" ascii
        $b3 = "Library/Application Support/BraveSoftware" ascii
        $b4 = "Library/Application Support/Firefox/Profiles" ascii
        $b5 = "Cookies.binarycookies" ascii
        $w1 = "Library/Application Support/Exodus" ascii
        $w2 = ".electrum/wallets" ascii
        $w3 = "Library/Application Support/Atomic" ascii
    condition:
        (umay_kind == "macho" or umay_kind == "script" or umay_derived)
        and any of ($kc*) and 2 of ($b*, $w*)
}

rule MacOS_GatekeeperTampering
{
    meta:
        umay_name = "Heur.MacOS.GatekeeperTampering"
        umay_weight = 40
        description = "Removes the download quarantine mark or turns off Gatekeeper so unsigned code runs unchallenged"
    strings:
        $xattr = /xattr\s+-(d|rd|dr)\s+com\.apple\.quarantine/ ascii
        $clear = /xattr\s+-(c|cr|rc)\s/ ascii
        $spctl = /spctl\s+--(master-disable|global-disable)/ ascii
        $fetch = /\b(curl|wget)\b/ ascii
    condition:
        (umay_kind == "macho" or umay_kind == "script" or umay_derived)
        and ($spctl or (($xattr or $clear) and $fetch))
}

rule MacOS_PrivacyDatabaseTampering
{
    meta:
        umay_name = "Heur.MacOS.PrivacyDatabaseTampering"
        umay_weight = 45
        description = "Edits the database that records which apps may use the camera, microphone and disk"
    strings:
        $db = "com.apple.TCC/TCC.db" ascii
        $sql1 = "INSERT INTO access" nocase ascii
        $sql2 = "INSERT OR REPLACE INTO access" nocase ascii
        $sql3 = "UPDATE access" nocase ascii
    condition:
        (umay_kind == "macho" or umay_kind == "script" or umay_derived) and $db and any of ($sql*)
}

rule MacOS_LaunchAgentDropper
{
    meta:
        umay_name = "Heur.MacOS.LaunchAgentDropper"
        umay_weight = 30
        description = "Writes a start-at-login job that runs a downloaded or temporary file"
    strings:
        $dir = "Library/LaunchAgents" ascii
        $key1 = "RunAtLoad" ascii
        $key2 = "ProgramArguments" ascii
        $p1 = "/tmp/" ascii
        $p2 = "/private/tmp/" ascii
        $p3 = "osascript" ascii
        $p4 = /\b(curl|wget)\b/ ascii
        $p5 = "/Users/Shared/" ascii
    condition:
        (umay_kind == "macho" or umay_kind == "script" or umay_derived)
        and $dir and $key1 and $key2 and 2 of ($p*)
}

rule ELF_CoinMiner
{
    meta:
        umay_name = "Heur.ELF.CoinMiner"
        umay_weight = 60
        description = "Cryptocurrency miner"
    strings:
        $pool = /stratum\+(tcp|ssl|tls):\/\// ascii
        $m1 = "cryptonight" nocase ascii
        $m2 = "randomx" nocase ascii
        $m3 = "donate-level" ascii
        $m4 = "xmrig" nocase ascii
    condition:
        (umay_kind == "elf" or umay_kind == "macho" or umay_kind == "pe") and $pool and 2 of ($m*)
}

rule ELF_PreloadRootkit
{
    meta:
        umay_name = "Heur.ELF.PreloadRootkit"
        umay_weight = 50
        description = "Library built to load into every process and hide files, processes or connections"
    strings:
        $preload = "/etc/ld.so.preload" ascii
        $h1 = "readdir64" ascii
        $h2 = "getdents64" ascii
        $h3 = "/proc/self/fd" ascii
        $h4 = "dlsym" ascii
        $h5 = "RTLD_NEXT" ascii
        $hide1 = "/proc/net/tcp" ascii
        $hide2 = "hide" nocase ascii
    condition:
        umay_kind == "elf" and $preload and 2 of ($h*) and any of ($hide*)
}

rule ELF_IotBotnet
{
    meta:
        umay_name = "Heur.ELF.IotBotnet"
        umay_weight = 55
        description = "Shares the traits of Mirai-family botnet clients that take over routers and cameras"
    strings:
        $s1 = "/bin/busybox" ascii
        $s2 = "/dev/watchdog" ascii
        $s3 = "/dev/misc/watchdog" ascii
        $s4 = "/proc/net/tcp" ascii
        $s5 = "enable\x00system\x00shell\x00sh" ascii
        $s6 = "TSource Engine Query" ascii
        $s7 = /(telnetd|dropbear|sshd)\x00/ ascii
        $s8 = "/etc/resolv.conf" ascii
    condition:
        umay_kind == "elf" and filesize < 2MB and 5 of them
}

rule ELF_LogWiper
{
    meta:
        umay_name = "Heur.ELF.LogWiper"
        umay_weight = 35
        description = "References every login-record file, as tools that erase traces of an intrusion do"
    strings:
        $l1 = "/var/log/wtmp" ascii
        $l2 = "/var/log/btmp" ascii
        $l3 = "/var/log/lastlog" ascii
        $l4 = "/var/run/utmp" ascii
        $l5 = ".bash_history" ascii
    condition:
        umay_kind == "elf" and filesize < 5MB and 4 of them
}
