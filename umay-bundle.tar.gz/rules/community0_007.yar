import "dotnet"
import "hash"
import "pe"

rule DITEKSHEN_MALWARE_Win_TRAT : FILE
{
	meta:
		description = "TRAT payload"
		author = "ditekSHen"
		id = "15f80970-6bc7-5e29-86d6-f7529a10d227"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1715-L1730"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b8474c74cd9f21fcb3a8ae1c7a7a0a801f0f117782e9803cdae39daf7f0f8b2f"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.TRAT"

	strings:
		$s1 = "^STEAM_0:[0-1]:([0-9]{1,10})$" fullword wide
		$s2 = "^7656119([0-9]{10})$" fullword wide
		$s3 = "Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)" ascii
		$s4 = "\"schtasks\", \"/delete /tn UpdateWindows /f\");" ascii
		$s5 = "ProcessWindowStyle.Hidden" ascii
		$s6 = "+<>c+<<ListCommands>" ascii
		$s7 = "//B //Nologo *Y" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Matiex : FILE
{
	meta:
		description = "Matiex/XetimaLogger keylogger payload"
		author = "ditekSHen"
		id = "61803e0c-8f6a-5ded-855a-ff26eed1384f"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1768-L1788"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "62b45c43d99bef93a6c0e72200b869fdce331f8fa325640df7d8b72af56a3ef2"
		score = 75
		quality = 73
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.MatiexKeylogger"

	strings:
		$id = "--M-A-T-I-E-X--K-E-Y-L-O-G-E-R--" ascii wide
		$s1 = "StartKeylogger" fullword ascii
		$s2 = "_KeyboardLoggerTimer" ascii
		$s3 = "_ScreenshotLoggerTimer" ascii
		$s4 = "_VoiceRecordLogger" ascii
		$s5 = "_ClipboardLoggerTimer" ascii
		$s6 = "get_logins" fullword ascii
		$s7 = "get_processhackerFucked" fullword ascii
		$s8 = "_ThePSWDSenders" fullword ascii
		$pdb = "\\Before FprmT\\Document VB project\\FireFox Stub\\FireFox Stub\\obj\\Debug\\VNXT.pdb" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( $id or 4 of ( $s* ) or ( $pdb and 2 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Iamthekingkeylogger : FILE
{
	meta:
		description = "IAmTheKing Keylogger payload"
		author = "ditekSHen"
		id = "f9c84241-6db2-5243-9bea-2165104cb0c3"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1790-L1805"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "80d8cabfd02cd73e19e6cf1c2a8a5f06c5b3b502fe4f07289e92b448425aaa6d"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.IAmTheKingKeylogger"

	strings:
		$s1 = "[TIME:]%d/%d/%d %02d:%02d:%02d" fullword ascii
		$s2 = "[TITLE:]" fullword ascii
		$s3 = "%s-%02d-%02d-%02d-%02d" fullword ascii
		$s4 = "[DATA]:" fullword ascii
		$s5 = "[BK]" fullword ascii
		$s6 = "Log.txt" fullword ascii
		$s7 = "sonme hting is wrong x" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Iamthekingscrcap : FILE
{
	meta:
		description = "IAmTheKing screen capture payload"
		author = "ditekSHen"
		id = "ba385194-9578-568c-b908-bc4fc742e52e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1807-L1821"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "594ddad4e08bad51f90de1c4299e28b4800b4fa686bd4176e406ba401a1242ba"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "@MyScreen.jpg" fullword wide
		$s2 = "DISPLAY" fullword wide
		$s3 = ".?AVCImage@ATL@@" fullword ascii
		$s4 = ".?AVGdiplusBase@Gdiplus@@" fullword ascii
		$s5 = ".?AVImage@Gdiplus@@" fullword ascii
		$s6 = ".?AVBitmap@Gdiplus@@" fullword ascii
		$s7 = ".?AVCAtlException@ATL@@" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Iamthekingkingofhearts : FILE
{
	meta:
		description = "IAmTheKing King Of Hearts payload"
		author = "ditekSHen"
		id = "95c73ec0-75b0-5d46-87da-b30feb170716"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1823-L1843"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "75b6dd0ebb90fd04f9e4a0b1fc6a1bbf417fc66daad24c8b01f0390f6155ec55"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "write info fail!!! GetLastError-->%u" fullword ascii
		$s2 = "LookupAccountSid Error %u" fullword ascii
		$s3 = "CreateServiceErrorID:%d" fullword ascii
		$s4 = "In ControlServiceErrorID:%d" fullword ascii
		$s5 = "In QueryServiceStatus ErrorID:%d" fullword ascii
		$s6 = "Content-Disposition: form-data; name=\"%s\"; filename=\"%s\"" fullword ascii
		$s7 = "hello%s" fullword ascii
		$s8 = "additional header failed..." fullword ascii
		$s9 = "Set Option failed errcode: %ld" fullword ascii
		$s10 = "add cookie failed..." fullword ascii
		$u1 = "Mozilla/4.0 (compatible; )" fullword ascii
		$u2 = "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; SE)" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $u* ) and 4 of ( $s* ) ) or ( all of ( $u* ) and 3 of ( $s* ) ) or ( 5 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Redlinedropperahk : FILE
{
	meta:
		description = "Detects AutoIt/AutoHotKey executables dropping RedLine infostealer"
		author = "ditekSHen"
		id = "16eee826-f1fd-5a6f-b6f3-e02ccd889614"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1866-L1878"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0950fe9daa02f3a8fd527f75275766111be7e8774578963b0bdb455800dfc4f9"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.RedLineDropper-AHK"

	strings:
		$s1 = ".SetRequestHeader(\"User-Agent\",\" ( \" OSName \" | \" bit \" | \" CPUNAme \"\"" ascii
		$s2 = ":= \" | Windows Defender\"" ascii
		$s3 = "WindowSpy.ahk" wide
		$s4 = ">AUTOHOTKEY SCRIPT<" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Dlagent01 : FILE
{
	meta:
		description = "Detects known downloader agent"
		author = "ditekSHen"
		id = "85ead6fd-b56e-5e78-8fb4-7c9ecb4c0b58"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1880-L1894"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "7aec81655af9b779a314c3e2cff933aa6426fcfe21b5a87e60e159c7e7f5238a"
		score = 75
		quality = 75
		tags = "FILE"
		snort_sid = "920007"
		clamav_sig = "MALWARE.Win.Trojan.DLAgent01"

	strings:
		$s1 = "Mozilla/5.0 Gecko/41.0 Firefox/41.0" fullword wide
		$s2 = "/Node:localhost /Namespace:\\\\root\\SecurityCenter2 Path AntiVirusProduct Get displayName /Format:List" fullword wide
		$s3 = "GUID.log" fullword wide
		$s4 = "NO AV" fullword wide
		$s5 = "%d:%I64d:%I64d:%I64d" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Linux_PLEAD : FILE
{
	meta:
		description = "PLEAD Linux payload"
		author = "ditekSHen"
		id = "07aa0561-d6d9-53b6-97ac-670cdf04335d"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1896-L1920"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "539998248ded0eb8ea1702c527804f89cfd55412f17ec699bd0af801f4fba673"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Linux.Trojan.PLEAD"

	strings:
		$x1 = "CFileTransfer" ascii
		$x2 = "CFileManager" ascii
		$x3 = "CPortForward" ascii
		$x4 = "CPortForwardManager" ascii
		$x5 = "CRemoteShell" ascii
		$x6 = "CSockClient" ascii
		$s1 = "/proc/self/exe" fullword ascii
		$s2 = "/bin/sh" fullword ascii
		$s3 = "echo -e '" ascii
		$s4 = "%s    <DIR>    %s" ascii
		$s5 = "%s    %lld    %s" ascii
		$s6 = "Files: %d        Size: %lld" ascii
		$s7 = "Dirs: %d" ascii
		$s8 = "%s(%s)/" ascii
		$s9 = "%s %s %s %s" ascii

	condition:
		uint16( 0 ) == 0x457f and ( all of ( $x* ) or all of ( $s* ) or 12 of them )
}
rule DITEKSHEN_MALWARE_Win_CRAT : FILE
{
	meta:
		description = "Detects CRAT main DLL"
		author = "ditekSHen"
		id = "9757a8de-61ea-55c0-b64c-055798450985"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1922-L1944"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5a9fef68e110a1564dd5956408abcc3736cfa6853e1ac5510a089cc68f6bdc35"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "cmd /c \"dir %s /s >> %s\"" wide
		$s2 = "Set-Cookie:\\b*{.+?}\\n" wide
		$s3 = "Location: {[0-9]+}" wide
		$s4 = "Content-Disposition: form-data; name=\"%s\"; filename=\"" ascii
		$s6 = "%serror.log" wide
		$v2x_1 = "?timestamp=%u" wide
		$v2x_2 = "config.txt" wide
		$v2x_3 = "entdll.dll" wide
		$v2x_4 = "\\cmd.exe" wide
		$v2x_5 = "[MyDocuments]" wide
		$v2x_6 = "@SetWindowTextW FindFileExA" wide
		$v2x_7 = "Microsoft\\Windows\\WinX\\Group1\\*.exe" wide
		$v2s_1 = "Installed Anti Virus Programs" ascii
		$v2s_2 = "Running Processes" ascii
		$v2s_3 = "id=%u&content=" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or 6 of ( $v2x* ) or all of ( $v2s* ) or ( 2 of ( $v2s* ) and 4 of ( $v2x* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Cratpluginkeylogger : FILE
{
	meta:
		description = "Detects CRAT keylogger plugin DLL"
		author = "ditekSHen"
		id = "a8682786-7704-56f0-a6df-b4e2ab4d7536"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1946-L1962"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "58ef1f7466fcc871be2e74aa447c76970fd90c9d9d345a896fb8e6335114d189"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.CRAT"

	strings:
		$ai1 = "VM detected!" fullword wide
		$ai2 = "Sandbox detected!" fullword wide
		$ai3 = "Debug detected!" fullword wide
		$ai4 = "Analysis process detected!" fullword wide
		$s1 = "Create KeyLogMutex %s failure %d" wide
		$s2 = "Key Log Mutex already created! %s" wide
		$s3 = /KeyLogThread\s(started|finished|terminated)!/ wide
		$s4 = /KeyLog_(x64|x32|Win64|Win32)_DllRelease\.dll/ fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( all of ( $ai* ) and 1 of ( $s* ) ) or ( 3 of ( $s* ) and 1 of ( $ai* ) ) or 5 of them )
}
rule DITEKSHEN_MALWARE_Win_Cratpluginclipboardmonitor : FILE
{
	meta:
		description = "Detects CRAT Clipboad Monitor plugin DLL"
		author = "ditekSHen"
		id = "587487c7-f00b-5d4a-8b18-e46d6c6560e2"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1964-L1979"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c3e692a06388e143a8e1053e75a6eb6a82da5bdf26d38e3a0e339bc20d8312a1"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$ai1 = "VM detected!" fullword wide
		$ai2 = "Sandbox detected!" fullword wide
		$ai3 = "Debug detected!" fullword wide
		$ai4 = "Analysis process detected!" fullword wide
		$s1 = "Clipboard Monitor Mutex [%s] already created!" wide
		$s2 = "ClipboardMonitorThread started!" fullword wide
		$s3 = /MonitorClipboardThread\s(finished|terminated)!/ wide
		$s4 = /ClipboardMonitor_(x64|x32|Win64|Win32)_DllRelease\.dll/ fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( all of ( $ai* ) and 1 of ( $s* ) ) or ( 3 of ( $s* ) and 1 of ( $ai* ) ) or 5 of them )
}
rule DITEKSHEN_MALWARE_Win_Cratpluginscreencapture : FILE
{
	meta:
		description = "Detects CRAT Screen Capture plugin DLL"
		author = "ditekSHen"
		id = "ef0b6b88-8b1b-5ab5-ad81-276eaff0411f"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L1981-L2000"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "7b4378ae883d01338fabe2eb50a5509b722c661e63afc287afa07b263a0ebc42"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$ai1 = "VM detected!" fullword wide
		$ai2 = "Sandbox detected!" fullword wide
		$ai3 = "Debug detected!" fullword wide
		$ai4 = "Analysis process detected!" fullword wide
		$s1 = "User is inactive!, give up capture" wide
		$s2 = "Capturing screen..." wide
		$s3 = "%s\\P%02d%lu.tmp" fullword wide
		$s4 = "CloseHandle ScreenCaptureMutex failure! %d" fullword wide
		$s5 = "ScreenCaptureMutex already created! %s" fullword wide
		$s6 = "Create ScreenCaptureMutex %s failure %d" fullword wide
		$s7 = /ScreenCaptureThread\s(finished|terminated)!/ wide
		$s8 = /ScreenCapture_(x64|x32|Win64|Win32)_DllRelease\.dll/ fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( all of ( $ai* ) and 1 of ( $s* ) ) or ( 3 of ( $s* ) and 1 of ( $ai* ) ) or 6 of them )
}
rule DITEKSHEN_MALWARE_Win_Cratpluginransomhansom : FILE
{
	meta:
		description = "Detects CRAT Hansom Ransomware plugin DLL"
		author = "ditekSHen"
		id = "0bfc97df-545f-5453-afe0-5777dc1c95b4"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2002-L2020"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b22f6d22630f311241634513eb051df2b36af84a938c1ae1f5284e5a5d7d3077"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$cmd1 = "/f /im \"%s\"" wide
		$cmd2 = "add HKLM\\%s /v %s /t REG_DWORD /d %d /F" wide
		$cmd3 = "add HKCU\\%s /v %s /t REG_DWORD /d %d /F" wide
		$cmd4 = "\"%s\" a -y -ep -k -r -s -ibck -df -m0 -hp%s -ri1:%d \"%s\" \"%s\"" wide
		$s1 = "\\hansom.jpg" wide
		$s2 = "HansomMain" fullword ascii wide
		$s3 = "ExtractHansom" fullword ascii wide
		$s4 = "Hansom2008" fullword ascii
		$s5 = ".hansomkey" fullword wide
		$s6 = ".hansom" fullword wide
		$s7 = /Ransom_(x64|x32|Win64|Win32)_DllRelease\.dll/ fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 2 of ( $cmd* ) and 2 of ( $s* ) ) or ( 4 of ( $s* ) and 1 of ( $cmd* ) ) or 6 of them )
}
rule DITEKSHEN_MALWARE_Win_Aliencrypter : FILE
{
	meta:
		description = "Detects AlienCrypter injector/downloader/obfuscator"
		author = "ditekSHen"
		id = "af9e785a-bdec-5d3e-9a50-56f7f1a0507e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2022-L2036"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "28a2a6e6d58fd6efbb5753a7be5b621a3eac546d45f9481b9dd2641cbe70b547"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = ".AlienRunPE." ascii wide
		$s2 = "RunAsNewUser_RunDLL" fullword wide
		$s3 = { 00 50 52 4f 43 45 53 53 5f 53 55 53 50 45 4e 44 5f 52 45 53 55 4d 45 00 64 6e 6c 69 62 2e 50 45 00 }
		$s4 = { 2e 41 6c 69 65 6e 52 75 6e 50 45 00 50 52 4f 43 45 53 53 5f 54 45 52 4d 49 4e 41 54 45 00 }
		$s5 = "@@@http" wide
		$resp1 = "</p><p>@@@77,90," ascii wide
		$resp2 = "</p><p>@@@HH,JA," ascii wide

	condition:
		( uint16( 0 ) == 0x5a4d and 3 of them ) or ( 1 of ( $resp* ) and 2 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Ficker : FILE
{
	meta:
		description = "Detects Ficker infostealer"
		author = "ditekSHen"
		id = "1cfeea86-e8bf-50fb-ba08-435d7a14a913"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2038-L2055"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "adcc0ffc0e1ded36dc41c22d10d2ea293d5740484203892bcecf89a5f4001452"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.Ficker"

	strings:
		$s1 = "JNOde\\" ascii
		$s2 = "\"SomeNone" fullword ascii
		$s3 = "kindmessage" fullword ascii
		$s4 = "..\\\\?\\.\\UNC\\Windows stdio in console mode does not support writting non-UTF-8 byte sequences" ascii
		$s5 = "..\\\\?\\.\\UNC\\Windows stdio in console mode does not support writing non-UTF-8 byte sequences" ascii
		$s6 = "(os error other os erroroperation interrruptedwrite zerotimed" ascii
		$s7 = "(os error other os erroroperation interruptedwrite zerotimed" ascii
		$s8 = "nPipeAlreadyExistsWouldBlockInvalidInputInvalidDataTimedOutWriteZeroInterruptedOtherN" fullword ascii
		$s9 = "_matherr(): %s in %s(%g, %g)  (retval=%g)" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Xorist : FILE
{
	meta:
		description = "Detects Xorist ransomware"
		author = "ditekSHen"
		id = "76119441-343d-51c3-90eb-9d54c80a983d"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2057-L2078"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b34e3fa065cabcd8d26908866e53ff599631128e1da884e42a2e63d890879eaa"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Ransomware.Xorist"

	strings:
		$x1 = { 00 4d 00 41 00 47 00 45 00 0b 00 50 00 55 00 
                53 00 53 00 59 00 4c 00 49 00 43 00 4b 00 45
                00 52 00 }
		$x2 = { 30 70 33 6e 53 4f 75 72 63 33 20 58 30 72 31 35
                37 2c 20 6d 6f 74 68 65 72 66 75 63 6b 65 72 21
                00 70 75 73 73 79 6c 69 63 6b 65 72 00 2e 62 6d
                70 00 2e 00 2e 2e 00 6f 70 65 6e 00 2e 65 78 65 }
		$s1 = "\\shell\\open\\command" fullword ascii
		$s2 = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run" fullword ascii
		$s3 = "CRYPTED!" fullword ascii
		$s4 = "Attention!" fullword ascii
		$s5 = "Password:" fullword ascii
		$s6 = { 43 6f 6d 53 70 65 63 00 2f 63 20 64 65 6c 20 22 00 22 20 3e 3e 20 4e 55 4c }

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) or 5 of ( $s* ) or ( 1 of ( $x* ) and 3 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_PYSA : FILE
{
	meta:
		description = "Detects PYSA/Mespinoza ransomware"
		author = "ditekSHen"
		id = "3a3fad6a-46bc-51dc-9723-4412034ca442"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2080-L2100"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e614b827bd8d065e94852fed01497c785bf90c52c3624aff9939b3f40ecf96a4"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Ransomware.PYSA"

	strings:
		$s1 = "%s\\Readme.README" fullword wide
		$s2 = "Every byte on any types of your devices was encrypted" ascii
		$s3 = { 6c 65 67 61 6c 6e 6f 74 69 63 65 74 65 78 74 00 (50|70) (59|79) (53|73) (41|61) }
		$s4 = { 6c 65 67 61 6c 6e 6f 74 69 63 65 63 61 70 74 69 6f 6e 00 00 (50|70) (59|79) (53|73) (41|61) }
		$s5 = { 2e 62 61 74 00 00 6f 70 65 6e 00 00 00 00 53
                4f 46 54 57 41 52 45 5c 4d 69 63 72 6f 73 6f
                66 74 5c 57 69 6e 64 6f 77 73 5c 43 75 72 72
                65 6e 74 56 65 72 73 69 6f 6e 5c 50 6f 6c 69
                63 69 65 73 5c 53 79 73 74 65 6d 00 00 00 }
		$f1 = ".?AVPK_EncryptorFilter@CryptoPP@@" ascii
		$f2 = ".?AV?$TF_EncryptorImpl@" ascii
		$f3 = "@VTF_EncryptorBase@CryptoPP@@" ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of ( $f* ) and 3 of ( $s* )
}
rule DITEKSHEN_MALWARE_Win_Polar : FILE
{
	meta:
		description = "Detects Polar ransomware"
		author = "ditekSHen"
		id = "ab4e4478-5417-5918-b5df-5b6ffe7438a9"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2102-L2123"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4f05a8ace9a03d02f54f0ebdd5349d1d1b23db8e34aa71edd44eebf02b88745c"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Ransomware.Polar"

	strings:
		$s1 = "Encrypt Failed ! ErrorMessage :" wide
		$s2 = ".locked" fullword wide
		$s3 = ".cryptd" fullword wide
		$s4 = "$SysReset" fullword wide
		$s5 = "Polar.Properties.Resources" ascii wide
		$s6 = "AES_EnDecryptor.Basement" fullword ascii
		$s7 = "RunCMDCommand" fullword ascii
		$s8 = "killerps_list" fullword ascii
		$s9 = "clearlog" fullword ascii
		$s10 = "encryptFile" fullword ascii
		$s11 = "changeBackPictrue" fullword ascii
		$pdb1 = "\\Ransomware_ALL_encode\\dir_file\\obj\\x86\\Release\\Encode.pdb" ascii
		$pdb2 = "\\Ransomware_ALL_encode\\dir_file\\obj\\x64\\Release\\Encode.pdb" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 8 of ( $s* ) or ( 1 of ( $pdb* ) and 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Poullight : FILE
{
	meta:
		description = "Detects Poullight infostealer"
		author = "ditekSHen"
		id = "c80143f8-9c44-5e96-b1ff-2adb4bf031e4"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2155-L2176"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e60ffb10892d35664a088d69c965e130f87bb1a59c257d484bdfe5085074bccd"
		score = 75
		quality = 75
		tags = "FILE"
		snort2_sid = "920074-920075"
		snort3_sid = "920074-920075"
		clamav_sig = "MALWARE.Win.Trojan.Poullight"

	strings:
		$s1 = "zipx" fullword wide
		$s2 = "{0}Windows Defender.exe" fullword wide
		$s3 = "pll_test" fullword wide
		$s4 = "loginusers.vdf" wide
		$s5 = "Stealer by Nixscare" wide
		$s6 = "path_lad" fullword ascii
		$s7 = "<CheckVM>" ascii
		$s8 = "Poullight.Properties" ascii
		$s9 = "</ulfile>" fullword wide
		$s10 = "{0}processlist.txt" fullword wide
		$s11 = "{0}Browsers\\Passwords.txt" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and 7 of them
}
rule DITEKSHEN_MALWARE_Linux_Xorddos : FILE
{
	meta:
		description = "Detects XORDDoS"
		author = "ditekSHen"
		id = "0ca581c3-bce2-5b4f-8146-9aeb49b88813"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2209-L2220"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "192378d903316c1d80b064e78feb6ed9d2ffc9e6c7dc0c8df223d83d17e4e8d9"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "for i in `cat /proc/net/dev|grep :|awk -F: {'print $1'}`; do ifconfig $i up& done" fullword ascii
		$s2 = "cp /lib/libudev.so /lib/libudev.so.6" fullword ascii
		$s3 = "sed -i '/\\/etc\\/cron.hourly\\/gcc.sh/d' /etc/crontab && echo '*/3 * * * * root /etc/cron.hourly/gcc.sh' >> /etc/crontab" fullword ascii
		$s4 = "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; SV1; TencentTraveler ; .NET CLR 1.1.4322)" fullword ascii

	condition:
		uint32( 0 ) == 0x464c457f and 3 of them
}
rule DITEKSHEN_MALWARE_Win_Blacknet : FILE
{
	meta:
		description = "Detects BlackNET RAT"
		author = "ditekSHen"
		id = "c1ece46a-3cd9-54aa-a105-1c5b19357a7e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2222-L2250"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "64e00325a5a6a595067c6133800e73d943f45e2783475c24ed4a9bd9937fe0d6"
		score = 75
		quality = 75
		tags = "FILE"
		snort2_sid = "920079-920082"
		snort3_sid = "920079-920082"
		clamav_sig = "MALWARE.Win.Trojan.BlackNET"

	strings:
		$s1 = "SbieCtrl" fullword wide
		$s2 = "SpyTheSpy" fullword wide
		$s3 = "\\BlackNET.dat" fullword wide
		$s4 = "StartDDOS" fullword wide
		$s5 = "UDPAttack" fullword wide
		$s6 = "ARMEAttack" fullword wide
		$s7 = "TCPAttack" fullword wide
		$s8 = "HTTPGetAttack" fullword wide
		$s9 = "RetriveLogs" fullword wide
		$s10 = "StealPassword" fullword wide
		$s11 = "/create /f /sc ONSTART /RL HIGHEST /tn \"'" fullword wide
		$b1 = "DeleteScript|BN|" fullword wide
		$b2 = "|BN|Online" fullword wide
		$b3 = "NewLog|BN|" fullword wide
		$cnc1 = "/getCommand.php?id=" fullword wide
		$cnc2 = "/upload.php?id=" fullword wide
		$cnc3 = "connection.php?data=" fullword wide
		$cnc4 = "/receive.php?command=" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 9 of ( $s* ) or all of ( $cnc* ) or all of ( $b* ) or 12 of them )
}
rule DITEKSHEN_MALWARE_Win_Stormkitty : FILE
{
	meta:
		description = "Detects StormKitty infostealer"
		author = "ditekSHen"
		id = "a061a1c0-9ed5-5048-85df-4d7ed6995e92"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2252-L2269"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5d139aad6932f177cd14e0356f822ad68ddc659ea4fabd2fd2fbcbc8bad58888"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.StormKitty"

	strings:
		$x1 = "\\ARTIKA\\Videos\\Chrome-Password-Recovery" ascii
		$x2 = "https://github.com/LimerBoy/StormKitty" fullword ascii
		$x3 = "StormKitty" fullword ascii
		$s1 = "GetBSSID" fullword ascii
		$s2 = "GetAntivirus" fullword ascii
		$s3 = "C:\\Users\\Public\\credentials.txt" fullword wide
		$s4 = "^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$" fullword wide
		$s5 = "BCrypt.BCryptGetProperty() (get size) failed with status code:{0}" fullword wide
		$s6 = "\"encrypted_key\":\"(.*?)\"" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $x* ) or 5 of ( $s* ) or ( 3 of ( $s* ) and 1 of ( $x* ) ) )
}

rule DITEKSHEN_MALWARE_Win_Bulz01 : FILE
{
	meta:
		description = "Detects trojan loader"
		author = "ditekSHen"
		id = "4ac4125b-70f5-5cda-ae45-fd5713e25a6e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2271-L2281"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "29884dda4936016660f5d1e33ffcf97a20c7d3116483a5895a5e2a1dd4ac9e9f"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "DisableTrivet.dll" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and pe.is_dll ( ) and all of ( $s* ) and ( pe.exports ( "Ordinal" ) or pe.exports ( "Chechako" ) or pe.exports ( "Originator" ) or pe.exports ( "Repressions" ) )
}
rule DITEKSHEN_MALWARE_Win_Powerpool_STG1 : FILE
{
	meta:
		description = "Detects first stage PowerPool backdoor"
		author = "ditekSHen"
		id = "8531c22d-8d71-5794-b9c8-0a4cd81bb2b0"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2334-L2361"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9ab00d6e3007743a8bb30fbcdb435ac49101b52face55549ae454c64345caff9"
		score = 75
		quality = 75
		tags = "FILE"
		snort2_sid = "920088"
		snort3_sid = "920086"
		clamav_sig = "MALWARE.Win.Trojan.PowerPool-STG-1"

	strings:
		$s1 = "cmd /c powershell.exe $PSVersionTable.PSVersion > \"%s\"" fullword wide
		$s2 = "cmd /c powershell.exe \"%s\" > \"%s\"" fullword wide
		$s3 = "rar.exe a -r %s.rar -ta%04d%02d%02d%02d%02d%02d -tb%04d%02d%02d%02d%02d%02d" fullword wide
		$s4 = "MyDemonMutex%d" fullword wide
		$s5 = "MyScreen.jpg" fullword wide
		$s6 = "proxy.log" fullword wide
		$s7 = "myjt.exe" fullword wide
		$s8 = "/?id=%s&info=%s" fullword wide
		$s9 = "auto.cfg" fullword ascii
		$s10 = "Mozilla/5.0 (Windows NT 6.1; WOW64)" fullword wide
		$s11 = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko)" fullword wide
		$s12 = "CMD COMMAND EXCUTE ERROR!" fullword ascii
		$c1 = "run.afishaonline.eu" fullword wide
		$c2 = "home.Sports-Collectors.com" fullword wide
		$c3 = "about.Sports-Collectors.com" fullword
		$c4 = "179.43.158.15" fullword wide
		$c5 = "185.227.82.35" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or ( 1 of ( $c* ) and 5 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Powerpool_STG2 : FILE
{
	meta:
		description = "Detects second stage PowerPool backdoor"
		author = "ditekSHen"
		id = "1a059900-3292-5419-a143-caea3e710191"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2363-L2395"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b80712bab281dbde816e2eda6ab1b4a9e21be26578fb755a1e1e1635675aa911"
		score = 75
		quality = 73
		tags = "FILE"
		snort2_sid = "920089-920091"
		snort3_sid = "920087-920089"
		clamav_sig = "MALWARE.Win.Trojan.PowerPool-STG-2"

	strings:
		$s1 = "write info fail!!! GetLastError-->%u" fullword ascii
		$s2 = "LookupAccountSid Error %u" fullword ascii
		$s3 = "Mozilla/4.0 (compatible; )" fullword ascii
		$s4 = "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; SE)" fullword ascii
		$s5 = "Content-Disposition: form-data; name=\"%s\"" fullword ascii
		$s6 = "Content-Disposition: form-data; name=\"%s\"; filename=\"%s\"" fullword ascii
		$s7 = "Content-Type: multipart/form-data; boundary=--MULTI-PARTS-FORM-DATA-BOUNDARY" fullword ascii
		$s8 = "in Json::Value::find" fullword ascii
		$s9 = "in Json::Value::resolveReference" fullword ascii
		$s10 = "in Json::Value::duplicateAndPrefixStringValue" fullword ascii
		$s11 = ".?AVLogicError@Json@@" fullword ascii
		$s12 = ".?AVRuntimeError@Json@@" fullword ascii
		$s13 = "http:\\\\82.221.101.157:80" ascii
		$s14 = "http://172.223.112.130:80" ascii
		$s15 = "http://172.223.112.130:443" ascii
		$s16 = "http://info.newsrental.net:80" ascii
		$s17 = "%s|%I64d" ascii
		$s18 = "open internet failed..." ascii
		$s19 = "connect failed..." ascii
		$s20 = "handle not opened..." ascii
		$s21 = "corrupted regex pattern" fullword ascii
		$s22 = "add cookie failed..." ascii

	condition:
		uint16( 0 ) == 0x5a4d and 14 of them
}

rule DITEKSHEN_MALWARE_Win_Egregor : FILE
{
	meta:
		description = "Detects Egregor ransomware variants"
		author = "ditekSHen"
		id = "2e24d4ec-39c2-5148-80a1-04f96bc8b477"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2397-L2434"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d39a7bf89a7574f7dfe56db78c8cdbbee97782f829805d4ee87fd9f1635154cd"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Ransomware.Egregor"

	strings:
		$s1 = "C:\\Logmein\\{888-8888-9999}\\Logmein.log" fullword wide
		$p1 = "--deinstall" fullword wide
		$p2 = "--del" fullword wide
		$p3 = "--exit" fullword wide
		$p4 = "--kill" fullword wide
		$p5 = "--loud" fullword wide
		$p6 = "--nooperation" fullword wide
		$p7 = "--nop" fullword wide
		$p8 = "--skip" fullword wide
		$p9 = "--useless" fullword wide
		$p10 = "--yourmommy" fullword wide
		$p11 = "-passegregor" ascii wide
		$p12 = "-peguard" ascii wide
		$p13 = "--nomimikatz" ascii wide
		$p14 = "--multiproc" ascii wide
		$p15 = "--killrdp" ascii wide
		$p16 = "--nonet" ascii wide
		$p17 = "--norename" ascii wide
		$p18 = "--greetings" ascii wide

	condition:
		( uint16( 0 ) == 0x5a4d and pe.is_dll ( ) and ( ( all of ( $s* ) and 1 of ( $p* ) ) or ( 2 of them and filesize < 1000KB and for any i in ( 0 .. pe.number_of_sections ) : ( ( pe.sections [ i ] . name == ".00cfg" ) ) ) ) ) or 8 of ( $p* )
}

rule DITEKSHEN_MALWARE_Win_Redlinedropperexe : FILE
{
	meta:
		description = "Detects executables dropping RedLine infostealer"
		author = "ditekSHen"
		id = "364ba540-60a5-5e1b-bb21-505a442eabb6"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2461-L2484"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "cd1fb4a1d0883221dbdcc519db7f54b0f7285e8a19201dbc586c2520e8086bc2"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.RedLineDropper-EXE"

	strings:
		$s1 = "Wizutezinod togeto0Rowadufevomuki futenujilazem jic lefogatenezinor" fullword wide
		$s2 = "6Tatafamobevofaj bizafoju peyovavacoco lizine kezakajuj" fullword wide
		$s3 = "Lawuherusozeru kucu zam0Zorizeyuk lepaposupu gala kinarusot ruvasaxehuwo" fullword wide
		$s4 = "ClearEventLogW" fullword ascii
		$s5 = "ProductionVersion" fullword wide
		$s6 = "Vasuko)Yugenizugilobo toxocivoriye yexozoyohuzeb" wide
		$s7 = "Yikezevavuzus gucajanesan#Rolapucededoxu xewulep fuwehofiwifi" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( pe.exports ( "_fgeek@8" ) and 2 of them ) or ( 2 of them and for any i in ( 0 .. pe.number_of_sections ) : ( ( pe.sections [ i ] . name == ".rig" ) ) )
}
rule DITEKSHEN_MALWARE_Win_Nibiru : FILE
{
	meta:
		description = "Detects Nibiru ransomware"
		author = "ditekSHen"
		id = "78c3bf75-1ab3-5f88-ba4b-d5a0a906d57c"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2486-L2504"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f3718e9091b09e0f47ecd6715a3a2c160ede6ab9fb144e7ed115dd5a25c8e379"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Ransomware.Nibiru"

	strings:
		$s1 = ".encrypt" fullword wide
		$s2 = "crypted" fullword wide
		$s3 = ".Nibiru" fullword wide
		$s4 = "Encryption Complete" fullword wide
		$s5 = "All your files,documents,important datas,mp4,mp3 and anything valuable" ascii
		$s6 = "EncryptOrDecryptFile" fullword ascii
		$s7 = "get_hacker" ascii
		$s8 = "/C choice /C Y /N /D Y /T 3 & Del \"" fullword wide
		$s9 = "Once You pay,you get the KEY to decrypt files" ascii
		$pdb = "\\Projects\\Nibiru\\Nibiru\\obj\\x86\\Release\\Nibiru.pdb" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 7 of them or ( $pdb and 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Medusalocker : FILE
{
	meta:
		description = "Detects MedusaLocker ransomware"
		author = "ditekshen"
		id = "06b7645f-228d-5ec1-9b82-88caee447a5c"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2506-L2537"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0e2a0a9f12f550a5c6a11731710e0dc2c2e26d17f43d2385bf6e298518631771"
		score = 75
		quality = 73
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Ransomware.MedusaLocker"

	strings:
		$x1 = "\\MedusaLockerInfo\\MedusaLockerProject\\MedusaLocker\\Release\\MedusaLocker.pdb" ascii
		$x2 = "SOFTWARE\\Medusa" wide
		$x3 = "=?utf-8?B?0RFQctTF0YDQcNC60IXQvdC+IEludGVybmV0IED4cGxvseVyIDEz?=" ascii
		$s1 = "Recovery_Instructions.mht" fullword wide
		$s2 = "README_LOCK.TXT" fullword wide
		$s3 = "C:\\Users\\Public\\Desktop" wide
		$s4 = "[LOCKER] " wide
		$s5 = "TmV3LUl0ZW0gJ2" ascii
		$s6 = "<HEAD>=20" ascii
		$s7 = "LIST OF ENCRYPTED FILES" ascii
		$s8 = "KEY.FILE" ascii
		$cmd1 = { 2f 00 63 00 20 00 64 00 65 00 6c 00 20 00 00 00 20 00 3e 00 3e 00 20 00 4e 00 55 00 4c 00 }
		$cmd2 = "vssadmin.exe delete" wide nocase
		$cmd3 = "bcdedit.exe /set {default}" wide
		$cmd4 = "wbadmin delete systemstatebackup" wide nocase
		$mut1 = "{8761ABBD-7F85-42EE-B272-A76179687C63}" fullword wide
		$mut2 = "{3E5FC7F9-9A51-4367-9063-A120244FBEC7}" fullword wide
		$mut3 = "{6EDD6D74-C007-4E75-B76A-E5740995E24C}" fullword wide
		$ext1 = { 2e 00 52 00 65 00 61 00 64 00 49 00 6e 00 73 00 
                  74 00 72 00 75 00 63 00 74 00 69 00 6f 00 6e 00
                  73 00 00 00 00 00 00 00 2e 00 6b 00 65 00 76 00
                  65 00 72 00 73 00 65 00 6e }
		$ext2 = ".exe,.dll,.sys,.ini,.lnk,.rdp,.encrypted" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $x* ) or ( 1 of ( $x* ) and ( 4 of ( $s* ) or 1 of ( $mut* ) ) ) or 6 of ( $s* ) or ( 1 of ( $mut* ) and 2 of ( $cmd* ) ) or ( 1 of ( $ext* ) and 5 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Ransomexx : FILE
{
	meta:
		description = "Detects RansomEXX ransomware"
		author = "ditekshen"
		id = "4d1294de-d73c-5f9c-adb7-18ce5b5aca9f"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2539-L2555"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "351398d89b847b3439fa58b7aab50f3c6e48be27877d3f8b85cc78e994413ecc"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Ransomware.RansomEXX"

	strings:
		$id = "ransom.exx" ascii
		$s1 = "!TXDOT_READ_ME!.txt" fullword wide
		$s2 = "debug.txt" fullword wide
		$s3 = ".txd0t" fullword wide
		$s4 = "crypt_detect" fullword wide
		$s5 = "powershell.exe" fullword wide
		$s6 = "cipher.exe" fullword ascii wide
		$s7 = "?ReflectiveLoader@@" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( $id and 3 of ( $s* ) ) or all of ( $* ) )
}
rule DITEKSHEN_MALWARE_Win_Quasarstealer : FILE
{
	meta:
		description = "Detects Quasar infostealer"
		author = "ditekshen"
		id = "d0d532fe-bd0a-560a-8570-f6038d694338"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2557-L2572"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4b6ab49992db4d7bf4404d51b0ef1773249de89545ec31176ad45d00803ba703"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.QuasarStealer"

	strings:
		$s1 = "PGma.System.MouseKeyHook, Version=5.6.130.0, Culture=neutral, PublicKeyToken=null" fullword ascii
		$s2 = "DQuasar.Common, Version=1.4.0.0, Culture=neutral, PublicKeyToken=null" fullword ascii
		$s3 = "Process already elevated." fullword wide
		$s4 = "get_PotentiallyVulnerablePasswords" fullword ascii
		$s5 = "GetKeyloggerLogsDirectory" ascii
		$s6 = "set_PotentiallyVulnerablePasswords" fullword ascii
		$s7 = "BQuasar.Client.Extensions.RegistryKeyExtensions+<GetKeyValues>" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Bandook : FILE
{
	meta:
		description = "Detects Bandook backdoor"
		author = "ditekshen"
		id = "c74bd688-c79e-5939-93a8-c2cd9f2cd60e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2676-L2705"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "bff09f769aae890d81efe9926cc8ce85c1caa4eeeb6bc7d2321d2d906ac8d6cf"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.Bandook"

	strings:
		$s1 = "\"%sLib\\dpx.pyc\" \"%ws\" \"%ws\" \"%ws\" \"%ws\" \"%ws\"" fullword wide
		$s2 = "%s\\usd\\dv-%s.dat" fullword ascii
		$s3 = "%sprd.dat" fullword ascii
		$s4 = "%sfile\\shell\\open\\command" fullword ascii
		$s5 = "explorer.exe , %s" fullword ascii
		$f1 = "CaptureScreen" fullword ascii
		$f2 = "StartShell" fullword ascii
		$f3 = "ClearCred" fullword ascii
		$f4 = "GrabFileFromDevice" fullword ascii
		$f5 = "PutFileOnDevice" fullword ascii
		$f6 = "ChromeInject" fullword ascii
		$f7 = "StartFileMonitor" fullword ascii
		$f8 = "DisableMouseCapture" fullword ascii
		$f9 = "StealUSB" fullword ascii
		$f10 = "DDOSON" fullword ascii
		$f11 = "InstallMac" fullword ascii
		$f12 = "SendCam" fullword ascii
		$x1 = "RTC-TGUBP" fullword ascii
		$x2 = "AVE_MARIA" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or 6 of ( $f* ) or ( 2 of ( $s* ) and 3 of ( $f* ) ) or ( all of ( $x* ) and ( 2 of ( $f* ) or 3 of ( $s* ) ) ) )
}
rule DITEKSHEN_MALWARE_Win_Kimsuky : FILE
{
	meta:
		description = "Detects Kimsuky backdoor"
		author = "ditekshen"
		id = "6216b874-13f1-5283-9d17-90b7ca6996f8"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2707-L2730"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9f9e64a9cfb3f61bc6b355035c5f0644e4750b740e05cb557c6183c7acfc5a19"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.Kimsuky"

	strings:
		$s1 = "Win%d.%d.%dx64" fullword ascii
		$s2 = ".zip" fullword ascii
		$s3 = ".enc" fullword ascii
		$s4 = "&p2=a" fullword ascii
		$s5 = "Content-Disposition: form-data; name=\"binary\"; filename=\"" fullword ascii
		$s6 = "%s/?m=a&p1=%s&p2=%s-%s-v%d" fullword ascii
		$s7 = "/?m=b&p1=" fullword ascii
		$s8 = "/?m=c&p1=" fullword ascii
		$s9 = "/?m=d&p1=" fullword ascii
		$s10 = "http://%s/%s/?m=e&p1=%s&p2=%s&p3=%s" fullword ascii
		$s11 = "taskkill.exe /im iexplore.exe /f" fullword ascii
		$s12 = "GetParent" fullword ascii
		$s13 = "DllRegisterServer" fullword ascii
		$dll1 = "AutoUpdate.dll" fullword ascii
		$dll2 = "dropper-ie64.dll" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $dll* ) and 7 of ( $s* ) ) or ( 11 of ( $* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Salfram : FILE
{
	meta:
		description = "Detects Salfram executables"
		author = "ditekSHen"
		id = "323e1c8e-2184-5831-9af5-a460c55fbf7c"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2755-L2766"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "19d7934727baa870dcd3ec77ba596cd64e49763477ba3feb7baec5ab6d3866d3"
		score = 75
		quality = 75
		tags = "FILE"
		snort2_sid = "920085-920087"
		snort3_sid = "920085"
		clamav_sig = "MALWARE.Win.Trojan.Salfram"

	strings:
		$s1 = "!This Salfram cannot be run in DOS mode." fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Hawkeyev9
{
	meta:
		description = "Detects HawkEyeV9 payload"
		author = "ditekshen"
		id = "ca59aa45-fb55-5f9a-a224-8bd2b72ce5ac"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2768-L2793"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d24111930dd0230c01963a90c9fbbc0a0a71df170c2ca116bb329e6158cb681c"
		score = 75
		quality = 75
		tags = ""
		clamav_sig = "MALWARE.Win.Trojan.HawkEyeV9"

	strings:
		$id1 = "HawkEye Keylogger - Reborn v9 - {0} Logs - {1} \\ {2}" wide
		$id2 = "HawkEye Keylogger - Reborn v9{0}{1} Logs{0}{2} \\ {3}{0}{0}{4}" wide
		$str1 = "_PasswordStealer" ascii
		$str2 = "_KeyStrokeLogger" ascii
		$str3 = "_ScreenshotLogger" ascii
		$str4 = "_ClipboardLogger" ascii
		$str5 = "_WebCamLogger" ascii
		$str6 = "_AntiVirusKiller" ascii
		$str7 = "_ProcessElevation" ascii
		$str8 = "_DisableCommandPrompt" ascii
		$str9 = "_WebsiteBlocker" ascii
		$str10 = "_DisableTaskManager" ascii
		$str11 = "_AntiDebugger" ascii
		$str12 = "_WebsiteVisitorSites" ascii
		$str13 = "_DisableRegEdit" ascii
		$str14 = "_ExecutionDelay" ascii
		$str15 = "_InstallStartupPersistance" ascii

	condition:
		int16 ( 0 ) == 0x5a4d and ( 1 of ( $id* ) or 5 of ( $str* ) )
}
rule DITEKSHEN_MALWARE_Win_Hyperbro : FILE
{
	meta:
		description = "Detects HyperBro (class names) payload"
		author = "ditekSHen"
		id = "539b796d-297b-5e2f-84df-282ceaa57bd4"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2795-L2813"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f6e86ef963de885e0bf92ead075e265618c0745104d223302edd824d409c45cd"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.HyperBro"

	strings:
		$s1 = "VTClipboardInfo" ascii wide
		$s2 = "VTClipboardMgr" ascii wide
		$s3 = "VTFileRename" ascii wide
		$s4 = "VTFileRetime" ascii wide
		$s5 = "VTKeyboardInfo" ascii wide
		$s6 = "VTKeyboardMgr" ascii wide
		$s7 = "VTRegeditKeyInfo" ascii wide
		$s8 = "VTRegeditMgr" ascii wide
		$s9 = "VTRegeditValueInfo" ascii wide
		$s10 = "VTFileDataRes" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and 9 of them
}
rule DITEKSHEN_MALWARE_Linux_UNK01 : FILE
{
	meta:
		description = "Detects unknown/unidentified Linux malware"
		author = "ditekSHen"
		id = "24c6ff35-9378-5a6b-90d1-9740917b1b72"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2815-L2836"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "8bb4822c1c7e0f52726ecafafa696d83c741257587f351360c5295163c245450"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$f1 = "%sresponse.php?status" ascii
		$f2 = "%supstream.php?mid=%s&os=%s" ascii fullword
		$f3 = "%supstream.php?tid=%" ascii
		$f4 = "%sindex.php?token=%.32s&flag=%d&name=%s" ascii fullword
		$f5 = "%sactive_off.php?id=%d&uniqu=%d" ascii fullword
		$s1 = "lock:%i usable num:%i n:%i" fullword ascii
		$s2 = "tid:%.*s tNumber:%i" fullword ascii
		$s3 = "init.php" fullword ascii
		$s4 = "mod_drone" fullword ascii
		$s5 = "new_mid" fullword ascii
		$s6 = "&exists[]=" fullword ascii
		$s7 = "&mod[]=" fullword ascii
		$s8 = "shutdown" fullword ascii
		$s9 = "&mac[]=%02X%02X%02X%02X%02X%02X" fullword ascii

	condition:
		uint16( 0 ) == 0x457f and ( 3 of ( $f* ) or 6 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Linux_UNK02 : FILE
{
	meta:
		description = "Detects unknown/unidentified Linux malware"
		author = "ditekSHen"
		id = "6e62df0d-d329-5e52-af74-2a1f19dc4cca"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2838-L2852"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4cde21932c27fe3c08495f557b5e086b1fb668d8b5508249891828b9ed48edd4"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$rf1 = "[]A\\A]A^A_" ascii
		$rf2 = "[A\\A]A^A_]" ascii
		$f1 = "/bin/basH" ascii fullword
		$f2 = "/proc/seH" ascii fullword
		$f3 = "/dev/ptsH" ascii fullword
		$f4 = "pqrstuvwxyzabcde" ascii fullword
		$f5 = "libnss_%s.so.%d.%d" ascii fullword

	condition:
		uint16( 0 ) == 0x457f and ( all of ( $f* ) and #rf1 > 3 and #rf2 > 3 )
}
rule DITEKSHEN_MALWARE_Win_Itranslatordll : FILE
{
	meta:
		description = "Detects iTranslator DLL payload"
		author = "ditekSHen"
		id = "df05da78-3626-5eb5-81a2-a93fba844484"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2876-L2892"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ca0479efd241058f358553b6382a1987a5b4c069965f4adb88cd2f3fc4bef21a"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.iTranslator_DLL"

	strings:
		$d1 = "system32\\drivers\\%S.sys" fullword wide
		$d2 = "\\windows\\system32\\winlogon.exe" fullword ascii
		$d3 = "\\Registry\\Machine\\SYSTEM\\ControlSet001\\services\\%s" fullword wide
		$d4 = "\\Registry\\Machine\\SYSTEM\\ControlSet001\\services\\webssx" fullword wide
		$d5 = "\\Device\\CtrlSM" fullword wide
		$d6 = "\\DosDevices\\CtrlSM" fullword wide
		$d7 = "\\driver_wfp\\CbFlt\\Bin\\CbFlt.pdb" ascii
		$d8 = ".php" ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Caspertroy : FILE
{
	meta:
		description = "Detects CasperTroy payload"
		author = "ditekSHen"
		id = "822c3231-60ba-5e60-8df8-06dea80b318a"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2919-L2931"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ce070b1e6279ef9fa47f84da7c5166cd93b3e7a0f95541ae14c048b2af9bc431"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "DllTroy.dll" fullword ascii
		$s2 = "Content-Disposition: form-data; name=\"image\"; filename=\"title.gif\"" fullword ascii
		$s3 = "Content-Disposition: form-data; name=\"COOKIE_ID\"" fullword ascii
		$s4 = "Content-Disposition: form-data; name=\"PHP_SESS_ID\"" fullword ascii
		$s5 = "Content-Disposition: form-data; name=\"SESS_ID\"" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Win_Rasftuby : FILE
{
	meta:
		description = "Detects Rasftuby/DarkCrystal"
		author = "ditekSHen"
		id = "908624a8-0068-5512-a5d0-77ce1f4efd80"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2933-L2950"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b769c1986d23173cf8a8a3c8a14d388a7c0327e46d936fc97c449dc55f2a5575"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.DarkCrystal.RAT-Rasftuby"

	strings:
		$s1 = "/DCRS/main.php?data=active" fullword ascii wide
		$s2 = "/socket.php?type=__ds_" ascii wide
		$s3 = "/uploader.php" fullword ascii wide
		$s4 = "del \\\"%USERPROFILE%\\\\AppData\\\\Roaming\\\\Microsoft\\\\Windows\\\\Start Menu\\\\Programs\\\\Startup\\\\System.lnk\\\"" fullword ascii wide
		$s5 = "Host:{0},Port:{1},User:{2},Pass:{3}<STR>" fullword ascii wide
		$s6 = "keyloggerstart_status" fullword ascii wide
		$s7 = "keyloggerstop_status" fullword ascii wide
		$s8 = "[PRINT SCREEN]" fullword ascii wide
		$s9 = "DCS.Internal" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of ( $s* )
}
rule DITEKSHEN_MALWARE_Win_Protonbot : FILE
{
	meta:
		description = "Detects ProtonBot loader"
		author = "ditekSHen"
		id = "b0d08378-0297-5e70-99f1-1dc0fec6fa01"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2952-L2969"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b511dfd47109d36ffc7fcb23b49779e1164d50a28061ab724d7a2c744ac23ac8"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.ProtonBot"

	strings:
		$x1 = "\\PROTON\\Release\\build.pdb" ascii
		$x2 = "\\proton\\proton bot\\json.hpp" wide
		$x3 = "proton bot" ascii wide
		$s1 = "endptr == token_buffer.data() + token_buffer.size()" fullword wide
		$s2 = "ranges.size() == 2 or ranges.size() == 4 or ranges.size() == 6" fullword wide
		$s3 = "ref_stack.back()->is_array() or ref_stack.back()->is_object()" fullword wide
		$s4 = "ktmw32.dll" fullword ascii
		$s5 = "@detail@nlohmann@@" ascii
		$s6 = "urlmon.dll" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $x* ) or ( all of ( $s* ) and 1 of ( $x* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Imminentrat : FILE
{
	meta:
		description = "Detects ImminentRAT"
		author = "ditekSHen"
		id = "99831b32-d8a0-5814-bf41-491f607ee825"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2971-L2994"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f959fd28e818b17c962fcd5bb99fa5ac0058f22494950e0200f139703f3e756a"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "abuse@imminentmethods.net" ascii
		$x2 = "Imminent-Monitor-" ascii
		$x3 = "AddressChangeListener" fullword ascii
		$x4 = "SevenZipHelper" fullword ascii
		$x5 = "WrapNonExceptionThrows" fullword ascii
		$s1 = "_ENABLE_PROFILING" wide
		$s2 = "Anti-Virus: {0}" wide
		$s3 = "File downloaded & executed" wide
		$s4 = "Chat - You are speaking with" wide
		$s5 = "\\Imminent\\Plugins" wide
		$s6 = "\\Imminent\\Path.dat" wide
		$s7 = "\\Imminent\\Geo.dat" wide
		$s8 = "DisableTaskManager = {0}" wide
		$s9 = "This client is already mining" wide
		$s10 = "Couldn't get AV!" wide
		$s11 = "Couldn't get FW!" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 4 of ( $x* ) or 5 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Warzonerat : FILE
{
	meta:
		description = "Detects AveMaria/WarzoneRAT"
		author = "ditekSHen"
		id = "4f3df696-280c-5f2b-9511-8cc7c9dff1d6"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L2996-L3011"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "1af8b0f90b0de3287499082a6d6d9da6ed62a3110018e0c0f7149353693060b2"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "RDPClip" fullword wide
		$s2 = "Grabber" fullword wide
		$s3 = "Ave_Maria Stealer OpenSource" wide
		$s4 = "\\MidgetPorn\\workspace\\MsgBox.exe" wide
		$s5 = "@\\cmd.exe" wide
		$s6 = "/n:%temp%\\ellocnak.xml" wide
		$s7 = "Hey I'm Admin" wide
		$s8 = "warzone160" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of ( $s* )
}
rule DITEKSHEN_MALWARE_Win_Karaganycore : FILE
{
	meta:
		description = "Detects Karagany/xFrost core plugin"
		author = "ditekSHen"
		id = "c066805b-9373-5524-aff9-d16cd59f5a24"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3013-L3027"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "cde96ac6477fda1312ce4f7532018c9f11df7d39c40155d10bdde0e3d84c6d57"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "127.0.0.1" fullword ascii
		$s2 = "port" fullword ascii
		$s3 = "C:\\Windows\\System32\\Kernel32.dll" fullword ascii
		$s4 = "kernel32.dll" fullword ascii
		$s5 = "http" ascii
		$s6 = "Move" fullword ascii
		$s7 = "<supportedOS Id=\"{" ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Karaganyscreenutil : FILE
{
	meta:
		description = "Detects Karagany/xFrost ScreenUtil module"
		author = "ditekSHen"
		id = "5eab1bb9-a433-54e6-963b-4aca863dc73f"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3043-L3055"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d10230d94adfdddd604e2569ae3323efa1d5722647b9c704fceefe9446ccebd1"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "__pic__" ascii wide
		$s2 = "__pickill__" ascii wide
		$s3 = "\\picture.png" fullword wide
		$s4 = "%d.jpg" wide
		$s5 = "\\Update\\Tmp" wide

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Win_Karaganylistrix : FILE
{
	meta:
		description = "Detects Karagany/xFrost Listrix module"
		author = "ditekSHen"
		id = "837cc9e7-eefb-530c-854b-51bb4444ae78"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3057-L3069"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "02216061dbe93b7bea108f4b27c052d87c14cfe9395c6c5d4eed46ed7819e7ae"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\Update\\Tmp\\" wide
		$s2 = "*pass*.*" fullword wide
		$s3 = ">> NUL" wide
		$s4 = "%02d.%02d.%04d %02d:%02d" wide
		$s5 = "/c del" wide

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Osx_Macsearch : FILE
{
	meta:
		description = "Detects MacSearch adware"
		author = "ditekSHen"
		id = "facdf05c-5ee4-54c6-9ca3-01978af2b6e6"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3071-L3092"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "973b7215fc8d04685a46d05b53b4092e7b81ed0d64d6982b534f2b89d0a59443"
		score = 75
		quality = 71
		tags = "FILE"

	strings:
		$s1 = "open -a safari" ascii
		$s2 = "/INDownloader" ascii
		$s3 = "/safefinder" ascii
		$s4 = "/INEncryptor" ascii
		$s5 = "/INInstallerFlow" ascii
		$s6 = "/INConfiguration" ascii
		$s7 = "/INChromeAndFFSetter" ascii
		$s8 = "/INSafariSetter" ascii
		$s9 = "/bin/launchctl" fullword ascii
		$s10 = "/usr/bin/csrutil" fullword ascii
		$s11 = "_Tt%cSs%zu%.*s%s" fullword ascii
		$s12 = "_Tt%c%zu%.*s%zu%.*s%s" fullword ascii
		$s13 = "/macap/safefinder_Obf/safefinder/" ascii
		$s14 = "/safefinder.build/Release/macsearch.build/" ascii

	condition:
		uint16( 0 ) == 0xfacf and 10 of them
}
rule DITEKSHEN_MALWARE_Osx_Genieo : FILE
{
	meta:
		description = "Detects LinqurySearch/Genieo adware"
		author = "ditekSHen"
		id = "ac44eefd-bf1c-5d4b-bcd4-9a5d394ac1d3"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3094-L3112"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "951dc8539435a52d9eea00b3fdaf98cf618c03867066819f2f9244165e57c675"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Osx.Trojan.Genieo"

	strings:
		$s1 = "<key>com.apple.security.get-task-allow</key>" fullword ascii
		$s2 = "U1QQFXAfCxAfRUNCH1JZXh9" ascii
		$s3 = "XVFTQ1VRQlNYH" ascii
		$s4 = "dF9HXlxfUVQQVUJCX0IQHRB" ascii
		$s5 = "Value:forHTTPHeaderField:" ascii
		$s6 = "postContent:::" fullword ascii
		$s7 = "postLog:" fullword ascii
		$s8 = "initWithBase64EncodedString:options:" fullword ascii
		$s9 = "do shell script \"%@\" with administrator privileges" fullword ascii
		$s10 = /LinqurySearch-[a-f0-9]{40,}/

	condition:
		uint16( 0 ) == 0xfacf and 6 of them
}
rule DITEKSHEN_MALWARE_Osx_AMCPCVARK : FILE
{
	meta:
		description = "Detects OSX TechyUtils/PCVARK adware"
		author = "ditekSHen"
		id = "1378364b-db10-5194-98f8-5347504a92e6"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3114-L3139"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b18a9f578af98feb5107d9ef85850457ba5921ab58af7b097a815e3af74f05f7"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Osx.Adware.AMC-PCVARK-TechyUtils"

	strings:
		$s1 = "Mac Auto Fixer.app" fullword ascii
		$s2 = "com.techyutil.macautofixer" fullword ascii
		$s3 = "com.findApp.findApp" ascii
		$s4 = "Library/Preferences/%@.plist" fullword ascii
		$s5 = "Library/%@/%@" fullword ascii
		$s6 = "Library/Application Support/%@/%@" fullword ascii
		$s7 = "sleep 3; rm -rf \"%@\"" fullword ascii
		$s8 = "Silently calling url: %@" ascii
		$cnc1 = "cloudfront.net/getdetails" ascii
		$cnc2 = "trk.entiretrack.com/trackerwcfsrv/tracker.svc/trackOffersAccepted/?" ascii
		$cnc3 = "pxl=%@&x-count=1&utm_source=%@&lpid=0&utm_content=&utm_term=&x-base=&utm_medium=%@&utm_publisher=%@&offerpxl=&x-fetch=1&utm_campaign=@&affiliateid=&x-at=&btnid=" ascii
		$x1 = "mafsysinfo" fullword ascii
		$x2 = "MAF4497_MAF4399_MAF2204" ascii
		$developerid = "Developer ID Application: Rahul Gahlot (RZ74UYT742)" ascii

	condition:
		uint16( 0 ) == 0xfacf and ( 6 of ( $s* ) or 2 of ( $cnc* ) or all of ( $x* ) or $developerid )
}
rule DITEKSHEN_MALWARE_Osx_Windtrail : FILE
{
	meta:
		description = "Detects WindTrail OSX trojan"
		author = "ditekSHen"
		id = "abf7cd20-b37d-5d0a-8f3f-f4e491965713"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3189-L3206"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "291f919cb1e8c4b33960dd3f2c842b9efec04852bd5661543e3ee60bc0fc5ba6"
		score = 75
		quality = 73
		tags = "FILE"
		clamav_sig = "MALWARE.Osx.Trojan.WindTrail"

	strings:
		$s1 = "m_ComputerName_UserName" fullword ascii
		$s2 = "m_uploadURL" fullword ascii
		$s3 = "m_logString" fullword ascii
		$s4 = "GenrateDeviceName" fullword ascii
		$s5 = "open -a" fullword ascii
		$s6 = "AESEncryptFile:toFile:usingPassphrase:error:" fullword ascii
		$s7 = "scheduledTimerWithTimeInterval:target:selector:userInfo:repeats:" fullword ascii
		$s8 = "_kLSSharedFileListSessionLoginItems" fullword ascii
		$developerid = "Developer ID Application: warren portman (95RKE2AA8F)" ascii

	condition:
		uint16( 0 ) == 0xfacf and ( all of ( $s* ) or $developerid )
}
rule DITEKSHEN_MALWARE_Osx_Techyutils : FILE
{
	meta:
		description = "Detects TechyUtils OSX packages"
		author = "ditekSHen"
		id = "59fd4165-987f-5b68-9341-d78184b25a1c"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3208-L3224"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "071c67cace09dd66233bd4c4dd78c32d0f39f7e38dc06ec62e09fef67762d098"
		score = 75
		quality = 73
		tags = "FILE"
		clamav_sig = "MALWARE.Osx.Trojan.TechyUtils"

	strings:
		$s1 = "__ZL58__arclite_NSMutableDictionary__" ascii
		$s2 = "__ZL46__arclite_NSDictionary_" ascii
		$s3 = "<key>com.apple.security.get-task-allow</key>" fullword ascii
		$s4 = "/productprice.svc/GetCountryCode" ascii
		$s5 = "@_pthread_mutex_lock" fullword ascii
		$s6 = "_mh_execute_header" fullword ascii
		$s7 = "/Users/prasoon/Documents/" ascii
		$developerid = "Developer ID Application: Techyutils Software Private Limited (VS9Q8BRRRJ)" ascii

	condition:
		uint16( 0 ) == 0xfacf and ( all of ( $s* ) or $developerid )
}
rule DITEKSHEN_MALWARE_Win_Dlagent04 : FILE
{
	meta:
		description = "Detects known downloader agent downloading encoded binaries in patches from paste-like websites, most notably hastebin"
		author = "ditekSHen"
		id = "d591c591-aecc-557e-85b4-1e2589fbfbf9"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3247-L3263"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "73e6af7c32d38ec5d1d2bc9f2517860367b46779b53e0faff8885b655561ab01"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.DLAgent04"

	strings:
		$x1 = "@@@http" ascii wide
		$s1 = "HttpWebRequest" fullword ascii
		$s2 = "GetResponseStream" fullword ascii
		$s3 = "set_FileName" fullword ascii
		$s4 = "set_UseShellExecute" fullword ascii
		$s5 = "WebClient" fullword ascii
		$s6 = "set_CreateNoWindow" fullword ascii
		$s7 = "DownloadString" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 300KB and #x1 > 1 and 4 of ( $s* )
}
rule DITEKSHEN_MALWARE_Win_STOP : FILE
{
	meta:
		description = "Detects STOP ransomware"
		author = "ditekSHen"
		id = "e928d917-a9d9-5830-938a-59b62608e84c"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3286-L3309"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "61f7e7c1139c56088b2f58b78ae132ffcfef0f931c15b67ea775b0d5e51d189d"
		score = 75
		quality = 73
		tags = "FILE"
		snort2_sid = "920113"
		snort3_sid = "920111"
		clamav_sig = "MALWARE.Win.Ransomware.STOP"

	strings:
		$x1 = "C:\\SystemID\\PersonalID.txt" fullword wide
		$x2 = "/deny *S-1-1-0:(OI)(CI)(DE,DC)" wide
		$x3 = "e:\\doc\\my work (c++)\\_git\\encryption\\" ascii wide nocase
		$s1 = "\" --AutoStart" fullword ascii wide
		$s2 = "--ForNetRes" fullword wide
		$s3 = "--Admin" fullword wide
		$s4 = "%username%" fullword wide
		$s5 = "?pid=" fullword wide
		$s6 = /&first=(true|false)/ fullword wide
		$s7 = "delself.bat" ascii
		$mutex1 = "{1D6FC66E-D1F3-422C-8A53-C0BBCF3D900D}" fullword ascii
		$mutex2 = "{FBB4BCC6-05C7-4ADD-B67B-A98A697323C1}" fullword ascii
		$mutex3 = "{36A698B9-D67C-4E07-BE82-0EC5B14B4DF5}" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 2 of ( $x* ) and 1 of ( $mutex* ) ) or ( all of ( $x* ) ) or ( 6 of ( $s* ) and ( 1 of ( $x* ) or 1 of ( $mutex* ) ) ) or ( 9 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Parallaxrat : FILE
{
	meta:
		description = "Detects ParallaxRAT"
		author = "ditekSHen"
		id = "e602b28f-ae5d-52af-b1c5-5c41776dd4c5"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3311-L3328"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "7fd94dee44079b595b906f1687f44b51b8cebabbeb0900563b8d4fcc0e46bdd0"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.ParallaxRAT"

	strings:
		$s1 = "[Clipboard End]" fullword wide
		$s2 = "[Ctrl +" fullword wide
		$s3 = "[Alt +" fullword wide
		$s4 = "Clipboard Start" wide
		$s5 = "(Wscript.ScriptFullName)" wide
		$s6 = "CSDVersion" fullword ascii
		$s7 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion" fullword ascii
		$x1 = { 2e 65 78 65 00 00 84 00 00 4d 5a 90 00 }
		$x2 = "This program cannot be run in DOS mode" ascii

	condition:
		(( uint16( 0 ) == 0x5a4d and all of ( $s* ) ) or all of them )
}
rule DITEKSHEN_MALWARE_Win_Meterpreter : FILE
{
	meta:
		description = "Detects Meterpreter payload"
		author = "ditekSHen"
		id = "d72fef80-d624-5e39-963a-8d7c12eb2d9c"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3330-L3343"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5226cd7bb2344b822ee94d75f81a523ff701778de97a32ae52c604a4855e960c"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "PACKET TRANSMIT" fullword ascii
		$s2 = "PACKET RECEIVE" fullword ascii
		$s3 = "\\\\%s\\pipe\\%s" fullword ascii wide
		$s4 = "%04x-%04x:%s" fullword wide
		$s5 = "server.dll" fullword ascii

	condition:
		( uint16( 0 ) == 0x5a4d and all of them ) or ( filesize < 300KB and all of them )
}
rule DITEKSHEN_MALWARE_Win_Trojan_Expresscms : FILE
{
	meta:
		description = "Detects ExpressCMS"
		author = "ditekSHen"
		id = "d096db0c-05f6-5b69-9d84-0105f2182ff3"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3366-L3382"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "64d551e0c11b6394f9ae2b8fa749c36cb1b5c3f498592f95dc19fdea23c53160"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.ExpressCMS"

	strings:
		$s1 = "/click.php?cnv_id=" fullword wide
		$s2 = "/click.php?key=" wide
		$s3 = "jdlnb" fullword wide
		$s4 = "Gkjfdshfkjjd: dsdjdsjdhv" fullword wide
		$s5 = "--elevated" fullword wide
		$s6 = "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\%d" wide
		$s7 = "\\Microsoft\\Manager.exe" fullword wide
		$s8 = "\\Microsoft\\svchost.exe" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Meterpreterstager : FILE
{
	meta:
		description = "Detects Meterpreter stager payload"
		author = "ditekSHen"
		id = "dfbc37e9-13e0-55e2-a501-1005eea52b63"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3384-L3395"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0ac53a10abb1e4dd7da57872cd1779851d953127a912c31a5e411d8eb9bd07f4"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "PAYLOAD:" fullword ascii
		$s2 = "AQAPRQVH1" fullword ascii
		$s3 = "ws2_32" fullword ascii
		$s4 = "KERNEL32.dll" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them and filesize < 100KB
}
rule DITEKSHEN_MALWARE_Win_Ziggy : FILE
{
	meta:
		description = "Detects Ziggy ransomware"
		author = "ditekSHen"
		id = "6d2d316a-cf19-5001-bf94-842346229d76"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3397-L3421"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "103a50511971161ca673e0c8378aeca2fa7d0f6309966bbb2b70e0d039e0f196"
		score = 75
		quality = 75
		tags = "FILE"
		snort2_sid = "920098"
		snort3_sid = "920096"
		clamav_sig = "MALWARE.Win.Ransomware.Ziggy"

	strings:
		$id1 = "/Ziggy Info;component/mainwindow.xaml" fullword wide
		$id2 = "AZiggy Info, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null" fullword ascii
		$id3 = "Ziggy Ransomware" fullword wide
		$id4 = "clr-namespace:Zeggy" fullword ascii
		$s1 = "GetCooldown" fullword ascii
		$s2 = "checkCommandMappings" fullword ascii
		$s3 = "add_OnExecuteCommand" fullword ascii
		$s4 = "MindLated.jpg" fullword wide
		$s5 = "http://fixfiles.xyz/ziggy/api/info.php?id=" fullword wide
		$s6 = "Reamaining time:" fullword wide
		$msg1 = "<:In case of no answer in 12 hours write us to this e-mail" ascii
		$msg2 = "Free decryption as guarantee" fullword ascii
		$msg3 = "# Do not try to decrypt your data using third party software, it may cause permanent data loss" ascii
		$msg4 = "# Decryption of your files with the help of third parties may cause increased price (they add their fee to our) or you can becom" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $id* ) or 4 of ( $s* ) or 3 of ( $msg* ) )
}
rule DITEKSHEN_MALWARE_Win_Nworm : FILE
{
	meta:
		description = "Detects NWorm/N-W0rm payload"
		author = "ditekSHen"
		id = "06546ccf-8914-5b1c-942f-99664b9ecf44"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3423-L3443"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a1397a057422be260b5bdf1eb58571e95c259c132cc2518b39e1524a0eda9c66"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.NWorm"

	strings:
		$id1 = "N-W0rm" ascii
		$id2 = "N_W0rm" ascii
		$x1 = "pongPing" fullword wide
		$x2 = "|NW|" fullword wide
		$s1 = "runFile" fullword wide
		$s2 = "runUrl" fullword wide
		$s3 = "killer" fullword wide
		$s4 = "powershell" fullword wide
		$s5 = "wscript.exe" fullword wide
		$s6 = "ExecutionPolicy Bypass -WindowStyle Hidden -NoExit -File \"" fullword wide
		$s7 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36" fullword wide
		$s8 = "Start-Sleep -Seconds 1.5; Remove-Item -Path '" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $id* ) and ( 1 of ( $x* ) or 3 of ( $s* ) ) ) or ( all of ( $x* ) and 2 of ( $s* ) ) or 7 of ( $s* ) or 10 of them )
}
rule DITEKSHEN_MALWARE_Win_Qakbot : FILE
{
	meta:
		description = "Detects variants of QakBot payload"
		author = "ditekSHen"
		id = "3a3b3b6c-0969-584e-a184-7acfca3cdd42"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3445-L3457"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b64c05eb7ac03b2b4709f9979d117e4cacc617f21d0b3bf1c1be42aa18cc44cc"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "stager_1.dll" fullword ascii
		$s2 = "_vsnwprintf" fullword ascii
		$s3 = "DllRegisterServer" fullword ascii
		$s4 = "Win32_PnPEntity" fullword wide
		$s5 = "0>user32.dll" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Fonix : FILE
{
	meta:
		description = "Detects Fonix ransomware"
		author = "ditekSHen"
		id = "d67cce49-5f4f-59f6-b2a9-9c4dd1c6c0f6"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3459-L3481"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "159b8946f7772c76271de821eb12897689bf73d96fc6a1d7c4a65cdc50b877c7"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Ransomware.Fonix"

	strings:
		$s1 = "dontcryptanyway" fullword wide
		$s2 = "Cpriv.key" ascii wide
		$s3 = "Cpub.key" ascii wide
		$s4 = "NetShareEnum() failed!Error: % ld" fullword wide
		$s5 = "<div class='title'> Attention!</div><ul><li><u><b>DO NOT</b> pay" wide
		$s6 = "Encryption Completed !!!" fullword wide
		$s7 = "kill process" fullword ascii
		$s8 = "Copy SystemID C:\\ProgramData\\SystemID" ascii
		$id1 = "].FONIX" fullword wide
		$id2 = "xinofconfig.txt" fullword ascii wide
		$id3 = "XINOF4MUTEX" wide
		$id4 = ":\\Fonix\\cryptoPP\\" ascii
		$id5 = "schtasks /CREATE /SC ONLOGON /TN fonix" ascii
		$id6 = "Ransomware\\Fonix" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 6 of ( $s* ) or 3 of ( $id* ) or ( 1 of ( $id* ) and 3 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Bobik : FILE
{
	meta:
		description = "Detects Bobik infostealer"
		author = "ditekSHen"
		id = "12f14151-0c89-519d-85d3-4b4b82a950a3"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3483-L3498"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "735dcb9e04956863305ca89a43686b8e48e3b20784ae9292cfc40d1c2c09d467"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.Bobik"

	strings:
		$s1 = "@Default\\Login Data" fullword ascii
		$s2 = "@Default\\Cookies" fullword ascii
		$s3 = "@logins.json" fullword ascii
		$s4 = "@[EXECUTE]" fullword ascii
		$s5 = "@C:\\Windows\\System32\\cmd.exe" fullword ascii
		$s6 = /(CHROME|OPERA|FIREFOX)_BASED/ fullword ascii
		$s7 = "threads.nim" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Dlagent05 : FILE
{
	meta:
		description = "Detects an unknown dropper. Typically exisys as a DLL in base64-encoded gzip-compressed file embedded within another executable"
		author = "ditekSHen"
		id = "a8a72484-42be-5c5c-962b-75bed8acdf39"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3538-L3551"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e8c7c03451bbfcba7a1ab02f8c1320ad50d17d2e990f0e2f89942faea2a1e531"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.Trojan.DLAgent05"

	strings:
		$s1 = "MARCUS.dll" fullword ascii wide
		$s2 = "GZipStream" fullword ascii
		$s3 = "MemoryStream" fullword ascii
		$s4 = "proj_name" fullword ascii
		$s5 = "res_name" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Nemty : FILE
{
	meta:
		description = "Detects Nemty/Nefilim ransomware"
		author = "ditekSHen"
		id = "361269c6-5215-5ecf-869c-3c55ff8387e1"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3553-L3577"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "dcebcddc472f4fb3bb34c35fc5a5424e54bfc3a262fdae10b189d210217b9b37"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Go build ID:" ascii
		$s2 = "GOMAXPROCSGetIfEntryGetVersionGlagoliticKharoshthiManichaeanOld_ItalicOld_PermicOld_TurkicOther_MathPOSTALCODEPhoenicianSaurasht" ascii
		$s3 = "crypto/x509.ExtKeyUsage" ascii
		$s4 = "crypto/x509.KeyUsageContentCommitment" ascii
		$s5 = "DEK-Info header" ascii
		$s6 = "GetUserProfileDirectoryWMagallanes Standard TimeMontevideo Standard TimeNorth Asia Standard TimePacific SA Standard TimeQueryPerformanceCounter" fullword ascii
		$s7 = "*( -  <  =  >  k= m=%: +00+03+04+05+06+07+08+09+10+11+12+13+14-01-02-03-04-05-06-08-09-11-12..." ascii
		$s8 = "Go cmd/compile go1.10" fullword ascii
		$s9 = ".dllprogramdatarecycle.bin" ascii
		$s10 = ".dll.exe.lnk.sys.url" ascii
		$vx1_1 = "Fa1led to os.OpenFile()" ascii
		$vx1_2 = "-HELP.txt" ascii
		$vf1_1 = "main.CTREncrypt" fullword ascii
		$vf1_2 = "main.FileSearch" fullword ascii
		$vf1_3 = "main.getdrives" fullword ascii
		$vf1_4 = "main.RSAEncrypt" fullword ascii
		$vf1_5 = "main.SaveNote" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 9 of ( $s* ) or ( all of ( $vx* ) and 2 of ( $s* ) ) or all of ( $vf* ) )
}
rule DITEKSHEN_MALWARE_Win_Qnapcrypt : FILE
{
	meta:
		description = "Detects QnapCrypt/Lockedv1/Cryptfile2 ransomware"
		author = "ditekSHen"
		id = "3ef5643a-f2af-5d62-8927-e46679e069c2"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3579-L3607"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "68fc3f0503d82295ffa5bfb49bda8b790142913217775a2812e3965a6c9a1fe1"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$go = "Go build ID:" ascii
		$s1 = "Encrypting %s..." ascii
		$s2 = "\\Start Menu\\Programs\\StartUp\\READMEV" ascii
		$s3 = "main.deleteRecycleBin" ascii
		$s4 = "main.encryptFiles" ascii
		$s5 = "main.antiVirtualBox" ascii
		$s6 = "main.antiVmware" ascii
		$s7 = "main.deleteShadows" ascii
		$s8 = "main.delUAC" ascii
		$s9 = "main.KillProcess" ascii
		$s10 = "main.delExploit" ascii
		$s11 = "main.encrypt" ascii
		$s12 = "main.ClearLogDownload" ascii
		$s13 = "main.ClearLog" ascii
		$s14 = "main.EndEncrypt" ascii
		$s15 = "main.RunFuckLogAndSoft" ascii
		$s16 = "main.ClearUsercache" ascii
		$s17 = "main.FirstDuty" ascii
		$s18 = ".lockedv1" ascii
		$s19 = "WSAStartup\\clear.bat\\ngrok.exe\\video.mp4" ascii
		$s20 = "net stop " ascii

	condition:
		uint16( 0 ) == 0x5a4d and $go and 6 of ( $s* )
}
rule DITEKSHEN_MALWARE_Win_Vidar : FILE
{
	meta:
		description = "Detects Vidar / ArkeiStealer"
		author = "ditekSHen"
		id = "d858c463-26d7-5f96-ad9a-cb261a8c61c6"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3640-L3650"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c95c8694c05ff0e8d28f098e668a8ae8fa70130e31af6c0e540c4e5596007e41"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\"os_crypt\":{\"encrypted_key\":\"" fullword ascii
		$s2 = "screenshot.jpg" fullword wide
		$s3 = "Content-Disposition: form-data; name=\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Babuk : FILE
{
	meta:
		description = "Detects Babuk ransomware"
		author = "ditekSHen"
		id = "6bb7093f-bbef-5b43-b4f9-be72ae4ef319"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3652-L3674"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5ca5c5106747cf8f4ccd5df4ddbc78321fea3c8f533cb807a704d270eb956007"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "ecdh_pub_k.bin" wide
		$s2 = "How To Restore Your Files.txt" wide
		$s3 = /(babuk|babyk)\s(ransomware|locker)/ ascii nocase
		$s4 = "/login.php?id=" ascii
		$s5 = "http://babuk" ascii
		$s6 = "bootsect.bak" fullword wide
		$s7 = "Can't open file after killHolder" ascii
		$s8 = "Can't OpenProcess" ascii
		$s9 = "DoYouWantToHaveSexWithCuongDong" ascii
		$arg1 = "-lanfirst" fullword ascii
		$arg2 = "-lansecond" fullword ascii
		$arg3 = "-nolan" fullword ascii
		$arg4 = "shares" fullword wide
		$arg5 = "paths" fullword wide
		$arg6 = "gdebug" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $s* ) or ( 3 of ( $arg* ) and 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Nitol : FILE
{
	meta:
		description = "Detects Nitol backdoor"
		author = "ditekSHen"
		id = "d545f826-11ff-5d0f-9a95-8232b19d35b6"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3676-L3704"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c0ddcd6179bea2f3af77ae198e07f55f62884e07a975623ae41bcec163060f89"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "%$#@!.aspGET ^&*().htmlGET" ascii
		$s2 = "Applications\\iexplore.exe\\shell\\open\\command" fullword ascii
		$s3 = "taskkill /f /im rundll32.exe" fullword ascii
		$s4 = "\\Tencent\\Users\\*.*" fullword ascii
		$s5 = "[Pause Break]" fullword ascii
		$s6 = ":]%d-%d-%d  %d:%d:%d" fullword ascii
		$s7 = "GET %s HTTP/1.1" fullword ascii
		$s8 = "GET %s%s HTTP/1.1" fullword ascii
		$s9 = "Accept-Language: zh-cn" fullword ascii
		$s10 = "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows 5.1)" fullword ascii
		$s11 = "User-Agent:Mozilla/4.0 (compatible; MSIE %d.00; Windows NT %d.0; MyIE 3.01)" fullword ascii
		$s12 = "User-Agent:Mozilla/4.0 (compatible; MSIE %d.0; Windows NT %d.1; SV1)" fullword ascii
		$w1 = ".aspGET" ascii
		$w2 = ".htmGET" ascii
		$w3 = ".htmlGET" ascii
		$domain = "www.xy999.com" fullword ascii
		$v2_1 = "loglass" fullword ascii
		$v2_2 = "rlehgs" fullword ascii
		$v2_3 = "eherrali" fullword ascii
		$v2_4 = "agesrlu" fullword ascii
		$v2_5 = "lepejagas" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 5 of ( $s* ) or ( all of ( $v2* ) ) or ( $domain and 3 of them ) or ( #w1 > 2 and #w2 > 2 and #w3 > 2 and 3 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Strongpity : FILE
{
	meta:
		description = "Detects StrongPity"
		author = "ditekSHen"
		id = "9dcc5edb-5c86-5412-af63-f88d488d5829"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3706-L3720"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e92147966cd68152eb536b805c4918462f72f64280d1b3df800bb41266aa232f"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Boundary%08X" ascii wide
		$s2 = "Content-Disposition: form-data; name=\"file\";" fullword ascii
		$s3 = "%sfilename=\"%ls\"" fullword ascii
		$s4 = "name=%ls&delete=" fullword ascii
		$s5 = "Content-Type: application/octet-stream" fullword ascii
		$s6 = "cmd.exe /C ping" wide
		$s7 = "& rmdir /Q /S \"" wide

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Jssloader : FILE
{
	meta:
		description = "Detects JSSLoader RAT/backdoor"
		author = "ditekSHen"
		id = "ef710c21-5c64-513e-b882-b5768478976e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3722-L3752"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "91764dabfb40cb51914110de229ddb00cd565078fef83c825f7a86fa502fda37"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$cmd1 = "Cmd_UPDATE" fullword ascii
		$cmd2 = "Cmd_IDLE" fullword ascii
		$cmd3 = "Cmd_EXE" fullword ascii
		$cmd4 = "Cmd_VBS" fullword ascii
		$cmd5 = "Cmd_JS" fullword ascii
		$cmd6 = "Cmd_PWS" fullword ascii
		$cmd7 = "Cmd_RAT" fullword ascii
		$cmd8 = "Cmd_UNINST" fullword ascii
		$cmd9 = "Cmd_RunDll" fullword ascii
		$s1 = "ANSWER_OK" fullword ascii
		$s2 = "GatherDFiles" ascii
		$s3 = "CommandCd" fullword ascii
		$s4 = "URL_GetCmd" fullword ascii
		$s5 = "\"host\": \"{0}\", \"domain\": \"{1}\", \"user\": \"{2}\"" wide
		$s6 = "pc_dns_host_name" wide
		$s7 = "\"adinfo\": { \"adinformation\":" wide
		$e1 = "//e:vbscript" wide
		$e2 = "//e:jscript" wide
		$e3 = "/c rundll32.exe" wide
		$e4 = "/C powershell" wide
		$e5 = "C:\\Windows\\System32\\cmd.exe" wide
		$e6 = "echo del /f" wide
		$e7 = "AT.U() {0}. format" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 5 of ( $cmd* ) or 5 of ( $s* ) or all of ( $e* ) or 7 of them )
}
rule DITEKSHEN_MALWARE_Linux_Ransomexx : FILE
{
	meta:
		description = "Detects RansomEXX ransomware"
		author = "ditekshen"
		id = "b449afc7-9055-55ed-a876-316d1aea8fee"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3834-L3858"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c233ccc3e741cb2c53f182c48093e41595a82a3f4e5bdb1dc0204f1f57b96c2a"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Linux.Ransomware.RansomEXX"

	strings:
		$c1 = "crtstuff.c" fullword ascii
		$c2 = "cryptor.c" fullword ascii
		$c3 = "ransomware.c" fullword ascii
		$c4 = "logic.c" fullword ascii
		$c5 = "enum_files.c" fullword ascii
		$c6 = "readme.c" fullword ascii
		$c7 = "ctr_drbg.c" fullword ascii
		$s1 = "regenerate_pre_data" fullword ascii
		$s2 = "g_RansomHeader" fullword ascii
		$s3 = "CryptOneBlock" fullword ascii
		$s4 = "RansomLogic" fullword ascii
		$s5 = "CryptOneFile" fullword ascii
		$s6 = "encrypt_worker" fullword ascii
		$s7 = "list_dir" fullword ascii
		$s8 = "ctr_drbg_update_internal" fullword ascii

	condition:
		uint16( 0 ) == 0x457f and ( 5 of ( $c* ) or 6 of ( $s* ) or ( 3 of ( $c* ) and 3 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Trickbotmodule : FILE
{
	meta:
		description = "Detects Trickbot modules"
		author = "ditekshen"
		id = "c56c664f-5928-5e2e-ab06-0b9d504981be"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3860-L3881"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4d06653dad5f8a18598855212548364b3c3d2b68b99784846b494fcb1d1c8df9"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$mc = "<moduleconfig>" ascii
		$s1 = "<autostart>" ascii
		$s2 = "<nohead>" ascii
		$s3 = "<needinfo" ascii
		$s4 = "<conf ctl" ascii
		$s5 = "<limit>" ascii
		$w1 = "<sys>yes</sys>" ascii
		$w2 = "<sys>no</sys>" ascii
		$w3 = "<autostart>yes</autostart>" ascii
		$w4 = "<autostart>no</autostart>" ascii
		$w5 = "<nohead>yes</nohead>" ascii
		$w6 = "<nohead>no</nohead>" ascii
		$w7 = /<limit>\d+<\/limit>/ ascii
		$w8 = "<moduleconfig> </moduleconfig" ascii

	condition:
		uint16( 0 ) == 0x5a4d and $mc and ( 2 of ( $s* ) or ( 1 of ( $s* ) and 1 of ( $w* ) ) or 1 of ( $w* ) )
}
rule DITEKSHEN_MALWARE_Win_Gaudox : FILE
{
	meta:
		description = "Detects Gaudox RAT"
		author = "ditekshen"
		id = "c60ac433-20a1-5f01-9447-fa99621bd9e2"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3883-L3893"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "117ee89e264067ab3e695688872bbe7d83963731e877d04ac7e2505e64f6e793"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "hdr=%s&tid;=%s&cid;=%s&trs;=%i" ascii wide
		$s2 = "\\\\\\\\.\\\\PhysicalDrive%u" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Ratty : FILE
{
	meta:
		description = "Detects Ratty Java RAT"
		author = "ditekshen"
		id = "87719e28-dfe7-5366-8d90-65e6c0c6fb4f"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3910-L3929"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d90bca1b18023da8e60cb6ca86d1c562bff3867c6d5cf893dce605ebb92b9637"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "/rat/RattyClient.class" ascii
		$s2 = "/rat/ActiveConnection.class" ascii
		$s3 = "/rat/attack/" ascii
		$s4 = "/rat/gui/swing/Ratty" ascii
		$s5 = "/rat/packet/PasswordPacket" ascii
		$s6 = "/rat/packet/" ascii
		$e1 = "/engine/Keyboard.class" ascii
		$e2 = "/engine/IMouseListener.class" ascii
		$e3 = "/engine/Screen$ResizeBehavior.class" ascii
		$e4 = "/engine/fx/ISoundListener.class" ascii
		$e5 = "/engine/net/TCPServer.class" ascii
		$e6 = "/engine/noise/PerlinNoise.class" ascii

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0xcfd0 or uint16( 0 ) == 0x4b50 ) and ( 3 of ( $s* ) or all of ( $e* ) )
}
rule DITEKSHEN_MALWARE_Win_Fatduke : FILE
{
	meta:
		description = "Detects FatDuke"
		author = "ditekSHen"
		id = "dc80c0f0-c61c-5f0c-841b-3a75e8a1cef3"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3931-L3946"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a7923d15b10098e9402614fe7107a6ba1d71512efa6e462d522ef64e13f82b47"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\\\?\\Volume" fullword ascii
		$s2 = "WINHTTP_AUTOPROXY_OPTIONS@@PAUWINHTTP_PROXY_INFO@@" ascii
		$s3 = "WINHTTP_CURRENT_USER_IE_PROXY_CONFIG@@" ascii
		$s4 = "Cannot write a Cannot find the too long string mber of records Log malfunction! Cannot create ain an invalid ra Internal sync iright function iWaitForSingleObjffsets" ascii
		$pattern = "()$^.*+?[]|\\-{},:=!" ascii
		$b64 = "eyJjb25maWdfaWQiOi" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $s* ) or ( $b64 and 2 of them ) or ( #pattern > 3 and 2 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Miniduke : FILE
{
	meta:
		description = "Detects MiniDuke"
		author = "ditekSHen"
		id = "947cd414-d19d-5543-8961-94aef69cc94e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3948-L3969"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c3ab139b4fda2ff9678ceecbdf5ac0c57536bd658f62aa9d19610028b0a5f92c"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "DefPipe" fullword ascii
		$s2 = "term %5d" fullword ascii
		$s3 = "pid %5d" fullword ascii
		$s4 = "uptime %5d.%02dh" fullword ascii
		$s5 = "login: %s\\%s" fullword ascii
		$s6 = "Software\\Microsoft\\ApplicationManager" ascii
		$s7 = { 69 64 6c 65 ?? 00 73 74 6f 70 ?? 00 61 63 63 65 70 74 ?? 00 63 6f 6e 6e 65 63 74 ?? 00 6c 69 73 74 65 6e ?? 00 }
		$net1 = "salesappliances.com" ascii
		$net2 = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36" fullword ascii
		$net3 = "http://10." ascii
		$net4 = "JiM9t8g7j8KoJkLJlKqka8dbo7q5z4v5u3o4z" ascii
		$net5 = "application/octet-stream" ascii
		$net6 = "Content-Disposition: form-data; name=\"%s\"; filename=\"%s\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 5 of ( $s* ) or 4 of ( $net* ) or 7 of them )
}

rule DITEKSHEN_MALWARE_Win_Polyglotduke : FILE
{
	meta:
		description = "Detects PolyGlotDuke"
		author = "ditekSHen"
		id = "01ac90db-35f6-5192-8630-81000573b4f9"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3971-L3986"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c1fb8ea1d21768cbd65bd7b91e3f817fa97a0a933b511dff2ae4d5db49bdb2ec"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = { 48 b9 ff ff ff ff ff ff ff ff 51 48 23 8c 24 ?? 00 00 00 48 89 8C 24 00 00 00 00 }
		$s2 = { 56 be ff ff ff ff 56 81 e6 7f }
		$s3 = { 48 8b 05 19 ?4 4b 00 48 05 48 83 00 00 4c 8b 44 24 50 8b 54 24 48 48 8b }

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) ) or ( 2 of them and pe.exports ( "InitSvc" ) )
}
rule DITEKSHEN_MALWARE_Win_WSHRATJS : FILE
{
	meta:
		description = "Detects WSHRAT JS variants"
		author = "ditekSHen"
		id = "7dbaea67-48dc-5fb8-ba58-b0d6eeca207b"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4028-L4045"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9956ed4613ac403360ab0222a7ed62350fcd998710843bd6700717f8bbb5052e"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$charset_full = "us-ascii" nocase ascii
		$charset_begin = "\"us-\"" nocase ascii
		$charset_end = "Array(97,115,99,105,105)" nocase ascii
		$wsc_object1 = "WScript.CreateObject(\"System.Text.UTF8Encoding" nocase ascii
		$wsc_object2 = "WScript.CreateObject(\"Adodb.Stream" nocase ascii
		$wsc_object3 = "WScript.CreateObject(\"Microsoft.XmlDom" nocase ascii
		$s1 = "function(){return" ascii
		$s2 = "}catch(err){" ascii
		$s3 = "{item: \"bin.base64\"}" nocase ascii
		$s4 = "* 1].item =" ascii

	condition:
		filesize < 400KB and ( $charset_full or ( $charset_begin and $charset_end ) ) and 2 of ( $wsc_object* ) and 3 of ( $s* )
}
rule DITEKSHEN_MALWARE_Win_Quilclipper
{
	meta:
		description = "Detects QuilClipper variants mostly in memory or extracted AutoIt script"
		author = "ditekSHen"
		id = "bd23ec5a-f21a-5133-a77a-de2615933b82"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4076-L4094"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "dcac93806a438b188ae70a679301cb6630b9eb6849bf8fbbb1cea5fed5e7cf75"
		score = 75
		quality = 75
		tags = ""

	strings:
		$cnc1 = "QUILCLIPPER by" ascii
		$cnc2 = "/ UserName:" ascii
		$cnc3 = "/ System:" ascii
		$s1 = "DLLCALL ( \"kernel32.dll\" , \"handle\" , \"CreateMutexW\" , \"struct*\"" ascii
		$s2 = "SHELLEXECUTE ( @SCRIPTFULLPATH , \"\" , \"\" , FUNC_" ascii
		$s3 = "CASE BITROTATE" ascii
		$s4 = "CASE BITXOR" ascii
		$s5 = "CLIP( FUNC_" ascii
		$s6 = "CLIPPUT (" ascii
		$s7 = "FUNC _CLIPPUTFILE(" ascii
		$s8 = "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Schedule" ascii

	condition:
		all of ( $cnc* ) or all of ( $s* )
}
rule DITEKSHEN_MALWARE_Win_Spyeye : FILE
{
	meta:
		description = "Detects SpyEye"
		author = "ditekSHen"
		id = "aa15220a-6fd4-5c5e-8287-957fc3c3fe52"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4096-L4111"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "352853d600d1f4fbc09e58b783eb4e13b335fefbfe89842873710f0a9085d107"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "_CLEANSWEEP_" ascii wide
		$x2 = "config.datUT" fullword ascii
		$x3 = "webinjects.txtUT" fullword ascii
		$s1 = "confirm:processCommand" fullword ascii
		$s2 = "Smth wrong with navigate to REF-PAGE (err code: %d). 0_o" fullword ascii
		$s3 = "(UTC%s%2.2f) %s" fullword wide
		$s4 = "M\\F;u`r" fullword ascii
		$s5 = "]YH0%Yn" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $x* ) or ( 1 of ( $x* ) and 1 of ( $s* ) ) )
}

rule DITEKSHEN_MALWARE_Win_Renamer : FILE
{
	meta:
		description = "Detects Renamer/Tainp variants"
		author = "ditekSHen"
		id = "9e701bbe-d698-510a-b63d-3c1575dac7b0"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4114-L4135"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "df80657631f072bc1627e1cf503881a2c065396f8798d7f347259672f600198d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "shell\\open\\command=" fullword wide
		$s2 = "icon=%SystemRoot%\\system32\\SHELL32.dll,4" fullword wide
		$s3 = "DropTarget" ascii
		$s4 = "C:\\Windows\\Paint" fullword wide
		$s5 = "hold.inf" fullword wide
		$s6 = "Dropped" ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of ( $s* ) or ( 4 of ( $s* ) and for any directory in pe.data_directories : ( directory.virtual_address != 0 and directory.size == 0 ) )
}
rule DITEKSHEN_MALWARE_Win_Epsilon : FILE
{
	meta:
		description = "Detects Epsilon ransomware"
		author = "ditekSHen"
		id = "c5561a0d-85ac-5137-a97e-310aa03eb787"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4137-L4169"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "cc4481ddb6f5fd52a0bc901dde4c34ccf79024cd68605245df0dcbea22d0adee"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = ".Speak \"" wide
		$s2 = "chkUpdateRegistry" fullword wide
		$s3 = "/C choice /C Y /N /D Y /T 1 & Del \"" fullword wide
		$s4 = "CreateObject(\"sapi.spvoice\")" fullword wide
		$s5 = "READ_ME.hta" wide
		$s6 = "WScript.Sleep(" wide
		$s7 = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run" fullword wide
		$s8 = "<div class='bold'>Files are encrypted* but not deleted.</div>" ascii
		$e1 = { 72 00 75 00 6e 00 64 00 6c 00 6c 00 2e 00 65 00
                78 00 65 00 00 09 2e 00 74 00 78 00 74 00 00 09
                2e 00 64 00 6f 00 63 00 00 0b 2e 00 64 00 6f 00
                63 00 78 00 00 09 2e 00 78 00 6c 00 73 00 00 0d
                2e 00 69 00 6e 00 64 00 65 00 78 00 00 09 2e 00
                70 00 64 00 66 00 00 09 2e 00 7a 00 69 00 70 00
                00 09 2e 00 72 00 61 00 72 00 00 09 2e 00 63 00
                73 00 73 00 00 09 2e 00 6c 00 6e 00 6b 00 00 0b
                2e 00 78 00 6c 00 73 00 78 00 00 09 2e 00 70 00
                70 00 74 00 00 0b 2e 00 70 00 70 00 74 00 78 00
                00 09 2e 00 6f 00 64 00 }
		$e2 = { 68 00 74 00 6d 00 00 07 2e 00 6d 00 6c 00 00 07
                43 00 3a 00 5c 00 00 07 44 00 3a 00 5c 00 00 07
                45 00 3a 00 5c 00 00 07 46 00 3a 00 5c 00 00 07
                47 00 3a 00 5c 00 00 07 5a 00 3a 00 5c 00 00 07
                41 00 3a 00 5c 00 00 0f 63 00 6d 00 64 00 2e 00
                65 00 78 00 65 }

	condition:
		uint16( 0 ) == 0x5a4d and ( 6 of ( $s* ) or ( all of ( $e* ) and 4 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Dllloader : FILE
{
	meta:
		description = "Detects unknown DLL Loader"
		author = "ditekSHen"
		id = "164967b8-d0f5-543d-82ac-bb2465b85c2a"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4228-L4239"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "aaf1ff0f93d1fe6cf189c9f30403c226e64146178150dff8dfd3a9e3ed84bcc2"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "LondLibruryA" fullword ascii
		$s2 = "LdrLoadDll" fullword ascii
		$s3 = "snxhk.dll" fullword ascii
		$s4 = "DisableThreadLibraryCalls" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Warezov : FILE
{
	meta:
		description = "Detects Warezov worm/downloader"
		author = "ditekSHen"
		id = "8cb1dcb1-981d-5ff2-b0d9-aa18dfbfc795"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4255-L4269"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e65922902fd18175a3ce7b600d46535e92b92240fa3ca83dced6f9ce14f3e815"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "ft\\Windows\\CurrentVersion\\Run" wide
		$s2 = "DIR%SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run" wide
		$s3 = "%WINDIR%\\sqhos32.wmf" wide
		$s4 = "Accept: */*" fullword ascii
		$s5 = "Range: bytes=" fullword ascii
		$s6 = "module.exe" fullword ascii
		$s7 = { 25 73 25 73 2e 25 73 ?? ?? 22 22 26 6c 79 79 56 00 00 00 00 25 73 25 30 34 64 25 30 32 64 25 30 32 64 00 }

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Win_Arechclient2 : FILE
{
	meta:
		description = "Detects Arechclient2 RAT"
		author = "ditekSHen"
		id = "c12858ea-5e06-5303-9df0-0f59ba83b5e5"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4271-L4303"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0d841f4d4664fb09801c51f7b65e897e4e698753ad67fc20e2b81d98c0b3d07d"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "\\Google\\Chrome\\User Data\\copiedProf\"" wide
		$s2 = "\",\"BotName\":\"" wide
		$s3 = "\",\"BotOS\":\"" wide
		$s4 = "\",\"URLData\":\"" wide
		$s5 = "{\"Type\":\"ConnectionType\",\"ConnectionType\":\"Client\",\"SessionID\":\"" wide
		$s6 = "{\"Type\":\"TestURLDump\",\"SessionID\":\"" wide
		$s7 = "<ReceiveParticipantList>" ascii
		$s8 = "<potocSkr>" ascii
		$s9 = "fuck_sd" fullword ascii
		$s10 = "HandleBotKiller" fullword ascii
		$s11 = "RunBotKiller" fullword ascii
		$s12 = "ConnectToServer" fullword ascii
		$s13 = "KillBrowsers" fullword ascii
		$s14 = "keybd_event" fullword ascii
		$s15 = "FuckCodeImg" fullword ascii
		$v1_1 = "grabber@" fullword ascii
		$v1_2 = "<BrowserProfile>k__" ascii
		$v1_3 = "<SystemHardwares>k__" ascii
		$v1_4 = "<geoplugin_request>k__" ascii
		$v1_5 = "<ScannedWallets>k__" ascii
		$v1_6 = "<DicrFiles>k__" ascii
		$v1_7 = "<MessageClientFiles>k__" ascii
		$v1_8 = /<Scan(Browsers|Wallets|Screen|VPN)>k__BackingField/ fullword ascii
		$v1_9 = "displayName[AString-ZaString-z\\d]{2String4}\\.[String\\w-]{String6}\\.[\\wString-]{2String7}Local Extension Settingshost" wide
		$v1_10 = "\\sitemanager.xml MB or SELECT * FROM Cookiesconfig" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 6 of ( $s* ) or 7 of ( $v1* ) or ( 6 of ( $v1* ) and 1 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Killmbr : FILE
{
	meta:
		description = "Detects KillMBR"
		author = "ditekSHen"
		id = "b109865f-e268-5633-bb8e-f390dd050d99"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4305-L4316"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "1ed9206f90052df7e533be4612afa373e5e69fba8f5b5ae4df1c09a9d98958cf"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\\\.\\PhysicalDrive" ascii
		$s2 = "/logger.php" ascii
		$s3 = "Ooops! Your MBR was been rewritten" ascii
		$s4 = "No, this ransomware dont encrypt your files, erases it" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of them and #s1 > 10 )
}
rule DITEKSHEN_MALWARE_Win_Lcpdot : FILE
{
	meta:
		description = "Detects LCPDot"
		author = "ditekSHen"
		id = "e4db3784-7fb0-58bd-997e-788f409445cd"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4318-L4337"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b0f77f17976c38a69c2ff0d84002f2db29a4d25873309259519115b5f2b210ff"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko" fullword wide
		$s2 = "Cookie: SESSID=%s" fullword ascii
		$s3 = "Cookie=Enable" fullword ascii
		$s4 = "Cookie=Enable&CookieV=%d&Cookie_Time=32" fullword ascii
		$s5 = ".?AVTShellCodeRuner@@" fullword ascii
		$s6 = ".?AVTHashEncDecoder@@" fullword ascii
		$s7 = ".?AVTWebAddressList@@" fullword ascii
		$s8 = "WinMain.dll" fullword ascii
		$s9 = "HotPlugin" wide
		$o0 = { 4c 89 6c 24 08 4c 89 34 24 44 8d 77 01 44 8d 6f }
		$o1 = { 8b f0 e8 58 34 00 00 48 8b f8 48 85 c0 74 0c 48 }
		$o2 = { c7 44 24 30 47 49 46 38 c7 44 24 34 39 61 27 00 }

	condition:
		uint16( 0 ) == 0x5a4d and 6 of ( $s* ) or ( all of ( $o* ) and 3 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Torisma : FILE
{
	meta:
		description = "Detects Torisma"
		author = "ditekSHen"
		id = "e62a0f1c-4404-5da1-9c43-4cb58e735827"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4339-L4355"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "bd3823f8a91fdfc443e20bcb299a5103b7176a694f0d5328e7986de83f677a31"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "ACTION=PREVPAGE&CODE=C%s&RES=%d" fullword ascii
		$s2 = "ACTION=VIEW&PAGE=%s&CODE=%s&CACHE=%s&REQUEST=%d" fullword ascii
		$s3 = "ACTION=NEXTPAGE&CODE=S%s&CACHE=%s&RES=%d" fullword ascii
		$s4 = "Your request has been accepted. ClientID: {" ascii
		$s5 = "Proxy-Connection: Keep-Alive" fullword wide
		$s6 = "Content-Length: %d" fullword wide
		$o0 = { f7 f9 8b c2 89 44 24 34 48 63 44 24 34 48 8b 4c }
		$o1 = { 48 c7 00 ff ff ff ff 48 8b 84 24 90 }
		$o2 = { f3 aa 83 7c 24 30 01 75 34 c7 44 24 20 01 }

	condition:
		uint16( 0 ) == 0x5a4d and 4 of ( $s* ) or ( all of ( $o* ) and 3 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Thanos : FILE
{
	meta:
		description = "Detects Thanos / Prometheus / Spook ransomware"
		author = "ditekSHen"
		id = "f523906e-ef5e-57be-82ed-06e75c393f42"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4357-L4389"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "8ce7cdfe4bca31e21d6fa31a75c46737a41fae3b5b0fda818e3a4709ceaf9bf5"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$f1 = "<WorkerCrypter2>b__" ascii
		$f2 = "<Encrypt2>b__" ascii
		$f3 = "<Killproc>b__" ascii
		$f4 = "<GetIPInfo>b__" ascii
		$f5 = "<MacAddress>k__" ascii
		$f6 = "<IPAddress>k__" ascii
		$f7 = "<Crypt>b__" ascii
		$s1 = "Aditional KeyId:" wide
		$s2 = "process call create cmd.exe /c \\\\" wide
		$s3 = "/c rd /s /q %SYSTEMDRIVE%\\$Recycle.bin" wide
		$s4 = "\\HOW_TO_DECYPHER_FILES." wide
		$s5 = "Client Unique Identifier Key:" wide
		$s6 = "/s /f /q c:\\*.VHD c:\\*.bac c:\\*.bak c:\\*.wbcat c:\\*.bkf c:\\Backup*.* c:\\backup*.* c:\\*.set c:\\*.win c:\\*.dsk" fullword wide
		$s7 = "NtOpenProcess" fullword wide
		$s8 = "Builder_Log" fullword wide
		$s9 = "> Nul & fsutil file setZeroData offset=0 length=" wide
		$s10 = "3747bdbf-0ef0-42d8-9234-70d68801f407" wide
		$s11 = "4b195894-0f06-4fdd-afb4-b17fb9246a59" wide
		$s12 = "cec564ff-2433-4771-b918-15f58ef6e26c" wide
		$s13 = "56258a19-7489-468b-86ee-e7899203d67c" wide
		$s14 = "WalkDirectoryTree" fullword ascii
		$s15 = "hashtableLock" fullword ascii
		$s16 = "get_ParentFrn" fullword ascii
		$m1 = "SW5mb3JtYXRpb24uLi" wide
		$m2 = "QWxsIHlvdXIgZmlsZXMgd2VyZSBlbmNyeXB0" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 5 of ( $f* ) or 5 of ( $s* ) or ( 4 of ( $f* ) and 2 of ( $s* ) or ( all of ( $m* ) and 3 of them ) ) or 8 of them )
}
rule DITEKSHEN_MALWARE_Win_Tmanager : FILE
{
	meta:
		description = "Detects TManager RAT. Associated with TA428"
		author = "ditekSHen"
		id = "391b72bd-ddf5-5251-b566-c75c1cc16b74"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4391-L4410"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "cdbcc00ae67c9161f6db89cfa658c8bc8fb7fab3915ac5ae99bdd34c42ee2abb"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "WSAStartup Error!" fullword wide
		$s2 = "KB3112342.LOG" fullword wide
		$s3 = "\\cmd.exe -c" fullword wide
		$s4 = "sock_hmutex" fullword wide
		$s5 = "cmd_hmutex" fullword wide
		$s6 = "powershell" fullword wide
		$s7 = "%s_%d.bmp" fullword wide
		$s8 = "!Error!" fullword wide
		$s9 = "[Execute]" fullword ascii
		$s10 = "[Snapshot]" fullword ascii
		$s11 = "GetLanIP error!" fullword ascii
		$s12 = "chcp & exit" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Sn0Wlogger : FILE
{
	meta:
		description = "Detects Sn0w Logger"
		author = "ditekSHen"
		id = "cdb70164-3f72-553f-a6c5-190f699e0743"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4412-L4428"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ea4b2281f906271dc249b5036b22eadfc5add94def4f8e4f8a40c384618465d8"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\SnowP\\Example\\Secured\\" ascii
		$s2 = "{0}{3}Content-Type: {4}{3}Content-Disposition: form-data; name=\"{1}\"{3}{3}{2}{3}" wide
		$s3 = "\"encrypted_key\":\"(.*?)\"" fullword wide
		$s4 = "<SendToDiscord>d__" ascii
		$s5 = "_urlWebhook" ascii
		$r1 = "[\\w-]{24}\\.[\\w-]{6}\\.[\\w-]{27}" fullword wide
		$r2 = "^\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$" fullword wide
		$r3 = "mfa\\.[\\w-]{84}" fullword wide
		$r4 = "(\\w+)=(\\d+)-(\\d+)$" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 4 of ( $s* ) or ( all of ( $r* ) and 2 of ( $s* ) ) or 7 of them )
}
rule DITEKSHEN_MALWARE_Win_Klackring : FILE
{
	meta:
		description = "Detects Klackring variants. Associated with ZINC / Lazarus"
		author = "ditekSHen"
		id = "7bd9a68f-d58b-5437-a28b-5a7f1a11038e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4461-L4475"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b894e89de720affadd80966d726a44ffce75d71095b0530edb6bfddb76660c54"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "%s\\%s.dll" fullword wide
		$s2 = "cmd.exe /c move /Y %s %s" fullword wide
		$s3 = "%s\\win32k.sys" fullword wide
		$s4 = "NetSvcInst_Rundll32.dll" fullword ascii
		$s5 = "Spectrum.dll" fullword ascii wide
		$s6 = "%s\\cmd.exe" fullword wide
		$s7 = ".?AVA5Stream@@" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Suncrypt : FILE
{
	meta:
		description = "Detects SunCrypt ransomware"
		author = "ditekSHen"
		id = "1a28fcbf-1fc0-5f18-ae71-2e813ed0f958"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4494-L4532"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "abde9bbf2577304ff059972a38e803ba17de7a1f0346efe880a710f2ad79db37"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "-noshares" fullword wide
		$s2 = "-nomutex" fullword wide
		$s3 = "-noreport" fullword wide
		$s4 = "-noservices" fullword wide
		$s5 = "$Recycle.bin" fullword wide
		$s6 = "YOUR_FILES_ARE_ENCRYPTED.HTML" fullword wide
		$s7 = "\\\\?\\%c:" fullword wide
		$s8 = "locker.exe" fullword ascii
		$s9 = "DllRegisterServer" fullword ascii
		$g1 = "main.EncFile" fullword ascii nocase
		$g2 = "main.detectName" fullword ascii nocase
		$g3 = "main.detectIP" fullword ascii nocase
		$g4 = "main.detectDebugProc" fullword ascii nocase
		$g5 = "main.Bypass" ascii nocase
		$g6 = "main.allocateMemory" fullword ascii nocase
		$g7 = "main.killAV" fullword ascii nocase
		$g8 = "main.disableShadowCopy" fullword ascii nocase
		$g9 = "main.(*windowsDrivesModel).LoadDrives" fullword ascii nocase
		$g10 = "main.IsFriends" fullword ascii nocase
		$g11 = "main.walkMsg" fullword ascii nocase
		$g12 = "main.makeSecretMessage" fullword ascii nocase
		$g13 = "main.stealFiles" fullword ascii nocase
		$g14 = "main.newKey" fullword ascii nocase
		$g15 = "main.openBrowser" fullword ascii nocase
		$g16 = "main.killProc" fullword ascii nocase
		$g17 = "main.selfRemove" fullword ascii nocase
		$m1 = "<h2>\\x20Offline\\x20HowTo\\x20</h2>\\x0a\\x09\\x09\\x09\\x09<p>Copy\\x20&\\x20Paste\\x20this\\x20message\\x20to" ascii
		$m2 = "\\x20restore\\x20your\\x20files." ascii
		$m3 = "\\x20your\\x20documents\\x20and\\x20files\\x20encrypted" ascii
		$m4 = "\\x20lose\\x20all\\x20of\\x20your\\x20data\\x20and\\x20files." ascii
		$m5 = ",'/#/client/','<h2>\\x20Whats\\x20Happen" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 5 of ( $s* ) or 6 of ( $g* ) or 3 of ( $m* ) )
}
rule DITEKSHEN_MALWARE_Win_Zegost : FILE
{
	meta:
		description = "Detects Zegost"
		author = "ditekSHen"
		id = "cce29602-c096-53df-a99b-16f18ed43b80"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4534-L4560"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "96727a0f5c113e5cdfe871f104553fd1c04a8f63ecbb8db7223afb71fcdd4087"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "rtvscan.exe" fullword ascii
		$s2 = "ashDisp.exe" fullword ascii
		$s3 = "KvMonXP.exe" fullword ascii
		$s4 = "egui.exe" fullword ascii
		$s5 = "avcenter.exe" fullword ascii
		$s6 = "K7TSecurity.exe" fullword ascii
		$s7 = "TMBMSRV.exe" fullword ascii
		$s8 = "RavMonD.exe" fullword ascii
		$s9 = "kxetray.exe" fullword ascii
		$s10 = "mssecess.exe" fullword ascii
		$s11 = "QUHLPSVC.EXE" fullword ascii
		$s12 = "360tray.exe" fullword ascii
		$s13 = "QQPCRTP.exe" fullword ascii
		$s14 = "knsdtray.exe" fullword ascii
		$s15 = "V3Svc.exe" fullword ascii
		$s16 = "??1_Winit@std@@QAE@XZ" fullword ascii
		$s17 = "ClearEventLogA" fullword ascii
		$s18 = "SeShutdownPrivilege" fullword ascii
		$s19 = "%s\\shell\\open\\command" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_GENERIC01 : FILE
{
	meta:
		description = "Detects known unamed malicious executables, mostly DLLs"
		author = "ditekSHen"
		id = "3c16df71-f2e2-591c-b377-7e5ed697d43f"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4562-L4575"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ddae979db5ddda772ca66a3d50e4b5479b16052ea002fd04fdbf295ce784e291"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\wmkawe_%d.data" ascii
		$s2 = "\\resmon.resmoncfg" ascii
		$s3 = "ByPassUAC" fullword ascii
		$s4 = "rundll32.exe C:\\ProgramData\\Sandboxie\\SbieMsg.dll,installsvc" fullword ascii nocase
		$s5 = "%s\\SbieMsg." ascii
		$s6 = "Stupid Japanese" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Dlagent06 : FILE
{
	meta:
		description = "Detects known downloader agent downloading encoded binaries in patches"
		author = "ditekSHen"
		id = "00cb5184-b12d-5014-bee8-116cc72dfa47"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4593-L4610"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9188804ad0e08f3e0cd09eb8815abea14da5aa28aef9084d19108a24f49f65c7"
		score = 75
		quality = 75
		tags = "FILE"
		snort2_sid = "920122"
		snort3_sid = "920119"

	strings:
		$s1 = "totallist" fullword ascii wide
		$s2 = "LINKS_HERE" fullword wide
		$s3 = "[SPLITTER]" fullword wide
		$var2_1 = "DownloadWeb" fullword ascii
		$var2_2 = "WriteByte" fullword ascii
		$var2_3 = "MemoryStream" fullword ascii
		$var2_4 = "DownloadString" fullword ascii
		$var2_5 = "WebClient" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( all of ( $s* ) and 2 of ( $var2* ) ) or ( 4 of ( $var2* ) and 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_PWSH_Poshkeylogger
{
	meta:
		description = "Detects PowerShell PoshKeylogger"
		author = "ditekSHen"
		id = "a816d716-caeb-5f08-9043-29db531f9e7c"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4612-L4627"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "20bde87ded7e3b68bc554c4b9a6c2ef08514f0d47b6b144763927bede81ea540"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = "::GetKeyboardState" ascii
		$s2 = "GetAsyncKeyState(" ascii
		$s3 = "::MapVirtualKey(" ascii
		$s4 = "::GetAsyncKeyState" ascii
		$s5 = "Start-Sleep" ascii
		$s6 = "send-mailmessage" ascii
		$s7 = "[System.IO.File]::AppendAllText($" ascii
		$s8 = "new-object Management.Automation.PSCredential $" ascii

	condition:
		6 of them
}
rule DITEKSHEN_MALWARE_Win_Fujinamarat : FILE
{
	meta:
		description = "Detects FujinamaRAT"
		author = "ditekSHen"
		id = "f6b08713-1c03-5914-b0a2-ea9164a3f2cb"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4629-L4645"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "42557094afe67196442f46d76f156c09852d694bcc5f03eac51e79ad247c2fdd"
		score = 75
		quality = 75
		tags = "FILE"
		snort2_sid = "920124"
		snort3_sid = "920121"

	strings:
		$s1 = "GetAsyncKeyState" fullword ascii
		$s2 = "HTTP/1.0" fullword wide
		$s3 = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727)" fullword wide
		$s4 = "frmMain" fullword ascii
		$s5 = "G<=>?@ABGGGGGGGGGGGGGGGGGGGGGGGGGGCDEF" fullword ascii
		$s6 = "VBA6.DLL" fullword ascii
		$s7 = "t_save" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Phorpiex : FILE
{
	meta:
		description = "Detects Phorpiex variants"
		author = "ditekSHen"
		id = "e2d26c5f-939e-53e3-8730-622341d26273"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4647-L4666"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4c48a20aaf37d65471710181238d2c39c1cb0fc5a37b9c411e8d4dcfd7a9e26e"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "ShEllExECutE=__\\DriveMgr.exe" fullword wide nocase
		$s2 = "/c start __ & __\\DriveMgr.exe & exit" fullword wide nocase
		$s3 = "%s\\autorun.inf" fullword wide
		$s4 = "svchost." wide
		$s5 = "%ls\\%d%d" wide
		$s6 = "bitcoincash:" ascii
		$s7 = "%ls:*:Enabled:%ls" fullword wide
		$s8 = "%s\\%s\\DriveMgr.exe" fullword wide
		$s9 = "api.wipmania.com" ascii
		$v1_1 = "%appdata%" fullword wide
		$v1_2 = "(iPhone;" ascii
		$v1_3 = "/tst.php" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 5 of ( $s* ) or all of ( $v1* ) )
}
rule DITEKSHEN_MALWARE_Win_Vovalex : FILE
{
	meta:
		description = "Detects Vovalex ransomware"
		author = "ditekSHen"
		id = "967af585-8a91-5ed0-8400-a8a24d95fd12"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4705-L4718"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ea695521981f4b007eee50e95f7989dda1f07cc411c59450489bb17391ff29dc"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "README.VOVALEX.txt" fullword ascii
		$s2 = "\\src\\phobos\\std\\" ascii
		$s3 = "LoadLibraryA(\"Advapi32.dll\")" fullword ascii
		$s4 = "Failed to spawn process \"" fullword ascii
		$s5 = "=== Bypassed ===" fullword ascii
		$s6 = "If you don't know where to buy" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Win_Dharma : FILE
{
	meta:
		description = "Detects Dharma ransomware"
		author = "ditekSHen"
		id = "070be95e-8d9c-5c4d-9d46-cddea6dbb682"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4720-L4728"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "2727b2c0295e32699e08c3c79d7ac6fd52f1520358ac23290d40df428c969f4b"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "C:\\crysis\\Release\\PDB\\payload.pdb" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Cryptolocker : FILE
{
	meta:
		description = "Detects Cryptolocker ransomware variants (Betarasite)"
		author = "ditekSHen"
		id = "4c6d714d-1fb1-55ce-8022-40f6f634e2cd"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4730-L4752"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e1700e8ace338c25119305878e8bc52210506bd42183007985ba9601abdab87b"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$x1 = "CryptoLocker" fullword wide
		$x2 = ".betarasite" fullword wide
		$x3 = "CMSTPBypass" fullword ascii
		$s1 = "CommandToExecute" fullword ascii
		$s2 = "SetInfFile" fullword ascii
		$s3 = "SchoolPrject1" ascii
		$s4 = "$730d5f64-bd57-47c1-9af4-d20aec714d02" fullword ascii
		$s5 = "Encrypt" fullword ascii
		$s6 = "Invalide Key! Please Try Again." fullword wide
		$s7 = "RegAsm" fullword wide
		$s8 = "Your key will be destroyed" wide
		$s9 = "encrypted using RC4 and RSA-2048" wide
		$c1 = "https://coinbase.com" fullword wide
		$c2 = "https://localbictoins.com" fullword wide
		$c3 = "https://bitpanda.com" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) or all of ( $s* ) or ( 2 of ( $x* ) and 5 of ( $s* ) ) or ( all of ( $c* ) and 1 of ( $x* ) and 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_PWSH_Poshwifistealer
{
	meta:
		description = "Detects PowerShell PoshWiFiStealer"
		author = "ditekSHen"
		id = "69ac123d-b746-57f1-a488-547f9a9cdd86"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4754-L4765"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "769349360b5d22226a5339a9e8471d06731dc522475c9385c1c145a0488e0ad1"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = "netsh wlan export profile" ascii
		$s2 = "Send-MailMessage" ascii
		$u1 = "https://github.com/axel05869/Wifi-Grab" ascii
		$u2 = "/exploitechx/wifi-password-extractor" ascii

	condition:
		all of ( $s* ) or all of ( $u* )
}
rule DITEKSHEN_MALWARE_Win_Steamhook : FILE
{
	meta:
		description = "Detects potential Steam stealer"
		author = "ditekSHen"
		id = "7533fb83-d721-54e6-8ae1-1c840dd5a13d"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4767-L4781"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "da743ca99fd19828e3938875acaf6544f17d884587a59623c8361f5905af4a57"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "Mozilla/4.0 (compatible; )" fullword ascii
		$s2 = "/steam/upload.php" ascii
		$s3 = ".*?(ssfn\\d+)" fullword ascii
		$s4 = "add cookie failed..." fullword ascii
		$s5 = "Content-Type: multipart/form-data; boundary=--MULTI-PARTS-FORM-DATA-BOUNDARY" fullword ascii
		$pdb1 = "\\SteamHook\\Install\\" ascii
		$pdb2 = "\\SteamHook\\dll\\" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or all of ( $pdb* ) or ( 1 of ( $pdb* ) and 3 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Netwire : FILE
{
	meta:
		description = "Detects NetWire RAT"
		author = "ditekSHen"
		id = "c215f449-c725-51da-8f5b-2619bc282b22"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4783-L4805"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "bae4f0cd7a431336bd784ba95f6ba3396e6f0f12c081e62482ad37ff859c1f1c"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "SOFTWARE\\NetWire" fullword ascii
		$x2 = { 4e 65 74 57 69 72 65 00 53 4f 46 54 57 41 52 45 5c 00 }
		$s1 = "User-Agent: Mozilla/4.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko" fullword ascii
		$s2 = "filenames.txt" fullword ascii
		$s3 = "GET %s HTTP/1.1" fullword ascii
		$s4 = "[%.2d/%.2d/%d %.2d:%.2d:%.2d]" fullword ascii
		$s5 = "Host.exe" fullword ascii
		$s6 = "-m \"%s\"" fullword ascii
		$g1 = "HostId" fullword ascii
		$g2 = "History" fullword ascii
		$g3 = "encrypted_key" fullword ascii
		$g4 = "Install Date" fullword ascii
		$g5 = "hostname" fullword ascii
		$g6 = "encryptedUsername" fullword ascii
		$g7 = "encryptedPassword" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or all of ( $x* ) or ( 1 of ( $x* ) and 2 of ( $s* ) ) or ( all of ( $g* ) and ( 2 of ( $s* ) or 1 of ( $x* ) ) ) )
}
rule DITEKSHEN_MALWARE_Win_Breakstaf : FILE
{
	meta:
		description = "Detects BreakStaf ransomware"
		author = "ditekSHen"
		id = "3c8ca485-2cb4-56fd-a1f5-16b43515cec9"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4807-L4827"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "56078b797c64ce77398f9b92e5677f7159d8357eafb03cf62bb30f06d4f3b2e3"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "C:\\Program files" wide
		$s2 = "C:\\Program files (x86)" wide
		$s3 = "C:\\System Volume Information" wide
		$s4 = "C:\\$Recycle.Bin" wide
		$s5 = "C:\\Windows" wide
		$s6 = ".?AVRandomNumberGenerator@Crypto" ascii
		$s7 = ".?AV?$SymmetricCipherFinal@" ascii
		$s8 = ".breakstaf" fullword wide nocase
		$s9 = "readme.txt" fullword wide nocase
		$s10 = ".VHD" fullword wide nocase
		$s11 = ".vhdx" fullword wide nocase
		$s12 = ".BAK" fullword wide nocase
		$s13 = ".BAC" fullword wide nocase

	condition:
		uint16( 0 ) == 0x5a4d and 12 of them
}
rule DITEKSHEN_MALWARE_Win_Kitty : FILE
{
	meta:
		description = "Detects HelloKitty ransomware, triggers on FIVEHANDS"
		author = "ditekSHen"
		id = "4147294a-7eff-595a-ad4f-8a84ffff960f"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4829-L4847"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "3a36755c81ec70c127bb73448fc29325444b85b5f0704327fc81975c2af2e99e"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Kitty" wide
		$s2 = "-path" fullword wide
		$s3 = "select * from Win32_ShadowCopy" fullword wide
		$s4 = "Win32_ShadowCopy.ID='%s'" fullword wide
		$s5 = "programdata" fullword wide
		$s6 = "$recycle.bin" fullword wide
		$s7 = ".crypt" fullword wide
		$s8 = "%s/secret/%S" wide
		$s9 = "decrypts3nln3tic.onion" wide
		$n1 = "read_me_lkd.txt" wide
		$n2 = "DECRYPT_NOTE.txt" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 5 of ( $s* ) or 1 of ( $n* ) and 4 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Dlagent07 : FILE
{
	meta:
		description = "Detects delf downloader agent"
		author = "ditekSHen"
		id = "a45afe84-15ae-528a-ad7e-ab9f03045789"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4849-L4867"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "1e0001d18524d0d34ad876e67e2c4dc0495ee18a73c34f53f97367876e27b406"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "C:\\Users\\Public\\Libraries\\temp" fullword ascii
		$s2 = "SOFTWARE\\Borland\\Delphi" ascii
		$s3 = "Mozilla/5.0(compatible; WinInet)" fullword ascii
		$o1 = { f3 a5 e9 6b ff ff ff 5a 5d 5f 5e 5b c3 a3 00 40 }
		$o2 = { e8 83 d5 ff ff 8b 15 34 40 41 00 89 10 89 58 04 }
		$o3 = { c3 8b c0 53 51 e8 f1 ff ff ff 8b d8 85 db 74 3e }
		$o4 = { e8 5c e2 ff ff 8b c3 e8 b9 ff ff ff 89 04 24 83 }
		$o5 = { 85 c0 74 1f e8 62 ff ff ff a3 98 40 41 00 e8 98 }
		$o6 = { 85 c0 74 19 e8 be ff ff ff 83 3d 98 40 41 00 ff }
		$x1 = "22:40:08        \"> <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"> <rdf:Description rdf:about=\"\"" ascii
		$x2 = "uuid:A9BD8E384B2FDE118D26E6EE744C235C\" stRef:documentID=\"uuid:A8BD8E384B2FDE118D26E6EE744C235C\"/>" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 2 of ( $s* ) and 5 of ( $o* ) ) or ( all of ( $s* ) and 2 of ( $o* ) ) or ( all of ( $x* ) and 2 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Clop : FILE
{
	meta:
		description = "Detects Clop ransomware variants"
		author = "ditekSHen"
		id = "d3c9e950-8b03-5d19-8448-9cf208813df2"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4869-L4889"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a1a21100c468c4db147f97b0724b7a3aefbb92b157071bfe6f61d02768573b44"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "Cllp^_-" ascii
		$s2 = "temp.dat" fullword wide
		$s3 = "README_README.txt" wide
		$s4 = "BEGIN PUBLIC KEY" ascii
		$s5 = "runrun" wide
		$s6 = "wevtutil.exe" ascii
		$s7 = "%s%s.Cllp" fullword wide
		$s8 = "WinCheckDRVs" fullword wide
		$o1 = { 6a ff 56 89 9d 28 dd ff ff ff d0 a1 64 32 41 00 }
		$o2 = { 56 89 9d 28 dd ff ff ff 15 78 32 41 00 eb 07 43 }
		$o3 = { 68 ?? 34 41 00 8d 85 58 dd ff ff 50 ff d7 85 c0 }
		$o4 = { 68 d0 34 41 00 50 ff d6 8b bd 28 d5 ff ff 83 c4 }
		$o5 = { a1 64 32 41 00 43 56 89 9d 08 d5 ff ff ff d0 8b }

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or ( 1 of ( $x* ) and ( 3 of ( $s* ) or 4 of ( $o* ) ) ) or ( all of ( $o* ) and 2 of ( $s* ) ) or ( 4 of ( $s* ) and 4 of ( $o* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Maktub : FILE
{
	meta:
		description = "Detects Maktub ransomware"
		author = "ditekSHen"
		id = "be47d858-8497-593f-865b-c3d3a5db6c2e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4891-L4905"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5c11d04fc3088eb8a0132b9ed83748ddb7e1bbe9d03b9e884d4003181cbb6d69"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Content-Disposition: attachment; filename=" ascii
		$s2 = "Mozilla/5.0 (Windows NT 6.1; rv:45.0) Gecko/20100101 Firefox/45.0" fullword ascii
		$s3 = "/tor/status-vote/current/consensus" ascii
		$s4 = "/tor/server/fp/" ascii
		$s5 = "/tor/rendezvous2/" ascii
		$s6 = "404 Not found" fullword ascii
		$s7 = /_request@\d+/ fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Pwshloader_Runpe01
{
	meta:
		description = "Detects PowerShell PE loader / executer. Observed Gorgon TTPs"
		author = "ditekSHen"
		id = "fd44f48c-7a24-512b-8375-c9f978a8b5bd"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4907-L4920"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "7dd377f6a1cc48ef8ab9d53989755fb967c89d3798b721781bc09043ba3d86f4"
		score = 75
		quality = 75
		tags = ""

	strings:
		$rp1 = "GetType('RunPe.RunPe'" ascii
		$rp2 = "GetType(\"RunPe.RunPe\"" ascii
		$rm1 = "GetMethod('Run'" ascii
		$rm2 = "GetMethod(\"Run\"" ascii
		$s1 = ".Invoke(" ascii
		$s2 = "[Reflection.Assembly]::Load(" ascii

	condition:
		all of ( $s* ) and 1 of ( $rp* ) and 1 of ( $rm* )
}
rule DITEKSHEN_MALWARE_Win_Pwshloader_Runpe02
{
	meta:
		description = "Detects PowerShell PE loader / executer. Observed Gorgon TTPs"
		author = "ditekSHen"
		id = "08261054-bebc-58fe-949a-27f6e817003a"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4922-L4934"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d7677689938d3e3eb6b59b99b7e347c60214f6edf8e5f83bf85da5a5f1ad33bb"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = "'.Replace('" ascii nocase
		$s2 = "'aspnet_compiler.exe'" ascii
		$s3 = "[Byte[]]$" ascii
		$pe1 = "(77,90," ascii
		$pe2 = "='4D5A" ascii

	condition:
		all of ( $s* ) and ( #pe1 > 1 or #pe2 > 1 ) and #s1 > 4
}
rule DITEKSHEN_MALWARE_Win_Peloader_Runpe : FILE
{
	meta:
		description = "Detects PE loader / injector. Observed Gorgon TTPs"
		author = "ditekSHen"
		id = "262dedee-05d2-5783-b0ff-24470d310ab8"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4936-L4950"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0369c3e2f83a0265c81e5dcd10b4d88753bd6ce3da4bb893a364486712a2b80d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "commandLine'" fullword ascii
		$s2 = "RunPe.dll" fullword ascii
		$s3 = "HandleRun" fullword ascii
		$s4 = "inheritHandles" fullword ascii
		$s5 = "BlockCopy" fullword ascii
		$s6 = "WriteProcessMemory" fullword ascii
		$s7 = "startupInfo" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Peloader_INF : FILE
{
	meta:
		description = "Detects PE loader / injector. Potentical HCrypt. Observed Gorgon TTPs"
		author = "ditekSHen"
		id = "09823302-34e0-5283-9740-1475ab8077be"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4952-L4963"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "758f7b465b8f9dab5c1194bee266392efe143ac219a5307e6886845b3c862700"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "Managament.inf" fullword ascii
		$x2 = "rOnAlDo" fullword ascii
		$x3 = "untimeResourceSet" fullword ascii
		$x4 = "3System.Resources.Tools.StronglyTypedResourceBuilder" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Dlagent08 : FILE
{
	meta:
		description = "Detects known downloader agent downloading encoded binaries in patches"
		author = "ditekSHen"
		id = "e3450f93-7c57-5386-a901-bc5e710657a4"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4965-L4975"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0238c13b00e5778ef216b4e8576c321803da6e269c96c3051b9cc45a3ac6e567"
		score = 75
		quality = 75
		tags = "FILE"
		snort2_sid = "920122"
		snort3_sid = "920119"

	strings:
		$pat = /\/base\/[A-F0-9]{32}\.html/ ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and $pat and #pat > 1
}
rule DITEKSHEN_MALWARE_Win_Doejocrypt : FILE
{
	meta:
		description = "Detects DoejoCrypt / DearCry ransomware"
		author = "ditekSHen"
		id = "2c90f8e7-ced4-56da-ab8d-61b5ba63dacd"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4977-L4993"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f8a3897de9522340799a59e3e755c323b0defaab73a9030b6b69a1a82c05dcd0"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "DEARCRY!" fullword ascii
		$s2 = ".CRYPT" fullword ascii
		$s3 = "\\EncryptFile -svcV2\\" ascii
		$s4 = "please send me the following hash!" ascii
		$s5 = "dear!!!" fullword ascii
		$s6 = "/readme.txt" fullword ascii
		$o1 = { c3 8b 65 e8 c7 45 fc fe ff ff ff 8b b5 f4 e9 ff }
		$o2 = { 0f 8c 27 ff ff ff 33 db 57 e8 7b 36 00 00 eb 0a }
		$o3 = { 0f 8c 2a ff ff ff 53 57 e8 b7 42 00 00 8b 4c 24 }

	condition:
		uint16( 0 ) == 0x5a4d and 4 of ( $s* ) or ( all of ( $o* ) and ( 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Sunshuttle : FILE
{
	meta:
		description = "Detects SunShuttle / GoldMax"
		author = "ditekSHen"
		id = "1618d0bc-6e72-5f1e-81e7-56611bfd7f8b"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L4995-L5017"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "fa8feb069e73aa0a7fcb4daecc1fdf8edeff65e5aeefef161626647fe989e5c0"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "main.beaconing" fullword ascii
		$s2 = "main.clean_file" fullword ascii
		$s3 = "main.decrypt" fullword ascii
		$s4 = "main.define_internal_settings" fullword ascii
		$s5 = "main.delete_empty" fullword ascii
		$s6 = "main.encrypt" fullword ascii
		$s7 = "main.false_requesting" fullword ascii
		$s8 = "main.removeBase64Padding" fullword ascii
		$s9 = "main.resolve_command" fullword ascii
		$s10 = "main.retrieve_session_key" fullword ascii
		$s11 = "main.save_internal_settings" fullword ascii
		$s12 = "main.send_command_result" fullword ascii
		$s13 = "main.send_file_part" fullword ascii
		$s14 = "main.wget_file" fullword ascii
		$s15 = "main.write_file" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Ranzylocker : FILE
{
	meta:
		description = "Detects RanzyLocker / REntS ransomware"
		author = "ditekSHen"
		id = "0d74f6fd-e1d2-5939-991e-7fdd2ca3310b"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5019-L5042"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "15897144843acf49b81c5428fd1bb56d7a2acf16047a6e5d3ca4f2aaa8891577"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$hr1 = "776261646D696E2044454C4554452053595354454D53544154454241434B5550" ascii
		$hr2 = "776D69632E65786520534841444F57434F5059202F6E6F696E746572616374697665" ascii
		$hr3 = "626364656469742E657865202F736574207B64656661756C747D207265636F76657279656E61626C6564204E6F" ascii
		$hr4 = "776261646D696E2044454C4554452053595354454D53544154454241434B5550202D64656C6574654F6C64657374" ascii
		$hr5 = "626364656469742E657865202F736574207B64656661756C747D20626F6F74737461747573706F6C6963792069676E6F7265616C6C6661696C75726573" ascii
		$hr6 = "76737361646D696E2E6578652044656C65746520536861646F7773202F416C6C202F5175696574" ascii
		$hx1 = "476C6F62616C5C33353335354641352D303745392D343238422D423541352D314338384341423242343838" ascii
		$hx2 = "534F4654574152455C4D6963726F736F66745C45524944" ascii
		$hx3 = "227375626964223A22" ascii
		$hx4 = "226E6574776F726B223A22" ascii
		$hx5 = "726561646D652E747874" ascii
		$hx6 = "-nolan" fullword wide
		$o1 = { 8d 45 e9 89 9d 54 ff ff ff 88 9d 44 ff ff ff 3b }
		$o2 = { 8b 44 24 2? 8b ?c 24 34 40 8b 54 24 38 89 44 24 }
		$o3 = { 8b 44 24 2? 8b ?c 24 1c 89 44 24 34 8b 44 24 28 }
		$o4 = { 8b 44 24 2? 8b ?c 24 34 05 00 00 a0 00 89 44 24 }

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $hx* ) or ( 2 of ( $hr* ) and 2 of ( $hx* ) ) or ( all of ( $o* ) and 2 of ( $h* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Wobbychipmbr : FILE
{
	meta:
		description = "Detects WobbyChipMBR / Covid-21 ransomware"
		author = "ditekSHen"
		id = "581fbce1-128d-5323-a259-14d9bfdf09b1"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5044-L5060"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "168c7f610625131c9552252d2b824a90918d2961996ee0f783497dff5cf17351"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "You became a Victim of the Covid-21 Ransomware" ascii wide
		$x2 = "Reinstalling Windows has been blocked" ascii wide
		$x3 = "Enter Decryption Key:" ascii wide
		$x4 = "encrypted with military grade encryption" ascii wide
		$s1 = "schtasks.exe /Create /TN wininit /ru SYSTEM /SC ONSTART /TR" ascii
		$s2 = "\\EFI\\Boot\\bootx64.efi" ascii wide
		$s3 = "DumpHex" fullword ascii
		$s4 = "TFTP Error" fullword wide
		$s5 = "HD(Part%d,MBRType=%02x,SigType=%02x)" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $x* ) or all of ( $s* ) or ( 1 of ( $x* ) and 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Snatch : FILE
{
	meta:
		description = "Detects Snatch / GoRansome / MauriGo ransomware"
		author = "ditekSHen"
		id = "00dce673-b909-571f-8117-c5d4ce73fb31"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5062-L5091"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "bf8c33a7203458c80a43944c3117bb897b1702f0024271904d9be682cbd695fc"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "main.encryptFile" ascii
		$s2 = "main.encryptFileExt" ascii
		$s3 = "main.deleteShadowCopy" ascii
		$s4 = "main.Shadow" fullword ascii
		$s5 = "main.RecoverMe" fullword ascii
		$s6 = "main.EncryptWithPublicKey" ascii
		$s7 = "main.EncoderLookupDir" fullword ascii
		$s8 = "main.ALIGNUP" fullword ascii
		$s9 = "main.encrypt" fullword ascii
		$s10 = "github.com/mauri870/ransomware" ascii
		$m1 = "Dear You, ALl Your files On YOUR network computers are encrypted" ascii
		$m2 = "You have to pay the ransom of %s USD in bitcoins to the address" ascii
		$m3 = "REMEMBER YOU FILES ARE IN SAVE HANDS AND WILL BE RESTORED OR RECOVERED ONCE PAYMENT IS DONE" ascii
		$m4 = ":HELP FEEED A CHILD:" ascii
		$m5 = ">SYSTEM NETWORK ENCRYPTED<" ascii
		$m6 = "YOUR IDENTIFICATION : %s" ascii
		$m7 = "convince you of our honesty" ascii
		$m8 = "use TOR browser to talk with support" ascii
		$m9 = "encrypted and attackers are taking" ascii
		$p1 = "/Go/src/kitty/kidrives/" ascii
		$p2 = "/LGoGo/encoder.go" ascii nocase
		$p3 = "/Go/src/kitty/kidata/" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $s* ) or 2 of ( $m* ) or ( 1 of ( $m* ) and 1 of ( $s* ) ) or ( all of ( $p* ) and ( 1 of ( $s* ) or 1 of ( $m* ) ) ) )
}
rule DITEKSHEN_MALWARE_Win_Meteorite : FILE
{
	meta:
		description = "Detects Meteorite downloader"
		author = "ditekSHen"
		id = "ce7a72ce-56a8-5def-a952-f0b08efe8a4a"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5093-L5109"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0ae8183d949046be4257b48571a266f2501d60dd302f511ca1a2d518884e6a7f"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "MeteoriteDownloader" fullword ascii wide
		$x2 = "Meteorite Downloader" fullword ascii wide
		$x3 = "Meteorite Downloader v" wide
		$s1 = "regwrite" fullword wide
		$s2 = "urlmon" fullword ascii
		$s3 = "wscript.shell" fullword wide
		$s4 = "modMain" fullword ascii
		$s5 = "VBA6.DLL" fullword ascii
		$s6 = "^_http" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $x* ) or ( 5 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Legionlocker : FILE
{
	meta:
		description = "Detects LegionLocker ransomware"
		author = "ditekSHen"
		id = "4e5c50d0-808e-5adb-bce9-804ddf66ca61"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5111-L5129"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "2da897b5603415f14fff134b3a94d77e6963da79e117d26ba16e6b04e45f4045"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$m1 = "+Do not run task manager, powershell, cmd etc." ascii wide
		$m2 = "3 hours your files will be deleted." ascii wide
		$m3 = "files have been encrypted by Legion Locker" ascii wide
		$s1 = "passwordBytes" fullword ascii
		$s2 = "_start_enc_" ascii
		$s3 = "_del_desktop_" ascii
		$s4 = "Processhacker" wide
		$s5 = "/k color 47 && del /f /s /q %userprofile%\\" wide
		$s6 = "Submit code" fullword wide
		$pdb1 = "\\obj\\Debug\\LegionLocker.pdb" ascii
		$pdb2 = "\\obj\\Release\\LegionLocker.pdb" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $m* ) or 1 of ( $pdb* ) or 4 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Dlagentgo : FILE
{
	meta:
		description = "Detects Go-based downloader"
		author = "ditekSHen"
		id = "e16ccb89-2eb6-5457-a88e-f802f3c35764"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5131-L5144"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b9dd2446eddff18be00feb34d8911600feb395a9ce2566786d42b48b444230d0"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "main.downloadFile" fullword ascii
		$s2 = "main.fetchFiles" fullword ascii
		$s3 = "main.createDefenderAllowanceException" fullword ascii
		$s4 = "main.unzip" fullword ascii
		$s5 = "HideWindow" fullword ascii
		$s6 = "/go/src/installwrap/main.go" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Win_Blackmoon : FILE
{
	meta:
		description = "Detects executables using BlackMoon RunTime"
		author = "ditekSHen"
		id = "76071d36-3d2d-589c-8c3f-0ae60e69996e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5146-L5155"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "05bfde8ec3a469df5707c195e25995ac6af730e8a1595b1a598276c024420be2"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "blackmoon" fullword ascii
		$s2 = "BlackMoon RunTime Error:" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Iceid : FILE
{
	meta:
		description = "Detects IceID / Bokbot variants"
		author = "ditekSHen"
		id = "0da94737-0f82-5892-a0eb-f9f3c0a114cc"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5157-L5176"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "204b4c297806a36ca14bb3e659824f4eb49b18308af7090f0db1194705f1e2c9"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$n1 = "POST" fullword wide
		$n2 = "; _gat=" fullword wide
		$n3 = "; _ga=" fullword wide
		$n4 = "; _u=" fullword wide
		$n5 = "; __io=" fullword wide
		$n6 = "; _gid=" fullword wide
		$n7 = "Cookie: __gads=" fullword wide
		$s1 = "c:\\ProgramData" ascii
		$s2 = "loader_dll_64.dll" fullword ascii
		$s3 = "loader_dll_32.dll" fullword ascii
		$s4 = "/?id=%0.2X%0.8X%0.8X%s" ascii
		$s5 = "%0.2X%0.2X%0.2X%0.2X%0.2X%0.2X%0.8X" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( all of ( $n* ) and 1 of ( $s* ) ) or ( 3 of ( $s* ) and 1 of ( $n* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Purge : FILE
{
	meta:
		description = "Detects Purge ransomware"
		author = "ditekSHen"
		id = "b3fb9f38-ce12-5e0e-8908-3379b5da3497"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5178-L5201"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "83d13eca69bc99539e47d6d29689edf2a4fcd2260c6e909582126a490eef8115"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$n1 = "imagesave/imagesize.php" ascii
		$n2 = "imageinfo.html" ascii
		$n3 = "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)" ascii
		$n4 = "Content-Type: application/x-www-form-urlencoded" ascii
		$m1 = "YOUR_ID: %x%x" wide
		$m2 = "Specially for your PC was generated personal" wide
		$m3 = "which is on our Secret Server" wide
		$m4 = "wait for a miracle and get your price" wide
		$s1 = "%s\\SpyHunter Remove Ransomware" wide
		$s2 = "$recycle.bin" fullword wide
		$s3 = "TheEnd" fullword wide
		$s4 = "%s\\HELP_DECRYPT_YOUR_FILES.TXT" fullword wide
		$s5 = "%s.id_%x%x_email_" wide
		$s6 = "scmd" fullword wide
		$s7 = "process call create \"%s\"" wide
		$s8 = "FinishEnds" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or all of ( $n* ) or 2 of ( $m* ) or ( 3 of ( $s* ) and ( 1 of ( $n* ) or 1 of ( $m* ) ) ) )
}
rule DITEKSHEN_MALWARE_Win_Njrat : FILE
{
	meta:
		description = "Detects NjRAT / Bladabindi / NjRAT Golden"
		author = "ditekSHen"
		id = "078dea64-8f95-5939-a1fb-c0a888adcf0d"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5203-L5220"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "92d535a7c7f361b7a0901d0b99427ebc82a69577bfea73c04a7f9d51d2054b36"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = /Njrat\s\d+\.\d+\sGolden\s/ wide
		$s1 = /\sfirewall\s(add|delete)\sallowedprogram/ wide
		$s2 = { 63 00 6d 00 64 00 2e 00 65 00 78 00 65 00 20 00 2f 00 (63|6b) 00 20 00 70 00 69 00 6e 00 67 }
		$s3 = "Execute ERROR" wide
		$s4 = "Download ERROR" wide
		$s5 = "[kl]" fullword wide
		$s6 = "UploadValues" fullword wide
		$s7 = "winmgmts:\\\\.\\root\\SecurityCenter2" fullword wide
		$s8 = "HideM" fullword wide
		$s9 = "No Antivirus" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Win_Darktrackrat : FILE
{
	meta:
		description = "Detects OzoneRAT / DarkTrack / DarkSky"
		author = "ditekSHen"
		id = "ef8675f8-f643-5948-a967-e4a9ce5ab89e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5222-L5245"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "2a831c0f7707864d8c9e9fa338085a52933869d8cfbdbe0d12715da301c12646"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "Klog.dat" ascii
		$x2 = "I_AM_DT" ascii
		$x3 = " Alien" ascii
		$x4 = "Local Victim" ascii
		$x5 = "Dtback\\AlienEdition\\Server\\SuperObject.pas" ascii
		$x6 = "].encryptedUsername" ascii
		$x7 = "].encryptedPassword" ascii
		$x8 = { 49 41 4d [6] 44 41 52 [0-2] 4b [6] 44 54 41 43 4b }
		$s1 = "AntiVirusProduct" ascii
		$s2 = "AntiSpywareProduct" ascii
		$s3 = "ConnectServer" ascii
		$s4 = "ExecQuery" ascii
		$s5 = "\\Drivers\\Etc\\Hosts" fullword ascii
		$s6 = "BTMemoryLoadLibary: Get DLLEntyPoint" ascii
		$s7 = "\\\\.\\SyserDbgMsg" fullword ascii
		$s8 = "\\\\.\\SyserBoot" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 4 of ( $x* ) or 6 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Godzilla : FILE
{
	meta:
		description = "Detects Godzilla loader"
		author = "ditekSHen"
		id = "3384b844-6abf-5f94-a62b-7ebbdfe321bd"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5247-L5265"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ff87fbaaf488ac69e06a03a7f8e5305ec114caa6271c25fa130033f50f0d9095"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "MSVBVM60.DLL" fullword ascii
		$x2 = "Loginserver8" fullword ascii
		$x3 = "Proflogger7" fullword ascii
		$s1 = "Badgeless5" fullword ascii
		$s2 = "Montebrasite3" fullword ascii
		$s3 = "Atelomyelia4" fullword ascii
		$s4 = "Xxencoded5" fullword ascii
		$s5 = "Garneau2" fullword ascii
		$s6 = "Hypostasis0" fullword ascii
		$s7 = "Piarhemia4" fullword ascii
		$s8 = "Foredestine8" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of ( $x* ) and 2 of ( $s* )
}
rule DITEKSHEN_MALWARE_Win_UNK03 : FILE
{
	meta:
		description = "Detects unknown malware"
		author = "ditekSHen"
		id = "b0711427-b6bf-5e4b-af36-9c752ead4d6c"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5267-L5280"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f1a4be68206628c3addbce8b6bbc1f801e67632d4e6a6af1d45cdad833e9a991"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Software\\Microsoft\\Windows\\CurrentVersion" ascii
		$s2 = "rundll32.exe C:\\Windows\\System32\\shimgvw.dll,ImageView_Fullscreen %s" ascii
		$s3 = "%s.jpg" ascii
		$s4 = "%s\\sz.txt" ascii
		$s5 = "ChromeSecsv9867%d7.exe" ascii
		$s6 = "%s\\appl%c.jpg" ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_UNK04 : FILE
{
	meta:
		description = "Detects unknown malware (proxy tool)"
		author = "ditekSHen"
		id = "6a178f37-a9fd-5a83-a550-c6333342ac9b"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5282-L5296"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ba6e5bbc1d094b23e3870af963503d1ccbcd56adc24126b4a38b77d4b88b4b67"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "127.0.0.1/%d" fullword ascii
		$x2 = "SYSTEM\\CurrentControlSet\\SERVICES\\PORTPROXY\\V4TOV4\\TCP" fullword ascii
		$x3 = "%s rundll32.exe" fullword ascii
		$s1 = "kxetray.exe" fullword ascii
		$s2 = "ksafe.exe" fullword ascii
		$s3 = "Mcshield.exe" fullword ascii
		$s4 = "Miner.exe" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of ( $x* ) and 2 of ( $s* )
}
rule DITEKSHEN_MALWARE_Win_Karkoff : FILE
{
	meta:
		description = "Detects Karkoff"
		author = "ditekSHen"
		id = "7d2fe783-18b3-5d84-a9b5-e8e0b5a0db98"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5298-L5313"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e9b6ba5be2b3cd0faa898347e57cee5a57b80b19842c3a1ddb42d620307c8b39"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "C:\\Windows\\Temp\\MSEx_log.txt" fullword wide
		$x2 = "CMD.exe" fullword wide
		$x3 = "Karkoff.ProjectInstaller.resources" fullword ascii
		$s1 = /try\shttp(s)?\s(ip|domain)/ fullword wide
		$s2 = "Reg cleaned!" fullword wide nocase
		$s3 = "Content-Disposition: form-data; name=\"{1}\"" fullword wide
		$s4 = "^[A-Fa-f0-9]{8}-([A-Fa-f0-9]{4}-){3}[A-Fa-f0-9]{12}$" fullword wide
		$s5 = "new backdoor" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) or 4 of ( $s* ) or ( 2 of ( $x* ) and 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Dlagent09 : FILE
{
	meta:
		description = "Detects known downloader agent"
		author = "ditekSHen"
		id = "90f71ac7-19d9-5a8e-9830-df2f16e12c9b"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5315-L5328"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9336507fa4bb9d3a6325d5e9caafc8c4e816a0166fded7d4e53e09a87628bc89"
		score = 75
		quality = 71
		tags = "FILE"

	strings:
		$h1 = "//:ptth" ascii wide nocase
		$h2 = "//:sptth" ascii wide nocase
		$s1 = "DownloadString" fullword ascii wide
		$s2 = "StrReverse" fullword ascii wide
		$s3 = "FromBase64String" fullword ascii wide
		$s4 = "WebClient" fullword ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $h* ) and all of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Coinminingbot : FILE
{
	meta:
		description = "Detects coinmining bot"
		author = "ditekSHen"
		id = "df15bfbd-f531-5eaa-b160-ad8a1fbe992f"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5330-L5343"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a307a6c9184e8f4068cfa89a8432ae017c8aab10b706ba065051f8749860c15c"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "FullScreenDetect" fullword ascii
		$s2 = "GetChildProcesses" fullword ascii
		$s3 = "HideBotPath" fullword ascii
		$s4 = "Inject" fullword ascii
		$s5 = "DownloadFile" fullword ascii
		$s6 = "/Data/GetUpdateInfo" wide

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}

rule DITEKSHEN_MALWARE_Win_Fyanti : FILE
{
	meta:
		description = "Hunt for FYAnti third-stage loader DLLs"
		author = "ditekSHen"
		id = "7a1f913c-d83f-50e9-943c-246c4c71c654"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5345-L5351"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "baaeef0b1452d7ea41ffaaff592cac2c5e16f921dbbfb3a300a63e69f134e9d0"
		score = 75
		quality = 75
		tags = "FILE"

	condition:
		uint16( 0 ) == 0x5a4d and pe.is_dll ( ) and pe.exports ( "FuckYouAnti" )
}
rule DITEKSHEN_MALWARE_Win_Pureloader : FILE
{
	meta:
		description = "Detects Pure loader / injector"
		author = "ditekSHen"
		id = "ad44a12a-4ac7-5cc7-92ab-13c23514de69"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5366-L5382"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "1f0bd20e769ea79d28d6e60ca06aa8aa2b3436426cfe0cd4f2023a08236875cd"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "InvokeMember" fullword wide
		$s2 = "ConcatProducer" fullword wide
		$s3 = ".Classes.Resolver" wide
		$s4 = "get_DLL" fullword ascii
		$s5 = "BufferedStream" fullword ascii
		$s6 = "GZipStream" fullword ascii
		$s7 = "MemoryStream" fullword ascii
		$s8 = "Decompress" fullword ascii
		$s9 = "lSystem.Resources.ResourceReader, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089#System.Resources.R" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 8 of them
}
rule DITEKSHEN_MALWARE_Win_VBS_Dlagent01
{
	meta:
		description = "Detects VBS MSHTA downloader"
		author = "ditekSHen"
		id = "447ea323-ecab-5f6b-b13e-0690254c754e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5384-L5395"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0e47839a55773764aca0aebcf1078c06c729b86d1e2f18d7d64e3bb11e87f3eb"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = "llehS.tpircsW" ascii
		$s2 = ".Run" ascii
		$s3 = "mshta http" ascii nocase
		$s4 = "StrReverse" ascii

	condition:
		all of them
}
rule DITEKSHEN_MALWARE_Win_Ranumbot : FILE
{
	meta:
		description = "Detects RanumBot / Windigo / GoStealer"
		author = "ditekSHen"
		id = "26a0832e-8a39-5a0e-bd39-710744212c16"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5397-L5430"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a9c32445e62d072e4184d25497696ef6225edb176dc7a9743a54194d4ddb4b0c"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$f1 = "main.addSchedulerTaskSSH" fullword ascii
		$f2 = "main.attackRouter" fullword ascii
		$f3 = "main.decryptPassword" fullword ascii
		$f4 = "main.handleScanRequest" fullword ascii
		$f5 = "main.scanNetwork" fullword ascii
		$f6 = "main.extractCredentials" fullword ascii
		$s1 = "H_T= H_a= H_g= MB,  W_a= and  h_a= h_g= h_t= max= ptr  siz= tab= top= u_a= u_g=%s/16%s:%d%s:22+0330+0430+0530+0545+0630+0845+10" ascii
		$s2 = "<== as  at  fp= is  lr: of  on  pc= sp: sp=) = ) m=+Inf, n -Inf00%x112212343125: p=ABRTACDTACSTAEDTAESTAKDTAKSTALRMAWSTAhomAtoiCESTChamDashEESTGOGCJulyJuneKILLLEAFLisuMiaoModiNZDTNZSTNewaPIPEQUITSASTSEGVTERMThai" ascii
		$s3 = "W*struct { P *big.Int; Q *big.Int; G *big.Int; Y *big.Int; Rest []uint8 \"ssh:\\\"rest\\\"\" }" ascii
		$s4 = "policy=api,ftp,local,password,policy,read,reboot,sensitive,sniff,ssh,telnet,test,web,winbox,write" ascii
		$s5 = "/Users/alexander/go/src/mikrotik/winbox.go" ascii
		$xf1 = "main.readConfig" fullword ascii
		$xf2 = "main.ensureRunningAsUser" fullword ascii
		$xf3 = "main.configRegPath" fullword ascii
		$xf4 = "main.oldConfigRegPath" fullword ascii
		$uf1 = "main.locateChrome" fullword ascii
		$uf2 = "main.decryptAndUploadProfile" fullword ascii
		$uf3 = "main.decryptCookies" fullword ascii
		$uf4 = "main.extractPasswords" fullword ascii
		$uf5 = "main.getFirefoxProfile" fullword ascii
		$uf6 = "main.postBrowsersData" fullword ascii
		$uf7 = "main.uploadFirefoxProfile" fullword ascii
		$uf8 = "main.zipFirefoxProfile" fullword ascii
		$uf9 = /main\.detect(Browsers|Chrome|Coccoc|Edge|Firefox|InternetExplorer|Opera|Yandex)/ fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 5 of ( $f* ) or 4 of ( $s* ) or ( 2 of ( $f* ) and 2 of ( $s* ) ) or ( all of ( $xf* ) and 1 of ( $uf* ) ) or 6 of ( $uf* ) )
}
rule DITEKSHEN_MALWARE_Win_Dllhijacker01 : FILE
{
	meta:
		description = "Hunt for VSNTAR21 / DllHijacker01 IronTiger / LuckyMouse / APT27 malware"
		author = "ditekSHen"
		id = "0a858058-310a-5b1c-a6fe-abdec7b25abe"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5432-L5448"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "48535c0bb5342e2f91ac9d015c761d8d543b122dd3cc08b7029631fcf3037bfb"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "libvlc_add_intf" fullword ascii
		$s2 = "libvlc_dllonexit" fullword ascii
		$s3 = "libvlc_getmainargs" fullword ascii
		$s4 = "libvlc_initenv" fullword ascii
		$s5 = "libvlc_set_app_id" fullword ascii
		$s6 = "libvlc_set_app_type" fullword ascii
		$s7 = "libvlc_set_user_agent" fullword ascii
		$s8 = "libvlc_wait" fullword ascii
		$s9 = "dll.dll" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Hyperbro02 : FILE
{
	meta:
		description = "Detects HyperBro IronTiger / LuckyMouse / APT27 malware"
		author = "ditekSHen"
		id = "1880afd7-ca06-5b43-af8f-e791ded0d7d8"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5450-L5474"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ca4ee116516549fc42f7e32b3c24d631b7f2c638efbde5c07227358e78fd6f35"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\cmd.exe /A" fullword wide
		$s2 = "C:\\windows\\explorer.exe" fullword wide
		$s3 = "\\\\.\\pipe\\testpipe" fullword wide
		$s4 = "Elevation:Administrator!new:{" wide
		$s5 = "log.log" fullword wide
		$s6 = "%s\\%d.exe" fullword wide
		$s7 = ".?AVTPipeProtocol@@" fullword ascii
		$s8 = ".?AVTCaptureMgr@@" fullword ascii
		$s9 = "system-%d" fullword wide
		$s10 = "[test] %02d:%02d:%02d:%03d %s" fullword wide
		$s11 = "\\..\\data.dat" fullword wide
		$s12 = "\\..\\config.ini" fullword wide
		$s13 = { 73 00 76 00 63 00 68 00 6f 00 73 00 74 00 2e 00 65 00 78 00 65 00 00 00 20 00 2d 00 77 00 6f 00 72 00 6b 00 65 00 72 00 }
		$s14 = { 73 00 76 00 63 00 68 00 6f 00 73 00 74 00 2e 00 65 00 78 00 65 00 00 00 20 00 2d 00 64 00 61 00 65 00 6d 00 6f 00 6e 00 }
		$cnc1 = "https://%s:%d/ajax" fullword wide
		$cnc2 = "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.116 Safari/537.36" fullword wide
		$cnc3 = "139.180.208.225" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 7 of ( $s* ) or ( 2 of ( $cnc* ) and 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Dllhijacker02 : FILE
{
	meta:
		description = "Detects ServiceCrt / DllHijacker03 IronTiger / LuckyMouse / APT27 malware"
		author = "ditekSHen"
		id = "de5eee06-570a-5ec3-9e1b-13de4c4f260f"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5512-L5527"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d4eb236256c413d4d3223cc897783f5631c7798c0f3280e72d8c8504438fcaf9"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "ServiceCrtMain" fullword ascii
		$s2 = "mpsvc.dll" fullword ascii
		$o1 = { 84 db 0f 85 4c ff ff ff e8 14 06 00 00 8b f0 83 }
		$o2 = { f7 c1 00 ff ff ff 75 c5 eb 13 0f ba 25 10 20 01 }
		$o3 = { 8d 04 b1 8b d9 89 45 fc 8d 34 b9 a1 18 20 01 10 }
		$o4 = { b0 01 c3 68 b8 2c 01 10 e8 83 ff ff ff c7 04 24 }
		$o5 = { eb 34 66 0f 12 0d 00 fe 00 10 f2 0f 59 c1 ba cc }
		$o6 = { 73 c7 dc 0d 4c ff 00 10 eb bf dd 05 34 ff 00 10 }

	condition:
		uint16( 0 ) == 0x5a4d and all of ( $s* ) and 5 of ( $o* )
}
rule DITEKSHEN_MALWARE_Win_Zeoticus : FILE
{
	meta:
		description = "Detects Zeoticus ransomware"
		author = "ditekSHen"
		id = "6d1096dd-d075-54eb-ade9-48e2f945145d"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5529-L5549"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "588c140c141e82dae56758550549dfb96410db50521ac546477e1adc5575b4a0"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Dear %s" fullword wide
		$s2 = "\\??\\UNC\\%s\\%s\\" wide
		$s3 = "\\\\%ws\\admin$\\%ws" wide
		$s4 = "%s /node:\"%ws\" /user:\"%ws\" /password:" wide
		$s5 = "process call create" wide
		$s6 = ">----===Zeoticus" ascii
		$s7 = "ZEOTICUSV2" ascii
		$s8 = "GetExtendedTcpTable" fullword ascii
		$s9 = "SHAMROckSWTF" ascii
		$s10 = "NTDLL.RtlAllocateHeap" fullword ascii
		$s11 = ".pandora" fullword wide
		$s12 = { 70 00 20 00 72 00 20 00 69 00 20 00 76 00 20 00 65 00 20 00 74 }
		$pdb = "_cryptor\\shell_gen\\Release\\" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 6 of ( $s* ) or ( $pdb ) )
}
rule DITEKSHEN_MALWARE_Win_Dlagent11 : FILE
{
	meta:
		description = "Detects downloader agent"
		author = "ditekSHen"
		id = "c8bf9b1a-4ec1-5291-a334-82c79980ef53"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5551-L5564"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "61df4855766050237c0b67bf70684020beb5d88f5928fa2814077e505be938a6"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$pdb = "\\loader2\\obj\\Debug\\loader2.pdb" ascii
		$s1 = "DownloadFile" fullword ascii
		$s2 = "ZipFile" fullword ascii
		$s3 = "WebClient" fullword ascii
		$s4 = "ExtractToDirectory" fullword ascii
		$s5 = "System Clear" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or ( ( $pdb ) and 4 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Softcnapp : FILE
{
	meta:
		description = "Detects SoftCNApp"
		author = "ditekSHen"
		id = "473442e2-d411-5e2b-948e-c7ce034a5810"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5566-L5583"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "2d7f4320282218842fa2e82906bcaf691610ad1a6ea257a2a9fc9e062229a2e8"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\\\.\\PIPE\\SOC%d" fullword ascii
		$s2 = "Mozilla/5.0 (Windows NT 6.1)" fullword ascii
		$s3 = "Param: sl=%d; sl=%d; sl=%d; sl=%d; sl=%d;" fullword ascii
		$s4 = ".?AVCHPPlugin@@" fullword ascii
		$s5 = ".?AVCHPCmd@@" fullword ascii
		$s6 = ".?AVCHPExplorer@@" fullword ascii
		$s7 = "%s\\svchost.exe -O" fullword wide
		$s8 = "\"%s\\%s\" -P" fullword ascii
		$n1 = "45.63.58.34" fullword ascii
		$n2 = "127.0.0.1" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 4 of ( $s* ) or ( all of ( $n* ) and 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Covenantgruntstager : FILE
{
	meta:
		description = "Detects Covenant Grunt Stager"
		author = "ditekSHen"
		id = "61495541-ed9c-5227-aa50-cbaeacfb20a2"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5585-L5606"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "638f63f605b21154f062b0f4d0659cd6cd87aee319debb2c1a991a679fec087a"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "VXNlci1BZ2VudA" ascii wide
		$x2 = "cGFnZT17R1VJRH0mdj0x" ascii wide
		$x3 = "0eXBlPXtHVUlEfSZ2PTE" ascii wide
		$x4 = "tZXNzYWdlPXtHVUlEfSZ2PTE" ascii wide
		$x5 = "L2VuLXVzL" ascii wide
		$x6 = "L2VuLXVzL2luZGV4Lmh0bWw" ascii wide
		$x7 = "L2VuLXVzL2RvY3MuaHRtbD" ascii wide
		$s1 = "ExecuteStager" ascii
		$s2 = "UseCertPinning" fullword ascii
		$s3 = "FromBase64String" fullword ascii
		$s4 = "ToBase64String" fullword ascii
		$s5 = "DownloadString" fullword ascii
		$s6 = "UploadString" fullword ascii
		$s7 = "GetWebRequest" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $x* ) or all of ( $s* ) or ( 1 of ( $x* ) and 5 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Fabookie : FILE
{
	meta:
		description = "Detects Fabookie / ElysiumStealer"
		author = "ditekSHen"
		id = "dfa653c4-37d9-5e31-9c47-23adf751e4aa"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5608-L5624"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "bbe10323817d501a361a33abf61a49ad59fcac69d78d9d9ec1744ee99a4b4629"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "rwinssyslog" fullword wide
		$s2 = "_kasssperskdy" fullword wide
		$s3 = "[Title:%s]" fullword wide
		$s4 = "[Execute]" fullword wide
		$s5 = "[Snapshot]" fullword wide
		$s6 = "Mozilla/4.0 (compatible)" fullword wide
		$s7 = "d-k netsvcs" fullword wide
		$s8 = "facebook.websmails.com" fullword wide
		$s9 = "CUdpClient::Start" fullword ascii

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0x0805 ) and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Cobianrat : FILE
{
	meta:
		description = "Detects CobianRAT, a fork of Njrat"
		author = "ditekSHen"
		id = "5a9b6f04-fc52-52a9-b72f-d24dd093e886"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5626-L5640"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5c8f55e5328b61c3591c876797b4521f8e98af7a6c53bab918f10d5c3c2b5013"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "1.0.40.7" fullword wide
		$s2 = "DownloadData" fullword wide
		$s3 = "Executed As" fullword wide
		$s4 = "\\Plugins" fullword wide
		$s5 = "LOGIN" fullword wide
		$s6 = "software\\microsoft\\windows\\currentversion\\run" wide
		$s7 = "Hidden" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Leivion : FILE
{
	meta:
		description = "Detects Leivion"
		author = "ditekSHen"
		id = "77800add-8fff-5657-9ed6-a23517bce0b1"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5660-L5673"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a0cda23df4301b66feedad7c04b4d051c07474ccaa07c05598dd0b47bb6fc7e6"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "/var/lib/veil/go/src/runtime/mem_windows.go" fullword ascii
		$s2 = "/var/lib/veil/go/src/internal/singleflight/singleflight.go" fullword ascii
		$s3 = "/var/lib/veil/go/src/net/http/sniff.go" fullword ascii
		$s4 = "/var/lib/veil/go/src/net/sendfile_windows.go" fullword ascii
		$s5 = "/var/lib/veil/go/src/os/exec_" ascii
		$s6 = "/var/lib/veil/go/src/runtime/mgcsweep.go" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Win_Banload : FILE
{
	meta:
		description = "Detects Banload"
		author = "ditekSHen"
		id = "4672bce1-1280-576d-b7df-f0181a854058"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5675-L5688"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5cbc69d11b73f60d6eee3f23ed6cc217ba37a3408cb69e396e0394b5a1e20b75"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "main.die" fullword ascii
		$s2 = "main.postResults" fullword ascii
		$s3 = "main.checkin" fullword ascii
		$s4 = "RegQueryValueExWRemoveDirectoryWSETTINGS_TIMEOUTTerminateProcessUpgrade RequiredUser-Agent: %s" ascii
		$s5 = "pcuser-agentws2_32.dll (targetpc= DigestType ErrCode=%v" ascii
		$s6 = "invalid pc-encoded table f=runtime: invalid typeBitsBulkBarrie" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Infinitylock : FILE
{
	meta:
		description = "Detects InfinityLock ransomware"
		author = "ditekSHen"
		id = "7a66cc19-c635-580b-abc2-b58bd48673bd"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5705-L5723"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "634759f1c2d48becebc9c87e146e898524071738f74b7001b112dc793bcb581c"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "_Encrypted$" fullword ascii
		$s2 = "PublicKeyToken=" fullword ascii nocase
		$s3 = "GenerateHWID" fullword ascii
		$s4 = "CreateKey" fullword ascii
		$d1 = "ProgrammFiles" fullword ascii
		$d2 = "OneDrive" fullword ascii
		$d3 = "ProgrammsX86" fullword ascii
		$d4 = "UserDirs" fullword ascii
		$d5 = "B_Drive" fullword ascii
		$pdb1 = "F:\\DESKTOP!\\ChkDsk\\ChkDsk\\obj\\" ascii
		$pdb2 = "\\ChkDsk\\obj\\Debug\\PremiereCrack.pdb" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( all of ( $s* ) and 1 of ( $d* ) ) or ( 4 of ( $d* ) and 2 of ( $s* ) ) or ( any of ( $pdb* ) and 1 of ( $s* ) and 1 of ( $d* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Mountlocker : FILE
{
	meta:
		description = "Detects MountLocker ransomware"
		author = "ditekSHen"
		id = "0590d08d-1ee8-5dfe-af12-15b149acd2d6"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5725-L5740"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "30bc601fef60cc1c9d8bff5dd3f8a53214f088b74eb24fe2369f5664613e0eaf"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "] locker.dir.check > " ascii wide
		$s2 = "] locekr.kill." ascii wide
		$s3 = "] locker.worm" ascii wide
		$s4 = "%CLIENT_ID%" fullword ascii
		$s5 = "RecoveryManual.html" ascii wide
		$s6 = "RECOVERY MANUAL" ascii
		$s7 = ".ReadManual.%0.8X" ascii wide
		$s8 = "/?cid=%CLIENT_ID%" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 3 of them
}
rule DITEKSHEN_MALWARE_Win_Pingback : FILE
{
	meta:
		description = "Detects PingBack ICMP backdoor"
		author = "ditekSHen"
		id = "ecb313b6-f923-5b6d-a4d7-a4650817ed84"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5742-L5761"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c5fa9ecefca1188ba5e81c0518f74023884ad0f66718fc030601cb458bdf2f12"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Sniffer ok!" fullword ascii
		$s2 = "recv icmp packet!" fullword ascii
		$s3 = "WSASocket() failed: %d" fullword ascii
		$s4 = "file on remote computers success" ascii
		$s5 = "listen port error!" fullword ascii
		$s6 = "\\PingBackService" ascii
		$c1 = "exec" fullword ascii
		$c2 = "rexec" fullword ascii
		$c3 = "exep" fullword ascii
		$c4 = "download" fullword ascii
		$c5 = "upload" fullword ascii
		$c6 = "shell" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $s* ) or all of ( $c* ) or ( 4 of ( $c* ) and 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Bazarloader : FILE
{
	meta:
		description = "Detects BazarLoader variants"
		author = "ditekSHen"
		id = "6282df59-7244-501f-bb60-09a2a519bd47"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5763-L5776"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "8febd1355bc03f71794ffb8d51cbb112e8acd2d26fec5bb736a388d5384e7747"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Startdelay for %d ms to avoid some dynamic AV detects!" ascii
		$s2 = "Use Debug for moving faster!" ascii
		$s3 = "Logging Mutex %s to %s" ascii
		$s4 = "FIRST AND ONLY COPY RUNNING! Mutex %s" ascii
		$s5 = "the most secret 3d GetWinApiPointers line in the world!" ascii
		$s6 = "[+] makeMD5hash. " ascii

	condition:
		uint16( 0 ) == 0x5a4d and 3 of ( $s* )
}
rule DITEKSHEN_MALWARE_Win_Coinminer01 : FILE
{
	meta:
		description = "Detects coinmining malware"
		author = "ditekSHen"
		id = "739e7cea-c6b6-5add-86d4-382b00e2b645"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5778-L5790"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "31a7531ecc7b8a35ba882c17d15bd3581e65b4b99dd3a7cb8bca8f6edf204114"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "-o pool." ascii wide
		$s2 = "--cpu-max-threads-hint" ascii wide
		$s3 = "-P stratum" ascii wide
		$s4 = "--farm-retries" ascii wide
		$dl = "github.com/ethereum-mining/ethminer/releases/download" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $s* ) or ( $dl ) )
}
rule DITEKSHEN_PUA_Win_Ultrasurf : FILE
{
	meta:
		description = "Detects UltraSurf / Ultrareach PUA"
		author = "ditekSHen"
		id = "ba0f6867-bddc-5e72-978c-8e29b1b6b709"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5792-L5807"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d8d17b1bf20c12f864697d3dd66f345a8b93e2a75f0489b58b23b7f5264b6be3"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Ultrareach Internet Corp." ascii
		$s2 = "UltrasurfUnionRectUrlFixupWUse Proxy" ascii
		$s3 = "Ultrasurf UnlockFileUrlEscapeWUser-Agent" ascii wide
		$s4 = "Ultrasurf0#" ascii
		$m1 = "main.bindata_read" fullword ascii
		$m2 = "main.icon64_png" fullword ascii
		$m3 = "main.setProxy" fullword ascii
		$m4 = "main.openbrowser" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $s* ) or ( all of ( $m* ) and 1 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Hello : FILE
{
	meta:
		description = "Hunt for Hello / WickrMe ransomware"
		author = "ditekSHen"
		id = "99c11aab-8a3a-5e10-9af0-542e55129d51"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5809-L5820"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f52f12eb38613f5afd5258b5263c6e6e2d9db6c9659a769f896a2bb66564fa69"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "DeleteBackupFiles" ascii wide
		$s2 = "GetEncryptFiles" ascii wide
		$s3 = "DeleteVirtualDisks" ascii wide
		$s4 = "DismountVirtualDisks" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and 3 of them
}
rule DITEKSHEN_MALWARE_Win_Buterat : FILE
{
	meta:
		description = "Detects ButeRAT"
		author = "ditekSHen"
		id = "74f63d61-6589-5fb1-864a-3a02ddd57ebc"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5822-L5839"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c3d93e8dc1bde8e77c11586c8d8b67d137ef2c4791e12269f1af310fbe14832b"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$x1 = "TVqQAAMAA" ascii
		$s1 = "ipinfo.io/geo" wide
		$s2 = "/index.php" wide
		$s3 = "Copy-Item -Path" wide
		$s4 = ";Start-Process" wide
		$s5 = "Microsoft\\Windows\\Start Menu\\Programs\\Startup" wide
		$s6 = "LOCALAPPDATA" fullword wide
		$s7 = "passwords.json" wide
		$s8 = "Scripting.FileSystemObject" fullword wide
		$z1 = /(edge|chrome|opera|exodus|jaxx|atomic|coinomi)\.zip/ ascii wide nocase

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) or 1 of ( $z* ) ) and ( 4 of ( $s* ) ) or ( 6 of ( $s* ) ) or ( #z1 > 4 and 2 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Cookiestealer : FILE
{
	meta:
		description = "Detects generic cookie stealer"
		author = "ditekSHen"
		id = "64c6c59d-4046-5949-bf71-22a5f6bfa209"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5841-L5857"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9cc406ae078e37430b3cf10954c02014b9760bc887344842e724df735d1d9808"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "([\\S]+?)=([^;|^\\r|^\\n]+)" fullword ascii
		$s2 = "(.+?): ([^;|^\\r|^\\n]+)" fullword ascii
		$s3 = "Set-Cookie: ([^\\r|^\\n]+)" fullword ascii
		$s4 = "cmd.exe /c taskkill /f /im chrome.exe" fullword ascii
		$s5 = "FIREFOX.EXE|Google Chrome|IEXPLORE.EXE" ascii
		$pdb1 = "F:\\facebook_svn\\trunk\\database\\Release\\DiskScan.pdb" fullword ascii
		$pdb2 = "D:\\Projects\\crxinstall\\trunk\\Release\\spoofpref.pdb" fullword ascii
		$ua1 = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36" fullword ascii
		$ua2 = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( all of ( $s* ) and 1 of ( $pdb* ) and 1 of ( $ua* ) ) or ( all of ( $ua* ) and 1 of ( $pdb* ) and 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Bitcoingrabber : FILE
{
	meta:
		description = "Detects generic bitcoin stealer"
		author = "ditekSHen"
		id = "f73b58da-1db5-5767-ae0a-074648e30966"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5859-L5875"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "2dc762525c1fbf25517df52f0561d96d7469bf1367eada31c236fc313001c6cb"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run" wide
		$s2 = "Bitcoin-Grabber" ascii
		$s3 = "Bitcoin_Grabber" ascii
		$s4 = "encrypt resources [compress]T" fullword ascii
		$s5 = "code control flow obfuscationT" fullword ascii
		$s6 = "\\Users\\lakol\\Desktop\\a\\Crypto Currency Wallet Changer\\" ascii
		$pat1 = "\\b(bc1|[13])[a-zA-HJ-NP-Z0-9]{26,35}\\b" fullword wide
		$pat2 = "\\b0x[a-fA-F0-9]{40}\\b" fullword wide
		$pat3 = "\\b4([0-9]|[A-B])(.){93}\\b" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and 4 of ( $s* ) or ( all of ( $pat* ) and 2 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_FOXGRABBER : FILE
{
	meta:
		description = "Detects FOXGRABBER utility"
		author = "ditekSHen"
		id = "b98e501c-e9c6-5fcc-bfa0-9475ce32864c"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5877-L5890"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5ecba516f1155bdcccf83b0a034b11d8eac8619d4c3326fdbc76082fbe4daf02"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "start grabbing" wide
		$s2 = "end grabbing in" wide
		$s3 = "error of copying files from comp:" wide
		$s4 = "\\Firefox\\" wide nocase
		$pdb1 = "\\obj\\Debug\\grabff.pdb" ascii
		$pdb2 = "\\obj\\Release\\grabff.pdb" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or ( 1 of ( $pdb* ) and 1 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Deathransom : FILE
{
	meta:
		description = "Detects known DeathRansom ransomware"
		author = "ditekSHen"
		id = "a6eeb607-8b5c-5982-8b5a-aa2b3c6a65e6"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5908-L5925"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "3c87364a7ecc403262056eeccaa16bf230fbbe684e21d35099d0d572abba9eda"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "%s %f %c" fullword ascii
		$pdb1 = ":\\wud.pdb" ascii
		$spdb2 = "\\crypt_server\\runtime\\crypt" ascii
		$spdb3 = "\\bin\\nuvin.pdb" ascii
		$h1 = "#Dunubeyokunov" wide
		$h2 = "^Neyot dehipijakeyelih" wide
		$h3 = "talin%Sanovurenofibiw" wide
		$h4 = "WriteFile" fullword ascii
		$h5 = "ClearEventLogA" fullword ascii
		$h6 = "Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $pdb* ) or ( all of ( $s* ) and 1 of ( $pdb* ) ) or 5 of ( $h* ) )
}
rule DITEKSHEN_MALWARE_Win_Unlockyourfiles : FILE
{
	meta:
		description = "Detects UnlockYourFiles ransomware"
		author = "ditekSHen"
		id = "265f2a48-143a-56c9-9cd4-b5137799a9e8"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5927-L5946"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "05f549467fac03d4aa2248a9c6c87e4c4273ed6ad727ebb77a4dd115032e454b"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "filesx0" wide
		$s2 = "_auto_file" wide
		$s3 = "<EncyptedKey>" fullword wide
		$s4 = "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FileExts\\" wide
		$s5 = "DecryptAllFile" fullword ascii
		$s6 = "AES_Only_Decrypt_File" fullword ascii
		$m1 = "Free files decrypted" wide
		$m2 = "Restore my files" wide
		$m3 = "Type tour password..." wide
		$m4 = "files encrypted by strong password" ascii
		$m5 = "buy bitcoin" ascii
		$m6 = "Unlock File" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 4 of ( $s* ) or 5 of ( $m* ) or ( 2 of ( $s* ) and 2 of ( $m* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Decryptmyfiles : FILE
{
	meta:
		description = "Detects DecryptMyFiles ransomware"
		author = "ditekSHen"
		id = "dab518f2-3fac-5492-88fb-35cd0000ec47"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5948-L5964"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5b7f74569700e2ad3f31388571dad5ffda45f5ab3dd36806f7514aff0367d5ba"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "FILES ENCRYPTED" wide
		$s2 = "pexplorer.exe" fullword wide
		$s3 = "uniquesession" fullword ascii
		$s4 = ".[decryptmyfiles.top]." fullword ascii
		$s5 = "decrypt 1 file" ascii
		$s6 = "(databases,backups, large excel" ascii
		$c1 = "api/connect.php" ascii
		$c2 = "decryptmyfiles.top" ascii
		$c3 = "/contact/" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 4 of ( $s* ) or all of ( $c* ) or ( 2 of ( $c* ) and 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Motocos : FILE
{
	meta:
		description = "Detects Motocos ransomware"
		author = "ditekSHen"
		id = "be7284be-b57d-5a2c-9a84-37d76445cd0d"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5966-L5981"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "99ac365c277058503874313e3a74ab016d6d279b47c754c3df950e3ce60e29f1"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Block Investigation Tools" wide
		$s2 = "powershell.exe,taskmgr.exe,procexp.exe,procmon.exe" wide
		$s3 = "google.com,youtube.com,baidu.com,facebook.com,amazon.com,360.cn,yahoo.com,wikipedia.org,zoom.us,live.com,reddit.com,netflix.com,microsoft.com,instagram.com,vk.com," wide
		$s4 = "START ----" wide
		$s5 = "TEngine.Clear_EventLog_Result" wide
		$s6 = "TEngine.EncryptLockFiles" wide
		$s7 = "TEngine.CleanShadowFiles" wide
		$s8 = "TDNSUtils.SendCommand" wide

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Win_Dlagent12 : FILE
{
	meta:
		description = "Detects downloader agent"
		author = "ditekSHen"
		id = "841b998b-99d1-50d8-bc7b-75b2a8e690bf"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5983-L5993"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b9845414f4ce4cc25b75a8de7569c4135bbb7ba9098fd4c50d7ac80302e99b8f"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "WebClient" fullword ascii
		$s2 = "DownloadData" fullword ascii
		$s3 = "packet_server" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and all of them and filesize < 50KB
}
rule DITEKSHEN_MALWARE_Win_Dlinjector01 : FILE
{
	meta:
		description = "Detects specific downloader injector shellcode"
		author = "ditekSHen"
		id = "c5e0946c-3e15-5ebc-b1b5-3f00566dc5cd"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L5995-L6015"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5c13af5fdbb2e8a27103d9502126a82d0bff15d9a269b22e4279b5b459d50e2d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "process call create \"%s\"" ascii wide
		$s2 = "\\REGISTRY\\MACHINE\\System\\CurrentControlSet\\Enum\\" ascii wide
		$s3 = "%systemroot%\\system32\\ntdll.dll" ascii wide
		$s4 = "qemu-ga.exe" ascii wide
		$s5 = "prl_tools.exe" ascii wide
		$s6 = "vboxservice.exe" ascii wide
		$o1 = { 75 04 74 02 38 6e 8b 34 24 83 c4 04 eb 0a 08 81 }
		$o2 = { 16 f8 f7 ba f0 3d 87 c7 95 13 b7 64 22 be e1 59 }
		$o3 = { 8b 0c 24 83 c4 04 eb 05 ea f2 eb ef 05 e8 ad fe }
		$o4 = { eb 05 1d 51 eb f5 ce e8 80 fd ff ff 77 a1 f4 cd }
		$o5 = { eb 05 6e 33 eb f5 73 e8 64 f6 ff ff 77 a1 f4 77 }
		$o6 = { 59 eb 05 fd 98 eb f4 50 e8 d5 f5 ff ff 3b b9 00 }
		$o7 = "bYkoDA7G" fullword ascii

	condition:
		( uint16( 0 ) == 0x5a4d and all of ( $o* ) ) or ( all of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Dlinjector02 : FILE
{
	meta:
		description = "Detects downloader injector"
		author = "ditekSHen"
		id = "ce2c418d-18e4-579c-9828-94e294385846"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6017-L6034"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "76d185cfcbc7f4996c2fb5c7c1ba4eb20b32d322d8ff47594283a4ca3e573a0b"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "In$J$ct0r" fullword wide
		$x2 = "%InJ%ector%" fullword wide
		$a1 = "WriteProcessMemory" fullword wide
		$a2 = "URLDownloadToFileA" fullword ascii
		$a3 = "Wow64SetThreadContext" fullword wide
		$a4 = "VirtualAllocEx" fullword wide
		$s1 = "RunPE" fullword wide
		$s2 = "SETTINGS" fullword wide
		$s3 = "net.pipe" fullword wide
		$s4 = "vsmacros" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $x* ) or ( all of ( $a* ) and 3 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Nermer : FILE
{
	meta:
		description = "Detects Nermer ransomware"
		author = "ditekSHen"
		id = "fce4f178-8e98-53b0-ae09-2ce876ad524e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6036-L6062"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e885b1b908b256ee07f5cb144d63f5ad65e5bf746b70efe168b0ac742a246ab3"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "gPROTECT_INFO.TXT" fullword wide
		$x2 = ".nermer" fullword wide
		$s1 = "db_journal" fullword wide
		$s2 = "quicken2015backup" fullword wide
		$s3 = "mysql" fullword wide
		$s4 = "sas7bdat" fullword wide
		$s5 = "httpd.exe" fullword wide
		$s6 = "Intuit.QuickBooks.FCS" fullword wide
		$s7 = "convimage" fullword wide
		$s8 = ".?AV?$_Binder@U_Unforced@std@@P8shares_t@" ascii
		$s9 = "BgIAAACkAABSU0ExAAgAAAEAAQCt" ascii
		$m1 = "YOUR FILES WERE ENCRYPTED" ascii
		$m2 = "MARKED BY EXTENSION .nermer" ascii
		$m3 = "send us your id: >> {id} <<" ascii
		$m4 = "email us: >> {email} <<" ascii
		$c1 = "/repeater.php" ascii
		$c2 = "HTTPClient/0.1" fullword ascii
		$c3 = "94.156.35.227" ascii
		$c4 = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $m* ) or all of ( $c* ) or all of ( $s* ) or ( 4 of ( $s* ) and ( 1 of ( $x* ) or 1 of ( $m* ) or 2 of ( $c* ) ) ) or 14 of them )
}
rule DITEKSHEN_MALWARE_Win_Beastdoor : FILE
{
	meta:
		description = "Detects Beastdoor backdoor"
		author = "ditekSHen"
		id = "b271d53e-2693-5a93-825a-ef32f72a4b01"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6064-L6084"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d9a72717d124bcf1e3b95850cd524e577abe96a094586a5555faadba78fcb9ad"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "shellx.pif" fullword ascii nocase
		$s2 = "Beasty" fullword ascii
		$s3 = "* Boot:[" ascii
		$s4 = "^ Shut Down:[" ascii
		$s5 = "set cdaudio door" ascii
		$s6 = "This \"Portable Network Graphics\" image is not valid" wide
		$n1 = ".aol.com" ascii
		$n2 = "web.icq.com" ascii
		$n3 = "&fromemail=" fullword ascii
		$n4 = "&subject=" fullword ascii
		$n5 = "&Send=" fullword ascii
		$n6 = "POST /scripts/WWPMsg.dll HTTP/1.0" fullword ascii
		$n7 = "mirabilis.com" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or 5 of ( $n* ) or ( 3 of ( $s* ) and 3 of ( $n* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Gravityrat : FILE
{
	meta:
		description = "Detects GravityRAT"
		author = "ditekSHen"
		id = "cb581dd6-15b2-54ae-9f27-30ec21554fb9"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6086-L6108"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a6b049dbf21f22f751c15da98536e9ef2a4ced7755ade0cc9904afddef1d3ae6"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "/GX/GX-Server.php?VALUE=2&Type=" wide
		$s2 = "&SIGNATUREHASH=" wide
		$s3 = "Error => CommonFunctionClass => Upload()" wide
		$s4 = "/GetActiveDomains.php" wide
		$s5 = "DetectVM" ascii wide
		$s6 = "/c {0} > {1}" wide
		$s7 = "DRIVEUPLOADCOMPLETED => TOTALFILES={0}, FILESUPLOADED={1}" wide
		$s8 = "Program => RunAFile()" wide
		$s9 = "DoViaCmd" ascii
		$s10 = ".msoftupdates.com:" wide
		$f1 = "<RootJob>b__" ascii
		$f2 = "<GetFiles>b__" ascii
		$f3 = "<UpdateServer>b__" ascii
		$f4 = "<EthernetId>b__" ascii
		$f5 = "<MatchMacAdd>b__" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 5 of ( $s* ) or ( all of ( $f* ) and 1 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Fatalrat : FILE
{
	meta:
		description = "Detects FatalRAT"
		author = "ditekSHen"
		id = "f9d0c5dd-ae69-512d-a260-01b9765e10eb"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6110-L6128"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "fb7f6822aa4ef98e77670d276d06c9a37718bce38d32ce5b53fe67513b107fbe"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "XXAcQbcXXfRSScR" fullword ascii
		$s1 = "CHROME_NO_DATA" fullword ascii
		$s2 = "CHROME_UNKNOW" fullword ascii
		$s3 = "-Thread running..." ascii
		$s4 = "InetCpl.cpl,ClearMyTracksByProcess" ascii nocase
		$s5 = "MSAcpi_ThermalZoneTemperature" ascii nocase
		$s6 = "taskkill /f /im rundll32.exe" fullword ascii nocase
		$s7 = "del /s /f %appdata%\\Mozilla\\Firefox" ascii nocase
		$s8 = "\\\\%s\\C$\\" ascii
		$s9 = "fnGetChromeUserInfo" fullword ascii
		$s10 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Svchost" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) and 3 of ( $s* ) ) or 5 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Wingo : FILE
{
	meta:
		description = "Detects malicious Golang executables"
		author = "ditekSHen"
		id = "bc0c84d6-7ea1-5234-89f6-98337900e044"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6130-L6141"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "423b1631ad625fd46a9d10f0ecdf24931cf62a2c1694da3ebdd38daad0a4f724"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "Go build ID:" ascii
		$s2 = /main\.[a-z]{9}Delete/ fullword ascii
		$s3 = /main\.[a-z]{9}Update/ fullword ascii
		$s4 = /main\.[a-z]{9}rundll/ fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of them and #s2 > 2 and #s3 > 2 and #s4 > 2 )
}
rule DITEKSHEN_MALWARE_Win_Ipsechelper : FILE
{
	meta:
		description = "Detects IPsecHelper backdoor"
		author = "ditekSHen"
		id = "f848ac2a-95ad-596a-b193-5cfb424e33a2"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6256-L6279"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "be0ecf8a97d289b15b902420d769925b7b22ab835bd7d10d10b059119f41e540"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "rundll32.exe advapi32.dll,ProcessIdleTasks" wide
		$s2 = "CommandExecute" fullword ascii
		$s3 = "DownloadExecuteUrl" fullword ascii
		$s4 = "DownloadExecuteFile" fullword ascii
		$s5 = "CmdExecute" fullword ascii
		$s6 = "ExecuteProcessWithResult" fullword ascii
		$s7 = "IsFirstInstance ==> checked" fullword wide
		$s8 = "del \"%PROG%%SERVICENAME%\".*" fullword wide
		$s9 = ".CreateConfig" wide
		$s10 = ".SelfDelete" wide
		$c1 = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; EmbeddedWB 14.52 from: http://www.google.com/ EmbeddedWB 14.52;" wide
		$c2 = "boot.php" wide
		$c3 = "lastupdate.php" wide
		$c4 = "main.php" wide
		$c5 = "InternetNeeded" wide
		$c6 = "DeviceIdSalt" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 6 of ( $s* ) or 4 of ( $c* ) or 8 of them )
}
rule DITEKSHEN_MALWARE_Win_Apostle : FILE
{
	meta:
		description = "Detects Apsotle"
		author = "ditekSHen"
		id = "6e6d2ef0-b709-5915-b644-db86d9d3f26a"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6281-L6295"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "aa5a522383cbb7e2fdb90f4c4395c7f92f546aa1dbda8f44090225861f011630"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "bytesToBeEncrypted" fullword ascii
		$s2 = "SelfDelete" fullword ascii
		$s3 = "ReadMeFileName" ascii
		$s4 = "DesktopFileName" ascii
		$s5 = "SetWallpaper" fullword ascii
		$s6 = "get_EncryptionKey" fullword ascii
		$s7 = "disall" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_DEADWOOD : FILE
{
	meta:
		description = "Detects DEADWOOD"
		author = "ditekSHen"
		id = "a75e30d8-75ec-5eaf-94f5-5556a3b947ae"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6297-L6313"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "bf53abc801971b294e0a23bb0162ceb7c56a563a16e73c317f6a890ba545b67d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Service Start Work !!!!" fullword ascii
		$s2 = "Error GetTokenInformation : " fullword ascii
		$s3 = "\\Windows\\System32\\net.exe" fullword wide
		$s4 = "App Start Work !!!!" fullword ascii
		$s5 = "vmmouse" fullword wide
		$s6 = "CDPUserSvc_" wide
		$s7 = "WpnUserService_" wide
		$s8 = "User is :" wide
		$s9 = "\\params" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Turian : FILE
{
	meta:
		description = "Hunt for Turian / Qurian"
		author = "ditekSHen"
		id = "eafa9442-a01b-5044-bc47-634297a3efcc"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6315-L6343"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		hash = "d1218ab9d608ee0212e880204e4d7d75f29f03b77248bca7648d111d67405759"
		logic_hash = "87f4263381c5e93fcba0873aa3bb9a1db4b21225141cd7f06be30f5777a47806"
		score = 75
		quality = 75
		tags = "FILE"
		cnc_domain = "windowsupdate[.]dyndns[.]info"
		cnc_ip = "58[.]158[.]177[.]102"

	strings:
		$s1 = "%s a -m5 -hp1qaz@WSX3edc -r %s %s\\*.*" ascii wide
		$s2 = "%s a -m5 -hpMyHost-1 -r %s %s\\*.*" ascii wide
		$s3 = "%s a -m5 -hp1qaz@WSX3edc -ta%04d%02d%02d000000 -r %s c:" ascii wide
		$s4 = "%s a -m5 -hpMyHost-1 -ta%04d%02d%02d000000 -r %s c:"
		$s5 = "cmd /c dir /s /O:D %s>>\"%s\"" ascii wide
		$s6 = "\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run /v %s /t REG_SZ /d \"%s\" /f" fullword ascii
		$s7 = "Not Connect!" fullword ascii
		$p1 = "RECYCLER\\S-1-3-33-854245398-2067806209-0000980848-2003\\" ascii wide
		$p2 = "%sRECYCLER.{S-1-3-33-854245398-2067806209-0000980848-2003}\\" ascii wide
		$p3 = "\\RECYCLER.{S-1-3-33-854245398-2067806209-0000980848-2003}\\" ascii wide
		$p4 = "\\RECYCLER.{645ff040-5081-101b-9f08-00aa002f954e}\\" ascii wide
		$p5 = "%sRECYCLER.{645ff040-5081-101b-9f08-00aa002f954e}\\" ascii wide
		$c1 = "CONNECT %s:%u HTTP/1." ascii wide
		$c2 = "User-Agent: Mozilla/4.0" ascii wide
		$m1 = "winsupdatetw" fullword ascii wide
		$m2 = "clientsix" fullword ascii wide
		$m3 = "updatethres" fullword ascii wide
		$m4 = "uwatchdaemon" fullword ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $s* ) or ( all of ( $c* ) and ( 2 of ( $s* ) or 1 of ( $m* ) or 1 of ( $p* ) ) ) or ( 1 of ( $m* ) and 1 of ( $s* ) and ( 1 of ( $c* ) or 1 of ( $p* ) ) ) )
}
rule DITEKSHEN_MALWARE_Win_Dlagent14 : FILE
{
	meta:
		description = "Detects downloader injector"
		author = "ditekSHen"
		id = "6f80567e-b89a-557d-a282-b61c0b99625e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6365-L6378"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "2806b553635dbf96e9c00d3554dd5732df64200b3ae2c4845a2675218bd56387"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "%ProgramData%\\AVG" fullword wide
		$s2 = "%ProgramData%\\AVAST Software" fullword wide
		$s3 = "%wS\\%wS.vbs" fullword wide
		$s4 = "%wS\\%wS.exe" fullword wide
		$s5 = "CL,FR,US,CY,FI,HR,HU,RO,PL,IT,PT,ES,CA,DK,AT,NL,AU,AR,NP,SE,BE,NZ,SK,GR,BG,NO,GE" ascii
		$s6 = "= CreateObject(\"Microsoft.XMLHTTP\")" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Markirat : FILE
{
	meta:
		description = "Detects MarkiRAT"
		author = "ditekSHen"
		id = "6cfa276c-a64e-532a-a1ae-11a9e00867bd"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6380-L6403"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "17b8bcfe8d2b4c87ff8e0bddb436e18029a3b28a5ad3994fe9bef359588d9cad"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$pdb = "\\mfcmklg.pdb" ascii
		$s1 = "runinhome Completed" wide
		$s2 = "ERROR find next file<br>" wide
		$s3 = "<br><mark>Hello: %s</mark>" wide
		$s4 = "<br><mark>CLIPBOARD[" wide
		$s5 = "@userhome@" wide
		$s6 = "Global\\{2194ABA1-BFFA-4e6b-8C26-D1BB20190312}" wide
		$s7 = "taskkill /im svehost.exe /t /f" fullword ascii
		$s8 = "taskkill /im keepass.exe /t /f" fullword ascii
		$ba = /bitsadmin \/(addfile|cancel|SetPriority|resume)/ ascii wide
		$c1 = "/ech/client.php?u=" wide
		$c2 = "/up/uploadx.php?u=" wide
		$c3 = "/ech/echo.php?req=rr&u=" wide
		$c4 = "/ech/rite.php" wide
		$c5 = "http://microsoft.com-view.space/i.php?u=" wide
		$c6 = "Content-Disposition: form-data; name=\"uploadedfile\"; filename=\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( $pdb and any of them ) or ( 5 of ( $s* ) ) or ( 3 of ( $c* ) ) or ( ( #ba > 3 and 4 of them ) ) )
}
rule DITEKSHEN_MALWARE_Win_Klingonrat : FILE
{
	meta:
		description = "Detects KlingonRAT"
		author = "ditekSHen"
		id = "bea50bce-b38c-50a0-902a-1014615bd9b8"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6405-L6427"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "2abfbfc1b67f931f15bfdfd2cd4ba7821e62eb8c518bbc04629c0dd694bbd9c1"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$go = "Go build ID:" ascii
		$s1 = "/UCRelease/src/client/uac/once/"
		$s2 = "%T\\AppData\\Local\\Windows Update\\"
		$s3 = "%TSoftware\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\"
		$s4 = "wmic /namespace:'\\\\root\\subscription' PATH"
		$s5 = "C:\\Windows\\System32\\fodhelper.exeCaption,ParentProcessId,ProcessId"
		$s6 = "ldpro.exelsass.exeluall.exeluspt.exe"
		$s7 = "scangui.exedeps/lsass.exeetrustcipe.exefile"
		$s8 = "alogserv.exeaplica32.exeapvxdwin.exeatro55en.exeautodown.exeavconsol.exeavgserv9.exeavkwctl9.exeavltmain.exeavpdos32.exeavsynmgr.exeavwupd32.exeavwupsrv.exe"
		$c1 = "%s/keyLogger?machineId=%s" ascii
		$c2 = "%s/stealer?machineId=%s" ascii
		$c3 = "%s/lsass?machineId=%s" ascii
		$c4 = "%s/logger?machineId=%s" ascii
		$c5 = "%s/machineInfo?machineId=%s" ascii
		$c6 = "failurehttps://%s:%d/botif-modified-sinceillegal" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( $go ) and ( 3 of ( $c* ) or 5 of ( $s* ) or ( 3 of ( $s* ) and 1 of ( $c* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Xfiles : FILE
{
	meta:
		description = "Detects X-Files infostealer (formerly BotSh1zoid)"
		author = "ditekSHen"
		id = "3f8b2f9b-aa6a-5ffc-95b8-5e44de0d1a49"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6429-L6460"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0c04a8f019aea36f4bba3ce8289c2d608c69d76bbf321052560b4ca2214be057"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$x1 = "\\BotSh1zoid\\" ascii
		$x2 = "\\BuildPacker.pdb" ascii
		$x3 = "\\Svc_host.pdb" ascii nocase
		$s1 = "WDefender" fullword ascii
		$s2 = "CheckDefender" fullword ascii
		$s3 = "RunPS" fullword ascii
		$s4 = "DownloadFile" fullword ascii
		$v1_1 = "<Pass encoding=\"base64\">(.*)</Pass>" wide
		$v1_2 = "Grabber\\" wide
		$v1_3 = "/log.php" wide
		$v1_4 = /Browsers\\(Logins|Cards|Cookies)/ wide
		$v1_5 = "<StealSteam>b__" ascii
		$v1_6 = "record_header_field" fullword ascii
		$v1_7 = "JavaScreenshotiptReader" fullword ascii
		$v1_8 = "HTTPDebuggerPro" wide
		$v1_9 = "IEInspector" wide
		$v1_10 = "Fiddler" wide
		$v2_1 = /get_(Cookie|Logins|Cards)Path/ fullword ascii
		$v2_2 = "get_AllScreens" fullword ascii
		$v2_3 = "{0}_{1}_{2}.zip" fullword wide
		$v2_4 = "\\Stealer" fullword wide
		$g1 = "$983a3552-4ec3-4936-bd4a-8e6fd67b4c67" fullword ascii
		$g2 = "$a5d9ca4d-400f-4e07-8c09-a916b548f2e3" fullword ascii
		$g3 = "$ebc25cf6-9120-4283-b972-0e5520d0000C" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) and ( 3 of ( $s* ) or 3 of ( $v1* ) or 3 of ( $v2* ) ) ) or 7 of ( $v1* ) or 3 of ( $v2* ) or ( 2 of ( $g* ) and 3 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Allakore : FILE
{
	meta:
		description = "Detects AllaKore"
		author = "ditekSHen"
		id = "371663c1-6faf-5ca3-a79e-e4340d44660b"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6462-L6493"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0e93682787e27246cdddbd67ca5360728c65049a2e97e71809b5902854aa4bef"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$x1 = "AllaKore Remote - Chat" fullword wide
		$x2 = "AllaKore Remote - Share Files" fullword wide
		$x3 = "CYRUS - Chat" fullword wide
		$x4 = "CYRUS - Share Files" fullword wide
		$x5 = "<|REDIRECT|><|GETFOLDERS|>" fullword wide
		$x6 = "<|REDIRECT|><|DOWNLOADFILE|>" fullword wide
		$x7 = "<|REDIRECT|><|WHEELMOUSE|>" fullword wide
		$x8 = "<|REDIRECT|><|SETMOUSE" wide
		$x9 = "<|CHECKIDPASSWORD|>" fullword wide
		$x10 = "<|KEYBOARDSOCKET|>" fullword wide
		$x11 = "<|REDIRECT|><|CLIPBOARD|>" fullword wide
		$x12 = "<|IDEXISTS!REQUESTPASSWORD|>" fullword wide
		$x13 = "<|GETFULLSCREENSHOT|>" fullword wide
		$x14 = "<|MAINSOCKET|>" fullword ascii
		$s1 = "You can not connect with yourself!" wide
		$s2 = "Waiting for authentication..." wide
		$s3 = "Connected support!" wide
		$s4 = "ID does nor exists." wide
		$s5 = "Finding the ID..." wide
		$s6 = "PC is Busy!" wide
		$s7 = "Upload &  Execute" fullword ascii
		$s8 = "Download file selected" fullword ascii
		$s9 = "CaptureKeys_TimerTimer" fullword ascii
		$s10 = "Remote File Manager" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 4 of ( $x* ) or 4 of ( $s* ) or ( 3 of ( $s* ) and 2 of ( $x* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Reverserat : FILE
{
	meta:
		description = "Detects ReverseRAT"
		author = "ditekSHen"
		id = "df13fc6c-025a-54db-809d-4f3c27b8aa7a"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6495-L6514"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "87ab00a5588bfce04ec47a07b184fffe359e472ac8bf561b02a8b070edf2e014"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$pdb1 = "\\ReverseRat.pdb" ascii nocase
		$pdb2 = "\\ReverseRat\\obj\\" ascii nocase
		$s1 = "processCmd" fullword ascii
		$s2 = "CmdOutputDataHandler" fullword ascii
		$s3 = "sendingProcess" fullword ascii
		$s4 = "SetStartup" fullword ascii
		$s5 = "RunServer" fullword ascii
		$s6 = "_OutputDataReceived" ascii
		$s7 = { 63 00 6d 00 64 00 2e 00 65 00 78 00 65 00 
                00 03 0a 00 00 13 74 00 65 00 72 00 6d 00
                69 00 6e 00 61 00 74 00 65 00 00 09 65 00
                78 00 69 00 74 00 }

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $pdb* ) and 2 of ( $s* ) ) or 5 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Smokeloader : FILE
{
	meta:
		description = "Detects SmokeLoader variants"
		author = "ditekSHen"
		id = "e8f28f89-3a79-5d78-8c0a-bad16a57df84"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6516-L6539"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "65c56ed11a3cb4e4bcf8fd2a6be097545cb96e84ba4c4202969d1d163a2a36ed"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "G2A/CLP/05/RYS" fullword wide
		$x2 = "0N1Y/53R10U5/BU51N355" fullword wide
		$x3 = "CH4PG3PB-6HT2VI9C-O2NL2NO5-QP1BW0EG" fullword wide
		$s1 = "Azure-Update-Task" fullword wide
		$s2 = "C:\\Windows\\System32\\schtasks.exe" fullword wide
		$s3 = "/C /create /F /sc minute /mo 1 /tn \"" fullword wide
		$s4 = "\\Microsoft\\Network" fullword wide
		$s5 = "\\Microsoft\\TelemetryServices" fullword wide
		$s6 = "\" /tr \"" fullword wide
		$e1 = "\\sqlcmd.exe" fullword wide
		$e2 = "\\sihost.exe" fullword wide
		$e3 = "\\fodhelper.exe" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) and 4 of ( $s* ) ) or ( 5 of ( $s* ) and 1 of ( $e* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Dlinjector03 : FILE
{
	meta:
		description = "Detects unknown loader / injector"
		author = "ditekSHen"
		id = "2d0df2d8-5b1c-5408-b8c7-8ca14d57da0f"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6541-L6551"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "10092e7916775fe0a39baa5714fdda89f443ceabdcc610cc1fcd5a0fb0e68d0c"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$x1 = "LOADER ERROR" fullword ascii
		$s1 = "_ZN6curlpp10OptionBaseC2E10CURLoption" fullword ascii
		$s2 = "The procedure entry point %s could not be located in the dynamic link library %s" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Coinminer02 : FILE
{
	meta:
		description = "Detects coinmining malware"
		author = "ditekSHen"
		id = "1878a1b5-4e97-5575-802e-573caded2b3a"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6553-L6571"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "83760aef667819923a2ac67c006e03bb6d4260b7a4aedd691dd5b145fb50d5c1"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "%s/%s (Windows NT %lu.%lu" fullword ascii
		$s2 = "\\Microsoft\\Libs\\WR64.sys" wide
		$s3 = "\\\\.\\WinRing0_" wide
		$s4 = "pool_wallet" ascii
		$s5 = "cryptonight" ascii
		$s6 = "mining.submit" ascii
		$c1 = "stratum+ssl://" ascii
		$c2 = "daemon+http://" ascii
		$c3 = "stratum+tcp://" ascii
		$c4 = "socks5://" ascii
		$c5 = "losedaemon+https://" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $s* ) and 1 of ( $c* ) )
}
rule DITEKSHEN_MALWARE_Win_Mercurial : FILE
{
	meta:
		description = "Detects Mercurial infostealer"
		author = "ditekSHen"
		id = "c262ada2-01ca-5fc1-adef-987908514019"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6573-L6593"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "400f8f717a4e07bf4de508c02bbcd9e82bf21f3df84c989fc622378f33e192f0"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "mercurial grabber" wide nocase
		$x2 = "\"text\":\"Mercurial Grabber |" wide
		$x3 = "/nightfallgt/mercurial-grabber" wide
		$s1 = "/LimerBoy/Adamantium-Thief/" ascii
		$s2 = "Mozilla/5.0 (Macintosh; Intel Mac OS X x.y; rv:42.0) Gecko/20100101 Firefox/42.0" fullword wide
		$s3 = "StealCookies" fullword ascii
		$s4 = "StealPasswords" fullword ascii
		$s5 = "DetectDebug" fullword ascii
		$s6 = "CaptureScreen" fullword ascii
		$s7 = "WebhookContent" fullword ascii
		$s8 = /Grab(Token|Product|IP|Hardware)/ fullword ascii
		$p1 = "[\\w-]{24}\\.[\\w-]{6}\\.[\\w-]{27}" fullword ascii wide
		$p2 = "mfa\\.[\\w-]{84}" fullword ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $x* ) or 5 of ( $s* ) or ( all of ( $p* ) and 3 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Phonzy : FILE
{
	meta:
		description = "Detects specific downloader agent"
		author = "ditekSHen"
		id = "d35f41e4-4633-5482-9ae4-79354463f1b9"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6595-L6608"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "924e7674d76594314df1a32d38f19cee12a3ed49cdf5e153f98bb08a7634055c"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$ua1 = "User-Agent: Mozilla/5.0 (X11; Linux" wide
		$s1 = "<meta name=\"keywords\" content=\"([\\w\\d ]*)\">" fullword wide
		$s2 = "WebClient" fullword ascii
		$s3 = "WriteAllText" fullword ascii
		$s4 = "DownloadString" fullword ascii
		$s5 = "WriteByte" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or ( 1 of ( $ua* ) and ( $s1 ) and 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Hive : FILE
{
	meta:
		description = "Detects Hive ransomware"
		author = "ditekSHen"
		id = "7b79dc54-01c7-5667-acf5-a32cd7a45b54"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6610-L6647"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "14c20ff2fa62d80eed0f4f364e24d93d493d4f3b47f664983714940afa74046f"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$url1 = "http://hivecust" ascii
		$url2 = "http://hiveleakdb" ascii
		$s1 = "encrypt_files.go" ascii
		$s2 = "erase_key.go" ascii
		$s3 = "kill_processes.go" ascii
		$s4 = "remove_shadow_copies.go" ascii
		$s5 = "stop_services_windows.go" ascii
		$s6 = "remove_itself_windows.go" ascii
		$x1 = "/encryptor/" ascii
		$x2 = "HOW_TO_DECRYPT.txt" ascii
		$x3 = "FilesEncrypted" fullword ascii
		$x4 = "EncryptionStarted" fullword ascii
		$x5 = "encryptFilesGroup" fullword ascii
		$x6 = "Your data will be undecryptable" ascii
		$x7 = "- Do not fool yourself. Encryption has perfect secrecy" ascii
		$v1_1 = ".EncryptFiles." ascii
		$v1_2 = ".EncryptFilename." ascii
		$v1_3 = ")*struct { F uintptr; .autotmp_14 string }" ascii
		$v1_4 = "D*struct { F uintptr; data *[]uint8; seed *uint8; fnc *main.decFunc }" ascii
		$v1_5 = "golang.org/x/sys/windows.getSystemWindowsDirectory" ascii
		$v1_6 = "path/filepath.WalkDir" ascii
		$v2_1 = "taskkill /f /im" ascii
		$v2_2 = "schtasks /delete /tn" ascii
		$v2_3 = "encfile.txt" ascii
		$v2_4 = "README.html" ascii
		$v2_5 = "total encrypt %v/%v" ascii
		$v2_6 = "<b>ITSSHOWKEY</b>" ascii
		$v2_7 = "Recovery your files." ascii
		$v2_8 = "yaml:\"send_host\"" ascii
		$v2_9 = "yaml:\"ignore_dir\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $url* ) or all of ( $s* ) or 4 of ( $x* ) or 5 of ( $v1* ) or 5 of ( $v2* ) or ( 4 of ( $v2* ) and #v2_1 > 10 ) )
}
rule DITEKSHEN_MALWARE_Win_Spyro : FILE
{
	meta:
		description = "Detects Spyro / VoidCrypt / Limbozar ransomware"
		author = "ditekSHen"
		id = "8b3273c4-827e-50ce-983e-a5843f6b5a78"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6649-L6675"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "2e3be361f6d4283fd312a4486eaa39d6594813937cc3f62dbb603babeff17929"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Decrypt-info.txt" ascii wide
		$s2 = "AbolHidden" ascii wide
		$s3 = "C:\\ProgramData\\prvkey" ascii wide
		$s4 = ".?AV?$TF_CryptoSystemBase@VPK_Encryptor@CryptoPP" ascii
		$s5 = "C:\\Users\\LEGION\\" ascii
		$s6 = "C:\\ProgramData\\pkey.txt" fullword ascii
		$s7 = ".Spyro" fullword ascii
		$m1 = "Go to C:\\ProgramData\\ or in Your other Drives" wide
		$m2 = "saving prvkey.txt.key file will cause" wide
		$m3 = "in Case of no Answer:" wide
		$m4 = "send us prvkey*.txt.key" wide
		$m5 = "Somerhing went wrong while writing payload on disk" ascii
		$m6 = "this country is forbidden.\"}" ascii
		$c1 = "Voidcrypt/1.0" ascii
		$c2 = "h1dd3n.cc" ascii
		$c3 = "/voidcrypt/index.php" ascii
		$c4 = "&user=" ascii
		$c5 = "&disk-size=" ascii
		$c6 = "unique-id=" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 5 of ( $s* ) or 4 of ( $c* ) or 3 of ( $m* ) or 8 of them )
}
rule DITEKSHEN_MALWARE_Win_Darkvnc : FILE
{
	meta:
		description = "Detects DarkVNC"
		author = "ditekSHen"
		id = "3c7d215c-fcca-5a0f-b59c-d84fd894677a"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6677-L6696"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b0dbde04c0a05e476d505b92cf7dbf3b4ef0dd9e88eafcd21b7a7d0e3623abbd"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "USR-%s(%s)_%S-%S%u%u" fullword wide
		$s2 = "BOT-%s(%s)_%S-%S%u%u" fullword wide
		$s3 = "USR-UnicodeErr(Err)_%s-%s%u%u" fullword ascii
		$s4 = "BOT-UnicodeErr(Err)_%s-%s%u%u" fullword ascii
		$s5 = "PRM_STRG" fullword wide
		$s6 = "bot_shell >" ascii
		$s7 = "monitor_off / monitor_on" ascii
		$s8 = "kbd_off / kbd_on" ascii
		$s9 = "ActiveDll: Dll inject thread for process 0x%x terminated with status: %u" ascii
		$s10 = "PsSup: File %s successfully started with parameter \"%s\"" ascii
		$s11 = "PsSup: ShellExecute failed. File: %s, error %u" ascii
		$s12 = "#hvnc" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Avoslocker : FILE
{
	meta:
		description = "Hunt for AvosLocker ransomware"
		author = "ditekSHen"
		id = "390e57b2-207e-5013-899a-0b04aa63a56f"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6748-L6757"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "85601fdd13ddeb1fc0b8b98eb68e324046d60c1ae9467d083a75abebcb50e3a0"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "GET_YOUR_FILES_BACK.txt" ascii wide
		$s2 = ".avos" fullword ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Margulasrat : FILE
{
	meta:
		description = "Detects MargulasRAT"
		author = "ditekSHen"
		id = "6efabf80-9194-542d-afd2-9bf9c8e26e55"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6786-L6810"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "dd5b94c947d97cdc34032f2cb84b4975a1e8f510638857fb6dbe553bcff7d16e"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$pdb1 = "G:\\VP-S-Fin\\memory\\" ascii
		$pdb2 = "G:\\VP-S-Fin\\Margulas\\" ascii
		$pdb3 = "G:\\VP-S-Fin\\remote" ascii
		$pdb4 = "G:\\VP-S-Fin\\" ascii
		$s1 = "/C choice /C Y /N /D Y /T 1 & Del " fullword wide
		$s2 = "strToHash" fullword ascii
		$s3 = "\\socking" fullword wide
		$s4 = "\\wininets" fullword wide
		$s5 = "ClientSocket" fullword ascii
		$s6 = "new Stream()" fullword wide
		$s7 = "CipherText" fullword ascii
		$s8 = "WriteAllBytes" fullword ascii
		$s9 = { 00 50 72 6f 63 65 73 73 00 45 78 69 73 74 73 00}
		$s10 = "pxR/THCwdLuruMmw8wB8xAUvbno1yPGBTOV9IoOkAp/n7+paQm74pkzlfSKDpAKfTOV9IoOkAp9M5X0ig6QCn0zlfSKDpAKfTOV9IoOkAp" wide
		$c1 = "149.248.52.61" wide
		$c2 = "://vpn.nic.in" wide
		$c3 = "://www.mod.gov.in/dod/sites/default/files/" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $pdb* ) and ( 1 of ( $c* ) or 3 of ( $s* ) ) ) or ( 1 of ( $c* ) and 3 of ( $s* ) ) or ( 6 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Lilithrat : FILE
{
	meta:
		description = "Detects LilithRAT"
		author = "ditekSHen"
		id = "87e56524-f557-5662-86bc-2b26e7c74aee"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6812-L6839"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		hash = "132870a1ae6a0bdecaa52c03cfe97a47df8786f148fa8ca113ac2a8d59e3624a"
		hash = "ab7b6e0b28995bdeea44f20c0aba47f95e1d6ba281af3541cd2c04dc6c2a3ad9"
		hash = "b2eeb487046ba1d341fb964069b7e83027b60003334e04e41b467e35c3d2460f"
		hash = "cebcda044c60b709ba4ee0fa9e1e7011a6ffc17285bcc0948d27f866ec8d8f20"
		logic_hash = "1e8ac8a329ff99318e12666ea1d90d21bb9b0dff656a5eb1ce741b940c99afd5"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$pdb1 = "c:\\Users\\Groovi\\Documents\\Visual Studio 2008\\Projects\\TestDll\\" ascii
		$pdb2 = "C:\\Users\\iceberg\\Downloads\\RAT-Server-master\\RAT-Server-master\\RAT\\Debug\\RAT.pdb" ascii
		$pdb3 = "C:\\Users\\Samy\\Downloads\\Compressed\\Lilith-master\\Debug\\Lilith.pdb" ascii
		$s1 = "log.txt" fullword ascii
		$s2 = "keylog.txt" fullword ascii
		$s3 = "File Listing Completed Successfully." fullword ascii
		$s4 = "Download Execute" fullword ascii
		$s5 = "File Downloaded and Executed Successfully." fullword ascii
		$s6 = "C:\\WINDOWS\\system32\\cmd.exe" fullword ascii
		$s7 = "CMD session closed" ascii
		$s8 = "Restart requested: Restarting self" fullword ascii
		$s9 = "Termination requested: Killing self" fullword ascii
		$s10 = "Couldn't write to CMD: CMD not open" fullword ascii
		$s11 = "keydump" fullword ascii
		$s12 = "remoteControl" fullword ascii
		$s13 = "packettype" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $pdb* ) or 6 of ( $s* ) or ( 1 of ( $pdb* ) and 4 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Epicenterrat : FILE
{
	meta:
		description = "Detects EpicenterRAT"
		author = "ditekSHen"
		id = "6abe6e94-d7f5-5f88-96a6-a8fad599ef6a"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6841-L6863"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e9086dff22e301f57c6a9bdb38fbed8e902d5b8ca20a5e5b3cda56db08d5582e"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$pdb1 = "c:\\Users\\Zombie\\Desktop\\MutantNinja\\" ascii
		$pdb2 = "\\Epicenter Client\\" ascii
		$s1 = "PROCESS_LIST<%SEP%>" fullword wide
		$s2 = "GETREADY_RECV_FILE<%SEP%>" fullword wide
		$s3 = "DISPLAY<%SEP%>" wide
		$s4 = "GETSCREEN<%SEP%>" fullword wide
		$s5 = "dumpImageName" fullword ascii
		$s6 = "dumpLoc" fullword ascii
		$s7 = "EXPECT<%SEP%>filelist<%SEP%>" fullword wide
		$s8 = "<%FSEP%>FOLDER<%FSEP%>-<%SEP%>" fullword wide
		$s9 = "KILLPROC<%SEP%>" fullword wide
		$s10 = "LAUNCHPROC<%SEP%>" fullword wide
		$s11 = "cmd.exe /c start /b " fullword wide
		$s12 = "savservice" fullword wide
		$s13 = "getvrs" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $pdb* ) or 5 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Lastconn : FILE
{
	meta:
		description = "Detects LastConn"
		author = "ditekSHen"
		id = "18727c30-d84d-5ffa-acd4-2cc54e553604"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6865-L6894"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "94f5874353d0fb475595373c06a0de91603cad9b435d35dc00febf90608d6b5a"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "System.Net.Http.SysSR" fullword wide
		$s2 = "System.Net.Http.WrSR" fullword wide
		$s3 = "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK" fullword wide
		$s4 = { 63 00 6f 00 6e 00 74 00 65 00 6e 00 74 00 0c 6e
               00 6f 00 74 00 69 00 66 00 79 00 04 06 12 80 e8
               05 00 00 12 80 e8 08 75 00 73 00 65 00 72 00 08
               74 00 65 00 61 00 6d 00 06 61 00 70 00 70 00 0c
               6e 00 6f 00 61 00 75 00 74 00 68 00 }
		$s5 = { 68 00 69 00 64 00 64 00 65 00 6e 00 10 64 00 69
               00 73 00 61 00 6c 00 6c 00 6f 00 77 00 0e 65 00
               78 00 74 00 65 00 6e 00 64 00 73 00 04 69 00 64
               00 16 75 00 6e 00 69 00 71 00 75 00 65 00 49 00
               74 00 65 00 6d 00 73 }
		$s6 = "<RunFileOnes>d__" ascii
		$s7 = "<UploadFile>d__" ascii
		$s8 = "<ChunkUpload>d__" ascii
		$s9 = "<StartFolder>d__" ascii
		$s10 = "<ReadFileAlw>d__" ascii
		$s12 = "<WriteFileToD>d__" ascii
		$s13 = "<ReadFile>d__" ascii
		$s14 = "<GetUpload>d__" ascii
		$s15 = "CDropbox.Api.DropboxRequestHandler+<RequestJsonStringWithRetry>d__" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 12 of them
}
rule DITEKSHEN_MALWARE_Win_Crimsonrat : FILE
{
	meta:
		description = "Detects CrimsonRAT"
		author = "ditekSHen"
		id = "54c9bbb2-9fa6-5c1f-9272-13255357ddbf"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6896-L6920"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a40cf09dbaafb2e7b9130af1b40e46b4c38fed6185b16435ad4c118f9e6d56c7"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run|" fullword wide
		$s2 = "system volume information|" fullword wide
		$s3 = "program files (x86)|" fullword wide
		$s4 = "program files|" fullword wide
		$s5 = "<SAVE_AUTO<|" fullword wide
		$s6 = "add_up_files" fullword ascii
		$s7 = "see_folders" ascii
		$s8 = "see_files" ascii
		$s9 = "see_scren" ascii
		$s10 = "see_recording" ascii
		$s11 = "see_responce" ascii
		$s12 = "pull_data" ascii
		$s13 = "do_process" ascii
		$s14 = "do_updated" ascii
		$s15 = "IPSConfig" fullword ascii
		$s16 = "#Runing|ver#" wide
		$s17 = "|fileslog=" wide

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Actionrat : FILE
{
	meta:
		description = "Detects ActionRAT, CSharp and Delfi variants"
		author = "ditekSHen"
		id = "ceb4bd65-85c0-5614-a7cb-8f3f2f849eae"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6922-L6955"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "1552cda3f02c08582e3dd97df98416635a25005081627097df181bfc6aac4665"
		score = 75
		quality = 71
		tags = "FILE"

	strings:
		$x1 = /<action>(connect|command|drives|getfiles|upload|execute|download)<action>/ fullword wide
		$x2 = "aHR0cDovLzE0NC45MS42NS4xMDAv" wide
		$x3 = "aHR0cDovL21mYWhvc3QuZGRucy5uZXQv" wide
		$f1 = "<updateCommand>b__" ascii
		$f2 = "<getDrives>b__" ascii
		$f3 = "<getStatus>b__" ascii
		$f4 = "<getDirectories>b__" ascii
		$f5 = "<updateUpload>b__" ascii
		$f6 = "<infinity>b__" ascii
		$f7 = "<uploadFile>b__" ascii
		$s1 = "beaconURL" ascii
		$s2 = "PingReply" ascii
		$s3 = "updateUpload" ascii
		$s4 = "updateCommand" ascii
		$s5 = "runCommand" ascii
		$s6 = "uploadFile" ascii
		$s7 = "SELECT * FROM MSFT_NetAdapter WHERE ConnectorPresent = True AND DeviceID = '{0}'" fullword wide
		$s8 = "SOFTWARE\\Wow6432Node\\Microsoft\\Windows NT\\CurrentVersion" fullword wide
		$s9 = "Mozilla/3.0" fullword wide
		$s10 = "|directory|N/A|" fullword wide
		$s11 = "cmd.exe /c" fullword wide
		$c1 = /Content-Disposition: form-data; name=(hostname|hid|id|action|secondary)/ fullword wide
		$c2 = /(classification|updatecs|update|beacon)\.php/ wide
		$c3 = "Content-Disposition: form-data;name=\"{0}\";filename=\"{1}\"filepath=\"{2}\"" fullword wide
		$pdb1 = "D:\\Projects\\C#\\HTTP-Simple\\WindowsMediaPlayer - HTTP - " ascii
		$pdb2 = "\\WindowsMediaPlayer10\\obj\\x86\\Release\\winow4.pdb" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( #x1 > 5 or ( all of ( $f* ) and ( 1 of ( $s* ) or 2 of ( $c* ) ) ) or 7 of ( $s* ) or all of ( $c* ) or ( all of ( $pdb* ) and 4 of them ) or ( 2 of ( $x* ) and 5 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Nodachi : FILE
{
	meta:
		description = "Detects Nodachi infostealer"
		author = "ditekSHen"
		id = "bce0c44d-7e75-5c51-ba93-75bd81896921"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6957-L6972"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c8a262b862a47d5c0c9bd76b722aa4ceb55dd365b5dca35a61318d8a1c53269d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "//AppData//Roaming//kavachdb//kavach.db" ascii
		$s1 = "/upload/drive/v3/files/{fileId}" ascii
		$s2 = "main.getTokenFromWeb" ascii
		$s3 = "main.tokenFromFile" ascii
		$s4 = "/goLazagne/" ascii
		$s5 = "/extractor/withoutdrive/main.go" ascii
		$s6 = "struct { Hostname string \"json:\\\"hostname\\\"\"; EncryptedUsername string \"json:\\\"encryptedUsername\\\"\"; EncryptedPassword string \"json:\\\"encryptedPassword\\\"\" }" ascii
		$s7 = "C://Users//public//cred.json" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) and 3 of ( $s* ) ) or ( 4 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Iamthekingqueenofhearts : FILE
{
	meta:
		description = "IAmTheKing Queen Of Hearts payload"
		author = "ditekSHen"
		id = "b8d222f0-b3ce-5143-816b-4bbcde645672"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6974-L6991"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0aafeb1dce380ebe6cccc3c7f9564022e1a4cdcf20091943d2bfcc845129152d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "{'session':[{'name':'" ascii
		$s2 = "begin mainthread ok" wide
		$s3 = "getcommand error" wide
		$s4 = "querycode error" wide
		$s5 = "Code = %d" wide
		$s6 = "cookie size :%d" wide
		$s7 = "send request error:%d" wide
		$s8 = "PmMytex%d" wide
		$s9 = "%s_%c%c%c%c_%d" wide
		$s10 = "?what@exception@std@@UBEPBDXZ" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Iamthekingqueenofclubs : FILE
{
	meta:
		description = "IAmTheKing Queen Of Clubs payload"
		author = "ditekSHen"
		id = "4d19a484-0483-5b3e-a9ad-1cd8ca263a04"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L6993-L7007"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "28d7d3e9a3b7c104fc5b0fa38ce33b34596f16f6987c34a0e2e3fd93a8a908bd"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Not Support!" fullword wide
		$s2 = "%s|%s|%s|%s" fullword wide
		$s3 = "cmd.exe" fullword wide
		$s4 = "for(;;){$S=Get-Content \"%s\";IF($S){\"\" > \"%s\";$t=iex $S 2>\"%s\";$t=$t+' ';echo $t >>\"%s\";}sleep -m " wide
		$s5 = "PowerShell.exe -nop -c %s" fullword wide
		$s6 = "%s \"%s\" Df" fullword wide
		$s7 = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; SV1; .NET CLR 1.1.4322)" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Biopass_Dropper : FILE
{
	meta:
		description = "Detects Go BioPass dropper"
		author = "ditekSHen"
		id = "56037c79-59f7-587c-8f54-c9618e871f34"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7088-L7111"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "06f3b3ee38349ddcf9be7cbb7627d60fa673962409dde6e4badd112841a3ed19"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$go = "Go build ID:" ascii
		$s1 = "main.NetWorkStatus" ascii
		$s2 = "main.NoErrorRunFunction" ascii
		$s3 = "main.FileExist" ascii
		$s4 = "main.execute" ascii
		$s5 = "main.PsGenerator" ascii
		$s6 = "main.downFile" ascii
		$s7 = "main.Unzip" ascii
		$url1 = "https://flashdownloadserver.oss-cn-hongkong.aliyuncs.com/res/" ascii
		$x1 = "SCHTASKS /Run /TN SYSTEM_CDAEMON" ascii
		$x2 = "SCHTASKS /Run /TN SYSTEM_SETTINGS" ascii
		$x3 = "SCHTASKS /Run /TN SYSTEM_TEST && SCHTASKS /DELETE /F /TN SYSTEM_TEST" ascii
		$x4 = ".exe /install /quiet /norestart" ascii
		$x5 = "exec(''import urllib.request;exec(urllib.request.urlopen(urllib.request.Request(\\''http" ascii
		$x6 = "powershell.exe -Command $" ascii
		$x7 = ".Path ='-----BEGIN RSA TESTING KEY-----" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or 5 of ( $x* ) or ( 1 of ( $url* ) and ( $go ) ) or 9 of them )
}
rule DITEKSHEN_MALWARE_Win_A310Logger : FILE
{
	meta:
		description = "Detects A310Logger"
		author = "ditekSHen"
		id = "d2cf2f7b-5710-56ab-b13d-97a70fe7f618"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7113-L7149"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "8205169c9c78eb784b9d07a5fd85ad3a54763452e1e315f7e7911b8ac49a6c01"
		score = 75
		quality = 73
		tags = "FILE"
		snort_sid = "920204-920207"

	strings:
		$s1 = "Temporary Directory * for" fullword wide
		$s2 = "HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunOnce\\*RD_" wide
		$s3 = "@ENTIFIER=" wide
		$s4 = "ExecQuery" fullword wide
		$s5 = "MSXML2.ServerXMLHTTP.6.0" fullword wide
		$s6 = "Content-Disposition: form-data; name=\"document\"; filename=\"" wide
		$s7 = "CopyHere" fullword wide
		$s8 = "] Error in" fullword wide
		$s9 = "shell.application" fullword wide nocase
		$s10 = "SetRequestHeader" fullword wide
		$s11 = "\\Ethereum\\keystore" fullword wide
		$s12 = "@TITLE Removing" fullword wide
		$s13 = "@RD /S /Q \"" fullword wide
		$en1 = "Unsupported encryption" fullword wide
		$en2 = "BCryptOpenAlgorithmProvider(SHA1)" fullword wide
		$en3 = "BCryptGetProperty(ObjectLength)" fullword wide
		$en4 = "BCryptGetProperty(HashDigestLength)" fullword wide
		$v1_1 = "PW\\FILES\\SC::" wide
		$v1_2 = "AddAttachment" fullword wide
		$v1_3 = "Started:" fullword wide
		$v1_4 = "Ended:" fullword wide
		$v1_5 = "sharedSecret" fullword wide
		$v1_6 = "\":\"([^\"]+)\"" fullword wide
		$v1_7 = "\\credentials.txt" fullword wide
		$v1_8 = "WritePasswords" fullword ascii
		$v1_9 = "sGeckoBrowserPaths" fullword ascii
		$v1_10 = "get_sPassword" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 7 of ( $s* ) or ( 3 of ( $en* ) and 4 of ( $s* ) ) or ( 5 of ( $s* ) and 1 of ( $en* ) ) or 5 of ( $v1* ) or ( 4 of ( $v1* ) and 2 of ( $s* ) and 2 of ( $en* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Crylock : FILE
{
	meta:
		description = "Detects CryLock ransomware"
		author = "ditekSHen"
		id = "296288d8-2fdd-592a-aef9-7d4853885594"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7151-L7186"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "dde35dd2c7e89212c4562f2dcf6a78d06fbb3d31150d49e6c48f758b07f1834f"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "Encrypted by BlackRabbit. (BR-" ascii
		$s2 = "{ENCRYPTENDED}" ascii
		$s3 = "{ENCRYPTSTART}" ascii
		$s4 = "<%UNDECRYPT_DATETIME%>" ascii
		$s5 = "<%RESERVE_CONTACT%>" ascii
		$s6 = "how_to_decrypt.hta" ascii wide
		$s7 = "END ENCRYPT ONLY EXTENATIONS" ascii
		$s8 = "END UNENCRYPT EXTENATIONS" ascii
		$s9 = "END COMMANDS LIST" ascii
		$s10 = "END PROCESSES KILL LIST" ascii
		$s11 = "END SERVICES STOP LIST" ascii
		$s12 = "END PROCESSES WHITE LIST" ascii
		$s13 = "END UNENCRYPT FILES LIST" ascii
		$s14 = "END UNENCRYPT FOLDERS LIST" ascii
		$s15 = "Encrypted files:" ascii
		$s16 = { 65 78 74 65 6e 61 74 69 6f 6e 73 00 ff ff ff ff
                 06 00 00 00 63 6f 6e 66 69 67 00 00 ff ff ff ff
                 (0a|0d 0a) 00 00 00 63 6f 6e 66 69 67 2e 74 78 
                 74 00 00 ff ff ff ff 03 00 00 00 68 74 61 }
		$p1 = "-exclude" fullword
		$p2 = "-makeff" fullword
		$p3 = "-full" fullword
		$p4 = "-nolocal" fullword
		$p5 = "-nolan" fullword
		$p6 = "\" -id \"" fullword
		$p7 = "\" -wid \"" fullword
		$p8 = "\"runas\"" fullword
		$p9 = " -f -s -t 00" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $s* ) or 6 of ( $p* ) )
}
rule DITEKSHEN_MALWARE_Win_Deeprats : FILE
{
	meta:
		description = "Detects DeepRats ("
		author = "ditekSHen"
		id = "5b774e24-3864-519f-9cfd-d729d7d567a0"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7188-L7218"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		hash = "1f8b7e1b14869d119c5de1f05330094899bd997fca4c322d852db85cbd9271e6"
		logic_hash = "511264c0b6932f90069a5206cd142ca7210b0bc40c51ef5aa9c41a161fb57aab"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "https://freegeoip.live/json/https://myexternalip.com/rawin" ascii
		$s2 = "github.com/cretz/bine" ascii
		$s3 = "github.com/kbinani/screenshot" ascii
		$s4 = "socks5://%s:%d" ascii
		$s5 = "socks5://%s:%s@%s:%d" ascii
		$s6 = "http://%s:%d" ascii
		$s7 = "http://%s@%s:%d" ascii
		$s8 = "%SystemRoot%\\system32\\--CookieAuthentication" ascii
		$s9 = "tor_addr_" ascii
		$f1 = ".GetVnc" ascii
		$f2 = ".GetCommand" ascii
		$f3 = ".GetPayload" ascii
		$f4 = ".ListenCommands" ascii
		$f5 = ".ReceiveFile" ascii
		$f6 = ".RegisterImplant" ascii
		$f7 = ".Screenshot" ascii
		$f8 = ".SendFile" ascii
		$f9 = ".StartShell" ascii
		$f10 = ".UnregisterImplant" ascii
		$f11 = ".VncInstalled" ascii
		$f12 = ".PingPong" ascii
		$f13 = ".ListenCMD" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 7 of ( $s* ) or 8 of ( $f* ) )
}
rule DITEKSHEN_MALWARE_Win_Gasket : FILE
{
	meta:
		description = "Detects Gasket"
		author = "ditekSHen"
		id = "3afa131d-9c88-50df-a3b4-552db4a84e69"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7220-L7250"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0279979915891fc8c813ba555120ee5705b53b234a808b5ca77bff35a082e376"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "main.checkGasket" ascii
		$s2 = "main.connectGasket" ascii
		$s3 = "/cert/trust/dev/stderr/dev/stdout/index.html" ascii
		$f1 = ".SetPingHandler." ascii
		$f2 = ".SetPongHandler." ascii
		$f3 = ".computeMergeInfo." ascii
		$f4 = ".computeDiscardInfo." ascii
		$f5 = ".readPlatformMachineID." ascii
		$f6 = ".(*Session).establishStream." ascii
		$f7 = ".(*Session).handleGoAway." ascii
		$f8 = ".(*Stream).processFlags." ascii
		$f9 = ".(*Session).handlePing." ascii
		$f10 = ".(*windowsService).Install." ascii
		$f11 = ".(*windowsService).Uninstall." ascii
		$f12 = ".(*windowsService).Status." ascii
		$f13 = ".getStopTimeout." ascii
		$f14 = ".DialContext." ascii
		$f15 = ".WriteControl." ascii
		$f16 = ".(*Server).authenticate." ascii
		$f17 = ".(*Server).ServeConn." ascii
		$f18 = ".(*TCPProxy).listen." ascii
		$f19 = ".UserPassAuthenticator.Authenticate." ascii
		$f20 = ".(*InfoPacket).XXX_" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or 16 of ( $f* ) )
}
rule DITEKSHEN_MALWARE_Win_Lu0Bot : FILE
{
	meta:
		description = "Detects Lu0Bot"
		author = "ditekSHen"
		id = "f8595553-b911-5e30-9ece-cad7d5913f19"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7274-L7285"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b4822248230a804b1dc75f8d517af28a621dab1746c9ef45eaa4754149ce0cba"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "WinExec" fullword ascii
		$s2 = "AlignRects" fullword ascii
		$o1 = { be 00 20 40 00 89 f7 89 f0 81 c7 a? 01 00 00 81 }
		$o2 = { 53 50 e8 b0 01 00 00 e9 99 01 00 00 e8 ae 01 00 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 4KB and 1 of ( $s* ) and all of ( $o* )
}
rule DITEKSHEN_MALWARE_Win_Shellcodedlei : FILE
{
	meta:
		description = "Detects shellcode downloader, executer, injector"
		author = "ditekSHen"
		id = "62a4f141-87f8-596a-adf6-5bf9a50c9e91"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7287-L7304"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "064c17427ae6b33ffb09a14abcb924d20ead44250e8bd03070bf40869f1c812e"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "PPidSpoof" fullword ascii
		$s2 = "ProcHollowing" fullword ascii
		$s3 = "CreateProcess" fullword ascii
		$s4 = "DynamicCodeInject" fullword ascii
		$s5 = "PPIDDynCodeInject" fullword ascii
		$s6 = "MapAndStart" fullword ascii
		$s7 = "PPIDAPCInject" fullword ascii
		$s8 = "PPIDDLLInject" fullword ascii
		$s9 = "CopyShellcode" fullword ascii
		$s10 = "GetEntryFromBuffer" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 100KB and 5 of ( $s* )
}
rule DITEKSHEN_MALWARE_Win_Bluebot : FILE
{
	meta:
		description = "Detects BlueBot"
		author = "ditekSHen"
		id = "cddd40bb-c3c6-5c44-9cb1-480571375be8"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7306-L7333"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "04a19f649eb2fff7a5bc59ccead80cd0a04c4e5418cbc83e850045dba75b03e0"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "Blue_Botnet" wide
		$x2 = "5-START-http" ascii
		$x3 = "*300-END-" ascii
		$x4 = "botlogger.php" wide
		$s1 = "//TARGET//" wide
		$s2 = "//BLOG//" wide
		$s3 = "MCBOTALPHA" wide
		$s4 = "//IPLIST//" wide
		$s5 = "Host: //BLOG//" wide
		$s6 = "User-Agent: //USERAGENT//" wide
		$s7 = "<string>//TARGET//</string>" wide
		$s8 = "POST //URL// HTTP/1.1/r/n" wide
		$v1 = "<attack>b__" ascii
		$v2 = "PressData" fullword ascii
		$v3 = "POSTPiece" fullword ascii
		$v4 = /(load|tcp|udp)Stuff/ fullword ascii
		$v5 = "isAttacking" fullword ascii
		$v6 = "DoSAttack" fullword ascii
		$v7 = "prv_attack" fullword ascii
		$v8 = "blogList" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $x* ) or 5 of ( $s* ) or 5 of ( $v* ) or 9 of them )
}
rule DITEKSHEN_MALWARE_Win_Unkcobaltstrike : FILE
{
	meta:
		description = "Detects unknown malware, potentially CobaltStrike related"
		author = "ditekSHen"
		id = "24ddccc7-3700-57a1-999c-ddefae6911bb"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7335-L7354"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "2fb4e87eec3b56773b812ce6a5c28143183087e0f93d92d76c1103563f8e0891"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "https://%hu.%hu.%hu.%hu:%u" ascii wide
		$s2 = "https://microsoft.com/telemetry/update.exe" ascii wide
		$s3 = "\\System32\\rundll32.exe" ascii wide
		$s4 = "api.opennicproject.org" ascii wide
		$s5 = "%s %s,%s %u" ascii wide
		$s6 = "User32.d?" ascii wide
		$s7 = "StrDupA" fullword ascii wide
		$s8 = "{6d4feed8-18fd-43eb-b5c4-696ad06fac1e}" ascii wide
		$s9 = "{ac41592a-3d21-46b7-8f21-24de30531656}" ascii wide
		$s10 = "bd526:3b.4e32.57c8.9g32.35ef41642767~" ascii wide
		$s11 = { 4b d3 91 49 a1 80 91 42 83 b6 33 28 36 6b 90 97 }
		$s12 = { 0d 4c e3 5c c9 0d 1f 4c 89 7c da a1 b7 8c ee 7c }

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_MB150 : FILE
{
	meta:
		description = "Detects MB150? Go ransomware"
		author = "ditekSHen"
		id = "9688974b-ccf9-59ea-bb31-e46c63f021bf"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7376-L7402"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a07535fc53912ddde6a0bed187c21ecdb2701d317d7de0cbdd2db37071bc9a21"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = /main\.evade_(clicks_count|cpu_count|disk_size|foreground_window|hostname|mac|printer|screen_size|system_memory|time_acceleration|tmp|utc)/ fullword ascii
		$x2 = /main\.sandbox_(hostname|mac_addresses)/ fullword ascii
		$x3 = "main.drop_ransom_note" fullword ascii
		$x4 = "main.ransom_amount" fullword ascii
		$x5 = "main.create_encryption_key" fullword ascii
		$x6 = "main.encrypt" fullword ascii
		$x7 = "main.encrypt_encryption_key" fullword ascii
		$x8 = "main.encrypt_file" fullword ascii
		$x9 = "main.ext_blacklist" fullword ascii
		$mac1 = "00:03:FF00:05:6900:0C:2900:16:3E00:1C:1400:1C:4200:50:56" ascii nocase
		$mac2 = "00-03-FF00-05-6900-0C-2900-16-3E00-1C-1400-1C-4200-50-56" ascii nocase
		$mac3 = "0003FF000569000C2900163E001C14001C42005056" ascii nocase
		$go = "Go build ID:" ascii
		$s1 = "main.MB150" ascii
		$s2 = "http://1.1.1.1" ascii
		$s3 = "your personnal ID" ascii
		$s4 = "ransom amount" ascii
		$s5 = "binance.com" ascii
		$s6 = "getmonero.org" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 4 of ( $x* ) or ( $go and 4 of ( $s* ) ) or ( 1 of ( $mac* ) and ( 2 of ( $x* ) or 3 of ( $s* ) ) ) )
}
rule DITEKSHEN_MALWARE_Win_Horuseyesrat : FILE
{
	meta:
		description = "Detects HorusEyesRAT"
		author = "ditekSHen"
		id = "80b2fd11-f8b4-5aee-b55a-4f7ee9fad6cf"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7435-L7451"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c0f499e3a17923b391ed6b7fa723525a9d4aef0ce04a2c7abec60d5eda15888f"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$x1 = "\\HorusEyesRat-" ascii
		$x2 = "\\HorusEyesRat.pdb" ascii
		$x3 = "get_horus_eye" ascii
		$s1 = "get_Type_Packet" fullword ascii
		$s2 = "PacketLib" fullword ascii nocase
		$s3 = "System.Net.Sockets" fullword ascii
		$s4 = "PROCESS_MODE_BACKGROUND_BEGIN" fullword ascii
		$s5 = "EXECUTION_STATE" fullword ascii
		$s6 = /Plugins\\[A-Z]{2}.dll/ fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $x* ) or ( 1 of ( $x* ) and 3 of ( $s* ) ) or ( 4 of ( $s* ) and #s6 > 4 ) )
}
rule DITEKSHEN_MALWARE_Win_Breakwin : FILE
{
	meta:
		description = "Detects BreakWin Wiper"
		author = "ditekSHen"
		id = "4ffadbfa-c1cc-59e6-a9ba-7a34eca6c3fe"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7453-L7471"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "86fc89e28fc107c2d4fe98dc16048d9e076b1fef53a3df0814f80a88bbe09c48"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Started wiping file %s with %s." fullword wide
		$s2 = "C:\\Program Files\\Lock My PC" wide
		$s3 = "Stardust is still alive." fullword wide
		$s4 = "Failed to terminate the locker process." fullword wide
		$s5 = "C:\\Windows\\System32\\cmd.exe" fullword wide
		$s6 = "Process created successfully. Executed command: %s." fullword wide
		$s7 = "locker_background_image_path" fullword ascii
		$s8 = "takeown.exe /F \"C:\\Windows\\Web\\Screen\" /R /A /D Y" fullword ascii
		$s9 = "icacls.exe \"C:\\Windows\\Web\\Screen\" /reset /T" fullword ascii
		$s10 = "takeown.exe /F \"C:\\ProgramData\\Microsoft\\Windows\\SystemData\" /R /A /D Y" fullword ascii
		$s11 = ".?AVProcessSnapshotCreationFailedException@@" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Win_Coinminer03 : FILE
{
	meta:
		description = "Detects coinmining malware"
		author = "ditekSHen"
		id = "e0e57557-7c46-5336-b904-c4c1f142bd81"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7506-L7528"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f22e1af955a0d132dda820fe5e5e1ae2f077b7264ce1f0125a2f37c0da6b6508"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "UnVzc2lhbiBTdGFuZGFyZCBUaW1l" wide
		$s2 = "/xmrig" wide
		$s3 = "/gminer" wide
		$s4 = "-o {0} -u {1} -p {2} -k --cpu-priority 0 --threads={3}" wide
		$s5 = "--algo ethash --server" wide
		$s6 = "--algo kawpow --server" wide
		$cnc1 = "/delonl.php?hwid=" fullword wide
		$cnc2 = "/gateonl.php?hwid=" fullword wide
		$cnc3 = "&cpuname=" fullword wide
		$cnc4 = "&gpuname=" fullword wide
		$cnc5 = "{0}/gate.php?hwid={1}&os={2}&cpu={3}&gpu={4}&dateinstall={5}&gpumem={6}" fullword wide
		$cnc6 = "/del.php?hwid=" fullword wide
		$f1 = "<StartGpuethGminer>b__" ascii
		$f2 = "<StartGpuetcGminer>b__" ascii
		$f3 = "<StartGpurvnGminer>b__" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $cnc* ) or ( 2 of ( $f* ) and ( 1 of ( $s* ) or 1 of ( $f* ) ) ) or all of ( $f* ) or 5 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Zeppelin : FILE
{
	meta:
		description = "Detects Zeppelin (Delphi) ransomware"
		author = "ditekSHen"
		id = "368d0c31-745d-50ad-a265-50561fdc822a"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7530-L7545"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f6c8420756b562662985dd26eaad58500a24cae786a47b788c953e86276116a1"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "TUnlockAndEncrypt" ascii
		$s2 = "TExcludeFiles" ascii
		$s3 = "TExcludeFolders" ascii
		$s4 = "TDrivesAndShares" ascii
		$s5 = "TTaskKiller" ascii
		$x1 = "!!! D !!!" ascii
		$x2 = "!!! LOCALPUBKEY !!!" ascii
		$x3 = "!!! ENCLOCALPRIVKEY !!!" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or all of ( $x* ) or ( 2 of ( $x* ) and 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Slackbot : FILE
{
	meta:
		description = "Detects SlackBot"
		author = "ditekSHen"
		id = "cd540aa2-dc8f-5ccc-b66c-a8d72b73c896"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7547-L7588"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "919839883c437b69cf7f380830f2499be24415f96f1e42424e4859114f958581"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$x1 = "lp0o4bot v" ascii
		$x2 = "slackbot " ascii
		$s1 = "cpu: %lumhz %s, uptime: %u+%.2u:%.2u, os: %s" fullword ascii
		$s2 = "%s, running for %u+%.2u:%.2u" fullword ascii
		$s3 = "PONG :%s" fullword ascii
		$s4 = "PRIVMSG %s :%s" fullword ascii
		$s5 = "Mozilla/4.0 (compatible; MSIE 5.5; Windows 98)" fullword ascii
		$m1 = "saving %s to %s" ascii
		$m2 = "visit number %u failed" ascii
		$m3 = "sending %s packets of %s bytes to %s with a delay of %s" ascii
		$m4 = "file executed" ascii
		$m5 = "packets sent" ascii
		$m6 = "upgrading to %s" ascii
		$m7 = "rebooting..." ascii
		$c1 = "!@remove" fullword ascii
		$c2 = "!@restart" fullword ascii
		$c3 = "!@reboot" fullword ascii
		$c4 = "!@rndnick" fullword ascii
		$c5 = "!@exit" fullword ascii
		$c6 = "!@sysinfo" fullword ascii
		$c7 = "!@upgrade" fullword ascii
		$c8 = "!@login" fullword ascii
		$c9 = "!@run" fullword ascii
		$c10 = "!@webdl" fullword ascii
		$c11 = "!@cycle" fullword ascii
		$c12 = "!@clone" fullword ascii
		$c13 = "!@visit" fullword ascii
		$c14 = "!@udp" fullword ascii
		$c15 = "!@nick" fullword ascii
		$c16 = "!@say" fullword ascii
		$c17 = "!@quit" fullword ascii
		$c18 = "!@part" fullword ascii
		$c19 = "!@join" fullword ascii
		$c20 = "!@raw" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) or all of ( $s* ) or all of ( $m* ) or ( 10 of ( $c* ) and ( 1 of ( $x* ) or 3 of ( $s* ) or 2 of ( $m* ) ) ) )
}
rule DITEKSHEN_MALWARE_Win_Sweetystealer : FILE
{
	meta:
		description = "Detects SweetyStealer"
		author = "ditekSHen"
		id = "21dd1706-2cb5-5b27-ad3a-c3de8e6fb333"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7590-L7608"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ecf22240b47af077055260faba0406721f1b4cc5ed04180285df0de86c4e1241"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "SWEETY STEALER" wide
		$s2 = "\\SWEETYLOG.zip" fullword wide
		$s3 = "\\SWEETY STEALER\\SWEETY\\" ascii
		$s4 = "\\Sweety" fullword wide
		$s5 = "SWEETYSTEALER." ascii
		$s6 = "in Virtual Environment, so we prevented stealing" wide
		$s7 = ":purple_square:" wide
		$f1 = "<GetDomainDetect>b__" ascii
		$f2 = "<GetAllProfiles>b__" ascii
		$f3 = "<ProcessExtraFieldZip64>b__" ascii
		$f4 = "<PostExtractCommandLine>k__" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 3 of ( $s* ) or ( 3 of ( $f* ) and 1 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Genircbot : FILE
{
	meta:
		description = "Detects generic IRCBots"
		author = "ditekSHen"
		id = "e1faa1dd-bbf5-5208-97d6-a6e8597d39bc"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7610-L7626"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "cc7f4599148c45fdf755c07530ae4846b7e283b5c1001c121f9ea05279997dc1"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "@login" ascii nocase
		$s2 = "PRIVMSG" fullword ascii
		$s3 = "JOIN" fullword ascii
		$s4 = "PING :" fullword ascii
		$s5 = "NICK" fullword ascii
		$s6 = "USER" fullword ascii
		$x1 = "irc.danger.net" fullword ascii nocase
		$x2 = "evilBot" fullword ascii nocase
		$x3 = "#evilChannel" fullword ascii nocase

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or 2 of ( $x* ) )
}
rule DITEKSHEN_MALWARE_Win_Nanocore : FILE
{
	meta:
		description = "Detects NanoCore"
		author = "ditekSHen"
		id = "931b98f6-df2b-538b-bc49-ecbbd24334da"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7654-L7681"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "6336260e0af2b4b51338ee066f41b7c58aa134a6c03ca110db7e088edf2b65a7"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "NanoCore Client" fullword ascii
		$x2 = "NanoCore.ClientPlugin" fullword ascii
		$x3 = "NanoCore.ClientPluginHost" fullword ascii
		$i1 = "IClientApp" fullword ascii
		$i2 = "IClientData" fullword ascii
		$i3 = "IClientNetwork" fullword ascii
		$i4 = "IClientAppHost" fullword ascii
		$i5 = "IClientDataHost" fullword ascii
		$i6 = "IClientLoggingHost" fullword ascii
		$i7 = "IClientNetworkHost" fullword ascii
		$i8 = "IClientUIHost" fullword ascii
		$i9 = "IClientNameObjectCollection" fullword ascii
		$i10 = "IClientReadOnlyNameObjectCollection" fullword ascii
		$s1 = "ClientPlugin" fullword ascii
		$s2 = "EndPoint" fullword ascii
		$s3 = "IPAddress" fullword ascii
		$s4 = "IPEndPoint" fullword ascii
		$s5 = "IPHostEntr" fullword ascii
		$s6 = "get_ClientSettings" fullword ascii
		$s7 = "get_Connected" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $x* ) or 8 of ( $i* ) or all of ( $s* ) or ( 1 of ( $x* ) and ( 3 of ( $i* ) or 2 of ( $s* ) ) ) )
}
rule DITEKSHEN_MALWARE_Win_Neshta : FILE
{
	meta:
		description = "Detects Neshta"
		author = "ditekSHen"
		id = "b96ee19e-b631-57fd-bf8a-67d790202c46"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7711-L7720"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "7967c1154f652e28e541058a7b7f61aa077cfaf6be58282e1de68d9a6088c1ac"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Delphi-the best. Fuck off all the rest. Neshta 1.0 Made in Belarus." fullword ascii
		$s2 = "! Best regards 2 Tommy Salo. [Nov-2005] yours [Dziadulja Apanas]" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Linux_Hellokitty : FILE
{
	meta:
		description = "Detects Linux version of HelloKitty ransomware"
		author = "ditekSHen"
		id = "bb228937-8cd8-5fb8-aaed-3bd539ae96f2"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7722-L7746"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "bcb1188d616b29fa535e757a37476435a3061d27e143339413f6829876701868"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "exec_pipe:%s" ascii
		$s2 = "Error InitAPI !!!" fullword ascii
		$s3 = "No Files Found !!!" fullword ascii
		$s4 = "Error open log File:%s" fullword ascii
		$s5 = "%ld - Files Found  " fullword ascii
		$s6 = "Total VM run on host:" fullword ascii
		$s7 = "error:%d open:%s" fullword ascii
		$s8 = "work.log" fullword ascii
		$s9 = "esxcli vm process kill" ascii
		$s10 = "readdir64" fullword ascii
		$s11 = "%s_%d.block" fullword ascii
		$s12 = "EVP_EncryptFinal_ex" fullword ascii
		$s13 = ".README_TO_RESTORE" fullword ascii
		$m1 = "COMPROMISED AND YOUR SENSITIVE PRIVATE INFORMATION WAS STOLEN" ascii nocase
		$m2 = "damage them without special software" ascii nocase
		$m3 = "leaking or being sold" ascii nocase
		$m4 = "Data will be Published and/or Sold" ascii nocase

	condition:
		uint16( 0 ) == 0x457f and ( 6 of ( $s* ) or ( 2 of ( $m* ) and 2 of ( $s* ) ) or 8 of them )
}
rule DITEKSHEN_MALWARE_Win_Blackmatter : FILE
{
	meta:
		description = "Detects BlackMatter ransomware"
		author = "ditekSHen"
		id = "8883e652-edab-5cbf-a4fa-963b437447d9"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7748-L7767"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4558002b424f7102f67fc44dfc37ac20f6013e25ae827c6aee0fc37231e2fa72"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "C:\\Windows\\System32\\*.drv" fullword wide
		$s2 = "NYbr-Vk@" fullword ascii
		$s3 = ":7:=:H:Q:W:\\:b:&;O;^;v;" fullword ascii
		$o1 = { b0 34 aa fe c0 e2 fb b9 03 }
		$o2 = { fe 00 ff 75 08 ff 75 0c ff b5 d8 fe ff ff ff b5 }
		$o3 = { 6a 00 ff 75 0c ff b5 d8 fe ff ff ff b5 dc fe ff }
		$o4 = { ff 75 08 ff 75 0c ff b5 d8 fe ff ff ff b5 dc fe }
		$o5 = { 53 56 57 8d 85 70 ff ff ff 83 c0 0f 83 e0 f0 89 }
		$o6 = { c7 85 68 ff ff ff 00 04 00 00 8b 85 6c ff ff ff }

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) and all of ( $o* ) )
}
rule DITEKSHEN_MALWARE_Win_Dlinjector04 : FILE
{
	meta:
		description = "Detects downloader / injector"
		author = "ditekSHen"
		id = "fe423aee-6ff4-5fd0-9fa2-51dd0c27f54b"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7769-L7790"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ab9a047e53dec2cc5986522636783b5cb8aae7fc0297292d017ec22ee5750cce"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Runner" fullword ascii
		$s2 = "DownloadPayload" fullword ascii
		$s3 = "RunOnStartup" fullword ascii
		$a1 = "Antis" fullword ascii
		$a2 = "antiVM" fullword ascii
		$a3 = "antiSandbox" fullword ascii
		$a4 = "antiDebug" fullword ascii
		$a5 = "antiEmulator" fullword ascii
		$a6 = "enablePersistence" fullword ascii
		$a7 = "enableFakeError" fullword ascii
		$a8 = "DetectVirtualMachine" fullword ascii
		$a9 = "DetectSandboxie" fullword ascii
		$a10 = "DetectDebugger" fullword ascii
		$a11 = "CheckEmulator" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( all of ( $s* ) and 5 of ( $a* ) ) or 10 of ( $a* ) )
}
rule DITEKSHEN_MALWARE_Win_Macoute : FILE
{
	meta:
		description = "Detects Macoute"
		author = "ditekSHen"
		id = "0ecfb923-2e51-544e-984d-efdeeb175727"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7814-L7836"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "1dffa48fe6c0ac053509b5f5994d323fd72d090da0f077b52c9bc33df6997964"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "scp%s%s%s%s" ascii
		$s2 = "putfile %s %s" ascii
		$s3 = "pscp|%s|%s:%s" ascii
		$s4 = "connect %host %port\\n" ascii
		$s5 = "/ecoute/spool/%s-%lu" ascii
		$s6 = "<f n=\"%s\" s=\"%lu\" d=\"%d-%d-%d\"/>" ascii
		$s7 = "CMPT;%s;%s;%s;%s;%s" ascii
		$s8 = "%s\\apoScreen%lu.dll" ascii
		$s9 = "/cap/%s%lu.jpg" ascii
		$s10 = "INFO;%u;%u;%u;%d;%d;%d;%d;%d;%d;%d;%s" ascii
		$s11 = "SUBJECT: %s is comming!" ascii
		$s12 = "Content-type: multipart/mixed; boundary=\"#BOUNDARY#\"" ascii
		$s13 = "FROM: %s@yahoo.com" ascii
		$s14 = "<html><script language=\"JavaScript\">window.open(\"readme.eml\", null,\"resizable=no,top=6000,left=6000\")</script></html>" ascii
		$s15 = "<html><HEAD></HEAD><body bgColor=3D#ffffff><iframe src=3Dcid:THE-CID height=3D0 width=3D0></iframe></body></html>" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 10 of them
}
rule DITEKSHEN_MALWARE_Win_Coinminer04 : FILE
{
	meta:
		description = "Detects coinmining malware"
		author = "ditekSHen"
		id = "d90d8ad3-20b7-5bb4-8c58-3488c60ed9a2"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7838-L7858"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "2ef60dbf0bac3d5910635bb011a45e5ebc1392094b10425604fa9dd290198f8b"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "createDll" fullword ascii
		$s2 = "getTasks" fullword ascii
		$s3 = "SetStartup" fullword ascii
		$s4 = "loadUrl" fullword ascii
		$s5 = "Processer" fullword ascii
		$s6 = "checkProcess" fullword ascii
		$s7 = "runProcess" fullword ascii
		$s8 = "createDir" fullword ascii
		$cnc1 = "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0" fullword wide
		$cnc2 = "?hwid=" fullword wide
		$cnc3 = "?timeout=1" fullword wide
		$cnc4 = "&completed=" fullword wide
		$cnc5 = "/cmd.php" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 5 of ( $s* ) and 1 of ( $cnc* ) )
}
rule DITEKSHEN_MALWARE_Win_Sidewalk : FILE
{
	meta:
		description = "Detects SideWalk"
		author = "ditekSHen"
		id = "ab82b83a-a279-555a-83c2-6340431b10da"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7860-L7880"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "6885a1ad69d61fa5875ee0db949071e84390fc2db4307c412b32cd17c0806f6a"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Decommit" fullword ascii
		$s2 = "Shellc0deRunner" fullword ascii
		$s3 = "shellc0de" fullword ascii
		$s4 = "C:\\Windows\\System32\\msdt.exe" fullword wide
		$s5 = "StartProcessWOPid" fullword ascii
		$s6 = "StartProcessWithParent" fullword ascii
		$m1 = "alloctype" fullword ascii
		$m2 = "ThreadIoPriority" fullword ascii
		$m3 = "PebAddress" fullword ascii
		$m4 = "dotnet.4.x64.dll" fullword wide
		$m5 = "LogonNetCredentialsOnly" fullword ascii
		$m6 = "ThreadIdealProcessor" fullword ascii
		$m7 = "LogonWithProfile" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 5 of ( $s* ) or all of ( $m* ) or ( 11 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Vanillarat : FILE
{
	meta:
		description = "Detects VanillaRAT"
		author = "ditekSHen"
		id = "70c2cd1a-a6d4-562e-a6fc-c16a9e87c6b7"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7882-L7902"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d7b90ac88a50693ec4bb0676c04f5d161f04f67970ea60d80e79d774da75bfdc"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$stub = "VanillaStub." ascii wide
		$s1 = "Client.Send: " wide
		$s2 = "Connected to chat" fullword wide
		$s3 = "GetStoredPasswords" fullword wide
		$s4 = "Started screen locker." fullword wide
		$s5 = "[<\\MOUSE>]" fullword wide
		$s6 = "YOUR SCREEN HAS BEEN LOCKED!" fullword wide
		$s7 = "record recsound" fullword wide
		$f1 = "<StartRemoteDestkop>d__" ascii
		$f2 = "<ConnectLoop>d__" ascii
		$f3 = "<Scan0>k__" ascii
		$f4 = "<RemoteShellActive>k__" ascii
		$f5 = "KillClient" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( $stub and ( 2 of ( $s* ) or 2 of ( $f* ) ) ) or 6 of ( $s* ) or all of ( $f* ) )
}
rule DITEKSHEN_MALWARE_Win_Sectoprat : FILE
{
	meta:
		description = "Detects SectopRAT"
		author = "ditekSHen"
		id = "d6594834-24d7-5e86-84b5-5a7920e7bc89"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7904-L7929"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b4048f837c02560a8b650247173be25893b466e5cec8f2784eea58172f973822"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\\\.\\root\\cimv2:Win32_Process" wide
		$s2 = "\\\\.\\root\\cimv2:CIM_DataFile.Name=" wide
		$s3 = "^.*(?=Windows)" fullword wide
		$s4 = "C:\\Windows\\System32\\cmd.exe" wide
		$s5 = "C:\\Windows\\explorer.exe" wide
		$s6 = "Disabling IE protection" wide
		$s7 = "stream started succces" wide
		$b1 = "/C start Firefox" wide
		$b2 = "/C start chrome" wide
		$b3 = "/C start iexplore" wide
		$m1 = "DefWindowProc" fullword ascii
		$m2 = "AuthStream" fullword ascii
		$m3 = "KillBrowsers" fullword ascii
		$m4 = "GetAllNetworkInterfaces" fullword ascii
		$m5 = "EnumDisplayDevices" fullword ascii
		$m6 = "RemoteClient.Packets" fullword ascii
		$m7 = "IServerPacket" fullword ascii
		$m8 = "keybd_event" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 5 of ( $s* ) and 2 of ( $b* ) ) or all of ( $s* ) or ( all of ( $b* ) and ( 4 of ( $s* ) or 5 of ( $m* ) ) ) )
}
rule DITEKSHEN_MALWARE_Win_Neptune : FILE
{
	meta:
		description = "Detects Neptune keylogger / infostealer"
		author = "ditekSHen"
		id = "0f619bea-f00b-5078-95a4-83306e3e87b4"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7931-L7953"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e3298bf55f89180ed7e9f7ad35b59d39284a5143fd69fa2a4fbc27d91fb2fbd3"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "your keylogger has been freshly installed on" wide
		$x2 = "Attached is a screenshot of the victim" wide
		$x3 = "color: rgb(2, 84, 138);'>Project Neptune</span><br>" wide
		$x4 = ">{Monitor Everything}</span><br><br>" wide
		$x5 = "[First Run] Neptune" wide
		$x6 = "Neptune - " wide
		$s1 = "Melt" fullword wide
		$s2 = "Hide" fullword wide
		$s3 = "SDDate+" fullword wide
		$s4 = "DelOff+" fullword wide
		$s5 = "MsgFalse+" fullword wide
		$s6 = "Clipboard:" fullword wide
		$s7 = "information is valid and working!" wide
		$s8 = ".exe /k %windir%\\System32\\reg.exe ADD HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v EnableLUA /t REG_DWORD /d 0 /f" wide
		$s9 = "http://www.exampleserver.com/directfile.exe" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $x* ) or 7 of ( $s* ) or ( 1 of ( $x* ) and 5 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Tomiris : FILE
{
	meta:
		description = "Detects Tomiris"
		author = "ditekSHen"
		id = "86efd4fb-3c76-504e-b367-132aee59e09a"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7955-L7978"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "1d9baeb6db2e849dd053c3fc735984e23b9cead39cf166f8a544ee5a439185d1"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$f1 = "main.workPath" ascii
		$f2 = "main.selfName" ascii
		$f3 = "main.infoServerAddr" ascii
		$f4 = "main.configFileName" ascii
		$s1 = "C:/Projects/go/src/Tomiris/main.go" ascii
		$s2 = "C:/GO/go1.16.2/src/os/user/lookup_windows.go" ascii
		$s3 = "C:\\GO\\go1.16.2" ascii
		$s4 = ".html.jpeg.json.wasm.webp/p/gf/p/kk1562515" ascii
		$s5 = "\" /ST 10:00alarm clockassistQueueavx512vbmi2avx512vnniwbad" ascii
		$s6 = "write /TR \" Value addr= alloc base  code= ctxt: curg= free  goid  jobs= list= m->p=" ascii
		$t1 = "SCHTASKS /DELETE /F /TN \"%s\"" ascii
		$t2 = "SCHTASKS /CREATE /SC DAILY /TN" ascii
		$t3 = "SCHTASKS /CREATE /SC ONCE /TN \"%s\" /TR \"%s\" /ST %s" ascii
		$t4 = "SCHTASKS /CREATE /SC ONCE /TN \"%s\" /TR \"'%s' %s\" /ST %s" ascii
		$r1 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Time Zones" ascii
		$r2 = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( all of ( $f* ) and 3 of ( $s* ) and 2 of ( $t* ) and 1 of ( $r* ) ) or ( 4 of ( $s* ) and 2 of ( $t* ) and 1 of ( $r* ) ) or 12 of them )
}
rule DITEKSHEN_MALWARE_Win_Jennlog : FILE
{
	meta:
		description = "Detects JennLog loader"
		author = "ditekSHen"
		id = "38f8cd13-f157-5cce-bf04-80c29d254144"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7980-L7996"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "085a4783c7c01ec95491d9999d1835ad9ab3dc70d77b944578e097b3ffe3a627"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "%windir%\\system32\\rundll32.exe advapi32.dll,ProcessIdleTasks" fullword wide
		$x2 = "https://fkpageintheworld342.com" fullword wide
		$s1 = "ExecuteInstalledNodeAndDelete" fullword ascii
		$s2 = "ProcessExsist" fullword ascii
		$s3 = "helloworld.Certificate.txt" fullword wide
		$s4 = "ASCII85 encoded data should begin with '" fullword wide
		$s5 = "] WinRE config file path: C:\\" ascii
		$s6 = "] Parameters: configWinDir: NULL" ascii
		$s7 = "] Update enhanced config info is enabled." ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) and 3 of ( $s* ) ) or 5 of ( $s* ) or ( all of ( $x* ) and 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Lockfile : FILE
{
	meta:
		description = "Detects LockFile ransomware"
		author = "ditekSHen"
		id = "762ac376-43ff-56d2-b279-2879ce6d8542"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L7998-L8014"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "28c8aa8931d599e5a1860fe2ed0b8172e709dad1a48a319858a907fa775af293"
		score = 75
		quality = 71
		tags = "FILE"

	strings:
		$x1 = "LOCKFILE" fullword ascii
		$x2 = "25a01bb859125507013a2fe9737d3c33" fullword ascii
		$s1 = "</key>" fullword ascii
		$s2 = "<computername>%s</computername>" fullword ascii
		$s3 = "<blocknum>%d</blocknum>" fullword ascii
		$s4 = "%s\\%s-%s-%d%s" fullword ascii
		$s5 = ">RAC=OQD:S>P@:AO?R:EEOS:ARDD=N?EENSB" ascii wide
		$m1 = "<title>LOCKFILE</title>" ascii wide nocase
		$m2 = "<hta:application id=LOCKFILE applicationName=LOCKFILE" ascii wide nocase

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) or all of ( $s* ) or ( 1 of ( $x* ) and ( 2 of ( $s* ) or 1 of ( $m* ) ) ) or ( 1 of ( $m* ) and ( 1 of ( $x* ) or 2 of ( $s* ) ) ) )
}
rule DITEKSHEN_MALWARE_Win_Unicorn : FILE
{
	meta:
		description = "Detects Unicorn infostealer"
		author = "ditekSHen"
		id = "7cc8298d-abbd-5dda-bbd4-8b061095c367"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8077-L8107"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c4150b213c0dd88c87eb81e3ad455d8f658a57b0998bc6e394c5afac9423d9f2"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "WinHTTP Downloader/1.0" fullword wide
		$x2 = "[CTRL + %c]" fullword wide
		$x3 = "\\UnicornLog.txt" fullword wide
		$x4 = "/*INITIALIZED*/" fullword wide
		$s1 = { 2f 00 63 00 20 00 22 00 43 00 4f 00 50 00 59 00
               20 00 2f 00 59 00 20 00 2f 00 42 00 20 00 22 00
               25 00 73 00 22 00 20 00 22 00 25 00 73 00 22 00
               22 00 00 00 63 00 6d 00 64 00 2e 00 65 00 78 00
               65 }
		$s2 = { 72 00 75 00 6e 00 64 00 6c 00 6c 00 33 00 32 00
               2e 00 65 00 78 00 65 00 00 00 00 00 25 00 73 00
               20 00 22 00 25 00 73 00 22 00 2c 00 25 00 68 00
               73 }
		$s3 = "%*[^]]%c%n" fullword ascii
		$s4 = "file://%s%s%s" fullword ascii
		$s5 = "%s://%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s" fullword ascii
		$s6 = "regex_start_injects" fullword ascii
		$s7 = "DLEXEC" fullword ascii
		$s8 = "^((((3|1)[A-Za-z0-9]{33}))(\\s|$)|(bc1q)[A-Za-z0-9]{38}(\\s|$))" fullword ascii
		$s9 = "^(0x)?[A-Za-z0-9]{40}(\\s|$)" fullword ascii
		$s10 = "clipRegex" fullword ascii
		$s11 = "%s?k=%s&src=clip&id=%s" fullword ascii
		$s12 = "http://izuw6rclbgl2lwsh.onion/o.php" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) or 8 of ( $s* ) or ( 3 of ( $x* ) and 5 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Spectre : FILE
{
	meta:
		description = "Detects Spectre infostealer"
		author = "ditekSHen"
		id = "43b32900-8dff-5a95-bcff-d6bd17703476"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8109-L8124"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ee041928ab5010fd5a06538f9a7cf9c72e44903fdb05f13b12362af0b326fd6f"
		score = 75
		quality = 75
		tags = "FILE"
		snort_sid = "920233-920234"

	strings:
		$s1 = "\\../../../json.h" wide
		$s2 = "static_cast<std::size_t>(index) < kCachedPowers.size()" fullword wide
		$s3 = " cmd.exe" fullword wide
		$s4 = "m_it.object_iterator != m_object->m_value.object->end()" fullword wide
		$h1 = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1" fullword wide
		$h2 = "----974767299852498929531610575" ascii wide
		$h3 = "Content-Disposition: form-data; name=\"file\"; filename=\"" fullword ascii

	condition:
		( uint16( 0 ) == 0x5a4d and ( ( all of ( $s* ) and 1 of ( $h* ) ) or ( all of ( $h* ) and 2 of ( $s* ) ) ) ) or ( 6 of them )
}
rule DITEKSHEN_MALWARE_Win_Dlinjector05 : FILE
{
	meta:
		description = "Detects downloader / injector (NiceProcess)"
		author = "ditekSHen"
		id = "857eb13b-a882-5326-b7aa-4d2fcd0b6425"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8141-L8158"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5345c2b03e14b7324a13bac0da783eec8c30da18043c1b2d46162e5b511fae63"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "pidhtmpfile.tmp" fullword ascii
		$s2 = "pidhtmpdata.tmp" fullword ascii
		$s3 = "pidHTSIG" fullword ascii
		$s4 = "Taskmgr.exe" fullword ascii
		$s5 = "[HP][" ascii
		$s6 = "[PP][" ascii
		$s7 = { 70 69 64 68 74 6d 70 66 69 6c 65 2e 74 6d 70 00
                2e 64 6c 6c 00 00 00 00 70 69 64 48 54 53 49 47
                00 00 00 00 ?? ?? 00 00 54 61 73 6b 6d 67 72 2e
                65 78 65 }

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Win_Kutaki : FILE
{
	meta:
		description = "Detects Kutaki"
		author = "ditekSHen"
		id = "d91812bb-4564-56b5-9757-81255b5233fb"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8160-L8173"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "24fbc9ca6de421275813c285a8fca91cfcede48f4b4de9feda010c644f0c251f"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "AASEaHR0cDovL29qb3JvYmlhLmNsdWIvbGFwdG9wL2xhcHRvcC5waHA" ascii
		$x2 = "aHR0cDovL3RlcmViaW5uYWhpY2MuY2x1Yi9zZWMva29vbC50eHQ" ascii
		$s1 = "wewqeuuiwe[XXXXXXX]" ascii
		$s2 = "alt|aHR0cD" ascii
		$s3 = "<rdf:Description about='uuid:fb761dc9-9daf-11d9-9a32-fcf1da45dca2'" ascii
		$s4 = "<rdf:Description about='uuid:0ab54f47-96d6-11d9-a59c-cbc93330e07e'" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) and 1 of ( $s* ) ) or ( all of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Dlinjector06 : FILE
{
	meta:
		description = "Detects downloader / injector"
		author = "ditekSHen"
		id = "9d8164ee-49b3-5eb1-bd1d-9437fc6f1392"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8175-L8189"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e44ea8dbb94c6cd3b63d66eac3e9b3d6d5ff7d561410b8328e6c24630645305b"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36" ascii wide
		$s2 = "Content-Type: application/x-www-form-urlencoded" wide
		$s3 = "https://ipinfo.io/" wide
		$s4 = "https://db-ip.com/" wide
		$s5 = "https://www.maxmind.com/en/locate-my-ip-address" wide
		$s6 = "https://ipgeolocation.io/" wide
		$s7 = "POST" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Crown : FILE
{
	meta:
		description = "Detects Crown Tech Support Scam"
		author = "ditekSHen"
		id = "ac4551d0-a574-5287-9b37-899c736db792"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8191-L8211"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "eeb36993c93d76ed118643ee417f15e1768015f72464dbabca7ae001f64a0aef"
		score = 75
		quality = 75
		tags = "FILE"
		snort_sid = "920251-920261"

	strings:
		$d1 = "//prodownload.live" ascii
		$c1 = "&uid=" ascii
		$c2 = "&ver=" ascii
		$c3 = "&mcid=" ascii
		$c4 = ".php?uid=" ascii
		$c5 = ".php?ip=" ascii
		$s1 = "Operating System Support ID:" ascii
		$s2 = "taskkill /IM explorer.exe -f" ascii nocase
		$s3 = "/C taskkill /IM Taskmgr.exe -f" ascii nocase
		$s4 = "FastSuport" fullword ascii
		$s5 = "Support Override!" fullword wide
		$s6 = "Support Assistance Override Activated!" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $c* ) or 4 of ( $s* ) or ( 1 of ( $d* ) and ( 3 of ( $c* ) or 2 of ( $s* ) ) ) )
}

rule DITEKSHEN_MALWARE_Win_Floodfix : FILE
{
	meta:
		description = "Detects FloodFix"
		author = "ditekSHen"
		id = "b05b0b40-0de8-58a0-889e-44a12d346de4"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8213-L8219"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d7da820b00ef5ee2e943b012cfa57421a39f8a7bfc627cc1909151a47092a26d"
		score = 75
		quality = 75
		tags = "FILE"

	condition:
		uint16( 0 ) == 0x5a4d and pe.is_dll ( ) and ( pe.exports ( "FloodFix" ) or pe.exports ( "FloodFix2" ) ) and pe.exports ( "crc32" )
}
rule DITEKSHEN_MALWARE_Win_UNK_Infostealer : FILE
{
	meta:
		description = "Detects unknown information stealer"
		author = "ditekSHen"
		id = "f6f9816f-79bd-527c-9c0f-24e09c95ae35"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8221-L8246"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		hash = "b7a2cb34d3bc42d6d4c9d9af7dd406e2a5caef8ea46e5d09773feeb9920a6b21"
		hash = "dd95377842932d77e225b126749e1e6e8ecd6f5c6540d084a551a80a54d02d7d"
		hash = "12f790d9a0775b5e62effc6ea9e55bbef345fffbfb2f671f85098c4f7661dd0f"
		hash = "0a4cea763dffde451c75a434143fc5d014c32c6d1f8f34920ea5f2854e62118f"
		logic_hash = "ca57ebf4b56020d278ec8a7e721c72de7a1f925a8e7f1f3a9edc8a70b88ff9d1"
		score = 75
		quality = 75
		tags = "FILE"
		snort_sid = "920263"

	strings:
		$s1 = "%s\\%s\\%s-Qt" fullword wide
		$s2 = "%s\\%s.json" fullword wide
		$s3 = "*.mmd*" fullword wide
		$s4 = "%s\\%s.vdf" fullword wide
		$s5 = "%-50s %s" fullword wide
		$s6 = "dISCORD|lOCAL" fullword ascii nocase
		$s7 = "sTORAGE|LEVELDB" fullword ascii nocase
		$s8 = ".coin" fullword ascii
		$s9 = ".emc" fullword ascii
		$s10 = ".lib" fullword ascii
		$s11 = ".bazar" fullword ascii
		$s12 = "id=%d" fullword ascii
		$s13 = "2:?/v /v /v /^Y" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 8 of them
}
rule DITEKSHEN_MALWARE_Win_DECAF : FILE
{
	meta:
		description = "Detects DECAF ransomware"
		author = "ditekSHen"
		id = "c6e4ce00-0be9-572d-987c-c47d699002f0"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8248-L8268"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5d79a4f310fb00022eb9d636f161227e84a7e15517c4d2c39acafa7d81af5c2a"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "main.EncWorker" fullword ascii
		$s2 = "Paths2Encrypt" fullword ascii
		$s3 = "/cmd/encryptor/main.go" ascii
		$s4 = "*win.FileUtils; .autotmp_41 *lib.Encryptor; .autotmp_" ascii
		$s5 = "\"Microsoft Window" fullword wide
		$s6 = "Legal_Policy_Statement" fullword wide
		$s7 = ").Encrypt." ascii
		$s8 = "*struct { F uintptr; pw *os.File; c *" ascii
		$s9 = ".ListFilesToEnc." ascii
		$m1 = "WINNER WINNER CHICKEN DINNER" ascii
		$m2 = "All your servers and computers are encrypted" ascii
		$m3 = "We guarantee to decrypt one image file for free." ascii
		$m4 = "We WILL NOT be able to RESTORE them." ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 4 of ( $s* ) or 3 of ( $m* ) or ( 1 of ( $m* ) and 2 of ( $s* ) ) )
}

rule DITEKSHEN_MALWARE_Win_Windealer : FILE
{
	meta:
		description = "Detects WinDealer"
		author = "ditekSHen"
		id = "d4f3b0cc-121e-5032-9721-1e2a86842fa5"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8270-L8301"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "eabc41ea69f142ee7c243cbc75ceda909a722be382ad91a01c805aef637be915"
		score = 75
		quality = 73
		tags = "FILE"
		snort_sid = "920264"

	strings:
		$d1 = "downfile" fullword ascii
		$d2 = "getmypath" fullword ascii
		$d3 = "content-type: monitor" fullword ascii
		$d4 = "content-type: UsedType" fullword ascii
		$d5 = "write command error" fullword ascii
		$d6 = "C:\\WINDOWS\\system32\\kernel32.dll" fullword ascii
		$l1 = "currentconfig" fullword ascii
		$l2 = "remotedomain" fullword ascii
		$l3 = "reserveip" fullword ascii
		$l4 = "otherinfo" fullword ascii
		$l5 = "filelen" fullword ascii
		$l6 = "%s%s.bak" fullword wide
		$l7 = "localmachine" fullword ascii
		$l8 = "remoteip" fullword ascii
		$l9 = "datastate" fullword ascii
		$l10 = "SYSTEM\\CurrentControlSet\\Control\\Network\\{4D36E972-E325-11CE-BFC1-08002BE10318}\\%s\\Connection" fullword ascii
		$s1 = "%s\\%s\\V5_History.dat" fullword wide
		$s2 = "%s\\%s\\history2.dat" fullword wide
		$s3 = "%s\\%s\\history.imw" fullword wide
		$s4 = "%s\\%s\\main.imw" fullword wide
		$s5 = "%s%d.%d.%d.%dWindows/%u" fullword ascii
		$s6 = "%s\\%c_%s_tmp" fullword wide
		$s7 = "%s\\%s\\main.db" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 4 of ( $d* ) and 1 of ( $s* ) ) or ( 5 of ( $s* ) and 1 of ( $d* ) ) or 6 of ( $l* ) or ( pe.exports ( "DealC" ) and pe.exports ( "DealR" ) and pe.exports ( "DealS" ) and 1 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Exmatter : FILE
{
	meta:
		description = "Detects BlackMatter data exfiltration tool"
		author = "ditekSHen"
		id = "93df7a68-1e19-5db3-95d4-39d77d1036d8"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8303-L8325"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		hash = "4a0e10e1e9fea0906379f99fa350b91c2af37f0fd2cc55491643cc71a9887d30"
		hash = "a5e050f1278473d41c3a3d6f98f3fd82932f51a937bc57d8f5605815f0efb0f8"
		logic_hash = "25a35c82919f96bdba00558616f574e901b83785713ed1a63a6f06df576777cd"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Renci.SshNet." ascii
		$s2 = "DirNotEmpty" fullword ascii
		$s3 = "MkDir" fullword ascii
		$s4 = "RmDir" fullword ascii
		$s5 = "get_MainWindowHandle" fullword ascii
		$s6 = "GetCurrentProcess" fullword ascii
		$s7 = "]]>]]>" fullword wide
		$s8 = "1.3.132.0.35" fullword wide
		$s9 = "1.3.132.0.34" fullword wide
		$s10 = "1.2.840.10045.3.1.7" fullword wide
		$x1 = "sender2.pdb" fullword ascii
		$x2 = { 64 00 61 00 74 00 61 00 ?? 72 00 6f 00 6f 00 74 }
		$x3 = "157.230.28.192" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or ( 1 of ( $x* ) and 7 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Brbbot : FILE
{
	meta:
		description = "Detects BrbBot"
		author = "ditekSHen"
		id = "d77dfdcf-4cd5-578e-99eb-c987e7b5b706"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8327-L8345"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "64df5bba698fbba1baf27eedb9a2eb46c5e0752996ea91900f8377200d54eeeb"
		score = 75
		quality = 75
		tags = "FILE"
		snort_sid = "920265"

	strings:
		$x1 = "brbconfig.tmp" fullword ascii
		$x2 = "brbbot" fullword ascii
		$s1 = "%s?i=%s&c=%s&p=%s" fullword ascii
		$s2 = "exec" fullword ascii
		$s3 = "CONFIG" fullword ascii wide
		$s4 = "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0)" fullword ascii
		$s5 = { 43 4f 4e 46 49 47 00 00 65 6e 63 6f 64 65 00 00
                73 6c 65 65 70 00 00 00 65 78 69 74 00 00 00 00
                63 6f 6e 66 00 00 00 00 66 69 6c 65 00 00 00 00
                65 78 65 63 }

	condition:
		uint16( 0 ) == 0x5a4d and ( ( all of ( $x* ) and 1 of ( $s* ) ) or ( 1 of ( $x* ) and 4 of ( $s* ) ) or all of ( $s* ) )
}

rule DITEKSHEN_MALWARE_Win_Gobrutloader : FILE
{
	meta:
		description = "Detects GoBrut StealthWorker laoder"
		author = "ditekSHen"
		id = "748f8055-71d9-5757-8eb0-90dc3ee35c74"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8388-L8394"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "6241117cffb147763ace41b36cd1524f48bfc7cb06d56a82d7b30bec9e1baf5b"
		score = 75
		quality = 75
		tags = "FILE"

	condition:
		uint16( 0 ) == 0x5a4d and pe.exports ( "@SetFirstEverVice@8" )
}
rule DITEKSHEN_MALWARE_Win_UNK05 : FILE
{
	meta:
		description = "Detects potential BazarLoader"
		author = "ditekSHen"
		id = "12f66315-f381-5910-b1d4-2cbf21c889a4"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8469-L8486"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b3074f237fbaf449a53dcc219f48509db6af4c0d0859e6590563c3412be30aa8"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "/api/get" ascii wide
		$s2 = "PARENTCMDLINE" fullword ascii
		$s3 = "https://microsoft.com/telemetry/update.exe" ascii wide
		$s4 = "api.opennicproject.org" fullword ascii wide
		$s5 = "https://%hu.%hu.%hu.%hu:%u" fullword ascii wide
		$s6 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36 Edg/94.0.992.31" ascii wide
		$s7 = "PARENTJOBID" fullword ascii wide
		$s8 = "\\System32\\rundll32.exe" fullword ascii wide
		$s9 = "{ccc38b40-5b04-4fb1-a684-07c7e448d4df}" fullword ascii wide
		$s10 = "{065f6686-990b-46fc-829c-a53ec188a723}" fullword ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Clipbanker01 : FILE
{
	meta:
		description = "Detects ClipBanker infostealer"
		author = "ditekSHen"
		id = "b56514f4-8362-5698-8142-be836b70a11a"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8488-L8521"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "8ef90e22299a1009468761a4cdb8e2a92920d721f1a7ebceeb81a07e14f9156f"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "Clipper" fullword wide
		$s2 = "Ushell" fullword wide
		$s3 = "Banker" fullword wide
		$s4 = "ClipPurse" fullword wide nocase
		$s5 = "SelfClip" fullword wide
		$s6 = "Cliper" fullword wide
		$s7 = "FHQD4313-33DE-489D-9721-6AFF69841DEA" fullword wide
		$s8 = "Remove.bat" fullword wide
		$s9 = "\\w{1}\\d{12}" fullword wide
		$s10 = "SELECT * FROM Win32_ComputerSystem" fullword wide
		$s11 = "red hat" fullword wide
		$s12 = { 73 00 63 00 68 00 74 00 61 00 73 00 6b 00 73 00
                 2e 00 65 00 78 00 65 00 00 ?? 2f 00 63 00 72 00
                 65 00 61 00 74 00 65 00 20 00 2f 00 73 00 63 00
                 20 00 00 ?? 20 00 2f 00 6d 00 6f 00 20 00 00 ??
                 20 00 2f 00 72 00 6c 00 20 00 00 ?? 20 00 2f 00
                 74 00 6e 00 20 00 00 ?? 20 00 2f 00 74 00 72 00
                 20 00 00 ?? 20 00 ?? 00 ?? 00 00 ?? 2f 00 64 00
                 65 00 6c 00 65 00 74 00 65 00 20 00 2f 00 74 00
                 6e }
		$s13 = "ClipChanger" fullword ascii
		$s14 = "CheckVirtual" fullword ascii
		$s15 = "InjReg" fullword ascii
		$s16 = "SuicideFile" fullword ascii
		$s17 = "HideFile" fullword ascii
		$s18 = "AntiVm" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 7 of them
}
rule DITEKSHEN_MALWARE_Win_Zombieboy : FILE
{
	meta:
		description = "Detects ZombieBoy Downloader"
		author = "ditekSHen"
		id = "c1345196-1686-534c-ab4c-557113c83411"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8523-L8532"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0840367c1b56c4c266f22400df95411ba7784b98919a922380e1ec789783bb65"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = ":\\Users\\ZombieBoy\\" ascii wide
		$s2 = "RookIE/1.0" fullword ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Pcrat : FILE
{
	meta:
		description = "Detects PCRat / Gh0st"
		author = "ditekSHen"
		id = "de5b3e08-16da-56e2-a0a4-d8bed5840804"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8534-L8561"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ad56d7d6a2bb6d09bc4530c31b51456b6bbca5def1810449fd2a31973cce18f8"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "ClearEventLogA" fullword ascii
		$s2 = "NetUserAdd" fullword ascii
		$s3 = "<H1>403 Forbidden</H1>" fullword ascii
		$s4 = ":]%d-%d-%d  %d:%d:%d" fullword ascii
		$s5 = "Mozilla/4.0 (compatible)" fullword ascii
		$s6 = "<Enter>" fullword ascii
		$s7 = "\\cmd.exe" fullword ascii
		$s8 = "Program Files\\Internet Explorer\\IEXPLORE.EXE" fullword ascii
		$s9 = "Collegesoft ScenicPlayer" fullword wide
		$a1 = "360tray.exe" fullword ascii
		$a2 = "avp.exe" fullword ascii
		$a3 = "RavMonD.exe" fullword ascii
		$a4 = "360sd.exe" fullword ascii
		$a5 = "Mcshield.exe" fullword ascii
		$a6 = "egui.exe" fullword ascii
		$a7 = "kxetray.exe" fullword ascii
		$a8 = "knsdtray.exe" fullword ascii
		$a9 = "TMBMSRV.exe" fullword ascii
		$a10 = "avcenter.exe" fullword ascii
		$a11 = "ashDisp.exe" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of ( $s* ) and 6 of ( $a* )
}
rule DITEKSHEN_MALWARE_Win_Rapid : FILE
{
	meta:
		description = "Detects Rapid ransomware"
		author = "ditekSHen"
		id = "3a23f344-8345-5ae8-aacb-f2f422d3fc9d"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8563-L8585"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c3f1bffeb402951da8bcccc899b2cdeb3c218b342d8338c750b9ff275537b4b5"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "encblklen" fullword ascii
		$s2 = ".rapid" fullword ascii
		$s3 = "BgIAAACkAABSU0E" ascii
		$s4 = "IFdlIHNlbmQ" ascii
		$s5 = "Software\\EncryptKeys" fullword ascii
		$s6 = "local_enc_private_key" fullword ascii
		$s7 = "local_public_key" fullword ascii
		$s8 = "How Recovery Files.txt" ascii
		$s9 = "recovery.txt" ascii
		$s10 = "thr %i run %s" fullword ascii
		$s11 = " /TN Encrypter" ascii
		$s12 = /Encrypter_\d+/ fullword ascii
		$s13 = "BleepingComputer_rapid" ascii wide
		$m1 = "tell us your unique ID - ID-" ascii
		$m2 = "really want to restore your files?" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 6 of ( $s* ) or ( 1 of ( $m* ) and 4 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Satana : FILE
{
	meta:
		description = "Detects Satana ransomware"
		author = "ditekSHen"
		id = "f3cb7cc4-3c63-50b2-8e19-d675abbb33f8"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8587-L8604"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b2946e8c37be4a57237999aaa0c0a760a181306320162e04bc6fc12a542b81d5"
		score = 75
		quality = 73
		tags = "FILE"
		snort_sid = "920269-920270"

	strings:
		$bf1 = "Try Decrypt: uc_size = %d, c_size = %d" ascii
		$bf2 = "dwMailSelector = %d  dwBtcSelector = %d" ascii
		$bf3 = "%s: Error DecB: 0x%X" ascii
		$bf4 = "MBR written to Disk# %d" ascii
		$bf5 = "!SATANA!" ascii wide nocase
		$bf6 = "1 -th start" fullword ascii
		$bf7 = "id=%d&code=%d&sdata=%d.%d.%d %d %d %s %s %d&name=%s&md5=%s&dlen=%s" ascii
		$bf8 = "threadAdminFlood: %s %s %s" wide
		$bf9 = "%s: NET RES FOUND: %s" wide

	condition:
		( uint16( 0 ) == 0x5a4d and 4 of ( $bf* ) ) or ( 5 of ( $bf* ) )
}
rule DITEKSHEN_MALWARE_Win_Virlock : FILE
{
	meta:
		description = "Detects VirLock ransomware"
		author = "ditekSHen"
		id = "dbf46963-3e74-54a0-8f7d-b24436c3ea2c"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8606-L8624"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "8d516a0d771d7134c0f917f010b3973ed53b4ee7e4a2cf0bb5daecf9867b0081"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "BThere are two ways to pay a fine:" fullword wide
		$x2 = "^Es gibt zwei M" fullword wide
		$x3 = "glichkeiten, eine Strafe zahlen." fullword wide
		$x4 = /usertile\d+\.bmp/ fullword wide
		$s1 = "WinSock 2.0" fullword ascii
		$s2 = "Running" fullword ascii
		$s3 = "echo WScript.Sleep(50)>%TEMP%/file.vbs" fullword ascii
		$s4 = "cscript %TEMP%/file.vbs" fullword ascii
		$s5 = "del /F /Q file.js" fullword ascii
		$s6 = "del /F /Q %1" fullword ascii
		$s7 = "del /F /Q %0" fullword ascii

	condition:
		( uint16( 0 ) == 0x5a4d and ( ( 2 of ( $x* ) and 2 of ( $s* ) ) or ( 5 of ( $s* ) and 1 of ( $x* ) ) ) ) or ( 8 of them )
}
rule DITEKSHEN_MALWARE_Win_Nglite : FILE
{
	meta:
		description = "Detects NGLite"
		author = "ditekSHen"
		id = "b014ed4f-57b1-597e-befc-6e7f80855201"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8646-L8668"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d83663908949f69018461c73cf7137cf4ab16cc057cfe47942e6de0415ab5447"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "/lprey/main.go" ascii
		$x2 = "/NGLiteV1.01/lprey/" ascii
		$x3 = "/ng.com/lprey/" ascii
		$x4 = "/mnt/hgfs/CrossC2-2.2/src/" ascii
		$x5 = "WHATswrongwithUu" ascii
		$s1 = "main.Preylistener" fullword ascii
		$s2 = "main.Runcommand" fullword ascii
		$s3 = "main.RandomPass" fullword ascii
		$s4 = "main.AesEncode" fullword ascii
		$s5 = "main.RsaEncode" fullword ascii
		$s6 = "main.AesDecode" fullword ascii
		$s7 = "main.initonce" fullword ascii
		$s8 = "main.SendOnce" fullword ascii
		$s9 = "main.clientConf" fullword ascii
		$s10 = "main.Sender" fullword ascii

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0x457f or uint16( 0 ) == 0xfacf ) and ( ( 1 of ( $x* ) and 2 of ( $s* ) ) or ( 6 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Chinotto : FILE
{
	meta:
		description = "Detects Chinotto"
		author = "ditekSHen"
		id = "e66703d4-c9c6-5bb4-9e07-11dc89b0a034"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8702-L8754"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "92f37bdc4cf17e07bb556c60e3bde4547c34f67a2fb5c806000d9cb2446adff1"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$x1 = "xxxchinotto" ascii wide
		$x2 = "\\Chinotto.pdb" ascii wide
		$x3 = { 50 4f 53 54 20 25 73 20 48 54 54 50 2f 31 2e 31
                0d 0a 41 63 63 65 70 74 2d 45 6e 63 6f 64 69 6e
                67 3a 20 67 7a 69 70 2c 20 64 65 66 6c 61 74 65
                0d 0a 55 73 65 72 2d 41 67 65 6e 74 3a 20 4d 6f
                7a 69 6c 6c 61 2f 34 2e 30 28 63 6f 6d 70 61 74
                69 62 6c 65 3b 20 4d 53 49 45 20 36 2e 30 3b 20
                57 69 6e 64 6f 77 73 20 4e 54 20 35 2e 31 3b 20
                53 56 31 29 0d 0a 41 63 63 65 70 74 3a 20 69 6d
                61 67 65 2f 67 69 66 2c 20 69 6d 61 67 65 2f 78
                2d 78 62 69 74 6d 61 70 2c 20 69 6d 61 67 65 2f
                6a 70 65 67 2c 20 69 6d 61 67 65 2f 70 6a 70 65
                67 2c 20 61 70 70 6c 69 63 61 74 69 6f 6e 2f 78
                2d 73 68 6f 63 6b 77 61 76 65 2d 66 6c 61 73 68
                2c 20 2a 0d 0a 41 63 63 65 70 74 2d 4c 61 6e 67
                75 61 67 65 3a 20 65 6e 2d 75 73 0d 0a 43 6f 6e
                74 65 6e 74 2d 54 79 70 65 3a 20 6d 75 6c 74 69
                70 61 72 74 2f 66 6f 72 6d 2d 64 61 74 61 3b 62
                6f 75 6e 64 61 72 79 3d 25 73 0d 0a 48 6f 73 74
                3a 20 25 73 3a 25 64 0d 0a 43 6f 6e 74 65 6e 74
                2d 4c 65 6e 67 74 68 3a 20 25 64 0d 0a 43 6f 6e
                6e 65 63 74 69 6f 6e 3a 20 4b 65 65 70 2d 41 6c
                69 76 65 0d 0a 43 61 63 68 65 2d 43 6f 6e 74 72
                6f 6c 3a 20 6e 6f 2d 63 61 63 68 65 0d 0a 0d 0a
                00 00 00 00 48 54 54 50 2f 31 2e 31 20 32 30 30
                20 4f 4b 00 0d 0a 0d 0a 00 00 00 00 65 72 72 6f
                72 3c 2f 62 3e }
		$s1 = "Run /v xxxzexs /t REG_SZ /d %s /f" ascii wide
		$s2 = "ShellExecute Error, ret" ascii wide
		$s3 = "Run app succeed" ascii
		$s4 = "cleartemp:" fullword ascii
		$s5 = "wakeup:" fullword ascii
		$s6 = "updir:" fullword ascii
		$s7 = "regstart:" fullword ascii
		$s8 = "chdec:" fullword ascii
		$s9 = "cmd:" fullword ascii
		$s10 = "error</b>" fullword ascii
		$c1 = "Host: %s:%d" ascii wide
		$c2 = "Mozilla/4.0(compatible; MSIE 6.0; Windows NT 5.1; SV1)" ascii wide
		$c3 = "Mozilla/5.0(Windows NT 10.0; Win64; x64)AppleWebKit/537.36(KHTML, like Gecko)Chrome/78.0.3904.108 Safari/537.36" ascii wide
		$c4 = "id=%s&type=hello&direction=send" ascii wide
		$c5 = "id=%s&type=command&direction=receive" ascii wide
		$c6 = "id=%s&type=file&direction=" ascii wide
		$c7 = "id=%s&type=result&direction=" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $x* ) or ( 1 of ( $x* ) and ( 2 of ( $s* ) or 2 of ( $c* ) ) ) or 4 of ( $c* ) or 5 of ( $s* ) )
}

rule DITEKSHEN_MALWARE_Win_Tardigrade : FILE
{
	meta:
		description = "Detects Tardigrade"
		author = "ditekSHen"
		id = "a46caaaa-2954-552a-a20f-952c47370393"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8756-L8787"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		hash = "c0976a1fbc3dd938f1d2996a888d0b3a516b432a2c38d788831553d81e2f5858"
		hash = "966b2c7c72a28310acd58bb23af4d3c893b2afca264b2d9c0ec42db815c77487"
		hash = "88be5da274df704dc7fd9882c661a0afdd35f1ce0a7145e30f51c292abd2a86b"
		hash = "cf88926b7d5a5ebbd563d0241aaf83718b77cec56da66bdf234295cc5a91c5fe"
		hash = "4afd9f0dde092daeac3f3e6ffb0aee06682b3dba6005d2bd1a914eefd5cc6a30"
		logic_hash = "2bd4f23f66844a320b6bed6242ba39096f66a08affb84abd78c342d433ed9fe6"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "cmd.exe /c echo kOJAdtQoDcMuogIZIl>\"%s\"&exit" fullword ascii
		$x2 = "cmd.exe /c echo HBnBcZPeUevCDQmKGzXxYJHqpzRAbRCQCihOxiLi>\"%s\"&exit" fullword ascii
		$x3 = "cmd.exe /c set kpUUCjoLWLZvJFc=3167 & reg add HKCU\\SOFTWARE\\EQwIobTRgsJ /v PDMXPmqSYnUx /t REG_DWORD /d 10080 & exit" fullword ascii
		$s1 = "ReplaceFileA" ascii
		$s2 = "FlushFileBuffers" ascii
		$s3 = "WaitNamedPipeA" ascii
		$s4 = "ImpersonateNamedPipeClient" ascii
		$s5 = "RegFlushKey" ascii
		$s6 = /cmd\.exe \/c (echo|set)/ ascii
		$s7 = ">\"%s\"&exit" ascii

	condition:
		uint16( 0 ) == 0x5a4d and pe.is_dll ( ) and ( 1 of ( $x* ) or 6 of ( $s* ) ) and ( pe.exports ( "DllGetClassObject" ) and pe.exports ( "DllMain" ) and pe.exports ( "DllRegisterServer" ) and pe.exports ( "DllUnregisterServer" ) and pe.exports ( "InitHelperDll" ) and pe.exports ( "StartW" ) )
}
rule DITEKSHEN_MALWARE_Win_Clipbanker02 : FILE
{
	meta:
		description = "Detects ClipBanker infostealer"
		author = "ditekSHen"
		id = "c2a480cf-e81b-53a2-999a-80209050e0cf"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8789-L8814"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "51a43245b1e0b6fea874302b73bf552012c54c3f7c12b8c447c96c2ffdcc1dcb"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "\\Allcome\\Source code\\Clipper\\" ascii nocase
		$x2 = "\\cleaper\\Release\\cleaper.pdb" ascii nocase
		$v1_1 = "&username=" fullword ascii
		$v1_2 = "/card.php?data=" fullword ascii
		$v1_3 = "/Create /tn MicrosoftDriver /sc MINUTE /tr" fullword ascii
		$v1_4 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:93.0) Gecko/20100101 Firefox/93.0" fullword ascii
		$v1_5 = "/API/Clipper/ykesqk0o.php?cf6zrlhn=" fullword ascii
		$v1_6 = "&di7ztth6=" fullword ascii
		$v1_7 = "/API/Clipper/hr627gzk.php?v6etwxo5=" fullword ascii
		$v2_1 = "bitcoincash:" fullword ascii
		$v2_2 = "\\Microsoft\\Windows\\Start Menu\\Programs\\Startup" ascii
		$re1 = "^[0-9]{16}$" fullword ascii
		$re2 = "^[0-9]{4}\\s[0-9]{4}\\s[0-9]{4}\\s[0-9]{4}" fullword ascii
		$re3 = "^\\d{2}\\D\\d{2}" fullword ascii
		$re4 = "^[0-9]{3}" fullword ascii
		$re5 = "([\\W]?[0-9]{4}[\\W]?[0-9]{4}[\\W]?[0-9]{4}[\\W]?[0-9]{4}[\\W]?)" fullword ascii
		$re6 = "(\\d{2}\\D\\d{2})" fullword ascii
		$re7 = "(\\d{3})" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) and ( 5 of ( $v1* ) or all of ( $v2* ) ) ) or ( 3 of ( $re* ) and ( 2 of ( $v1* ) or 2 of ( $v2* ) ) ) )
}
rule DITEKSHEN_MALWARE_Win_Badjoke : FILE
{
	meta:
		description = "Detects BadJoke / Witch"
		author = "ditekSHen"
		id = "082727d5-618f-542d-93ca-ba93be16cd80"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8816-L8831"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4699a772bcd50d2fe43740df59a4c56598ba43ebcc18acbf8ec401b6f5a01fe6"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "msdownld.tmp" fullword ascii
		$s2 = "UPDFILE%lu" fullword ascii
		$s3 = "Command.com /c %s" fullword ascii
		$s4 = "launch.cmd" fullword ascii
		$s5 = "virus.vbs" fullword ascii
		$s6 = "virus.py" fullword ascii
		$m1 = "Message from Google Virus" ascii
		$m2 = "you cannot get rid of this virus" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $m* ) or all of ( $s* ) or ( 1 of ( $m* ) and 2 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Heracles : FILE
{
	meta:
		description = "Detects Heracles infostealer"
		author = "ditekSHen"
		id = "36cb9366-c70b-5117-955f-402f87f3a88c"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8833-L8861"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "1d5c80c084f9d6e4692a18f74574179095ecdd5eaadd70b5d16c19702761d74f"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$x1 = "aHR0cHM6Ly9uYWNrZXIudG9hbnNlY3UuY29tL3VwbG9hZHM/a2V5PX" wide
		$b1 = "XEdvb2dsZVxDaHJvbWVc" wide
		$b2 = "XEJyYXZlU29mdHdhcmVcQnJhdmUtQnJvd3Nlcl" wide
		$b3 = "XENvY0NvY1xCcm93c2VyX" wide
		$b4 = "VXNlciBEYXRh" wide
		$b5 = "RGVmYXVsdA" wide
		$b6 = "UHJvZmlsZQ" wide
		$b7 = "Q29va2llcw" wide
		$b8 = "TG9naW4gRGF0YQ" wide
		$b9 = "TG9jYWwgU3RhdGU" wide
		$b10 = "bG9jYWxzdGF0ZQ" wide
		$b11 = "bG9naW5kYXRh" wide
		$s1 = "encrypted_key" fullword wide
		$s2 = "<GetIpInfoAsync>d__" ascii
		$s3 = "<reqHTML>5__" ascii
		$s4 = "<idHardware>5__" ascii
		$s5 = "<profilePaths>5__" ascii
		$s6 = "<cookieFile>5__" ascii
		$s7 = "<loginDataFile>5__" ascii
		$s8 = "<localStateFile>5__" ascii
		$s9 = "<postData>5__" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $x* ) or 8 of ( $s* ) or ( 4 of ( $b* ) and 4 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Blackbytego : FILE
{
	meta:
		description = "Detects BlackByte ransomware Go variants"
		author = "ditekSHen"
		id = "25431446-8cce-54cc-925d-5d9147344c6d"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8884-L8904"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b3e6a4a2f043293e8693cfbe1515681ce0616d98e2492732fc06a01a96309883"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "BlackByteGO/_cgo_gotypes.go" fullword ascii
		$x3 = "BlackByteGO/" ascii nocase
		$s1 = ".Disconnect" ascii
		$s2 = ".OpenService" ascii
		$s3 = ".ListServices" ascii
		$s4 = ".Start" ascii
		$s5 = ".Encrypt" ascii
		$s6 = ".Decrypt" ascii
		$s7 = ".MustFindProc" ascii
		$s8 = ".QuoRem" ascii
		$s9 = "C:\\Windows\\regedit.exe" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $x* ) or all of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Vulturi : FILE
{
	meta:
		description = "Detects Vulturi infostealer"
		author = "ditekSHen"
		id = "dca814d6-ca26-5315-9f80-628ee50e8dfa"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8906-L8931"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4d1d88764dd72ae78a74b802e11c2f28899b7b9f45c54cf3bf7aaac49dd48d7f"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "Vulturi_" ascii wide
		$x2 = "VulturiProject" fullword ascii
		$s1 = { 5b 00 2d 00 5d 00 20 00 53 00 65 00 72 00 76 00
               65 00 72 00 20 00 ?? ?? 20 00 69 00 73 00 20 00
               6f 00 66 00 66 00 6c 00 69 00 6e 00 65 00 2e 00
               2e 00 2e 00 00 ?? 5b 00 2b 00 5d 00 20 00 53 00
               65 00 72 00 76 00 65 00 72 00 20 00 00 ?? ?? 00
               69 00 73 00 20 00 6f 00 6e 00 6c 00 69 00 6e 00
               65 00 }
		$s2 = "Writing is not alowed" wide
		$s3 = "System\\ProcessList.txt" fullword wide
		$s4 = "[X] GetSSL ::" fullword wide
		$s5 = "Failed to steal " wide
		$s6 = "StealerStub" fullword ascii
		$s7 = "/C chcp 65001 && netsh" wide
		$n1 = "fetch_options" fullword wide
		$n2 = "send_report" fullword wide
		$n3 = "?username=" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) and any of them ) or all of ( $n* ) or 5 of ( $s* ) or ( 1 of ( $n* ) and 3 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Tofsee : FILE
{
	meta:
		description = "Detects Tofsee"
		author = "ditekSHen"
		id = "86371c0b-72f9-56c0-9f34-f14d2a069c91"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8933-L8949"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9ef06643173c70c5b06b19200cb5b5efa7db7eb3516b67621f0b1975f1c80781"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "n%systemroot%\\system32\\cmd.exe" fullword wide
		$s2 = "loader_id" fullword ascii
		$s3 = "start_srv" fullword ascii
		$s4 = "lid_file_upd" fullword ascii
		$s5 = "localcfg" fullword ascii
		$s6 = "Incorrect respons" fullword ascii
		$s7 = "mx connect error" fullword ascii
		$s8 = "Error sending command (sent = %d/%d)" fullword ascii
		$s9 = "%s, %u %s %u %.2u:%.2u:%.2u %s%.2u%.2u" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Khonsari : FILE
{
	meta:
		description = "Detects Khonsari ransomware"
		author = "ditekSHen"
		id = "2d562e62-a948-570d-8ff2-cc4835b91573"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8951-L8963"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "2a78f36259481fccb31b2e6248fed19699b6eb05bacfd08905414764c3045943"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$x1 = ".khonsari" fullword wide nocase
		$s1 = "Encrypt" fullword ascii
		$s2 = "CreateEncryptor" fullword ascii
		$s3 = "GenerateKey" fullword ascii
		$s4 = "277e5e6a-4da6-4138-97fa-3fecbdad0176" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) and 2 of ( $s* ) ) or ( all of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Owowa : FILE
{
	meta:
		description = "Detects Owowa"
		author = "ditekSHen"
		id = "c0a61601-e810-5acc-91a3-fa70db6d94da"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L8989-L9007"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "afdeb30845ed4ef7b79e733e05d3e1ee53a8c441db74519577893d75c1249a41"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$u1 = "jFuLIXpzRdateYHoVwMlfc" fullword ascii wide
		$u2 = "Fb8v91c6tHiKsWzrulCeqO" fullword ascii wide
		$u3 = "dEUM3jZXaDiob8BrqSy2PQO1" fullword ascii wide
		$s1 = "powershell.exe" fullword wide
		$s2 = "<RSAKeyValue><Modulus>" wide
		$s3 = "HealthMailbox" fullword wide
		$s4 = "6801b573-4cdb-4307-8d4a-3d1e2842f09f" ascii
		$s5 = "<PreSend_RequestContent>b__" ascii
		$s6 = "ClearHeaders" fullword ascii
		$s7 = "get_UserHostAddress" fullword ascii
		$s8 = "ExtenderControlDesigner" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $u* ) or ( 2 of ( $u* ) and 3 of ( $s* ) ) or 6 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Chebka : FILE
{
	meta:
		description = "Detects Chebka"
		author = "ditekSHen"
		id = "df486522-695c-56f5-b93a-6f16829a3a3e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9009-L9030"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "cc8123a5d20fac51d4dfc225e743539456efb4d649060d078c3ed93e7724da01"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "-k netsvcs" wide
		$s2 = "%ssvchost.exe -k SystemNetworkService" wide
		$s3 = "Mozilla/4.0 (compatible)" wide
		$s4 = "_kasssperskdy" wide
		$s5 = "winssyslog" wide
		$s6 = "LoaderDll%d" wide
		$s7 = "cmd.exe /c rundll32.exe shell32.dll," wide
		$s8 = /cmd.exe \/c start (chrome|msedge|firefox|iexplorer)\.exe/ wide
		$f1 = ".?AVCHVncManager@@" fullword ascii
		$f2 = ".?AVCNetstatManager@@" fullword ascii
		$f3 = ".?AVCTcpAgentListener@@" fullword ascii
		$f4 = ".?AVIUdpClientListener@@" fullword ascii
		$f5 = ".?AVCShellManager@@" fullword ascii
		$f6 = ".?AVCScreenSpy@@" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 5 of ( $s* ) or all of ( $f* ) or ( 3 of ( $f* ) and 3 of ( $s* ) ) or ( #s8 > 2 and 5 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Flagpro : FILE
{
	meta:
		description = "Detects Flagpro"
		author = "ditekSHen"
		id = "da1bf899-feb5-5ed0-956e-c20bc3565a6e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9032-L9049"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c5e5944426b7be690ad62dd0d98a8fc6f8135cab0dbdd8a5aaf1670491eda59d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "download...." fullword ascii
		$s2 = "~MYTEMP" fullword wide
		$s3 = ".?AVCV20_LoaderApp@@" fullword ascii
		$s4 = ".?AVCV20_LoaderDlg@@" fullword ascii
		$s5 = "ExecYes" fullword ascii
		$s6 = /<BODY ID=CV\d+_LoaderDlg BGCOLOR=/ ascii
		$n1 = "://139.162.87.180" wide
		$n2 = "://172.104.109.217" wide
		$n3 = "://org.misecure.com/index.html" wide
		$b1 = /(get all|click|close|maybe|get_outerHTML|download\d) (finished|pass|ok|windows|failed)!/ fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of ( $s* ) or ( 1 of ( $n* ) and ( 2 of ( $s* ) or 1 of ( $b* ) ) ) or ( 2 of ( $s* ) and 1 of ( $b* ) )
}
rule DITEKSHEN_MALWARE_Win_Nplusminer
{
	meta:
		description = "Detects PowerShell based NPlusMiner"
		author = "ditekSHen"
		id = "a16b504f-e69a-5abb-8e37-01bf7c2df6ef"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9051-L9064"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f6b81c2276765455d46e20ed81e19caa3ae36a31827568486a09bc1619ec478c"
		score = 75
		quality = 75
		tags = ""
		snort_sid = "920284"

	strings:
		$s1 = "$Core | Add-Member @{IsReadOnly = $((Get-ItemProperty -Path \".\\Includes\\Core.ps1\").IsReadOnly)} -Force" fullword ascii
		$s2 = "$Core | Add-Member @{MinerCustomConfig = $((Get-Content \".\\Config\\MinerCustomConfig.json\" -Raw))} -Force" fullword ascii
		$s3 = "If ($Variables.CheatGuy -and $Core.corehash -in $Hashes -and $Core.ScriptStartDate -le (Get-Date)" ascii
		$s4 = "Try{(Get-ItemProperty -Path \".\\Includes\\Core.ps1\").IsReadOnly = $false} catch {}" fullword ascii
		$s5 = " NPlusMiner/" ascii

	condition:
		3 of them
}
rule DITEKSHEN_MALWARE_Win_PWSH_Poshcookiestealer
{
	meta:
		description = "Detects PowerShell PoshCookieStealer"
		author = "ditekSHen"
		id = "7326a056-288b-534b-811d-172bd6936d7b"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9066-L9080"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "234958098d09732675dd539e8d25c6754ba50bf92b3a19e7fef8c68d70503ec4"
		score = 75
		quality = 75
		tags = ""

	strings:
		$s1 = "\\User Data\\default\\Network\\Cookies" ascii nocase
		$s2 = "Send-ToEmail" ascii
		$s3 = "[Security.Cryptography.ProtectedData]::Unprotect($" ascii
		$s4 = "$($env:LOCALAPPDATA)\\" ascii
		$s5 = "$($env:HOMEPATH)\\" ascii
		$s6 = "|ForEach-Object ToString X2) -join ''" ascii
		$s7 = ".Attachments.Add($" ascii

	condition:
		5 of them
}
rule DITEKSHEN_MALWARE_Win_Garrantdecrypt : FILE
{
	meta:
		description = "Detects GarrantDecrypt ransomware"
		author = "ditekSHen"
		id = "e3be3663-9978-5b8e-b6b2-0f44f269adb2"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9082-L9096"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "84b139e51f0ef0389c641d62409d702b0ae7ec6ecd2fa54baf2cf0c0078a8f5a"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "%appdata%\\_uninstalling_.png" fullword wide
		$x2 = "C:\\Windows\\sysnative\\vssadmin.exe" fullword wide
		$x3 = /(ICQ|Skype) (@nuncatarde|@supersuso|@Whitehorsedecryption|@likeahorse|@Konwarszawski|@zipzipulya|Whitehorsedecryption|LIKEAHORSE DECRYPTION|Zip Zipulya)/ ascii
		$s1 = "your unique ID" ascii
		$s2 = "Google market ICQ" ascii
		$s3 = "If you want to restore them, install ICQ" ascii
		$s4 = "Write to our ICQ @" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 2 of ( $x* ) and 1 of ( $s* ) ) or all of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Locked : FILE
{
	meta:
		description = "Detects Locked ransomware"
		author = "ditekSHen"
		id = "ad2f91ab-9bbb-5d47-a5c3-5a38dbab2ebe"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9098-L9114"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b838b996946fb268c66bac68d5e326ff3049340dfb08f2e0a77492df49915d5a"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$x1 = "http://xxxx.onion/xxxx-xxxx-xxxx-xxxx" ascii
		$x2 = "http://pigetrzlperjreyr3fbytm27bljaq4eungv3gdq2tohnoyfrqu4bx5qd.onion" ascii
		$x3 = "dHA6Ly94eHh4Lm9uaW9uL3h4eHgteHh4eC14eHh4LXh4eHg" ascii
		$s1 = "choice /t 1 /d y /n >nul" ascii
		$s2 = ".locked" fullword ascii
		$s3 = "c:\\system volume information" fullword ascii
		$s4 = "__$$RECOVERY_README$$__.html" fullword ascii
		$s5 = "Trunc..." fullword ascii
		$s6 = /C:\\windows\\temp\\[a-z0-9A-Z]{6}\.tmp/ fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) or all of ( $s* ) or ( 1 of ( $x* ) and 4 of ( $s* ) ) or ( #s6 > 1 and 4 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Maze : FILE
{
	meta:
		description = "Detects Maze ransomware"
		author = "ditekSHen"
		id = "f5d1d3e2-1ffe-5ec6-b1ee-bded81867fb8"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9116-L9145"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d3ce3b43c65dfd9f59ba3c6b64e8d7687db175673cc62068caa1e1da023390c0"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "Uc32nbspacec97c98c99c100c101c102c103c104c105c106c107c108c109c110c" ascii
		$s1 = "\"%s\" shadowcopy delete" wide
		$s2 = "[%windir%\\system32\\wbem\\wmic" wide
		$s3 = "process call create \"cmd /c start %s\"" wide
		$s4 = "DECRYPT-FILES.html" fullword wide
		$s5 = "Dear %s, your files" wide
		$s6 = "%s! Alert! %s! Alert!" wide
		$s7 = "%BASE64_PLACEHOLDER%" fullword ascii
		$s8 = "-orDGorX0or" fullword ascii
		$s9 = { 47 45 54 20 2f 25 73 20 48 54 54 50 2f 31 2e 31
               0d 0a 55 73 65 72 2d 41 67 65 6e 74 3a 20 25 73
               0d 0a 48 6f 73 74 3a 20 25 73 0d 0a 43 6f 6e 6e
               65 63 74 69 6f 6e 3a 20 4b 65 65 70 2d 41 6c 69
               76 65 0d 0a 0d 0a 00 50 4f 53 54 20 2f 25 73 20
               48 54 54 50 2f 31 2e 31 0d 0a 55 73 65 72 2d 41
               67 65 6e 74 3a 20 25 73 0d 0a 48 6f 73 74 3a 20
               25 73 0d 0a 43 6f 6e 74 65 6e 74 2d 54 79 70 65
               3a 20 25 73 0d 0a 43 6f 6e 74 65 6e 74 2d 4c 65
               6e 67 74 68 3a 20 25 64 0d 0a 43 6f 6e 6e 65 63
               74 69 6f 6e 3a 20 4b 65 65 70 2d 41 6c 69 76 65
               0d 0a 0d 0a 00 0d 0a 0d 0a 00 43 6f 6e 74 65 6e
               74 2d 4c 65 6e 67 74 68 3a 20 00 }

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) and 3 of ( $s* ) ) or 6 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Lokilocker : FILE
{
	meta:
		description = "Detects LokiLocker ransomware"
		author = "ditekSHen"
		id = "4f4927c5-79e6-5c5a-b84d-c4728affe9e1"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9169-L9194"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "bf78f5e8f40c1a19f6b078a85854e95d5ef1f321393a831edda17b0d65515da7"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "SOFTWARE\\Loki" fullword wide
		$x2 = "Cpriv.Loki" fullword wide
		$x3 = "Loki/" wide
		$x4 = /loki(\s)?locker/ fullword wide nocase
		$s1 = "Restore-My-Files.txt" wide
		$s2 = "loading encryption keys" wide
		$s3 = "Kill switch -> enabled" wide
		$s4 = "ScanSMBShares" fullword ascii
		$s5 = "RewriteMBR" fullword ascii
		$s6 = /Encrypt(Drives|File|WinVolume|OsDrive)/ fullword ascii
		$n1 = "unique-id=" ascii wide
		$n2 = "&disk-size=" ascii wide
		$n3 = "&user=Darwin&cpu-name=" ascii wide
		$n4 = "&ram-size=" ascii wide
		$n5 = "&os-name=" ascii wide
		$n6 = "&chat-id=" ascii wide
		$n7 = "&msg-id=" ascii wide
		$n8 = "&elapsed-time=" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $x* ) or 4 of ( $s* ) or 6 of ( $n* ) or ( 3 of ( $s* ) and 3 of ( $n* ) ) or ( 1 of ( $x* ) and ( 2 of ( $s* ) or 2 of ( $n* ) ) ) )
}
rule DITEKSHEN_MALWARE_Win_Bhunt : FILE
{
	meta:
		description = "Detects BHunt infostealer"
		author = "ditekSHen"
		id = "4c699f10-64a0-5e3c-af00-e08ebe1c6830"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9212-L9233"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ca0a7e6898047fa3b369125a4402e2beffd328a5db47b1d5dd5914a86d6f0073"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "BHUNT.Resources.resources" fullword ascii
		$x2 = "//minecraftsquid.hopto.org/" wide
		$s1 = "chaos_crew" ascii wide
		$s2 = "golden7" ascii wide
		$s3 = "mrpropper" ascii wide
		$s4 = "/ifo.php?" ascii wide
		$s5 = "bonanza=:=" ascii wide
		$s6 = "blackjack=:=" ascii wide
		$s7 = "SendPostData" fullword ascii
		$c1 = "cmd /c REG ADD" wide
		$c2 = "taskkill /F /IM" wide
		$c3 = "cmd.exe /c wmic" wide
		$g1 = "$ca9a291d-266c-41dc-9f1c-93cfe0dcac16" fullword ascii
		$g2 = "$6d0feb35-213d-4b9f-afc7-06d168cfcb5e" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) or ( 1 of ( $x* ) and ( 5 of ( $s* ) or 2 of ( $c* ) ) ) or ( 6 of ( $s* ) and 2 of ( $c* ) ) or ( all of ( $g* ) and 2 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Lorenz : FILE
{
	meta:
		description = "Detects Lorenz ransomware"
		author = "ditekSHen"
		id = "9c11cfbc-aa77-5138-81e4-3a5f4f21a470"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9235-L9265"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e9fc9d405b955c379ae40b1804d43b19999f6ea264fc645c897080fb020e8ae8"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$x1 = "143.198.117.43" fullword ascii
		$x2 = "157.90.147.28" fullword ascii
		$x3 = "//kpb3ss3vwvfejd4g3gvpvqo6ad7nnmvcqoik4mxt2376yu2adlg5fwyd.onion" ascii
		$x4 = "http://lorenz" ascii
		$x5 = "\\lora\\Release\\lora.pdb" ascii
		$x6 = "--MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQ" ascii
		$x7 = "/USER:'HOMEOFFICE.COM\\" ascii
		$x8 = "/USER:'Sentinel.com\\" ascii
		$s1 = "to->_What == nullptr && to->_DoFree == false" fullword wide
		$s2 = "*it == '\\0'" fullword wide
		$s3 = "process call create 'cmd.exe /c" ascii
		$s4 = "\\Control Panel\\Desktop\" /V Wallpaper /T REG_SZ /F /D" ascii
		$s5 = "HELP_SECURITY_EVENT.html" ascii
		$s6 = "<br>[+] Whats Happen?" ascii
		$s7 = /\.Lorenz\.sz\d+$/ fullword ascii
		$s8 = "TW9Vc29Db3JlV29ya2VyLmV4ZQ==" fullword ascii
		$s9 = ".Speak(\"You've been hack" ascii nocase
		$s10 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAo" ascii
		$n1 = "ame_serv=" ascii
		$n2 = "&ip=" ascii
		$n3 = "&winver=Windows" ascii
		$n4 = "&list_drive=" ascii
		$n5 = "&file=" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $x* ) or 8 of ( $s* ) or ( 4 of ( $n* ) and 2 of them ) or ( 1 of ( $x* ) and 6 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Blackcat : FILE
{
	meta:
		description = "Detects BlackCat ransomware"
		author = "ditekSHen"
		id = "b6831d84-40d7-52ae-8c4d-30b087b0007b"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9267-L9289"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "cd76e5b87f33d91c17fd032417583c3f68d0e310aaf6f08e26ec5d53844ed9d2"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "{\"config_id\":\"\",\"public_key\":\"MIIBIjANBgkqhkiG9w0BAQEFAAO" ascii
		$x2 = "C:\\Users\\Public\\All Usersdeploy_note_and_image_for_all_users=" fullword ascii
		$s1 = "encrypt_app::windows" ascii
		$s2 = /locker::core::os::windows::(desktop_note|self_propagation|privilege_escalation|psexec|shadow_copy)/ ascii
		$s3 = "uac_bypass::shell_exec=" ascii
		$s4 = "-u-p-s-d-f-cpropagate::attempt=" ascii
		$s5 = "masquerade_peb" ascii
		$s6 = "RECOVER-${EXTENSION}-FILES.txt" ascii
		$s7 = ".onion/?access-key=${ACCESS_KEY}" ascii
		$s8 = "-vm-killno-vm-snapshot-killno-vm-kill-" ascii
		$s9 = "esxi_vm_killenable_esxi_vm_snapshot_killstrict_" ascii
		$s10 = /enum_(shares|servers)_sync::ok/ fullword ascii
		$s11 = "hidden_partitions::mount_all::mounting=" ascii

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0x457f ) and ( all of ( $x* ) or 5 of ( $s* ) or ( 1 of ( $x* ) and 3 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Timetime : FILE
{
	meta:
		description = "Detects TimeTime ransomware"
		author = "ditekSHen"
		id = "4d6a31b5-b5a5-58e2-bfce-c40c72cda391"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9311-L9327"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c75ca595ff25f8c79bfe8e5c6af29349be8f07c2de79fd24f09b02afffb7168b"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "@_DECRYPTOR_@" ascii wide
		$s2 = "@__RECOVER_YOUR_FILES__@" wide
		$s3 = "\\TimeTime.pdb" ascii
		$s4 = "runCommand" fullword ascii
		$s5 = "decryptor_file_name" fullword ascii
		$s6 = "encryption_hiding_process" fullword ascii
		$s7 = "admin_hiding_process" fullword ascii
		$s8 = "security_vaccine" fullword ascii
		$s9 = "EncrFiles_Load" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Win_Strifewater : FILE
{
	meta:
		description = "Detects StrifeWater RAT"
		author = "ditekSHen"
		id = "69f0bd07-3e4e-5245-9c42-c3f8199b566e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9329-L9354"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ddb189dfe58af08d2c0682239551a5b9d82db94eedcefc02895316bcbbaca3f2"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "example/1.0" fullword wide
		$s2 = "coname:" fullword ascii
		$s3 = "*elev:" fullword ascii
		$s4 = "*uname:" fullword ascii
		$s5 = "--BoundrySign" ascii
		$s6 = "000000c:\\users\\public\\libraries\\tmp.bi" ascii
		$s7 = "9c4arSBr32g6IOni" fullword ascii
		$pdb = "\\win8\\Desktop\\ishdar_win8\\" ascii
		$xn1 = "techzenspace.com" fullword wide
		$xn2 = "87.120.8.210" wide
		$xn3 = "192.168.40.27" wide
		$n1 = /RVP\/index\d+\.php/ fullword wide
		$n2 = "tid=%d&code=%s&fname=%s&apiData=%s" fullword ascii
		$n3 = "code=%s&tid=%d&fname=%s&apiData=%s" fullword ascii
		$n4 = "Content-Disposition: form-data; name=\"token\"" fullword ascii
		$n5 = "Content-Disposition: form-data; name=\"apiData\"" fullword ascii
		$n6 = "Content-Disposition: form-data; name=\"data\"; filename=\"" fullword ascii
		$n7 = "Content-Disposition: form-data; name=\"tid\"" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $xn* ) or 6 of ( $s* ) or 6 of ( $n* ) or ( 1 of ( $xn* ) and 4 of them ) or ( $pdb and 4 of them ) or ( 3 of ( $s* ) and 3 of ( $n* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Surtr : FILE
{
	meta:
		description = "Detects Surtr ransomware. Ransom note is similar to LockFile"
		author = "ditekSHen"
		id = "7a31415d-5c03-5537-9adb-65e637f9fa0e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9356-L9378"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a8db5588079d471d8904f0444973973a0c01dbec1ccbe3d43a34d41a0dde495d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "<title>SurtrRansomware</title>" ascii
		$s2 = "<HTA:APPLICATION ID=\"SurtrRansomware\"" ascii
		$s3 = "APPLICATIONNAME=\"SurtrRansomware\"" ascii
		$s4 = "src=\"data:image/jpeg; base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wCEAAgICAgJCAkKCgkNDgwODRMREBARExwUFhQWFBwrGx8bGx8bKyYuJSMlLiZENS8v" ascii
		$s5 = "4rbgxisigb4pxnloxzc265rmzaj7fslrhyouegtrph2a7xhh55r6xaid.onion" ascii
		$s6 = "schtasks /CREATE /SC ONLOGON /TN svchos" wide
		$s7 = "reg add HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run\\ /v \"svchos" ascii
		$s8 = "reg add HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunOnce\\ /v \"svchos" ascii
		$s9 = "SURTR_README.txt" wide
		$s10 = "surtr-decrypt.top" ascii
		$s11 = /(Public|Private|ID)_DATA\.surt/ wide

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Win_Udprat : FILE
{
	meta:
		description = "Detects UDPRat"
		author = "ditekSHen"
		id = "938fc9fd-4f08-5c23-8583-06083d2efe59"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9380-L9395"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4606b304d179148c6e44a0a8329675f2823f862a0944284cb646e5910659ea7c"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\code\\UDP\\Client\\" ascii
		$s2 = "ssdp:discover" ascii
		$s3 = ": Device:" ascii
		$s4 = "for the SNMP U encountered" ascii
		$s5 = "privat:InternetGatewayelink" fullword ascii
		$s6 = "schemas A jet error was" ascii
		$s7 = "msidentity" fullword ascii
		$s8 = "microsoftonliser-based Securi" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Jesterstealer : FILE
{
	meta:
		description = "Detects JesterStealer"
		author = "ditekSHen"
		id = "7b07061f-97a4-5158-8084-46ccf212f6be"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9397-L9417"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c84df5d3ad2bc7a75a11c07995cc034c2a92b2f6f6f6943288add9c44c57bf6d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = /\[(Credman|Networks|Screenshot|Vault)\]\s\{0\}/ fullword wide
		$s3 = "encoding=\"base64\"" fullword wide
		$s4 = "/json/list" fullword wide
		$s5 = "/L1ghtM4n/TorProxy/" ascii wide
		$s6 = "<EnumerateCredentials>" ascii
		$s7 = "<EnumerateBrowsers>" ascii
		$s8 = "<PerformSelfDestruct>" ascii
		$s9 = "<get_GrabberCount>" ascii
		$s10 = "AnalyzeData" fullword ascii
		$s11 = "CheckCard" fullword ascii
		$s12 = "CreateGrabberZipPath" fullword ascii
		$s13 = "Jester" fullword ascii
		$s14 = /Stealer\.(Recovery|Grabber|Investigation)\./ ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Soranostealer : FILE
{
	meta:
		description = "Detects SoranoStealer / HogGrabber. Available on Github: /Alexuiop1337/SoranoStealer"
		author = "ditekSHen"
		id = "2fc40a73-5f28-5b5c-938a-35e8336e1d11"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9419-L9443"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "27c9d6bf3f40f3d41c35975e856671fafcd4a0a8143b3bcbdff61c1fb28a37ab"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "OiCuntJollyGoodDayYeHavin_" ascii
		$x2 = { 00 56 4d 50 72 6f 74 65 63 74 00 52 65 61 63 74
                6f 72 00 64 65 34 66 75 63 6b 79 6f 75 00 42 61
                62 65 6c 4f 62 66 75 73 63 61 74 6f 72 41 74 74
                72 69 62 75 74 65 00 43 72 79 74 70 6f 4f 62 66
                75 73 63 61 74 6f 72 00 }
		$x3 = { 00 4f 62 66 75 73 63 61 74 65 64 42 79 47 6f 6c
                69 61 74 68 00 42 65 64 73 2d 50 72 6f 74 6f 72 00 }
		$s1 = ".Binaries.whysosad" ascii
		$s2 = "Adminstrator permissons are required" wide
		$s3 = "12:03:33:4A:04:AF" fullword wide
		$s4 = "RemoveEXE" fullword ascii
		$s5 = "$340becfa-1688-4c32-aa49-30fdb4005e4b" fullword ascii
		$s6 = "$99cffbcc-6ad7-4d32-bd1f-450967cf4a6b" fullword ascii
		$s7 = "\"cam\": " ascii
		$s8 = " - 801858595527371999762718088" fullword ascii
		$s9 = "  - 96188142294460126639341306" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) or ( 2 of ( $x* ) and 3 of ( $s* ) ) or 5 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Gloomanestealer : FILE
{
	meta:
		description = "Detects GloomaneStealer"
		author = "ditekSHen"
		id = "6e3c7e8f-4b75-5198-aa41-076f29aac227"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9445-L9461"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "36aa9f863efb8172ed6449932169e6cb26cdeedd84bc734e09a8116a9c7774ac"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "=GLOOMANE STEALER=" wide
		$x2 = "Maded by GLOOMANE" wide
		$s1 = "\\44CALIBER" ascii
		$s2 = "Ethernet()" fullword wide
		$s3 = ":spy: NEW LOG FROM" wide
		$s4 = ":eye: IP:" wide
		$s5 = ":file_folder: Grabbed Files" wide
		$s6 = "$ebc25cf6-9120-4283-b972-0e5520d0000C" fullword ascii
		$s7 = "$3b0e2d3d-3d66-42bb-8f9c-d6e188f359ae" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) or ( 1 of ( $x* ) and 3 of ( $s* ) ) or 5 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Lockdown : FILE
{
	meta:
		description = "Detects Lockdown / cantopen ransomware"
		author = "ditekSHen"
		id = "793df99d-016a-5f96-9ff9-76d3f08e0dd2"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9463-L9476"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a9bc2f514730703f3edf78a61f1bc357eee12b3289fc7491197c3b885286ca7e"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "BgIAAACkAABSU0E" wide
		$s2 = ".cantopen" fullword wide
		$s3 = "\\HELP_DECRYPT_YOUR_FILES.txt" wide
		$s4 = "SALT" fullword wide
		$s5 = "$4e677664-9a63-458e-a365-deb792509557" fullword ascii
		$s6 = "CreateEncryptor" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Win_Unamedstealer : FILE
{
	meta:
		description = "Detects unknown infostealer. Observed as 2nd stage and injects into .NET AppLaunch.exe"
		author = "ditekSHen"
		id = "cb3d575b-3d53-5b89-abc1-3b3857ec9f46"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9478-L9494"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "84f4ac7489a0d522763f69ce55f816642a8511dc4b9698ce47c983020a2b7bea"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "HideMelt" fullword ascii
		$s2 = ".Implant" ascii
		$s3 = "SetUseragent" fullword ascii
		$s4 = "SendReport" fullword ascii
		$s5 = "cookiesList" fullword ascii
		$s6 = "WriteAppsList" fullword ascii
		$s7 = "Timeout /T 2 /Nobreak" fullword wide
		$s8 = "Directory not exists" wide
		$s9 = "### {0} ### ({1})" wide

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Mystic : FILE
{
	meta:
		description = "Hunt for Mystic Infostealer"
		author = "ditekSHen"
		id = "959eceab-0a2c-5361-b8f4-6739033ffae5"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9614-L9628"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "26e0b85141df818d70124c0b19b5b6a05ac24ae679724d7a8ad94415a6462d17"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "LaStFiLe:)" ascii wide
		$s2 = "LaStPrOcEsS:)" ascii wide
		$s3 = "credit_cards" ascii wide
		$s4 = "number_of_processors" ascii wide
		$s5 = "computername" ascii wide
		$p1 = "G:\\Projects\\Python\\morpher\\" ascii wide
		$p2 = /G:\\Projects\\stealer\\.{15}\\Release\\.{5,25}\.pdb/ ascii wide

	condition:
		( uint16( 0 ) == 0x5a4d and ( 4 of ( $s* ) or ( 1 of ( $p* ) and 3 of ( $s* ) ) ) ) or ( all of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Linux_Buhti : FILE
{
	meta:
		description = "Detects Buhti Ransomware"
		author = "ditekSHen"
		id = "a50b8c34-e9e2-5466-80a1-b0ab805c68be"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9630-L9643"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "1bab3202dbeaf088b233c3ab1056c357d156b7eef3111bea997b1c610a27f561"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "buhtiRansom" ascii
		$x2 = "://satoshidisk.com/pay/" ascii
		$s1 = "main.encrypt_file" fullword ascii
		$s2 = "/path/to/be/encrypted" ascii
		$s3 = "Restore-My-Files.txt" ascii
		$s4 = ".buhti390625" ascii

	condition:
		uint16( 0 ) == 0x457f and ( all of ( $x* ) or ( 1 of ( $x* ) and 3 of ( $s* ) ) or 5 of them )
}
rule DITEKSHEN_MALWARE_Win_Commonmagic : FILE
{
	meta:
		description = "Detects CommonMagic and Modules"
		author = "ditekSHen"
		id = "cbebe334-9b66-5931-8f92-25d080f7fd6a"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9645-L9660"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e94ba53f31f3effe12b1fbaca19fea59c0e12f742f6fc0af2a0a679bf4299cbe"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$p1 = "\\\\.\\pipe\\PipeMd" wide
		$p2 = "\\\\.\\pipe\\PipeCrDtMd" wide
		$p3 = "\\\\.\\pipe\\PipeDtMd" wide
		$s1 = "graph.microsoft.com" fullword wide
		$s2 = "CreateNamedPipe" ascii
		$s3 = "\\CommonCommand\\" wide
		$ua1 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.75 Safari/537.36" wide
		$ua2 = "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10136" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $p* ) and 1 of ( $s* ) ) or ( 1 of ( $ua* ) and 1 of ( $s* ) and 1 of ( $p* ) )
}
rule DITEKSHEN_MALWARE_Win_Greetingghoul : FILE
{
	meta:
		description = "Detects GreetingGhoul Cryptocurrency Infostealer"
		author = "ditekSHen"
		id = "42791b26-1cda-5bf3-b955-9de2dda1d63b"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9662-L9679"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5a2635066df031ba6e291c3ba14f9ed85bf3247c82c66eb1b3d3618fdebb47a6"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "peer_list" fullword ascii
		$s2 = "seed_hash" fullword ascii
		$s3 = "pool_id" fullword ascii
		$s4 = "%smutex=%s:%lu" ascii
		$s5 = "miner.cfg" fullword ascii
		$s6 = "{\"method\": \"%s\"%s}" ascii
		$s7 = "/app/manager/%s" ascii
		$s8 = "X-VNC-STATUS" fullword ascii
		$s9 = "%s\\%lu.zip" fullword ascii
		$s10 = "\\??\\%programdata%\\" wide

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Multi_Family_Infostealer : FILE
{
	meta:
		description = "Detects Prynt, WorldWind, DarkEye, Stealerium and ToxicEye / TelegramRAT infostealers"
		author = "ditekSHen"
		id = "960830ba-df0d-539d-be2a-7778229f79bd"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9681-L9703"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0fdd1cdc4f2e5bee6c763e6e6b2e79d85285e44e2b5e3168a56d7d360252ee99"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$n1 = /Prynt|WorldWind|DarkEye(\s)?Stealer/ ascii wide
		$n2 = "Stealerium" ascii wide
		$x1 = "@FlatLineStealer" ascii wide
		$x2 = "@CashOutGangTalk" ascii wide
		$x3 = /\.Target\.(Passwords|Messengers|Browsers|VPN|Gaming)\./ ascii
		$x4 = /\.Modules\.(Keylogger|Implant|Passwords|Messengers|Browsers|VPN|Gaming|Clipper)\./ ascii
		$s1 = "Timeout /T 2 /Nobreak" fullword wide
		$s2 = /---\s(AntiAnalysis|WebcamScreenshot|Keylogger|Clipper)/ wide
		$s3 = "Downloading file: \"{file}\"" wide
		$s4 = "/bot{0}/getUpdates?offset={1}" wide
		$s5 = "send command to bot!" wide
		$s6 = " *Keylogger " fullword wide
		$s7 = "*Stealer" wide
		$s8 = "Bot connected" wide
		$s9 = "### {0} ### ({1})" wide

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Win_Darkeye : FILE
{
	meta:
		description = "Detects DarkEye infostealer"
		author = "ditekSHen"
		id = "5296fe28-b54e-5d0f-aa2f-2050db585d82"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9751-L9770"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5496dcbfe075a4030a446027765186e9dd1931561a29a481139281e1708ce87d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$c1 = /Prynt(\s)?Stealer/ ascii wide
		$c2 = /WorldWind(\s)?Stealer/ ascii wide
		$c3 = "ToxicEye" ascii wide
		$x2 = "@FlatLineStealer" ascii wide
		$x3 = "@CashOutGangTalk" ascii wide
		$s1 = "--- Clipper" wide
		$s2 = "Downloading file: \"{file}\"" wide
		$s3 = "/bot{0}/getUpdates?offset={1}" wide
		$s4 = "send command to bot!" wide
		$s5 = " *Keylogger " fullword wide
		$s6 = "*Stealer" wide
		$s7 = "Bot connected" wide

	condition:
		uint16( 0 ) == 0x5a4d and not any of ( $c* ) and ( ( 1 of ( $x* ) and 2 of ( $s* ) ) or ( 4 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Invalidprinter : FILE
{
	meta:
		description = "Invalid Printer (in2al5d p3in4er) Loader"
		author = "ditekSHen"
		id = "9b0a59e1-8105-5687-83b2-fb96229f59f9"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9772-L9782"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d14d53b2a73952244641f4e68a3dd5af8cb1e2bfc5936f300f9347b4881ceeb8"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.InvalidPrinter"

	strings:
		$s1 = "in2al5d p3in4er" fullword ascii
		$s2 = "CreateDXGIFactory" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and filesize < 15000KB and all of them
}
rule DITEKSHEN_MALWARE_Win_Truebot : FILE
{
	meta:
		description = "Detects TrueBot"
		author = "ditekSHen"
		id = "7210a0bd-d310-55bf-bb0c-14cadb59bd67"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9807-L9827"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a92141ef0aa7d68b3594a0f56c0370498fe5751a472c9011ac8b92ae46e88e53"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "%s\\rundll32.exe" fullword wide
		$s2 = "ChkdskExs" fullword wide
		$s3 = "n=%s&o=%s&a=%d&u=%s&p=%s&d=%s" ascii
		$s4 = "KLLS" fullword ascii
		$s5 = "%s\\%08x-%08x.ps1" fullword ascii
		$s6 = ".JSONIP" ascii
		$s7 = "CreateProcessAsUserW res %d err %d" fullword ascii
		$s8 = "ldr_sys64.dll" fullword ascii
		$s9 = "SVCHOST" fullword ascii
		$s10 = "WINLOGON" fullword ascii
		$s11 = { 67 6f 6f 67 6c 65 2e 63 6f 6d 00 00 00 00 00 00 
                2f 00 63 00 20 00 64 00 65 00 6c 00 20 00 00 00 
                20 00 3e 00 3e 00 20 00 4e 00 55 00 4c 00 }

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Lummastealer : FILE
{
	meta:
		description = "Detects Lumma Stealer"
		author = "ditekSHen"
		id = "b54521ab-4a31-5c1c-8ef2-b08b0f713693"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9829-L9854"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "74014c5bcc85977b90faed93b348c34e47ee033b06c2f145348ca9c54c27bda5"
		score = 75
		quality = 73
		tags = "FILE"
		snort1 = "2023813001"
		snort2 = "2023813002"
		clamav1 = "MALWARE.Win.Trojan.LummaStealer"

	strings:
		$x1 = /Lum[0-9]{3}xedmaC2,\sBuild/ ascii
		$x2 = /LID\(Lu[0-9]{3}xedmma\sID\):/ ascii
		$s1 = /os_c[0-9]{3}xedrypt\.encry[0-9]{3}xedpted_key/ fullword ascii
		$s2 = "c2sock" wide
		$s3 = "c2conf" wide
		$s4 = "TeslaBrowser/" wide
		$s5 = "Software.txt" fullword wide
		$s6 = "SysmonDrv" fullword
		$s7 = "*.eml" fullword wide nocase
		$s8 = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall" wide
		$s9 = "- Screen Resoluton:" ascii
		$s10 = "lid=%s" ascii
		$s11 = "&ver=" ascii
		$s12 = "769cb9aa22f4ccc412f9cbc81feedd" fullword wide
		$s13 = "gapi-node.io" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) or ( 1 of ( $x* ) and 2 of ( $s* ) ) or 5 of ( $s* ) or 7 of them )
}
rule DITEKSHEN_MALWARE_Win_Dotrunpex : FILE
{
	meta:
		description = "Detects dotRunpeX injector"
		author = "ditekSHen"
		id = "4845edc1-110c-59a2-ace0-57a62b1e69e8"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9906-L9918"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d7f802f233b2b4ff2c250bb8e96649f307bbb3457c78004751401b3ea7f531a0"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\Registry\\Machine\\System\\CurrentControlSet\\Services\\TaskKill" fullword wide
		$s2 = "KoiVM" ascii
		$s3 = "RunpeX.Stub.Framework" wide
		$s4 = "ExceptionServices.ExceptionDispatchInfo" wide
		$s5 = "Kernel32.Dll" wide

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Cyberstealer : FILE
{
	meta:
		description = "Detects CyberStealer infostealer"
		author = "ditekSHen"
		id = "cb02013f-ffb2-5a17-9d6e-1d19b0e98fb8"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9920-L9941"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "72413b68fa1381656202165dcd878761727e7caf0f15ccd65f3f2f842243a1f6"
		score = 75
		quality = 71
		tags = "FILE"

	strings:
		$x1 = "\\Cyber Stealer\\" ascii
		$s1 = "[Virtualization]" fullword wide
		$s2 = "\"encryptedPassword\":\"([^\"]+)\"" fullword wide
		$s3 = "CreditCard" fullword ascii
		$s4 = "DecryptPassword" fullword ascii
		$s5 = "_modTime" fullword ascii
		$s6 = "_pathname" fullword ascii
		$s7 = "_pathnameInZip" fullword ascii
		$s8 = "GetBookmarksDBPath" fullword ascii
		$s9 = "GrabberImages" fullword ascii
		$r1 = "^1[a-km-zA-HJ-NP-Z1-9]{25,34}$" wide
		$r2 = "^3[a-km-zA-HJ-NP-Z1-9]{25,34}$" wide
		$r3 = "^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$" wide
		$r4 = "^(?!:\\/\\/)([a-zA-Z0-9-_]+\\.)*[a-zA-Z0-9][a-zA-Z0-9-_]+\\.[a-zA-Z]{2,11}?$" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) and ( 2 of ( $s* ) or 2 of ( $r* ) ) ) or 7 of ( $s* ) or ( 5 of ( $s* ) and 2 of ( $r* ) ) or ( all of ( $r* ) and 4 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Arrowrat : FILE
{
	meta:
		description = "Detects ArrowRAT"
		author = "ditekSHen"
		id = "14d3aabe-1ef5-599f-adbd-61b580099447"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9943-L9961"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "13e6d4fd274f75c50aa4110276812d02885c03cfc269dde480db66955e5f703a"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3MgTlRcQ3VycmVudFZlcnNpb25cV2lubG9nb" wide
		$s2 = "Software\\Classes\\ms-settings\\shell\\open\\command" wide
		$s3 = "DelegateExecute" fullword wide
		$s4 = "powershell" wide
		$s5 = "DESKTOP_HOOKCONTROL" fullword ascii
		$s6 = "PROCESS_INFORMATION" fullword ascii
		$s7 = "STARTUP_INFORMATION" fullword ascii
		$s8 = /(Venom|Pandora)\shVNC/ fullword wide
		$s9 = "cmd.exe /k START" fullword wide
		$s10 = "ExclusionWD" fullword ascii
		$s11 = "WinExec" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Ducktail : FILE
{
	meta:
		description = "Detects DuckTail"
		author = "ditekSHen"
		id = "2d1a8f9e-ed5f-53fa-8ba8-b6d1344f6d39"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L9963-L9991"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a416212e5f87b33fdc14590c3d6d6ebc2915c2b383adf78d660c9408beb2323f"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "&global_scope_id=" wide
		$s2 = "#ResolveMyIpAll" wide
		$s3 = "#ApproveInvitesHandler" wide
		$s4 = "#ProcessShareCok" wide
		$s5 = "#InviteEmpHandler" wide
		$s6 = "__activeScenarioIDs=%" wide
		$s7 = "&__a=1&fb_dtsg=" wide
		$s8 = "adAccountLimit\":(.*?)}" wide
		$s9 = "|PUSH|" fullword wide
		$s10 = "|SCREEN|" fullword wide
		$s11 = "|SCREEC|" fullword wide
		$s12 = "_ad_accounts>k__" ascii
		$s13 = "get_Pwds" fullword ascii
		$s14 = "Telegram.Bot" ascii
		$s15 = { 2f 00 7b 00 43 00 59 00 52 00 7d 00 2e 00 74 00
               78 00 74 00 00 15 2f 00 7b 00 4c 00 4f 00 47 00
               7d 00 2e 00 74 00 78 00 74 00 00 15 2f 00 7b 00
               43 00 46 00 47 00 7d 00 2e 00 74 00 78 00 74 00
               00 15 2f 00 7b 00 50 00 52 00 53 00 7d 00 2e 00
               74 00 78 00 74 00 00 15 2f 00 7b 00 53 00 43 00
               52 00 7d 00 2e 00 6a 00 70 00 67 }

	condition:
		uint16( 0 ) == 0x5a4d and 13 of them
}
rule DITEKSHEN_MALWARE_Win_Dlinjector07 : FILE
{
	meta:
		description = "Detects downloader injector"
		author = "ditekSHen"
		id = "244ad6fb-8769-5b57-84e2-66f51fccb32a"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10009-L10025"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "aef43b59ef7d0d62a853280ec1588a48d6c21da5218b7fd7e6ab1aa0f048896b"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$x1 = "23lenrek[||]lldtn[||]daerhTemuseR[||]txetnoCdaerhTteS46woW[||]txetnoCdaerhTteS[||]txetnoCdaerhTteG46woW[||]txetnoCdaerhTteG[||]xEcollAlautriV[||]yromeMssecorPetirW[||]yromeMssecorPdaeR[||]noitceSfOweiVpamnUwZ[||]AssecorPetaerC" wide
		$l1 = "[||]" wide
		$r1 = "yromeMssecorPetirW" wide
		$r2 = "xEcollAlautriV" wide
		$r3 = "daerhTemuseR" ascii wide
		$r4 = "noitceSfOweiVpamnUwZ" wide
		$s1 = "Debugger Detected" fullword wide
		$s2 = "payload" fullword ascii
		$s3 = "_ENABLE_PROFILING" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $x* ) or ( 1 of ( $l* ) and 2 of ( $r* ) ) or 6 of them )
}
rule DITEKSHEN_MALWARE_Win_Stealerium : FILE
{
	meta:
		description = "Detects Stealerium infostealer"
		author = "ditekSHen"
		id = "ea137900-3add-54b4-9ce9-bc7e98f86d41"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10027-L10042"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a2834e7fe26ad0197a9e490ab517029ceed2e09506fcc37e6ddf0c1804fa6cb9"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$x1 = "Stealerium" ascii wide
		$x2 = /\.Target\.(Passwords|Messengers|Browsers|VPN|Gaming)\./ ascii
		$x3 = /\.Modules\.(Keylogger|Implant|Passwords|Messengers|Browsers|VPN|Gaming|Clipper)\./ ascii
		$s1 = "Timeout /T 2 /Nobreak" fullword wide
		$s2 = "Directory not exists" wide
		$s3 = "### {0} ### ({1})" wide
		$s4 = /---\s(AntiAnalysis|WebcamScreenshot|Keylogger|Clipper)/ wide
		$s5 = " *Keylogger " fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) or ( 2 of ( $x* ) and all of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Linux_Gobrat : FILE
{
	meta:
		description = "Detects GobRAT"
		author = "ditekSHen"
		id = "0561fa99-24ee-5e02-ba54-17a1dd81daa4"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10044-L10062"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "070687c909b066e38f72b6421b77670e87476d7e1eb1ed8d41d027836629eb71"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "BotList" ascii
		$x2 = "BotCount" ascii
		$x3 = "/etc/services/zone/bot.log" ascii
		$x4 = "aaa.com/bbb/me" ascii
		$s1 = "encoding/gob." ascii
		$s2 = ".GetMacAddress" ascii
		$s3 = ".IpString2Uint32" ascii
		$s4 = ".RegisterLogFile" ascii
		$s5 = ".UniqueAppendString" ascii
		$s6 = ".NewDaemon" ascii
		$s7 = ".SimpleCommand" ascii

	condition:
		uint16( 0 ) == 0x457f and ( 3 of ( $x* ) or ( 2 of ( $x* ) and 3 of ( $s* ) ) or ( 1 of ( $x* ) and 5 of ( $s* ) ) or all of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Hakunamatata : FILE
{
	meta:
		description = "Detects HakunaMatata ransomware"
		author = "ditekSHen"
		id = "43ca40bb-9eb6-558e-977d-f1fff5659565"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10064-L10084"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b49705845e5440c3c1e47e196592ca2b31319d1af5265f2f954d3367e3d39d5c"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run" wide
		$s2 = "(?:[13]{1}[a-km-zA-HJ-NP-Z1-9]{26,33}|bc1[a-z0-9]{39,59})" wide
		$s3 = "<RSAKeyValue><Modulus>" wide
		$s4 = "HAKUNA MATATA" ascii wide
		$s5 = "EXCEPTIONAL_FILE" ascii
		$s6 = "TRIPLE_ENCRYPT" ascii
		$s7 = "FULL_ENCRYPT" ascii
		$s8 = "TARGETED_EXTENSIONS" ascii
		$s9 = "CHANGE_PROCESS_NAME" ascii
		$s10 = "KILL_APPS_ENCRYPT_AGAIN" ascii
		$s11 = "<ALL_DRIVES>b__" ascii
		$s12 = "dataToEncrypt" ascii
		$s13 = "<RECURSIVE_DIRECTORY_LOOK>" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Hakunamatata_Builder : FILE
{
	meta:
		description = "Detects HakunaMatata ransomware builder"
		author = "ditekSHen"
		id = "dbf3490f-418c-5d3b-9f9e-e9fb29d8b652"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10086-L10104"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ac258851de38504cf63ba51fd06f8a9a3dfbe0096d199ba702e9763b5ecc43e4"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "ENCRYPT FILES IN PROCESS" wide
		$s2 = "#TARGET_FILES" ascii wide
		$s3 = "HAKUNA MATATA" ascii wide nocase
		$s4 = "#PRIVATE_KEY" ascii wide
		$s5 = "/target:winexe /platform:anycpu /optimize+" wide
		$s6 = "/win32icon:" fullword wide
		$s7 = "SkippedFolders" ascii
		$s8 = "RECURSIVE_DIRECTORY_LOOK(" ascii
		$s9 = "DRAW_WALLPAPER(" ascii
		$s10 = "startupKey.SetValue(MESSAGE_FILE.Split('.')[0], executablePath);" ascii
		$s11 = /\\obj\\(Debug|Release)\\Hakuna\sMatata\.pdb/ ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Twarbot : FILE
{
	meta:
		description = "Detect TWarBot IRC Bot"
		author = "ditekSHen"
		id = "3acae103-c8d8-5959-83fd-f47d33da350b"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10106-L10121"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "6b1b0b92d2ea7adec58a4b0ac712384542d96dc8707b6f1f13df2d8150a03a7a"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "TWarBot" fullword ascii
		$s1 = "PRIVMSG #" ascii
		$s2 = "C:\\marijuana.txt" fullword ascii
		$s3 = "C:\\rar.bat" fullword ascii
		$s4 = "C:\\zip.bat" fullword ascii
		$s5 = "software\\microsoft\\windows\\currentversion\\app paths\\winzip32.exe" ascii
		$s6 = "software\\microsoft\\windows\\currentversion\\app paths\\WinRAR.exe" ascii
		$s7 = "a -idp -inul -c- -m5" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) and 3 of ( $s* ) ) or 5 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_G0Crypt : FILE
{
	meta:
		description = "Detects G0Crypt / BRG0SNet / NovaGP ransomware"
		author = "ditekSHen"
		id = "c0dd8a1b-1aa6-50be-92c4-125eabaf3f9f"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10123-L10156"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a678bbb02b82c34fb5e7bdce2e60b0da88f12b094e7ca3b74345814d0da5ce42"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$x1 = "G0Crypt/go/" ascii
		$x2 = "BRG0SNet" ascii
		$x3 = "/NovaGroup" ascii
		$x4 = "novagroup@onionmail.org" ascii nocase
		$x5 = "# Nova Group" ascii
		$f1 = "main.HaveRun" ascii
		$f2 = "main.FindFile" ascii
		$f3 = "main.deriveKey" ascii
		$f4 = "main.Pwd" fullword ascii
		$f5 = "/ClearBashFile" ascii
		$f6 = "/ClearUserTempFiles" ascii
		$f7 = "/KillProccess" ascii
		$f8 = "/Encryptor" ascii
		$f9 = "/NoDirEncrypt" ascii
		$f10 = "/RunCmdEexecutable" ascii
		$f11 = "/StopImportantServices" ascii
		$f12 = "/GetPwd" ascii
		$s1 = "\\$Recycle.Bin"
		$s2 = ".README.txt"
		$s3 = "\\BRSPATH.exe"
		$s4 = "taskkill /F /IM sql*"
		$s5 = "C:\\inetpub\\logs\\"
		$s6 = "shutdown /r"
		$s7 = ":\\Program Files\\VMware\\"
		$s8 = "reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run /v Message /t REG_SZ /d"
		$s9 = "reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run /v DelLogSoft /t REG_SZ /d"

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $x* ) or 7 of ( $f* ) or ( 1 of ( $x* ) and ( 5 of ( $f* ) or 5 of ( $s* ) ) ) or ( 6 of ( $f* ) and 4 of ( $s* ) ) or 12 of them )
}
rule DITEKSHEN_MALWARE_Win_Akira : FILE
{
	meta:
		description = "Detects Akira Ransomware Windows"
		author = "ditekSHen"
		id = "350ecf81-7926-5cd2-b0c8-2dd748775e74"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10220-L10243"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "73dd0a1b21be8ff7362536f6b6255cd19510632782effd67a56d7656bebf04ff"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "https://akira" ascii
		$x2 = ":\\akira\\" ascii
		$x3 = ".akira" ascii
		$x4 = "akira_readme.txt" ascii
		$x5 = "\\akira\\asio\\include\\asio\\impl\\co_spawn.hpp" ascii
		$s1 = "Get-WmiObject Win32_Shadowcopy | Remove-WmiObject" ascii
		$s2 = "Win32_ProcessStartup" fullword wide
		$s3 = /Failed\sto\smake\s(part|full|spot)\sencrypt/ ascii wide
		$s4 = "--encryption_" ascii
		$s5 = "--share_file" ascii
		$s6 = { 24 00 52 00 45 00 43 00 59 00 43 00 4C 00 45 00 2E 00 42 00 49 00 4E 00 00 00 00 00 6? 6? 6? 00 (24|57) 00 (52|69) 00 }
		$s7 = " PUBLIC KEY-----" ascii
		$s8 = ".onion" ascii
		$s9 = "/Esxi_Build_Esxi6/./" ascii nocase
		$s10 = "No path to encrypt" ascii
		$s11 = "-fork" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $x* ) or ( 1 of ( $x* ) and 4 of ( $s* ) ) or 6 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Linux_Akira : FILE
{
	meta:
		description = "Detects Akira Ransomware Linux"
		author = "ditekSHen"
		id = "3ac144b3-c747-58e5-bc75-b3f90786f404"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10245-L10264"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "3a00154e1cfc442718e753641d3706ffd4dd8465525d0bb2854f74dfb1cf5dd0"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "https://akira" ascii
		$x2 = ":\\akira\\" ascii
		$x3 = ".akira" ascii
		$x4 = "akira_readme.txt" ascii
		$s1 = "--encryption_" ascii
		$s2 = "--share_file" ascii
		$s3 = { 00 24 52 65 63 79 63 6c 65 2e 42 69 6e 00 24 52 45 43 59 43 4c 45 2e 42 49 4e 00 }
		$s4 = " PUBLIC KEY-----" ascii
		$s5 = ".onion" ascii
		$s6 = "/Esxi_Build_Esxi6/./" ascii nocase
		$s7 = "No path to encrypt" ascii
		$s8 = "-fork" fullword ascii

	condition:
		uint16( 0 ) == 0x457f and ( 3 of ( $x* ) or ( 1 of ( $x* ) and 4 of ( $s* ) ) or 6 of ( $s* ) )
}

rule DITEKSHEN_MALWARE_Win_Romcom_Loader : FILE
{
	meta:
		description = "Hunt for RomCom loader"
		author = "ditekShen"
		id = "49a5398a-e28d-51e2-90d5-479d815f9967"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10291-L10307"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "7aef88aa9f201c3a1852d63b17c14e44c7c2a7dfe94a9bc77897a4aa0eb97486"
		score = 75
		quality = 75
		tags = "FILE"

	condition:
		uint16( 0 ) == 0x5a4d and pe.is_dll ( ) and ( pe.exports ( "DllCanUnloadNow" ) and pe.exports ( "DllGetClassObject" ) and pe.exports ( "DllRegisterServer" ) and pe.exports ( "DllUnregisterServer" ) and pe.exports ( "GetProxyDllInfo" ) ) and for any fn in pe.export_details : ( fn.forward_name contains "Dll" )
}

rule DITEKSHEN_MALWARE_Win_Romcom_Worker : FILE
{
	meta:
		description = "Hunt for RomCom worker"
		author = "ditekShen"
		id = "ce545a33-731c-5ecd-b02e-cedf24f75cc7"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10309-L10322"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "488db046458585882a4709438042b57e02d7dbc06483fdfdfc463a64ee8db203"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "UpdateProcThreadAttribute" fullword ascii
		$s2 = "WriteFile" fullword ascii
		$s3 = "GetAdaptersAddresses" fullword ascii nocase
		$s4 = /inflate\s\d+\.\d+\.\d+\sCopyright/ ascii
		$s5 = "SetHandleInformation" fullword ascii
		$s6 = "PeekNamedPipe" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and pe.is_dll ( ) and pe.number_of_exports == 1 and pe.exports ( "Main" ) and all of them
}

rule DITEKSHEN_MALWARE_Win_Romcom_Dropper : FILE
{
	meta:
		description = "Hunt for RomCom worker"
		author = "ditekShen"
		id = "1b77122d-95d7-535d-897e-b542da17f499"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10324-L10335"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "89f62f71e5870c1e5d14bc32dd3508da620f5fa85494251c69682eb09d630029"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\REGISTRY\\MACHINE\\SOFTWARE\\Classes" wide nocase
		$s2 = "\\REGISTRY\\USER" wide nocase
		$s3 = "BINARY" fullword wide
		$s4 = "POST" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and pe.is_dll ( ) and pe.number_of_exports == 1 and pe.exports ( "Main" ) and 3 of them
}
rule DITEKSHEN_MALWARE_Win_Arcrypt : FILE
{
	meta:
		description = "Detects ARCrypt / ChileLocker ransomware"
		author = "ditekSHen"
		id = "a53bbae6-a321-549d-9d45-e1a408d08740"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10373-L10399"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "cc9fa68d093fdf9745a06beb28e29108cb2ba846122ce097ad892213b1edba25"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$c1 = "readme_for_unlock.txt" wide
		$c2 = "vssadmin.exe delete shadows /all /quiet" wide
		$c3 = "START /b \"\" cmd /c wmic /node:" wide
		$c4 = "START /b \"\" cmd /c DEL \"" wide
		$c5 = "process call create cmd /c START" wide
		$c6 = "net config server /autodisconnect:" wide
		$c7 = "/NOBREAK>NUL) ELSE (START /b \"\" cmd /c DEL \"%~f" ascii
		$c8 = ":\\_ARC\\_WorkSolution\\cryptopp" ascii
		$e1 = /\.crYpt([A-F]{0,1}(\d+)?)?/ fullword wide
		$e2 = ".dnt___.crYpt" wide nocase
		$s1 = "create_directory" fullword ascii
		$s2 = "create_directories" fullword ascii
		$s3 = "NoClose" fullword ascii
		$s4 = "StartMenuLogOff" fullword ascii
		$s5 = "NoLogOff" fullword ascii
		$s6 = "DisableTaskMgr" fullword ascii
		$s7 = "DisableChangePassword" fullword ascii
		$s8 = "HideFastUserSwitching" fullword ascii
		$s9 = "RemotePath" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 5 of ( $c* ) or 7 of ( $s* ) or ( 3 of ( $c* ) and 4 of ( $s* ) ) or ( 1 of ( $e* ) and ( 1 of ( $c* ) and 1 of ( $s* ) ) ) or ( all of ( $e* ) and ( 1 of ( $c* ) or 1 of ( $s* ) ) ) )
}
rule DITEKSHEN_MALWARE_Win_Rootteamstealer : FILE
{
	meta:
		description = "Detects RootTeam infostealer"
		author = "ditekSHen"
		id = "3b57ff3e-09cf-52be-ac7f-45ee832d70ab"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10401-L10417"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d1693865253067527d58c980653d550b55d022d5a394b88090a958e5d5818143"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "RootTeamStl" ascii
		$x2 = "Bot: https://t.me/rootteam_bot" ascii
		$x3 = "rootteam_bot" ascii
		$x4 = "Root Team" ascii
		$s1 = "-ldflags=\"-s -w -H windowsgui -X" ascii
		$s2 = "'RootTeamStl/vars." ascii
		$s3 = "{ Hostname string \"json:\\\"hostname\\\"\"; EncryptedUsername string \"json:\\\"encryptedUsername\\\"\"; EncryptedPassword string \"json:\\\"encryptedPassword\\\"\" }" ascii
		$s4 = "\\Program Files (x86)\\Steam\\config\\loginusers.vdf" ascii
		$s5 = /RootTeamStl\/managers\/(browser|coldwallets|discord|filegrabber|steam|userinformation)?/ ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $x* ) or ( 1 of ( $x* ) and 3 of ( $s* ) ) or 4 of ( $s* ) or 5 of them )
}
rule DITEKSHEN_MALWARE_Win_Espioloader : FILE
{
	meta:
		description = "Detects Espio loader and obfuscator"
		author = "ditekSHen"
		id = "fb2be984-abd6-5f71-b448-d41c9c3e35c5"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10438-L10451"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "8ad77a50db48f12e6f6465652b24fc1daa56375bb27e37e0eead1bea55b89e0c"
		score = 75
		quality = 75
		tags = "FILE"
		clamav_sig = "MALWARE.Win.EspioLoader"

	strings:
		$pdb = /\\loader\\x64\\(Release|Debug)\\Espio\.pdb/ ascii
		$s1 = "obfuscatedPayload" fullword wide
		$s2 = "OBFUSCATEDPAYLOAD" fullword wide
		$s3 = "\\??\\C:\\Windows\\System32\\werfault.exe" fullword wide
		$s4 = "C:\\windows\\system32\\ntdll.dll" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( $pdb or 3 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Celestybinderloader : FILE
{
	meta:
		description = "Detects Celesty Binder loader"
		author = "ditekSHen"
		id = "9c3404b7-311c-565d-b0fa-cfa80ba97289"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10453-L10466"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "8c9ffd48c9c8cd345dccfb48bcb345282f9978f7cf906a61e2ea81c48486b16d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\DarkCoderSc\\Desktop\\Celesty Binder\\Stub\\STATIC\\Stub.pdb" ascii
		$s2 = "DROPIN" fullword ascii wide
		$s3 = "EXEC" fullword ascii wide
		$s4 = "RBIND" fullword ascii wide
		$s5 = "%LAPPDATA%" fullword ascii wide
		$s6 = "%USERDIR%" fullword ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Blitzgrabber : FILE
{
	meta:
		description = "Detects BlitzGrabber infostealer"
		author = "ditekSHen"
		id = "4240527e-c2f8-5424-986a-c1616fafb9bb"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10468-L10487"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "8baceacf3c2af61e00b31e8106820b6f1ce2e7a9d98eaed965e698109ae08314"
		score = 75
		quality = 71
		tags = "FILE"

	strings:
		$x1 = "**BLITZED GRABBER V" wide
		$x2 = "\\BlitzedGrabberV" ascii
		$x3 = "Kyanite" ascii wide nocase
		$s1 = /;\/\/(SCREENSHOT|PASSWORDS|FORKBOMB|MELTSTUB)\/\// ascii wide
		$s2 = "KryptedWare" wide
		$s3 = "chckcopyTemp" wide
		$s4 = "chckscreenShot" wide
		$s5 = "Plugin.Banking." ascii
		$s6 = "sChromiumPswPaths" ascii
		$s7 = ".CreateDownloadLink(" ascii
		$s8 = "CaptureScreen()" ascii
		$s9 = ".UploadFile(\"https://api.anonfiles.com/upload\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $x* ) and 3 of ( $s* ) ) or ( 7 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Bagle : FILE
{
	meta:
		description = "Detect Bagle / Beagle email worm"
		author = "ditekSHen"
		id = "32632bdf-6cf5-5542-8e1f-70686139a465"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10489-L10505"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4c3a09f10c792de1ab25001da29ea2fee84c583d49d9a5225817644aabde2dea"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "SOFTWARE\\DateTime" fullword ascii
		$s2 = "%s?p=%lu" fullword ascii
		$s3 = "-upd" ascii
		$s4 = "[%RAND%]" fullword ascii
		$s5 = "MAIL FROM:<%s>" fullword ascii
		$s6 = "RCPT TO:<%s>" fullword ascii
		$s7 = "Message-ID: <%s%s>" fullword ascii
		$s8 = "Content-Disposition: attachment; filename=\"%s%s\"" fullword ascii
		$s9 = "http://www.%s" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 8 of them
}
rule DITEKSHEN_MALWARE_Win_Ragestealer : FILE
{
	meta:
		description = "Detect Rage / Priv8 infostealer"
		author = "ditekShen"
		id = "dfc1abaa-d975-5e6a-ad4d-344031b0c40c"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10507-L10522"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a26b86845bcd62d4a360a8dae9cfa56b5d96ebc521f224c18a01cc0a2bd958e9"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "\\RageStealer\\obj\\" ascii
		$x2 = "Priv8 Stealer" wide
		$s1 = "\\Screen.png" wide
		$s2 = "Content-Disposition: form-data; name=\"document\"; filename=\"{1}\"" wide
		$s3 = "NEW LOG FROM" wide
		$s4 = "GRABBED SOFTWARE" wide
		$s5 = "DOMAINS DETECTED" wide
		$s6 = "snder" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $x* ) and 4 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Abubasbanditbot : FILE
{
	meta:
		description = "Detects Abubasbandit Bot. Observed to drop cryptocurrency miner detected by MALWARE_Win_CoinMiner02"
		author = "ditekSHen"
		id = "8bedd1f7-bd77-5f26-8665-1d23fe56100f"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10524-L10541"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "aae40178dadff720b42d211a025fd696eabdcc91761c6a91809f5f088c588c31"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "magickeycmd" ascii
		$x2 = "chat_id" ascii
		$x3 = "GetTempPathW" ascii
		$x4 = "Add-MpPreference" ascii
		$x5 = "-Command" ascii
		$s1 = "application/x-www-form-urlencoded" ascii
		$s2 = "gzip, deflate/index.html" ascii
		$s3 = "powershellAdd-MpPreference -ExclusionPath" ascii
		$s4 = "tar-xf-C" ascii
		$s5 = "temp_file.bin" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) or ( 4 of ( $x* ) and 2 of ( $s* ) ) or ( ( all of ( $s* ) and 3 of ( $x* ) ) ) or ( 8 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Oracrat : FILE
{
	meta:
		description = "Detects OracRAT / Comfoo / Babar"
		author = "ditekSHen"
		id = "53f3778e-56d5-5390-8ce7-82d4ede46be4"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10543-L10557"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "078a5df9f3d0bb8213ea2fe28eefdb453ef186e6c1f62d3ba10cb04fca047700"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "\\\\.\\DevCtrlKrnl" fullword ascii
		$s2 = "SOFTWARE\\Microsoft\\IE4\\Setup" fullword ascii
		$s3 = "\\PLUGINS" fullword ascii
		$s4 = "\\config\\sam" fullword ascii
		$s5 = "\\iexplore.exe\" about:blank" fullword ascii
		$s6 = "usbak.sys" fullword ascii
		$s7 = "userctfm" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Phemedronestealer : FILE
{
	meta:
		description = "Detects Phemedrone Stealer infostealer"
		author = "ditekSHen"
		id = "297aab1f-351c-5955-8a19-9aa2b7c94748"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10559-L10580"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "74e150cc971f5648f9e3f6146afba162b1a29cf2744c862b2320db52c2efa930"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$p1 = /\{ file = \{(0|file)\}, data = \{(1|data)\} \}/ ascii wide
		$p2 = "{ <>h__TransparentIdentifier0 = {0}, match = {1} }" wide
		$p3 = "{ <>h__TransparentIdentifier1 = {0}, encrypted = {1} }" wide
		$p4 = "{<>h__TransparentIdentifier0}, match = {match} }" ascii
		$p5 = "{<>h__TransparentIdentifier1}, encrypted = {encrypted} }" ascii
		$s1 = "<KillDebuggers>b__" ascii
		$s2 = "<ParseExtensions>b__" ascii
		$s3 = "<ParseDiscordTokens>b__" ascii
		$s4 = "<IsVM>b__" ascii
		$s5 = "<Key3Database>b__" ascii
		$s6 = "masterPass" ascii
		$s7 = "rootLocation" ascii
		$s8 = "rgsServiceNames" ascii
		$s9 = "rgsFilenames" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( all of ( $p* ) and 3 of ( $s* ) ) or ( 3 of ( $p* ) and 4 of ( $s* ) ) or ( 7 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_WSHRAT : FILE
{
	meta:
		description = "Detects WASHRAT"
		author = "ditekSHen"
		id = "e7940b7f-51dd-5a32-899b-64310f27bf3e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10582-L10600"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "297bfe65815637a464e2a8fc23570c6e79694ffe0467d5898b7c845f1450de95"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$x1 = "WSH Rat v" wide
		$x2 = "SOFTWARE\\WSHRat" wide
		$x3 = "WSH Remote" wide nocase
		$x4 = "WSHRAT" wide nocase
		$s1 = "shellobj.regwrite \"HKEY_" ascii nocase
		$s2 = "shellobj.run(\"%comspec% /c" ascii nocase
		$s3 = "objhttpdownload.setrequestheader \"user-agent:\"," ascii nocase
		$s4 = "WScript.CreateObject(\"Shell.Application\").ShellExecute" ascii nocase
		$s5 = "objwmiservice.ExecQuery(\"select" ascii nocase
		$s6 = "httpobj.open(\"post\",\"http" ascii nocase
		$s7 = /(rdp|keylogger|get-pass|uvnc)\|http/ wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $x* ) or ( 1 of ( $x* ) and 1 of ( $s* ) ) or ( 6 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Rustystealer : FILE
{
	meta:
		description = "Detect Rusty / Luca stealer"
		author = "ditekSHen"
		id = "af39f88c-e0df-51f6-bb11-f3a7231180d0"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10602-L10625"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e60e66360c8f97a31e75cd90a12519f75f3a672874fc985a8da1d4d02e185b4d"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "EdgeMicrosoftedgechromiumChromium7star7StaramigoAmigobraveBrave" ascii
		$s2 = "BrowserchromeChromekometaKometaorbitumOrbitumsputnikSputniktorchTorchucozmediaUranuCozMediavivaldiVivaldiatom" ascii
		$s3 = ".kdbx.pdf.doc.docx.xls.xlsx.ppt.pptx.odt.odp\\logscx\\sensfiles.zip" ascii
		$s4 = "dumper.rs" ascii
		$s5 = "decryption_core.rs" ascii
		$s6 = "anti_emulation.rs" ascii
		$s7 = "discord.rs" ascii
		$s8 = /\\logscx\\(passwords_|cookies_|creditcards_)/ ascii
		$s9 = "VirtualBoxVBoxVMWareVMCountry" ascii
		$s10 = "New Log From ( /  )" ascii
		$s11 = "BrowserChromeKometaOrbitumSputnikTorchUranuCozMediaVivaldiAtomMail" ascii
		$s12 = "BrowserBraveSoftwareCentBrowserChedotChrome" ascii
		$s13 = "ChromeKometaOrbitumSputnikTorchUranuCozMediaVivaldi" ascii
		$s14 = "hostnameencryptedUsernameencryptedPasswordstruct" ascii
		$s15 = "encryptedPassword" fullword ascii
		$s16 = "AutoFill@~" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Simplepacker : FILE
{
	meta:
		description = "Detects Hydrochasma packer / dropper"
		author = "ditekSHen"
		id = "449f7531-408f-5bda-aa64-d148c363c3e5"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10627-L10638"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e2c07947fdf53814669250052f6cceb7412aa302422f3a0b430879da638c7e6a"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$p1 = "\\cloud-compiler-" ascii
		$p2 = "\\deps\\simplepacker.pdb" ascii
		$s1 = "uespemosarenegylmodnarodsetybdetqueue" ascii
		$s2 = "None{\"" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $p* ) or ( 1 of ( $p* ) and all of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Multi_Golangbypassav : FILE
{
	meta:
		description = "Detect Go executables using GolangBypassAV"
		author = "ditekSHen"
		id = "bd41ff7e-ce57-5bee-b6ca-9341b4c1c1fa"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10679-L10689"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "842dfc7c04cbd19bbbc8b6fbf9d9925f81a21dfb713af4542ca4157d64fa5b51"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "MALWARE.Win.Trojan.GolangBypassAV"
		clamav2 = "MALWARE.Linux.Trojan.GolangBypassAV"

	strings:
		$s1 = "/GolangBypassAV/gen/" ascii

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0x457f ) and 1 of them
}
rule DITEKSHEN_MALWARE_Win_Blankstealer : FILE
{
	meta:
		description = "Detects BlankStealer / BlankGrabber / Blank-c Stealer"
		author = "ditekSHen"
		id = "19686781-4be8-56c1-b606-d8fe14dbdc48"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10691-L10703"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "cc0c8d3e0061d192e445ef661387360644ab428a9e9fc2480e966db96bc8264c"
		score = 75
		quality = 75
		tags = "FILE"
		snort = "923829001"

	strings:
		$s1 = "Blank-c" ascii
		$s2 = "Stealer License" ascii
		$s3 = "UID=" ascii
		$h1 = { 42 6c 61 6e 6b 2d 63 0a 53 74 65 61 6c 65 72 20 4c 69 63 65 6e 73 65 0a 55 49 44 3d }

	condition:
		( uint16( 0 ) == 0x4152 and 2 of them ) or ( all of ( $s* ) or 1 of ( $h* ) )
}
rule DITEKSHEN_MALWARE_Linux_Getshell : FILE
{
	meta:
		description = "Detect GetShell Linux backdoor"
		author = "ditekSHen"
		id = "cccad93d-cd49-5237-96ac-66c9ac6ef532"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10705-L10725"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9d44ad2a3c270eed0e905402e8c32dcca54da90f4229d9d59874ee09b3b47277"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "MALWARE.Linux.Trojan.GetShell"

	strings:
		$x1 = "cat <(echo '@reboot echo socks5_backconnect" ascii
		$x2 = "(cd  && )') <(sed '/socks5_backconnect" ascii
		$s1 = "cat <(echo '@" ascii
		$s2 = "(cd  && )') <(sed '" ascii
		$s3 = "PORT1:" ascii
		$s4 = "HOST1:" ascii
		$s5 = "queryheader" ascii
		$s6 = "qsectionpost" ascii
		$s7 = "packedip" ascii
		$s8 = "copydata" ascii
		$s9 = "synsend" ascii
		$s10 = "bc_connect" ascii

	condition:
		uint16( 0 ) == 0x457f and ( ( all of ( $x* ) and 1 of ( $s* ) ) or 5 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Solarmarker : FILE
{
	meta:
		description = "Detects SolarMarker"
		author = "ditekSHen"
		id = "78c2f739-76b2-5a80-8b9a-6c677d578eaa"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10727-L10745"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "84182c8948c2f40439cd932885ae8b88bb677ecc9fba366f22d30e13dc4ffb68"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "token_type" fullword ascii
		$x2 = "request_data" fullword ascii
		$x3 = "request_timeout" fullword ascii
		$x4 = { 74 6f 6b 65 6e 73 00 66 72 6f 6d 00 74 6f 00 73 5f (66|72) }
		$s1 = "set_UseShellExecute" fullword ascii
		$s2 = "<Select>b__0" fullword ascii
		$s3 = "<get>b__e" fullword ascii
		$s4 = "<get>b__10" fullword ascii
		$s5 = "<get>b__f" fullword ascii
		$s6 = "<set>b__0" fullword ascii
		$s7 = "<set>b__1" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) and 4 of ( $s* ) )
}
rule DITEKSHEN_MALWRE_Win_Darkgate : FILE
{
	meta:
		description = "Detects DarkGate infostealer and coinminer"
		author = "ditekSHen"
		id = "4488e1e6-daac-5832-8326-3151c834daf1"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10747-L10771"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "805a04bbb3915d539e76927393384a2786c25490e8b9fc151d5b12415247578b"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "SYSTEM Elevation: Completed, new DarkGate connection with SYSTEM privileges" ascii
		$x2 = "-u 0xDark" ascii
		$x3 = "DarkGate" ascii
		$x4 = "/c cmdkey /generic:\"127.0.0.2\" /user:\"SafeMode\" /pass:\"darkgatepassword0\"" ascii
		$s1 = "c:\\temp\\crash.txt" ascii
		$s2 = "/cookiesfile \"" ascii
		$s3 = "/c rmdir /s /q \"" ascii
		$s4 = "/c xcopy /E /I /Y \"%s\" \"%s\" && exit" ascii
		$s5 = "U_MemScan" ascii
		$s6 = "U_Google_AD" ascii
		$s7 = "untBotUtils" ascii
		$s8 = "____padoru____" ascii
		$s9 = "u_SysHook" ascii
		$s10 = "zLAxuU0kQKf3sWE7ePRO2imyg9GSpVoYC6rhlX48ZHnvjJDBNFtMd1I5acwbqT+=" ascii
		$s11 = "C:\\Windows\\System32\\ntdll.dll" fullword ascii
		$s12 = /(SYSTEM )?Elevation: (Cannot|I already|AT RAW|FAILURE)/ ascii
		$s13 = /Stub: (WARNING:|Configuration updated:|Global Ping Invoked)/ ascii

	condition:
		( uint16( 0 ) == 0x5a4d and ( ( 3 of ( $x* ) ) or ( 2 of ( $x* ) and 3 of ( $s* ) ) or ( 1 of ( $x* ) and 5 of ( $s* ) ) or ( 6 of ( $s* ) ) ) ) or ( 10 of them )
}
rule DITEKSHEN_MALWARE_Win_Rookie_Downloader : FILE
{
	meta:
		description = "Detect malware downlaoder, variant of ZombieBoy downloader"
		author = "ditekSHen"
		id = "a991eecb-5275-5e33-bea4-e709590474a8"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10773-L10786"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "6d5625c2cd7e3a51c2fce9948e691ff2d1b7cf85083708790f89e15c6522059b"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "MALWARE.Win.Trojan.RookIE-Downloader"

	strings:
		$s1 = "shell:::{2559a1f3-21d7-11d4-bdaf-00c04f60b9f0}" fullword ascii
		$s2 = "taskkill /f /im hh.exe" fullword ascii
		$s3 = "RookIE/1.0" fullword ascii
		$s4 = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\\Zones\\0" fullword ascii
		$s5 = "#32770" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Win_Fiber : FILE
{
	meta:
		description = "Detects Fiber .NET injector"
		author = "ditekSHen"
		id = "0e562e2e-cb91-5acf-bb8f-5e7e7d971a3d"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10788-L10824"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "bd6c2c02272fe59c8d7de533197f15d94b5532d32875f01e3e4bd52506456a34"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "Fiber.dll" fullword ascii
		$s1 = "-WindowStyle Hidden Copy-Item -Path *.vbs -Destination" wide
		$s2 = "-WindowStyle Hidden {0} -WindowStyle Hidden Start-Sleep 5; Start-Process {1}" wide
		$s3 = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run" wide
		$s4 = "WScript.Shell" fullword wide
		$s5 = "{0}_{1:N}.lnk" fullword wide
		$s6 = "notepad.exe,0" fullword wide
		$i1 = "AppLaunch.exe" fullword wide
		$i2 = "aspnet_regbrowsers.exe" fullword wide
		$i3 = "cvtres.exe" fullword wide
		$i4 = "ilasm.exe" fullword wide
		$i5 = "jsc.exe" fullword wide
		$i6 = "MSBuild.exe" fullword wide
		$i7 = "RegAsm.exe" fullword wide
		$i8 = "RegSvcs.exe" fullword wide
		$v1 = "is tampered" wide
		$v2 = "Debugger Detected" wide
		$v3 = "RepositoryUrl" ascii
		$v4 = { 72 00 63 00 65 00 41 00 00 11 56 00 69 00 72 00
                74 00 75 00 61 00 6c 00 20 00 00 0b 41 00 6c 00
                6c 00 6f 00 63 00 00 0d 57 00 72 00 69 00 74 00
                65 00 20 00 00 11 50 00 72 00 6f 00 63 00 65 00
                73 00 73 00 20 00 00 0d 4d 00 65 00 6d 00 6f 00
                72 00 79 00 00 0f 50 00 72 00 6f 00 74 00 65 00
                63 00 74 00 00 0b 4f 00 70 00 65 00 6e 00 20 00
                00 0f 50 00 72 00 6f 00 63 00 65 00 73 00 73 00
                00 0d 43 00 6c 00 6f 00 73 00 65 00 20 00 00 0d
                48 00 61 00 6e 00 64 00 6c 00 65 00 00 0f 6b 00
                65 00 72 00 6e 00 65 00 6c }

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) and 3 of ( $s* ) and 2 of ( $i* ) ) or ( 4 of ( $s* ) and 4 of ( $i* ) ) or ( 2 of ( $s* ) and 6 of ( $i* ) ) or ( 1 of ( $x* ) and 3 of ( $v* ) ) or ( all of ( $v* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Unknown_Packedloader_01 : FILE
{
	meta:
		description = "Detects unknown loader / packer. Observed running LummaStealer"
		author = "ditekShen"
		id = "2969090f-dff9-5745-b87d-a031741dd2e0"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10826-L10845"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "6fd9075793b55e04c68bb13d21b88741889a9c37a0a9d1a19d895c7b68af4506"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Error at hooking API \"%S\"" wide
		$s2 = "Dumping first %d bytes:" wide
		$s3 = "Error at initialization of bundled DLL: %s" wide
		$s4 = "GetMemoryForDLL()" ascii
		$s5 = "type=activation&code=" ascii
		$s6 = "activation.php?code=" ascii
		$s7 = "&hwid=" ascii
		$s8 = "&hash=" ascii
		$s9 = "type=deactivation&hash=" ascii
		$s10 = "deactivation.php?hash=" ascii
		$s11 = "BANNED" fullword ascii
		$s12 = "GetAdaptersInfo" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 11 of them
}
rule DITEKSHEN_MALWARE_Win_LOLKEK : FILE
{
	meta:
		description = "Detects LOLKEK / GlobeImposter ransowmare"
		author = "ditekShen"
		id = "96374c8d-2ef7-5706-a96f-27d60f73f8c1"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10847-L10864"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "047492f8b7b56c75cfdcc4359de2b02a76cf9591b902171785806987e552995a"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "$Recycle.bin" fullword wide
		$s2 = "\\\\?\\%c:" fullword wide
		$s3 = ".MMM" fullword wide
		$s4 = "ReadMe.txt" fullword wide
		$s5 = "select * from Win32_ShadowCopy" fullword wide
		$s6 = "Win32_ShadowCopy.ID='%s'" fullword wide
		$s7 = "W3CRYPTO LOCKER" ascii
		$s8 = "http://mmcb" ascii
		$s9 = "yip.su/2QstD5" ascii
		$s10 = "C:\\Windows\\Microsoft.NET\\Framework\\v4.0.30319\\AddInProcess32.exe" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 7 of them
}
rule DITEKSHEN_MALWARE_Win_Rhysida : FILE
{
	meta:
		description = "Detects Rhysida ransomware"
		author = "ditekSHen"
		id = "a70bdf19-3b56-5dc0-be74-20a2e85099cc"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10888-L10902"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "fb15f497cdee40b237dfc2aafcde2da95ff2a6f9c162273862ec1a0053269932"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "cmd.exe /c reg add \"HK" ascii
		$s2 = "rundll32.exe user32.dll,UpdatePerUserSystemParameters" fullword ascii
		$s3 = "C:/Users/Public/bg.jpg" fullword ascii
		$s4 = "CriticalBreachDetected.pdf" fullword ascii
		$s5 = "rhysida" ascii
		$s6 = "cmd.exe /c reg delete \"HKCU\\Cont" ascii
		$s7 = "Rhysida-" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of ( $s* ) or ( 3 of ( $s* ) and #s1 > 5 )
}
rule DITEKSHEN_MALWARE_Win_Povertystealer : FILE
{
	meta:
		description = "Detects PovertyStealer"
		author = "ditekSHen"
		id = "a431b82a-81cb-51a9-b3a8-61d71f36a60e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10904-L10917"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0d8a4dd1f3a9935935878840d19e16d91d240da776f99eb2dd3f12df96efa1d9"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "MALWARE.Win.Trojan.PovertyStealer"

	strings:
		$x1 = "Poverty is the parent of crime." ascii
		$s2 = "OperationSystem: %d:%d:%d" ascii
		$s3 = "ScreenSize: {lWidth=%d, lHeight=%d}" ascii
		$s4 = "VideoAdapter #%d: %s" ascii
		$s5 = "$d.log" fullword wide

	condition:
		(( uint16( 0 ) == 0x5a4d and ( 1 of ( $x* ) or all of ( $s* ) ) ) or all of them )
}
rule DITEKSHEN_MALWARE_Win_Janelarat : FILE
{
	meta:
		description = "Detects JanelaRAT"
		author = "ditekSHen"
		id = "6a49eeda-307f-5429-aa24-658223360239"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10919-L10939"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9f10112b6ffa382b03511e7b6c8757438d5910ee2c24d650d05bb53abfff3860"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "<Janela>k__" ascii
		$x2 = "janela" fullword ascii
		$x3 = "\\CSHARP\\RAT\\" ascii
		$s1 = "<SystemInfos>k__" ascii
		$s2 = "<SendKeepAlives>b__" ascii
		$s3 = "hookStruct" fullword ascii
		$s4 = "[^a-zA-Z]" fullword wide
		$s5 = "GetRecycled" fullword ascii
		$s6 = "import \"bcl.proto\";" wide
		$s7 = "\\KL_FINAL\\" ascii
		$s8 = "\\KL_FASEAVAST" ascii
		$s9 = "\\kl c++" ascii
		$s10 = "VisaoAPP" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $x* ) or ( 2 of ( $x* ) and 3 of ( $s* ) ) or ( 1 of ( $x* ) and 5 of ( $s* ) ) or ( 6 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Qwixxrat : FILE
{
	meta:
		description = "Detects QwixxRAT. Uses ToxicEye / TelegramRAT as base (MALWARE_Win_TelegramRAT)"
		author = "ditekSHen"
		id = "0a8f2f6f-aa78-56c2-aca0-d575fbf0b91e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10941-L10953"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e6e44697e393da35215f7835f122cb74b05dbeebb558345d5110d6fbc809f4dd"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = /Qwixx(\s)?Stealer/ ascii wide
		$s2 = "discord.gg/UXVFHzTjYe" wide
		$s3 = "t.me/QwixxTwixx" wide
		$s4 = "Secret Qwixx" wide
		$s5 = "\\Qwixx Rat\\" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 2 of them
}
rule DITEKSHEN_MALWARE_Win_Toxiceye : FILE
{
	meta:
		description = "Detects ToxicEye / TelegramRAT. Observed used as the basis for many infostealers"
		author = "ditekSHen"
		id = "99304f11-2444-5864-b174-514bb5bef0f7"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10955-L10973"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ee01c107dd295b923801c0d1a77b1534d3a5f2abf8d2cfa93c6786a1b0553504"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "[~] Handling command" wide
		$s2 = "[?] Sleeping {0}" wide
		$s3 = "GETPASSWORDS" wide
		$s4 = "FORKBOMB" wide
		$s5 = "SENDKEYPRESS" wide
		$s6 = "KEYLOGGER" wide
		$s7 = "/ToxicEye/master/TelegramRAT/" wide
		$s8 = "desktopScreenshot" ascii
		$s9 = "MeltFile" ascii
		$s10 = "AutoStealer" ascii
		$s11 = /\/LimerBoy\/(ToxicEye|Adamantium-Thief|hackpy)/ wide

	condition:
		uint16( 0 ) == 0x5a4d and 7 of them
}
rule DITEKSHEN_MALWARE_Win_Rdpcredsstealerinjector : FILE
{
	meta:
		description = "Detects RDP Credentials Stealer injector"
		author = "ditekSHen"
		id = "221b7d64-6585-5f3a-bffa-bde05390db73"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L10994-L11007"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0dfade8dde987f5134158b7c4abc3eaf8dcece86e1ff2ab1da4466da316939a2"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "MALWARE.Win.Trojan.RDPCredsStealer-Injector"

	strings:
		$s1 = "\\APIHookInjectorBin\\" ascii
		$s2 = "\\RDPCredsStealerDLL.dll" ascii
		$s3 = "DLL Injected" ascii
		$s4 = "Code Injected" ascii
		$s5 = /(OpenProcess|VirtualAllocEx|CreateRemoteThread)\(\) failed:/ fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 3 of them
}
rule DITEKSHEN_MALWARE_Win_Krakenstealer : FILE
{
	meta:
		description = "Detect Kraken infostealer"
		author = "ditekSHen"
		id = "460eb574-99c9-5f78-9efa-7a8808aaaae7"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11009-L11030"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "7f15823db706e6e51d8ea58fb026efb49f42234255d2f448614dc645d12648bb"
		score = 75
		quality = 73
		tags = "FILE"
		snort = "923828002"

	strings:
		$x1 = /Kraken(_)?(Stub|Keyboard|Clipboard|GeneratorMachine|PostLogs|Screenshot|Keylogs|Password)/ ascii wide
		$s1 = /(get|set)_(Clipboard|Keyboard|Screen)Recorder/ fullword ascii
		$s2 = /Dumping(FileZilla|360_China|Opera|Epic|CocCoc|Thunderbird|Brave)/ fullword ascii
		$s3 = "ScreenPostData" fullword ascii
		$s4 = "encrypt_data" fullword ascii
		$s5 = "KeyboardProc" fullword ascii
		$s6 = "UploadsKeyboard" fullword ascii
		$s7 = "ClpUploader" fullword ascii
		$s8 = "StartKeylogger" fullword ascii
		$s9 = "ClipoDetectedRemover" fullword ascii
		$s10 = "Disable_Regis" fullword ascii
		$s11 = "RecordedClips" fullword ascii
		$s12 = "HoneyPotStatus" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) and 2 of ( $s* ) ) or 9 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Whiffyrecon : FILE
{
	meta:
		description = "Detects Whiffy Recon"
		author = "ditekSHen"
		id = "19b0f327-06ee-5f78-abac-9c4fbcad98ac"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11032-L11052"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "58df9f47f5890c5e31d352be682c6164a940dad206ad29c54c43f70d3afb9543"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "WLANSVC" fullword wide
		$s2 = "f02fe1c0-137a-4802-8881-55dd300c5022" fullword wide
		$s3 = "\\wlan.lnk" fullword wide
		$s4 = "str-12.bin" wide
		$s5 = "/geolocation/v1/geolocate?key=" wide
		$s6 = "/wlan" fullword wide
		$s7 = "/scanned" fullword wide
		$s8 = "/bots/" fullword wide
		$s9 = "wlan.pdb" fullword ascii
		$s10 = "botId" fullword ascii
		$s11 = "wifiAccessPoints" fullword ascii
		$s12 = "considerIp" fullword ascii
		$s13 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_MALWARE_Win_Quiterat : FILE
{
	meta:
		description = "Detects QuiteRAT"
		author = "ditekSHen"
		id = "54f7b899-3418-5074-8138-38cf073cda8c"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11054-L11068"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "257f9151294254e3e86979f184963f0396587438393b11bad068ba0f386cfc4a"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "< No Pineapple! >" ascii
		$x2 = ".?AVPineapple" ascii
		$x3 = ".?AVApple@@" ascii
		$s1 = "XgsdCwsRFxZF" ascii
		$s2 = "XggZChkVRQ==" ascii
		$s3 = "RxUZERQRHEU=" ascii
		$s4 = "XhkbDBEXFkU" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( all of ( $x* ) and 1 of ( $s* ) ) or ( 1 of ( $x* ) and 3 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_PWSH_CUMII
{
	meta:
		description = "Detects multi-dropper PowerShell"
		author = "ditekSHen"
		id = "07b77251-1d79-5521-8c05-ecfc662f45cb"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11070-L11086"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ab9e59b0552718928d170a988d129b38352700076847f2f409976016858864eb"
		score = 75
		quality = 75
		tags = ""
		clamav = "ditekSHen.MALWARE.PWSH.CUMII"

	strings:
		$s1 = ".('{1}{$}'.replace('$','0')" ascii nocase
		$s2 = ",'I').replace('!','ex')" ascii nocase
		$s3 = "'.replace('*','0001')" ascii nocase
		$s4 = "Remove-Item $" ascii nocase
		$s5 = "the File will start cumiing" ascii nocase
		$b1 = "011001100111010101101110011*" ascii
		$b2 = "0101001000*1110110*010011111" ascii
		$b3 = "01001101010110101001*11*0000" ascii

	condition:
		(3 of ( $s* ) and 1 of ( $b* ) )
}
rule DITEKSHEN_MALWARE_Win_Agnianestealer : FILE
{
	meta:
		description = "Detects Agniane infostealer"
		author = "ditekSHen"
		id = "fcbbf748-dc01-579f-a6f8-37e0f3dea35e"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11088-L11114"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0031fbe6d76868819cbcfc638433d60a50e8f5cfd14ff25af88ed3dffefd7d62"
		score = 75
		quality = 75
		tags = "FILE"
		snort = "923828001"
		clamav = "ditekSHen.MALWARE.Win.AgnianeStealer"

	strings:
		$x1 = "Agniane.pdb" ascii
		$x2 = "IEnumerable<Agniane.Classes.LogRecord>." ascii
		$x3 = "Agniane Stealer" wide
		$x4 = "cinoshibot" wide
		$x5 = "yqbiguuno2zp5jxsmqbev4rwckvy27bqws5cgm3hiid7xolt65j72kqd.onion" wide
		$s1 = "<Pass encoding=\"base64\">" wide
		$s2 = "Domain Detect: detected {0}" wide
		$s3 = "DOMAINDETECTCOOKIES" ascii
		$s4 = /(Opera|Edge|Chrome|Brave|Vivaldi|Blink|Universal|Gecko|OperaGx|Firefox)Grabber/ fullword ascii
		$u1 = "/antivm.php?id=" wide
		$u2 = "/ferr.php?id=" wide
		$u3 = ".php?ownerid=" wide
		$u4 = "&buildid=" wide
		$u5 = "&username=" wide
		$u6 = "&BSSID=" wide
		$u7 = "&rndtoken=" wide
		$u8 = "&domaindetects=" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 2 of ( $x* ) or ( 1 of ( $x* ) and ( 2 of ( $s* ) or 3 of ( $u* ) ) ) or ( all of ( $s* ) and 3 of ( $u* ) ) or ( 7 of ( $u* ) ) )
}
rule DITEKSHEN_MALWARE_Win_TOITOIN_Kritaloader : FILE
{
	meta:
		description = "Detects TOITOIN KritaLoader"
		author = "ditekSHen"
		id = "5ff002fc-1108-554e-9de6-92d568826d1d"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11116-L11127"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9629a4cfa606812d2579c0c0d486dec5971854e5133f0594a4638db5b89c3135"
		score = 75
		quality = 75
		tags = "FILE"
		clamav = "ditekSHen.MALWARE.Win.Trojan.TOITOIN"

	strings:
		$p1 = ":\\Trabalho_2023\\OFF_2023\\" ascii
		$p2 = "DLL_Start_OK.pdb" ascii
		$s1 = "krita_main" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $p* ) and 1 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_TOITOIN_Downloader : FILE
{
	meta:
		description = "Detects TOITOIN Downloader"
		author = "ditekSHen"
		id = "0282ea26-e381-5c9a-9dad-c90246d8add0"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11143-L11154"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d7e5e99c9266ec144152c3d1066e0e1a862f48ded17fab8f504192ca48219826"
		score = 75
		quality = 75
		tags = "FILE"
		clamav = "ditekSHen.MALWARE.Win.Trojan.TOITOIN"

	strings:
		$p1 = ":\\Trabalho_2023\\OFF_2023\\" ascii
		$s1 = { 20 2f 63 20 22 [6-15] 63 00 6d 00 64 00 00 00 6f 00 70 00 65 00 6e }
		$o1 = { 48 83 fa 10 72 34 48 8b 8d 10 ?? 00 00 48 ff c2 }

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Venomrat : FILE
{
	meta:
		description = "Detects VenomRAT"
		author = "ditekSHen"
		id = "93cd5ae3-c222-51a2-bbb9-bdd3254006e5"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11156-L11170"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "47d343def76a323c66db4ba6fb1c0d119f45323f9b7f36695e4aeb7b070819d7"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "Venom RAT + HVNC" fullword ascii
		$x2 = "Venom" fullword ascii
		$x3 = "VenomByVenom" fullword wide
		$s1 = "/c schtasks /create /f /sc onlogon /rl highest /tn \"" fullword wide
		$s2 = "UmVjZWl2ZWQ" wide
		$s3 = "Pac_ket" fullword wide
		$s4 = "Po_ng" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $x* ) and 2 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Sapphirestealer : FILE
{
	meta:
		description = "Detects SapphireStealer"
		author = "ditekSHen"
		id = "ed6cffe4-23f1-5791-b07d-75abb698c899"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11172-L11190"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "97088c0decf158d45a02571bd50b5f370c139339c19b8071f38c0f9816232d1f"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "Sapphire.Modules." ascii
		$s2 = "sapphire\\" wide
		$s3 = "by r3vengerx0" wide
		$s4 = "Sapphire\\obj\\" ascii
		$s5 = "[ERROR_GETSECRETKEY_METHOD]" fullword wide
		$s6 = "[ERROR_CANT_GET_PASSWORD]" fullword wide
		$s7 = "<h2>------NEW LOGS------</h2>" wide
		$s8 = "[ERROR] can't create grab directory" wide
		$s9 = "<UploadToTelegram>d__" ascii
		$s10 = "UploadToTelegram" ascii
		$s11 = ".SendLog+<UploadToTelegram>d__" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}

rule DITEKSHEN_MALWARE_Win_R77 : FILE
{
	meta:
		description = "Detects r77 rootkit"
		author = "ditekSHen"
		id = "813d207e-c6d9-5fea-8387-19da33bc3317"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11192-L11217"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "e3ec6e88a3a77b7dc69eb51a528e6417f6b8695c7cb01d699cf248cebd9b84e2"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "startup" fullword wide
		$s2 = "process_names" fullword wide
		$s3 = "paths" fullword wide
		$s4 = "service_names" fullword wide
		$s5 = "tcp_local" fullword wide
		$s6 = "tcp_remote" fullword wide
		$s7 = "\\\\.\\pipe\\" wide
		$s8 = "SOFTWARE\\" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( all of ( $s* ) or ( 5 of them and pe.exports ( "ReflectiveDllMain" ) ) or ( 5 of them and for any i in ( 0 .. pe.number_of_sections ) : ( ( pe.sections [ i ] . name == ".detourd" ) ) ) )
}
rule DITEKSHEN_MALWARE_Win_Risepro : FILE
{
	meta:
		description = "Detects RisePro infostealer"
		author = "ditekShen"
		id = "77bc8791-cbe8-53b5-86f4-bc918454a6a6"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11239-L11269"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f6f1832f316df51ca108a3c75034bd53c3823cd3d9b16da120e12e252dbf90ff"
		score = 75
		quality = 71
		tags = "FILE"

	strings:
		$x1 = "t.me/riseprosupport" ascii wide nocase
		$s1 = "failed readpacket" fullword wide
		$s2 = "faield sendpacket" fullword wide
		$s3 = "PersistWal" fullword wide
		$s4 = /CRED_ENUMERATE_(ALL|SESSION)_CREDENTIALS/ fullword ascii
		$s5 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" fullword wide
		$s6 = { 4c 00 6f 00 67 00 69 00 6e 00 20 00 44 00 61 00 
                74 00 61 [10] 57 00 65 00 62 00 20 00 44 00 61 00
                74 00 61 [2] 48 00 69 00 73 00 74 00 6f 00 72 00
                79 [21] 43 00 6f 00 6f 00 6b 00 69 00 65 00 73 }
		$s7 = { 61 00 70 00 70 00 6c 00 69 00 63 00 61 00 74 00
                69 00 6f 00 6e 00 2f 00 78 00 2d 00 77 00 77 00
                77 00 2d 00 66 00 6f 00 72 00 6d 00 2d 00 75 00
                72 00 6c 00 65 00 6e 00 63 00 6f 00 64 00 65 00
                64 00 3b 00 20 00 63 00 68 00 61 00 72 00 73 00
                65 00 74 00 3d 00 75 00 74 00 66 00 2d 00 38 00
                42 61 00 70 00 70 00 6c 00 69 00 63 00 61 00 74
                00 69 00 6f 00 6e 00 2f 00 6a 00 73 00 6f 00 6e
                00 2c 00 20 00 74 00 65 00 78 00 74 00 2f 00 70
                00 6c 00 61 00 69 00 6e 00 2c 00 20 00 2a 00 2f
                00 2a }
		$s8 = /_(SET|GET)_(GRABBER|LOADER)/ wide
		$s9 = /catch (save )?(windows cred|screen|pluginscrypto|historyCC|autofill|cookies|passwords|passwords sql|autofills sql|dwnlhistory sql|discordToken|quantum|isDropped)/ fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $x* ) or 6 of ( $s* ) )
}
rule DITEKSHEN_MALWARE_Win_Graphicalproton_Rsockstun : FILE
{
	meta:
		description = "Detects GraphicalProton custom rsockstun"
		author = "ditekShen"
		id = "5efa85f6-7e73-53a1-92df-4cb975e62345"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11271-L11286"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "ca4d18160b89d82106310237cf81bba57a7f51be77a31d2f18ca8c2987972c2c"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$m1 = "main.connectviaproxy" ascii
		$m2 = "main.connectForSocks" ascii
		$m3 = "main.listenForClients" ascii
		$m4 = "main.listenForSocks" ascii
		$s1 = "Proxy-Authorization: NTLM TlRMTVNTUAABAAAABoIIAAAAAAAAAAAAAAAAAAAAAAA=" ascii
		$s2 = "Server: nginx/1.14.1" ascii
		$s3 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36" ascii
		$s4 = "wine_get" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( all of ( $m* ) and 2 of ( $s* ) ) or ( all of ( $s* ) and 1 of ( $m* ) ) or 7 of them )
}

rule DITEKSHEN_MALWARE_Win_PWSHDLLDL : FILE
{
	meta:
		description = "Detects downloader"
		author = "ditekShen"
		id = "553ed216-c8c2-504f-b689-0e8d21a00eaa"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11288-L11303"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "7acef81f0e6e282650c161963599dcbe2b3975d482eb7c330581901b0fe85655"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "powershell.exe Set-ExecutionPolicy Bypass -Scope Process ; powershell -file " fullword wide nocase
		$s2 = "objShell.run \"powershell -WindowStyle hidden -command wscript.exe //b //nologo '" fullword wide nocase
		$s3 = "cmd.exe /c schtasks.exe /create /tn \"" fullword wide nocase
		$s4 = "-WindowStyle hidden -command wscript.exe //b //nologo '" fullword wide nocase
		$s6 = "\" /tr \"wscript.exe //b //nologo '" fullword wide nocase
		$s7 = "\" -Value \"Powershell.exe -WindowStyle hidden \"\"& '" fullword wide nocase
		$op0 = { 61 01 00 34 53 79 73 74 65 6d 2e 57 65 62 2e 53 }
		$op1 = { 4b 04 00 00 34 01 00 00 7f 05 00 00 1a }

	condition:
		uint16( 0 ) == 0x5a4d and pe.is_dll ( ) and 5 of them
}

rule DITEKSHEN_MALWARE_Win_Nppspy : FILE
{
	meta:
		description = "Detects NPPSpy / Ntospy"
		author = "ditekShen"
		id = "3867ba96-1162-5693-b58e-fc6fa04d880a"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11305-L11325"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "53e929b52dddd5e3d060d2dd9937411f1ff215be4d3c67f5935c2a3fbab006d6"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "ntskrnl.dll" fullword ascii
		$s2 = "PasswordStealing.dll" fullword ascii
		$s3 = "ntoskrnl.dll" fullword ascii
		$s4 = "\\programdata\\packag~" ascii
		$s5 = "NPPSPY.dll" fullword ascii
		$s6 = "MSControll.dll" fullword ascii
		$s7 = "\\Windows\\Temp\\" ascii
		$s8 = "\\NPPSpy\\" ascii
		$s9 = "NPGetCaps" fullword ascii
		$s10 = "NPLogonNotify" fullword ascii
		$path = "\\GrzegorzTworek\\" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( pe.is_dll ( ) and filesize < 110KB and pe.number_of_exports == 2 and ( ( pe.exports ( "NPGetCaps" ) and pe.exports ( "NPLogonNotify" ) ) or ( 1 of ( $s* ) and ( pe.exports ( "NPGetCaps" ) or pe.exports ( "NPLogonNotify" ) ) ) ) ) or ( ( $path ) and any of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Agentracoon : FILE
{
	meta:
		description = "Detects AgentRacoon. Not Raccoon"
		author = "ditekShen"
		id = "cc31bd71-da96-5a3d-b2f1-40f9745d8d46"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11327-L11343"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "7ed17a1bc161855f2bdc432952086f3b86b58ae9ea6c0d541544f4b63a8e08e8"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "UdpClient" fullword ascii
		$s2 = "IPEndPoint" fullword ascii
		$s3 = "get_Client" fullword ascii
		$s4 = "set_ReceiveTimeout" fullword ascii
		$s5 = "Command failed:" wide
		$s6 = "uploaded" wide
		$s7 = "downloaded" wide
		$s8 = ".telemetry." wide
		$s9 = "xn--" wide

	condition:
		uint16( 0 ) == 0x5a4d and 7 of them
}
rule DITEKSHEN_MALWARE_Win_Simda : FILE
{
	meta:
		description = "Detects Simda / Shifu infostealer"
		author = "ditekShen"
		id = "892a5ffe-ea1a-5df3-9c36-0198fa61b8b6"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11345-L11361"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "3f06e86033e8f9534f9904a2a63c4717a9532eb235f6f4405ef1db7d9b93f036"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "command=auth_loginByPassword&back_command=&back_custom1=&" fullword ascii
		$s2 = "iexplore.exe|opera.exe|java.exe|javaw.exe|explorer.exe|isclient.exe|intpro.exe|ipc_full.exe|mnp.exe|cbsmain.dll|firefox.exe|clma" ascii
		$s3 = "debug_%s_%s.log" fullword ascii
		$s4 = "Content-Disposition: form-data; name=\"file\"; filename=\"report\"" ascii
		$s5 = "name=%s&port=%u" ascii
		$s6 = "id=%s&ver=4.0.1&up=%u&os=%03u&rights=%s&ltime=%s%d&token=%d" ascii
		$s7 = "{BotVer:" fullword ascii
		$s8 = "software\\microsoft\\windows nt\\currentversion\\winlogon" ascii
		$s9 = /(!|&|data_)inject(=ok)?/ fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Vbsdownloader : FILE
{
	meta:
		description = "Detects second stage VBS downloader of third stage VBS"
		author = "ditekShen"
		id = "480e6872-3a8c-58c5-a455-02342ec7918c"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11363-L11375"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "fee9a78e60d02ff2f03035812af2bf36fe350c70d3e4e094713791833f8ba4d6"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "CreateObject(\"MSXML2.ServerXMLHTTP\")" wide
		$s2 = ".Open \"GET\"," wide
		$s3 = ".Send" wide
		$s4 = ".responseText" wide
		$s5 = "ExecuteGlobal" wide

	condition:
		filesize < 50KB and all of them
}
rule DITEKSHEN_MALWARE_Win_Umbralstealer : FILE
{
	meta:
		description = "Detects Umbral infostealer"
		author = "ditekShen"
		id = "695a350b-3d8e-5244-a275-a60202a8e956"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11377-L11398"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "1686e4626e4d6335f028d6cb6471c32dac747a77fc95d97b4c9dfd043ba975e9"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "Umbral Stealer" wide
		$x2 = "Umbral.payload." ascii
		$s1 = "U2V0LU1wUHJlZmVyZW5jZ" wide
		$s2 = "{{ Key = {0}, Value = {1} }}" wide
		$s3 = "csproduct get uuid" wide
		$s4 = "0.0.0.0 www."
		$s5 = /(set|get)_Take(Screen|WebcamSnap)shot/ fullword ascii
		$s6 = "still_pin" fullword ascii
		$c1 = "kaspersky.com" wide
		$c2 = "bitdefender.com" wide
		$c3 = "virustotal.com" wide
		$c4 = "malwarebytes.com" wide
		$c5 = "clamav.net" wide
		$c6 = "trendmicro.com" wide

	condition:
		uint16( 0 ) == 0x5a4d and ( 1 of ( $x* ) or 5 of ( $s* ) or ( 3 of ( $s* ) and 4 of ( $c* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Metastealer : FILE
{
	meta:
		description = "Detects MetaStealer infostealer"
		author = "ditekSHen"
		id = "46aa30c1-12c2-56df-8c65-0b96147f9051"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11400-L11423"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "260c6d90a89ddb6219a5cbad18058e41611ae2dc68a8d4e589fa6ca81853752f"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "! #\"'&(&*)>=@?POQOROSOTOUOVOWOXOYOZO[O^]{z|z}z~z" fullword wide
		$s2 = "{0}{1}{2}" fullword wide
		$s3 = "localhost" fullword wide
		$s4 = "\\tdata" fullword wide
		$s5 = "DecryptBlob" fullword ascii
		$s6 = "GetMac" fullword ascii
		$s7 = "GetHdc" fullword ascii
		$s8 = "FindProc" fullword ascii
		$s9 = "targetPid" fullword ascii
		$s10 = "MessageSecurityOverTcp" fullword ascii
		$s11 = "ListOfProcesses" fullword ascii
		$s12 = "ListOfPrograms" fullword ascii
		$s13 = "browserPaths" fullword ascii
		$s14 = "configs" fullword ascii
		$s15 = "scanners" fullword ascii
		$s16 = "FileScannerRule" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 7 of ( $s* )
}

rule DITEKSHEN_MALWARE_Win_Mediapi : FILE
{
	meta:
		description = "Detects MediaPI"
		author = "ditekSHen"
		id = "95db8772-1bcd-5eea-956c-c9578b8e1329"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11425-L11439"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "2bce0a96b45e46c0cbd913dacb3dfe7ae1b519102d637e0fd9dabe2008037d94"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "SomeFunction" ascii
		$s2 = "\"stealth" ascii
		$s3 = "\"ServAddr" ascii
		$s4 = "\"ServPort" ascii
		$s5 = "\"ServIp" ascii
		$s6 = "\"wsaData" ascii
		$s7 = "\"-socket" ascii

	condition:
		uint16( 0 ) == 0x5a4d and pe.is_dll ( ) and ( ( 6 of them ) or ( 3 of them and pe.exports ( "SomeFunction" ) ) )
}
rule DITEKSHEN_MALWARE_Win_Blackhunt : FILE
{
	meta:
		description = "Detects BlackHunt ransomware"
		author = "ditekSHen"
		id = "4bdb26dd-a424-54a6-b313-e98bdf18cfce"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11441-L11456"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "62e9bc505eff3e19ff0cdaf180e45e6d7917f0bec7cd9b007bee9fe1d9d09b66"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = /#BlackHunt_(Logs|BG|Icon|Public|Private|ID|ReadMe|Update)\.(txt|jpg|ico|key|hta)/ ascii wide
		$s2 = /-(biggame|noencrypt|netinfo|nospread)/ fullword wide
		$s3 = "/v \"*BlackHunt\" /t REG_SZ /d" wide
		$s4 = "/sc onstart /TN \"Windows Critical Update\" /TR \"'%s' %s\" /F" wide
		$s5 = "/v \"DisableChangePassword\" /t REG_DWORD /d" wide
		$s6 = "<span> %s </span>this ID (<span> %s </span>)" wide
		$s7 = "}div.header h1 span#hunter" wide
		$s8 = "BLACK_HUNT_MUTEX" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_MALWARE_Win_Houdiniconfig : FILE
{
	meta:
		description = "Detects Houdini Trojan configurations"
		author = "ditekshen"
		id = "e4f974fe-731e-55a8-aa5f-068a1e62f54d"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/back-in-2017"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11600-L11616"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "70a67c9a91d2f82184f1d7a5ea51de911a054dd4e38e2cc36f495ed59219afab"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "install_name="
		$s2 = "nick_name="
		$s3 = "install_folder="
		$s4 = "reg_startup="
		$s5 = "startup_folder_startup="
		$s6 = "task_startup="
		$s7 = "injection="
		$s8 = "injection_process"

	condition:
		( uint16( 0 ) == 0x5a4d and 5 of them ) or ( all of them )
}
rule DITEKSHEN_MALWARE_Win_Lighthand : FILE
{
	meta:
		description = "Detects LightHand"
		author = "ditekshen"
		id = "2b644dfb-f09a-50a5-8260-7b7022bce1f4"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11691-L11718"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4f06467a522b786045839e6b22b888cecc554b0f63cc20dc43dc0f8ec80f5654"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "27.102." ascii
		$x2 = "109.248.150.179" fullword ascii
		$s1 = /Hello (Client|Server)/ fullword ascii
		$s2 = "%s|%s|%s|%s|%s|%s|" fullword wide
		$s3 = "%s\\cmd.exe" fullword wide
		$s4 = "Remote PC" fullword wide
		$s5 = { 2e 62 61 74 [3-4] 3a 4c 31 0d 0a 64 65 6c
                20 2f 46 20 22 25 73 22 0d 0a 69 66 20 65 78 69
                73 74 20 22 25 73 22 20 67 6f 74 6f 20 4c 31 0d
                0a 64 65 6c 20 2f 46 20 22 25 73 22 0d 0a 00 00
                6f 70 65 6e }
		$s6 = { 25 00 2e 00 32 00 66 00 47 00 42 00 00 00 00 00
                25 00 73 00 7c 00 25 00 73 00 7c 00 25 00 73 00
                0a 00 00 00 00 00 00 00 5c 00 2a 00 2e 00 2a 00
                00 00 00 00 0a 00 00 00 2e 00 00 00 2e 00 2e 00
                00 00 00 00 00 00 00 00 46 00 6f 00 6c 00 64 00
                65 00 72 00 00 00 00 00 25 00 73 00 5c 00 25 00
                73 00 00 00 00 00 00 00 25 00 64 00 42 00 00 00
                25 00 2e 00 31 00 66 00 4b 00 42 00 00 00 00 00
                25 00 2e 00 31 00 66 00 4d 00 42 }

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 5 of ( $s* ) ) or ( 1 of ( $x* ) and 3 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Validalpha : FILE
{
	meta:
		description = "Detects ValidApha / BlackRAT"
		author = "ditekshen"
		id = "3162eb5f-6e2d-598a-b199-22b70ec8a773"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11720-L11736"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "54d170076d1b32cee6f6252d40548acc7e23b467d692c59d6146a8aadf431211"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "RAT/Black/" ascii
		$x2 = "RAT/Black/Client_Go/" ascii
		$s1 = "main.RunTask" fullword ascii
		$s2 = "main.CmdShell" fullword ascii
		$s3 = "main.SelfDelete" fullword ascii
		$s4 = "main.RecvPacket" fullword ascii
		$s5 = "main.FileDownload" fullword ascii
		$s6 = "main.CaptureScreen" fullword ascii
		$s7 = "main.PeekNamedPipe" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) and 2 of ( $s* ) ) or ( 6 of ( $s* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Tigerrat : FILE
{
	meta:
		description = "Detects TigerRAT"
		author = "ditekshen"
		id = "37192fc8-1932-5f33-994a-bb319b131c58"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11738-L11756"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "38a238339db7e7f573e0c7362af5a08654a9e134f902c0ecae441250a0364c64"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$m0 = ".?AVCryptorRC4@@" fullword ascii
		$m1 = ".?AVModuleShell@@" fullword ascii
		$m2 = ".?AVModuleKeyLogger@@" fullword ascii
		$m3 = ".?AVModuleSocksTunnel@@" fullword ascii
		$m4 = ".?AVModuleScreenCapture@@" fullword ascii
		$m5 = ".?AVModulePortForwarder@@" fullword ascii
		$s1 = "\\x9891-009942-xnopcopie.dat" fullword wide
		$s2 = "(%02d : %02d-%02d %02d:%02d:%02d)--- %s[Clipboard]" fullword ascii
		$s3 = "[%02d : %02d-%02d %02d:%02d:%02d]--- %s[Title]" fullword ascii
		$s4 = "~KPTEMP" fullword wide
		$s5 = "del \"%s\"%s \"%s\" goto " ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( all of ( $s* ) ) or ( 5 of ( $m* ) ) or ( 3 of ( $m* ) and 2 of ( $s* ) ) or ( 5 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Ktlvdoor : FILE
{
	meta:
		description = "Detects KTLVdoor"
		author = "ditekshen"
		id = "f63ebd05-fb4b-50fb-887b-dacd379594a4"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11758-L11791"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "3ced9b558c7e17acd015cd2c9dd0c5d024bf9c31c7f2e7c9b7b937124109cf8b"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "/cmd/acc/agent_acc" ascii
		$s2 = "main.DLLWMain" ascii
		$s3 = "main.checkSilent" ascii
		$h1 = ".handleInteractiveShell" ascii
		$h2 = ".handleNetstat" ascii
		$h3 = ".handleProcess" ascii
		$h4 = ".handleRefreshHostInfo" ascii
		$h5 = ".handleTimestomp" ascii
		$h6 = ".handleSoInject" ascii
		$h7 = ".HandleRegInfo" ascii
		$h8 = ".handlePortscan" ascii
		$h9 = ".handleReflectDllInject" ascii
		$h10 = ".handleFileDownload" ascii
		$f1 = ".RdpWithNTLM." ascii
		$f2 = ".FingerPrintOs." ascii
		$f3 = ".ScanWMI." ascii
		$f4 = ".ScanWinRM." ascii
		$f5 = ".ScanWeb." ascii
		$f6 = ".ScanSmb2." ascii
		$f7 = ".ScanRDP." ascii
		$f8 = ".ScanPing." ascii
		$f9 = ".ScanOxid." ascii
		$f10 = ".ScanMssql." ascii
		$f11 = ".ScanBanner." ascii
		$fr1 = /\.proxy[CS]2[CS](TC|UD)P/ ascii
		$fr2 = /\.Scan(WMI|WinRM|Web|Smb2|RDP|Ping|Oxid|Mssql|Banner)\./ ascii

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0x457f ) and ( ( 6 of ( $h* ) ) or ( 12 of ( $f* ) ) or ( 2 of ( $h* ) and 4 of ( $f* ) ) or ( 1 of ( $s* ) and ( 4 of ( $h* ) or 4 of ( $f* ) ) ) or ( 13 of them ) )
}
rule DITEKSHEN_MALWARE_Win_Fakecaptcha_Downloader : FILE
{
	meta:
		description = "Detects downloader executables dropped by fake captcha"
		author = "ditekshen"
		id = "d577e8ef-11df-565c-9925-63b8768a7115"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11793-L11803"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "57c39ce93f74d03767e7fde53281983a8462e4f3705d1bb9084bc169a08a0f83"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = "</script>MZ" ascii
		$s2 = "window.close();" ascii
		$s3 = "eval(" ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_MALWARE_Win_Xenorat : FILE
{
	meta:
		description = "Detects Blacksuit"
		author = "ditekshen"
		id = "7f27ebef-8a0e-591a-a926-ac950db86053"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11805-L11820"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "487046464f545fb9e4a1d6e277cdc010eac6886583f0b388555a483d9021191b"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$x1 = "xeno rat client" wide
		$x2 = "xeno_rat_client." ascii
		$x3 = "xeno rat client" ascii
		$s1 = "+<AddToStartupNonAdmin>" ascii
		$s2 = "+<ConnectAndSetupAsync>" ascii
		$s3 = "+<SendUpdateInfo>" ascii
		$s4 = "+<RecvAllAsync_ddos_" ascii
		$s5 = "Plugin.Chromium+<Get" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( ( 1 of ( $x* ) and 2 of ( $s* ) ) or ( 4 of ( $s* ) ) or ( 2 of ( $x* ) ) )
}
rule DITEKSHEN_MALWARE_Multi_POOLRAT : FILE
{
	meta:
		description = "Detects POOLRAT"
		author = "ditekshen"
		id = "5831b479-592d-591b-88b4-73102fe4b6ec"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11822-L11839"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "efc5881975e97583188d43a8a6b0eb59bb7103664897cc0f88ddc4d2376bd842"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "MALWARE.Osx.Trojan.POOLRAT"
		clamav2 = "MALWARE.Linux.Trojan.POOLRAT"

	strings:
		$s1 = "MSG_CmdP" ascii
		$s2 = "MSG_WriteConfigP" ascii
		$s3 = "MSG_SecureDelP" ascii
		$s4 = "ConnectToProxyP" ascii
		$s5 = "MSG_KeepConP" ascii
		$s6 = "MSG_SleepP" ascii
		$s7 = "MSG_TestP" ascii
		$s8 = "MSG_SetPathP" ascii

	condition:
		( uint16( 0 ) == 0x457f or uint16( 0 ) == 0xfacf or uint16( 0 ) == 0xfeca ) and 7 of them
}
rule DITEKSHEN_MALWARE_Multi_Pondrat : FILE
{
	meta:
		description = "Detects PondRAT"
		author = "ditekshen"
		id = "cb8cca87-6b5e-5984-8a73-9f800b262d77"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11841-L11858"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "affa35f789725d3a8cea8dc95744c4e771690fde5f73936d0806a8c9f72fdb2e"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "MALWARE.Osx.Trojan.PondRAT"
		clamav2 = "MALWARE.Linux.Trojan.PondRAT"

	strings:
		$s1 = "MsgDown" ascii
		$s2 = "MsgUp" ascii
		$s3 = "MsgRun" ascii
		$s4 = "MsgCmd" ascii
		$s5 = "CryptPayload" ascii
		$s6 = "RecvPayload" ascii
		$s7 = "csleepi" ascii
		$s8 = "FConnectProxy" ascii

	condition:
		( uint16( 0 ) == 0x457f or uint16( 0 ) == 0xfacf or uint16( 0 ) == 0xfeca ) and 7 of them
}
rule DITEKSHEN_MALWARE_Win_Cicada3301 : FILE
{
	meta:
		description = "Detects Cicada3301"
		author = "ditekshen"
		id = "0aebee9f-177d-5a1b-87e0-8797fb6f6823"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11860-L11885"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "b8b7596bc8ae01b89742e17bd3dbfcc1e2fad486cc6ea19c8de813fc677509f4"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "MALWARE.Win.Ransomware.Cicada3301"

	strings:
		$s1 = "cmd/Cchcp 65001 >nulnet view \\\\"
		$s2 = "create_file_recovery"
		$s3 = "ecnrypted_files_full"
		$s4 = "get_excluded_directories"
		$s5 = "collect_files_except"
		$s6 = ".exe4d5a" ascii
		$s7 = "-accepteula -s -d \"\" --" ascii
		$s8 = "[*.exe*.EXE*.DLL*.ini*.inf*.pol*.cmd*.ps1*.vbs*.bat*.pagefile.sys*.hiberfil.sys*.drv" ascii
		$s9 = "memtasveeamsvc$backupsqlvssmsexchangesql$mysqlmysql$sophosMSExchange" ascii
		$s10 = "-DATA.txt" ascii
		$s11 = /--no_(local|net|impl)/ fullword ascii
		$c1 = "fsutil" ascii
		$c2 = "iisreset" ascii
		$c3 = "vssadmin" ascii
		$c4 = "wmic" ascii
		$c5 = "bcdedit" ascii
		$c6 = "wevtutil" ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 6 of ( $s* ) or ( 4 of ( $c* ) and 4 of ( $s* ) ) or ( all of ( $c* ) and 2 of ( $s* ) ) or 9 of them )
}

rule DITEKSHEN_MALWARE_Win_Fpspy : FILE
{
	meta:
		description = "FPSpy"
		author = "ditekshen"
		id = "39d3be12-1b06-57b1-b3c2-2cbd13a17b03"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11887-L11916"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c26736c7f056f3d13c58e724fda601e88468e2386852b072a37c6646fb5ef8f9"
		score = 75
		quality = 73
		tags = "FILE"
		clamav1 = "MALWARE.Win.Trojan.FPSpy"

	strings:
		$f1 = "[Analys_Spy]" wide
		$f2 = "[DeletePoorDll]" wide
		$f3 = "[DownloadProc]" wide
		$f4 = "[DragWarp]" wide
		$f5 = "[GetCoolDir]" wide
		$f6 = "[JackSleep]" wide
		$f7 = "[KillCmdExe]" wide
		$f8 = "[PsDownProc]" wide
		$f9 = "[PsUpProc]" wide
		$f10 = "[ReadFileFromPacket]" wide
		$f11 = "[RemoteDropExec]" wide
		$f12 = "[RemoteExec]" wide
		$f13 = "[RemoteInject]" wide
		$f14 = "[SendHttpForUpload]" wide
		$s1 = "MazeFunc" fullword ascii
		$s2 = /(Exit|Update|Drop)_EVT/ fullword ascii
		$s3 = "Key.dat" fullword ascii
		$s4 = "%sSysInfo_%02d_%02d_%02d.txt" fullword ascii
		$s5 = "cmd /c systeminfo >> %s" fullword ascii
		$s6 = "Content-Disposition: form-data; name=\"MAX_FILE_SIZE\"" fullword ascii
		$s7 = "FPSpy" fullword wide

	condition:
		uint16( 0 ) == 0x5a4d and ( ( pe.exports ( "MazeFunc" ) and 2 of ( $f* ) and 1 of ( $s* ) ) or ( 6 of ( $f* ) and 1 of ( $s* ) ) or ( 5 of ( $s* ) and 1 of ( $f* ) ) or ( 8 of ( $f* ) ) )
}
rule DITEKSHEN_MALWARE_Win_Klogexe : FILE
{
	meta:
		description = "Detects KLogExe"
		author = "ditekshen"
		id = "8c3ebc2c-717b-5c42-9233-274006d4331b"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11918-L11937"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "1f1809b83dc468122022b68d63734ba1597c6fede01582c31d1700ca0b9e1e22"
		score = 75
		quality = 73
		tags = "FILE"
		clamav1 = "MALWARE.Win.Trojan.KLogExe"

	strings:
		$s1 = "[clip_s]: %s" ascii
		$s2 = "------ %d/%d/%d : %d/%d ------" ascii
		$s3 = "[RWin+]" ascii
		$s4 = "[Too many clip_tail]" ascii
		$s5 = "name=\"userfile\"; filename=\"%s\"" ascii
		$s6 = "Origin: http://" wide
		$s7 = "%s_%d_%d_%d_%d" wide
		$s8 = "/wp-content/include.php?_sys_" wide
		$s9 = "\\desktops.ini" wide
		$s10 = "KLogExe" wide nocase
		$s11 = "dynamic_import.cpp [resolve_call] can`nt" wide

	condition:
		uint16( 0 ) == 0x5a4d and 6 of them
}
rule DITEKSHEN_MALWARE_Win_Babylockerkz : FILE
{
	meta:
		description = "Detects BabyLockerKZ"
		author = "ditekshen"
		id = "faa35818-2bed-528f-a6f0-5356a723ef5b"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L11939-L11957"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "423bbd3b23591608a32e4e724c156fbaa5d1d087515137a82a0aeb8c4865d1ca"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$s1 = ":\\locker\\bin\\stub_win_x64_encrypter.pdb" ascii
		$s2 = "taskkill /f /im explorer.exe" fullword wide
		$s3 = "\\SysWOW64\\cmd.exe /c %windir%\\" wide
		$s4 = "[!] Failed to RunNonElevated: %s, error 0x%X" fullword wide
		$s5 = "[!] Failed to run sync command: %s, error 0x%X" fullword wide
		$s6 = "[-] RunNonElevated: %s" fullword wide
		$s7 = "[!][Encrypt] Not" fullword
		$s8 = "[-] sALLUSERSPROFILE: %s" fullword wide
		$s9 = "[!] WNetGetConnection failed 0x%X" fullword wide
		$s10 = "[!][Scan] " wide
		$s11 = "[-] Start encrypt" wide

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_INDICATOR_RMM_Meshagent : FILE
{
	meta:
		description = "Detects MeshAgent. Review RMM Inventory"
		author = "ditekSHen"
		id = "3d0baa87-22c9-569d-ba84-37ccaac577b8"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L3-L27"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f36c0e23b20e4466100cf4ea2a91515bf1d54505e7b1f0926a4e416a04e0dbcf"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.RMM.MeshAgent"

	strings:
		$x1 = "\\MeshAgent" wide
		$x2 = "Mesh Agent" wide
		$x3 = "MeshDummy" wide
		$x4 = "MeshCentral" wide
		$x5 = "ILibRemoteLogging.c" ascii
		$x6 = "AgentCore/MeshServer_" wide
		$s1 = "var _tmp = 'Detected OS: ' + require('os').Name;" ascii
		$s2 = "console.log(getSHA384FileHash(process.execPath).toString('hex'))" ascii
		$s3 = "ScriptContainer.Create(): Error spawning child process, using [%s]" fullword ascii
		$s4 = "{\"agent\":\"" ascii
		$s6 = "process.versions.commitHash" fullword ascii
		$s7 = "console.log('Error Initializing script from Zip file');process._exit();" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and ( 3 of ( $x* ) or ( 1 of ( $x* ) and 3 of ( $s* ) ) or 6 of ( $s* ) )
}

rule DITEKSHEN_INDICATOR_RMM_Meshagent_CERT : FILE
{
	meta:
		description = "Detects Mesh Agent by (default) certificate. Review RMM Inventory"
		author = "ditekSHen"
		id = "b4b52faa-53a5-5ecf-bff8-984994449ee0"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L29-L42"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d8ac3aec723a87146be99aefbde5642d095d8d41f69c6f5e9981c39104790d33"
		score = 75
		quality = 75
		tags = "FILE"

	condition:
		uint16( 0 ) == 0x5a4d and for any i in ( 0 .. pe.number_of_signatures ) : ( pe.signatures [ i ] . issuer contains "MeshCentralRoot-" )
}
rule DITEKSHEN_INDICATOR_RMM_Connectwise_Screenconnect : FILE
{
	meta:
		description = "Detects ConnectWise Control (formerly ScreenConnect). Review RMM Inventory"
		author = "ditekSHen"
		id = "d752b7e4-b595-56cb-97f1-a60e73160e5a"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L62-L83"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "43003f97c33c631a2806ce2b82b2367d2452ceb21b0267b5dfe78b350b66924a"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.RMM.ConnectWise-ScreenConnect"

	strings:
		$s1 = "FILESYSCREENCONNECT.CORE, VERSION=" wide
		$s2 = "feedback.screenconnect.com/Feedback.axd" wide
		$s3 = /ScreenConnect (Software|Client)/ wide
		$s4 = "ScreenConnect.InstallerActions!ScreenConnect." wide
		$s5 = "\\\\.\\Pipe\\TerminalServer\\SystemExecSrvr\\" wide
		$s6 = "\\jmorgan\\Source\\cwcontrol\\Custom\\DotNetRunner\\" wide
		$s7 = "ScreenConnect." ascii
		$s8 = "\\ScreenConnect.Core.pdb" ascii
		$s9 = "relay.screenconnect.com" ascii

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0xcfd0 ) and 3 of them
}

rule DITEKSHEN_INDICATOR_RMM_Connectwise_Screenconnect_CERT : FILE
{
	meta:
		description = "Detects ConnectWise Control (formerly ScreenConnect) by (default) certificate. Review RMM Inventory"
		author = "ditekSHen"
		id = "7a032c24-8a9e-51c3-983e-62e13594aa35"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L85-L99"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "14291bd9ddb7fd3ee7932f8104687aae58fe7f5de13726153e5e1ee9c211f598"
		score = 75
		quality = 75
		tags = "FILE"

	condition:
		uint16( 0 ) == 0x5a4d and for any i in ( 0 .. pe.number_of_signatures ) : ( pe.signatures [ i ] . issuer contains "DigiCert" and pe.signatures [ i ] . subject contains "Connectwise, LLC" )
}
rule DITEKSHEN_INDICATOR_RMM_Fleetdeck_Agent : FILE
{
	meta:
		description = "Detects FleetDeck Agent. Review RMM Inventory"
		author = "ditekSHen"
		id = "342a196c-1c5c-5951-85e4-d288311b4980"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L101-L123"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "121e59ea0088c519b618e740b57c560d60cced4a48c9d468e6bf1ab22fa8c8ff"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.RMM.FleetDeckAgent"

	strings:
		$s1 = "fleetdeck.io/" ascii
		$s2 = "load FleetDeck agent" ascii
		$s3 = ".dev1.fleetdeck.io" ascii
		$s4 = "remoteDesktopSessionMutex" ascii
		$s5 = "main.remoteDesktopWatchdog" fullword ascii
		$s6 = "main.virtualTerminalWatchdog" fullword ascii
		$s7 = "main.meetRemoteDesktop" fullword ascii
		$s8 = "repo.senri.se/prototype3/" ascii
		$s9 = "main.svcIpcClient" fullword ascii
		$s10 = "main.hookMqttLogging" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_INDICATOR_RMM_Fleetdeck_Commander : FILE
{
	meta:
		description = "Detects FleetDeck Commander. Review RMM Inventory"
		author = "ditekSHen"
		id = "27d533b5-7a66-507e-8ef8-ad9a6cd39ab1"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L125-L143"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "feee888c6649af0d8e8b08a38dda0bf7970089cf064f58b8bd9c6ebd8378e094"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.RMM.FleetDeckCommander"

	strings:
		$s1 = "Software\\Microsoft\\FleetDeck Commander" ascii
		$s2 = "fleetdeck.io/prototype3/" ascii
		$s3 = "fleetdeck_commander_launcher.exe" ascii
		$s4 = "fleetdeck_commander_svc.exe" ascii
		$s5 = "|FleetDeck Commander" ascii
		$s6 = "c:\\agent\\_work\\66\\s\\" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_INDICATOR_RMM_Fleetdeck_Commander_SVC : FILE
{
	meta:
		description = "Detects FleetDeck Commander SVC. Review RMM Inventory"
		author = "ditekSHen"
		id = "c03b61b4-36d0-5d38-9af8-e78b9930231f"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L145-L162"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "20bd69df3d058c24f83af312671cf249a3f26f54ef2e60f6b5b48a5bdb21b68b"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.RMM.FleetDeckCommander-SVC"

	strings:
		$s1 = "fleetdeckfork/execfuncargs(" ascii
		$s2 = "REG ADD HKEY_CLASSES_ROOT\\%s /V \"URL Protocol\" /T REG_SZ /F" ascii
		$s3 = "proceed: *.fleetdeck.io" ascii
		$s4 = "fleetdeck.io/prototype3/commander_svc" ascii
		$s5 = "commanderupdate.fleetdeck.io" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_INDICATOR_RMM_Fleetdeck_Commander_Launcher : FILE
{
	meta:
		description = "Detects FleetDeck Commander Launcher. Review RMM Inventory"
		author = "ditekSHen"
		id = "9a4a221e-7a7a-5008-b509-7f01e4a3eea6"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L164-L178"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9429f55f162eebc58a7a9af8706244438cb76b1f0987facbb52d29997ed48b95"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.RMM.FleetDeckCommander-Launcher"

	strings:
		$s1 = "fleetdeck.io/prototype3/commander_launcher" ascii
		$s2 = "FleetDeck Commander Launcher" ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}

rule DITEKSHEN_INDICATOR_RMM_Fleetdeck_CERT : FILE
{
	meta:
		description = "Detects FleetDeck agent by (default) certificate. Review RMM Inventory"
		author = "ditekSHen"
		id = "49a6b0bb-599a-54b0-85bc-b2f6849e3ae8"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L180-L198"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "8f72713eb4a5d9d32629351b937eee7de5d83abe1cd409cd8c3a8c9c52e6e490"
		score = 75
		quality = 75
		tags = "FILE"

	condition:
		uint16( 0 ) == 0x5a4d and for any i in ( 0 .. pe.number_of_signatures ) : ( ( pe.signatures [ i ] . issuer contains "Sectigo Limited" or pe.signatures [ i ] . issuer contains "COMODO CA Limited" ) and pe.signatures [ i ] . subject contains "FleetDeck Inc" )
}
rule DITEKSHEN_INDICATOR_RMM_Pdqconnect_Agent : FILE
{
	meta:
		description = "Detects PDQ Connect Agent. Review RMM Inventory"
		author = "ditekSHen"
		id = "067e75a3-291b-500f-865d-8758eebe91e7"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L200-L227"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "34d0b07925551d1b08b86aa226c59aba569b6548cfa00a86ce6b1f271e427662"
		score = 75
		quality = 75
		tags = "FILE"

	strings:
		$api1 = "/devices/register" ascii
		$api2 = "/devices/socket/websocket?device_id=" ascii
		$api3 = "/devices/tasks" ascii
		$api4 = "/devices/auth-challenge" ascii
		$api5 = "/devices/receiver/Url" ascii
		$s1 = "sign_pdq.rs" ascii
		$s2 = "x-pdq-dateCredential=(.+?)/" ascii
		$s3 = "pdq-connect-agent" ascii
		$s4 = "PDQ Connect Agent" ascii
		$s5 = "PDQConnectAgent" ascii
		$s6 = "PDQConnectAgentsrc\\logger.rs" ascii
		$s7 = "-PDQ-Key-IdsUser-Agent" ascii
		$s8 = "\\PDQ\\PDQConnectAgent\\" ascii
		$s9 = "\\pdq_connect_agent.pdb" ascii
		$s10 = "task_ids[]PDQ rover" ascii
		$s11 = "https://app.pdq.com/" ascii

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0xcfd0 ) and ( 4 of ( $s* ) or ( 3 of ( $api* ) and 1 of ( $s* ) ) )
}

rule DITEKSHEN_INDICATOR_RMM_Pdqconnect_Agent_CERT : FILE
{
	meta:
		description = "Detects PDQ Connect Agent by (default) certificate. Review RMM Inventory"
		author = "ditekSHen"
		id = "7e830cf0-8f47-5b38-85cd-9777a6878cf1"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L229-L243"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "373a32b8bfd8c4295ba0c0302a217ccfbb7c7c616f91035097adbc5384b8afdb"
		score = 75
		quality = 75
		tags = "FILE"

	condition:
		uint16( 0 ) == 0x5a4d and for any i in ( 0 .. pe.number_of_signatures ) : ( pe.signatures [ i ] . issuer contains "DigiCert, Inc." and pe.signatures [ i ] . subject contains "PDQ.com Corporation" )
}
rule DITEKSHEN_INDICATOR_RMM_Pulseway_Pcmontasksrv : FILE
{
	meta:
		description = "Detects Pulseway pcmontask and service user agent responsible for Remote Control, Screens View, Computer Lock, etc"
		author = "ditekSHen"
		id = "83901679-ffff-5710-b472-ece592e6764f"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L245-L266"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "80ba217960dd1ddeb220545c1cccbe96d9b676d327364e1ca8a9dde2b059261f"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.RMM.PulseWay"

	strings:
		$s1 = "MM.Monitor." ascii
		$s2 = "RDAgentSessionSettingsV" ascii
		$s3 = "CheckForMacOSRemoteDesktopUpdateCompletedEvent" ascii
		$s4 = "ConfirmAgentStarted" ascii
		$s5 = "GetScreenshot" ascii
		$s6 = "UnloadRemoteDesktopDlls" ascii
		$s7 = "CtrlAltDeleteProc" ascii
		$s8 = "$7cfc3b88-6dc4-49fc-9f0a-bf9e9113a14d" ascii
		$s9 = "computermonitor.mmsoft.ro" ascii

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0xcfd0 ) and 7 of them
}
rule DITEKSHEN_INDICATOR_RMM_Pulseway_Remotedesktop : FILE
{
	meta:
		description = "Detects Pulseway Rempte Desktop client"
		author = "ditekSHen"
		id = "8bca3cef-b24f-597a-a6e2-86040ed726f4"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L268-L286"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a542c11f21ab48f4da69df4e7cb46531658a714687e2c2f8ccf78dc2a0338b68"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.RMM.PulseWay"

	strings:
		$s1 = "RemoteControl" ascii
		$s2 = "MM.Monitor.RemoteDesktopClient." ascii
		$s3 = "MM.Monitor.RemoteControl" ascii
		$s4 = "RemoteDesktopClientUpdateInfo" ascii
		$s5 = "ShowRemoteDesktopEnabledSystemsOnly" ascii
		$s6 = "$31f50968-d45c-49d6-ace9-ebc790855a51" ascii

	condition:
		( uint16( 0 ) == 0x5a4d or uint16( 0 ) == 0xcfd0 ) and 5 of them
}

rule DITEKSHEN_INDICATOR_RMM_Pulseway_CERT : FILE
{
	meta:
		description = "Detects PulseWay by (default) certificate. Review RMM Inventory"
		author = "ditekSHen"
		id = "e00f51dc-261e-5a38-89ed-1899d9b522d4"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L288-L302"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c667caa9b7de4b166630c66e5162071948fa93c68b1cdb3038fce28e13dcb1a9"
		score = 75
		quality = 75
		tags = "FILE"

	condition:
		uint16( 0 ) == 0x5a4d and for any i in ( 0 .. pe.number_of_signatures ) : ( pe.signatures [ i ] . issuer contains "DigiCert, Inc." and pe.signatures [ i ] . subject contains "MMSOFT Design Ltd." )
}
rule DITEKSHEN_INDICATOR_RMM_Manageengine_Zohomeeting : FILE
{
	meta:
		description = "Detects ManageEngine Zoho Meeting (dc_rds.exe)"
		author = "ditekSHen"
		id = "b15efdd1-323c-5ed6-894d-b44f04d2eaf3"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L304-L324"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "8066bcd17245efcc73f2bef7f022ad23ab648fe0ad15ca66c0d387ce4eda998b"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.RMM.ManageEngine-ZohoMeeting"

	strings:
		$s1 = "bin\\ClientAuthHandler.dll" wide
		$s2 = "AgentHook.dll" wide
		$s3 = "UEMS - Remote Control" wide
		$s4 = "Install hook...." wide
		$s5 = "india.adventnet.com/meet.sas?k=" ascii
		$s6 = "dcTcpSocket::" ascii
		$s7 = "%s/%s?clientId=%s&sessionId=%s&clientName=%s&ticket=%s&connectionId=%s" ascii
		$s8 = ".\\engines\\ccgost\\gost_" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 5 of them
}
rule DITEKSHEN_INDICATOR_RMM_Atera : FILE
{
	meta:
		description = "Detects Atera. Review RMM Inventory"
		author = "ditekSHen"
		id = "9801f5c9-bc1e-5502-8bca-ee1f5ca0f497"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L345-L366"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "dbc37a941b38d36ea9bc31880c3cba6cd2b88b534583e86741f7686fcb410235"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.RMM.Atera"

	strings:
		$s1 = "SOFTWARE\\ATERA Networks\\AlphaAgent" wide
		$s2 = "Monitoring & Management Agent by ATERA" ascii wide
		$s3 = "agent-api-{0}.atera.com" wide
		$s4 = "agent-api.atera.com" wide
		$s5 = "acontrol.atera.com" wide
		$s6 = /Agent\/(PingReply|GetCommandsFallback|GetCommands|GetTime|GetEnvironmentStatus|GetRecurringPackages|AgentStarting|AcknowledgeCommands)/ wide
		$s7 = "\\AlphaControlAgent\\obj\\Release\\AteraAgent.pdb" ascii
		$s8 = "AteraWebAddress" ascii
		$s9 = "AlphaControlAgent.CloudLogsManager+<>" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}

rule DITEKSHEN_INDICATOR_RMM_Atera_CERT : FILE
{
	meta:
		description = "Detects Atera by certificate. Review RMM Inventory"
		author = "ditekSHen"
		id = "a5ccb684-1e28-51c8-a4d6-0b5abba97de0"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L368-L383"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f51fef767cd529271f06d578146634e1ab5ee5ac3ffb829cbaa870e7c69ca3f6"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.RMM.Atera"

	condition:
		uint16( 0 ) == 0x5a4d and for any i in ( 0 .. pe.number_of_signatures ) : ( pe.signatures [ i ] . issuer contains "DigiCert" and pe.signatures [ i ] . subject contains "Atera Networks Ltd" )
}
rule DITEKSHEN_INDICATOR_RMM_Splashtopstreamer : FILE
{
	meta:
		description = "Detects Splashtop Streamer. Review RMM Inventory"
		author = "ditekSHen"
		id = "317f2be4-983f-5528-b629-75a13de7b411"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L385-L403"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "67181cd6ae071074c6bf35f44963c11c9ee9b7df242027c15b1e165d108f7b98"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.RMM.SplashtopStreamer"

	strings:
		$s1 = "\\slave\\workspace\\GIT_WIN_SRS_Formal\\Source\\irisserver\\" ascii
		$s2 = ".api.splashtop.com" wide
		$s3 = "Software\\Splashtop Inc.\\Splashtop" wide
		$s4 = "restarted the streamer.%nApp version: %1" wide
		$s5 = "Splashtop-Splashtop Streamer-" wide
		$s6 = "[RemoveStreamer] Send msg 2 cloud(%d:%d:%d)" wide

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}

rule DITEKSHEN_INDICATOR_RMM_Splashtopstreamer_CERT : FILE
{
	meta:
		description = "Detects Splashtop Streamer by certificate. Review RMM Inventory"
		author = "ditekSHen"
		id = "7e0e4d6f-38a3-5cac-8a82-8aea7943d373"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L405-L419"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "0a1225a79ff30678846b9cb4315419be04b46276b3e05310a21d088b30f01b72"
		score = 75
		quality = 75
		tags = "FILE"

	condition:
		uint16( 0 ) == 0x5a4d and for any i in ( 0 .. pe.number_of_signatures ) : ( pe.signatures [ i ] . issuer contains "DigiCert" and pe.signatures [ i ] . subject contains "Splashtop Inc." )
}
rule DITEKSHEN_INDICATOR_RMM_Aeroadmin : FILE
{
	meta:
		description = "Detects AeroAdmin. Review RMM Inventory"
		author = "ditekSHen"
		id = "0f69c6da-40e4-5952-b6f9-ed401279eb9e"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L421-L442"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a0a9e15f31b6b06fbc749b863563c30351c775c1b1d17952013670e7e1d68c41"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.RMM.AeroAdmin"

	strings:
		$s1 = "\\AeroAdmin" wide
		$s2 = ".aeroadmin.com" ascii wide
		$s3 = "XAeroadminAppRestarter" wide
		$s4 = "SYSTEM\\ControlSet001\\Control\\SafeBoot\\Network\\AeroadminService" wide
		$s5 = "AeroAdmin {}" ascii
		$s6 = "FAeroAdmin.cpp" fullword ascii
		$s7 = "Referer: http://900100.net" ascii
		$s8 = "POST /sims/sims_new.php" ascii
		$s9 = "aeroadmin.pdb" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}

rule DITEKSHEN_INDICATOR_RMM_Aeroadmin_CERT : FILE
{
	meta:
		description = "Detects AeroAdmin by certificate. Review RMM Inventory"
		author = "ditekSHen"
		id = "ca34fd3c-eb76-57e3-8b62-ab0d0c9ec7b3"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L444-L461"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f1fe2d2bb6a8afd25fc5ee7a60fe5a931484591bafab24c5d488c7f0483e248a"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.RMM.AeroAdmin"

	condition:
		uint16( 0 ) == 0x5a4d and for any i in ( 0 .. pe.number_of_signatures ) : ( pe.signatures [ i ] . issuer contains "GlobalSign" and ( pe.signatures [ i ] . subject contains "Aeroadmin LLC" or pe.signatures [ i ] . subject contains "@aeroadmin.com" ) )
}
rule DITEKSHEN_INDICATOR_RMM_Dwagentlib : FILE
{
	meta:
		description = "Detect DWAgent Remote Administration Tool library"
		author = "ditekSHen"
		id = "af0f9940-fbec-5775-9b74-bd73b55ec0ca"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L463-L482"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "608dd9bc8cfcec5a671bee9456dccedace31d7ae37180387ac2408f79fd9f452"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.RMM.DWAgent-LIB"

	strings:
		$s1 = "DWAgentLib" fullword wide
		$s2 = "PYTHONHOME" fullword wide
		$s3 = "isTaskRunning" fullword ascii
		$s4 = "isUserInAdminGroup" fullword ascii
		$s5 = "setFilePermissionEveryone" fullword ascii
		$s6 = "startProcessInActiveConsole" fullword ascii
		$s7 = "taskKill" fullword ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}
rule DITEKSHEN_INDICATOR_RMM_Dwagentsvc : FILE
{
	meta:
		description = "Detect DWAgent Remote Administration Tool service"
		author = "ditekSHen"
		id = "5d124c20-a0f8-5e82-8bab-93a782a2a649"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L484-L501"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "590d41d2e433a7a1bb373fbd0b0d47818a9867bee0399101881b05e83b586f6e"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.RMM.DWAgent-SVC"

	strings:
		$s1 = "\\native\\dwagupd.dll" wide
		$s2 = "\\native\\dwagsvc.exe\" run" wide
		$s3 = "CreateServiceW" fullword ascii
		$s4 = /dwagent\.(pid|start|stop)/ wide
		$s5 = "Check updating..." wide

	condition:
		uint16( 0 ) == 0x5a4d and 4 of them
}
rule DITEKSHEN_INDICATOR_RMM_Dwagent_Screencapture : FILE
{
	meta:
		description = "Detect DWAgent Remote Administration Tool Screen Capture Module"
		author = "ditekSHen"
		id = "79586e5e-b7e5-5adc-97f3-0d29ad695079"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L503-L528"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "d3160fd4cce445aa6d2bc6c083893c7610ea5e72824fe9824ad853700f4d3874"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.RMM.DWAgent-ScreenCapture"

	strings:
		$s1 = "DWAgentLib" fullword wide
		$s2 = "PYTHONHOME" wide
		$s3 = "VirtualBox" wide
		$s4 = "VMware" wide
		$s5 = "ScreenCapture::prepareCursor#" ascii
		$s6 = "ScreenCapture::getMonitorCount#" ascii
		$s7 = "ScreenCapture::token" ascii
		$s8 = "dwascreencapture" ascii
		$s9 = "inputKeyboard CTRLALTCANC" ascii
		$s10 = "_Z34ScreenCaptureNativeMonitorEnumProc" ascii
		$s11 = "_Z41ScreenCaptureNativeCreateWindowThreadProc" ascii
		$s12 = "_ZN13ScreenCapture" ascii
		$s13 = "isUserInAdminGroup" ascii

	condition:
		uint16( 0 ) == 0x5a4d and 7 of them
}
rule DITEKSHEN_INDICATOR_RMM_Dwagent_Soundcapture : FILE
{
	meta:
		description = "Detect DWAgent Remote Administration Tool Sound Capture Module"
		author = "ditekSHen"
		id = "4e395d1e-96a1-5ecc-abe5-6f8323a2c8ca"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L530-L545"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "c0efa9f383373dec1c5b9d127c2b4c6f4906718ae8f62eea28d7a369001be5af"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Win.RMM.DWAgent-SoundCapture"

	strings:
		$s1 = "DWASoundCapture" ascii
		$s2 = /_Z\d{2}DWASoundCapture/ ascii
		$s3 = "_Z6recordPvS_" ascii

	condition:
		uint16( 0 ) == 0x5a4d and all of them
}

rule DITEKSHEN_INDICATOR_RMM_Dwagent_CERT : FILE
{
	meta:
		description = "Detects DWAgent by certificate. Review RMM Inventory"
		author = "ditekSHen"
		id = "96572e83-ffb9-58d9-93d1-84e16ae1a3ba"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L547-L563"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		hash = "4a13f46def2c9427898a46a88a6a2122ed106b37"
		logic_hash = "9ed86f053c8d1423aae8cfc6e0bba6021510dfb6d722430c8c7edb15d3e8233a"
		score = 75
		quality = 75
		tags = "FILE"

	condition:
		uint16( 0 ) == 0x5a4d and for any i in ( 0 .. pe.number_of_signatures ) : ( pe.signatures [ i ] . subject contains "DWSNET srl" and pe.signatures [ i ] . issuer contains "Sectigo Public Code Signing CA R36" and pe.signatures [ i ] . serial == "00:af:bd:d3:be:b2:4e:1d:e7:37:82:e9:f8:34:7c:f1:53" )
}
rule DITEKSHEN_INDICATOR_OSX_RMM_Dwagent : FILE
{
	meta:
		description = "Detect DWAgent Remote Administration Tool macOS run"
		author = "ditekSHen"
		id = "0eeb9ae3-826e-52b7-bbb8-3f8c4920f5c3"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L565-L580"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9864668abdd534d8a33940f9513d07356451ce1eaa9233771e82b8138dc0b41b"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Osx.RMM.DWAgent-RUN"

	strings:
		$s1 = "net.dwservice.DWAgent" ascii
		$s2 = "-[DWADelegate" ascii
		$s3 = "customWindowsToEnterFullScreenForWindow:onScreen:" ascii

	condition:
		uint16( 0 ) == 0xfeca and all of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Bazarloader : FILE
{
	meta:
		description = "Detects Bazar executables with specific email addresses found in the code signing certificate"
		author = "ditekShen"
		id = "94b814e3-56c2-5cdb-9335-c92eea8ec668"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L11-L21"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "fd47a1d996c78a6efc144f0fe0a28951c34becab3101e7d25acc980bb6b9f8ce"
		score = 75
		quality = 71
		tags = "FILE"

	strings:
		$s1 = "skarabeyllc@gmail.com" ascii wide nocase
		$s2 = "admin@intell-it.ru" ascii wide nocase
		$s3 = "support@pro-kon.ru" ascii wide

	condition:
		uint16( 0 ) == 0x5a4d and any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_Amadey : FILE
{
	meta:
		description = "Detects Amadey executables with specific email addresses found in the code signing certificate"
		author = "ditekShen"
		id = "f9abbf1d-2077-52a8-bfb0-df3732649624"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L39-L47"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "3df3fe67835f76e51743b1b4fa2cbc48277d82689c2fc27457b4d7d820e56e43"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "tochka.director@gmail.com" ascii wide nocase

	condition:
		uint16( 0 ) == 0x5a4d and any of them
}
rule DITEKSHEN_INDICATOR_KB_ID_UNK01 : FILE
{
	meta:
		description = "Detects Amadey executables with specific email addresses found in the code signing certificate"
		author = "ditekShen"
		id = "56e83bfb-e17d-5d27-87fa-e275cc540148"
		date = "2021-01-21"
		modified = "2024-01-23"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_knownbad_id.yar#L49-L58"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		hash = "37d08a64868c35c5bae8f5155cc669486590951ea80dd9da61ec38defb89a146"
		logic_hash = "d85461f74186fcabcbf7f2bc1dce06b0012c504cf3235a6fc3e1499dc6f8a3ee"
		score = 75
		quality = 73
		tags = "FILE"

	strings:
		$s1 = "etienne@tetracerous.br" ascii wide nocase

	condition:
		uint16( 0 ) == 0x5a4d and any of them
}
