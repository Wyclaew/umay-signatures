/*
    Umay heuristics: PowerShell.

    Globals supplied by the engine:
      umay_kind     identified content type ("script", "pe", "text", ...)
      umay_derived  true when the buffer was decoded out of another file
                    (base64 payloads, de-obfuscated text)

    umay_weight is the strength of one rule as evidence (1..99). The engine
    combines weights; nothing here condemns a file on its own unless marked
    umay_definitive.
*/

rule PowerShell_DownloadAndExecute
{
    meta:
        umay_name = "Heur.PowerShell.DownloadAndExecute"
        umay_weight = 40
        description = "Fetches content from the network and runs it without saving a file"
    strings:
        $get1 = "DownloadString" nocase ascii wide
        $get2 = "DownloadData" nocase ascii wide
        $get3 = "Net.WebClient" nocase ascii wide
        $get4 = "Invoke-WebRequest" nocase ascii wide
        $get5 = "Invoke-RestMethod" nocase ascii wide
        $get6 = /\b(iwr|irm)\s+['"(]?\s*https?:/ nocase ascii wide
        $run1 = "Invoke-Expression" nocase ascii wide
        $run2 = /\bIEX\b/ nocase ascii wide
        $run3 = "Reflection.Assembly]::Load" nocase ascii wide
    condition:
        (umay_kind == "script" or umay_derived) and filesize < 5MB
        and any of ($get*) and any of ($run*)
}

rule PowerShell_HiddenUnrestrictedLaunch
{
    meta:
        umay_name = "Heur.PowerShell.HiddenLaunch"
        umay_weight = 25
        description = "Starts PowerShell with no window and with script restrictions switched off"
    strings:
        $hidden = /-w(in(dowstyle)?)?\s+(hidden|1)\b/ nocase ascii wide
        $bypass = /-e(p|xecutionpolicy)\s+(bypass|unrestricted)\b/ nocase ascii wide
        $noprofile = /-nop(rofile)?\b/ nocase ascii wide
    condition:
        (umay_kind == "script" or umay_kind == "lnk" or umay_derived) and filesize < 5MB
        and $hidden and ($bypass or $noprofile)
}

rule PowerShell_EncodedCommand
{
    meta:
        umay_name = "Heur.PowerShell.EncodedCommand"
        umay_weight = 30
        description = "Passes a long base64-encoded command line to PowerShell"
    strings:
        $enc = /powershell(\.exe)?[^\r\n]{0,200}\s-e(nc(odedcommand)?)?\s+[A-Za-z0-9+\/=]{120}/ nocase ascii wide
    condition:
        (umay_kind == "script" or umay_kind == "lnk" or umay_derived) and filesize < 5MB and $enc
}

rule PowerShell_CompressedPayload
{
    meta:
        umay_name = "Heur.PowerShell.CompressedPayload"
        umay_weight = 40
        description = "Unpacks a compressed, base64-encoded block and executes the result"
    strings:
        $b64 = "FromBase64String" nocase ascii wide
        $zip1 = "IO.Compression.GzipStream" nocase ascii wide
        $zip2 = "IO.Compression.DeflateStream" nocase ascii wide
        $run1 = "Invoke-Expression" nocase ascii wide
        $run2 = /\bIEX\b/ nocase ascii wide
        $run3 = "Reflection.Assembly]::Load" nocase ascii wide
    condition:
        (umay_kind == "script" or umay_derived) and filesize < 5MB
        and $b64 and any of ($zip*) and any of ($run*)
}

rule PowerShell_AmsiBypass
{
    meta:
        umay_name = "Heur.PowerShell.AmsiBypass"
        umay_weight = 65
        description = "Tampers with the Windows script-scanning interface so later code is not inspected"
    strings:
        $utils = "AmsiUtils" nocase ascii wide
        $failed = "amsiInitFailed" nocase ascii wide
        $context = "amsiContext" nocase ascii wide
        $buffer = "AmsiScanBuffer" nocase ascii wide
        $patch1 = "VirtualProtect" nocase ascii wide
        $patch2 = "SetValue" nocase ascii wide
        $patch3 = "Marshal]::Copy" nocase ascii wide
    condition:
        (umay_kind == "script" or umay_derived) and filesize < 5MB
        and any of ($utils, $failed, $context, $buffer) and any of ($patch*)
}

rule PowerShell_DefenderTampering
{
    meta:
        umay_name = "Heur.PowerShell.DefenderTampering"
        umay_weight = 55
        description = "Disables Microsoft Defender protections or adds exclusions to hide from it"
    strings:
        $set = "Set-MpPreference" nocase ascii wide
        $add = "Add-MpPreference" nocase ascii wide
        $off1 = "DisableRealtimeMonitoring" nocase ascii wide
        $off2 = "DisableBehaviorMonitoring" nocase ascii wide
        $off3 = "DisableIOAVProtection" nocase ascii wide
        $off4 = "DisableScriptScanning" nocase ascii wide
        $excl1 = "ExclusionPath" nocase ascii wide
        $excl2 = "ExclusionProcess" nocase ascii wide
        $excl3 = "ExclusionExtension" nocase ascii wide
    condition:
        (umay_kind == "script" or umay_derived) and filesize < 5MB
        and (($set and any of ($off*)) or ($add and any of ($excl*)))
}

rule PowerShell_InMemoryInjection
{
    meta:
        umay_name = "Heur.PowerShell.InMemoryInjection"
        umay_weight = 55
        description = "Allocates executable memory and runs raw machine code from a script"
    strings:
        $alloc = "VirtualAlloc" nocase ascii wide
        $thread1 = "CreateThread" nocase ascii wide
        $thread2 = "CreateRemoteThread" nocase ascii wide
        $thread3 = "QueueUserAPC" nocase ascii wide
        $bridge1 = "GetDelegateForFunctionPointer" nocase ascii wide
        $bridge2 = "Marshal]::Copy" nocase ascii wide
        $bridge3 = "DllImport" nocase ascii wide
    condition:
        (umay_kind == "script" or umay_derived) and filesize < 5MB
        and $alloc and any of ($thread*) and any of ($bridge*)
}

rule PowerShell_CredentialDumping
{
    meta:
        umay_name = "Heur.PowerShell.CredentialDumping"
        umay_weight = 60
        description = "Reads the memory of the Windows login process to steal passwords"
    strings:
        $tool1 = "Invoke-Mimikatz" nocase ascii wide
        $tool2 = "sekurlsa::" nocase ascii wide
        $lsass = "lsass" nocase ascii wide
        $dump1 = "MiniDumpWriteDump" nocase ascii wide
        $dump2 = /comsvcs(\.dll)?[^\r\n]{0,40}MiniDump/ nocase ascii wide
    condition:
        (umay_kind == "script" or umay_derived) and filesize < 5MB
        and (any of ($tool*) or ($lsass and any of ($dump*)))
}

rule PowerShell_ShadowCopyRemoval
{
    meta:
        umay_name = "Heur.PowerShell.ShadowCopyRemoval"
        umay_weight = 60
        description = "Deletes Windows restore points, as ransomware does before encrypting files"
    strings:
        $class = "Win32_ShadowCopy" nocase ascii wide
        $del1 = ".Delete()" nocase ascii wide
        $del2 = "Remove-WmiObject" nocase ascii wide
        $del3 = "Remove-CimInstance" nocase ascii wide
    condition:
        (umay_kind == "script" or umay_derived) and filesize < 5MB and $class and any of ($del*)
}
